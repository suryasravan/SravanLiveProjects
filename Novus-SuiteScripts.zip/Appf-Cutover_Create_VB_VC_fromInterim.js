/*
* Script Name : Appf-Create VB/VC from Interim SC
* Script Type : Schedule Scipt
* Description : This script will check for Interim VB  header records with "Create VB/C" checked and creates vendor bill and vendor credit records and backlinks to Interim records. This script also uses sync fields script
* Company   :	Appficiency Inc.
*/
var SPARAM_INTERM_REC_TYPE = 'custscript_appf_interim_rec_type';
 var SPARAM_INTERM_REC_ID = 'custscript_appf_interim_rec_id';
 var SPARAM_INTERM_INDEX = 'custscript_appf_interim_lindex';
 
 var FLD_IS_CUTOVER_TRANSACTION = 'custbody_appf_cutover_transaction';
 
 var SCRIPT_SYNC_INTERIM_TO_VBVC = 'customscript_sync_interim_vbvc_sc';
 
var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'
var FLD_CR_INTERIM_VENDOR = 'custrecord_appf_ivb_vendor';
var FLD_CR_PO_LINE_NOS= 'custrecord_appf_ivbl_po_line_id';
var FLD_CR_NET_AMTS= 'custrecord_appf_ivbl_vendor_net';
var FLD_CR_PO_INTERNALID= 'custrecord_appf_ivbl_po_link';
var FLD_CR_INV_TRNS= 'custrecord_appf_ivb_transid';
var FLD_CR_IV_ON_BASED_ID= 'custrecord_appf_ivb_onbasedocid';
var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';
var FLD_CR_IV_DESCRIPTIONS= 'custrecord_appf_ivbl_description';
var FLD_CR_IV_IO_NUM= 'custrecord_appf_ivbl_io_num';
var FLD_CR_IV_CIRCULATIONS= 'custrecord_appf_ivbl_circulation';
var FLD_CR_IV_UNITS='custrecord_appf_ivbl_novus_unit_rt'
var FLD_CR_IV_VENDOR_NUM='custrecord_appf_ivb_vendoraccnum'
var FLD_CR_IV_TRANS='custrecord_appf_transactions_created';
var FLD_CR_IV_DUE_DATE='custrecord_appf_ivb_due_date';
var FLD_CR_IV_GST_HST='custrecord_appf_ivb_gst';
var FLD_CR_IV_PST_QST='custrecord_appf_ivb_qst';
var FLD_CR_IV_CURRENCY='custrecord_appf_ivb_currency';
var FLD_IV_GST_HST_VB_LINK = 'custrecord_appf_ivb_gst_hst_vb';
var FLD_IV_PST_QST_VB_LINK = 'custrecord_ivb_pst_qst_vb';
var FLD_TRANSACTIOMN_FAILURE = 'custrecord_appf_transaction_failure';
 var EXTERNAL_SCRIPTS_NAMES={'billposl':'1','vendorcreditsl':'2'}

var FLD_COL_PRINT_CIRCULATION='custcol_appf_print_circulation'
var FLD_COL_RATE='custcol_appf_novusunitrate'
var FLD_COL_MASTER='custcol_appf_masterlink'
var FLD_COL_LINKS='custcol_appf_childlink'
var FLD_COL_IO='custcol_appf_ionum'
var FLD_COL_PUBLISH='custcol_appf_publisher'
var FLD_COL_LINE_IDS='custcol_appf_line_id'
var FLD_COL_PP_RECS='custcol_appf_pwp_custom_record'
var FLD_COL_PO_LINES='custcol_appf_po_line_id'

var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';

var SPARAM_INTERM_RECS_SS = 'custscript_appf_cutover_interim_ss';
var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'

 var CUSTOM_RECORD_REC_LINE_INTERIM='customrecord_appf_interim_vb_line'
 var FLD_IV_VB_LINKS='custrecord_appf_ivbl_vblink'
 var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'
 var SPARAM_VB_FIELDS = 'custscript_vb_header_fields_sync';
 var SPARAM_VB_LINE_FIELDS = 'custscript_vb_line_fields_sync';
 var FLD_IV_VC_LINKS='custrecord_appf_ivbl_vclink'
 var SPARAM_VC_FIELDS = 'custscript_vc_header_fields_sync';
 var SPARAM_VC_LINE_FIELDS = 'custscript_vc_line_fields_sync';
 var FLD_IV_VC_NET='custrecord_appf_ivbl_vendor_net'
 var FLD_IV_VC_NET='custrecord_appf_ivbl_vendor_net'
 var CUSTOM_RECORD_PO_LINES='customrecord_appf_bill_po_lines_log'
 var FLD_PO_LINE_BILL_LINKS='custrecord_appf_bill_po_lines_bill_link'
 var FLD_PO_LINE_INTERM_LINKS='custrecord_appf_bill_po_lines_vb_header'
 var FLD_PO_LINE_INTERM_LINES_LINKS='custrecord_appf_bill_po_lines_vb_lines'
	
var FLD_PO_LINE_INTERM_LINES_PWPLINK = 'custrecord_appf_ivbl_pwplink';
	 
 
 var FLD_PO_BUYING_SYSTEM = 'custbody_appf_buying_system';
 
var SPARAM_IMMEDIATE_EXECUTION = 'custscript_created_from_ext_scripts';
var FLD_IV_CUTOVER_EXECUTION = 'ustrecord_appf_ivb_cutover_transaction';

var SCRIPT_BILL_PO_LINES_WS_SL = 'customscript_appf_bill_po_lines_ws_sl';
var DEPLOY_BILL_PO_LINES_WS_SL = 'customdeploy_appf_bill_po_lines_ws_sl';

var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED_SUCCESSFULLY = '4';
var STATUS_COMPLETED_WITH_ERRORS = '5';

//var ITEM_GST_HST_TAX = '95';
//var ITEM_QST_PST_TAX = '96';
//var CUSTOM_FORM_NOVUS_VB_TAX = '184';
//var CUSTOM_FORM_NOVUS_VC_TAX = '182';


var BUYINGSYSTEM_PRINT='1'
var BUYINGSYSTEM_OOH='2'
var BUYINGSYSTEM_DIGI='3'
var BUYINGSYSTEM_SPOT='4'

var FORM_PRINT='180'
var FORM_OOH='181'
var FORM_DIGI='179'
var FORM_SPOT='182'

var SPARAM_ITEM_GST_HST_TAX='custscript_gst_hst_tax_item';
var SPARAM_ITEM_QST_PST_TAX='custscript_qst_pst_tax_item';
var SPARAM_CUSTOM_FORM_NOVUS_VB_TAX='custscript_custom_form_for_vb_tax';
var SPARAM_CUSTOM_FORM_NOVUS_VC_TAX='custscript_custom_form_for_vc_tax';
var SPARAM_FOLDER_BILL_PO = 'custscript_appf_selected_pos_folder_id';
var SPARAM_UNIQUE_VENDORS_OBJ_DATA = 'custscript_appf_unique_vend_obj_data';
var SPARAM_UNIQUE_VENDOR_OBJ = 'custscript_appf_unique_vend_obj_data_3';

var SCRIPT_UPDATE_BILL_PO_SC = 'customscript_appf_update_bill_po_status';

var FLD_PO_LINE_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
var FLD_BILL_PO_RESULTS_FILE = 'custrecord_appf_bill_po_results_file';	
var FLD_PO_BACKLINKING_STATUS = 'custrecord_appf_po_backlinking_status_bp';
var SPARAM_BILL_PO_EXEC_ID = 'custscript_update_bill_po_id';
var SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP='7';

var FLD_PO_LINE_INTERM_DISCREPANT = 'custrecord_appf_cutover_discrepant';

function craeteVBVCfromInterim(type)
{
	var context=nlapiGetContext();
	
	var ITEM_GST_HST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_GST_HST_TAX);
	var ITEM_QST_PST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_QST_PST_TAX);
	var CUSTOM_FORM_NOVUS_VB_TAX =context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VB_TAX);
	var CUSTOM_FORM_NOVUS_VC_TAX = context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VC_TAX);

	
	var ssID = context.getSetting('SCRIPT', SPARAM_INTERM_RECS_SS)
	var context=nlapiGetContext();
	   
	  
	var scriptParamVBHeaderFields = context.getSetting('SCRIPT', SPARAM_VB_FIELDS)
	var scriptParamVBLineFields = context.getSetting('SCRIPT', SPARAM_VB_LINE_FIELDS)
	   
	var scriptParamVCHeaderFields = context.getSetting('SCRIPT', SPARAM_VC_FIELDS)
	var scriptParamVCLineFields = context.getSetting('SCRIPT', SPARAM_VC_LINE_FIELDS)
	  
   
	var loadSS=nlapiLoadSearch(null, ssID);
	var fils = [];
	  
		 //fils.push(new nlobjSearchFilter(FLD_IV_CUTOVER_EXECUTION, null, 'is', 'T')); 
		 
	 


  	 var ssType = loadSS.getSearchType();
	 var ssfilts = loadSS.getFilters()
	 fils=fils.concat(ssfilts);
	 var sscolumns=loadSS.getColumns();
	 var searchResults=getAllSearchResults(ssType, fils, sscolumns);
	 nlapiLogExecution('debug','searchResults',searchResults)
	 
		
	 if (searchResults != null && searchResults != '') 
	 {
		 var InterimIds=[]
		 var InterimLinesIds=[]
		 var vbIds=[]
		 nlapiLogExecution('debug','searchResults.length',searchResults.length)
		 for(var s = 0; s <searchResults.length; s++) 
		 {
					
			 var searchresult = searchResults[s];
			 var internalId =searchresult.getId()
			 InterimIds.push(internalId)
			 
			 
			 if (nlapiGetContext().getRemainingUsage() <= 3000 && parseInt(s)+1 < searchResults.length)
			 {
	
				 nlapiScheduleScript(nlapiGetContext().getScriptId(), nlapiGetContext().getDeploymentId(), null);
				 break;
			 }else{
				 if(internalId!=null && internalId!='')
				 {
					 var nsMater=nlapiLoadRecord(CUSTOM_RECORD_INTERIM,internalId);
					 var transids=nsMater.getFieldValue(FLD_CR_INV_TRNS);
					 var tranName=nsMater.getFieldValue('name');
					 var invOnbase=nsMater.getFieldValue(FLD_CR_IV_ON_BASED_ID)
					 var invdate=nsMater.getFieldValue('custrecord_appf_ivb_date');
					 var dueDate = nsMater.getFieldValue('custrecord_appf_ivb_due_date');
					 var terms = nsMater.getFieldValue('custrecord_appf_ivb_terms');
					 var paymentType = nsMater.getFieldValue('custrecord_appf_ivb_payment_type');
					 if (paymentType == null)
						 paymentType = '';
					 var nsOrderCounts=nsMater.getLineItemCount(CUSTOM_RECORD_REC_INTERIM)
					 var NsaltVendor=nsMater.getFieldValue('custrecord_appp_ivb_alternatevendor');
					 var mainVendor = nsMater.getFieldValue(FLD_CR_INTERIM_VENDOR);
					 var poNo=nsMater.getFieldValue(FLD_CR_IV_VENDOR_NUM)
					 var apAcc=nsMater.getFieldValue('custrecord_appf_ivb_account')
					 var vendorSubsidiary='';
					 if(mainVendor !=null && mainVendor !='')
						 vendorSubsidiary=nlapiLookupField('vendor',mainVendor,'subsidiary');

					 nlapiLogExecution('debug','nsOrderCounts',nsOrderCounts)
					 var refcounter = 1;
					 var reftrans = 0;
					 var vbErrorLog = '';
					 var totalProcessed = 0;
	  
					 var resultFileData = '';
					 var dataLines=[];
	  

					 var bDiscrepant = 'F';
					 for (var p = 1; p <=nsOrderCounts; p++)
					 {
						 var revisedTranNum =tranName+ '-'+refcounter;
						 var poLineNo=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_PO_LINE_NOS,p)
						 nlapiLogExecution('debug','poLineNo',poLineNo)
						 
						 if(((poLineNo != null)&&(poLineNo != ''))  && ((invdate != null) && (invdate != ''))){
							 var poLineAmounts=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_NET_AMTS,p)
							 var poid=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_PO_INTERNALID,p)
							 var podescription=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_DESCRIPTIONS,p)
							 var ioNum=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_IO_NUM,p)
							 var poCurculatns=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_CIRCULATIONS,p)
							 var poUnit=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_UNITS,p)
							 var internalLink=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,'id',p)
							 var exisingVBLink = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_IV_VB_LINKS,p);
							 var exisingVCLink = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_IV_VC_LINKS,p);
							 var pwpLink = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_PO_LINE_INTERM_LINES_PWPLINK,p);
							 
							 refcounter++
							 InterimLinesIds.push(internalLink)
							 
							 //10/14/2020  - add condition for checking status
							 bDiscrepant = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_PO_LINE_INTERM_DISCREPANT,p);
							 
							 
							 if(poLineAmounts != null && poLineAmounts != '' && poLineAmounts>0 && (exisingVBLink == null || exisingVBLink == ''))
							 {
								 var vbillCreateInternal=null;
								 nlapiLogExecution('debug','poid',poid)
								 try{
									 //check if poid is empty  - 9/24/2020
									 if((poid != null && poid != '' )&& (pwpLink != null && pwpLink != '' ) && (pwpLink != null && pwpLink != '' )  ){
										 nlapiLogExecution('debug','vbillCreatetrty',poid)
										 var vbillCreate=nlapiTransformRecord('purchaseorder',poid,'vendorbill',{'recordmode':'dynamic'})
										 nlapiLogExecution('debug','vbillCreate',vbillCreate)
										 vbillCreate.setFieldValue('tranid',revisedTranNum)
										 vbillCreate.setFieldValue('custbody_appf_onbase_docid',invOnbase)
										 vbillCreate.setFieldValue('trandate',invdate)
										 //10/14/2020  - add condition for checking status
										 if(bDiscrepant == 'T' || bDiscrepant == true){
											 vbillCreate.setFieldValue('approvalstatus','1')
										 }else{
											 vbillCreate.setFieldValue('approvalstatus','2')
										 }
										 
										 vbillCreate.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
										 vbillCreate.setFieldValue('custbody_appf_vendor_payment_type',paymentType);

										 if(invdate)
										 {
											 var nextOpenPostingPeriod=postingPeriod(invdate);
											 vbillCreate.setFieldValue('postingperiod',nextOpenPostingPeriod);
										 }
										 vbillCreate.setFieldValue('terms', terms);
										 vbillCreate.setFieldValue('duedate',dueDate);
										 vbillCreate.setFieldValue('custbody_appf_accnum_ocr', poNo);
				
				
				
										 if (apAcc != null && apAcc != '')
											 vbillCreate.setFieldValue('account', apAcc);

										 if(scriptParamVBHeaderFields!=null && scriptParamVBHeaderFields!='')
										 {
											 var vbHeaderFieldList = scriptParamVBHeaderFields.split(',');
											 for (var vh = 0; vh < vbHeaderFieldList.length; vh++)
											 {
												 var interimHeaderFieldID = vbHeaderFieldList[vh].split('|')[0];
												 var vbHeaderFieldID = vbHeaderFieldList[vh].split('|')[1];
												 var interimHeaderFieldValue = nsMater.getFieldValue(interimHeaderFieldID);
												 vbillCreate.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
											 }
										 }

			          
										 nlapiLogExecution('debug','vbillCreate.getLineItemCount',vbillCreate.getLineItemCount('item'))
										 for(var c=1; c<=vbillCreate.getLineItemCount('item'); c++)
										 {
									
											 var cmInvLineId = vbillCreate.getLineItemValue('item', FLD_COL_PO_LINES, c);
											 nlapiLogExecution('debug','cmInvLineId',cmInvLineId)
											 if(cmInvLineId == poLineNo)
											 {
												 nlapiLogExecution('debug','line id matches',cmInvLineId)

												 vbillCreate.selectLineItem('item', c);
										         vbillCreate.setCurrentLineItemValue('item', 'quantity', poLineAmounts);
			                                     vbillCreate.setCurrentLineItemValue('item', 'rate', 1);

												 vbillCreate.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
												 vbillCreate.setCurrentLineItemValue('item', 'description', podescription);
												 vbillCreate.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
												 vbillCreate.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
												 vbillCreate.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
												 vbillCreate.setCurrentLineItemValue('item', FLD_COL_LINKS, internalLink);
																	
																	
												 if(scriptParamVBLineFields!=null && scriptParamVBLineFields!='')
												 {
													 var vbLineFieldList = scriptParamVBLineFields.split(',');
													 for (var vl = 0; vl < vbLineFieldList.length; vl++)
													 {
														 var interimLineFieldID = vbLineFieldList[vl].split('|')[0];
														 var vbLineFieldID = vbLineFieldList[vl].split('|')[1];
														 nlapiLogExecution('debug','vbLineFieldID',vbLineFieldID)	

														 var interimLineFieldValue = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,interimLineFieldID, p);
														 //vendorBillRecord.selectLineItem('item', 1);
														 nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)	

														 if(interimLineFieldValue){
															 vbillCreate.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
															 //vendorBillRecord.commitLineItem('item');
														 }
														
														 
													 }
												 }
																	

												 try{  //added 9/24/2020
													 //nlapiLogExecution('debug','check error','before check error')	
													 vbillCreate.commitLineItem('item');
													 //nlapiLogExecution('debug','check error','after check error')	
												 }catch(errorVbillCreate){
													 nlapiLogExecution('debug','errorVbillCreate commitline',errorVbillCreate.message)	;
												 }
												
											 }
											 else
											 {
												 //nlapiLogExecution('debug','check error remove line','remove line')	
												 vbillCreate.removeLineItem('item', c);
												 c--;
											 }
										 }
										 try{
											 vbillCreateInternal=nlapiSubmitRecord(vbillCreate,true,true)
											 //vbillCreateInternal=nlapiSubmitRecord(vbillCreate)
											 nlapiLogExecution('debug','ID of created bill',vbillCreateInternal)	
										 }catch(errorVbillCreateInternal){
											 nlapiLogExecution('debug','errorVbillCreateInternal submit bill',errorVbillCreateInternal.message)	;
											
											 /*if(invdate == null || invdate == '' ){
												 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty.' + '\n';
												 resultFileData += 'Failed, '+'Date field is empty.'+','+dataLines[p]+'\n';
												 
											 }else */
											 if(ioNum == null || ioNum == '' ){
												 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
												 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
												 
											 }else if(pwpLink == null || pwpLink == '' ){
												 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
												 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
												 
											 }else{
												 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+errorVbillCreateInternal.message + '\n';
												 resultFileData += 'Failed, '+errorVbillCreateInternal.message+','+dataLines[p]+'\n';
											 }
											 

										 }

										 nlapiLogExecution('debug','vbillCreateInternal saved',vbillCreateInternal);
										 if(vbillCreateInternal!=null && vbillCreateInternal!='')
										 {
					
											 resultFileData += 'Success, ,'+dataLines[p]+'\n';

											 vbIds.push(vbillCreateInternal)
											 reftrans++
											 //nsMater.setLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vblink',p,vbillCreateInternal)
											 nlapiSubmitField(CUSTOM_RECORD_REC_LINE_INTERIM, internalLink, FLD_IV_VB_LINKS, vbillCreateInternal);
				
											 if(NsaltVendor!=null  && NsaltVendor!='')
											 {
												 var vendorRec=nlapiLoadRecord('vendorbill',vbillCreateInternal);
												 vendorRec.setFieldValue('entity',NsaltVendor)
												 nlapiSubmitRecord(vendorRec,true,true)
											 }
					 
										 }
										 nlapiLogExecution('debug','vbillCreateInternal',vbillCreateInternal);
									 }else{
										 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'poid is empty' + '\n';
										 resultFileData += 'Failed, '+'poid is empty'+','+dataLines[p]+'\n';
									 }

								 }
				
								 catch(e1)
								 {
									 if ( e1 instanceof nlobjError )
									 {
										 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+e1.getDetails() + '\n';
										 resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';

									 }
									 else
									 {
										 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+e1.toString() + '\n';
										 resultFileData += 'Failed, '+e1.toString()+','+dataLines[p]+'\n';

									 }

								 }
								 totalProcessed++;
			
				
							 }
							 if (poLineAmounts != null && poLineAmounts != '' && (exisingVCLink == null || exisingVCLink == '') && poLineAmounts < 0)
							 {
								 var cFormVC = '';
								 var poRec=nlapiLoadRecord('purchaseorder',poid)
								 var poTranID = poRec.getFieldValue('tranid');
								 var poentity=poRec.getFieldValue('entity')
								 var pobuyingSys=poRec.getFieldValue(FLD_PO_BUYING_SYSTEM)
								 var poCount=poRec.getLineItemCount('item')
				
								 if(pobuyingSys==BUYINGSYSTEM_PRINT)
									 cFormVC=FORM_PRINT;
								 if(pobuyingSys==BUYINGSYSTEM_OOH)
									 cFormVC=FORM_OOH;
								 if(pobuyingSys==BUYINGSYSTEM_DIGI)
									 cFormVC=FORM_DIGI;
								 if(pobuyingSys==BUYINGSYSTEM_SPOT)
									 cFormVC=FORM_SPOT;
				
								 try{
									 var vcCreate=nlapiCreateRecord('vendorcredit');
									 refcounter++;
									 //nlapiLogExecution('debug','vcCreate',vcCreate)
									 if (cFormVC != '')
										 vcCreate.setFieldValue('customform',cFormVC)
									 if(NsaltVendor!=null  && NsaltVendor!='')
									 {
										 vcCreate.setFieldValue('entity',NsaltVendor)
									 }
									 else
									 {
										 vcCreate.setFieldValue('entity',poentity)
									 }
									 vcCreate.setFieldValue('tranid',revisedTranNum)
									 vcCreate.setFieldValue('custbody_appf_onbase_docid',invOnbase)
									 vcCreate.setFieldValue('trandate',invdate)
									 vcCreate.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
									 vcCreate.setFieldValue('custbody_appf_vendor_payment_type',paymentType);

									 if(invdate)
									 {
										 var nextOpenPostingPeriod=postingPeriod(invdate);
										 vcCreate.setFieldValue('postingperiod',nextOpenPostingPeriod);
									 }
									 vcCreate.setFieldValue('custbody_appf_accnum_ocr', poNo);
									 if (apAcc != null && apAcc != '')
										 vcCreate.setFieldValue('account', apAcc);

									 if(scriptParamVCHeaderFields!=null && scriptParamVCHeaderFields!='')
									 {
										 var vcHeaderFieldList = scriptParamVCHeaderFields.split(',');
										 for (var vh = 0; vh < vcHeaderFieldList.length; vh++)
										 {
											 var interimHeaderFieldID = vcHeaderFieldList[vh].split('|')[0];
											 var vbHeaderFieldID = vcHeaderFieldList[vh].split('|')[1];
											 var interimHeaderFieldValue = nsMater.getFieldValue(interimHeaderFieldID);
											 vcCreate.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
										 }
									 }
					
									 var poLineNum=poRec.findLineItemValue('item','custcol_appf_po_line_id',poLineNo)
									 var poItem=poRec.getLineItemValue('item','item',poLineNum)
									 var poStrat=poRec.getLineItemValue('item','custcolappf_so_line_startdate',poLineNum)
									 var poendDat=poRec.getLineItemValue('item','custcol_appf_so_line_enddate',poLineNum)
									 var poPublishs=poRec.getLineItemValue('item',FLD_COL_PUBLISH,poLineNum)
									 var soLineIds=poRec.getLineItemValue('item',FLD_COL_LINE_IDS,poLineNum)
									 var ppLineIds=poRec.getLineItemValue('item',FLD_COL_PP_RECS,poLineNum)
									 var poLineIds=poRec.getLineItemValue('item',FLD_COL_PO_LINES,poLineNum)
									 var pocust = poRec.getLineItemValue('item','customer',poLineNum)
									 vcCreate.selectNewLineItem('item');
									 vcCreate.setCurrentLineItemValue('item', 'item', poItem);
									 vcCreate.setCurrentLineItemValue('item', 'quantity', (-1)*poLineAmounts);
									 vcCreate.setCurrentLineItemValue('item', 'rate', 1);

									 vcCreate.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
									 vcCreate.setCurrentLineItemValue('item', 'description', podescription);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_PUBLISH, poPublishs);
									 vcCreate.setCurrentLineItemValue('item', 'custcolappf_so_line_startdate', poStrat);
									 vcCreate.setCurrentLineItemValue('item', 'custcol_appf_so_line_enddate', poendDat);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_LINE_IDS, soLineIds);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_PP_RECS, ppLineIds);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_PO_LINES, poLineIds);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
									 vcCreate.setCurrentLineItemValue('item', FLD_COL_LINKS, internalLink);
									 if (pocust != null && pocust != '')
										 vcCreate.setCurrentLineItemValue('item', 'customer', pocust);

									 if(scriptParamVCLineFields!=null && scriptParamVCLineFields!='')
									 {
										 var vcLineFieldList = scriptParamVCLineFields.split(',');
										 for (var vl = 0; vl < vcLineFieldList.length; vl++)
										 {
											 var interimLineFieldID = vcLineFieldList[vl].split('|')[0];
											 var vbLineFieldID = vcLineFieldList[vl].split('|')[1];

											 var interimLineFieldValue = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM, interimLineFieldID, p);
											 nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
											 nlapiLogExecution('debug','vbLineFieldID',vbLineFieldID)

											 if(interimLineFieldID==FLD_IV_VC_NET)
											 {
												 interimLineFieldValue=Math.abs(interimLineFieldValue);
												 nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
											 }
											 vcCreate.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
										 }
									 }

									 vcCreate.commitLineItem('item');
							
									 try{
										 var vcCreateIds=nlapiSubmitRecord(vcCreate,true,true)
										 
									 }catch(errorVcCreate){
										 /*if(invdate == null || invdate == '' ){
											 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty.' + '\n';
											 resultFileData += 'Failed, '+'Date field is empty.'+','+dataLines[p]+'\n';
											 
										 }else */
										 if(ioNum == null || ioNum == '' ){
											 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
											 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
											 
										 }else if(pwpLink == null || pwpLink == '' ){
											 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
											 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
											 
										 }else{
											 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+errorVcCreate.message + '\n';
											 resultFileData += 'Failed, '+errorVcCreate.message+','+dataLines[p]+'\n';
										 }
										 

									 }
									 
									 nlapiLogExecution('debug','vcCreateIds',vcCreateIds)
									 if(vcCreateIds!=null && vcCreateIds!='')
									 {
										 resultFileData += 'Success, ,'+dataLines[p]+'\n';

										 nlapiLogExecution('debug','vcCreateIds',vcCreateIds)	
										 reftrans++
										 //nsMater.setLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vclink',p,vcCreateIds)
										 nlapiSubmitField(CUSTOM_RECORD_REC_LINE_INTERIM, internalLink, FLD_IV_VC_LINKS, vcCreateIds);

			                                                                

									 }
								 }
				
								 catch(e1)
								 {
									 if ( e1 instanceof nlobjError )
									 {
										 vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.getDetails() + '\n';
										 resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';

									 }
									 else
									 {
										 vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.toString() + '\n';
										 resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';

									 }
								 }
							 }
							 
						 }else{
							 if(poLineNo == null || poLineNo == ''){
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID: null, Reason: '+'PO Line ID is empty' + '\n';
								 resultFileData += 'Failed, '+'PO Line ID is empty'+','+dataLines[p]+'\n';
							 }
							 if(invdate == null || invdate == ''){
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID: '+poLineNo+', Reason: '+'Date field is empty' + '\n';
								 resultFileData += 'Failed, '+'Date field is empty'+','+dataLines[p]+'\n';
							 }

						 }
						 

		
		
		
					 }
			

					 if(vbErrorLog == '' || vbErrorLog == null)
					 {
						 nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['T', '', '2']);
						 //nlapiScheduleScript(SCRIPT_SYNC_INTERIM_TO_VBVC, null, params);

						 //syncRecords(CUSTOM_RECORD_INTERIM, internalId);
						 nlapiLogExecution('debug','NsaltVendor','NsaltVendor')

					 }
					 else
					 {
						 nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['F',vbErrorLog, '2'])

					 }
		
		
					 var gsthst=nsMater.getFieldValue(FLD_CR_IV_GST_HST);
					 var pstqst=nsMater.getFieldValue(FLD_CR_IV_PST_QST);
					 var existingGSTLink = nsMater.getFieldValue(FLD_IV_GST_HST_VB_LINK);
					 var existingPSTLink = nsMater.getFieldValue(FLD_IV_PST_QST_VB_LINK);
	 

					 if(gsthst != null && gsthst != '' && parseFloat(gsthst)>0 && (existingGSTLink == null || existingGSTLink == '')&& vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
						 nlapiLogExecution('debug','create vendor bill 1','create vendor bill 1')
						 var vbRec = nlapiCreateRecord('vendorbill');
			
						 if(NsaltVendor!=null  && NsaltVendor!='')
						 {
							 vbRec.setFieldValue('entity',NsaltVendor)
						 }
						 else
						 {
							 vbRec.setFieldValue('entity', mainVendor);
				  
						 }
						 vbRec.setFieldValue('tranid',tranName+'-GST/HST');
						 nlapiLogExecution('debug','tranid',tranName+'-GST/HST');
						 vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
						 nlapiLogExecution('debug','customform',CUSTOM_FORM_NOVUS_VB_TAX)
						 vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
						 vbRec.setFieldValue('trandate',invdate);
						 vbRec.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
						 vbRec.setFieldValue('approvalstatus','2')
						 
						 vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
						 nlapiLogExecution('debug','invdate',invdate)
						 if(invdate)
						 {
							 var nextOpenPostingPeriod=postingPeriod(invdate);
							 vbRec.setFieldValue('postingperiod',nextOpenPostingPeriod);
							 nlapiLogExecution('debug','nextOpenPostingPeriod',nextOpenPostingPeriod)
						 }
						 vbRec.setFieldValue('terms', terms);
						 vbRec.setFieldValue('duedate',dueDate);
						 vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
						 nlapiLogExecution('debug','apAcc current',apAcc)	;
						 if (apAcc != null && apAcc != '')
							 vbRec.setFieldValue('account', apAcc);
	       
						 try{
							 vbRec.selectNewLineItem('item');
							 vbRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
							 nlapiLogExecution('debug','ITEM_GST_HST_TAX',ITEM_GST_HST_TAX)
							 vbRec.setCurrentLineItemValue('item', 'rate', 1);
							 vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(gsthst));
							 nlapiLogExecution('debug','quantity',parseFloat(gsthst))
							 vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
							 vbRec.commitLineItem('item');
						 }catch(errorNewVBIDLine){
							 nlapiLogExecution('debug','errorNewVBIDLine',errorNewVBIDLine)	;
							 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+errorNewVBIDLine.message + '\n';
							 resultFileData += 'Failed, '+errorNewVBIDLine.message+','+dataLines[p]+'\n';

						 }

						 
						 try{
							 /*nlapiLogExecution('debug','account used',vcRec.getFieldValue('account'));*/
							 var newVBID = nlapiSubmitRecord(vbRec, true, true);
							 if(newVBID != null && newVBID != ''){
								 nlapiLogExecution('debug', 'newVBID', newVBID);
								 nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_GST_HST_VB_LINK, newVBID);
							 }
							 
						 }catch(errorNewVBID){
							 nlapiLogExecution('debug','errorNewVBID submit bill',errorNewVBID)	;
							 /*if(invdate == null || invdate == '' ){
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty.' + '\n';
								 resultFileData += 'Failed, '+'Date field is empty'+','+dataLines[p]+'\n';
							 }else */
							 if(ioNum == null || ioNum == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
								 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
								 
							 }else if(pwpLink == null || pwpLink == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
								 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
								 
							 }else{
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+errorNewVBID.message + '\n';
								 resultFileData += 'Failed, '+errorNewVBID.message+','+dataLines[p]+'\n';
							 }

						 }
						 

			
					 }
					 if(gsthst != null && gsthst != '' && parseFloat(gsthst)<0 && (existingGSTLink == null || existingGSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
						 nlapiLogExecution('debug','create vendor credit 1','create vendor credit 1')
						 var vcRec = nlapiCreateRecord('vendorcredit');
						 if(NsaltVendor!=null  && NsaltVendor!='')
						 {
							 vcRec.setFieldValue('entity',NsaltVendor)
						 }
						 else
						 {
							 vcRec.setFieldValue('entity', mainVendor);
				  
						 }
						 // vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
						 vcRec.setFieldValue('tranid',tranName+'-GST/HST')
						 vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
						 vcRec.setFieldValue('trandate',invdate)
						 vcRec.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
						 vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);


						 if(invdate)
						 {
							 var nextOpenPostingPeriod=postingPeriod(invdate);
							 vcRec.setFieldValue('postingperiod',nextOpenPostingPeriod);
							 nlapiLogExecution('debug','nextOpenPostingPeriod',nextOpenPostingPeriod)
						 }
						 vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
						 if (apAcc != null && apAcc != '')
							 vcRec.setFieldValue('account', apAcc);
						 
						 vcRec.selectNewLineItem('item');
						 vcRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
						 vcRec.setCurrentLineItemValue('item', 'rate', 1);
						 nlapiLogExecution('debug','quantity',Math.abs(parseFloat(gsthst)))
						 vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(gsthst)));
						 vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
					     vcRec.commitLineItem('item');

					     
					     
					     try{
					    	 nlapiLogExecution('debug','account used',vcRec.getFieldValue('account'));
						     var newVCID = nlapiSubmitRecord(vcRec, true, true);
						     if(newVCID != null && newVCID != ''){
						    	 nlapiLogExecution('debug', 'newVCID', newVCID);
						    	 nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_GST_HST_VB_LINK, newVCID);
						     }
					    	 
					     }catch(errorNewVCID){
							 nlapiLogExecution('debug','errornewVCID submit vc',errorNewVCID.message)	;
							 
							 /*if(invdate == null || invdate == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty' + '\n';
								 resultFileData += 'Failed, '+errorNewVCID.message+','+dataLines[p]+'\n';
							 }else */
							 if(ioNum == null || ioNum == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
								 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
								 
							 }else if(pwpLink == null || pwpLink == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
								 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
								 
							 }else{
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+errorNewVCID.message + '\n';
								 resultFileData += 'Failed, '+'Date field is empty'+','+dataLines[p]+'\n';
							 }
							
					     }

			
					 }
		
					 if(pstqst != null && pstqst != '' && parseFloat(pstqst)>0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
						 nlapiLogExecution('debug','create vendor bill 2','create vendor bill 2')
						 var vbRec = nlapiCreateRecord('vendorbill');
						 if(NsaltVendor!=null  && NsaltVendor!='')
						 {
							 vbRec.setFieldValue('entity',NsaltVendor)
						 }
						 else
						 {
							 vbRec.setFieldValue('entity', mainVendor);
				  
						 }
						 vbRec.setFieldValue('tranid',tranName+'-PST/QST');
						 vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
						 vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
						 vbRec.setFieldValue('trandate',invdate);
						 vbRec.setFieldValue('approvalstatus','2')

						 vbRec.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
						 vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);

						 if(invdate)
						 {
							 var nextOpenPostingPeriod=postingPeriod(invdate);
							 vbRec.setFieldValue('postingperiod',nextOpenPostingPeriod);
						 }
						 vbRec.setFieldValue('terms', terms);
						 vbRec.setFieldValue('duedate',dueDate);
						 vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
						 if (apAcc != null && apAcc != '')
							 vbRec.setFieldValue('account', apAcc);
	       
						 vbRec.selectNewLineItem('item');
						 vbRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
						 vbRec.setCurrentLineItemValue('item', 'rate', 1);
						 vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(pstqst));
						 vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
						 vbRec.commitLineItem('item');

						 try{
							 var newVBID = nlapiSubmitRecord(vbRec, true, true);
							 if(newVBID != null && newVBID != ''){
								 nlapiLogExecution('debug', 'newVBID', newVBID);
								 nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_PST_QST_VB_LINK, newVBID);
							 }
						 }catch(errorNewVBID){
							 nlapiLogExecution('debug','errorNewVBID submit bill',errorNewVBID.message)	;
							 /*if(invdate == null || invdate == '' ){
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty.'+ '\n';
								 resultFileData += 'Failed, '+'Date field is empty.'+','+dataLines[p]+'\n';
							 }else */
							 if(ioNum == null || ioNum == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
								 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
								 
							 }else if(pwpLink == null || pwpLink == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
								 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
								 
							 }else{
								 vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+errorNewVBID.message + '\n';
								 resultFileData += 'Failed, '+errorNewVBID.message+','+dataLines[p]+'\n';
							 }
							 

						 }

			
					 }
					 if(pstqst != null && pstqst != '' && parseFloat(pstqst)<0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
						 nlapiLogExecution('debug','create vendor credit 2','create vendor credit 2')
						 var vcRec = nlapiCreateRecord('vendorcredit');
						 if(NsaltVendor!=null  && NsaltVendor!='')
						 {
							 vcRec.setFieldValue('entity',NsaltVendor)
						 }
						 else
						 {
							 vcRec.setFieldValue('entity', mainVendor);
				  
						 }
						 // vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
						 vcRec.setFieldValue('tranid',tranName+'-PST/QST')
						 vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
						 vcRec.setFieldValue('trandate',invdate)
						 vcRec.setFieldValue(FLD_IS_CUTOVER_TRANSACTION, 'T');
						 vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);


						 if(invdate)
						 {
							 var nextOpenPostingPeriod=postingPeriod(invdate);
							 vcRec.setFieldValue('postingperiod',nextOpenPostingPeriod);
						 }
						 vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
						 if (apAcc != null && apAcc != '')
							 vcRec.setFieldValue('account', apAcc);
						 vcRec.selectNewLineItem('item');
						 vcRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
						 vcRec.setCurrentLineItemValue('item', 'rate', 1);
						 vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(pstqst)));
						 vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
						 vcRec.commitLineItem('item');

						 try{
							 var newVCID = nlapiSubmitRecord(vcRec, true, true);
							 if(newVCID != null && newVCID != ''){
								 nlapiLogExecution('debug', 'newVCID', newVCID);
								 nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_PST_QST_VB_LINK, newVCID);
							 }
						 }catch(errorNewVCID){
							 nlapiLogExecution('debug','errornewVCID submit vc',errorNewVCID.message)	;
							 
							 /*if(invdate == null || invdate == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'Date field is empty.' + '\n';
								 resultFileData += 'Failed, '+'Date field is empty.'+','+dataLines[p]+'\n';
							 }else */
							 if(ioNum == null || ioNum == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
								 resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
								 
							 }else if(pwpLink == null || pwpLink == '' ){
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
								 resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
								 
							 }else{
								 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+errorNewVCID.message + '\n';
								 resultFileData += 'Failed, '+errorNewVCID.message+','+dataLines[p]+'\n';
							 }
							 

						 }

			
					 }
		
				 }
			 }
			 
			 


			 /*if (nlapiGetContext().getRemainingUsage() <= 3000 && parseInt(s)+1 < searchResults.length)
			 {
	
				 nlapiScheduleScript(nlapiGetContext().getScriptId(), nlapiGetContext().getDeploymentId(), null);
				 break;
			 }*/

		 }
    
	 }
	
	
}

function getAllSearchResults(record_type, filters, columns)
{
	var searchRes = nlapiCreateSearch(record_type, filters, columns);
	searchRes.setIsPublic(true);

	var searchRan = searchRes.runSearch()
	, bolStop = false
	, intMaxReg = 1000
	, intMinReg = 0
	, result = [];

	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
	{
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000)
		{
		bolStop = true;
		}
	}

	return result;
}

function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};
	
	for (i=0;i<len;i++) {
	obj[arr[i]]=0;
	}
	for (i in obj) {
	out.push(i);
	}
	return out;
}
function postingPeriod(date)
{
	date=nlapiStringToDate(date);
	var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
	var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
	var Dt1 = nlapiDateToString(startDate);
	var Dt2 = nlapiDateToString(endDate);
	var filters = new Array();
	filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
	filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
	filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
	filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
	//filters[4] = new nlobjSearchFilter('closed',null,'is','F');
	
	var columns = new Array();
	columns[0] = new nlobjSearchColumn('internalid');
	columns[1] = new nlobjSearchColumn('closed');
	var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters, columns);
	var periodId=''
	if(searchAccPeriods!=null && searchAccPeriods!='')
	{
	var isclosedperiod = searchAccPeriods[0].getValue('closed');
	if(isclosedperiod!='T')
	{
	periodId=searchAccPeriods[0].getValue('internalid');
	}
	else
	{
	var filters1 = new Array();
	filters1[0] = new nlobjSearchFilter('startdate', null, 'onorafter', Dt1);
	filters1[1] = new nlobjSearchFilter('enddate', null, 'onorafter', Dt2);
	filters1[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
	filters1[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
	filters1[4] = new nlobjSearchFilter('closed',null,'is','F');
	
	var columns1 = new Array();
	columns1[0] = new nlobjSearchColumn('internalid');
	columns1[1] = new nlobjSearchColumn('enddate');
	columns1[1].setSort();
	var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters1, columns1);
	if(searchAccPeriods!=null && searchAccPeriods!='')
	{
	periodId=searchAccPeriods[0].getValue('internalid');
	}
	}
	}
	
	return periodId;
 }