/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 * 
 * Appficiency Copyright 2021
 * 
 * Description: Set Discrepant Status of Vendor Bill = Discrepant - Circulation Lower.
 * 
 * Author: Roach
 * Date: Feb 02, 2021
 */
define(['N/record'],

function(record) {
   var FLD_VB_COL_DISCREPANT_STATUS = 'custcol_appf_discrepancy_type';
   var VAL_DISCREPANT_STATUS = 10;
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @Since 2016.1
     */
    function onAction(scriptContext) {
    	var currentRecord = scriptContext.newRecord; 
    	var recVB = record.load({type: record.Type.VENDOR_BILL,id: currentRecord.id,isDynamic: true});
		var lineCount = recVB.getLineCount({sublistId: 'item'});
		for(var i = 0; i < lineCount; i++) {
			recVB.selectLine({sublistId: 'item',line: i});
			recVB.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_VB_COL_DISCREPANT_STATUS,value: VAL_DISCREPANT_STATUS});
			recVB.commitLine({sublistId: 'item'});
		}
    	
    	recVB.save();

    }

    return {
        onAction : onAction
    };
    
});
