/*
*Script Name: Appf-Update PWP Record from PO UE
*Script Type: User Event
*Description: 
*Company 	: Appficiency Inc.

*/

var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_PO_LINK = 'custrecord_appf_pwp_po_link';
var FLD_PWP_PO_LINE_AMT = 'custrecord_appf_pwp_po_line_amount';
var FLD_PWP_PO_LINE_ID = 'custrecord_appf_pwp_po_line_id';

var SCRIPT_UPDATE_PWP_FROM_PO_SC = 'customscript_appf_update_pwp_rec_po_sc';

var SPARAM_PURCH_ORD_ID = 'custscript_appf_purch_ord_id'; 
var SPARAM_UPDATE_PWP_PURCH_ORD_SS = 'custscript_appf_update_pwp_pos_ss';

function updatePWPPOAfterSubmit(type) {
	var context = nlapiGetContext();
	if(context.getExecutionContext() != 'scheduled'){
			var poSS = context.getSetting('SCRIPT', SPARAM_UPDATE_PWP_PURCH_ORD_SS);

	if(type != 'delete'){
		var recType = nlapiGetRecordType();
		var recId = nlapiGetRecordId();
		var po = nlapiLoadRecord(recType, recId);
		var count = po.getLineItemCount('item');
		
		if(count <= 60){		
			for(var i=1; i<=count; i++){
				try{
				var pwpRecId = po.getLineItemValue('item', FLD_COL_PWP_RECORD, i);
				var soLineId = po.getLineItemValue('item', FLD_COL_SO_LINE_ID, i);
				if(pwpRecId != null && pwpRecId != '' && soLineId != null && soLineId != '' && poSS != null && poSS != ''){				
					
					var filters = [];
					filters.push(new nlobjSearchFilter(FLD_COL_SO_LINE_ID, null, 'is', soLineId));
						
					var poSearchResults = nlapiSearchRecord(null, poSS, filters, null);
					if(poSearchResults != null && poSearchResults != ''){
						var poIdsArr = [];
						var poLineIdsArr = [];
						var poAmtSum = 0;
						for(var j=0; j<poSearchResults.length; j++){
							var result = poSearchResults[j];
							var poId = result.getId();
							var ssCols = result.getAllColumns();
							var poLineId = result.getValue(ssCols[0]);
							var poAmt = result.getValue(ssCols[1]);
							if(poAmt == null || poAmt == '')
								poAmt = 0;

							poIdsArr.push(poId);
							poLineIdsArr.push(poLineId);
							poAmtSum = parseFloat(poAmtSum) + parseFloat(poAmt);
						}	
						poIdsArr = eliminateDuplicates(poIdsArr);
						poLineIdsArr = eliminateDuplicates(poLineIdsArr);
						var poLineIds = '';
						for(var l=0; l<poLineIdsArr.length; l++){
							if(l == (poLineIdsArr.length-1))
								poLineIds += poLineIdsArr[l];
							else
								poLineIds += poLineIdsArr[l] + ',';
						}
						
						nlapiLogExecution('debug', 'poLineIds', poLineIds);
						var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
						pwpRecord.setFieldValues(FLD_PWP_PO_LINK, poIdsArr);
						pwpRecord.setFieldValue(FLD_PWP_PO_LINE_ID, poLineIds);
						if(poAmtSum != null && poAmtSum != '')
							poAmtSum = Number(poAmtSum).toFixed(2);
						pwpRecord.setFieldValue(FLD_PWP_PO_LINE_AMT, poAmtSum);
						
						var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
						nlapiLogExecution('DEBUG', 'pwpId', pwpId);
					}
					
				}
			}catch(e){
				if ( e instanceof nlobjError )
					  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
					  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
			}
		}
		else{
			var params = {};
			params[SPARAM_PURCH_ORD_ID] = recId;
			nlapiScheduleScript(SCRIPT_UPDATE_PWP_FROM_PO_SC, null, params);
		}
	}
	}
}

function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}