/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Adds Print button to CI record to open suitelet pdf
 * 
 * Author: Rochelle Tapulado
 * Date: Aug 03, 2020
 */

define(['N/record','N/url','N/search'],

function(record,url,search) {
	var VAL_SL_SCRIPT_CONSOLIDATED_PDF_INVOICE = 'customscript_sl_consolidated_pdf_invoice';
	var VAL_SL_DEPLOY_CONSOLIDATED_PDF_INVOICE = 'customdeploy_sl_consolidated_pdf_invoice';
	var VAL_BTN_PRINT_BUTTON = 'custpage_button_consolidated_pdf';
	var VAL_PARAM_CI_ID = 'custparam_ci_id';
	var FLD_CI_PDF_LAYOUT = 'custrecord_appf_ci_pdf_layout';
	var VAL_PARAM_CI_PDF_LAYOUT = 'custparam_ci_pdf_layout';
	var FLD_INV_CI = 'custcol_appf_ci_record';
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	if (scriptContext.type == scriptContext.UserEventType.VIEW) {
    		var rec = scriptContext.newRecord;
    		var idPDFLayout = rec.getValue({
    		    fieldId: FLD_CI_PDF_LAYOUT
    		});
    		var idCI = rec.id;
    		
    		//check if lines > 2
    		if(countInvoices(idCI) >= 1){
        		var pdfSuiteletUrl = url.resolveScript({
        		    scriptId: VAL_SL_SCRIPT_CONSOLIDATED_PDF_INVOICE,
        		    deploymentId: VAL_SL_DEPLOY_CONSOLIDATED_PDF_INVOICE,
        		    returnExternalUrl: false
        		});
        		pdfSuiteletUrl += '&'+VAL_PARAM_CI_ID+'='+rec.id;
        		pdfSuiteletUrl += '&'+VAL_PARAM_CI_PDF_LAYOUT+'='+idPDFLayout;
        		
        		scriptContext.form.addButton({
        		    id : VAL_BTN_PRINT_BUTTON,
        		    label : 'Print',
        		    /*functionName: 'window.open(myUrl, target="_blank")'*/
        		    /*functionName: 'window.open('+ pdfSuiteletUrl +', target="_blank");'*/
        		    functionName: 'window.open("'+ pdfSuiteletUrl +'");'
        		});
    		}

    	}
    }
    
    /**
     * Count linked invoices to CI record
     */
    function countInvoices(idCI){
    	var searchObj = search.create({
	     	   type: 'transaction',
	     	   filters:
	     	   [
	     	      [FLD_INV_CI,'is',idCI]
	     	   ],
	     	   columns:
	     	   [
	     	      search.createColumn({
	     	         name: 'tranid'
	     	      }),
	     	      search.createColumn({
	      	         name: 'entity'
	      	      })
	     	   ]
	     	});
        var searchResult = searchObj.run().getRange({
            start: 0,
            end: 10
        });
        log.debug('length',searchResult.length);
        
        return searchResult.length;

    }

    return {
        beforeLoad: beforeLoad
    };
    
});
