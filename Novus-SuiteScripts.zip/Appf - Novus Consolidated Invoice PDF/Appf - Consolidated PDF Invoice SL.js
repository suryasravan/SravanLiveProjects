/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Generates custom PDF layout depending on PDF template assigned to CI record.
 *
 * Author: roach
 * Date: Aug 03, 2020
 */
define( [ 'N/search', 'N/ui/serverWidget', 'N/runtime', 'N/render', 'N/file', 'N/xml', 'N/config', 'N/record', 'N/error', 'N/redirect' ],

	function ( search, serverWidget, runtime, render, file, xml, config, record, error, redirect ) {
		var VAL_PARAM_CI_ID = 'custparam_ci_id';
		var VAL_PARAM_CI_PDF_LAYOUT = 'custparam_ci_pdf_layout';
		var FLD_PDF_MEDIATYPE = 'custrecord_appf_pdf_layout_type';
		var FLD_PDF_SUMMARY = 'custrecord_appf_pdf_summary';
		var FLD_PDF_SUBSIDIARY = 'custrecord_appf_pdf_subsidiary';
		var FLD_PDF_IO_SEARCH = 'custrecord_appf_pdf_ss';
		var FLD_PDF_TITLE = 'custrecord_appf_pdf_title'; //loop up to 10
		var FLD_PDF_IO = 'custrecord_appf_pdf_iofield';//loop up to 10
		var FLD_PDF_CURRENCY_SYMBOL = 'custrecord_appf_pdf_currency_symbol';
		var VAL_LOOP = 13;
		var REC_PDF_LAYOUT = 'customrecord_appf_pdf_layout';
		var REC_CI = 'customrecord_appf_ci_record';
		var FLD_CI_RECORD = 'custcol_appf_ci_record';
		var FLD_CI_LINKED = 'custrecord_ci_record';
		var FLD_CI_DATE = 'custrecord_appf_ci_date';
		var FLD_CI_DUEDATE = 'custrecord_appf_ci_due_date';
		var FLD_CI_TERMS = 'custrecord_appf_ci_terms';
		var FLD_CI_PARENT_CLIENT = 'custrecord_appf_ci_parent';
		var FLD_CI_CLIENT = 'custrecord_appf_ci_client';
		var FLD_CI_ADDRESS = 'custrecord_appf_ci_billing_address';
		var FLD_CI_SUBTOTAL = 'custrecord_appf_ci_subtotal';
		var FLD_CI_DISCOUNT = 'custrecord_appf_ci_discount';
		var FLD_CI_AMOUNTDUE = 'custrecord_appf_ci_amount';
		var FLD_CI_TAX = 'custrecord_appf_ci_tax';
		var FLD_CI_SUBSIDIARY = 'custrecord_appf_ci_subsidiary';
		var FLD_PDF_XML_TEMPLATE = 'custrecord_appf_pdf_xml_template';
		var SPARAM_CANADA_LOGO = 'custscript_canada_logo_file_id';
		var FLD_INV_BILLMONTH = 'custcol_appf_bill_month';
		var FLD_INV_CLIENT_PO = 'custcol_appf_do_client_po';
		var FLD_INV_PRODUCT = 'custcol_appf_do_dds_product';
		var FLD_INV_ESTIMATECODE = 'custcol_appf_do_ddpubcode';
		var FLD_INV_PUBCODE = 'custcol_appf_do_ddpubcode';
		var FLD_INV_VENDOR = 'custcol_appf_po_vendor_name';
		var FLD_INV_MARKET = 'custcol_appf_do_market';
		var FLD_INV_ESTIMATEDOMEDIA = 'custcol_appf_do_estimatenum';
		var FLD_INV_PRODUCTCODE = 'custcol_appf_do_productcode';
		var FLD_INV_DDS_ESTIMATE = 'custcol_appf_do_dds_estimate';
		var FLD_INV_SPOT_ESTIMATE = 'custbody_appf_estimateno';
		var FLD_INV_DDS_CLIENT_CODE = 'custcol_appf_do_dds_clientcode';
		var FLD_INV_US_ESTIMATE = 'custbody_appf_do_campaignnum';
		var FLD_INV_CA_ESTIMATE = 'custcol_appf_do_estimatenum';
		//11-04-2022 added by shravan kumar 
		var FLD_INV_DD_S_PUBCODE_MARKET = 'custcol_appf_do_ddspubcodemarket';

		var FLD_CI_GST_TOTAL = 'custrecord_appf_ci_gst';
		var FLD_CI_PST_TOTAL = 'custrecord_appf_ci_pst';
		var FLD_SO_COL_TAXGST = 'custcol_appf_tax_amount_gst';
		var FLD_SO_COL_TAXPST = 'custcol_appf_tax_amount_pst';

		var VAL_TAX = [ 'GST', 'PST', 'HST', 'QST' ];
		var FLD_INV_DIVISION_NAME = 'custbody_appf_do_divisionname';

		var DDS_PUBCODE_TEMPLATES = [ '36' ];

		var FLD_CI_CONTRACT = 'custrecord_appf_ci_contract';
		var FLD_CONTRACT_INVOICE_RECIPIENT = 'custrecord_appf_contract_inv_recipients';
		var REC_CONTRACT = 'customrecord_appf_client_contract';

		var FLD_SO_COL_TAXGST = 'custcol_appf_tax_amount_gst';
		var FLD_SO_COL_TAXPST = 'custcol_appf_tax_amount_pst';
		var FLD_SO_COL_GST_PERCENT = 'custcol_appf_gst_percent';
		var FLD_SO_COL_PST_PERCENT = 'custcol_appf_pst_percent';

		var VAL_COL_TYPE = [];
		var VAL_COL_NAME = [];

		//added by shravan 09-05-2022
		var EMAIL_TEMPLATES_RESTRICT_HEARTSCIENCEMONTREAL = [ '36', '35' ];
		var EMAIL_TEMPLATE_ADDRESS_CLIENT = [ '1166783' ];

		//added by shravankumar 17-06-2022
		var FLD_REGENERATE_PDF = 'custrecord_appf_ci_pdf';

		//added by shravankumar 28-06-2022
		var FLD_CI_PDF_LINK = 'custrecord_appf_ci_pdf_link';

		//added by shravankumar 10-05-2023
		var SPARM_PARENT_CHILD_IDS = 'custscript_appf_parent_child_pdf';

		//added by shravankumar 06-12-2023
		var CI_PDF_NOT_DISPLAY_GST_OMIT_CA_ZERO = [ '155', '18', '37', '22', '26', '36', '40', '151', '35', '120' ];
		
		var TAXCODE_GST_CA_ZERO = 32;


		/**
		 * Definition of the Suitelet script trigger point.
		 *
		 * @param {Object} context
		 * @param {ServerRequest} context.request - Encapsulation of the incoming request
		 * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
		 * @Since 2015.2
		 */
		function onRequest ( context ) {
			//look up CI record fields
			var idCI = context.request.parameters.custparam_ci_id; /*|| 8506;*/
			var idPDFLayout = context.request.parameters.custparam_ci_pdf_layout; /* || 1;*/

			//added by shravankumar 17-06-2022
			var isRedirect = context.request.parameters.custparam_ci_redirect;
			var isUserCreate = context.request.parameters.custparam_redirect_sl;

			var ACCOUNT_ID = runtime.accountId;
			ACCOUNT_ID = ACCOUNT_ID.toLowerCase()
			ACCOUNT_ID = ACCOUNT_ID.replace( '_', '-' );
			var aCIFields = [];

			if ( idPDFLayout == null || idPDFLayout == '' ) {

				var errorObj = error.create( {
					code: 'Error Printing PDF: No PDF Template assigned to this CI Record.',
					message: 'Error Printing PDF: No PDF Template assigned to this CI Record.'
				} );

				throw errorObj.message;
				return false;
			}

			var oCIFields = search.lookupFields( {
				type: REC_CI,
				id: idCI,
				columns: [ FLD_CI_LINKED, FLD_CI_DATE, FLD_CI_DUEDATE, FLD_CI_TERMS, FLD_CI_PARENT_CLIENT, FLD_CI_CLIENT, FLD_CI_ADDRESS, FLD_CI_SUBTOTAL, FLD_CI_DISCOUNT, FLD_CI_AMOUNTDUE, FLD_CI_TAX, FLD_CI_CONTRACT, FLD_CI_SUBSIDIARY ]
			} );
			log.debug( 'oCIFields[FLD_CI_PARENT_CLIENT]', oCIFields[ FLD_CI_PARENT_CLIENT ] + ' ' + JSON.stringify( oCIFields[ FLD_CI_PARENT_CLIENT ] ) );


			//look up pdf template fields
			var aPDFTitleFields = [];
			var aPDFIOFields = [];
			var aPDFFields = [];

			aPDFFields.push( FLD_PDF_MEDIATYPE );
			aPDFFields.push( FLD_PDF_SUMMARY );
			aPDFFields.push( FLD_PDF_SUBSIDIARY );
			aPDFFields.push( FLD_PDF_IO_SEARCH );
			aPDFFields.push( FLD_PDF_XML_TEMPLATE );
			aPDFFields.push( FLD_PDF_CURRENCY_SYMBOL );


			for ( var i = 0; i < VAL_LOOP; i++ ) {
				aPDFTitleFields.push( FLD_PDF_TITLE + '' + ( i + 1 ) );
				aPDFIOFields.push( FLD_PDF_IO + '' + ( i + 1 ) );
				aPDFFields.push( FLD_PDF_TITLE + '' + ( i + 1 ) );
				aPDFFields.push( FLD_PDF_IO + '' + ( i + 1 ) );
			}
			var oPDFFields = search.lookupFields( {
				type: REC_PDF_LAYOUT,
				id: idPDFLayout,
				columns: aPDFFields
			} );

			var idSearch = oPDFFields[ FLD_PDF_IO_SEARCH ][ 0 ].value;
			log.debug( 'Search ID', idSearch );
			var tableColumns = [];
			for ( var i = 0; i < VAL_LOOP; i++ ) {
				//tableColumns.push(oPDFFields[FLD_PDF_TITLE+''+(i+1)]);
				//remove subtotal keyword
				var sLabel = oPDFFields[ FLD_PDF_TITLE + '' + ( i + 1 ) ];
				if ( sLabel.indexOf( '(Total)' ) > -1 ) {
					sLabel = sLabel.replace( "(Total)", "" );
				} else if ( sLabel.indexOf( '(total)' ) > -1 ) {
					sLabel = sLabel.replace( "(total)", "" );
				} else if ( sLabel.indexOf( '(Subtotal)' ) > -1 ) {
					sLabel = sLabel.replace( "(Subtotal)", "" );
				} else if ( sLabel.indexOf( '(subtotal)' ) > -1 ) {
					sLabel = sLabel.replace( "(subtotal)", "" );
				} else if ( sLabel.indexOf( '(SubTotal)' ) > -1 ) {
					sLabel = sLabel.replace( "(SubTotal)", "" );
				}
				tableColumns.push( sLabel );
			}

			if ( ( oPDFFields[ FLD_PDF_SUMMARY ] ) == true || ( oPDFFields[ FLD_PDF_SUMMARY ] ) == 'T' ) {
				var oJSONData = getDataSummary( idSearch, idCI, aPDFTitleFields, aPDFIOFields, aPDFFields, oPDFFields, oCIFields, idPDFLayout );
			} else {
				var oJSONData = getData( idSearch, idCI, aPDFTitleFields, aPDFIOFields, aPDFFields, oPDFFields, oCIFields, idPDFLayout );
			}

			//log.audit( 'oJSONData', oJSONData );
			//depending on the media type load the corresponding template
			var fileTemplate = '';
			var oFile = renderPDFPage( oJSONData, tableColumns, oPDFFields[ FLD_PDF_XML_TEMPLATE ][ 0 ].value, idCI, oPDFFields, oCIFields, idPDFLayout );
			/*oFile.name = 'CI_'+idCI+'.pdf';
		context.response.writeFile({
		    file: oFile,
		    isInline: true
		});*/
			log.debug( 'oFile', oFile );

			if ( oFile != null && oFile != '' ) {
				oFile.name = 'CI_' + idCI + '.pdf';
				if ( !isUserCreate ) {
					var isconsolidate = context.request.parameters.isconsolidate;
					if ( !isconsolidate ) {
						context.response.writeFile( {
							file: oFile,
							isInline: true
						} );
					}
					else {
						oFile.folder = 3419; // Appf Temporary Consolidated PDFs - Script USE DND
						oFile.isOnline = true;
						var jsonFileID = oFile.save();
						//   log.debug('jsonFileID',jsonFileID);
						context.response.write( {
							output: jsonFileID + ''
						} );
					}
				}
				//added by shravankumar 17-06-2022
				else {
					oFile.folder = 941; // Appficiency Attachments > Consolidated Invoice Folder
					oFile.isOnline = true;
					var jsonFileID = oFile.save();

					var ci_record = record.load( {
						type: REC_CI,
						id: Number( idCI ),
						isDynamic: true,
					} )
					ci_record.setValue( FLD_REGENERATE_PDF, Number( jsonFileID ) );

					//28-06-2022 added by shravan
					var fileObj = file.load( {
						id: Number( jsonFileID )
					} )
					var fileUrl = fileObj.url;
					if ( fileUrl ) {
						fileUrl = 'https://' + ACCOUNT_ID + '.app.netsuite.com' + fileUrl
						ci_record.setValue( FLD_CI_PDF_LINK, fileUrl );
					}
					try {
						idCI = ci_record.save( true, true );
						log.debug( 'idCI', idCI );
						if ( isRedirect ) {
							redirect.toRecord( {
								id: idCI,
								type: REC_CI,
							} )
						}
					}
					catch ( e ) {
						log.debug( 'failed', e );
					}
				}
			}


			log.debug( 'remaining usage', 'remaining usage = ' + runtime.getCurrentScript().getRemainingUsage() );

		}

		/**
		 * Loads search and return JSON format data
		 */
		function getData ( idSearch, idCI, aPDFTitleFields, aPDFIOFields, aPDFFields, oPDFFields, oCIFields, idPDFLayout ) {
			log.debug( 'getdata test', 'getdata test' );

			try {
				var aTaxCol = [];
				for ( var i = 0; i < VAL_TAX.length; i++ ) {
					aTaxCol.push( VAL_TAX[ i ].toLowerCase() );
				}

				//load search
				var oSavedSearch = search.load( {
					id: idSearch
				} );
				var filterObj = search.createFilter( {
					name: FLD_CI_RECORD,
					operator: search.Operator.ANYOF,
					values: idCI
				} );

				oSavedSearch.filters.push( filterObj );
				oSavedSearch.columns.push( search.createColumn( {
					name: 'amountremaining'
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_CLIENT_PO
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_PRODUCT
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_ESTIMATECODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_PUBCODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_VENDOR
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_MARKET
				} ) );
				/*oSavedSearch.columns.push(search.createColumn({
				    name: 'entityid',
				    join:'job'
				}));*/
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DDS_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_SPOT_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_TAXGST
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_TAXPST
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: 'otherrefnum'
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DIVISION_NAME
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DDS_CLIENT_CODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: 'taxcode'
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_GST_PERCENT
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_PST_PERCENT
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_US_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_CA_ESTIMATE
				} ) );

				//11-04-2022 added by shravan kumar
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DD_S_PUBCODE_MARKET
				} ) );
				var ddsPubCodeMarket = '';

				//04-10-2023 added by shravan kumar
				var gstIndex = null;
				var pstIndex = null;
				var searchColumns = oSavedSearch.columns;
				for ( var s = 0; s < searchColumns.length; s++ ) {
					var columnNames = searchColumns[ s ];
					if ( columnNames ) {
						if ( columnNames.label == "Tax Amount (GST)" && columnNames.name == "formulanumeric" )
							gstIndex = s
						if ( columnNames.label == "Tax Amount (PST)" && columnNames.name == "formulanumeric" )
							pstIndex = s;
					}
				}
				log.audit( 'gstIndex', gstIndex + '-' + pstIndex );

				//loop results, store json
				var pageData = oSavedSearch.runPaged();
				var aData = [];
				var oAllData = "[";
				var str = "";
				var aSum = [];
				var aSumFormatted = [];
				var j = 0;
				var project = '';
				var count = 0;
				var usEstimate = [];
				var caEstimate = [];

				var oGroupedTax = new Object();
				var fSumGSTAmount = 0;
				var fSumPSTAmount = 0;
				pageData.pageRanges.forEach( function ( pageRange ) {
					var page = pageData.fetch( { index: pageRange.index } );
					page.data.forEach( function ( result ) {
						var columns = result.columns;

						str += "{";
						for ( var i = 0; i < VAL_LOOP; i++ ) {
							var nCol = oPDFFields[ FLD_PDF_IO + '' + ( i + 1 ) ];
							var titleCol = oPDFFields[ FLD_PDF_TITLE + '' + ( i + 1 ) ];
							//log.audit( 'sValue=' + i, titleCol );
							//check if has '+'
							var bCombined = ( nCol.indexOf( '+' ) > -1 ) ? true : false;
							//log.audit( 'titleCol', titleCol + 'nCol=' + nCol + ' bCombined=' + bCombined );
							if ( !isEmpty( titleCol ) && !isEmpty( nCol ) && !bCombined ) {
								var objCol = columns[ nCol - 1 ];
								//log.debug('code',titleCol.indexOf('code'));
								//log.debug('columns', ' name='+objCol.name + ' type='+objCol.type + ' label='+objCol.label);

								var sValue = result.getText( columns[ nCol - 1 ] ) || result.getValue( columns[ nCol - 1 ] );
								log.audit( 'sValue=', sValue + 'titleCol=' + titleCol );

								if ( titleCol == 'Campaign' ) {
									//	log.debug( titleCol, sValue.indexOf( '-' ) );
									if ( sValue.indexOf( '\t' ) != -1 ) {
										//sValue = sValue.replace( /-/g, "" );
										sValue = sValue.replace( /\t/g, " " );
									}

								}

								//check if has Subtotal keyword
								var bIsSubotal = false;
								if ( titleCol.indexOf( '(Total)' ) > -1 ) {
									bIsSubotal = true;
								} else if ( titleCol.indexOf( '(total)' ) > -1 ) {
									bIsSubotal = true;
								} else if ( titleCol.indexOf( '(Subtotal)' ) > -1 ) {
									bIsSubotal = true;
								} else if ( titleCol.indexOf( '(subtotal)' ) > -1 ) {
									bIsSubotal = true;
								} else if ( titleCol.indexOf( '(SubTotal)' ) > -1 ) {
									bIsSubotal = true;
								}


								var numStr = sValue;
								var numNum = +numStr;
								if ( ( !isNaN( numNum ) && numNum > 0 && sValue.indexOf( '.' ) > -1 ) || ( columns[ nCol - 1 ].name == 'formulacurrency' || columns[ nCol - 1 ].name == 'custcol_appf_clientunitrate' ) && bIsSubotal ) {
									if ( i > 1 ) {

										//get sum
										//log.debug('columns','i'+i+'-'+columns[nCol-1].name + '-'+ sValue);
										if ( bIsSubotal ) {
											if ( j == 0 ) {
												aSum[ i ] = parseFloat( sValue );
												aSumFormatted[ i ] = parseFloat( sValue ).toFixed( 2 );
											} else {
												if ( isNaN( parseFloat( aSum[ i ] ) ) ) { // ADHOC-FIX-VM
													aSum[ i ] = parseFloat( sValue );
													aSumFormatted[ i ] = parseFloat( sValue ).toFixed( 2 );
												} else {
													aSum[ i ] += parseFloat( sValue );
													aSumFormatted[ i ] += parseFloat( sValue ).toFixed( 2 );
												}
											}
											//log.debug( 'c1', parseFloat( sValue ).toFixed( 2 ) );
											sValue = currencyFormat( sValue, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );

										} else {
											var aColType = JSON.stringify( columns[ nCol - 1 ] );
											var oCol = aColType.split( ',' );
											var oType = oCol[ 2 ].split( ':' );
											var sColType = oType[ 1 ];
											// VAL_COL_TYPE.push(oType[1]);
											if ( sColType.indexOf( 'currency' ) > -1 || sColType.indexOf( 'float' ) > -1 || sColType.indexOf( 'numeric' ) > -1 ) {
												aSum[ i ] = '';
												aSumFormatted[ i ] = '';

												sValue = currencyFormat( sValue, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
											} else {
												aSum[ i ] = '';
												aSumFormatted[ i ] = '';

												sValue = sValue;
											}
										}

									} else {
										aSum[ i ] = '';
										aSumFormatted[ i ] = '';
									}


									//log.debug( 'c1', parseFloat( sValue ).toFixed( 2 ) );

								} else if ( ( !isNaN( numNum ) && numNum > 0 && sValue.indexOf( '.' ) < 0 ) && ( columns[ nCol - 1 ].name != 'formulacurrency' && bIsSubotal ) /*&& (titleCol.indexOf('code') != -1)*/ ) {
									//log.debug(titleCol +':'+titleCol.indexOf('code') + ':'+(titleCol.indexOf('Code')));
									if ( i > 1 && titleCol.indexOf( 'Code' ) == -1 && titleCol.indexOf( '#' ) == -1 ) {
										//log.debug('columns','i'+i+'-'+columns[nCol-1].name + '-'+ sValue);
										//get sum
										if ( j == 0 ) {
											aSum[ i ] = parseInt( sValue );
											aSumFormatted[ i ] = parseInt( sValue );
										} else {
											if ( isNaN( parseInt( aSum[ i ] ) ) ) { // ADHOC-FIX-VM
												aSum[ i ] = parseInt( sValue );
												aSumFormatted[ i ] = parseInt( sValue );
											} else {
												aSum[ i ] += parseInt( sValue );
												aSumFormatted[ i ] += parseInt( sValue );
											}
										}
										sValue = sValue;
										//log.debug( 'c2', sValue );
									} else {
										var aColType = JSON.stringify( columns[ nCol - 1 ] );
										var oCol = aColType.split( ',' );
										var oType = oCol[ 2 ].split( ':' );
										var sColType = oType[ 1 ];
										// VAL_COL_TYPE.push(oType[1]);
										if ( sColType.indexOf( 'currency' ) > -1 || sColType.indexOf( 'float' ) > -1 || sColType.indexOf( 'numeric' ) > -1 ) {
											aSum[ i ] = '';
											aSumFormatted[ i ] = '';

											sValue = currencyFormat( sValue, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
										} else {
											aSum[ i ] = '';
											aSumFormatted[ i ] = '';
										}



									}
									titleCol = titleCol.toLowerCase();
									if ( titleCol.indexOf( 'gst' ) != -1 || titleCol.indexOf( 'pst' ) != -1 || titleCol.indexOf( 'hst' ) != -1 || titleCol.indexOf( 'qst' ) != -1 ) {
										sValue = currencyFormat( sValue, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
									} else {
										sValue = sValue;
									}
									//log.debug( 'c2', parseFloat( sValue ).toFixed( 2 ) );

								} else {
									titleCol = titleCol.toLowerCase();
									log.audit( 'titleCol', titleCol );
									if ( titleCol.indexOf( 'gst' ) != -1 || titleCol.indexOf( 'pst' ) != -1 || titleCol.indexOf( 'hst' ) != -1 || titleCol.indexOf( 'qst' ) != -1 ) {
										//sValue = currencyFormat(sValue, oPDFFields[FLD_PDF_CURRENCY_SYMBOL]);
										//hide by shravan kumar 13-09-2023
										/*
										log.audit( 'titleCol - in block', titleCol );
										log.audit( 'sValue', sValue );
										aSum[ i ] = 0.00;
										aSumFormatted[ i ] = 0.00;
										sValue = sValue;
										sValue = currencyFormat( 0.00, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
										*/
										//added by shravan kumar 13-09-2023
										if ( j == 0 ) {
											aSum[ i ] = parseFloat( sValue );
											aSumFormatted[ i ] = parseFloat( sValue ).toFixed( 2 );
										} else {
											if ( isNaN( parseFloat( aSum[ i ] ) ) ) { // ADHOC-FIX-VM
												aSum[ i ] = parseFloat( sValue );
												aSumFormatted[ i ] = parseFloat( sValue ).toFixed( 2 );
											} else {
												aSum[ i ] += parseFloat( sValue );
												aSumFormatted[ i ] += parseFloat( sValue ).toFixed( 2 );
											}
										}

										sValue = sValue;
										sValue = currencyFormat( sValue, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );

									} else {
										//sValue = sValue;
										if ( aSum[ i ] != '' ) { // ADHOC-FIX-VM
											aSum[ i ] = aSum[ i ];
											aSumFormatted[ i ] = aSumFormatted[ i ];
										} else {
											aSum[ i ] = '';
											aSumFormatted[ i ] = '';
										}
										sValue = sValue;
										log.audit( 'c3', sValue );
										if ( columns[ nCol - 1 ].name == FLD_INV_VENDOR ) {
											sValue = sValue.split( /\s(.+)/ )[ 1 ];
										}

										if ( sValue != null && sValue != '' ) {

											sValue = xml.escape( {
												xmlText: sValue
											} );

										} else {
											sValue = '';
										}

									}
									//log.debug( 'c3', sValue ); //log.debug('c3',parseFloat(sValue).toFixed(2));
									//log.audit( 'c3', sValue );
								}
								str += '"' + aPDFIOFields[ i ] + '":"' + sValue + '",';
							}

							//log.debug( aPDFIOFields[ i ], sValue );
						}



						str = str.slice( 0, -1 );
						str += "},";
						//log.audit( 'str', str );

						j++;
						billMonth = result.getValue( FLD_INV_BILLMONTH );
						log.debug( 'billMonth', billMonth );
						clientPO = result.getValue( 'otherrefnum' ) || '';/*result.getValue(FLD_INV_CLIENT_PO)|| ''*/;
						product = result.getValue( FLD_INV_DIVISION_NAME ) || '';  /*result.getValue(FLD_INV_PRODUCTCODE) || '';*//*result.getValue(FLD_INV_PRODUCT) || '';*/
						estimateCode = result.getValue( FLD_INV_ESTIMATEDOMEDIA ) || '';/*result.getValue(FLD_INV_ESTIMATECODE) || '';*/
						pubCode = result.getValue( FLD_INV_PUBCODE ) || '';
						vendor = result.getText( FLD_INV_VENDOR ) || '';
						vendor = vendor.split( /\s(.+)/ )[ 1 ];
						if ( vendor != null && vendor != '' ) {
							vendor = xml.escape( {
								xmlText: vendor
							} );
						}

						market = result.getValue( FLD_INV_MARKET ) || '';
						productCodeDDS = result.getValue( FLD_INV_PRODUCT );
						estimateSpot = result.getValue( FLD_INV_SPOT_ESTIMATE );
						clientCodeDDS = result.getValue( FLD_INV_DDS_CLIENT_CODE );
						var lineUSEstimate = result.getValue( FLD_INV_US_ESTIMATE ) || '';
						var lineCAEstimate = result.getValue( FLD_INV_CA_ESTIMATE ) || '';
						log.debug( 'lineCAEstimate', lineCAEstimate );
						if ( lineUSEstimate != null && lineUSEstimate != '' ) {
							//usEstimate += lineUSEstimate + '|';
							usEstimate.push( lineUSEstimate );
						}
						if ( lineCAEstimate != null && lineCAEstimate != '' ) {
							//caEstimate += lineCAEstimate+ '|';
							caEstimate.push( lineCAEstimate );
						}

						//get tax columns and group
						idTaxCode = result.getValue( 'taxcode' );
						sTaxCode = result.getText( 'taxcode' );
						gstTaxPercent = result.getValue( FLD_SO_COL_GST_PERCENT );
						pstTaxPercent = result.getValue( FLD_SO_COL_PST_PERCENT );

						//hide by shravan kumar 13-09-2023
						/*
						gstTaxAmount = parseFloat( result.getValue( FLD_SO_COL_TAXGST ) ).toFixed( 2 );
						pstTaxAmount = parseFloat( result.getValue( FLD_SO_COL_TAXPST ) ).toFixed( 2 );
						*/

						//04-10-2023 added by shravan kumar
						if ( gstIndex != null )
							gstTaxAmount = parseFloat( result.getValue( oSavedSearch.columns[ gstIndex ] ) ).toFixed( 2 );
						else
							gstTaxAmount = 0;
						if ( pstIndex != null )
							pstTaxAmount = parseFloat( result.getValue( oSavedSearch.columns[ pstIndex ] ) ).toFixed( 2 );
						else
							pstTaxAmount = 0


						log.debug( 'idTaxCode=', idTaxCode );
						if ( idTaxCode && idTaxCode != -7 ) {//idTaxCode != 32
							var oCols = new Object();
							oCols[ 'idTaxCode' ] = idTaxCode;
							oCols[ 'sTaxCode' ] = sTaxCode;
							oCols[ 'gstTaxPercent' ] = gstTaxPercent;
							oCols[ 'pstTaxPercent' ] = pstTaxPercent;
							oCols[ 'gstTaxAmount' ] = gstTaxAmount;
							oCols[ 'pstTaxAmount' ] = pstTaxAmount;

							//added by shravankumar 06-Dec-2023 to Skip GST CA zero* Tax in CI PDF
							if ( CI_PDF_NOT_DISPLAY_GST_OMIT_CA_ZERO.indexOf( idPDFLayout ) != -1 && idTaxCode == TAXCODE_GST_CA_ZERO ) {
								//Do not display a row for the matched tax code
							}
							else {
								var aDataDetails = oGroupedTax[ idTaxCode ] || new Array();
								aDataDetails.push( oCols );
								oGroupedTax[ idTaxCode ] = aDataDetails;
							}
						}


						//project = result.getText('job');
						//log.debug('count', count);
						if ( count == 0 ) {
							if ( ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'OOH' ) || ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'Spot' ) ) {
								for ( var c = 0; c < columns.length; c++ ) {
									//log.debug('columns[c].name', columns[c].name + ' label = ' + columns[c].label );
									if ( ( columns[ c ].name ).replace( /\s/g, '' ) == 'entityid' && ( columns[ c ].label ).replace( /\s/g, '' ) == 'ID' ) {
										project = result.getValue( columns[ c ] );
										//log.debug('project', result.getValue(columns[c]));
									}
								}
							}

						}

						//11-04-2022 added by shravan 
						if ( ddsPubCodeMarket == null || ddsPubCodeMarket == '' )
							ddsPubCodeMarket = result.getValue( FLD_INV_DD_S_PUBCODE_MARKET );

						estimateDDS = result.getValue( FLD_INV_DDS_ESTIMATE );
						count++;
					} );

				} );

				str = str.slice( 0, -1 );
				log.debug( 'aSumFormatted where?', aSumFormatted );
				// log.debug('aSum',aSum);
				for ( var i = 0; i < aSum.length; i++ ) {
					if ( !isEmpty( aSum[ i ] ) ) {
						var temp = aSumFormatted[ i ] + "";

						if ( temp.indexOf( '.' ) > -1 || aSum[ i ] == 0 /*|| (aSum.length - i <= 2)*/ ) {
							aSum[ i ] = currencyFormat( aSum[ i ], oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
							//log.debug('aSum[i]','format');
						} else {
							aSum[ i ] = aSum[ i ];

						}
					} else {
						aSum[ i ] = '';
						//log.debug('aSum[i]',' - ' + aSum[i]);
					}
				}

				oAllData += str;
				oAllData += "]";
				log.debug( 'aSum', aSum );
				log.debug( 'oAllData', oAllData );

				//get sum tax group

				log.debug( 'oGroupedTax', JSON.stringify( oGroupedTax ) );
				var oGroupedTaxData = new Object();
				var oGroupedTaxJSON = "[";
				var str = "";
				for ( var idKey in oGroupedTax ) {
					var fSumGST = 0;
					var fSumPST = 0;
					var sTaxCode = '';

					var aRows = oGroupedTax[ idKey ];
					for ( var j = 0; j < aRows.length; j++ ) {
						var oCol = aRows[ j ];
						var fGSTTaxAmount = oCol[ 'gstTaxAmount' ];
						var fPSTTaxAmount = oCol[ 'pstTaxAmount' ];
						sTaxCode = oCol[ 'sTaxCode' ];
						fSumGST += parseFloat( fGSTTaxAmount );
						fSumPST += parseFloat( fPSTTaxAmount );
					}

					//store
					if ( fSumGST > 0 && fSumPST > 0 ) { //split to 2
						var oCols = new Object();
						oCols[ 'sTaxCode' ] = 'GST 5%';
						oCols[ 'fTaxAmount' ] = currencyFormat( fSumGST, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );

						var aDataDetails = oGroupedTaxData[ 'GST 5%' ] || new Array();
						aDataDetails.push( oCols );
						oGroupedTaxData[ 'GST 5%' ] = aDataDetails;

						str += "{";
						str += '"' + 'sTaxCode' + '":"' + 'GST 5%' + '",';
						str += '"' + 'fTaxAmount' + '":"' + currencyFormat( fSumGST, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] ) + '"},';

						var oCols = new Object();
						oCols[ 'sTaxCode' ] = 'QST 9.975%';
						oCols[ 'fTaxAmount' ] = currencyFormat( fSumPST, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );

						var aDataDetails = oGroupedTaxData[ 'QST 9.975%' ] || new Array();
						aDataDetails.push( oCols );
						oGroupedTaxData[ 'QST 9.975%' ] = aDataDetails;

						str += "{";
						str += '"' + 'sTaxCode' + '":"' + 'QST 9.975%' + '",';
						str += '"' + 'fTaxAmount' + '":"' + currencyFormat( fSumPST, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] ) + '"},';


					} else { //display name and tax amount

						var oCols = new Object();
						oCols[ 'sTaxCode' ] = sTaxCode;
						oCols[ 'fTaxAmount' ] = currencyFormat( oCIFields[ FLD_CI_TAX ], oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );

						var aDataDetails = oGroupedTaxData[ sTaxCode ] || new Array();
						aDataDetails.push( oCols );
						oGroupedTaxData[ sTaxCode ] = aDataDetails;

						str += "{";
						str += '"' + 'sTaxCode' + '":"' + sTaxCode + '",';
						str += '"' + 'fTaxAmount' + '":"' + currencyFormat( oCIFields[ FLD_CI_TAX ], oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] ) + '"},';
					}
				}

				str = str.slice( 0, -1 );
				oGroupedTaxJSON += str;
				oGroupedTaxJSON += "]";

				log.debug( 'oGroupedTaxJSON', oGroupedTaxJSON );

				//usEstimate = usEstimate.slice(0, -1);
				//caEstimate = caEstimate.slice(0, -1);
				usEstimate = eliminateDuplicates( usEstimate );
				caEstimate = eliminateDuplicates( caEstimate );

				usEstimate = usEstimate.toString();
				caEstimate = caEstimate.toString();


				if ( clientPO != null && clientPO != '' ) {
					clientPO = xml.escape( {
						xmlText: clientPO
					} );
				}

				if ( product != null && product != '' ) {
					product = xml.escape( {
						xmlText: product
					} );
				}
				if ( estimateCode != null && estimateCode != '' ) {
					estimateCode = xml.escape( {
						xmlText: estimateCode
					} );
				}
				if ( pubCode != null && pubCode != '' ) {
					//11-04-2022 added by shravan 
					if ( DDS_PUBCODE_TEMPLATES.indexOf( idPDFLayout ) != -1 ) {
						if ( ddsPubCodeMarket != null && ddsPubCodeMarket != '' )
							pubCode = pubCode + ',' + ddsPubCodeMarket
						pubCode = xml.escape( {
							xmlText: pubCode
						} );
					}
					else {
						pubCode = xml.escape( {
							xmlText: pubCode
						} );
					}

				}
				if ( market != null && market != '' ) {
					market = xml.escape( {
						xmlText: market
					} );
				}
				if ( productCodeDDS != null && productCodeDDS != '' ) {
					productCodeDDS = xml.escape( {
						xmlText: productCodeDDS
					} );
				}
				if ( project != null && project != '' ) {
					project = xml.escape( {
						xmlText: project
					} );
				}
				if ( estimateDDS != null && estimateDDS != '' ) {
					estimateDDS = xml.escape( {
						xmlText: estimateDDS
					} );
				}
				if ( estimateSpot != null && estimateSpot != '' ) {
					estimateSpot = xml.escape( {
						xmlText: estimateSpot
					} );
				}
				if ( clientCodeDDS != null && clientCodeDDS != '' ) {
					clientCodeDDS = xml.escape( {
						xmlText: clientCodeDDS
					} );
				}
				return [ oAllData, aSum, billMonth, clientPO, product, estimateCode, pubCode, vendor, market, productCodeDDS, project, estimateDDS, estimateSpot, clientCodeDDS, oGroupedTaxData, oGroupedTaxJSON, usEstimate, caEstimate ];
			} catch ( e ) {
				//throw message
				log.error( 'Error mapping data', e.message );
			}

		}

		/**
		 * Loads search and return JSON format data summary format
		 */
		function getDataSummary ( idSearch, idCI, aPDFTitleFields, aPDFIOFields, aPDFFields, oPDFFields, oCIFields, idPDFLayout ) {

			try {
				//load search
				var oSavedSearch = search.load( {
					id: idSearch
				} );
				var filterObj = search.createFilter( {
					name: FLD_CI_RECORD,
					operator: search.Operator.ANYOF,
					values: idCI
				} );

				oSavedSearch.filters.push( filterObj );
				oSavedSearch.columns.push( search.createColumn( {
					name: 'amountremaining'
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_CLIENT_PO
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_PRODUCT
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_ESTIMATECODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_PUBCODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_VENDOR
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_MARKET
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_ESTIMATEDOMEDIA
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_PRODUCTCODE
				} ) );
				/*oSavedSearch.columns.push(search.createColumn({
				    name: 'entityid',
				    join:'job'
				}));*/
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DDS_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_SPOT_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_TAXGST
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_SO_COL_TAXPST
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: 'otherrefnum'
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DIVISION_NAME
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DDS_CLIENT_CODE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_US_ESTIMATE
				} ) );
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_CA_ESTIMATE
				} ) );

				//11-04-2022 added by shravan kumar
				oSavedSearch.columns.push( search.createColumn( {
					name: FLD_INV_DD_S_PUBCODE_MARKET
				} ) );
				var ddsPubCodeMarket = '';

				//loop results, store json
				var pageData = oSavedSearch.runPaged();
				var aData = [];
				var oAllData = "[";
				var str = "";
				var aSum = [];
				var j = 0;
				var fAmountDueTotal = 0;
				var billMonth;
				var clientPO;
				var product;
				var estimateCode;
				var pubCode;
				var vendor;
				var market;
				var project;
				var count = 0;
				var usEstimate = [];
				var caEstimate = [];

				var oHashedData = new Object();

				pageData.pageRanges.forEach( function ( pageRange ) {
					var page = pageData.fetch( { index: pageRange.index } );
					page.data.forEach( function ( result ) {
						VAL_COL_TYPE = [];
						VAL_COL_NAME = [];
						var columns = result.columns;
						str += "{";
						var keys = new Array();
						var oCols = new Object();
						for ( var i = 0; i < VAL_LOOP; i++ ) {
							var aColTypeCols = [];
							var nCol = oPDFFields[ FLD_PDF_IO + '' + ( i + 1 ) ];
							var titleCol = oPDFFields[ FLD_PDF_TITLE + '' + ( i + 1 ) ];
							//check if has '+'
							var bCombined = ( nCol.indexOf( '+' ) > -1 ) ? true : false;

							//var aColType = columns[nCol-1];
							//var oCol = aColType.split(',');
							//log.debug('oCol', oCol);
							//var oType = oCol[2].split(':');

							// log.debug('titleCol=',titleCol + ' nCol= '+nCol + ' bCombined='+bCombined + 'col details='+JSON.stringify(columns[nCol-1]));
							if ( !isEmpty( titleCol ) && !isEmpty( nCol ) && !bCombined ) {
								var sValue = result.getText( columns[ nCol - 1 ] ) || result.getValue( columns[ nCol - 1 ] );
								var placementName = columns[ nCol - 1 ].name.indexOf( 'custcol_appf_placement' );


								//log.audit( 'placementName of ' + sValue, placementName );

								//var sValue = result.getText(columns[nCol-1],null,'group')||result.getValue(columns[nCol-1],null,'group');
								str += '"' + aPDFIOFields[ i ] + '":"' + sValue + '",';


								var numStr = sValue;
								var numNum = +numStr;
								if ( isNaN( numNum ) ) {
									keys.push( sValue );
								} else {

									var aColType = JSON.stringify( columns[ nCol - 1 ] );
									//log.debug('summary column = ',aColType + ' type text = '+aColType.indexOf('"text"') + ' name='+columns[nCol-1].name + ' type='+aColType.type + ' field name='+aPDFIOFields[i] + ' titleCol='+titleCol);


									var oCol = aColType.split( ',' );
									var oType = oCol[ 2 ].split( ':' );

									VAL_COL_TYPE.push( oType[ 1 ] );
									VAL_COL_NAME.push( aPDFIOFields[ i ] );
									//aColType = aColType.split('')
									/*if(aColType.indexOf('"text"') > -1){
										keys.push(sValue);
									}*/
								}


								if ( sValue ) {
									sValue = sValue.trim();
								}
								if ( i == 1 ) {
									log.debug( 'sValue of 2nd', sValue );
								}
								oCols[ aPDFIOFields[ i ] ] = sValue;
							}
						}
						var fAmountDue = result.getValue( 'amountremaining' ) || 0;
						fAmountDueTotal += parseFloat( fAmountDue );
						log.debug( 'keys=' + keys );
						var aDataDetails = oHashedData[ keys ] || new Array();
						aDataDetails.push( oCols );
						oHashedData[ keys ] = aDataDetails;


						str = str.slice( 0, -1 );
						str += "},";
						j++;
						billMonth = result.getValue( FLD_INV_BILLMONTH );
						// clientPO = result.getValue(FLD_INV_CLIENT_PO)|| '';
						// product = result.getValue(FLD_INV_PRODUCTCODE) || '';/*result.getValue(FLD_INV_PRODUCT) || '';*/
						clientPO = result.getValue( 'otherrefnum' ) || '';/*result.getValue(FLD_INV_CLIENT_PO)|| ''*/;
						product = result.getValue( FLD_INV_DIVISION_NAME ) || '';  /*result.getValue(FLD_INV_PRODUCTCODE) || '';*//*result.getValue(FLD_INV_PRODUCT) || '';*/

						estimateCode = result.getValue( FLD_INV_ESTIMATEDOMEDIA ) || '';/*result.getValue(FLD_INV_ESTIMATECODE) || '';*/
						pubCode = result.getValue( FLD_INV_PUBCODE ) || '';
						vendor = result.getText( FLD_INV_VENDOR ) || '';
						vendor = vendor.split( /\s(.+)/ )[ 1 ];
						if ( vendor != null && vendor != '' ) {
							vendor = xml.escape( {
								xmlText: vendor
							} );
						}
						market = result.getValue( FLD_INV_MARKET ) || '';
						productCodeDDS = result.getValue( FLD_INV_PRODUCT );
						estimateDDS = result.getValue( FLD_INV_DDS_ESTIMATE );
						estimateSpot = result.getValue( FLD_INV_SPOT_ESTIMATE );
						clientCodeDDS = result.getValue( FLD_INV_DDS_CLIENT_CODE );
						var lineUSEstimate = result.getValue( FLD_INV_US_ESTIMATE ) || '';
						var lineCAEstimate = result.getValue( FLD_INV_CA_ESTIMATE ) || '';
						//log.debug('lineUSEstimate', lineUSEstimate);
						log.debug( 'lineCAEstimate', lineCAEstimate );
						if ( lineUSEstimate != null && lineUSEstimate != '' ) {
							//usEstimate += lineUSEstimate + '|';
							usEstimate.push( lineUSEstimate );
						}
						if ( lineCAEstimate != null && lineCAEstimate != '' ) {
							//caEstimate += lineCAEstimate+ '|';
							caEstimate.push( lineCAEstimate );
						}

						//log.debug('count', count);
						if ( count == 0 ) {
							if ( ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'OOH' ) || ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'Spot' ) ) {
								for ( var c = 0; c < columns.length; c++ ) {
									//log.debug('columns[c].name', columns[c].name + ' label = ' + columns[c].label );
									if ( ( columns[ c ].name ).replace( /\s/g, '' ) == 'entityid' && ( columns[ c ].label ).replace( /\s/g, '' ) == 'ID' ) {
										project = result.getValue( columns[ c ] );
										//log.debug('project', result.getValue(columns[c]));
									}
								}
							}

						}
						//project = result.getText('job');
						log.debug( 'clientPO', clientPO );
						log.debug( 'vendor', vendor );
						log.debug( 'pubCode', pubCode );

						//11-04-2022 added by shravan 
						if ( ddsPubCodeMarket == null || ddsPubCodeMarket == '' )
							ddsPubCodeMarket = result.getValue( FLD_INV_DD_S_PUBCODE_MARKET );

						count++;
					} );
				} );


				str = str.slice( 0, -1 );

				oAllData += str;
				oAllData += "]";
				log.debug( 'oAllData', oAllData );
				log.debug( 'oHashedData', oHashedData );
				log.debug( 'VAL_COL_TYPE', VAL_COL_TYPE );
				log.debug( 'VAL_COL_NAME', VAL_COL_NAME );

				var aGroupedData = groupBy( oHashedData, oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ], oPDFFields, aPDFIOFields );

				//usEstimate = usEstimate.slice(0, -1);
				//caEstimate = caEstimate.slice(0, -1);

				usEstimate = eliminateDuplicates( usEstimate );
				caEstimate = eliminateDuplicates( caEstimate );

				usEstimate = usEstimate.toString();
				caEstimate = caEstimate.toString();

				//log.debug('usEstimate', usEstimate);

				if ( clientPO != null && clientPO != '' ) {
					clientPO = xml.escape( {
						xmlText: clientPO
					} );
				}

				if ( product != null && product != '' ) {
					product = xml.escape( {
						xmlText: product
					} );
				}
				if ( estimateCode != null && estimateCode != '' ) {
					estimateCode = xml.escape( {
						xmlText: estimateCode
					} );
				}
				//added by shravan 4/13/2022
				if ( pubCode != null && pubCode != '' ) {
					if ( DDS_PUBCODE_TEMPLATES.indexOf( idPDFLayout ) != -1 ) {
						if ( ddsPubCodeMarket != null && ddsPubCodeMarket != '' )
							pubCode = pubCode + ',' + ddsPubCodeMarket;
						pubCode = xml.escape( {
							xmlText: pubCode
						} );
					}
					else {
						pubCode = xml.escape( {
							xmlText: pubCode
						} );
					}
				}
				if ( market != null && market != '' ) {
					market = xml.escape( {
						xmlText: market
					} );
				}
				if ( productCodeDDS != null && productCodeDDS != '' ) {
					productCodeDDS = xml.escape( {
						xmlText: productCodeDDS
					} );
				}
				if ( project != null && project != '' ) {
					project = xml.escape( {
						xmlText: project
					} );
				}
				if ( estimateDDS != null && estimateDDS != '' ) {
					estimateDDS = xml.escape( {
						xmlText: estimateDDS
					} );
				}
				if ( estimateSpot != null && estimateSpot != '' ) {
					estimateSpot = xml.escape( {
						xmlText: estimateSpot
					} );
				}
				if ( clientCodeDDS != null && clientCodeDDS != '' ) {
					clientCodeDDS = xml.escape( {
						xmlText: clientCodeDDS
					} );
				}



				return [ aGroupedData, billMonth, fAmountDueTotal, clientPO, product, estimateCode, pubCode, vendor, market, productCodeDDS, project, estimateDDS, estimateSpot, clientCodeDDS, usEstimate, caEstimate ];
				//return [oAllData,billMonth];
			} catch ( e ) {
				//throw message
				log.error( 'Error mapping data', e.message );
			}

		}

		/**
		 * Render PDF page and pass custom data source
		 */
		function renderPDFPage ( oJSONData, tableColumns, fileTemplate, idCI, oPDFFields, oCIFields, idPDFLayout ) {
			try {
				var configRecObj = config.load( {
					type: config.Type.COMPANY_INFORMATION
				} );
				var idLogo = configRecObj.getValue( {
					fieldId: 'pagelogo'
				} );
				var objFile = file.load( {
					id: idLogo
				} );
				var sLogo = objFile.url;
				var sLogoUrl = xml.escape( {
					xmlText: sLogo
				} );

				var idCanadaLogo = runtime.getCurrentScript().getParameter( { name: SPARAM_CANADA_LOGO } );
				var objCanadaLogoFile = file.load( {
					id: idCanadaLogo
				} );
				var sCanadaLogo = objCanadaLogoFile.url;
				var sCanadaLogoUrl = xml.escape( {
					xmlText: sCanadaLogo
				} );


				/*var oCIFields = search.lookupFields({
				    type: REC_CI,
				    id: idCI,
				    columns: [FLD_CI_LINKED,FLD_CI_DATE,FLD_CI_DUEDATE,FLD_CI_TERMS,FLD_CI_PARENT_CLIENT,FLD_CI_CLIENT,FLD_CI_ADDRESS,FLD_CI_SUBTOTAL,FLD_CI_DISCOUNT,FLD_CI_AMOUNTDUE,FLD_CI_TAX,FLD_CI_CONTRACT]
				});
				log.debug('oCIFields[FLD_CI_PARENT_CLIENT]', oCIFields[FLD_CI_PARENT_CLIENT] + ' ' + JSON.stringify(oCIFields[FLD_CI_PARENT_CLIENT]));
				*/

				//get contract
				var contactAddress = '';

				if ( !isEmpty( oCIFields[ FLD_CI_CONTRACT ] ) ) {

					var idContract = oCIFields[ FLD_CI_CONTRACT ][ 0 ].value;

					//load contract
					var recContract = record.load( {
						type: REC_CONTRACT,
						id: idContract,
						isDynamic: true,
					} );

					var aRecipient = recContract.getValue( {
						fieldId: FLD_CONTRACT_INVOICE_RECIPIENT
					} );

					for ( var i = 0; i < aRecipient.length; i++ ) {

						//get address of contact


						var contact = record.load( {
							type: 'contact',
							id: aRecipient[ i ],
							isDynamic: true,
						} );

						clientRole = contact.getValue( 'custentity_appf_client_role' );
						log.debug( 'clientRole', clientRole );
						log.debug( ' role:', clientRole.indexOf( '3' ) );
						if ( clientRole && clientRole.indexOf( '3' ) != -1 ) {
							//contactAddress = contact.getValue('defaultaddress');
							//load subrecord

							var nAddressLine = contact.getLineCount( { sublistId: 'addressbook' } );
							log.debug( 'contact nAddressLine', nAddressLine );

							for ( var z = 0; z < nAddressLine; z++ ) {
								contact.selectLine( { sublistId: 'addressbook', line: z } );
								var bDefaultBill = contact.getCurrentSublistValue( {
									sublistId: 'addressbook',
									fieldId: 'defaultbilling'
								} );
								if ( bDefaultBill == true || bDefaultBill == 'T' ) {
									var addressSubRecord = contact.getCurrentSublistSubrecord( {
										sublistId: 'addressbook',
										fieldId: 'addressbookaddress'
									} );

									log.debug( 'addr1', addressSubRecord.getValue( 'addr1' ) );
									log.debug( 'addr2', addressSubRecord.getValue( 'addr2' ) );
									log.debug( 'country', addressSubRecord.getValue( 'country' ) );
									log.debug( 'parent 1', oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ] );
									log.debug( 'parent 1', oCIFields[ FLD_CI_PARENT_CLIENT ] + ' = ' + isEmpty( oCIFields[ FLD_CI_PARENT_CLIENT ] ) );
									var idParentCheck = '';
									var idChildCustomerCheck = '';
									//log.debug('cleint',oCIFields[FLD_CI_PARENT_CLIENT][0]);
									if ( !isEmpty( oCIFields[ FLD_CI_PARENT_CLIENT ] ) ) {
										//contactAddress += oCIFields[FLD_CI_PARENT_CLIENT][0].text + '<br/>';
										var oParent = search.lookupFields( {
											type: 'customer',
											id: oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ].value,
											columns: [ 'companyname' ]
										} );
										idParentCheck = oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ].value;

										//added by shravan  09-05-2022
										var isParentRestricted = false;
										if ( ( EMAIL_TEMPLATES_RESTRICT_HEARTSCIENCEMONTREAL.indexOf( idPDFLayout ) != -1 ) && ( idParentCheck == 1166783 ) )// && ( EMAIL_TEMPLATE_ADDRESS_CLIENT.indexOf( oCIFields[ FLD_CI_PARENT_CLIENT ] ) == -1 ) )
											isParentRestricted = true;
										if ( !isParentRestricted )
											contactAddress += oParent[ 'companyname' ] + '\n';

									}
									//contactAddress += oCIFields[FLD_CI_CLIENT][0].text + '\n';
									/*if(!isEmpty(oCIFields[FLD_CI_PARENT_CLIENT][0].text)){

										 contactAddress += oCIFields[FLD_CI_PARENT_CLIENT][0].text + '\n';
									}*/


									if ( !isEmpty( oCIFields[ FLD_CI_CLIENT ] ) ) {

										var oChild = search.lookupFields( {
											type: 'customer',
											id: oCIFields[ FLD_CI_CLIENT ][ 0 ].value,
											columns: [ 'companyname' ]
										} );
										idChildCustomerCheck = oCIFields[ FLD_CI_CLIENT ][ 0 ].value;

									}




									//log.debug('contactAddress=',contactAddress);
									//var aClientName = (oCIFields[FLD_CI_CLIENT][0].text).split(':');
									//contactAddress += aClientName[aClientName.length-1] + '\n';
									//log.debug('client name=',aClientName[aClientName.length-1]);

									// added by shravankumar 10-05-2023
									var parentChildIds = runtime.getCurrentScript().getParameter( { name: SPARM_PARENT_CHILD_IDS } );
									if ( parentChildIds ) {
										parentChildIds = parentChildIds.split( ',' );
									}
									//if ( idParentCheck != 542884 && idParentCheck != 542995 && idChildCustomerCheck != 542884 && idChildCustomerCheck != 542995 ) {

									if ( parentChildIds.indexOf( idParentCheck ) == -1 && parentChildIds.indexOf( idChildCustomerCheck ) == -1 ) {
										//added by shravan 09-05-2022
										var isParentRestricted = false;
										if ( ( EMAIL_TEMPLATES_RESTRICT_HEARTSCIENCEMONTREAL.indexOf( idPDFLayout ) != -1 ) && ( idParentCheck == 1166783 ) )// && ( EMAIL_TEMPLATE_ADDRESS_CLIENT.indexOf( oCIFields[ FLD_CI_PARENT_CLIENT ] ) == -1 ) )
											isParentRestricted = true;
										if ( !isParentRestricted )
											contactAddress += oChild[ 'companyname' ] + '\n';
									}
									if ( !isEmpty( addressSubRecord.getValue( 'addr1' ) ) ) {
										contactAddress += addressSubRecord.getValue( 'addr1' ) + '\n';
									}
									if ( !isEmpty( addressSubRecord.getValue( 'addr2' ) ) ) {
										contactAddress += addressSubRecord.getValue( 'addr2' ) + '\n';
									}
									if ( !isEmpty( addressSubRecord.getValue( 'addr3' ) ) ) {
										contactAddress += addressSubRecord.getValue( 'addr3' ) + '\n';
									}
									if ( !isEmpty( addressSubRecord.getValue( 'city' ) ) ) {
										contactAddress += addressSubRecord.getValue( 'city' ) + ' ' + addressSubRecord.getValue( 'state' ) + '\n';
									}
									if ( !isEmpty( addressSubRecord.getValue( 'country' ) ) ) {
										contactAddress += addressSubRecord.getText( 'country' ) + ' ' + addressSubRecord.getValue( 'zip' ) + '\n';

									}
									break;
								}


							}


							/*var addressSubrecord = customer.getCurrentSublistSubrecord({
								    sublistId: 'addressbook',
								    fieldId: 'addressbookaddress'
							});
	
							addressSubrecord.setValue('country', country);
							addressSubrecord.setValue('attention', attention);
							addressSubrecord.setValue('addressee', addressee);
							addressSubrecord.setValue('addrphone', phone);
							addressSubrecord.setValue('addr1', addr1);
							addressSubrecord.setValue('addr2', addr2);
							addressSubrecord.setValue('city', city);
							addressSubrecord.setValue('state', state);
							addressSubrecord.setValue('zip', zip);*/




							break;
						}

						//log.debug('parentClientName=,'+parentClientName + ' childClientName='+childClientName[1]);
						//address = address.replace(parentClientName, parentClientName + '-' + childClientName[1]);

					}


				}



				//get address
				var sAddress;
				if ( contactAddress == null || contactAddress == '' ) {
					sAddress = getChildClientAddress( oCIFields[ FLD_CI_CLIENT ][ 0 ].value, oCIFields, idPDFLayout );
					//var sAddress = (!isEmpty(oCIFields[FLD_CI_PARENT_CLIENT])) ? getParentClientAddress(oCIFields[FLD_CI_PARENT_CLIENT][0].value,oCIFields) : oCIFields[FLD_CI_ADDRESS];

				} else {
					sAddress = contactAddress;
				}
				log.debug( 'sAddress', sAddress );
				//check if has <br>
				log.debug( 'sAddress br', sAddress.indexOf( '<br>' ) );
				if ( sAddress.indexOf( '<br>' ) > -1 ) {
					//sAddress = sAddress.replace('<br>', '\n');
					sAddress = sAddress.replace( /<br>/g, '\n' )
				}
				sAddress = xml.escape( {
					xmlText: sAddress
				} );
				sAddress = sAddress.replace( /(?:\r\n|\r|\n)/g, '<br />' );
				//sAddress = sAddress.replace("<br />", "\n");;
				log.debug( 'sAddress after', sAddress );
				var advertiser = ( !isEmpty( oCIFields[ FLD_CI_PARENT_CLIENT ] ) ) ? oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ].text + '-' + oCIFields[ FLD_CI_CLIENT ][ 0 ].text : oCIFields[ FLD_CI_CLIENT ][ 0 ].text;
				var arrAdviser = advertiser.split( ':' );
				if ( arrAdviser.length > 0 ) {
					advertiser = arrAdviser[ arrAdviser.length - 1 ];
				}

				if ( advertiser != null && advertiser != '' ) {
					advertiser = xml.escape( {
						xmlText: advertiser
					} );

				}


				log.debug( 'oPDFFields[FLD_PDF_SUMMARY]', oPDFFields[ FLD_PDF_SUMMARY ] );
				log.debug( 'oPDFFields[FLD_PDF_MEDIATYPE]', oPDFFields[ FLD_PDF_MEDIATYPE ] );
				log.debug( 'oJSONData', oJSONData );
				log.debug( 'product', product + ' clientPO=' + oJSONData[ 3 ] );
				log.debug( 'estimateNo', estimateNo );
				log.debug( 'oJSONData', JSON.stringify( oJSONData ), +'-' + oJSONData );
				if ( ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'OOH' ) ) {
					var product = oJSONData[ 4 ];
					var project = oJSONData[ 10 ] || '';
					if ( project != null && project != '' ) {
						project = xml.escape( {
							xmlText: project
						} );
					}
					//var estimateNo = oJSONData[5] + ' ' + project;
					var idSubsidiary = oCIFields[ FLD_CI_SUBSIDIARY ][ 0 ].value;
					log.debug( 'idSubsidiary', idSubsidiary );
					if ( idSubsidiary == 7 ) { //canada
						if ( ( oPDFFields[ FLD_PDF_SUMMARY ] ) == true || ( oPDFFields[ FLD_PDF_SUMMARY ] ) == 'T' ) {
							var estimateNo = oJSONData[ 15 ];
							log.debug( 'oJSONData[15]', oJSONData[ 15 ] );
						} else {
							var estimateNo = oJSONData[ 17 ];
							log.debug( 'oJSONData[15]', oJSONData[ 17 ] );
						}
					} else { //US
						if ( ( oPDFFields[ FLD_PDF_SUMMARY ] ) == true || ( oPDFFields[ FLD_PDF_SUMMARY ] ) == 'T' ) {
							var estimateNo = oJSONData[ 14 ];
						} else {
							var estimateNo = oJSONData[ 16 ];
						}
					}




				} else if ( ( oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text == 'Spot' ) ) {
					var product = oJSONData[ 4 ];
					var project = oJSONData[ 10 ] || '';
					if ( project != null && project != '' ) {
						project = xml.escape( {
							xmlText: project
						} );
					}
					var estimateNo = oJSONData[ 12 ] + ' ' + project;
				} else {
					var product = 'Product Code (DoMedia)';
					var estimateNo = '(DoMedia) Project';
				}
				/*if(oPDFFields[FLD_PDF_MEDIATYPE][0].text == 'Spot'){
					  var estimateNo = estimateNo;
				}*/
				var billMonth = oJSONData[ 2 ];

				//log.debug('estimateNo',estimateNo);
				//render pdf page
				var renderer = render.create();
				var template = file.load( fileTemplate ).getContents();
				renderer.templateContent = template;
				log.debug( 'oPDFFields[FLD_PDF_CURRENCY_SYMBOL]', oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ] );
				log.debug( 'Grouped Tax', JSON.stringify( oJSONData[ 15 ] ) + 'media type=' + oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text );
				log.debug( 'ci linked =', oCIFields[ FLD_CI_LINKED ][ 0 ] );
				log.debug( 'FLD_CI_TERMS =', oCIFields[ FLD_CI_TERMS ][ 0 ] );



				var sSymbol = oPDFFields[ FLD_PDF_CURRENCY_SYMBOL ];
				/* if(parseFloat(oCIFields[FLD_CI_AMOUNTDUE]) < 0){  //Jan 07 2021
				    var fAmountDue = parseFloat(oCIFields[FLD_CI_AMOUNTDUE]) - parseFloat(oCIFields[FLD_CI_TAX]) + parseFloat(oCIFields[FLD_CI_DISCOUNT]);
				 }else{
				   var fAmountDue = parseFloat(oCIFields[FLD_CI_AMOUNTDUE]) + parseFloat(oCIFields[FLD_CI_TAX]) - parseFloat(oCIFields[FLD_CI_DISCOUNT]);
				 }*/
				var fAmountDue = parseFloat( oCIFields[ FLD_CI_AMOUNTDUE ] ) + parseFloat( oCIFields[ FLD_CI_TAX ] ) + parseFloat( oCIFields[ FLD_CI_DISCOUNT ] );


				//log.debug( 'fAmountDue', fAmountDue );

				//subsidiary address
				var recSub = record.load( {
					type: 'subsidiary',
					id: 7,
					isDynamic: true,
				} );
				var subrecord = recSub.getSubrecord( {
					fieldId: 'mainaddress'
				} );

				var subAddr1 = subrecord.getValue( {
					fieldId: 'addr1'
				} ) || '';

				var subAddr2 = subrecord.getValue( {
					fieldId: 'addr2'
				} ) || '';

				var subCity = subrecord.getValue( {
					fieldId: 'city'
				} ) || '';

				var subState = subrecord.getText( {
					fieldId: 'state'
				} ) || '';

				var subZip = subrecord.getValue( {
					fieldId: 'zip'
				} ) || '';

				if ( ( oPDFFields[ FLD_PDF_SUMMARY ] ) == true || ( oPDFFields[ FLD_PDF_SUMMARY ] ) == 'T' ) {
					var jsonObj = {
						oData: JSON.parse( oJSONData[ 0 ] ),
						logoUrl: sLogoUrl,
						canadaLogoUrl: sCanadaLogoUrl,
						ciNumber: oCIFields[ FLD_CI_LINKED ][ 0 ].text,
						trandate: oCIFields[ FLD_CI_DATE ],
						duedate: oCIFields[ FLD_CI_DUEDATE ],
						terms: oCIFields[ FLD_CI_TERMS ][ 0 ].text,
						billaddress: sAddress,
						advertiser: advertiser,
						mediatype: oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text,
						product: product,
						estimateNo: estimateNo,
						billMonth: oJSONData[ 1 ],
						subtotal: currencyFormat( oCIFields[ FLD_CI_AMOUNTDUE ], sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_SUBTOTAL],*/
						discount: currencyFormat( oCIFields[ FLD_CI_DISCOUNT ], sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_DISCOUNT],*/
						amountdue: currencyFormat( fAmountDue, sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_AMOUNTDUE],*/
						tax: currencyFormat( oCIFields[ FLD_CI_TAX ], sSymbol ), /*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_TAX],*/
						clientPO: oJSONData[ 3 ],

						ddsproduct: oJSONData[ 9 ],
						estimateCode: oJSONData[ 11 ],
						pubCode: oJSONData[ 6 ],
						vendor: oJSONData[ 7 ],
						market: oJSONData[ 8 ],
						clientCodeDDS: oJSONData[ 13 ],
						subAddr1: subAddr1,
						subAddr2: subAddr2,
						subCity: subCity,
						subState: subState,
						subZip: subZip
					}
				} else {
					var jsonObj = {
						oData: JSON.parse( oJSONData[ 0 ] ),
						logoUrl: sLogoUrl,
						canadaLogoUrl: sCanadaLogoUrl,
						ciNumber: oCIFields[ FLD_CI_LINKED ][ 0 ].text,
						trandate: oCIFields[ FLD_CI_DATE ],
						duedate: oCIFields[ FLD_CI_DUEDATE ],
						terms: oCIFields[ FLD_CI_TERMS ][ 0 ].text,
						billaddress: sAddress,
						oSum: oJSONData[ 1 ],
						advertiser: advertiser,
						mediatype: oPDFFields[ FLD_PDF_MEDIATYPE ][ 0 ].text,
						product: product,
						estimateNo: estimateNo,
						billMonth: billMonth,
						clientPO: oJSONData[ 3 ],
						ddsproduct: oJSONData[ 9 ],
						estimateCode: oJSONData[ 11 ],
						pubCode: oJSONData[ 6 ],
						vendor: oJSONData[ 7 ],
						market: oJSONData[ 8 ],
						subtotal: currencyFormat( oCIFields[ FLD_CI_AMOUNTDUE ], sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_SUBTOTAL],*/
						discount: currencyFormat( oCIFields[ FLD_CI_DISCOUNT ], sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_DISCOUNT],*/
						amountdue: currencyFormat( fAmountDue, sSymbol ),/*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_AMOUNTDUE],*/
						tax: currencyFormat( oCIFields[ FLD_CI_TAX ], sSymbol ), /*oPDFFields[FLD_PDF_CURRENCY_SYMBOL]+''+oCIFields[FLD_CI_TAX],*/
						clientCodeDDS: oJSONData[ 13 ],
						oGroupedTax: JSON.parse( oJSONData[ 15 ] ),
						subAddr1: subAddr1,
						subAddr2: subAddr2,
						subCity: subCity,
						subState: subState,
						subZip: subZip

					}
				}

				log.debug( 'jsonObj', JSON.stringify( jsonObj ) );

				renderer.addCustomDataSource( {
					format: render.DataSource.OBJECT,
					alias: "JSON",
					data: jsonObj
				} );
				var jsonObjColumns = {
					oData: tableColumns
				}

				renderer.addCustomDataSource( {
					format: render.DataSource.OBJECT,
					alias: "JSON_TITLEHEADER",
					data: jsonObjColumns
				} );

				/* renderer.addCustomDataSource({
					format: render.DataSource.OBJECT,
					alias: "JSON_GROUPEDTAX",
					data: jsonObjColumns
				 });*/

				return renderer.renderAsPdf();
			} catch ( e ) {
				//throw message
				log.error( 'Error renderring data', e.message );
			}

		}

		/**
		 * Group results for summary
		 */
		function groupBy ( oHashedData, currencySymbol, oPDFFields, aPDFIOFields ) {
			var oGroupedData = "[";
			var str = "";
			//for loop
			for ( var idKey in oHashedData ) {
				var aSum = [];
				var aIndex = [];

				var aSumKeys = [];
				var aRows = oHashedData[ idKey ];
				//log.audit( 'aRows.length', aRows.length );
				str += "{";
				for ( var j = 0; j < aRows.length; j++ ) {
					if ( j == 0 ) { //grouped by same keys
						var oCol = aRows[ j ];
						//log.debug('1', oCol);
						var z = 0;
						for ( var k = 0; k < VAL_LOOP; k++ ) {
							//log.audit( 'my k test::' + k, isEmpty( oCol[ FLD_PDF_IO + '' + ( k + 1 ) ] ) );

							if ( !isEmpty( oCol[ FLD_PDF_IO + '' + ( k + 1 ) ] ) ) {
								var sValue = oCol[ FLD_PDF_IO + '' + ( k + 1 ) ];

								var bSubTotal = false;
								var sLabel = oPDFFields[ FLD_PDF_TITLE + '' + ( k + 1 ) ];
								//log.audit( 'my sLabel test::', sLabel );
								if ( sLabel.indexOf( '(Total)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(total)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(Subtotal)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(subtotal)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(SubTotal)' ) > -1 ) {
									bSubTotal = true;
								}
								//log.debug('summary bSubTotal',bSubTotal);
								var numStr = sValue;
								var numNum = +numStr;

								var bCurrency = false;
								//log.audit( 'VAL_COL_NAME', VAL_COL_NAME );


								//log.debug('aPDFIOFields[k] 1', aPDFIOFields[k] + ' VAL_COL_NAME.indexOf(aPDFIOFields[k])='+VAL_COL_NAME.indexOf(aPDFIOFields[k]));
								if ( VAL_COL_NAME.indexOf( aPDFIOFields[ k ] ) > -1 ) {
									var nColIndex = VAL_COL_NAME.indexOf( aPDFIOFields[ k ] );
									//log.debug(' VAL_COL_TYPE.indexOf(iaPDFIOFields[k]) 1='+VAL_COL_TYPE[nColIndex] + ' ' + VAL_COL_TYPE[nColIndex].indexOf('currency') + ' float='+VAL_COL_TYPE[nColIndex].indexOf('float'));

									if ( VAL_COL_TYPE[ nColIndex ].indexOf( 'currency' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'float' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'numeric' ) > -1 ) {
										bCurrency = true;
									}
								}
								var nColIndex = VAL_COL_NAME.indexOf( aPDFIOFields[ k ] );

								//log.audit('my ytest::'+numStr, VAL_COL_TYPE[ nColIndex ].indexOf( 'text' ));

								if ( !isNaN( numNum ) && ( numStr.indexOf( '.' ) > -1 && nColIndex != null && nColIndex != '' && VAL_COL_TYPE[ nColIndex ].indexOf( 'text' ) == -1 ) || bSubTotal == true ) {
									//log.debug('sum cols index', k + ' numNum='+numNum);
									aSum[ z ] = numNum;
									aIndex.push( k );
									z++;
									aSumKeys.push( aPDFIOFields[ k ] );
								} else {
									//log.debug('sValue=', sValue);
									var sValue = xml.escape( {
										xmlText: oCol[ FLD_PDF_IO + '' + ( k + 1 ) ]
									} );
									str += '"' + ( FLD_PDF_IO + '' + ( k + 1 ) ) + '":"' + sValue + '",';
									//log.debug(' column value', FLD_PDF_IO+''+(k+1) + ' sValue='+sValue);
								}


								//log.debug('summary str',str);
							} else {
								//log.debug('empty', FLD_PDF_IO+''+(k+1));
								var rowCol = oPDFFields[ FLD_PDF_TITLE + '' + ( k + 1 ) ];
								//log.debug('rowCol',rowCol);
								if ( rowCol != null && rowCol != '' ) {
									//.debug('rowCol inside',rowCol);
									rowCol = rowCol.toLowerCase();

									if ( rowCol.indexOf( 'gst' ) != -1 || rowCol.indexOf( 'pst' ) != -1 || rowCol.indexOf( 'hst' ) != -1 || rowCol.indexOf( 'qst' ) != -1 || rowCol.indexOf( 'bill' ) != -1 || rowCol.indexOf( 'amount' ) != -1 ) {
										aSum[ z ] = 0;
										aIndex.push( k );
										//log.debug('rowCol',rowCol + ' k ='+k);
										z++;
										aSumKeys.push( aPDFIOFields[ k ] );
									}
								}

							}

						}
						//break;
					} else {
						var oCol = aRows[ j ];
						//log.debug('', oCol);
						var z = 0;
						for ( var k = 0; k < VAL_LOOP; k++ ) {
							if ( !isEmpty( oCol[ FLD_PDF_IO + '' + ( k + 1 ) ] ) ) {
								var sValue = oCol[ FLD_PDF_IO + '' + ( k + 1 ) ];
								//log.debug('sum cols', sValue);
								var bSubTotal = false;
								var sLabel = oPDFFields[ FLD_PDF_TITLE + '' + ( k + 1 ) ];
								if ( sLabel.indexOf( '(Total)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(total)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(Subtotal)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(subtotal)' ) > -1 ) {
									bSubTotal = true;
								} else if ( sLabel.indexOf( '(SubTotal)' ) > -1 ) {
									bSubTotal = true;
								}

								//log.debug('col type :::: sLabel',VAL_COL_TYPE[nColIndex]+ '::::' + sLabel);

								var numStr = sValue;
								var numNum = +numStr;
								/*if (!isNaN(numNum)){
										    //str += '"'+(FLD_PDF_IO+''+(k+1))+'":"'+sValue+'",';
									aSum[z] += numNum;
									z++;
								}*/
								//log.debug('summary bSubTotal',bSubTotal);

								var bCurrency = false;
								//log.debug('aPDFIOFields[k] 2', aPDFIOFields[k] + ' VAL_COL_NAME.indexOf(aPDFIOFields[k])='+VAL_COL_NAME.indexOf(aPDFIOFields[k]) + 'k='+k);
								if ( VAL_COL_NAME.indexOf( aPDFIOFields[ k ] ) > -1 ) {
									var nColIndex = VAL_COL_NAME.indexOf( aPDFIOFields[ k ] );
									//log.debug(' VAL_COL_TYPE.indexOf(iaPDFIOFields[k]) 2='+VAL_COL_TYPE[nColIndex] + ' ' + VAL_COL_TYPE[nColIndex].indexOf('currency') + ' float='+VAL_COL_TYPE[nColIndex].indexOf('float'));

									if ( VAL_COL_TYPE[ nColIndex ].indexOf( 'currency' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'float' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'numeric' ) > -1 ) {
										bCurrency = true;
									}
								}

								var nColIndex = VAL_COL_NAME.indexOf( aPDFIOFields[ k ] );

								//log.audit('my ztest', VAL_COL_TYPE[ nColIndex ].indexOf( 'text' ));

								if ( ( !isNaN( numNum ) && numStr.indexOf( '.' ) > -1 && nColIndex != null && nColIndex != '' && VAL_COL_TYPE[ nColIndex ].indexOf( 'text' ) == -1 ) || bSubTotal == true ) {
									//log.debug('sum cols index 2', k + ' numNum='+numNum);
									aSum[ z ] += numNum;
									aIndex.push( k );
									z++;
									aSumKeys.push( aPDFIOFields[ k ] );

								} else {
									var sValue = xml.escape( {
										xmlText: oCol[ FLD_PDF_IO + '' + ( k + 1 ) ]
									} );
									str += '"' + ( FLD_PDF_IO + '' + ( k + 1 ) ) + '":"' + sValue + '",';
									log.debug( ' column value of ' + sLabel, FLD_PDF_IO + '' + ( k + 1 ) + ' sValue=' + sValue );
								}


							} else {
								//log.debug('empty', FLD_PDF_IO+''+(k+1));
								var rowCol = oPDFFields[ FLD_PDF_TITLE + '' + ( k + 1 ) ];
								//log.debug('rowCol',rowCol);
								if ( rowCol != null && rowCol != '' ) {
									rowCol = rowCol.toLowerCase();
									//  log.debug('rowCol inside 2',rowCol);
									if ( rowCol.indexOf( 'gst' ) != -1 || rowCol.indexOf( 'pst' ) != -1 || rowCol.indexOf( 'hst' ) != -1 || rowCol.indexOf( 'qst' ) != -1 || rowCol.indexOf( 'bill' ) != -1 || rowCol.indexOf( 'amount' ) != -1 ) {
										aSum[ z ] = 0;
										aIndex.push( k );
										//log.debug('rowCol',rowCol + ' k ='+k);
										z++;
										aSumKeys.push( aPDFIOFields[ k ] );
									}

								}

							}

						}
					}

					if ( j == aRows.length - 1 ) {
						//log.debug('aSumKeys',aSumKeys);
						//add sum
						//log.debug('aSum.length',aSum.length);
						for ( var c = 0; c < aSum.length; c++ ) {
							var fSum = aSum[ c ];
							fSum = fSum.toString();
							var rowCol = oPDFFields[ FLD_PDF_TITLE + '' + ( c + 1 ) ];
							if ( rowCol != null && rowCol != '' ) {
								rowCol = rowCol.toLowerCase();
							}

							//log.debug('rowCol' + rowCol + ' index:'+FLD_PDF_TITLE+''+(c+1));

							var bCurrency = false;
							log.debug( 'aSumKeys', aSumKeys[ c ] + ' VAL_COL_NAME.indexOf(aSumKeys[c])=' + VAL_COL_NAME.indexOf( aSumKeys[ c ] ) );
							if ( VAL_COL_NAME.indexOf( aSumKeys[ c ] ) > -1 ) {
								var nColIndex = VAL_COL_NAME.indexOf( aSumKeys[ c ] );
								//log.debug(' VAL_COL_TYPE.indexOf(iaPDFIOFields[c]) ='+VAL_COL_TYPE[nColIndex] + 'currency= ' + VAL_COL_TYPE[nColIndex].indexOf('currency') + ' float='+VAL_COL_TYPE[nColIndex].indexOf('float'));

								if ( VAL_COL_TYPE[ nColIndex ].indexOf( 'currency' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'float' ) > -1 || VAL_COL_TYPE[ nColIndex ].indexOf( 'numeric' ) > -1 ) {
									bCurrency = true;
								}
							}



							if ( fSum.indexOf( '.' ) > -1 && bCurrency == true ) {
								fSum = currencyFormat( fSum, currencySymbol );
							} else {

								//var rowCol = oPDFFields[FLD_PDF_TITLE+''+(c+1)];
								var rowCol = oPDFFields[ FLD_PDF_TITLE + '' + ( ( aIndex[ c ] ) + 1 ) ];
								if ( rowCol != null && rowCol != '' ) {
									rowCol = rowCol.toLowerCase();

									if ( bCurrency == true || rowCol.indexOf( 'gst' ) != -1 || rowCol.indexOf( 'pst' ) != -1 || rowCol.indexOf( 'hst' ) != -1 || rowCol.indexOf( 'qst' ) != -1 || rowCol.indexOf( 'bill' ) != -1 || rowCol.indexOf( 'amount' ) != -1 ) {
										fSum = currencyFormat( fSum, currencySymbol );
										//log.debug('formatted ' + rowCol);
									} else {
										fSum = fSum;
										//log.debug('no formatted ' + rowCol);
									}
								}

							}
							log.debug( 'summary col', FLD_PDF_IO + '' + ( ( aIndex[ c ] ) + 1 ) + ' fSum=' + fSum );
							str += '"' + ( FLD_PDF_IO + '' + ( ( aIndex[ c ] ) + 1 ) ) + '":"' + fSum + '",';
						}

					}
				}
				str = str.slice( 0, -1 );
				str += "},";

			}
			str = str.slice( 0, -1 );

			oGroupedData += str;
			oGroupedData += "]";

			log.debug( 'oGroupedData', oGroupedData );
			return oGroupedData;

		}

		function getChildClientAddress ( idCustomer, oCIFields, idPDFLayout ) {
			var customer = record.load( {
				type: 'customer',
				id: idCustomer,
				isDynamic: true,
			} );
			var nAddressLine = customer.getLineCount( { sublistId: 'addressbook' } );
			log.debug( 'nAddressLine', nAddressLine );
			var contactAddress = '';
			for ( var z = 0; z < nAddressLine; z++ ) {
				customer.selectLine( { sublistId: 'addressbook', line: z } );
				var bDefaultBill = customer.getCurrentSublistValue( {
					sublistId: 'addressbook',
					fieldId: 'defaultbilling'
				} );
				if ( bDefaultBill == true || bDefaultBill == 'T' ) {
					var addressSubRecord = customer.getCurrentSublistSubrecord( {
						sublistId: 'addressbook',
						fieldId: 'addressbookaddress'
					} );

					log.debug( 'addr1', addressSubRecord.getValue( 'addr1' ) );
					log.debug( 'addr2', addressSubRecord.getValue( 'addr2' ) );
					log.debug( 'country', addressSubRecord.getValue( 'country' ) );
					//log.debug('parentClientName', oCIFields[FLD_CI_PARENT_CLIENT][0]);
					var idParentCheck = '';
					var idChildCustomerCheck = '';
					if ( !isEmpty( oCIFields[ FLD_CI_PARENT_CLIENT ] ) ) {

						var oParent = search.lookupFields( {
							type: 'customer',
							id: oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ].value,
							columns: [ 'companyname' ]
						} );

						idParentCheck = oCIFields[ FLD_CI_PARENT_CLIENT ][ 0 ].value;
						//added by shravan 09-05-2022
						var isParentRestricted = false;
						if ( ( EMAIL_TEMPLATES_RESTRICT_HEARTSCIENCEMONTREAL.indexOf( idPDFLayout ) != -1 ) && ( idParentCheck == 1166783 ) )// && ( EMAIL_TEMPLATE_ADDRESS_CLIENT.indexOf( oCIFields[ FLD_CI_PARENT_CLIENT ] ) == -1 ) )
							isParentRestricted = true;
						if ( !isParentRestricted )
							contactAddress += oParent[ 'companyname' ] + '\n';

					}
					//contactAddress += oCIFields[FLD_CI_CLIENT][0].text + '\n';
					//var aClientName = (oCIFields[FLD_CI_CLIENT][0].text).split(':');
					//contactAddress += aClientName[aClientName.length-1] + '\n';

					if ( !isEmpty( oCIFields[ FLD_CI_CLIENT ] ) ) {
						var oChild = search.lookupFields( {
							type: 'customer',
							id: oCIFields[ FLD_CI_CLIENT ][ 0 ].value,
							columns: [ 'companyname' ]
						} );
						idChildCustomerCheck = oCIFields[ FLD_CI_CLIENT ][ 0 ].value;
					}

					// added by shravankumar 10-05-2023
					var parentChildIds = runtime.getCurrentScript().getParameter( { name: SPARM_PARENT_CHILD_IDS } );
					if ( parentChildIds ) {
						parentChildIds = parentChildIds.split( ',' );
					}
					//if ( idParentCheck != 542884 && idParentCheck != 542995 && idChildCustomerCheck != 542884 && idChildCustomerCheck != 542995 ) {

					if ( parentChildIds.indexOf( idParentCheck ) == -1 && parentChildIds.indexOf( idChildCustomerCheck ) == -1 ) {
						//added by shravan 09-05-2022
						var isParentRestricted = false;
						if ( ( EMAIL_TEMPLATES_RESTRICT_HEARTSCIENCEMONTREAL.indexOf( idPDFLayout ) != -1 ) && ( idParentCheck == 1166783 ) )// && ( EMAIL_TEMPLATE_ADDRESS_CLIENT.indexOf( oCIFields[ FLD_CI_PARENT_CLIENT ] ) == -1 ) )
							isParentRestricted = true;
						if ( !isParentRestricted )
							contactAddress += oChild[ 'companyname' ] + '\n';
					}
					if ( !isEmpty( addressSubRecord.getValue( 'addr1' ) ) ) {
						contactAddress += addressSubRecord.getValue( 'addr1' ) + '\n';
					}
					if ( !isEmpty( addressSubRecord.getValue( 'addr2' ) ) ) {
						contactAddress += addressSubRecord.getValue( 'addr2' ) + '\n';
					}
					if ( !isEmpty( addressSubRecord.getValue( 'addr3' ) ) ) {
						contactAddress += addressSubRecord.getValue( 'addr3' ) + '\n';
					}
					if ( !isEmpty( addressSubRecord.getValue( 'city' ) ) ) {
						contactAddress += addressSubRecord.getValue( 'city' ) + ' ' + addressSubRecord.getValue( 'state' ) + '\n';
					}
					if ( !isEmpty( addressSubRecord.getValue( 'country' ) ) ) {
						contactAddress += addressSubRecord.getText( 'country' ) + ' ' + addressSubRecord.getValue( 'zip' ) + '\n';

					}
					break;
				}
			}
			return contactAddress;
		}
		function getParentClientAddress ( idCustomer, oCIFields ) {
			var customer = record.load( {
				type: 'customer',
				id: idCustomer,
				isDynamic: true,
			} );

			//return customer.getValue('defaultaddress'); /*oParentClientFields['defaultaddress'];*/
			//replace name
			var parentClientName = customer.getValue( 'companyname' );
			var childClientName = oCIFields[ FLD_CI_CLIENT ][ 0 ].text;
			childClientName = childClientName.split( ':' )
			var address = customer.getValue( 'defaultaddress' );
			//log.debug('parentClientName=,'+parentClientName + ' childClientName='+childClientName[1]);
			address = address.replace( parentClientName, parentClientName + '-' + childClientName[ 1 ] );

			return address;
		}

		function groupByOrig ( arr ) {
			var a = [ { "custrecord_appf_pdf_iofield1": "a", "custrecord_appf_pdf_iofield2": "a", "custrecord_appf_pdf_iofield3": "a", "custrecord_appf_pdf_iofield4": "a", "custrecord_appf_pdf_iofield5": "Four Color-16 Page Insert Tab", "custrecord_appf_pdf_iofield6": "19/11" }, { "custrecord_appf_pdf_iofield1": "a", "custrecord_appf_pdf_iofield2": "", "custrecord_appf_pdf_iofield3": "a", "custrecord_appf_pdf_iofield4": "a", "custrecord_appf_pdf_iofield5": "Four Color-16 Page Insert Tab", "custrecord_appf_pdf_iofield6": "19/11" } ];
			log.debug( 'arr', arr );
			log.debug( 'a', a );
			arr = JSON.parse( arr );
			var helper = {};
			var result = a.reduce( function ( r, o ) {
				log.debug( 'o', o );
				var key;
				for ( var i = 0; i < 10; i++ ) {
					if ( o[ 'custrecord_appf_pdf_iofield' + '' + ( i + 1 ) ] != 'undefined' && o[ 'custrecord_appf_pdf_iofield' + '' + ( i + 1 ) ] != undefined ) {
						key += o[ 'custrecord_appf_pdf_iofield' + '' + ( i + 1 ) ] + '-';
					}

				}
				key = key.replace( 'undefined', '' );
				key = key.slice( 0, -1 );
				// var key = o.custrecord_appf_pdf_iofield1 + '-' + o.custrecord_appf_pdf_iofield2 + '-' + o.custrecord_appf_pdf_iofield3;
				// log.debug('key',key);
				if ( !helper[ key ] ) {
					helper[ key ] = Object.assign( {}, o ); // create a copy of o
					r.push( helper[ key ] );
				} else {
					/*helper[key].used += o.used;
					helper[key].instances += o.instances;*/
				}

				return r;
			}, [] );

			log.debug( 'result', result );
			return result;
			//console.log(result);
		}

		function eliminateDuplicates ( arr ) {
			var i,
				len = arr.length,
				out = [],
				obj = {};

			for ( i = 0; i < len; i++ ) {
				obj[ arr[ i ] ] = 0;
			}
			for ( i in obj ) {
				out.push( i );
			}
			return out;
		}
		/**
		 * Evaluate id value is null
		 * @param stValue
		 */
		function isEmpty ( stValue ) {
			return (
				stValue === '' ||
				stValue === '[]' ||
				stValue === 'undefined' ||
				stValue == null ||
				stValue == undefined ||
				( stValue.constructor === Array && stValue.length == 0 ) ||
				( stValue.constructor === Object &&
					( function ( v ) {
						for ( var k in v ) return false;
						return true;
					} )( stValue ) )
			);
		}

		/**
		 * Formats value into currency
		 */
		function currencyFormat ( num, symbol ) {
			//log.debug('symbol',symbol);
			if ( num < 0 || parseFloat( num ) < 0 ) {
				num = parseFloat( num ) * -1;
				return '(' + symbol + '' + parseFloat( num ).toFixed( 2 ).replace( /(\d)(?=(\d{3})+(?!\d))/g, '$1,' ) + ')'
			} else {
				return symbol + '' + parseFloat( num ).toFixed( 2 ).replace( /(\d)(?=(\d{3})+(?!\d))/g, '$1,' )
			}

		}
		/**
		 * Formats value
		 */
		function valueFormat ( num ) {
			return parseFloat( num ).toFixed( 2 ).replace( /(\d)(?=(\d{3})+(?!\d))/g, '$1,' )
		}
		return {
			onRequest: onRequest
		};

	} );