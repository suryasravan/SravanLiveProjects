/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Description: Set up tax amount into custom fields for PST and GST calculation..
 * 
 * Author: roach
 * Date: Sep 21, 2020
 */
define(['N/record'],

function(record) {
	
	var FLD_SO_COL_TAXGST = 'custcol_appf_tax_amount_gst';
	var FLD_SO_COL_TAXPST = 'custcol_appf_tax_amount_pst';
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
		var recInvoice = scriptContext.newRecord;
    	
    	var nLines = recInvoice.getLineCount({ sublistId: 'item' });

		for(var i = 0; i < nLines; i++){
    		var fAmount = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: 'amount',
        	    line: i
        	});
    		var fGST = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: 'taxrate1',
        	    line: i
        	});
    		var fPST = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: 'taxrate2',
        	    line: i
        	});
    		log.debug('fGST',fGST);
            log.debug('fPST',fPST);
    		if((fGST != null && fGST != '') || (fGST == 0 || fPST == 0)){
    			var fGSTCalc = (parseFloat(fGST)/100)*parseFloat(fAmount);
    			fGSTCalc = fGSTCalc;
    			
    			var fGSTCalcFormat = fGSTCalc.toString();
    			fGSTCalcFormat = Number(Math.round(fGSTCalcFormat + "e2") + "e-2");
    			recInvoice.setSublistValue({
    			    sublistId: 'item',
    			    fieldId: FLD_SO_COL_TAXGST,
    			    line: i,
    			    value: fGSTCalc
    			});
    		}
    		
    		if(fPST != null && fPST != '' || (fGST == 0 || fPST == 0)){
    			var fPSTCalc = (parseFloat(fPST)/100)*parseFloat(fAmount);
    			fPSTCalc = fPSTCalc;
    			var fPSTCalcFormat = fPSTCalc.toString();
    			fGSTCalcFormat = Number(Math.round(fPSTCalcFormat + "e2") + "e-2");
    			recInvoice.setSublistValue({
    			    sublistId: 'item',
    			    fieldId: FLD_SO_COL_TAXPST,
    			    line: i,
    			    value: fPSTCalc
    			});
    		}



		}
		//recInvoice.save();
    }


    return {
        beforeSubmit: beforeSubmit
    };
    
});