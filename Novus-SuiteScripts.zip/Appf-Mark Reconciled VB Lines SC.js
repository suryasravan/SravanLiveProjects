/*Script Name: Appf-Mark Reconciled VB Lines SC
 *Script Type: Scheduled
 *Description: This Script will uncheck Discrepant check box & remove Discrepancy Type in VB lines from the "appf - Mark Reconciled Vendor Bill Lines (Script - Do Not Use)" SS. 
 *Company 	 : Appficiency.
 */
var FLD_COL_DISCREPANCY_TYPE='custcol_appf_discrepancy_type';
var FLD_COL_DISCREPANT='custcol_appf_discrepant';
var FLD_COL_VENDOR_BILL_LINE_ID='custcol_appf_vendorbill_line_id';

var SPARAM_RECOCILED_VB_LINES_SS='custscript_appf_saved_search_id';
var SPARAM_FILE_ID='custscript_appf_vb_file_id';
var SPARAM_INDEX = 'custscript_appf_vb_index';

function scheduledOnVendorBill(type)
{
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT',SPARAM_RECOCILED_VB_LINES_SS);
	var fileID = context.getSetting('SCRIPT',SPARAM_FILE_ID);
	var index = context.getSetting('SCRIPT',SPARAM_INDEX);

	if(index == null || index == '')
		index = 0;
	nlapiLogExecution('debug','ssID:', ssID);

	try{
	var mainObj={};
	if((fileID == null || fileID == '') && ssID != null && ssID != ''){
	var loadSS = nlapiLoadSearch(null,ssID);
   	var filters = loadSS.getFilters();
   	var columns = loadSS.getColumns();
 	var ssType = loadSS.getSearchType();
 	var searchResults=getAllSearchResults(ssType, filters, columns);
	if (searchResults != null && searchResults != '') {
		var columns = searchResults[0].getAllColumns();
		for(var i = 0; i < searchResults.length; i++) {
			 var internalid = searchResults[i].getId();
             var vbLineID = searchResults[i].getValue(columns[5]);
             
			 
			 if(!mainObj.hasOwnProperty(internalid))
			 {
				 mainObj[internalid] = [];
			     	 
             }
			  if(mainObj[internalid].indexOf(internalid) == -1)
			 {
				 mainObj[internalid].push(vbLineID);
			     	 
             }
			 
				
		}
	    nlapiLogExecution('debug','mainObj:',JSON.stringify(mainObj));

	
	 var contents = '';
	  if(mainObj != null && mainObj != '')
      {
	      for(var prop in mainObj)
	      { 
	    	
	    	  contents = contents + prop + '__';
	    	  var vbLineID=mainObj[prop];  
			 for(var j=0; j<vbLineID.length; j++)
			 {
				 contents +=  vbLineID[j] + '|' ;
			 }
			 contents = contents.slice(0, -1)+ '\n';

	      }

      }
	  if(contents != null && contents != '')
	     {
			 var timeStamp = new Date().getTime();
	          var file = nlapiCreateFile('markReconciledVblines_'+timeStamp+'.csv', 'CSV', contents);
	      	file.setFolder('-15');
	      	 fileID = nlapiSubmitFile(file);
		     nlapiLogExecution('debug','fileID',fileID);
	     }
	}
	}
	  if(fileID != null && fileID != '')
	  {
		var fileProcessed=true;
		var allData = nlapiLoadFile(fileID);
		var fileValue = allData.getValue();
		if(fileValue != null && fileValue != ''){
		var fileRows = fileValue.split('\n');
		if(fileRows != null && fileRows != ''){
		  for(var f=index; f<(fileRows.length-1); f++){
			  try{
			if (fileRows[f] != null && fileRows[f] != ''){
				
				var eachLine = fileRows[f];
				if(eachLine != null && eachLine != ''){
				var lines = eachLine.split('__');
				var vbID = lines[0];
				var vbLineID = lines[1];
			     var vendorBillRec = nlapiLoadRecord('vendorbill', vbID);
			     if(vbLineID != null && vbLineID != '')
			    {
			     var vbLines = vbLineID.split('|');
					for(var e=0; e<vbLines.length; e++){
						var eachLineID = vbLines[e];
					     if(eachLineID != null && eachLineID != ''){
					     var linenumber = vendorBillRec.findLineItemValue('item', FLD_COL_VENDOR_BILL_LINE_ID, eachLineID);
						 if(linenumber > 0)
						 {
						  vendorBillRec.setLineItemValue('item', FLD_COL_DISCREPANCY_TYPE, linenumber, '');
						  vendorBillRec.setLineItemValue('item', FLD_COL_DISCREPANT, linenumber, 'F');
						 }
					     }

					}
					var updatedVBID=nlapiSubmitRecord(vendorBillRec, true, true);
			     nlapiLogExecution('debug','updatedVBID',updatedVBID);
				}
				

				}

			}
		  }catch(e){
			  if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
		  }
		  if(context.getRemainingUsage() < 500 && (f+1)>(fileRows.length-1)){
			  fileProcessed=false;
			  var param={};
			  params[SPARAM_INDEX] = (f+1);
			  params[SPARAM_FILE_ID] = fileID;
			  params[SPARAM_RECOCILED_VB_LINES_SS] = ssID;
			  nlapiScheduleScript(context.getScriptId(),null,params);
			  break;
			  
		  }
		  }
	   }
	  }
if(fileProcessed)
 nlapiDeleteFile(fileID);
}

		  
}catch (e) {
	   if ( e instanceof nlobjError )
		      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		      else
		      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
		}
	   
}


//function calling
//var searchres_morethan1000 = getAllSearchResults(record_type, filters, columns);
//function definations
function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
