/**
* Script Name : Appf-VVCCP Post Filters Click  SS
* Script Type : Schedule Script
* 
* Version    Date            Author           		Remarks
* 1.00            			 Debendra Panigrahi		
*
* Company 	 : Appficiency. 
*/
var SPARAM_BILL_DATA_FILE_FROM_VVCCP_EXECUTION_LOG='custscript_bill_csv_data_files';
var SPARAM_CREDIT_DATA_FILE_FROM_VVCCP_EXECUTION_LOG='custscript_credit_csv_data_files';

var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS=3;
var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS=1;
var FLD_VVCCP_PROCESSING_STATUS_PROCESSED_FOR_TRANSACTIONS=2;

var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978;
var BILL_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_bill_vvccp';
var CREDIT_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_cred_vvccp';
function schedule(type)
{
	var context=nlapiGetContext();
	var billDataFile=context.getSetting('SCRIPT',SPARAM_BILL_DATA_FILE_FROM_VVCCP_EXECUTION_LOG);
	var creditDataFile=context.getSetting('SCRIPT',SPARAM_CREDIT_DATA_FILE_FROM_VVCCP_EXECUTION_LOG);
	nlapiLogExecution('DEBUG', 'billDataFile:',billDataFile);
	nlapiLogExecution('DEBUG', 'creditDataFile:',creditDataFile);
	var billCsvDataFile='';
	var creditCsvDataFile='';
	var randomNum = new Date();
	var randomText = randomNum.getTime()+'I';
	if(billDataFile !=null && billDataFile !='')
	{
				var billFile=nlapiLoadFile(Number(billDataFile));
				var billValues=billFile.getValue();
				billValues=billValues.split('\n');
				billValues=billValues.slice(0,-1);
				nlapiLogExecution('DEBUG', 'billValues:',billValues);
				for(var v=0;v<billValues.length;v++)
				{
					if(v == 0)
					{
						var columns=billValues[v];
						billCsvDataFile=columns+'\n';
					}
					else
					{
						var columns=billValues[v];
						var columnsValues=columns.split(',');
						billCsvDataFile+= columnsValues[0]+','+FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS+','+columnsValues[2]+','+columnsValues[3]+','+columnsValues[4]+','+columnsValues[5]+'\n'
					}
				}
		var billDataFileCreate=nlapiCreateFile('Selected_Bills_Status_update_Under_processing'+randomText+'.csv','CSV',billCsvDataFile);
		billDataFileCreate.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
		var billDataFileID= nlapiSubmitFile(billDataFileCreate);
		var importToUpdateBills = nlapiCreateCSVImport();
		importToUpdateBills.setMapping(BILL_UPDATE_CSV_IMPORT_ID);
		importToUpdateBills.setPrimaryFile(nlapiLoadFile(billDataFileID));
		var importToUpdateBillsID = nlapiSubmitCSVImport(importToUpdateBills);		
	}
	if(creditDataFile !=null && creditDataFile !='')
	{
				var creditFile=nlapiLoadFile(Number(creditDataFile));
				var creditValues=creditFile.getValue();
				creditValues=creditValues.split('\n');
				creditValues=creditValues.slice(0,-1);
				nlapiLogExecution('DEBUG', 'creditValues:',creditValues);
				for(var v=0;v<creditValues.length;v++)
				{
					if(v == 0)
					{
						var columns=creditValues[v];
						creditCsvDataFile=columns+'\n';
					}
					else
					{
						var columns=creditValues[v];
						var columnsValues=columns.split(',');
						creditCsvDataFile+= columnsValues[0]+','+FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS+','+columnsValues[2]+','+columnsValues[3]+'\n';
					}
				}
				var creditDataFileCreate=nlapiCreateFile('Selected_Credits_Status_update_UnderProcessing'+randomText+'.csv','CSV',creditCsvDataFilea);
				creditDataFileCreate.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var creditDataFileID= nlapiSubmitFile(creditDataFileCreate);
				var importToUpdateCredits = nlapiCreateCSVImport();
				importToUpdateCredits.setMapping(CREDIT_UPDATE_CSV_IMPORT_ID);
				importToUpdateCredits.setPrimaryFile(nlapiLoadFile(creditDataFileID));
				var importToUpdateCreditsID = nlapiSubmitCSVImport(importToUpdateCredits);
				
	}
	
}