
/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Generates custom PDF layout depending on PDF template assigned to CI NRECORD.
 * 
 * Author: marlon
 * Date: Nov 19, 2020
 */

define(
    [
        'N/http',
        'N/log',
        'N/record',
        'N/runtime',
        'N/search',
        'N/ui/serverWidget',
        'N/url',
        'N/file',
        'N/redirect',
        'N/task'

    ],

    function (
        NHTTP,
        NLOG,
        NRECORD,
        NRUNTIME,
        NSEARCH,
        NUI,
        NURL,
        NFILE,
        redirect,
        task
    ) {

        var FLD_GRP_CLIENT_DETAILS = 'custpage_client_details';
        var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
        var FLD_SL_CLIENT = 'custpage_client';
        var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
        var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
        var FLD_SL_LINE_OF_BUSINESS = 'custpage_line_of_business';
        var FLD_SL_CURRENCY = 'custpage_currency';
        var FLD_SL_CONTRACT = 'custpage_contract';
        var FLD_SL_PUBLISHER_MEDIA_SIPPLIER = 'custpage_publisher_media_supplier';
        var FLD_SL_VENDOR = 'custpage_vendor';
        var FLD_SL_TRANSACTION_TYPE = 'custpage_transaction_tupe';
        var FLD_SL_DATE_FROM = 'custpage_date_from';
        var FLD_SL_DATE_TO = 'custpage_date_to';
        var FLD_SL_SCHED_NAME_PROJ = 'custpage_sched_ame_proj';
        var FLD_SL_BILL_MONTH = 'custpage_bill_month';
        var FLD_SL_ADJUSTMENT_INVOICE = 'custpage_adjustment_invoice';

        var FLD_SL_PLACEMENT_STR_1 = 'custpage_placement_str_1';
        var FLD_SL_PLACEMENT_STR_2 = 'custpage_placement_str_2';
        var FLD_SL_PLACEMENT_STR_3 = 'custpage_placement_str_3';
        var FLD_SL_PLACEMENT_STR_4 = 'custpage_placement_str_4';
        var FLD_SL_PLACEMENT_STR_5 = 'custpage_placement_str_5';
        var FLD_SL_PLACEMENT_STR_6 = 'custpage_placement_str_6';
        var FLD_SL_GRP_TRANSACTION_LINKS = 'custpage_ci_transaction_links';


        var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
        var FLD_GRP_CONTRACT_DETAILS = 'custpage_contract_details_tab';
        var FLD_SL_GRP_BATCH_OPTION_1 = 'custpage_batch_opt_1';
        var FLD_SL_GRP_BATCH_OPTION_2 = 'custpage_batch_opt_2';
        var FLD_SL_GRP_BATCH_OPTION_3 = 'custpage_batch_opt_3';
        var FLD_SL_GRP_BATCH_OPTION_4 = 'custpage_batch_opt_4';
        var FLD_SL_GRP_OVERRIDE = 'custpage_override';

        var FLD_GRP_SUMMARY_DETAILS = 'custpage_summary_details';
        var FLD_SL_GRP_INV_AVAIL_CONSOL = 'custpage_inv_avail_consol';
        var FLD_SL_GRP_INV_LINES_AVAIL_CONSOL = 'custpage_inv_lines_avail_consol';
        var FLD_SL_GRP_TOT_CI_TO_CREATE = 'custpage_total_ci_to_create';
        var FLD_SL_GRP_TOT_CI_AMT = 'custpage_total_ci_amount';
        var FLD_SL_GRP_TOT_CI_INVOICES = 'custpage_total_ci_invoices';

        var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
        var CUSTOM_SEGMENT_MEDIA = 'line.cseg_appf_media_seg';
        var CUSTOM_RECORD_MEDIA_SUPLIER = 'customrecord_appf_media_supplier';
        var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
        var TRANSACTION_TYPE_INV = 'CustInvc';
        var TRANSACTION_TYPE_CM = 'CustCred';
        var CUSTOM_LIST_BATCH_OPTIONS = 'customlist_appf_batch_options';

        var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
        var BTN_SL_MARK_ALL = 'custpage_btn_mark_all';
        var BTN_SL_UNMARK_ALL = 'custpage_btn_unmark_all';

        var SUBLIST_SL_INV_DETAILS = 'custpage_sublist_inv_details';
        var FLD_COL_SL_SELECT = 'custpage_sl_select';
        var FLD_COL_SL_INTERNAL_ID = 'custpage_internal_id';
        var FLD_COL_SL_CLIENT_ID = 'custpage_client_id';
        var FLD_COL_SL_CONTRACT_ID = 'custpage_contract_id';
        var FLD_COL_SL_CURRENCY_ID = 'custpage_currency_id';
        var FLD_COL_SL_REC_TYPE = 'custpage_type_id';

        var FLD_CONTRACT = 'custbody_appf_client_contract';
        var FLD_PUBLISHER = 'custcol_appf_publisher';
        var FLD_CI_BATCH_STATUS = 'custbody_appf_ci_batch_status';
        var FLD_CONSOLIDATED = 'custcol_appf_ready_consolidation'

        var FLD_CI_BATCH_STATUS_NOT_STARTED = '1';
        var FLD_CI_BATCH_STATUS_UNDER_PROCESSING = '2';
        var FLD_CI_BATCH_STATUS_COMPLETED = '3';
        var FLD_CI_BATCH_STATUS_FAILED = '4';

        var FLD_COL_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';
        var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
        var FLD_COL_BILL_MONTH = 'custcol_appf_bill_month';
        var FLD_COL_PLACEMENT_STRING_1 = 'custcol_appf_placement1';
        var FLD_COL_PLACEMENT_STRING_2 = 'custcol_appf_placement2';
        var FLD_COL_PLACEMENT_STRING_3 = 'custcol_appf_placement3';
        var FLD_COL_PLACEMENT_STRING_4 = 'custcol_appf_placement4';
        var FLD_COL_PLACEMENT_STRING_5 = 'custcol_appf_placement5';
        var FLD_COL_PLACEMENT_STRING_6 = 'custcol_appf_placement6';
        var FLD_COL_CI_STATUS = 'custcol_appf_ci_status';
        var FLD_COL_CI_LOG = 'custcol_appf_ci_log';
        var CI_STATUS_UNDER_PROCESSING = '2';
        var FLD_COL_ADJUSTMENT_INVOICE = 'custcol_appf_adjustment_invoice';

        var SCRIPT_CREATE_CLIENT_CI_VALIDATIONS = 'customscript_appf_create_client_ci_valid';
        var SCRIPT_CREATE_CLIENT_CI_SC = 'customscript_appf_create_client_ci_sc';
        var SCRIPT_CREATE_CLIENT_CI_V2 = 'SuiteScripts/Appf - CI Solution Version 2/Appf-CL-Consolidated-Invoice-2_0.js';
        //var DEPLOY_CREATE_CLIENT_CI_SC = '';
        var SPARAM_CI_EXEC_LOG_ID = 'custscript_appf_ci_execution_log_id2_mr';
        var SPARAM_CI_EXEC_FOLDER_ID = 'custscript_appf_ci_exec_fold_id2_mr';

        var SPARAM_APPF_INV_LINES_FOR_CONSOL_SS = 'custscript_appf_inv_lines_for_ci_ss2';

        var SPARAM_FOLDER_CLIENT_CONSOLIDATED_INVOICES = 'custscript_appf_client_ci_folder_id2_mr';
        var SPARAM_SEARCH_COLS_LENGTH = 'custscript_appf_search_columns_length2_m';

        var CUSTOM_RECORD_CI_EXECUTION_LOG = 'customrecord_appf_ci_execution_log';
        var FLD_CI_EXEC_LOG_FILE = 'custrecord_appf_ci_file_to_process';
        var FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_ci_total_lines_process';
        var FLD_CI_EXEC_LOG_REMAIN_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_ci_remain_lines_process';
        var FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_PROCESSED = 'custrecord_appf_ci_lines_processed';
        var FLD_CI_EXEC_LOG_PERCENT_PROCESSED = 'custrecord_appf_ci_percent_processed';
        var FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE = 'custrecord_appf_ci_total_ci_to_create';
        var FLD_CI_EXEC_LOG_POST_EXEC_CONSOL_FILE = 'custrecord_appf_ci_post_exec_file';
        var FLD_CI_EXEC_LOG_PROCESSING_CONSOL_STATUS_FILE = 'custrecord_appf_ci_process_status_file';
        var FLD_CI_EXEC_LOG_ERROR_LOG = 'custrecord_appf_ci_error_log';
        var FLD_CI_EXEC_LOG_ERROR_FILE = 'custrecord_appf_ci_error_file';
        var FLD_CI_EXEC_LOG_CREATED_BY = 'custrecord_appf_ci_log_created_by';
        var FLD_CI_EXEC_LOG_TOT_CI_CREATED = 'custrecord_appf_ci_total_ci_created';
        var FLD_CI_EXEC_LOG_BATCH_OPTION_1 = 'custrecord_appf_ci_exec_batch_opt_1';
        var FLD_CI_EXEC_LOG_BATCH_OPTION_2 = 'custrecord_appf_ci_exec_batch_opt_2';
        var FLD_CI_EXEC_LOG_BATCH_OPTION_3 = 'custrecord_appf_ci_exec_batch_opt_3';
        var FLD_CI_EXEC_LOG_BATCH_OPTION_4 = 'custrecord_appf_ci_exec_batch_opt_4';
        var FLD_CI_EXEC_LOG_CI_BATCH_STATUS = 'custrecord_appf_ci_exec_batch_status';
        var FLD_CI_EXEC_LOG_TRANSACTION_LINKS = 'custrecord_appf_ci_transaction_links';
        var FLD_CI_EXEC_LOG_LINES_TO_PROCESS = 'custrecord_appf_ci_lines_toprocess';
        var FLD_CREATE_CLIENT_CI_SL = 'custpage_sl_url';

        var SEARCH_CI_LOGS_IN_PROGRESS = 'customsearch_appf_ci_logs_inprog';

        var SCRIPT_CI_MR = 'customscript_appf_create_client_ci_mr_v2';
        var DEPLOY_CI_MR = 'customdeploy_appf_create_client_ci_mr_v2';

        function buildFormClientDetails ( form, parms ) {
            var LOG_TITLE = 'buildFormClientDetails';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var fld;

            // Field Group
            form.addFieldGroup( { id: FLD_GRP_CLIENT_DETAILS, label: 'Client Details (Filters)' } );

            fld = form.addField( {
                id: FLD_SL_CLIENT,
                type: NUI.FieldType.SELECT,
                label: 'Client',
                source: 'customer',
                container: FLD_GRP_CLIENT_DETAILS
            } );
            fld.defaultValue = parms.clientFlt;
            fld.isMandatory = true;

            form.addField( {
                id: FLD_SL_SUBSIDIARY,
                type: NUI.FieldType.SELECT,
                label: 'Subsidiary',
                source: 'subsidiary',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.subsiFlt;

            form.addField( {
                id: FLD_SL_MEDIA_SEGMENT,
                type: NUI.FieldType.SELECT,
                label: 'Media Segment',
                source: CUSTOM_RECORD_MEDIA_SEGMENT,
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.medSegFlt;

            form.addField( {
                id: FLD_SL_LINE_OF_BUSINESS,
                type: NUI.FieldType.SELECT,
                label: 'Line of Business',
                source: 'classification',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.lobFlt;

            fld = form.addField( {
                id: FLD_SL_CURRENCY,
                type: NUI.FieldType.SELECT,
                label: 'Currency',
                source: 'currency',
                container: FLD_GRP_CLIENT_DETAILS
            } );
            fld.defaultValue = parms.currFlt;
            fld.isMandatory = true;

            fld = form.addField( {
                id: FLD_SL_CONTRACT,
                type: NUI.FieldType.SELECT,
                label: 'Contract',
                container: FLD_GRP_CLIENT_DETAILS
            } );
            fld.addSelectOption( { value: '', text: '' } );
            if ( parms.clientFlt ) {
                var contrSearch = NSEARCH.create( {
                    type: CUSTOM_RECORD_CONTRACT,
                    filters: [ { name: FLD_CONTRACT_CLIENT, operator: 'anyof', values: [ parms.clientFlt ] } ],
                    columns: [ { name: 'name' } ]
                } );
                // var contrFils = new nlobjSearchFilter(FLD_CONTRACT_CLIENT, null, 'anyof', clientFlt);
                // var contrCols = new nlobjSearchColumn('name');
                // var contrSearch = nlapiSearchRecord(CUSTOM_RECORD_CONTRACT, null, contrFils, contrCols);
                var contrSearchRes = contrSearch.run().getRange( { start: 0, end: 1000 } );
                for ( var cr = 0; cr < contrSearchRes.length; cr++ ) {
                    var isCRDefault = false;
                    if ( contrSearchRes[ cr ].id == parms.contractFlt ) {
                        isCRDefault = true;
                    }

                    fld.addSelectOption( {
                        value: contrSearchRes[ cr ].id,
                        text: contrSearchRes[ cr ].getValue( { name: 'name' } ),
                        isSelected: isCRDefault
                    } );
                }
            }
            fld.isMandatory = true;
            fld.defaultValue = parms.contractFlt;

            form.addField( {
                id: FLD_SL_PUBLISHER_MEDIA_SIPPLIER,
                type: NUI.FieldType.SELECT,
                label: 'Publisher/Media Supplier',
                source: CUSTOM_RECORD_MEDIA_SUPLIER,
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.pubMedSupFlt;

            form.addField( {
                id: FLD_SL_VENDOR,
                type: NUI.FieldType.SELECT,
                label: 'Vendor',
                source: 'vendor',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.vendFlt;

            fld = form.addField( {
                id: FLD_SL_TRANSACTION_TYPE,
                type: NUI.FieldType.SELECT,
                label: 'Transaction Type',
                container: FLD_GRP_CLIENT_DETAILS
            } );
            fld.addSelectOption( { value: '', text: '' } );
            fld.addSelectOption( {
                value: TRANSACTION_TYPE_INV,
                text: 'Client Invoice',
                isSelected: parms.transTypeFlt == TRANSACTION_TYPE_INV
            } );
            fld.addSelectOption( {
                value: TRANSACTION_TYPE_CM, text: 'Credit Memo',
                isSelected: parms.transTypeFlt == TRANSACTION_TYPE_CM
            } );

            form.addField( {
                id: FLD_SL_DATE_FROM,
                type: NUI.FieldType.DATE,
                label: 'Date (From)',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.dtFrmFlt;

            form.addField( {
                id: FLD_SL_DATE_TO,
                type: NUI.FieldType.DATE,
                label: 'Date (To)',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.dtToFlt;

            form.addField( {
                id: FLD_SL_SCHED_NAME_PROJ,
                type: NUI.FieldType.SELECT,
                label: 'Schedule Name/Project',
                source: 'job',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.schedProjFlt;

            form.addField( {
                id: FLD_SL_BILL_MONTH,
                type: NUI.FieldType.TEXT,
                label: 'Bill Month',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.billMnthFlt;

            fld = form.addField( {
                id: FLD_SL_ADJUSTMENT_INVOICE,
                type: NUI.FieldType.SELECT,
                label: 'Adjustment Invoice',
                container: FLD_GRP_CLIENT_DETAILS
            } );
            fld.addSelectOption( { value: '', text: '' } );
            fld.addSelectOption( { value: 'T', text: 'Yes' } );
            fld.addSelectOption( { value: 'F', text: 'No' } );
            fld.defaultValue = parms.adjustInvFlt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_1,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 1',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr1Flt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_2,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 2',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr2Flt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_3,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 3',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr3Flt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_4,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 4',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr4Flt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_5,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 5',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr5Flt;

            form.addField( {
                id: FLD_SL_PLACEMENT_STR_6,
                type: NUI.FieldType.TEXT,
                label: 'Placement String 6',
                container: FLD_GRP_CLIENT_DETAILS
            } ).defaultValue = parms.plcmntStr6Flt;

            NLOG.debug( { title: LOG_TITLE, details: 'END' } );

            var consFld = form.addField( {
                id: 'custpage_chkfld',
                type: NUI.FieldType.CHECKBOX,
                label: 'Ready for Consolidation',
                container: FLD_GRP_CLIENT_DETAILS
            } )
            if ( parms.cons == 'true' )
                consFld.defaultValue = 'T';
            else
                consFld.defaultValue = 'F';

        }

        function buildFormContractDetails ( form, parms ) {
            var LOG_TITLE = 'buildFormContractDetails';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var fld;

            // Contract Details (Group By)
            form.addFieldGroup( { id: FLD_GRP_CONTRACT_DETAILS, label: 'Contract Details (Group By)' } );

            fld = form.addField( {
                id: FLD_SL_GRP_BATCH_OPTION_1,
                type: NUI.FieldType.SELECT,
                label: 'Batch Option 1',
                source: CUSTOM_LIST_BATCH_OPTIONS,
                container: FLD_GRP_CONTRACT_DETAILS
            } );
            fld.defaultValue = parms.batOpt1;
            fld.updateDisplayType( {
                displayType: parms.isOverride == true ? NUI.FieldDisplayType.NORMAL : NUI.FieldDisplayType.DISABLED
            } );

            fld = form.addField( {
                id: FLD_SL_GRP_BATCH_OPTION_2,
                type: NUI.FieldType.SELECT,
                label: 'Batch Option 2',
                source: CUSTOM_LIST_BATCH_OPTIONS,
                container: FLD_GRP_CONTRACT_DETAILS
            } );
            fld.defaultValue = parms.batOpt2;
            fld.updateDisplayType( {
                displayType: parms.isOverride == true ? NUI.FieldDisplayType.NORMAL : NUI.FieldDisplayType.DISABLED
            } );

            fld = form.addField( {
                id: FLD_SL_GRP_BATCH_OPTION_3,
                type: NUI.FieldType.SELECT,
                label: 'Batch Option 3',
                source: CUSTOM_LIST_BATCH_OPTIONS,
                container: FLD_GRP_CONTRACT_DETAILS
            } );
            fld.defaultValue = parms.batOpt3;
            fld.updateDisplayType( {
                displayType: parms.isOverride == true ? NUI.FieldDisplayType.NORMAL : NUI.FieldDisplayType.DISABLED
            } );

            fld = form.addField( {
                id: FLD_SL_GRP_BATCH_OPTION_4,
                type: NUI.FieldType.SELECT,
                label: 'Batch Option 4',
                source: CUSTOM_LIST_BATCH_OPTIONS,
                container: FLD_GRP_CONTRACT_DETAILS
            } );
            fld.defaultValue = parms.batOpt4;
            fld.updateDisplayType( {
                displayType: parms.isOverride == true ? NUI.FieldDisplayType.NORMAL : NUI.FieldDisplayType.DISABLED
            } );

            NLOG.debug( { title: LOG_TITLE, details: 'isOverride = ' + parms.isOverride } );
            form.addField( {
                id: FLD_SL_GRP_OVERRIDE,
                type: NUI.FieldType.CHECKBOX,
                label: 'Override',
                container: FLD_GRP_CONTRACT_DETAILS
            } ).defaultValue = parms.isOverride == true ? 'T' : 'F';// == 'T';

            NLOG.debug( { title: LOG_TITLE, details: 'START' } );
        }

        function buildFormSummaryDetails ( form, parms ) {
            var LOG_TITLE = 'buildFormSummaryDetails';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var fld;

            // Summary Details
            form.addFieldGroup( { id: FLD_GRP_SUMMARY_DETAILS, label: 'Summary Details' } );

            form.addField( {
                id: FLD_SL_GRP_INV_AVAIL_CONSOL,
                type: NUI.FieldType.INTEGER,
                label: 'Invoices Available for Consolidation',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.DISABLED } );

            form.addField( {
                id: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL,
                type: NUI.FieldType.INTEGER,
                label: 'Invoice Lines Available for Consolidation',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.DISABLED } );

            form.addField( {
                id: FLD_SL_GRP_TOT_CI_TO_CREATE,
                type: NUI.FieldType.INTEGER,
                label: 'Total CI to Create',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.DISABLED } );

            form.addField( {
                id: FLD_SL_GRP_TOT_CI_AMT,
                type: NUI.FieldType.CURRENCY,
                label: 'Total CI Amount',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.DISABLED } );

            form.addField( {
                id: FLD_SL_GRP_TOT_CI_INVOICES,
                type: NUI.FieldType.INTEGER,
                label: 'Total No of Invoices',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );

            form.addField( {
                id: FLD_SL_GRP_TRANSACTION_LINKS,
                type: NUI.FieldType.MULTISELECT,
                label: 'Transaction Links',
                source: 'transaction',
                container: FLD_GRP_SUMMARY_DETAILS
            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );

            var script = NRUNTIME.getCurrentScript();
            fld = form.addField( {
                id: FLD_CREATE_CLIENT_CI_SL,
                type: NUI.FieldType.TEXT,
                label: 'Suitelet URL',
                container: FLD_GRP_SUMMARY_DETAILS
            } );
            fld.defaultValue = NURL.resolveScript( {
                scriptId: script.id,
                deploymentId: script.deploymentId
            } );
            fld.updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );

            NLOG.debug( { title: LOG_TITLE, details: 'END' } );
        }

        function buildFormFields ( form, parms ) {
            var LOG_TITLE = 'buildFormFields';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            buildFormClientDetails( form, parms );
            buildFormContractDetails( form, parms );
            buildFormSummaryDetails( form, parms );

            //sublist  11/28/2020
            buildFormSublist( form, parms );

            NLOG.debug( { title: LOG_TITLE, details: 'END' } );
        }

        function buildFormSublist ( form, parms ) {
            var LOG_TITLE = 'buildFormSublist';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );
            var applyFilters = parms.applyFilters;
            var clientFlt = parms.clientFlt;
            var subsiFlt = parms.subsiFlt;
            var medSegFlt = parms.medSegFlt;
            var lobFlt = parms.lobFlt;
            var currFlt = parms.currFlt;
            var contractFlt = parms.contractFlt;
            var pubMedSupFlt = parms.pubMedSupFlt;
            var vendFlt = parms.vendFlt;
            var transTypeFlt = parms.transTypeFlt;
            var dtFrmFlt = parms.dtFrmFlt;
            var dtToFlt = parms.dtToFlt;
            var schedProjFlt = parms.schedProjFlt;
            var billMnthFlt = parms.billMnthFlt;
            var adjustInvFlt = parms.adjustInvFlt;
            var plcmntStr1Flt = parms.plcmntStr1Flt;
            var plcmntStr2Flt = parms.plcmntStr2Flt;
            var plcmntStr3Flt = parms.plcmntStr3Flt;
            var plcmntStr4Flt = parms.plcmntStr4Flt;
            var plcmntStr5Flt = parms.plcmntStr5Flt;
            var plcmntStr6Flt = parms.plcmntStr6Flt;
            var applyFilters = parms.applyFilters;
            var consolidateFlt = parms.cons;
            var batOpt1 = parms.batOpt1;
            var batOpt2 = parms.batOpt2;
            var batOpt3 = parms.batOpt3;
            var batOpt4 = parms.batOpt4;
            var isOverride = parms.isOverride;
            var script = NRUNTIME.getCurrentScript();

            var invLinesConsolSS = script.getParameter( { name: SPARAM_APPF_INV_LINES_FOR_CONSOL_SS } );
            var invLinesConsolSSObj = NSEARCH.load( { id: invLinesConsolSS } );
            var srchFilters = invLinesConsolSSObj.filters;
            var srchColumns = invLinesConsolSSObj.columns;
            var srchType = invLinesConsolSSObj.searchType;




            var invLinesAvailConsol = form.getField( {
                id: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL
            } );
            var invAvailConsol = form.getField( {
                id: FLD_SL_GRP_INV_AVAIL_CONSOL
            } );


            //11/27/2020
            if ( applyFilters == 'T' || applyFilters == 'true' || applyFilters == 'true' ) {
                //var invDetailsSublist = form.addSubList(SUBLIST_SL_INV_DETAILS, 'list', 'Invoice Details (Results)');
                //invDetailsSublist.addButton(BTN_SL_MARK_ALL, 'Mark All', 'markAll();');
                //invDetailsSublist.addButton(BTN_SL_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
                var invDetailsSublist = form.addSublist( {
                    id: SUBLIST_SL_INV_DETAILS,
                    type: NUI.SublistType.LIST,
                    label: 'Invoice Details (Results)'
                } );

                //invDetailsSublist.addButton(BTN_SL_MARK_ALL, 'Mark All', 'markAll();');
                // invDetailsSublist.addButton(BTN_SL_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
                invDetailsSublist.addButton( {
                    id: BTN_SL_MARK_ALL,
                    label: 'Mark All',
                    functionName: 'markAll();'
                } );
                invDetailsSublist.addButton( {
                    id: BTN_SL_UNMARK_ALL,
                    label: 'Unmark All',
                    functionName: 'unmarkAll();'
                } );

                /*var fldSelect = oSblSalesOrders.addField({
                    id: FLD_SO_SELECT,
                    type: ui.FieldType.CHECKBOX,
                    label: 'Select'
                });*/

                if ( invLinesConsolSS != null && invLinesConsolSS != '' ) {
                    var searchObj = NSEARCH.create( { type: srchType, filters: null, columns: null } );
                    log.debug( 'searchObj1', searchObj );
                    //invDetailsSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
                    invDetailsSublist.addField( {
                        id: FLD_COL_SL_SELECT,
                        type: NUI.FieldType.CHECKBOX,
                        label: 'Select'
                    } );
                    //invDetailsSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');
                    invDetailsSublist.addField( {
                        id: FLD_COL_SL_INTERNAL_ID,
                        type: NUI.FieldType.TEXT,
                        label: 'Select'
                    } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                    var formulaIndex = 1;
                    for ( var c = 0; c < srchColumns.length; c++ ) {
                        var col = srchColumns[ c ];
                        //var col = getName
                        var oCol = JSON.stringify( col ).split( ',' );
                        var oType = oCol[ 2 ].split( ':' );

                        log.debug( 'col details', JSON.stringify( col ) + ' col.label:' + col.label + ' col.type:' + col[ 'type' ] + ' oCol=' + oCol[ 2 ] + ' oType=' + oType[ 1 ] );
                        var colName = col.name;  //col.getName();
                        var colLabel = col.label; //col.getLabel();
                        if ( colName.indexOf( 'formula' ) != -1 ) {
                            colName = colName + '_' + formulaIndex;
                            formulaIndex++;
                        }
                        //var sublistLine = invDetailsSublist.addField('custpage_' + colName, 'text', colLabel);
                        var sublistLine = invDetailsSublist.addField( {
                            id: 'custpage_' + colName,
                            type: NUI.FieldType.TEXT,
                            label: colLabel
                        } );


                        if ( col.type == 'select' || oType[ 1 ] == '"select"' /*col.getType() == 'select'*/ )
                            //sublistLine = invDetailsSublist.addField('custpage_' + colName + '_id', 'text', colLabel + '_ID').setDisplayType('hidden');
                            sublistLine = invDetailsSublist.addField( {
                                id: 'custpage_' + colName + '_id',
                                type: NUI.FieldType.TEXT,
                                label: colLabel + '_ID'
                            } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                        if ( colName == 'line' )
                            // sublistLine.setDisplayType('hidden');
                            sublistLine.updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                    }
                    if ( batOpt1 != null && batOpt1 != '' ) {
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name, 'text', batchFieldsData(batOpt1).label);
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt1 ).name,
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt1 ).label
                        } );
                        // invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name + '_id', 'text', batchFieldsData(batOpt1).label + '_ID').setDisplayType('hidden');
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt1 ).name + '_id',
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt1 ).label + '_ID'
                        } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );

                    }
                    if ( batOpt2 != null && batOpt2 != '' ) {
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name, 'text', batchFieldsData(batOpt2).label);
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt2 ).name,
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt2 ).label
                        } );
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name + '_id', 'text', batchFieldsData(batOpt2).label + '_ID').setDisplayType('hidden');
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt2 ).name + '_id',
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt2 ).label + '_ID'
                        } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                        //nlapiLogExecution('debug', 'batch 2 column field name', 'custpage_' + batchFieldsData(batOpt2).name);
                        //nlapiLogExecution('debug', 'batch 2 column field id', 'custpage_' + batchFieldsData(batOpt2).name + '_id');
                    }
                    if ( batOpt3 != null && batOpt3 != '' ) {
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name, 'text', batchFieldsData(batOpt3).label);
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt3 ).name,
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt3 ).label
                        } );
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name + '_id', 'text', batchFieldsData(batOpt3).label + '_ID').setDisplayType('hidden');
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt3 ).name + '_id',
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt3 ).label + '_ID'
                        } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                    }
                    if ( batOpt4 != null && batOpt4 != '' ) {
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name, 'text', batchFieldsData(batOpt4).label);
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt4 ).name,
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt4 ).label
                        } );
                        //invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name + '_id', 'text', batchFieldsData(batOpt4).label + '_ID').setDisplayType('hidden');
                        invDetailsSublist.addField( {
                            id: 'custpage_' + batchFieldsData( batOpt4 ).name + '_id',
                            type: NUI.FieldType.TEXT,
                            label: batchFieldsData( batOpt4 ).label + '_ID'
                        } ).updateDisplayType( { displayType: NUI.FieldDisplayType.HIDDEN } );
                    }
                    var filters = [];
                    log.debug( 'clientFlt', clientFlt );
                    log.debug( 'consolidateFlt', consolidateFlt );

                    if ( clientFlt != null && clientFlt != '' ) {
                        //filters.push(new nlobjSearchFilter('mainname', null, 'anyof', clientFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'mainname',
                            operator: NSEARCH.Operator.ANYOF,
                            values: clientFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                        //searchObj.filters.push(oProjManager);
                        //NLOG.debug('mainname',mainname   + ' filters='+ JSON.stringify(filters));
                        NLOG.debug( { title: 'mainname', details: ' filters=' + JSON.stringify( filters ) } );
                    }
                    if ( subsiFlt != null && subsiFlt != '' ) {
                        //filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsiFlt));
                        log.debug( 'subsiFlt', subsiFlt );
                        var oFilter = NSEARCH.createFilter( {
                            name: 'subsidiary',
                            operator: NSEARCH.Operator.ANYOF,
                            values: subsiFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( medSegFlt != null && medSegFlt != '' ) {
                        log.debug( 'medSegFlt', medSegFlt );
                        //filters.push(new nlobjSearchFilter(CUSTOM_SEGMENT_MEDIA, null, 'anyof', medSegFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: CUSTOM_SEGMENT_MEDIA,
                            operator: NSEARCH.Operator.ANYOF,
                            values: medSegFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }
                    if ( lobFlt != null && lobFlt != '' ) {
                        log.debug( 'lobFlt', lobFlt );
                        //filters.push(new nlobjSearchFilter('class', null, 'anyof', lobFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'class',
                            operator: NSEARCH.Operator.ANYOF,
                            values: lobFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( currFlt != null && currFlt != '' ) {
                        //filters.push(new nlobjSearchFilter('currency', null, 'anyof', currFlt));

                        var oFilter = NSEARCH.createFilter( {
                            name: 'currency',
                            operator: NSEARCH.Operator.ANYOF,
                            values: currFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( contractFlt != null && contractFlt != '' ) {
                        //.push(new nlobjSearchFilter(FLD_CONTRACT, null, 'anyof', contractFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_CONTRACT,
                            operator: NSEARCH.Operator.ANYOF,
                            values: contractFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }
                    if ( consolidateFlt == 'true' ) {
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_CONSOLIDATED,
                            operator: NSEARCH.Operator.IS,
                            values: true
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter )
                    }

                    if ( pubMedSupFlt != null && pubMedSupFlt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_PUBLISHER, null, 'anyof', pubMedSupFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_PUBLISHER,
                            operator: NSEARCH.Operator.ANYOF,
                            values: pubMedSupFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }


                    if ( vendFlt != null && vendFlt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_VENDOR_NAME, null, 'anyof', vendFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_VENDOR_NAME,
                            operator: NSEARCH.Operator.ANYOF,
                            values: vendFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( transTypeFlt != null && transTypeFlt != '' ) {
                        //filters.push(new nlobjSearchFilter('type', null, 'anyof', transTypeFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'type',
                            operator: NSEARCH.Operator.ANYOF,
                            values: transTypeFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( dtFrmFlt != null && dtFrmFlt != '' && dtToFlt != null && dtToFlt != '' ) {
                        //filters.push(new nlobjSearchFilter('trandate', null, 'within', dtFrmFlt, dtToFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'trandate',
                            operator: NSEARCH.Operator.WITHIN,
                            values: [ dtFrmFlt, dtToFlt ]
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );

                    }

                    if ( dtFrmFlt != null && dtFrmFlt != '' && ( dtToFlt == null || dtToFlt == '' ) ) {
                        //filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', dtFrmFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'trandate',
                            operator: NSEARCH.Operator.ONORAFTER,
                            values: dtFrmFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( ( dtFrmFlt == null || dtFrmFlt == '' ) && dtToFlt != null && dtToFlt != '' ) {
                        //.push(new nlobjSearchFilter('trandate', null, 'onorbefore', dtToFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'trandate',
                            operator: NSEARCH.Operator.ONORBEFORE,
                            values: dtToFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( schedProjFlt != null && schedProjFlt != '' ) {
                        //.push(new nlobjSearchFilter('internalid', 'job', 'anyof', schedProjFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: 'internalid',
                            join: 'job',
                            operator: NSEARCH.Operator.ANYOF,
                            values: schedProjFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );

                    }

                    if ( billMnthFlt != null && billMnthFlt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_BILL_MONTH, null, 'contains', billMnthFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_BILL_MONTH,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: billMnthFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( adjustInvFlt != null && adjustInvFlt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_ADJUSTMENT_INVOICE, null, 'is', adjustInvFlt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_ADJUSTMENT_INVOICE,
                            operator: NSEARCH.Operator.IS,
                            values: adjustInvFlt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr1Flt != null && plcmntStr1Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_1, null, 'contains', plcmntStr1Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_1,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr1Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr2Flt != null && plcmntStr2Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_2, null, 'contains', plcmntStr2Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_2,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr2Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr3Flt != null && plcmntStr3Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_3, null, 'contains', plcmntStr3Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_3,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr3Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr4Flt != null && plcmntStr4Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_4, null, 'contains', plcmntStr4Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_4,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr4Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr5Flt != null && plcmntStr5Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_5, null, 'contains', plcmntStr5Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_5,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr5Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    if ( plcmntStr6Flt != null && plcmntStr6Flt != '' ) {
                        //filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_6, null, 'contains', plcmntStr6Flt));
                        var oFilter = NSEARCH.createFilter( {
                            name: FLD_COL_PLACEMENT_STRING_6,
                            operator: NSEARCH.Operator.CONTAINS,
                            values: plcmntStr6Flt
                        } );
                        filters.push( oFilter );
                        searchObj.filters.push( oFilter );
                    }

                    NLOG.debug( { title: LOG_TITLE, details: JSON.stringify( srchFilters ) } );
                    NLOG.debug( { title: LOG_TITLE, details: JSON.stringify( filters ) } );
                    filters = filters.concat( srchFilters );
                    NLOG.debug( { title: LOG_TITLE, details: JSON.stringify( filters ) } );
                    var columns = [];
                    if ( batOpt1 != null && batOpt1 != '' ) {
                        //columns.push(new nlobjSearchColumn(batchFieldsData(batOpt1).name));
                        var oColumn = NSEARCH.createColumn( {
                            name: batchFieldsData( batOpt1 ).name
                        } );
                        columns.push( oColumn );
                        //searchObj.columns.push(oColumn);
                    }

                    if ( batOpt2 != null && batOpt2 != '' ) {
                        //columns.push(new nlobjSearchColumn(batchFieldsData(batOpt2).name));
                        var oColumn = NSEARCH.createColumn( {
                            name: batchFieldsData( batOpt2 ).name
                        } );
                        columns.push( oColumn );
                        //searchObj.columns.push(oColumn);
                    }

                    if ( batOpt3 != null && batOpt3 != '' ) {
                        //columns.push(new nlobjSearchColumn(batchFieldsData(batOpt3).name));
                        var oColumn = NSEARCH.createColumn( {
                            name: batchFieldsData( batOpt3 ).name
                        } );
                        columns.push( oColumn );
                        //searchObj.columns.push(oColumn);
                    }

                    if ( batOpt4 != null && batOpt4 != '' ) {
                        //columns.push(new nlobjSearchColumn(batchFieldsData(batOpt4).name));
                        var oColumn = NSEARCH.createColumn( {
                            name: batchFieldsData( batOpt4 ).name
                        } );
                        columns.push( oColumn );
                        //searchObj.columns.push(oColumn);
                    }

                    columns = columns.concat( srchColumns );
                    NLOG.debug( { title: LOG_TITLE, details: JSON.stringify( columns ) } );
                    //NLOG.debug({ title: LOG_TITLE, details: JSON.stringify(filters) });
                    //var invLinesConsolSSResults = getAllSearchResultsV2(searchObj);
                    var invLinesConsolSSResults = getAllSearchResults( srchType, filters, columns );
                    log.debug( 'invLinesConsolSSResults', invLinesConsolSSResults );
                    var pendingLines = getAllPendingLines();
                    if ( invLinesConsolSSResults != null && invLinesConsolSSResults != '' ) {
                        //invLinesAvailConsol.setDefaultValue(invLinesConsolSSResults.length);
                        invLinesAvailConsol.defaultValue = invLinesConsolSSResults.length;
                        var totalInvoices = [];
                        var r = -1;
                        for ( var rx = 0, rl = invLinesConsolSSResults.length; rx < rl; rx++ ) {
                            var result = invLinesConsolSSResults[ rx ];
                            //var lineID = result.getValue(FLD_COL_INVOICE_LINE_ID);
                            var lineID = result.getValue( { name: FLD_COL_INVOICE_LINE_ID } );
                            var sDocNo = result.getValue( { name: 'tranid' } );
                            var sTransactionType = result.getValue( { name: 'type' } );
                            var lineNo = result.getValue( { name: 'line' } );
                            log.debug( 'sTransactionType', sTransactionType + 'sDocNo = ' + sDocNo + ' lineNo = ' + lineNo );
                            log.debug( 'createClientCISuitelet', 'lineID = ' + lineID );

                            //check transaction type invoice/credit memo
                            if ( sTransactionType == 'invoice' ) {
                                if ( pendingLines.indexOf( lineID ) >= 0 ) {
                                    log.debug( 'lineID = ' + lineID, 'Skipping line...' );
                                    continue;
                                }
                            } else {
                                var cmLineID = sDocNo + '_' + lineNo;
                                log.debug( 'cmLineID', cmLineID );
                                if ( pendingLines.indexOf( cmLineID ) >= 0 ) {
                                    log.debug( 'lineID = ' + lineID, 'Skipping line...' );
                                    continue;
                                }

                            }

                            var recId = result.id; // result.getId();
                            var recType = result.recordType;   //result.getRecordType();
                            if ( totalInvoices.indexOf( recId ) == -1 ) {
                                totalInvoices.push( recId );
                            }
                            //invDetailsSublist.setLineItemValue(FLD_COL_SL_INTERNAL_ID, r + 1, recId);
                            invDetailsSublist.setSublistValue( {
                                id: FLD_COL_SL_INTERNAL_ID,
                                line: r + 1,
                                value: recId
                            } );

                            var formulaIndex = 1;
                            for ( var c = 0; c < srchColumns.length; c++ ) {
                                var col = srchColumns[ c ];
                                //var colName = col.getName();
                                //var colLabel = col.getLabel();
                                //var colVal = result.getValue(col);

                                var colName = col.name;  //col.getName();
                                var colLabel = col.label; //col.getLabel();
                                var colVal = result.getValue( { name: col } ) || '';
                                //log.debug('colName', colName + ' colVal',colVal);

                                var oCol = JSON.stringify( col ).split( ',' );
                                var oType = oCol[ 2 ].split( ':' );


                                if ( colName.indexOf( 'formula' ) != -1 ) {
                                    colName = colName + '_' + formulaIndex;
                                    formulaIndex++;
                                }
                                if ( col.type == 'select' || oType[ 1 ] == '"select"' /*col.getType() == 'select'*/ ) {
                                    //invDetailsSublist.setLineItemValue('custpage_' + colName + '_id', r + 1, colVal);

                                    //colVal = result.getText(col);
                                    colVal = result.getText( {
                                        name: col
                                    } );
                                    invDetailsSublist.setSublistValue( {
                                        id: 'custpage_' + colName + '_id',
                                        line: r + 1,
                                        value: result.getValue( { name: col } ) /*colVal*/
                                    } );
                                }
                                if ( colName == 'tranid' ) {
                                    //var url = nlapiResolveURL('RECORD', recType, recId);
                                    var url = NURL.resolveRecord( {
                                        recordType: recType,
                                        recordId: recId,
                                        isEditMode: false
                                    } );
                                    colVal = '<a href=' + url + ' target="_blank">' + colVal + '</a>';

                                }
                                //invDetailsSublist.setLineItemValue('custpage_' + colName, r + 1, colVal);
                                if ( colVal != null && colVal != '' ) {
                                    invDetailsSublist.setSublistValue( {
                                        id: 'custpage_' + colName,
                                        line: r + 1,
                                        value: colVal
                                    } );
                                }

                            }
                            if ( batOpt1 != null && batOpt1 != '' && ( result.getValue( batchFieldsData( batOpt1 ).name ) != null && result.getValue( batchFieldsData( batOpt1 ).name ) != '' ) ) {
                                if ( batchFieldsData( batOpt1 ).issel ) {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getText(batchFieldsData(batOpt1).name));
                                    if ( result.getText( batchFieldsData( batOpt1 ).name ) ) {
                                        invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt1 ).name, line: r + 1, value: result.getText( batchFieldsData( batOpt1 ).name ) } );
                                    }

                                }

                                else {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getValue(batchFieldsData(batOpt1).name));
                                    if ( result.getValue( batchFieldsData( batOpt1 ).name ) != null && result.getValue( batchFieldsData( batOpt1 ).name ) != '' ) {
                                        invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt1 ).name, line: r + 1, value: result.getValue( batchFieldsData( batOpt1 ).name ) } );
                                    }

                                }

                                //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt1).name));
                                if ( result.getValue( batchFieldsData( batOpt1 ).name ) ) {
                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt1 ).name + '_id', line: r + 1, value: result.getValue( batchFieldsData( batOpt1 ).name ) } );

                                }

                            }
                            if ( batOpt2 != null && batOpt2 != '' && ( result.getValue( batchFieldsData( batOpt2 ).name ) != null && result.getValue( batchFieldsData( batOpt2 ).name ) != '' ) ) {
                                if ( batchFieldsData( batOpt2 ).issel ) {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getText(batchFieldsData(batOpt2).name));

                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt2 ).name, line: r + 1, value: result.getText( batchFieldsData( batOpt2 ).name ) } );

                                }
                                else {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getValue(batchFieldsData(batOpt2).name));

                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt2 ).name, line: r + 1, value: result.getValue( batchFieldsData( batOpt2 ).name ) } );

                                }

                                //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt2).name));
                                invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt2 ).name + '_id', line: r + 1, value: result.getValue( batchFieldsData( batOpt2 ).name ) } );

                            }
                            if ( batOpt3 != null && batOpt3 != '' && ( result.getValue( batchFieldsData( batOpt3 ).name ) != null && result.getValue( batchFieldsData( batOpt3 ).name ) != '' ) ) {
                                if ( batchFieldsData( batOpt3 ).issel ) {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getText(batchFieldsData(batOpt3).name));
                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt3 ).name, line: r + 1, value: result.getText( batchFieldsData( batOpt3 ).name ) } );

                                }

                                else {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getValue(batchFieldsData(batOpt3).name));
                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt3 ).name, line: r + 1, value: result.getValue( batchFieldsData( batOpt3 ).name ) } );
                                }

                                //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt3).name));
                                invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt3 ).name + '_id', line: r + 1, value: result.getValue( batchFieldsData( batOpt3 ).name ) } );

                            }
                            if ( batOpt4 != null && batOpt4 != '' && ( result.getValue( batchFieldsData( batOpt4 ).name ) != null && result.getValue( batchFieldsData( batOpt4 ).name ) != '' ) ) {
                                if ( batchFieldsData( batOpt4 ).issel ) {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getText(batchFieldsData(batOpt4).name));
                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt4 ).name, line: r + 1, value: result.getText( batchFieldsData( batOpt4 ).name ) } );
                                }

                                else {
                                    //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getValue(batchFieldsData(batOpt4).name));
                                    invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt4 ).name, line: r + 1, value: result.getValue( batchFieldsData( batOpt4 ).name ) } );
                                }

                                //invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt4).name));
                                invDetailsSublist.setSublistValue( { id: 'custpage_' + batchFieldsData( batOpt4 ).name + '_id', line: r + 1, value: result.getValue( batchFieldsData( batOpt4 ).name ) } );


                            }
                            r++;
                        }
                        if ( totalInvoices != null && totalInvoices != '' ) {
                            //invAvailConsol.setDefaultValue(totalInvoices.length);
                            invAvailConsol.defaultValue = totalInvoices.length;
                        }

                    }
                }




            }

            NLOG.debug( { title: LOG_TITLE, details: 'END' } );
        }

        // function createClientCISuitelet(request, response) {
        function onRequest ( params ) {
            var LOG_TITLE = 'onRequest';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var script = NRUNTIME.getCurrentScript();
            var invLinesConsolSS = script.getParameter( { name: SPARAM_APPF_INV_LINES_FOR_CONSOL_SS } );
            var invLinesConsolSSObj = NSEARCH.load( { id: invLinesConsolSS } );
            var srchFilters = invLinesConsolSSObj.filters;
            var srchColumns = invLinesConsolSSObj.columns;
            var srchType = invLinesConsolSSObj.searchType;

            var request = params.request;
            if ( request.method == NHTTP.Method.GET ) {
                try {
                    var form = NUI.createForm( { title: 'Consolidate Client Invoices' } );
                    // form.setScript(SCRIPT_CREATE_CLIENT_CI_VALIDATIONS);
                    form.clientScriptModulePath = SCRIPT_CREATE_CLIENT_CI_V2;
                    form.addButton( {
                        id: BTN_SL_APPLY_FILTERS,
                        label: 'Apply Filters',
                        functionName: 'applyFilters();'
                    } );
                    form.addSubmitButton( { label: 'Submit' } );

                    buildFormFields( form, request.parameters );


                    /*if (applyFilters == 'T') {   ==> separate function
                        var invDetailsSublist = form.addSubList(SUBLIST_SL_INV_DETAILS, 'list', 'Invoice Details (Results)');
                        invDetailsSublist.addButton(BTN_SL_MARK_ALL, 'Mark All', 'markAll();');
                        invDetailsSublist.addButton(BTN_SL_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
                        if (invLinesConsolSS != null && invLinesConsolSS != '') {
                            invDetailsSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
                            invDetailsSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');
                            var formulaIndex = 1;
                            for (var c = 0; c < srchColumns.length; c++) {
                                var col = srchColumns[c];
                                var colName = col.getName();
                                var colLabel = col.getLabel();
                                if (colName.indexOf('formula') != -1) {
                                    colName = colName + '_' + formulaIndex;
                                    formulaIndex++;
                                }
                                var sublistLine = invDetailsSublist.addField('custpage_' + colName, 'text', colLabel);
                                if (col.getType() == 'select')
                                    sublistLine = invDetailsSublist.addField('custpage_' + colName + '_id', 'text', colLabel + '_ID').setDisplayType('hidden');
                                if (colName == 'line')
                                    sublistLine.setDisplayType('hidden');
                            }
                            if (batOpt1 != null && batOpt1 != '') {
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name, 'text', batchFieldsData(batOpt1).label);
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name + '_id', 'text', batchFieldsData(batOpt1).label + '_ID').setDisplayType('hidden');
                            }
                            if (batOpt2 != null && batOpt2 != '') {
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name, 'text', batchFieldsData(batOpt2).label);
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name + '_id', 'text', batchFieldsData(batOpt2).label + '_ID').setDisplayType('hidden');
                                nlapiLogExecution('debug', 'batch 2 column field name', 'custpage_' + batchFieldsData(batOpt2).name);
                                nlapiLogExecution('debug', 'batch 2 column field id', 'custpage_' + batchFieldsData(batOpt2).name + '_id');
                            }
                            if (batOpt3 != null && batOpt3 != '') {
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name, 'text', batchFieldsData(batOpt3).label);
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name + '_id', 'text', batchFieldsData(batOpt3).label + '_ID').setDisplayType('hidden');
                            }
                            if (batOpt4 != null && batOpt4 != '') {
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name, 'text', batchFieldsData(batOpt4).label);
                                invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name + '_id', 'text', batchFieldsData(batOpt4).label + '_ID').setDisplayType('hidden');
                            }
                            var filters = [];
                            if (clientFlt != null && clientFlt != '')
                                filters.push(new nlobjSearchFilter('mainname', null, 'anyof', clientFlt));
                            if (subsiFlt != null && subsiFlt != '')
                                filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsiFlt));
                            if (medSegFlt != null && medSegFlt != '')
                                filters.push(new nlobjSearchFilter(CUSTOM_SEGMENT_MEDIA, null, 'anyof', medSegFlt));
                            if (lobFlt != null && lobFlt != '')
                                filters.push(new nlobjSearchFilter('class', null, 'anyof', lobFlt));
                            if (currFlt != null && currFlt != '')
                                filters.push(new nlobjSearchFilter('currency', null, 'anyof', currFlt));
                            if (contractFlt != null && contractFlt != '')
                                filters.push(new nlobjSearchFilter(FLD_CONTRACT, null, 'anyof', contractFlt));
                            if (pubMedSupFlt != null && pubMedSupFlt != '')
                                filters.push(new nlobjSearchFilter(FLD_PUBLISHER, null, 'anyof', pubMedSupFlt));
                            if (vendFlt != null && vendFlt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_VENDOR_NAME, null, 'anyof', vendFlt));
                            if (transTypeFlt != null && transTypeFlt != '')
                                filters.push(new nlobjSearchFilter('type', null, 'anyof', transTypeFlt));
                            if (dtFrmFlt != null && dtFrmFlt != '' && dtToFlt != null && dtToFlt != '')
                                filters.push(new nlobjSearchFilter('trandate', null, 'within', dtFrmFlt, dtToFlt));
                            if (dtFrmFlt != null && dtFrmFlt != '' && (dtToFlt == null || dtToFlt == ''))
                                filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', dtFrmFlt));
                            if ((dtFrmFlt == null || dtFrmFlt == '') && dtToFlt != null && dtToFlt != '')
                                filters.push(new nlobjSearchFilter('trandate', null, 'onorbefore', dtToFlt));
                            if (schedProjFlt != null && schedProjFlt != '')
                                filters.push(new nlobjSearchFilter('internalid', 'job', 'anyof', schedProjFlt));
                            if (billMnthFlt != null && billMnthFlt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_BILL_MONTH, null, 'contains', billMnthFlt));
                            if (adjustInvFlt != null && adjustInvFlt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_ADJUSTMENT_INVOICE, null, 'is', adjustInvFlt));
                            if (plcmntStr1Flt != null && plcmntStr1Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_1, null, 'contains', plcmntStr1Flt));
                            if (plcmntStr2Flt != null && plcmntStr2Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_2, null, 'contains', plcmntStr2Flt));
                            if (plcmntStr3Flt != null && plcmntStr3Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_3, null, 'contains', plcmntStr3Flt));
                            if (plcmntStr4Flt != null && plcmntStr4Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_4, null, 'contains', plcmntStr4Flt));
                            if (plcmntStr5Flt != null && plcmntStr5Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_5, null, 'contains', plcmntStr5Flt));
                            if (plcmntStr6Flt != null && plcmntStr6Flt != '')
                                filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_6, null, 'contains', plcmntStr6Flt));
                            filters = filters.concat(srchFilters);
                            var columns = [];
                            if (batOpt1 != null && batOpt1 != '')
                                columns.push(new nlobjSearchColumn(batchFieldsData(batOpt1).name));
                            if (batOpt2 != null && batOpt2 != '')
                                columns.push(new nlobjSearchColumn(batchFieldsData(batOpt2).name));
                            if (batOpt3 != null && batOpt3 != '')
                                columns.push(new nlobjSearchColumn(batchFieldsData(batOpt3).name));
                            if (batOpt4 != null && batOpt4 != '')
                                columns.push(new nlobjSearchColumn(batchFieldsData(batOpt4).name));
                            columns = columns.concat(srchColumns);
                            var invLinesConsolSSResults = getAllSearchResults(srchType, filters, columns);
                            nlapiLogExecution('debug', 'invLinesConsolSSResults', invLinesConsolSSResults);
                            var pendingLines = getAllPendingLines();
                            if (invLinesConsolSSResults != null && invLinesConsolSSResults != '') {
                                invLinesAvailConsol.setDefaultValue(invLinesConsolSSResults.length);
                                var totalInvoices = [];
                                var r = 0;
                                for (var rx = 0, rl = invLinesConsolSSResults.length; rx < rl; rx++) {
                                    var result = invLinesConsolSSResults[rx];
                                    var lineID = result.getValue(FLD_COL_INVOICE_LINE_ID);
                                    nlapiLogExecution('DEBUG', 'createClientCISuitelet', 'lineID = ' + lineID);
                                    if (pendingLines.indexOf(lineID) >= 0) {
                                        nlapiLogExecution('DEBUG', 'lineID = ' + lineID, 'Skipping line...');
                                        continue;
                                    }
                                    var recId = result.getId();
                                    var recType = result.getRecordType();
                                    if (totalInvoices.indexOf(recId) == -1) {
                                        totalInvoices.push(recId);
                                    }
                                    invDetailsSublist.setLineItemValue(FLD_COL_SL_INTERNAL_ID, r + 1, recId);
                                    var formulaIndex = 1;
                                    for (var c = 0; c < srchColumns.length; c++) {
                                        var col = srchColumns[c];
                                        var colName = col.getName();
                                        var colLabel = col.getLabel();
                                        var colVal = result.getValue(col);
                                        if (colName.indexOf('formula') != -1) {
                                            colName = colName + '_' + formulaIndex;
                                            formulaIndex++;
                                        }
                                        if (col.getType() == 'select') {
                                            invDetailsSublist.setLineItemValue('custpage_' + colName + '_id', r + 1, colVal);
                                            colVal = result.getText(col);
                                        }
                                        if (colName == 'tranid') {
                                            var url = nlapiResolveURL('RECORD', recType, recId);
                                            colVal = '<a href=' + url + ' target="_blank">' + colVal + '</a>';
                                        }
                                        invDetailsSublist.setLineItemValue('custpage_' + colName, r + 1, colVal);
                                    }
                                    if (batOpt1 != null && batOpt1 != '') {
                                        if (batchFieldsData(batOpt1).issel)
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getText(batchFieldsData(batOpt1).name));
                                        else
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getValue(batchFieldsData(batOpt1).name));
                                        invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt1).name));
                                    }
                                    if (batOpt2 != null && batOpt2 != '') {
                                        if (batchFieldsData(batOpt2).issel)
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getText(batchFieldsData(batOpt2).name));
                                        else
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getValue(batchFieldsData(batOpt2).name));
                                        invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt2).name));
                                    }
                                    if (batOpt3 != null && batOpt3 != '') {
                                        if (batchFieldsData(batOpt3).issel)
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getText(batchFieldsData(batOpt3).name));
                                        else
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getValue(batchFieldsData(batOpt3).name));
                                        invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt3).name));
                                    }
                                    if (batOpt4 != null && batOpt4 != '') {
                                        if (batchFieldsData(batOpt4).issel)
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getText(batchFieldsData(batOpt4).name));
                                        else
                                            invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getValue(batchFieldsData(batOpt4).name));
                                        invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt4).name));
                                    }
                                    r++;
                                }
                                if (totalInvoices != null && totalInvoices != '')
                                    invAvailConsol.setDefaultValue(totalInvoices.length);
                            }
                        }
                    } */
                    params.response.writePage( form );
                }
                catch ( e ) {
                    NLOG.error( {
                        title: LOG_TITLE,
                        details: JSON.stringify( e )
                    } );
                }
            }
            else {
                try {
                    var batOpt1 = request.parameters[ FLD_SL_GRP_BATCH_OPTION_1 ];  //request.getParameter(FLD_SL_GRP_BATCH_OPTION_1);
                    var batOpt2 = request.parameters[ FLD_SL_GRP_BATCH_OPTION_2 ];
                    var batOpt3 = request.parameters[ FLD_SL_GRP_BATCH_OPTION_3 ];
                    var batOpt4 = request.parameters[ FLD_SL_GRP_BATCH_OPTION_4 ];
                    var totInvselected = request.parameters[ FLD_SL_GRP_TOT_CI_INVOICES ];
                    var totCItoCreate = request.parameters[ FLD_SL_GRP_TOT_CI_TO_CREATE ];
                    var transactionLinks = request.parameters[ FLD_SL_GRP_TRANSACTION_LINKS ]; //request.getParameterValues(FLD_SL_GRP_TRANSACTION_LINKS);
                    log.debug( 'transactionLinks', transactionLinks );
                    //var lineCount = request.getLineItemCount(SUBLIST_SL_INV_DETAILS);
                    var lineCount = request.getLineCount( {
                        group: SUBLIST_SL_INV_DETAILS
                    } );
                    if ( lineCount > 0 ) {
                        var selectedLinesData = '';
                        selectedLinesData += 'Internal ID,';
                        for ( var s1 = 0; s1 < srchColumns.length; s1++ ) {
                            var col = srchColumns[ s1 ];
                            selectedLinesData += col.label /*col.getLabel()*/ + ',';
                            var oCol = JSON.stringify( col ).split( ',' );
                            var oType = oCol[ 2 ].split( ':' );

                            if ( col.type == 'select' || oType[ 1 ] == '"select"' /*col.getType() == 'select'*/ )
                                selectedLinesData += col.label + '_ID,';
                        }
                        if ( batOpt1 != null && batOpt1 != '' ) {
                            selectedLinesData += batchFieldsData( batOpt1 ).label + ',';
                            selectedLinesData += batchFieldsData( batOpt1 ).label + '_ID,';
                        }
                        if ( batOpt2 != null && batOpt2 != '' ) {
                            selectedLinesData += batchFieldsData( batOpt2 ).label + ',';
                            selectedLinesData += batchFieldsData( batOpt2 ).label + '_ID,';
                        }
                        if ( batOpt3 != null && batOpt3 != '' ) {
                            selectedLinesData += batchFieldsData( batOpt3 ).label + ',';
                            selectedLinesData += batchFieldsData( batOpt3 ).label + '_ID,';
                        }
                        if ( batOpt4 != null && batOpt4 != '' ) {
                            selectedLinesData += batchFieldsData( batOpt4 ).label + ',';
                            selectedLinesData += batchFieldsData( batOpt4 ).label + '_ID,';
                        }
                        selectedLinesData = selectedLinesData.slice( 0, -1 ) + '\n';
                        var ssColumns = 1;
                        for ( var s1 = 0; s1 < srchColumns.length; s1++ ) {
                            ssColumns++;
                            log.debug( 'srchColumns[s1].type', srchColumns[ s1 ].type );
                            var oCol = JSON.stringify( srchColumns[ s1 ] ).split( ',' );
                            var oType = oCol[ 2 ].split( ':' );
                            if ( srchColumns[ s1 ].type == 'select' || oType[ 1 ] == '"select"' /*srchColumns[s1].getType() == 'select'*/ ) {
                                ssColumns++;
                            }
                        }
                        var selectedRecords = [];
                        var selectedRecordID = [];
                        for ( var c = 0; c < lineCount; c++ ) {
                            //var selected = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c);
                            var selected = request.getSublistValue( {
                                group: SUBLIST_SL_INV_DETAILS,
                                name: FLD_COL_SL_SELECT,
                                line: c
                            } );
                            if ( selected == 'T' || selected == true ) {
                                //var client = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + FLD_CONTRACT, c);
                                var client = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: 'custpage_' + FLD_CONTRACT,
                                    line: c
                                } );
                                //var internalId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_INTERNAL_ID, c);
                                var internalId = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: FLD_COL_SL_INTERNAL_ID,
                                    line: c
                                } );

                                var lineCol = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: 'custpage_line',
                                    line: c
                                } );

                                var sRecType = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: 'custpage_type',
                                    line: c
                                } );

                                var sRecTypeID = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: 'custpage_type_id',
                                    line: c
                                } );

                                var sDocNo = request.getSublistValue( {
                                    group: SUBLIST_SL_INV_DETAILS,
                                    name: 'custpage_tranid',
                                    line: c
                                } );
                                var aDoc = sDocNo.split( '>' );
                                aDoc2 = aDoc[ 1 ].split( '<' );
                                sDocNo = aDoc2[ 0 ];
                                selectedLinesData += internalId + ',';
                                var formulaIndex = 1;
                                for ( var s1 = 0; s1 < srchColumns.length; s1++ ) {
                                    var col = srchColumns[ s1 ];
                                    var colName = col.name; //col.getName();
                                    if ( colName.indexOf( 'formula' ) != -1 ) {
                                        colName = colName + '_' + formulaIndex;
                                        formulaIndex++;
                                    }

                                    //var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                                    var colVal = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName,
                                        line: c
                                    } );
                                    log.debug( 'colName', colName + ' colVal=' + colVal + ' ' + ' lineCol = ' + lineCol + ' sRecType = ' + sRecType + ' sDocNo =' + sDocNo );

                                    if ( colVal != null && colVal != '' )
                                        colVal = colVal.replace( /,/g, '|' );
                                    selectedLinesData += colVal + ',';

                                    var oCol = JSON.stringify( col ).split( ',' );
                                    var oType = oCol[ 2 ].split( ':' );

                                    if ( col.type == 'select' || oType[ 1 ] == '"select"' /*col.getType() == 'select'*/ ) {
                                        //var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                        var colValId = request.getSublistValue( {
                                            group: SUBLIST_SL_INV_DETAILS,
                                            name: 'custpage_' + colName + '_id',
                                            line: c
                                        } );
                                        selectedLinesData += colValId + ',';
                                        log.debug( 'colName', colName + ' colValId=' + colValId + ' ' );
                                    }

                                    //check transaction type
                                    if ( colName == 'custcol_appf_invoice_line_id' ) {
                                        if ( colVal != null && colVal != '' ) {
                                            selectedRecordID.push( colVal );
                                        } else { //credit memo

                                            colVal = sDocNo + '_' + lineCol;

                                            selectedRecordID.push( colVal );
                                        }

                                    }
                                }
                                if ( batOpt1 != null && batOpt1 != '' ) {
                                    var colName = batchFieldsData( batOpt1 ).name;
                                    //var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                                    var colVal = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName,
                                        line: c
                                    } );
                                    if ( colVal != null && colVal != '' )
                                        colVal = colVal.replace( /,/g, '|' );
                                    //var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                    var colValId = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName + '_id',
                                        line: c
                                    } );
                                    selectedLinesData += colVal + ',';
                                    selectedLinesData += colValId + ',';
                                    log.debug( 'batch 1 colName', colName + ' colValId=' + colValId + ' ' );
                                }
                                if ( batOpt2 != null && batOpt2 != '' ) {
                                    var colName = batchFieldsData( batOpt2 ).name;
                                    //var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                                    var colVal = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName,
                                        line: c
                                    } );
                                    if ( colVal != null && colVal != '' )
                                        colVal = colVal.replace( /,/g, '|' );
                                    //var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                    var colValId = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName + '_id',
                                        line: c
                                    } );
                                    selectedLinesData += colVal + ',';
                                    selectedLinesData += colValId + ',';
                                    log.debug( 'batch 2 colName', colName + ' colValId=' + colValId + ' ' );
                                }
                                if ( batOpt3 != null && batOpt3 != '' ) {
                                    var colName = batchFieldsData( batOpt3 ).name;
                                    //var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                                    var colVal = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName,
                                        line: c
                                    } );
                                    if ( colVal != null && colVal != '' )
                                        colVal = colVal.replace( /,/g, '|' );
                                    //var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                    var colValId = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName + '_id',
                                        line: c
                                    } );
                                    selectedLinesData += colVal + ',';
                                    selectedLinesData += colValId + ',';
                                    log.debug( 'batch 3 colName', colName + ' colValId=' + colValId + ' ' );
                                }
                                if ( batOpt4 != null && batOpt4 != '' ) {
                                    var colName = batchFieldsData( batOpt4 ).name;
                                    //var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                                    var colVal = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName,
                                        line: c
                                    } );
                                    if ( colVal != null && colVal != '' )
                                        colVal = colVal.replace( /,/g, '|' );
                                    //var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                    var colValId = request.getSublistValue( {
                                        group: SUBLIST_SL_INV_DETAILS,
                                        name: 'custpage_' + colName + '_id',
                                        line: c
                                    } );
                                    selectedLinesData += colVal + ',';
                                    selectedLinesData += colValId + ',';
                                    log.debug( 'batch 4 colName', colName + ' colValId=' + colValId + ' ' );
                                }
                                selectedLinesData = selectedLinesData.slice( 0, -1 ) + '\n';
                            }
                        }
                        var timestamp = new Date().getTime();
                        //var selectedDataFile = nlapiCreateFile('Selected_Lines_to_Consolidate' + timestamp + '.csv', 'CSV', selectedLinesData);

                        //var ciFolder = context.getSetting('SCRIPT', SPARAM_FOLDER_CLIENT_CONSOLIDATED_INVOICES);
                        var ciFolder = script.getParameter( { name: SPARAM_FOLDER_CLIENT_CONSOLIDATED_INVOICES } );
                        //selectedDataNFILE.setFolder(ciFolder);
                        log.debug( 'ciFolder', ciFolder );
                        var selectedDataFile = NFILE.create( {
                            name: 'Selected_Lines_to_Consolidate' + timestamp + '.csv',
                            fileType: NFILE.Type.CSV,
                            contents: selectedLinesData,
                            //description: 'This is a plain text NFILE.',
                            // encoding: NFILE.Encoding.UTF8,
                            folder: ciFolder,
                            isOnline: true
                        } );
                        //selectedDataFile.folder = ciFolder;


                        //var fileId = nlapiSubmitFile(selectedDataFile);
                        var fileId = selectedDataFile.save();

                        //var currentUser = nlapiGetUser();
                        var currentUser = NRUNTIME.getCurrentUser();
                        currentUser = currentUser.id;

                        //var ciExecLogRec = nlapiCreateRecord(CUSTOM_RECORD_CI_EXECUTION_LOG);
                        var ciExecLogRec = NRECORD.create( { type: CUSTOM_RECORD_CI_EXECUTION_LOG, isDynamic: true } );
                        ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_FILE, value: fileId } );
                        ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_CREATED_BY, value: currentUser } );

                        //ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_FILE, fileId);
                        //ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CREATED_BY, currentUser);
                        if ( totCItoCreate != null && totCItoCreate != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE, value: totCItoCreate } );
                        if ( totInvselected != null && totInvselected != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_TO_PROCESS, value: totInvselected } );
                        if ( transactionLinks != null && transactionLinks != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_TRANSACTION_LINKS, value: transactionLinks } );
                        if ( batOpt1 != null && batOpt1 != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_1, value: batOpt1 } );
                        if ( batOpt2 != null && batOpt2 != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_2, value: batOpt2 } );
                        if ( batOpt3 != null && batOpt3 != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_3, value: batOpt3 } );
                        if ( batOpt4 != null && batOpt4 != '' )
                            ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_4, value: batOpt4 } );
                        //ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CI_BATCH_STATUS, '1');
                        ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_CI_BATCH_STATUS, value: '1' } );
                        log.debug( 'selectedRecordID', selectedRecordID );
                        //ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_LINES_TO_PROCESS, selectedRecordID.join(','));
                        ciExecLogRec.setValue( { fieldId: FLD_CI_EXEC_LOG_LINES_TO_PROCESS, value: selectedRecordID.join( ',' ) } );
                        //var newCIExecLogRec = nlapiSubmitRecord(ciExecLogRec, true, true);
                        var newCIExecLogRec = ciExecLogRec.save( {
                            enableSourcing: true,
                            ignoreMandatoryFields: true
                        } );
                        log.debug( 'newCIExecLogRec', newCIExecLogRec );
                        if ( newCIExecLogRec != null && newCIExecLogRec != '' ) {
                            //response.sendRedirect('RECORD', CUSTOM_RECORD_CI_EXECUTION_LOG, newCIExecLogRec);
                            redirect.toRecord( {
                                type: CUSTOM_RECORD_CI_EXECUTION_LOG,
                                id: newCIExecLogRec
                            } );
                            var params = {};
                            params[ SPARAM_CI_EXEC_LOG_ID ] = newCIExecLogRec;
                            params[ SPARAM_SEARCH_COLS_LENGTH ] = parseInt( ssColumns );
                            params[ SPARAM_CI_EXEC_FOLDER_ID ] = ciFolder;
                            //nlapiScheduleScript(SCRIPT_CREATE_CLIENT_CI_SC, null, params);


                            var scriptTask = task.create( { taskType: task.TaskType.MAP_REDUCE } );
                            scriptTask.scriptId = SCRIPT_CI_MR;
                            //scriptTask.deploymentId = DEPLOY_CI_MR;
                            //scriptTask.params = {custscript_appf_sales_order_ids : aSOIDs.toString() };
                            scriptTask.params = params;
                            var scriptTaskId = scriptTask.submit();

                        }
                    }
                } catch ( e ) {
                    /*if (e instanceof nlobjError)
                        nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails());
                    else
                        nlapiLogExecution('DEBUG', 'unexpected error', e.toString());*/

                    log.debug( 'Error', e.message /* + '\n' + e.getDetails()*/ );
                }
            }
        }

        function batchFieldsData ( batchId ) {
            var batchFields = {};
            batchFields[ 1 ] = {
                'name': 'custcol_appf_bill_month',
                'label': 'Bill Month'
            };
            batchFields[ 2 ] = {
                'name': '',
                'label': 'Client Objective'
            };
            batchFields[ 3 ] = {
                'name': 'custcol_appf_do_client_po',
                'label': 'Client PO Number'
            };
            batchFields[ 4 ] = {
                'name': '',
                'label': 'DMA'
            };
            batchFields[ 5 ] = {
                'name': '',
                'label': 'Insertion Date'
            };
            batchFields[ 6 ] = {
                'name': 'custbody_appf_print_isodate',
                'label': 'Issue Date'
            };
            batchFields[ 7 ] = {
                'name': 'custcol_appf_publisher',
                'label': 'Media Supplier',
                'issel': 'T'
            };
            batchFields[ 8 ] = {
                'name': 'custcol_appf_placement1',
                'label': 'Placement_String 1'
            };
            batchFields[ 9 ] = {
                'name': 'custcol_appf_placement2',
                'label': 'Placement_String 2'
            };
            batchFields[ 10 ] = {
                'name': 'custcol_appf_placement3',
                'label': 'Placement_String 3'
            };
            batchFields[ 11 ] = {
                'name': 'custcol_appf_placement4',
                'label': 'Placement_String 4'
            };
            batchFields[ 12 ] = {
                'name': 'custcol_appf_placement5',
                'label': 'Placement_String 5'
            };
            batchFields[ 13 ] = {
                'name': 'custcol_appf_placement6',
                'label': 'Placement_String 6'
            };
            batchFields[ 14 ] = {
                'name': 'custbody_appf_print_mediatype',
                'label': 'Reporting Media Type',
                'issel': 'T'
            };
            batchFields[ 15 ] = {
                'name': 'entity',
                'label': 'Schedule Name',
                'issel': 'T'
            };
            batchFields[ 16 ] = {
                'name': 'custcol_appf_print_servicedate',
                'label': 'Service Date'
            };
            batchFields[ 17 ] = {
                'name': 'custcol_appf_do_dds_estimate',
                'label': 'Estimate # (DoMedia)'
            };
            batchFields[ 18 ] = {
                'name': 'custcol_appf_do_estimatenum',
                'label': 'Estimate # (Strata)'
            };
            batchFields[ 19 ] = {
                'name': 'custcol_appf_do_dds_product',
                'label': 'Product Code (DoMedia)'
            };
            batchFields[ 20 ] = {
                'name': 'custcol_appf_print_dds',
                'label': 'Product Code (Strata)'
            };
            batchFields[ 21 ] = {
                'name': 'custcol_appf_do_market',
                'label': 'Market'
            };
            batchFields[ 22 ] = {
                'name': 'custcol_appf_po_vendor_name',
                'label': 'Vendor'
            };
            batchFields[ 23 ] = {
                'name': 'custcol_appf_strata_product',
                'label': 'Strata Product'
            };
            return batchFields[ batchId ];
        }

        function getAllPendingLines () {
            var LOG_TITLE = 'fn:getAllPendingLines';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var srch = NSEARCH.load( { id: SEARCH_CI_LOGS_IN_PROGRESS } );
            // var srchFilters = srch.filters;
            // var srchColumns = srch.columns;
            // var srchType = srch.searchType;
            var results = getAllSearchResults( srch.searchType, srch.filters, srch.columns );
            var lineIDs = [];
            for ( var i = 0, n = results.length; i < n; i++ ) {
                var ids = results[ i ].getValue( { name: 'custrecord_appf_ci_lines_toprocess' } );
                lineIDs = lineIDs.concat( ids.split( ',' ) );
            }
            NLOG.debug( { title: LOG_TITLE + ' lineIDs', details: JSON.stringify( lineIDs ) } );

            NLOG.debug( { title: LOG_TITLE, details: 'END' } );
            return lineIDs;
        }

        function getAllSearchResults ( record_type, filters, columns ) {
            var LOG_TITLE = 'fn:getAllSearchResults';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            var search = NSEARCH.create( { type: record_type, filters: filters, columns: columns } );
            //search.filters.push(oProject);

            // NSEARCH.setIsPublic(true);
            var searchRan, bolStop = false, intMaxReg = 1000, intMinReg = 0, result = [];

            searchRan = search.run();
            while ( !bolStop && NRUNTIME.getCurrentScript().getRemainingUsage() > 10 ) {
                var extras = searchRan.getRange( { start: intMinReg, end: intMaxReg } );
                result = searchUnion( result, extras );
                intMinReg = intMaxReg;
                intMaxReg += 1000;
                if ( extras.length < 1000 ) {
                    bolStop = true;
                }
            }

            NLOG.debug( { title: LOG_TITLE, details: 'Retrieved result count = ' + result.length } );
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );
            return result;
        }

        function getAllSearchResultsV2 ( searchObj ) {
            var LOG_TITLE = 'fn:getAllSearchResults';
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );

            //var search = NSEARCH.create({ type: record_type, filters: filters, columns: columns });
            //searchObj.filters.push(oProject);

            // NSEARCH.setIsPublic(true);
            var searchRan, bolStop = false, intMaxReg = 1000, intMinReg = 0, result = [];

            //searchRan = NSEARCH.run();
            searchRan = search.run()
            while ( !bolStop && NRUNTIME.getCurrentScript().getRemainingUsage() > 10 ) {
                var extras = searchRan.getRange( { start: intMinReg, end: intMaxReg } );
                result = searchUnion( result, extras );
                intMinReg = intMaxReg;
                intMaxReg += 1000;
                if ( extras.length < 1000 ) {
                    bolStop = true;
                }
            }

            NLOG.debug( { title: LOG_TITLE, details: 'Retrieved result count = ' + result.length } );
            NLOG.debug( { title: LOG_TITLE, details: 'START' } );
            return result;
        }

        function searchUnion ( target, array ) {
            return target.concat( array );
        }

        return {
            onRequest: onRequest
        }
    }
);