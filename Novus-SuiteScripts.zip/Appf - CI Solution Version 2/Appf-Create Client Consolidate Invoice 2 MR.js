/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Creates invoice/trasform matching Sales Order lines into invoice.
 *
 * Author: Roach
 * Date: Oct 20, 2020
 */
define(['N/record','N/search','N/runtime','N/format','N/file','N/error'],

function(record,search,runtime,format,file,error) {
	var CUSTOM_RECORD_CI_EXECUTION_LOG = 'customrecord_appf_ci_execution_log';
	var FLD_CI_EXEC_LOG_FILE = 'custrecord_appf_ci_file_to_process';
	var FLD_CI_EXEC_LOG_TOT_LINES_TO_PROCESS = 'custrecord_appf_ci_total_lines_process';
	var FLD_CI_EXEC_LOG_REMAIN_LINES_TO_PROCESS = 'custrecord_appf_ci_remain_lines_process';
	var FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED = 'custrecord_appf_ci_lines_processed';
	var FLD_CI_EXEC_LOG_PERCENT_PROCESSED = 'custrecord_appf_ci_percent_processed';
	var FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE = 'custrecord_appf_ci_total_ci_to_create';
	var FLD_CI_EXEC_LOG_POST_EXEC_CONSOL_FILE = 'custrecord_appf_ci_post_exec_file';
	var FLD_CI_EXEC_LOG_PROCESSING_CONSOL_STATUS_FILE = 'custrecord_appf_ci_process_status_file';
	var FLD_CI_EXEC_LOG_ERROR_LOG = 'custrecord_appf_ci_error_log';
	var FLD_CI_EXEC_LOG_ERROR_FILE = 'custrecord_appf_ci_error_file';
	var FLD_CI_EXEC_LOG_CREATED_BY = 'custrecord_appf_ci_log_created_by';
	var FLD_CI_EXEC_LOG_TOT_CI_CREATED = 'custrecord_appf_ci_total_ci_created';
	var FLD_CI_EXEC_LOG_BATCH_OPTION_1 = 'custrecord_appf_ci_exec_batch_opt_1';
	var FLD_CI_EXEC_LOG_BATCH_OPTION_2 = 'custrecord_appf_ci_exec_batch_opt_2';
	var FLD_CI_EXEC_LOG_BATCH_OPTION_3 = 'custrecord_appf_ci_exec_batch_opt_3';
	var FLD_CI_EXEC_LOG_BATCH_OPTION_4 = 'custrecord_appf_ci_exec_batch_opt_4';
	var FLD_CI_EXEC_LOG_CI_REC_LINKS = 'custrecord_appf_ci_record_links';
	var FLD_CI_EXEC_LOG_CI_BATCH_STATUS = 'custrecord_appf_ci_exec_batch_status';
	var FLD_CI_EXEC_LOG_INV_BACKLINK_STATUS_FILE = 'custrecord_appf_inv_backlink_status_file';
	var FLD_CI_EXEC_LOG_CM_BACKLINK_STATUS_FILE = 'custrecord_cm_backlinking_status_file';

	var CUSTOM_RECORD_CI = 'customrecord_appf_ci_record';
	var FLD_CI_CLIENT = 'custrecord_appf_ci_client';
	var FLD_CI_CONTRACT = 'custrecord_appf_ci_contract';
	var FLD_CI_INVOICES = 'custrecord_appf_ci_invoices';
	var FLD_CI_NO_OF_INVOICES = 'custrecord_appf_ci_number_invoices';
	var FLD_CI_AMOUNT = 'custrecord_appf_ci_amount';
	var FLD_CI_DISCOUNT = 'custrecord_appf_ci_discount';
	var FLD_CI_TAX = 'custrecord_appf_ci_tax';
	var FLD_CI_SUBTOTAL = 'custrecord_appf_ci_subtotal';
	var FLD_CI_CURRENCY = 'custrecord_appf_ci_currency';
	var FLD_CI_SUBSIDIARY = 'custrecord_appf_ci_subsidiary';
	var FLD_CI_CREATED_BY = 'custrecord_appf_ci_created_by';
	var FLD_CI_DATE_CREATED = 'custrecord_appf_ci_date_created';
	var FLD_CI_DATE = 'custrecord_appf_ci_date';
	var FLD_CI_TERMS = 'custrecord_appf_ci_terms';
	var FLD_CI_DUE_DATE = 'custrecord_appf_ci_due_date';
	var FLD_CI_RECORD = 'custrecord_ci_record';

	var FLD_CI_BATCH_OPTION_1 = 'custrecord_appf_ci_batchoption_1';
	var FLD_CI_BATCH_OPTION_2 = 'custrecord_appf_ci_batchoption_2';
	var FLD_CI_BATCH_OPTION_3 = 'custrecord_appf_ci_batchoption_3';
	var FLD_CI_BATCH_OPTION_4 = 'custrecord_appf_ci_batchoption_4';

	var FLD_CI_BATCH_OPTION_1_VALUE = 'custrecord_appf_batch_option1_value';
	var FLD_CI_BATCH_OPTION_2_VALUE = 'custrecord_appf_batch_option2_value';
	var FLD_CI_BATCH_OPTION_3_VALUE = 'custrecord_appf_batch_option3_value';
	var FLD_CI_BATCH_OPTION_4_VALUE = 'custrecord_appf_batch_option4_value';

	var FLD_CI_BATCH_STATUS_NOT_STARTED = '1';
	var FLD_CI_BATCH_STATUS_UNDER_PROCESSING = '2';
	var FLD_CI_BATCH_STATUS_COMPLETED = '3';
	var FLD_CI_BATCH_STATUS_FAILED = '4';

	var FLD_COL_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';

	var SPARAM_CI_EXEC_LOG_ID = 'custscript_appf_ci_execution_log_id2_mr';
	var SPARAM_CI_LINE_INDEX = 'custscript_appf_line_index2_mr';
	var SPARAM_SEARCH_COLS_LENGTH = 'custscript_appf_search_columns_length2_m';
	var SPARAM_CI_EXEC_FOLDER_ID = 'custscript_appf_ci_exec_fold_id2_mr';
	var SPARAM_BATCH_FILE_ID = 'custscript_appf_ci_batch_file_id2_mr';

	var IMPORT_CSV_SYNC_INV_CI_RECORD = 'custimport_appf_sync_inv_ci_record';
	var IMPORT_CSV_SYNC_CM_CI_RECORD = 'custimport_appf_sync_cm_ci_record';

	var FLD_TRAN_LINE_CI_BATCH_STATUS = '';
	var FLD_TRAN_LINE_CI_STATUS = 'custcol_appf_ci_status';
	var FLD_TRAN_LINE_CI_LOG = 'custcol_appf_ci_log';
	var FLD_TRAN_LINE_CI_RECORD = 'custcol_appf_ci_record';

	function searchMoreRecords(recordType, searchID, filters, columns)
	{
		if(searchID != null){
			var searchObj = search.load({
				id: searchID
			});
		}else{
			var searchObj = search.create({
				id: searchID,
				type: recordType,
				filters: filters,
				columns: columns
			});
		}

		var resultSet = searchObj.run();
		var results = [];
		var start = 0;
		var end = 1000;
		do{
			var result = resultSet.getRange(start,end);
			results = results.concat(result);
			start += 1000;
			end += 1000;

		}while(result.length == 1000);

		return results;
	}

	function searchTerms(){
        var aTerms = [];
		//get terms
		var searchTerms = search.create({
	     	   type: 'term',
	     	   columns:
	     	   [
	     	      search.createColumn({
	     	         name: 'internalid'
	     	      }),
	     	      search.createColumn({
	      	         name: 'daysuntilnetdue'
	      	      })
	     	   ]
	     	});
		searchTerms.run().each(function(result){
			// .run().each has a limit of 4,000 results
			var termId = result.getValue({
				name: 'internalid'
			});
			var daysuntilnetdue = result.getValue({
				name: 'daysuntilnetdue'
			});
			log.debug('termId :',termId  + ' daysuntilnetdue:'+ daysuntilnetdue);
			aTerms[termId] = daysuntilnetdue;
     	   	return true;
		});

		return aTerms;
	}

    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
    	var ciExecLogId = runtime.getCurrentScript().getParameter({name: SPARAM_CI_EXEC_LOG_ID});

    	var ciExecFolderId = runtime.getCurrentScript().getParameter({name: SPARAM_CI_EXEC_FOLDER_ID});

    	var ciBatchFileId = runtime.getCurrentScript().getParameter({name: SPARAM_BATCH_FILE_ID});
    	var searchColsLength = runtime.getCurrentScript().getParameter({name: SPARAM_SEARCH_COLS_LENGTH});
    	var index = runtime.getCurrentScript().getParameter({name: SPARAM_CI_LINE_INDEX});
        log.debug('ciExecLogId::ciExecFolderId::ciBatchFileId::searchColsLength::index', ciExecLogId+'::'+ciExecFolderId+'::'+ciBatchFileId+'::'+searchColsLength+'::'+index);

        if(index == null || index == '')
    		index = 0;
    	var uniqueBatchGroupObj = '';
    	if(ciExecLogId != null && ciExecLogId != ''){

    		//get terms
    		var aTerms = searchTerms();
    		var ciExecLogRec = record.load({type: CUSTOM_RECORD_CI_EXECUTION_LOG,id: ciExecLogId,isDynamic: false});

    		var totCIRecordsCreated = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_TOT_CI_CREATED
    		});

    		if (totCIRecordsCreated == null || totCIRecordsCreated == '')
    			totCIRecordsCreated = 0;

    			totCIRecordsCreated = parseInt(totCIRecordsCreated);

    		var totRecordsCompleted = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED
    		});
    		if (totRecordsCompleted == null || totRecordsCompleted == '')
    			totRecordsCompleted = 0;

    		var existingCIRecordLinks = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_CI_REC_LINKS
    		});

    		totRecordsCompleted = parseInt(totRecordsCompleted);


    		var batchOpt1 = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_1
    		});


    		var batchOpt2 = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_2
    		});


    		var batchOpt3 = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_3
    		});


    		var batchOpt4 = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_BATCH_OPTION_4
    		});

    		var errorLog = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_ERROR_LOG
    		});

    		if(errorLog != null && errorLog != '' && errorLog != 'undefined' && errorLog != undefined)
    			errorLog = errorLog + '\n';
    		else
    			errorLog = '';

    		var totalBatchOpts = 0;
    		if(batchOpt1 != null && batchOpt1 != '')
    			totalBatchOpts++;
    		if(batchOpt2 != null && batchOpt2 != '')
    			totalBatchOpts++;
    		if(batchOpt3 != null && batchOpt3 != '')
    			totalBatchOpts++
    		if(batchOpt4 != null && batchOpt4 != '')
    			totalBatchOpts++


    		var fileId = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_FILE
    		});

    		if (ciBatchFileId == null || ciBatchFileId == '')
            {
    			//load file
    			var fileData = file.load(fileId).getContents();

    			if(fileData != null && fileData != ''){
    				uniqueBatchGroupObj = {};
    				var selectedLines = fileData.split('\n');

    				var hasCreditMemos = false;
    				var hasInvoices = false;
    				var hasCreditMemos2 = false;
    				var hasInvoices2 = false;
    				var hasCreditMemos3 = false;
    				var hasInvoices3 = false;


    				for(var i=1; i<(selectedLines.length-1); i++){
    					var line = selectedLines[i].split(',');
    					var transRecId = line[0];
    					var transRecType = line[7];
    					var client = line[2];
    					var contract = line[4];
    					var amt = line[13];
    					var lineId = line[16];
    					var taxAmt = line[19];
    					var discountAmt = line[20];
    					if(taxAmt == null || taxAmt == '' || taxAmt == 'null')
    						taxAmt = 0;
    					if(discountAmt == null || discountAmt == '' || discountAmt == 'null')
    						discountAmt = 0;
    					var batchGroup = '';
    					var ssCols = searchColsLength-1;
    					for(var b=0; b<totalBatchOpts; b++){
    						ssCols = parseInt(ssCols)+2;
    						batchGroup = batchGroup+line[parseInt(ssCols)]+'||';
    					}
    					if(!uniqueBatchGroupObj.hasOwnProperty(batchGroup)){
    						uniqueBatchGroupObj[batchGroup] = {};
    						uniqueBatchGroupObj[batchGroup].client = client;
    						uniqueBatchGroupObj[batchGroup].contract = contract;
    						uniqueBatchGroupObj[batchGroup].amt = amt;
    						uniqueBatchGroupObj[batchGroup].transRecIds = [];
    						var obj = {};
    						obj.recType = transRecType;
    						obj.recId = transRecId;
    						obj.invLineId = lineId;
    						obj.taxAmt = taxAmt;
    						obj.counter = i;
    						obj.discountAmt = discountAmt;
    						uniqueBatchGroupObj[batchGroup].transRecIds.push(obj);
    					}
    					else{
    						uniqueBatchGroupObj[batchGroup].amt = parseFloat(uniqueBatchGroupObj[batchGroup].amt)+parseFloat(amt);
    						var obj = {};
    						obj.recType = transRecType;
    						obj.recId = transRecId;
    						obj.invLineId = lineId;
    						obj.taxAmt = taxAmt;
    						obj.counter = i;
    						obj.discountAmt = discountAmt;
    						uniqueBatchGroupObj[batchGroup].transRecIds.push(obj);
    					}

    				}
    			}
            }
    		else
    		{
    			var batchFileData = file.load(ciBatchFileId).getContents();
    			uniqueBatchGroupObj = JSON.parse(batchFileData);

    		}

    		var ciRecordLinks = [];
    		if (existingCIRecordLinks != null && existingCIRecordLinks != '' && existingCIRecordLinks.length > 0)
    			ciRecordLinks = ciRecordLinks.concat(existingCIRecordLinks);

    		var uniqueBatchGroupArr = [];

    		for(var prop in uniqueBatchGroupObj){

    			var innerobj = {};
    			innerobj.propname = prop;

    			var obj = uniqueBatchGroupObj[prop];
    			innerobj.propvalues = obj;

    			innerobj.ciExecLogId = ciExecLogId;


    			uniqueBatchGroupArr.push(innerobj);

    		}

    		log.debug('uniqueBatchGroupObj', JSON.stringify(uniqueBatchGroupArr));

    		//call map stage
    		//return uniqueBatchGroupArr;

	    	//group by invoice/cm internal ud
	    	var oGroupedTransaction = new Object();
        var aAllRec = [];
    		//create CI records, loop object uniqueBatchGroupArr
    		for(var p=index; p<uniqueBatchGroupArr.length; p++){
    			var prop = uniqueBatchGroupArr[p].propname;
    			var obj = uniqueBatchGroupArr[p].propvalues;
    			//var prop = uniqueBatchGroupArr.propname;
    			log.debug('map prop', prop);

    			//var obj = uniqueBatchGroupArr.propvalues;
    			log.debug('map obj', obj);

    			var batchValuesList = prop.split('||');

    			var totRecords =  obj.transRecIds;
    			log.debug('totRecords', totRecords);
    			var recIds = [];
    			var taxTotal = 0;
    			var discountTotal = 0;
    			var recType = '';
    			if(totRecords != null && totRecords != ''){
    				for(var t=0; t<totRecords.length; t++){
    					var  totRecObj = totRecords[t];
    					recIds.push(totRecObj.recId);
    					taxTotal = parseFloat(taxTotal) + parseFloat(totRecObj.taxAmt);
    					discountTotal = parseFloat(discountTotal) + parseFloat(totRecObj.discountAmt);
    					sRecType = totRecObj.recType;
              aAllRec.push(totRecObj.recId);
    				}
    			}
    			log.debug('recIds', recIds);

    			var ciRecordLinks = [];
    			if (existingCIRecordLinks != null && existingCIRecordLinks != '' && existingCIRecordLinks.length > 0)
    				ciRecordLinks = ciRecordLinks.concat(existingCIRecordLinks);

    			if(recIds != null && recIds != '')
    				recIds = eliminateDuplicates(recIds);
    				log.debug('eliminate dup recIds', recIds);
            aAllRec = eliminateDuplicates(aAllRec);
            log.debug('eliminate dup recIds aAllRec', aAllRec);


    				var newCIRecord = '';
    				try{
    		    		var ciRecord = record.create({type: CUSTOM_RECORD_CI,isDynamic : true});
    		    		ciRecord.setValue({fieldId: FLD_CI_CLIENT,value: obj.client });
    		    		ciRecord.setValue({fieldId: FLD_CI_CONTRACT,value: obj.contract });

    					if(recIds != null && recIds != ''){
    						ciRecord.setValue({fieldId: FLD_CI_INVOICES,value: recIds });
    			    		ciRecord.setValue({fieldId: FLD_CI_NO_OF_INVOICES,value: recIds.length });
    			    		log.debug('set link recIds', recIds);
    					}
    					var subtotalValue = parseFloat(obj.amt) - parseFloat(taxTotal);
    					ciRecord.setValue({fieldId: FLD_CI_SUBTOTAL,value: subtotalValue });
    					log.debug('subtotalValue', subtotalValue);
    		    		ciRecord.setValue({fieldId: FLD_CI_AMOUNT,value: obj.amt });
    		    		log.debug('obj.amt', obj.amt);
    		    		ciRecord.setValue({fieldId: FLD_CI_TAX,value: taxTotal });
    		    		log.debug('taxTotal', taxTotal);
    		    		ciRecord.setValue({fieldId: FLD_CI_DISCOUNT,value: discountTotal });
    		    		log.debug('discountTotal', discountTotal);

    		    		try{
    						newCIRecord = ciRecord.save({
    						    enableSourcing: true,
    						    ignoreMandatoryFields: true
    						});
    						log.debug('newCIRecord', newCIRecord);

    		    		}catch(eCI){
    		    			log.debug('error ci', eCI.message);
    		    		}

    					if(newCIRecord != null && newCIRecord != ''){
    						ciRecord = record.load({type: CUSTOM_RECORD_CI,id: newCIRecord,isDynamic: false});
    			    		var ciDate = ciRecord.getValue({
    			    		    fieldId: FLD_CI_DATE
    			    		});
    			    		var ciTerms = ciRecord.getValue({
    			    		    fieldId: FLD_CI_TERMS
    			    		});
    						var dueDate = ciDate;
    						if(ciDate != null && ciDate != '' && ciTerms != null && ciTerms != ''){
    								/*var oTermdays = search.lookupFields({
    						    	    type: 'term',
    						    	    id: ciTerms,
    						    	    columns: ['daysuntilnetdue']
    						    	});*/

    						    	//var termdays = oTermdays['daysuntilnetdue'];
    								var  termdays = aTerms[ciTerms];
    						    	log.debug('termdays', termdays + ' ciDate='+ciDate);
    								if(termdays != null && termdays != ''){
    									dueDate = new Date(ciDate.setDate(ciDate.getDate() + Number(termdays)));
    								    log.debug('dueDate',dueDate);

    								}

    						}
    						ciRecord.setValue({fieldId: FLD_CI_DUE_DATE,value: dueDate });
    						log.debug('set due date','set due date');
    						ciRecord.setValue({fieldId: FLD_CI_RECORD,value: newCIRecord });
    						log.debug('set  new record','set new record');

    						var b = 0;
    			    		var batchoption1 = ciRecord.getValue({
    			    		    fieldId: FLD_CI_BATCH_OPTION_1
    			    		});

    						if (batchoption1 != null && batchoption1 != '')
    						{
    							ciRecord.setValue({fieldId: FLD_CI_BATCH_OPTION_1_VALUE,value: batchValuesList[b] });
    							b++;
    						}
    			    		var batchoption2 = ciRecord.getValue({
    			    		    fieldId: FLD_CI_BATCH_OPTION_2
    			    		});
    						if (batchoption2 != null && batchoption2 != '')
    						{
    							ciRecord.setValue({fieldId: FLD_CI_BATCH_OPTION_2_VALUE,value: batchValuesList[b] });
    							b++;
    						}
    			    		var batchoption3 = ciRecord.getValue({
    			    		    fieldId: FLD_CI_BATCH_OPTION_3
    			    		});

    						if (batchoption3 != null && batchoption3 != '')
    						{
    							ciRecord.setValue({fieldId: FLD_CI_BATCH_OPTION_3_VALUE,value: batchValuesList[b] });
    							b++;
    						}
    			    		var batchoption4 = ciRecord.getValue({
    			    		    fieldId: FLD_CI_BATCH_OPTION_4
    			    		});
    						if (batchoption4 != null && batchoption4 != '')
    						{
    							ciRecord.setValue({fieldId: FLD_CI_BATCH_OPTION_4_VALUE,value: batchValuesList[b] });
    							b++;
    						}
    						log.debug('set batch option','set batch option');
    						try{
    							newCIRecord = ciRecord.save({
    							    enableSourcing: true,
    							    ignoreMandatoryFields: true
    							});

    							log.debug('ci save success','ci save success');

    						}catch(error2){
    							log.debug('error2', error2.message);
    						}

    						log.debug('totCIRecordsCreated',totCIRecordsCreated);

    						totCIRecordsCreated++;
    						log.debug('totCIRecordsCreated',totCIRecordsCreated);
    						ciRecordLinks.push(newCIRecord);
    						totRecordsCompleted = parseInt(totRecordsCompleted) + parseInt(recIds.length);
    						log.debug('totRecordsCompleted',totRecordsCompleted);
    									//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG, ciExecLogId, FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED, totRecordsCompleted);


    					}
    				}catch(e){
    					totRecordsCompleted = parseInt(totRecordsCompleted) + parseInt(recIds.length);
    					FLD_CI_BATCH_STATUS_COMPLETED = FLD_CI_BATCH_STATUS_FAILED;
    					log.debug('error creating CI', e.message);
    					errorLog = e.message;
    				}

    				log.debug('submit fields','submit fields');
    				var aUpdateFields = {};
    	        	aUpdateFields[FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED] = aAllRec.length; /*totRecordsCompleted*/;
    	        	aUpdateFields[FLD_CI_EXEC_LOG_TOT_CI_CREATED] = totCIRecordsCreated;
    	        	aUpdateFields[FLD_CI_EXEC_LOG_CI_BATCH_STATUS] = 2;
    	        	//record submit

    				record.submitFields({
    				    type: CUSTOM_RECORD_CI_EXECUTION_LOG,
    				    id: ciExecLogId,
    				    values: aUpdateFields
    				});

    	    		//backlinking, prepare object for map/reduce

    		    	log.debug('totRecords',totRecords);
    				if(totRecords != null && totRecords != ''){
    					for(var t=0; t<totRecords.length; t++){
    						var obj = totRecords[t];
    						var recType = obj.recType;
    						 //to object invoice ids
    						 var keys = [];
    						 keys.push(recType);
    						 keys.push(obj.recId);
    						 //keys.push(newCIRecord);
    			             var oCols = new Object();
    			             oCols['keys'] = keys;
    			             oCols['idInvoice'] = obj.recId;
    			             oCols['ciBatchStatus'] = FLD_CI_BATCH_STATUS_NOT_STARTED;
    			             oCols['invoiceLineID'] = obj.invLineId;
    			             oCols['ciStatus'] = FLD_CI_BATCH_STATUS_COMPLETED;
    			             oCols['ciExecLogId'] = ciExecLogId;
    			             oCols['newCIRecord'] = newCIRecord;

    			             log.debug('oCols',oCols);
    			             var aDataDetails = oGroupedTransaction[keys] || new Array();
    			         	 aDataDetails.push(oCols);
    			         	 oGroupedTransaction[keys] = aDataDetails;

    					}
    				}

    		}

			log.debug('oGroupedTransaction',JSON.stringify(oGroupedTransaction));

			//grouped by id
	         for(var idKey in oGroupedTransaction){
	      	    var aRows = oGroupedTransaction[idKey];
	      	    log.debug('for reduce stage aRows', JSON.stringify(aRows));
	      	    log.debug('for reduce key', idKey);
	      	    log.debug('for reduce aRows', aRows);
	           /* context.write({
	                key: idKey ,
	                value: aRows
	            }); */
	          }

	         return oGroupedTransaction;

    	}
    }


   //get input - 1 record; group by 4
   //map -  4 batches , 1st - 3 invoice, 2 - 2 invoice, 3 - 4 invoice - 4th - invoice
   //reduce - 10 times

    function reduce(context){
    //function map(context){
    	log.debug('rowJson reduce raw', context);
    	var rowJson = JSON.parse(context.values[0]); //JSON.parse(context.values[0]);
    	//var rowJson = context.values[0];
    	var aData = rowJson;
    	log.debug('reduce stage: aData', aData + ' key = ' + context.key );
    	log.debug('reduce stage: aData length='+aData.length + ' start = '+ new Date());
    	var aKey = (context.key).split(',');
    	log.debug('reduce stage: akey[0]', aKey[0] + ' - ' + aKey[1]);
    	if(aKey[0] == 'CustInvc' || aKey[0] == 'Client Invoice'){
    		var recInvoice = record.load({type: record.Type.INVOICE,id: aKey[1],isDynamic: false});
    	}else{
    		var recInvoice = record.load({type: record.Type.CREDIT_MEMO,id: aKey[1],isDynamic: false});
    	}

		var getLineCount = recInvoice.getLineCount({sublistId: 'item'});
    	log.debug('reduce stage: getLineCount', getLineCount);
    	var ciExecLogId;
    	var idCIRecord;
      var aCI = [];
        //for(var idKey in aData){
    	for(var k = 0; k < aData.length; k++){
    		log.debug('aData', JSON.stringify(aData[k]));
    		var idKey = aData[k].keys
        	log.debug('idKey', idKey);
      	    //var aRows = aData[idKey];
      	    //log.debug('aRows', aRows);

			//var getLineId = aRows.invoiceLineID;
    		var getLineId = aData[k].invoiceLineID;
			getLineId =  getLineId.replace(/\s+/g,'');

			var i = recInvoice.findSublistLineWithValue({
			    sublistId: 'item',
			    fieldId: 'line',
			    value: getLineId
			});
			log.debug('i', i);

			if(i >= 0){
				ciExecLogId = aData[k].ciExecLogId;
				/*recInvoice.selectLine({sublistId: 'item',line: i});
				//recInvoice.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_BATCH_STATUS,value: aData[i].ciBatchStatus});
				recInvoice.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_STATUS,value: aData[k].ciStatus});
				recInvoice.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_LOG,value: aData[k].ciExecLogId});
				recInvoice.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_RECORD,value: aData[k].newCIRecord});
				recInvoice.commitLine({sublistId: 'item'});*/
				recInvoice.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_BATCH_STATUS,line: i,value: aData[k].ciBatchStatus});
				recInvoice.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_STATUS,line: i,value: aData[k].ciStatus});
				recInvoice.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_LOG,line: i,value: aData[k].ciExecLogId});
				recInvoice.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_RECORD,line: i,value: aData[k].newCIRecord});
				log.debug('commit line', 'commit line : ' + getLineId);
				idCIRecord = aData[k].newCIRecord;
				aCI.push(aData[k].newCIRecord);
			}


          }


		try{
			recInvoice.save();
			//context write reduce to summarize, get all unique CI
	        context.write({
	            key: aKey[1],
	            value: aCI
	        });

			log.debug('reduce stage: successfully linked invoice : ' + aKey[1]);
		}catch(e){
			log.debug('Error', e.message);

		}

    }

    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */

    function summarize(summary)
    {
    	var ciExecLogId = runtime.getCurrentScript().getParameter({name: SPARAM_CI_EXEC_LOG_ID});
    	
		log.debug('Input Summary: ', JSON.stringify(summary.inputSummary));
		log.debug('Map Summary: ', JSON.stringify(summary.mapSummary));
		log.debug('Reduce Summary: ', JSON.stringify(summary.reduceSummary));


        var aInvoice = [];
        var aCI = []
        //summary.reduceSummary.output.iterator().each(function (key, value) {
        summary.output.iterator().each(function (key, value) {
            log.debug({
                title: 'Output for key ' + key,
                details: value
            });
            log.debug('value',value);
            var aVal = value.split(',');
            for(k = 0; k < aVal.length; k++){
            	log.debug('aVal[k]',aVal[k]);
            	var str = aVal[k];
            	str = str.replace("[", "");
            	str = str.replace("]", "");
            	aCI.push(str);
            }

            aInvoice.push(key);
            return true;
        });
        aInvoice = eliminateDuplicates(aInvoice);
        var nInvLength = aInvoice.length;

        log.debug('aCI',aCI);
        //remove duplicates
        aCI = eliminateDuplicates(aCI);
        log.debug('aCI2',aCI);
        var nCILength = aCI.length;
        
        var bReady = false;
        
        while(bReady == false){
            var ciExecLogRec = record.load({type: CUSTOM_RECORD_CI_EXECUTION_LOG,id: ciExecLogId,isDynamic: false});
            ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_CI_REC_LINKS,value: aCI });
            ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED,value: nInvLength });
            ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_TOT_CI_CREATED,value: nCILength });

    		var expectedCIstoCreate = ciExecLogRec.getValue({
    		    fieldId: FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE
    		});
    		log.debug('expectedCIstoCreate',expectedCIstoCreate + ' nCILength =' +nCILength);


    		var errmsg = [];

    		//We are gonna go through each stages summary and check for errors.
    		//IF error is found, send email,
    		//Otherwise, Queue up Release Revenue Hold Map/Reduce Script
    		if (summary.inputSummary.error)
    		{
    			errmsg.push('<li>INPUT Failed: '+summary.inputSummary.error);
    		}

    		summary.mapSummary.errors.iterator().each(function(key, value) {
    			log.error(key, 'ERROR String: '+value);

    			errmsg.push('<li>CI Internal ID '+key+': '+JSON.parse(value).message+'</li>');

    			return true;
    		});

    		summary.reduceSummary.errors.iterator().each(function(key, value) {
        		log.error('Reduce Error CI ID '+key, 'ERROR String: '+value);

        		errmsg.push('<li>CI Internal ID '+key+': '+JSON.parse(value).message+'</li>');

        		return true;
        	});

    		//At this point, if there are any errors notify the Admin
    		if (errmsg.length > 0)
    		{
    			var errMsg = '';
    			for (var er=0; er < errmsg.length; er+=1)
    			{
    				errMsg += errmsg[er];
    			}
    			errMsg = '<ul>'+errMsg+'</ul>';
    			//set to fail
    			ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_CI_BATCH_STATUS,value: '3' });
    			log.debug('summary status','3');
    			ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_ERROR_LOG,value: errMsg });
    		}else{

    			//check if totals match
    			if (nCILength == expectedCIstoCreate){
    				//set to complete
    				ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_CI_BATCH_STATUS,value: '4' });
    				log.debug('summary status','4');
    			}else{
    				//set to complete
    				ciExecLogRec.setValue({fieldId: FLD_CI_EXEC_LOG_CI_BATCH_STATUS,value: '3' });
    				log.debug('summary status','3');
    			}


    		}
    		
    		try{
    			ciExecLogRec.save();
    			bReady = true;
    		}catch(errorSave){
    			log.debug('errorSave', errorSave.message);
    			
    			if(errorSave.message == 'Record has been changed' || errorSave.message == 'Record has been changed.'){
    				bReady = false;
    			}
    			
    		}
    		
        	
        }



		log.debug('summary end',new Date());
    }


    function eliminateDuplicates(arr)
    {
	    var i,
	    len=arr.length,
	    out=[],
	    obj={};

	    for (i=0;i<len;i++) {
	    obj[arr[i]]=0;
	    }
	    for (i in obj) {
	    out.push(i);
	    }
	    return out;
    }

    return {
        getInputData: getInputData,
        //map: map,
        reduce: reduce,
        summarize: summarize
    };

});
