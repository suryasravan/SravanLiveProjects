/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Generates custom PDF layout depending on PDF template assigned to CI record.
 * 
 * Script Name : Appf-Create Client CI Validations CL
 * Script Type : Client
 * Description : 
 * Company     : Appficiency Inc.
 * Author      : marlon
 * Date        : Nov 19, 2020
 */

define(
    [
        'N/currentRecord',
        'N/log',
        'N/search',
		'N/format'
    ],

    function (
        NCR,
        NLOG,
        NSEARCH,
		format
    ) {
        var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
        var FLD_SL_CLIENT = 'custpage_client';
        var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
        var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
        var FLD_SL_LINE_OF_BUSIBNESS = 'custpage_line_of_business';
        var FLD_SL_CURRENCY = 'custpage_currency';
        var FLD_SL_CONTRACT = 'custpage_contract';
        var FLD_SL_PUBLISHER_MEDIA_SIPPLIER = 'custpage_publisher_media_supplier';
        var FLD_SL_VENDOR = 'custpage_vendor';
        var FLD_SL_TRANSACTION_TYPE = 'custpage_transaction_tupe';
        var FLD_SL_DATE_FROM = 'custpage_date_from';
        var FLD_SL_DATE_TO = 'custpage_date_to';
        var FLD_SL_SCHED_NAME_PROJ = 'custpage_sched_ame_proj';
        var FLD_SL_BILL_MONTH = 'custpage_bill_month';
        var FLD_SL_ADJUSTMENT_INVOICE = 'custpage_adjustment_invoice';
        var FLD_SL_PLACEMENT_STR_1 = 'custpage_placement_str_1';
        var FLD_SL_PLACEMENT_STR_2 = 'custpage_placement_str_2';
        var FLD_SL_PLACEMENT_STR_3 = 'custpage_placement_str_3';
        var FLD_SL_PLACEMENT_STR_4 = 'custpage_placement_str_4';
        var FLD_SL_PLACEMENT_STR_5 = 'custpage_placement_str_5';
        var FLD_SL_PLACEMENT_STR_6 = 'custpage_placement_str_6';
		var FLD_SL_GRP_TRANSACTION_LINKS = 'custpage_ci_transaction_links';


        var FLD_SL_CONSOLIDATED = 'custpage_chkfld';

        var FLD_SL_GRP_BATCH_OPTION_1 = 'custpage_batch_opt_1';
        var FLD_SL_GRP_BATCH_OPTION_2 = 'custpage_batch_opt_2';
        var FLD_SL_GRP_BATCH_OPTION_3 = 'custpage_batch_opt_3';
        var FLD_SL_GRP_BATCH_OPTION_4 = 'custpage_batch_opt_4';
        var FLD_SL_GRP_OVERRIDE = 'custpage_override';

        var FLD_SL_GRP_INV_AVAIL_CONSOL = 'custpage_inv_avail_consol';
        var FLD_SL_GRP_INV_LINES_AVAIL_CONSOL = 'custpage_inv_lines_avail_consol';
        var FLD_SL_GRP_TOT_CI_TO_CREATE = 'custpage_total_ci_to_create';
        var FLD_SL_GRP_TOT_CI_AMT = 'custpage_total_ci_amount';
        var FLD_SL_GRP_TOT_CI_INVOICES = 'custpage_total_ci_invoices';

        var SUBLIST_SL_INV_DETAILS = 'custpage_sublist_inv_details';
        var FLD_COL_SL_SELECT = 'custpage_sl_select';
        var FLD_COL_SL_AMOUNT = 'custpage_formulacurrency_1';
        var FLD_COL_SL_INTERNAL_ID = 'custpage_internal_id';

        var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
        var FLD_CONTRACT_REC_BATCH_OPT_1 = 'custrecord_appf_contract_batchoption1';
        var FLD_CONTRACT_REC_BATCH_OPT_2 = 'custrecord_appf_contract_batchoption2';
        var FLD_CONTRACT_REC_BATCH_OPT_3 = 'custrecord_appf_contract_batchoption3';
        var FLD_CONTRACT_REC_BATCH_OPT_4 = 'custrecord_appf_contract_batchoption4';

        var SCRIPT_CREATE_CLIENT_CI_SL = 'customscript_appf_create_client_ci_sl_v2';
        var DEPLOY_CREATE_CLIENT_CI_SL = 'customdeploy_appf_create_client_ci_sl_v2';
        var FLD_CREATE_CLIENT_CI_SL = 'custpage_sl_url';

        function createCCIFieldChange ( context ) {
            var cr = context.currentRecord;
            var LOG_TITLE = 'createCCIFieldChange: ';
            console.log( LOG_TITLE + ' START' );
            console.log( LOG_TITLE + ' ctx.fieldId = ' + context.fieldId );

            if ( context.fieldId == FLD_SL_CLIENT ) {
                var clientFlt = cr.getValue( { fieldId: FLD_SL_CLIENT } );

                if ( clientFlt != null && clientFlt != '' ) {
                    var client = NSEARCH.lookupFields( {
                        type: NSEARCH.Type.CUSTOMER,
                        id: clientFlt,
                        columns: [
                            'subsidiary',
                            'currency'
                        ]
                    } );
                    //alert(client);

                    var clientSub = client.subsidiary;
                    var clientCurrecy = client.currency;

                    cr.setValue( { fieldId: FLD_SL_CURRENCY, value: clientCurrecy } );
                    cr.setValue( { fieldId: FLD_SL_SUBSIDIARY, value: clientSub } );
                }
                else {
                    cr.setValue( { fieldId: FLD_SL_CURRENCY, value: '' } );
                    cr.setValue( { fieldId: FLD_SL_SUBSIDIARY, value: '' } );
                }

                applyFilters( cr, 'yes' );
            }
            if ( context.fieldId == FLD_SL_GRP_OVERRIDE ) {
                var batOpt1Fld = cr.getField( { fieldId: FLD_SL_GRP_BATCH_OPTION_1 } );
                var batOpt2Fld = cr.getField( { fieldId: FLD_SL_GRP_BATCH_OPTION_2 } );
                var batOpt3Fld = cr.getField( { fieldId: FLD_SL_GRP_BATCH_OPTION_3 } );
                var batOpt4Fld = cr.getField( { fieldId: FLD_SL_GRP_BATCH_OPTION_4 } );
                var override = cr.getValue( { fieldId: FLD_SL_GRP_OVERRIDE } );

                if ( override == 'T' || override == true ) {
                    /*batOpt1Fld.updateDisplayType({ displayType: UI.FieldDisplayType.NORMAL });
                    batOpt2Fld.updateDisplayType({ displayType: UI.FieldDisplayType.NORMAL });
                    batOpt3Fld.updateDisplayType({ displayType: UI.FieldDisplayType.NORMAL });
                    batOpt4Fld.updateDisplayType({ displayType: UI.FieldDisplayType.NORMAL });*/
                    batOpt1Fld.isDisabled = false;
                    batOpt1Fld.isDisplay = true;
                    batOpt2Fld.isDisabled = false;
                    batOpt2Fld.isDisplay = true;
                    batOpt3Fld.isDisabled = false;
                    batOpt3Fld.isDisplay = true;
                    batOpt4Fld.isDisabled = false;
                    batOpt4Fld.isDisplay = true;
                }
                else {
                    /*batOpt1Fld.updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
                    batOpt2Fld.updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
                    batOpt3Fld.updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });
                    batOpt4Fld.updateDisplayType({ displayType: UI.FieldDisplayType.DISABLED });*/
                    batOpt1Fld.isDisabled = true;
                    batOpt1Fld.isDisplay = true;
                    batOpt2Fld.isDisabled = true;
                    batOpt2Fld.isDisplay = true;
                    batOpt3Fld.isDisabled = true;
                    batOpt3Fld.isDisplay = true;
                    batOpt4Fld.isDisabled = true;
                    batOpt4Fld.isDisplay = true;

                }
            }
            if ( context.fieldId == FLD_SL_CONTRACT ) {
                var contractFlt = cr.getValue( { fieldId: FLD_SL_CONTRACT } );
                console.log( LOG_TITLE, ' contractFlt = ' + contractFlt );

                if ( contractFlt != null && contractFlt != '' ) {
                    var contractRec = NSEARCH.lookupFields( {
                        type: CUSTOM_RECORD_CONTRACT,
                        id: contractFlt,
                        columns: [
                            FLD_CONTRACT_REC_BATCH_OPT_1,
                            FLD_CONTRACT_REC_BATCH_OPT_2,
                            FLD_CONTRACT_REC_BATCH_OPT_3,
                            FLD_CONTRACT_REC_BATCH_OPT_4
                        ]
                    } );
                    // var contractRec = nlapiLoadRecord(CUSTOM_RECORD_CONTRACT, contractFlt });
                    // var batchOpt1 = contractcr.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_1 });
                    // var batchOpt2 = contractcr.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_2 });
                    // var batchOpt3 = contractcr.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_3 });
                    // var batchOpt4 = contractcr.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_4 });
                    // alert('contractRec');
                    console.log( contractRec );

                    var batchOpt1 = contractRec[ FLD_CONTRACT_REC_BATCH_OPT_1 ].length > 0 ?
                        contractRec[ FLD_CONTRACT_REC_BATCH_OPT_1 ][ 0 ].value : '';

                    var batchOpt2 = contractRec[ FLD_CONTRACT_REC_BATCH_OPT_2 ].length > 0 ?
                        contractRec[ FLD_CONTRACT_REC_BATCH_OPT_2 ][ 0 ].value : '';

                    var batchOpt3 = contractRec[ FLD_CONTRACT_REC_BATCH_OPT_3 ].length > 0 ?
                        contractRec[ FLD_CONTRACT_REC_BATCH_OPT_3 ][ 0 ].value : '';

                    var batchOpt4 = contractRec[ FLD_CONTRACT_REC_BATCH_OPT_4 ].length > 0 ?
                        contractRec[ FLD_CONTRACT_REC_BATCH_OPT_4 ][ 0 ].value : '';

                    // var batchOpt1 = contractRec[FLD_CONTRACT_REC_BATCH_OPT_1][0].value;
                    // var batchOpt2 = contractRec[FLD_CONTRACT_REC_BATCH_OPT_2][0].value;
                    // var batchOpt3 = contractRec[FLD_CONTRACT_REC_BATCH_OPT_3];
                    // var batchOpt4 = contractRec[FLD_CONTRACT_REC_BATCH_OPT_4];

                    // if (batchOpt1 == null || batchOpt1 == '') {
                    // batchOpt1 = '';
                    // }

                    // if (batchOpt2 == null || batchOpt2 == '')
                    // batchOpt2 = '';
                    // if (batchOpt3 == null || batchOpt3 == '')
                    // batchOpt3 = '';
                    // if (batchOpt4 == null || batchOpt4 == '')
                    // batchOpt4 = '';

                    console.log( batchOpt1, batchOpt2, batchOpt3, batchOpt4 );

                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_1, value: batchOpt1 } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_2, value: batchOpt2 } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_3, value: batchOpt3 } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_4, value: batchOpt4 } );
                }
                else {
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_1, value: '' } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_2, value: '' } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_3, value: '' } );
                    cr.setValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_4, value: '' } );
                }
            }
            if ( context.sublistId == SUBLIST_SL_INV_DETAILS && context.fieldId == FLD_COL_SL_SELECT ) {
                var batOpt1 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_1 } );
                var batOpt2 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_2 } );
                //console.log('batOpt2',batOpt2);
                var batOpt3 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_3 } );
                //  console.log('batOpt3',batOpt3);
                var batOpt4 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_4 } );
                //  console.log('batOpt4',batOpt4);
                var uniqueBatchGrp = {};
                var uniqueTransactions = [];

                // Get the number of lines from the field instead of the sublist
                // var count = cr.getLineCount({ sublistId: SUBLIST_SL_INV_DETAILS });
                //var count = cr.getValue({ sublistId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL });
                var count = cr.getValue( { fieldId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL } );
                //console.log('count',count);
                for ( var c = 0; c < count; c++ ) {
                    var prevSelected = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_SELECT, line: c } );
                    //console.log('prevSelected',prevSelected + ' c='+c);
                    if ( prevSelected == true || prevSelected == 'T' ) {
                        //console.log('prevSelected',prevSelected);
                        var internalId = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_INTERNAL_ID, line: c } );
                        //console.log('internalId',internalId);
                        if ( uniqueTransactions.indexOf( internalId ) == -1 )
                            uniqueTransactions.push( internalId );
                        var batchGrp = '';
                        var amt = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_AMOUNT, line: c } );

                        if ( amt == null || amt == '' ) {
                            amt = 0;
                        }

                        if ( batOpt1 != null && batOpt1 != '' ) {
                            var batch1FldName = batchFieldsData( batOpt1 ).name;
                            batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch1FldName, line: c } ) + '||';
                            //console.log('batch1FldName=' + batch1FldName + ' batch 1=' + cr.getValue({ sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch1FldName, line: c }));
                        }

                        if ( batOpt2 != null && batOpt2 != '' ) {
                            var batch2FldName = batchFieldsData( batOpt2 ).name;
                            batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch2FldName, line: c } ) + '||';
                            //console.log('batOpt2 column id = ' + 'custpage_' + batch2FldName);

                            //console.log('batch2FldName=' + batch2FldName + ' batch 2=' + cr.getValue({ sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch2FldName, line: c }));
                        }
                        //console.log('next');
                        if ( batOpt3 != null && batOpt3 != '' ) {
                            var batch3FldName = batchFieldsData( batOpt3 ).name;
                            //console.log('batOpt3 column id = ' + 'custpage_' + batch3FldName);
                            batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch3FldName, line: c } ) + '||';
                            //  console.log('batchGrp = ' + batchGrp);
                        }

                        if ( batOpt4 != null && batOpt4 != '' ) {
                            var batch4FldName = batchFieldsData( batOpt4 ).name;
                            //  console.log('batch4FldName column id = ' + 'custpage_' + batch4FldName);
                            batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch4FldName, line: c } ) + '||';
                        }

                        if ( !uniqueBatchGrp.hasOwnProperty( batchGrp ) ) {
                            uniqueBatchGrp[ batchGrp ] = {};
                            uniqueBatchGrp[ batchGrp ].amt = amt;
                        }
                        else {
                            uniqueBatchGrp[ batchGrp ].amt = parseFloat( uniqueBatchGrp[ batchGrp ].amt ) + parseFloat( amt );
                        }
                    }
                }

                var totAmt = 0;
                var totCItoCreate = 0;
                //console.log('uniqueBatchGrp=' + JSON.stringify(uniqueBatchGrp));

                for ( var prop in uniqueBatchGrp ) {
                    totCItoCreate++;
                    totAmt = parseFloat( totAmt ) + parseFloat( uniqueBatchGrp[ prop ].amt );
                }

                cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_TO_CREATE, value: totCItoCreate } );
                cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_AMT, value: totAmt } );

                if ( uniqueTransactions != null && uniqueTransactions != '' ) {
                    cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_INVOICES, value: uniqueTransactions.length } );
                    cr.setValue( { fieldId: FLD_SL_GRP_TRANSACTION_LINKS, value: uniqueTransactions } );
                }
                else {
                    cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_INVOICES, value: 0 } );
                    cr.setValue( { fieldId: FLD_SL_GRP_TRANSACTION_LINKS, value: null } );
                }
            }
        }

        function submitCreateCISL ( context ) {
            var cr = context.currentRecord;

            // Get the line count from the field instead of the sublist
            // var count = cr.getLineCount({ sublistId: SUBLIST_SL_INV_DETAILS });
            var count = cr.getValue( { fieldId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL } );
            var selectedLines = 0;

            for ( var c = 0; c < count; c++ ) {
                var selected = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_SELECT, line: c } );

                if ( selected == 'T' || selected == true ) {
                    selectedLines++;
                }
            }

            if ( selectedLines == 0 ) {
                alert( 'Please select atleast one line to Submit.' );
                return false;
            }
            else {
                var submitConfirmation = confirm( 'Selected transactions will be processed for Consolidation, Click OK to proceed.' );

                if ( submitConfirmation == true ) {
                    return true;
                }
                else {
                    return false;
                }
            }
        }

        function applyFilters ( cr, doNotapply ) {
            // var cr = NCR.get();

            if ( !cr ) {
                var cr = NCR.get();
            }

            var clientFlt = cr.getValue( { fieldId: FLD_SL_CLIENT } );
            var subsiFlt = cr.getValue( { fieldId: FLD_SL_SUBSIDIARY } );
            var medSegFlt = cr.getValue( { fieldId: FLD_SL_MEDIA_SEGMENT } );
            var lobFlt = cr.getValue( { fieldId: FLD_SL_LINE_OF_BUSIBNESS } );
            var currFlt = cr.getValue( { fieldId: FLD_SL_CURRENCY } );
            var contractFlt = cr.getValue( { fieldId: FLD_SL_CONTRACT } );
            var pubMedSupFlt = cr.getValue( { fieldId: FLD_SL_PUBLISHER_MEDIA_SIPPLIER } );
            var vendFlt = cr.getValue( { fieldId: FLD_SL_VENDOR } );
            var transTypeFlt = cr.getValue( { fieldId: FLD_SL_TRANSACTION_TYPE } );
            var dtFrmFlt = cr.getValue( { fieldId: FLD_SL_DATE_FROM } );
			if (dtFrmFlt != null && dtFrmFlt != '')
				dtFrmFlt = format.format({value:dtFrmFlt, type: format.Type.DATE});
			else
				dtFrmFlt='';
            var dtToFlt = cr.getValue( { fieldId: FLD_SL_DATE_TO } );
			if (dtToFlt != null && dtToFlt != '')
				dtToFlt = format.format({value:dtToFlt, type: format.Type.DATE});
			else
				dtToFlt='';
            var schedProjFlt = cr.getValue( { fieldId: FLD_SL_SCHED_NAME_PROJ } );
            var billMnthFlt = cr.getValue( { fieldId: FLD_SL_BILL_MONTH } );
            var adjustInvFlt = cr.getValue( { fieldId: FLD_SL_ADJUSTMENT_INVOICE } );
            var plcmntStr1Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_1 } );
            var plcmntStr2Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_2 } );
            var plcmntStr3Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_3 } );
            var plcmntStr4Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_4 } );
            var plcmntStr5Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_5 } );
            var plcmntStr6Flt = cr.getValue( { fieldId: FLD_SL_PLACEMENT_STR_6 } );
            var batOpt1 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_1 } );
            var batOpt2 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_2 } );
            var batOpt3 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_3 } );
            var batOpt4 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_4 } );
            var override = cr.getValue( { fieldId: FLD_SL_GRP_OVERRIDE } );
            var consolidateFlt = cr.getValue( { fieldId: FLD_SL_CONSOLIDATED } );

            if ( !doNotapply ) {
                if ( ( clientFlt == null || clientFlt == '' ) && ( contractFlt == null || contractFlt == '' ) && ( currFlt == null || currFlt == '' ) ) {
                    alert( 'Please enter value(s) for the fields: Client, Contract and Currency' );
                }
                else if ( ( clientFlt == null || clientFlt == '' ) && ( contractFlt != null && contractFlt != '' ) && ( currFlt == null || currFlt == '' ) ) {
                    alert( 'Please enter value for the fields: Client and Currency' );
                }
                else if ( clientFlt != null && clientFlt != '' && ( contractFlt == null || contractFlt == '' ) && ( currFlt == null || currFlt == '' ) ) {
                    alert( 'Please enter value for the fields: Contract and Currency' );
                }
                else if ( ( clientFlt == null || clientFlt == '' ) && ( contractFlt == null || contractFlt == '' ) && ( currFlt != null && currFlt != '' ) ) {
                    alert( 'Please enter value for the fields: Client and Contract' );
                }
                else if ( ( clientFlt == null || clientFlt == '' ) && ( contractFlt != null && contractFlt != '' ) && ( currFlt != null && currFlt != '' ) ) {
                    alert( 'Please enter value for the field: Client' );
                }
                else if ( clientFlt != null && clientFlt != '' && ( contractFlt == null || contractFlt == '' ) && ( currFlt != null && currFlt != '' ) ) {
                    alert( 'Please enter value for the field: Contract' );
                }
                else if ( clientFlt != null && clientFlt != '' && ( contractFlt != null && contractFlt != '' ) && ( currFlt == null || currFlt == '' ) ) {
                    alert( 'Please enter value for the field: Currency' );
                }
                else {
                    // var url = NURL.resolveScript({ scriptId: SCRIPT_CREATE_CLIENT_CI_SL, deploymentId: DEPLOY_CREATE_CLIENT_CI_SL });
                    // Get URL from hidden field
                    var url = cr.getValue( { fieldId: FLD_CREATE_CLIENT_CI_SL } );

                    url += '&clientFlt=' + clientFlt + '&subsiFlt=' + subsiFlt + '&medSegFlt=' + medSegFlt + '&lobFlt=' + lobFlt + '&currFlt=' + currFlt;
                    url += '&contractFlt=' + contractFlt + '&pubMedSupFlt=' + pubMedSupFlt + '&vendFlt=' + vendFlt + '&transTypeFlt=' + transTypeFlt + '&dtFrmFlt=' + dtFrmFlt + '&dtToFlt=' + dtToFlt;
                    url += '&schedProjFlt=' + schedProjFlt + '&billMnthFlt=' + billMnthFlt + '&adjustInvFlt=' + adjustInvFlt + '&plcmntStr1Flt=' + plcmntStr1Flt + '&plcmntStr2Flt=' + plcmntStr2Flt + '&plcmntStr3Flt=' + plcmntStr3Flt;
                    url += '&plcmntStr4Flt=' + plcmntStr4Flt + '&plcmntStr5Flt=' + plcmntStr5Flt + '&plcmntStr6Flt=' + plcmntStr6Flt + '&batOpt1=' + batOpt1 + '&batOpt2=' + batOpt2 + '&batOpt3=' + batOpt3 + '&batOpt4=' + batOpt4;
                    url += '&isOverride=' + override + '&applyFilters=T' + '&cons=' + consolidateFlt;

                    console.log( 'url = ' + url );
                    window.open( url, '_self' );
                }
            }
            else {
                // var url = nlapiResolveURL('SUITELET', SCRIPT_CREATE_CLIENT_CI_SL, DEPLOY_CREATE_CLIENT_CI_SL });
                var url = cr.getValue( { fieldId: FLD_CREATE_CLIENT_CI_SL } );

                url += '&clientFlt=' + clientFlt + '&subsiFlt=' + subsiFlt + '&medSegFlt=' + medSegFlt + '&lobFlt=' + lobFlt + '&currFlt=' + currFlt;
                url += '&contractFlt=' + contractFlt + '&pubMedSupFlt=' + pubMedSupFlt + '&vendFlt=' + vendFlt + '&transTypeFlt=' + transTypeFlt + '&dtFrmFlt=' + dtFrmFlt + '&dtToFlt=' + dtToFlt;
                url += '&schedProjFlt=' + schedProjFlt + '&billMnthFlt=' + billMnthFlt + '&adjustInvFlt=' + adjustInvFlt + '&plcmntStr1Flt=' + plcmntStr1Flt + '&plcmntStr2Flt=' + plcmntStr2Flt + '&plcmntStr3Flt=' + plcmntStr3Flt;
                url += '&plcmntStr4Flt=' + plcmntStr4Flt + '&plcmntStr5Flt=' + plcmntStr5Flt + '&plcmntStr6Flt=' + plcmntStr6Flt + '&batOpt1=' + batOpt1 + '&batOpt2=' + batOpt2 + '&batOpt3=' + batOpt3 + '&batOpt4=' + batOpt4;
                url += '&isOverride=' + override + '&applyFilters=F' + '&cons=' + consolidateFlt;

                console.log( 'url = ' + url );
                window.open( url, '_self' );
            }
        }

        function markAll ( cr ) {
            // var cr = NCR.get();
            /*if (!cr) {
                var cr = NCR.get();
            }*/
            var cr = NCR.get();
            console.log( 'cr', cr );
            var batOpt1 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_1 } );
            var batOpt2 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_2 } );
            var batOpt3 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_3 } );
            var batOpt4 = cr.getValue( { fieldId: FLD_SL_GRP_BATCH_OPTION_4 } );
            var uniqueBatchGrp = {};
            var uniqueTransactions = [];

            // Get the line count from the field instead of the sublist
            // var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS });
            //var count = cr.getValue({ sublistId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL });
            var count = cr.getValue( { fieldId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL } );
            console.log( 'markAll count', count );

            for ( var c = 0; c < count; c++ ) {
                //cr.setSublistValue({ sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_SELECT, line: c, value: 'T' });
                cr.selectLine( { sublistId: SUBLIST_SL_INV_DETAILS, line: c } );
                //transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'memo',value: getMemoLine});


                cr.setCurrentSublistValue( {
                    sublistId: SUBLIST_SL_INV_DETAILS,
                    fieldId: FLD_COL_SL_SELECT,
                    value: true,
                    ignoreFieldChange: true
                } );
                cr.commitLine( { sublistId: SUBLIST_SL_INV_DETAILS } );

                var internalId = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_INTERNAL_ID, line: c } );

                if ( uniqueTransactions.indexOf( internalId ) == -1 )
                    uniqueTransactions.push( internalId );

                var batchGrp = '';
                var amt = cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_AMOUNT, line: c } );

                if ( amt == null || amt == '' ) {
                    amt = 0;
                }

                if ( batOpt1 != null && batOpt1 != '' ) {
                    var batch1FldName = batchFieldsData( batOpt1 ).name;
                    batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch1FldName, line: c } ) + '||';
                }

                if ( batOpt2 != null && batOpt2 != '' ) {
                    var batch2FldName = batchFieldsData( batOpt2 ).name;
                    batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch2FldName, line: c } ) + '||';
                }

                if ( batOpt3 != null && batOpt3 != '' ) {
                    var batch3FldName = batchFieldsData( batOpt3 ).name;
                    batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch3FldName, line: c } ) + '||';
                }

                if ( batOpt4 != null && batOpt4 != '' ) {
                    var batch4FldName = batchFieldsData( batOpt4 ).name;
                    batchGrp += cr.getSublistValue( { sublistId: SUBLIST_SL_INV_DETAILS, fieldId: 'custpage_' + batch4FldName, line: c } ) + '||';
                }

                if ( !uniqueBatchGrp.hasOwnProperty( batchGrp ) ) {
                    uniqueBatchGrp[ batchGrp ] = {};
                    uniqueBatchGrp[ batchGrp ].amt = amt;
                }
                else {
                    uniqueBatchGrp[ batchGrp ].amt = parseFloat( uniqueBatchGrp[ batchGrp ].amt ) + parseFloat( amt );
                }
            }

            var totAmt = 0;
            var totCItoCreate = 0;

            for ( var prop in uniqueBatchGrp ) {
                totCItoCreate++;
                totAmt = parseFloat( totAmt ) + parseFloat( uniqueBatchGrp[ prop ].amt );
            }

            cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_TO_CREATE, value: totCItoCreate } );
            cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_AMT, value: totAmt } );

            if ( uniqueTransactions != null && uniqueTransactions != '' ) {
                cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_INVOICES, value: uniqueTransactions.length } );
                cr.setValue( { fieldId: FLD_SL_GRP_TRANSACTION_LINKS, value: uniqueTransactions } );
            }
        }

        function unmarkAll () {
            // Get the line count from the field instead of the sublist
            // var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS });
            if ( !cr ) {
                var cr = NCR.get();
            }

            //var count = cr.getValue({ sublistId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL });
            var count = cr.getValue( { fieldId: FLD_SL_GRP_INV_LINES_AVAIL_CONSOL } );

            for ( var c = 0; c < count; c++ ) {
                //cr.setSublistValue({ sublistId: SUBLIST_SL_INV_DETAILS, fieldId: FLD_COL_SL_SELECT, line: c, value: 'F' });

                cr.selectLine( { sublistId: SUBLIST_SL_INV_DETAILS, line: c } );
                //transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'memo',value: getMemoLine});


                cr.setCurrentSublistValue( {
                    sublistId: SUBLIST_SL_INV_DETAILS,
                    fieldId: FLD_COL_SL_SELECT,
                    value: false,
                    ignoreFieldChange: true
                } );
                cr.commitLine( { sublistId: SUBLIST_SL_INV_DETAILS } );
            }

            cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_TO_CREATE, value: '' } );
            cr.setValue( { fieldId: FLD_SL_GRP_TOT_CI_AMT, value: '' } );
            cr.setValue( { fieldId: FLD_SL_GRP_TRANSACTION_LINKS, value: null } );
        }

        function batchFieldsData ( batchId ) {
            var batchFields = {};
            batchFields[ 1 ] = {
                'name': 'custcol_appf_bill_month',
                'label': 'Bill Month'
            };
            batchFields[ 2 ] = {
                'name': '',
                'label': 'Client Objective'
            };
            batchFields[ 3 ] = {
                'name': 'custcol_appf_do_client_po',
                'label': 'Client PO Number'
            };
            batchFields[ 4 ] = {
                'name': '',
                'label': 'DMA'
            };
            batchFields[ 5 ] = {
                'name': '',
                'label': 'Insertion Date'
            };
            batchFields[ 6 ] = {
                'name': 'custbody_appf_print_isodate',
                'label': 'Issue Date'
            };
            batchFields[ 7 ] = {
                'name': 'custcol_appf_publisher',
                'label': 'Media Supplier',
                'issel': 'T'
            };
            batchFields[ 8 ] = {
                'name': 'custcol_appf_placement1',
                'label': 'Placement_String 1'
            };
            batchFields[ 9 ] = {
                'name': 'custcol_appf_placement2',
                'label': 'Placement_String 2'
            };
            batchFields[ 10 ] = {
                'name': 'custcol_appf_placement3',
                'label': 'Placement_String 3'
            };
            batchFields[ 11 ] = {
                'name': 'custcol_appf_placement4',
                'label': 'Placement_String 4'
            };
            batchFields[ 12 ] = {
                'name': 'custcol_appf_placement5',
                'label': 'Placement_String 5'
            };
            batchFields[ 13 ] = {
                'name': 'custcol_appf_placement6',
                'label': 'Placement_String 6'
            };
            batchFields[ 14 ] = {
                'name': 'custbody_appf_print_mediatype',
                'label': 'Reporting Media Type',
                'issel': 'T'
            };
            batchFields[ 15 ] = {
                'name': 'entity',
                'label': 'Schedule Name',
                'issel': 'T'
            };
            batchFields[ 16 ] = {
                'name': 'custcol_appf_print_servicedate',
                'label': 'Service Date'
            };
            batchFields[ 17 ] = {
                'name': 'custcol_appf_do_dds_estimate',
                'label': 'Estimate # (DoMedia)'
            };
            batchFields[ 18 ] = {
                'name': 'custcol_appf_do_estimatenum',
                'label': 'Estimate # (Strata)'
            };
            batchFields[ 19 ] = {
                'name': 'custcol_appf_do_dds_product',
                'label': 'Product Code (DoMedia)'
            };
            batchFields[ 20 ] = {
                'name': 'custcol_appf_print_dds',
                'label': 'Product Code (Strata)'
            };
            batchFields[ 21 ] = {
                'name': 'custcol_appf_do_market',
                'label': 'Market'
            };
            batchFields[ 22 ] = {
                'name': 'custcol_appf_po_vendor_name',
                'label': 'Vendor'
            };
            batchFields[ 23 ] = {
                'name': 'custcol_appf_strata_product',
                'label': 'Strata Product'
            };
            return batchFields[ batchId ];
        }

        return {
            saveRecord: submitCreateCISL,
            fieldChanged: createCCIFieldChange,
            applyFilters: applyFilters,
            markAll: markAll,
            unmarkAll: unmarkAll
        };
    }
);