/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Updates the Invoice Date with the CI Date
 *
 * Author: Marlon
 * Date: Dec 18, 2020
 */
define(
    [
        'N/log',
        'N/record',
        'N/runtime',
        'N/search'
    ],
    
    function (
        LOG,
        RECORD,
        RUNTIME,
        SEARCH
    ) {
        
        function _getAllResults(srch) {
            var LOG_TITLE = '_getAllResults';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var ISPROD = true;
            var results = [], res = [];
            
            var ixSize = ISPROD == true ? 1000 : 5;
            var limit = ISPROD == true ? -1 : 8;
            var ixStart = 0, ixEnd = ixSize;
            var runAgain = true;
            
            LOG.debug({
                title: LOG_TITLE,
                details: 'ISPROD = ' + ISPROD +
                    ', ixSize = ' + ixSize +
                    ', limit = ' + limit
            });
            
            while(runAgain == true) {
                res = srch.run().getRange({ start: ixStart, end: ixEnd });
                
                results = results.concat(res);
                
                runAgain = (
                    (res.length < ixSize) ||
                    ((limit > 0) && (results.length >= limit))
                ) == true ? false : true;
                
                ixStart += ixSize;
                ixEnd += ixSize;
                LOG.debug({
                    title: LOG_TITLE,
                    details: 'results.length = ' + results.length +
                        ', res.length = ' + res.length +
                        ', runAgain = ' + runAgain
                });
            }
            
            LOG.debug({ title: LOG_TITLE, details: 'END' });
            return results;
        }
        
        function _getInputData() {
            var LOG_TITLE = '_getInputData';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var script = RUNTIME.getCurrentScript();
            var srchId = script.getParameter({ name: 'custscript_ci_inv_mismatch_srch' });
            var results = [];
            
            if (srchId) {
                var srch = SEARCH.load({ id: srchId });
                results = _getAllResults(srch);
            }
            
            
            
            LOG.audit({ title: LOG_TITLE, details: 'results.length = ' + results.length });
            LOG.debug({ title: LOG_TITLE, details: 'END' });
            return results;
        }
        
        function _reduce(context) {
            var LOG_TITLE = '_reduce';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            LOG.debug({ title: LOG_TITLE, details: 'key = ' + context.key + ', value = ' + context.values[0] });
            
            var val = JSON.parse(context.values[0]);
            var invId = val.id;
            var ciDate = val.values['CUSTCOL_APPF_CI_RECORD.custrecord_appf_ci_date'];
            LOG.debug({ title: LOG_TITLE, details: 'invId = ' + val.id + ', ciDate = ' + ciDate });
            
            try {
                RECORD.submitFields({
                    type: val.recordType,
                    id: val.id,
                    values: {
                        'trandate': ciDate
                    }
                });
                LOG.audit({ title: LOG_TITLE, details: 'Successfully synced invoice ' + val.values.tranid + ' to CI Date = ' + ciDate });
            }
            catch (ex) {
                LOG.debug({ title: LOG_TITLE, details: ex.toString() });
            }
            
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        function _summarize(context) {
            var LOG_TITLE = '_summarize';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            LOG.audit({ title: LOG_TITLE, details: 'Done executing' });
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        return {
            getInputData: _getInputData,
            reduce: _reduce,
            summarize: _summarize
        };
    }
);
