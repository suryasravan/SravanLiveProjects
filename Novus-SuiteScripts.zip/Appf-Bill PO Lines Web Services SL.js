var CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG = 'customrecord_appf_bill_po_lines_log';
var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';
var FLD_CR_TOTAL_POS_TO_PROCESS = 'custrecord_appf_bill_po_lines_to_process';
var FLD_CR_PROCESSED_PERCENT = 'custrecord_appf_bill_po_lines_percent';
var FLD_CR_CREATED = 'custrecord_appf_bill_po_lines_created_by';
var FLD_CR_BILL_POS_BATCH_STATUS = 'custrecord_appf_bill_po_lines_status';
var FLD_CR_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
var FLD_CR_STATUS_FILE = 'custrecord_appf_bill_po_lines_status_fil';
var FLD_CR_ERROR_LOG = 'custrecord_appf_bill_po_lines_error_log';
var FLD_CR_PO_LINK = 'custrecord_appf_bill_po_lines_po_link';
var FLD_CR_BILL_LINK = 'custrecord_appf_bill_po_lines_bill_link';

var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED_SUCCESSFULLY = '4';
var STATUS_COMPLETED_WITH_ERRORS = '5';

var FLD_COL_BILL_PO_LINE = 'custcol_appf_bill_po_line';
var FLD_COL_UNBILLED_AMOUNT = 'custcol_appf_unbilled_amount';

var IMPORT_CSV_INITIATE_BILL_PO_LINES = 'custimport_initiate_bill_po_lines';

function suiteletSoap(request, response) {
	try{
		
		//nlapiLogExecution('debug', 'ws sl triggered', 'ws sl triggered');
		var customRecId = request.getParameter('customRecId');
		nlapiLogExecution('debug', 'customRecId', customRecId);
		var dataObj = request.getBody();
		var selectedPOs = [];
		var poUnbilledAmtObj = {};
	if(dataObj != null && dataObj != '' && customRecId != null && customRecId != ''){	
		var customRec = nlapiLoadRecord(CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG, customRecId);
		var errorFileData = 'PO ID\n';
		var isError = false;
		var errorLog = customRec.getFieldValue(FLD_CR_ERROR_LOG);
		if(errorLog == null || errorLog == '')
			errorLog = '';
		
	  var stSOSOAPRequest = "";
	stSOSOAPRequest += "<soapenv:Envelope xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:platformCore='urn:core_2019_2.platform.webservices.netsuite.com' xmlns:platformMsgs='urn:messages_2019_2.platform.webservices.netsuite.com'>";
	stSOSOAPRequest += "<soapenv:Header>";
    stSOSOAPRequest += "<passport xsi:type='platformCore:Passport'>";
       stSOSOAPRequest += "<email xsi:type='xsd:string'>ymanikanta@appficiencyinc.com</email>";
        stSOSOAPRequest += "<password xsi:type='xsd:string'>appficiency_12</password>";
        stSOSOAPRequest += "<account xsi:type='xsd:string'>3619984</account>";
    stSOSOAPRequest += "</passport>";
    stSOSOAPRequest += "<applicationInfo xsi:type='platformMsgs:ApplicationInfo'>";
        stSOSOAPRequest += "<applicationId xsi:type='xsd:string'>4BA024A5-BCAE-42BC-BB64-2B6C4A156B80</applicationId>";
    stSOSOAPRequest += "</applicationInfo>";
stSOSOAPRequest += "</soapenv:Header>";
	stSOSOAPRequest += "<soapenv:Body>";
			dataObj = JSON.parse(dataObj);
			nlapiLogExecution('debug', 'dataObj', JSON.stringify(dataObj));
			stSOSOAPRequest += "<addList xmlns='urn:messages_2019_2.platform.webservices.netsuite.com'>";
			for(var vend in dataObj){
				nlapiLogExecution('debug', 'vend', vend);
				
			stSOSOAPRequest += '<record xsi:type="ns6:VendorBill" xmlns:ns6="urn:purchases_2019_2.transactions.webservices.netsuite.com">'; 
				stSOSOAPRequest += '<ns6:entity internalId="'+vend+'" xsi:type="ns7:RecordRef" xmlns:ns7="urn:core_2019_2.platform.webservices.netsuite.com"/>';    
				stSOSOAPRequest += '<ns6:purchaseOrderList xsi:type="ns8:RecordRefList" xmlns:ns8="urn:core_2019_2.platform.webservices.netsuite.com">'; 
				var poIds = dataObj[vend].poIds;
				for(var p=0; p< poIds.length; p++){
					try{
					if(selectedPOs.indexOf(poIds[p]) == -1)
						selectedPOs.push(poIds[p]);
					nlapiLogExecution('debug', 'poId', poIds[p]);
                  stSOSOAPRequest += '<ns8:recordRef internalId="'+poIds[p]+'" type="purchaseOrder" xsi:type="ns8:RecordRef"/>'; 
					}catch(e){
						isError = true;
						errorFileData += poIds[p]+'\n';
						if ( e instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
							errorLog += 'system error while Processing the PO ID : '+poIds[p]+' ' + e.getDetails();
						}
						else{
							nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
							errorLog += 'unexpected error while Processing the PO ID : '+poIds[p]+' ' + e.toString();
						}
					}				  
				}
				stSOSOAPRequest += '</ns6:purchaseOrderList>';   
				  stSOSOAPRequest += '</record>';    
         
			} 
      stSOSOAPRequest += '</addList>'; 
      stSOSOAPRequest += "</soapenv:Body>";

stSOSOAPRequest += '</soapenv:Envelope>';
//stSOSOAPRequest = encodeURIComponent(stSOSOAPRequest);
	var salesUpdateResponse = callNetsuiteWebService(stSOSOAPRequest, 'addList');
	var stsalesUpdateResponse = salesUpdateResponse.getBody();
	nlapiLogExecution('debug', 'stsalesUpdateResponse', stsalesUpdateResponse);
	var xmldoc = nlapiStringToXML(stsalesUpdateResponse);
	var xmlNodeList = xmldoc.getElementsByTagName('baseRef');
	var vbIds = [];
	for (var s = 0; s < xmlNodeList.getLength(); s++)
	{
		var singleBaseRef = xmlNodeList.item(s);
		for (var j = 0; j < singleBaseRef.attributes.getLength(); j++)
		{
			var attributeName= singleBaseRef.attributes.item(j).name;
			var attributeValue= singleBaseRef.attributes.item(j).value;
			if (attributeName.toLowerCase() == 'internalid')
			{
				vbIds.push(attributeValue);
				break;
			}
		}
	}
	vbIds = eliminateDuplicates(vbIds);
	nlapiLogExecution('debug', 'vbIds', JSON.stringify(vbIds));
	var vendorBillsSubmitted = 0;
	for(var v=0; v<vbIds.length; v++){
		var vendBill = nlapiLoadRecord('vendorbill', vbIds[v]);
		vendBill.setFieldValue(FLD_BILL_PO_LINES_EXEC_LOG, customRecId);
		var count = vendBill.getLineItemCount('item');
		for(var l=1; l<=count; l++){
			var billPOLine = vendBill.getLineItemValue('item', FLD_COL_BILL_PO_LINE, l);
			if(!billPOLine){
				vendBill.removeLineItem('item', l);
			}
			else{
				var unbilledAmt = vendBill.getLineItemValue('item', FLD_COL_UNBILLED_AMOUNT, l);
				vendBill.setLineItemValue('item', 'quantity', l, unbilledAmt);
			}
		}
		nlapiSubmitRecord(vendBill, true, true);
		vendorBillsSubmitted++;
	}		
		customRec.setFieldValue(FLD_CR_ERROR_LOG, errorLog);
		customRec.setFieldValue(FLD_CR_TOTAL_BILLS_CREATED, vendorBillsSubmitted);
		if(errorLog != null && errorLog != '')
			customRec.setFieldValue(FLD_CR_BILL_POS_BATCH_STATUS, STATUS_COMPLETED_WITH_ERRORS);
		else
			customRec.setFieldValue(FLD_CR_BILL_POS_BATCH_STATUS, STATUS_COMPLETED_SUCCESSFULLY);
		customRec.setFieldValue(FLD_CR_BILL_LINK, vbIds);
		if(isError){
			var timestamp = new Date().getTime();
			var errorFileCreate=nlapiCreateFile('Error_Data_'+timestamp+'.csv','CSV',errorFileData);
			errorFileCreate.setFolder(poFolderId);
			var errorFileID= nlapiSubmitFile(errorFileCreate);
			
		}
		nlapiSubmitRecord(customRec, true, true);
	}
 }
catch(e)
{
	if ( e instanceof nlobjError )
		nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
	else
		nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
}
}
 
function callNetsuiteWebService(stSoapRequest, stSoapAction, stSessionCookie, stCookieInfo){
    var stWebServiceConsumer = 'https://3619984.suitetalk.api.netsuite.com/services/NetSuitePort_2019_2';
    if (isEmpty(stSoapRequest) || isEmpty(stSoapAction)) {
  throw nlapiCreateError('10014', 'SOAP Request and Action should not be empty.');
 }
    var stFinalCookie = stCookieInfo;
    if (isEmpty(stFinalCookie)) {
  stFinalCookie = 'NS_VER=2019.1.0';
 }
 var soapHeaders = new Array();
 soapHeaders['User-Agent-x'] = 'SuiteScript-Call';
 soapHeaders['SOAPAction'] = stSoapAction;
 soapHeaders['Host'] = "webservices.netsuite.com";
 if (!isEmpty(stSessionCookie)) {
  soapHeaders['Cookie'] = '$Version=0; ' + stFinalCookie + '; ' + stSessionCookie;
 }
 var soapResponse = nlapiRequestURL(stWebServiceConsumer, stSoapRequest, soapHeaders);
 return soapResponse;
}
function isEmpty( inputStr ) { 
 if ( null == inputStr || "" == inputStr ) 
 { return true; } 
 return false; 
}

function randomString(length) {
  var text = "";
  var possible =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}


function getCurrentDateTime(){
var countries={};

countries['Etc/GMT+12']=-12;
countries['Pacific/Samoa']=-11;
countries['Pacific/Honolulu']=-10;
countries['America/Anchorage']=-9;
countries['America/Los_Angeles']=-8;
countries['America/Tijuana']=-8;
countries['America/Denver']=-7;
countries['America/Phoenix']=-7;
countries['America/Chihuahua']=-7;
countries['America/Chicago']=-6;
countries['America/Regina']=-6;
countries['America/Guatemala']=-6;
countries['America/Mexico_City']=-6;
countries['America/New_York']=-5;
countries['US/East-Indiana']=-5;
countries['America/Bogota']=-5;
countries['America/Caracas']=-4.5;
countries['America/Halifax']=-4;
countries['America/La_Paz']=-4;
countries['America/Manaus']=-4;
countries['America/Santiago']=-4;
countries['America/St_Johns']=-3.5;
countries['America/Sao_Paulo']=-3;
countries['America/Buenos_Aires']=-3;
countries['Etc/GMT+3']=-3;
countries['America/Godthab']=-3;
countries['America/Montevideo']=-3;
countries['America/Noronha']=-2;
countries['Etc/GMT+1']=-1;
countries['Atlantic/Azores']=-1;
countries['Europe/London']=0;
countries['GMT']=0;
countries['Atlantic/Reykjavik']=0;
countries['Europe/Warsaw']=+1;
countries['Europe/Paris']=+1;
countries['Etc/GMT-1']=+1;
countries['Europe/Amsterdam']=+1;
countries['Europe/Budapest']=+1;
countries['Africa/Cairo']=+2;
countries['Europe/Istanbul']=+2;
countries['Asia/Jerusalem']=+2;
countries['Asia/Amman']=+2;
countries['Asia/Beirut']=+2;
countries['Africa/Johannesburg']=+2;
countries['Europe/Kiev']=+2;
countries['Europe/Minsk']=+2;
countries['Africa/Windhoek']=+2;
countries['Asia/Riyadh']=+3;
countries['Europe/Moscow']=+3;
countries['Asia/Baghdad']=+3;
countries['Africa/Nairobi']=+3;
countries['Asia/Tehran']=+3.5;
countries['Asia/Muscat']=+4;
countries['Asia/Baku']=+4;
countries['Asia/Yerevan']=+4;
countries['Etc/GMT-3']=+4;
countries['Asia/Kabul']=+4.5;
countries['Asia/Karachi']=+5;
countries['Asia/Yekaterinburg']=+5;
countries['Asia/Tashkent']=+5;
countries['Asia/Calcutta']=+5.5;
countries['Asia/Katmandu']=+5.75;
countries['Asia/Almaty']=+6;
countries['Asia/Dhaka']=+6;
countries['Asia/Rangoon']=+6.5;
countries['Asia/Bangkok']=+7;
countries['Asia/Krasnoyarsk']=+7;
countries['Asia/Hong_Kong']=+8;
countries['Asia/Kuala_Lumpur']=+8;
countries['Asia/Taipei']=+8;
countries['Australia/Perth']=+8;
countries['Asia/Irkutsk']=+8;
countries['Asia/Manila']=+8;
countries['Asia/Seoul']=+9;
countries['Asia/Tokyo']=+9;
countries['Asia/Yakutsk']=+9;
countries['Australia/Darwin']=+9.5;
countries['Australia/Adelaide']=+9.5;
countries['Australia/Sydney']=+10;
countries['Australia/Brisbane']=+10;
countries['Australia/Hobart']=+10;
countries['Pacific/Guam']=+10;
countries['Asia/Vladivostok']=+10;
countries['Asia/Magadan']=+11;
countries['Pacific/Kwajalein']=+12;
countries['Pacific/Auckland']=+12;
countries['Pacific/Tongatapu']=+13;

var companyInfo=nlapiLoadConfiguration('companyinformation');
	var timeZone=companyInfo.getFieldValue('timezone');
	var offSet=countries[''+timeZone+''];
	var dt=new Date();
	var utc = dt.getTime() + (dt.getTimezoneOffset() * 60000);
	var pst = new Date(utc + (3600000*offSet));
	
	return pst;
	
}

function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}