/**
*Script Name: Appf-Connex Contract to NetSuite Contract sc
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Connext Contract and pushes the Contract from those messages into netsuite and creates or updates as Contract records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
var SPARAM_CONNEX_CONTRACT='customscript_appf_connex_contrac_2_ns_sc'
function getContractRESTlet(dataIn)
{
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
             nlapiScheduleScript(SPARAM_CONNEX_CONTRACT,null)
	return 'RESTlet successfully connected.';
		  }
            