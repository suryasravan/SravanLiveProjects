/**
*Script Name: Appf-Strata Project to Netsuite Project
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Strata Project and pushes the clients from those messages into netsuite and creates or updates as Customer records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_strata_spo_project_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecordappf_strata_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_strata_spot_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecord_appf_strata_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_strata_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_strata_project_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_response_strats_status';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_appf_ns_response';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_order_strata_correl_id';
 var CUSTOMRECORD_FLD_CONNEX_NS_RESP = 'custrecord_appf_ns_strat_projec_response';
 // Integration Relatedcustrecord_appf_order_correl_id
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
// Integration Related
 var QUEUE_CONNEX_CLIENT_INBOUND = 'novusmedia_strata_project_in';
 //novusmedia_connex_client_in
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'novusmedia_placement_change';
 var URL_BASE = 'https://novusmediallc-dev.servicebus.windows.net/';
 var FLD_BUYING_SYSTEM_ID='custentity_appf_buyingsystem_id';
   var FLD_LAST_UPDATE_DATE_TIME = 'custentity_appf_integr_lastupdatedate';

 var NS_OB_RESPONSE_PROPERTY='Novus.Azure.WebJobs.NetSuite.Dtos.ProjectResponse'

var SCRIPT_SCHEDULED='customscript_appf_strata_project_2_ns_sc';

function createProjectScheduled(type) 
  {	
	
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
		var context = nlapiGetContext();

		   var messagesFound=true
    while (messagesFound == true) 
	{
	var usageRemaining = context.getRemainingUsage();
	 var idForResponse = '';
		var buyingSystemIDResponseValue=''
		var d = new Date();
        var UTCDate= d.toISOString();
		var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey',"Date":UTCDate,"Content-Type": 'application/xml'};
		var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
		var mainObj = responseData.getBody()+'';
            nlapiLogExecution('debug','mainObj content',mainObj);
		var CorrelationIdProp='NServiceBus.CorrelationId'
		var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

		var CorrelationId=responseData.getHeader(CorrelationIdProp)  
		var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
        var Status=''
		var Status1=''
		var scriptStatus=''
var fileData=''
        if(mainObj==null || mainObj=='')
        {
			 messagesFound=false;
			 Status='FAILED'+'(Empty Message)'
			 scriptStatus='FAILED'
			 Status1='FAILED'+'(Empty Message)'
        }
        else
        {
		   try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_BUYING_SYSTEM_ID))
					{
						buyingSystemIDResponseValue=mainObj[FLD_BUYING_SYSTEM_ID];
						nlapiLogExecution('debug', 'buyingSystemIDResponseValue:', buyingSystemIDResponseValue);
					}
					Status='SUCCESS'
			   } 
			catch (e) 
			{
			   Status='FAILED'+'(invalid JSON)'
			   scriptStatus='FAILED'
				Status1='FAILED'+'(invalid JSON)'
			}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var integrationResponseObj={}
								
		if(responseData.getCode()!='200' && responseData.getCode()!='201')
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
		   var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS,'FAILED')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   nlapiSubmitRecord(integrationRecord,true,true)
		   }
		   
		}    
		else
        {
			var nsClientRecord='';
			var isNewRecord = true; 
           var internalId=''
		    var isUpdateRecord = true; 
			 var nsCreationMsg = '';
			 try
			   {
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsClientRecord=nlapiCreateRecord('job')
               if(mainObj.hasOwnProperty('companyname'))
				 {
					 var CompanyName=mainObj['companyname']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					if(CompanyName!=null && CompanyName!='')
					{
                      CompanyName=CompanyName.trim();
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter('jobname',null,'is',CompanyName));
							 
							  var custRecord=nlapiSearchRecord('job', null, nsfils);
if (custRecord != null && custRecord != '')
							  {								
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);

var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
					}
                    }
					 
				 }
			}
			else
			{
			
				var internalId=mainObj['id']
				nlapiLogExecution('debug', 'internalId',  internalId);
				if(internalId==null || internalId=='' || internalId=='null')
				{
				  nsClientRecord=nlapiCreateRecord('job')
                   if(mainObj.hasOwnProperty('companyname'))
				 {
					 var CompanyName=mainObj['companyname']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					if(CompanyName!=null && CompanyName!='')
					{
                      CompanyName=CompanyName.trim();
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter('jobname',null,'is',CompanyName));
							 
							  var custRecord=nlapiSearchRecord('job', null, nsfils);
if (custRecord != null && custRecord != '')
							  {								
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);
					var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
                              }
					}
					 
				 }
				}
				else
				{
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);
					var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
				}
			}
			   }
			    catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
		   var nsClientRecordID=null;
		  
			if(Status==null || Status=='' || Status=='SUCCESS')
		   {
				try{
					 if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {	
					for (var parentProp in mainObj)
					{
						// nlapiLogExecution('debug', ' parentProp',  parentProp);
			          //  var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=nsClientRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!=''))
						 {
						      if(parentProp!='otherrelationships' && parentProp!='version')
			                  nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])	
						  
						 }
		            }					  
		               nsClientRecordID = nlapiSubmitRecord(nsClientRecord,true,true);
					   }
					   else
					   {
						if(nsCreationMsg==null || nsCreationMsg=='')
                          {
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
                             scriptStatus='WARNING'
                          }
					   }
				}
				catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				}                       					   
				if (nsClientRecordID != null)
				{
					var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') 
						  isInActiveRecord=true
					}
					if(!isInActiveRecord)
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS,CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsClientRecordID, 'SUCCESS']);
				}					   
				else
				{
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus+":"+nsCreationMsg]); 						   
				}							
				if(nsClientRecordID!=null && nsClientRecordID!='')
				{
				idForResponse=nsClientRecordID;
					
                    scriptStatus='SUCCESS'
                        // integrationResponseObj.internalId=recordId  				 				  
					if (responseData.getCode() == '200' || responseData.getCode() == '201')
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					  else
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
					
				}
            }
        }				   
		if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
		{			
			if(buyingSystemIDResponseValue==null || buyingSystemIDResponseValue=='')
				   buyingSystemIDResponseValue=''			   
			integrationResponseObj.EntityId=buyingSystemIDResponseValue
			
			if(idForResponse==null || idForResponse=='')
				idForResponse=''
			  integrationResponseObj.NetSuiteId=idForResponse
          
			if(Status1!=null && Status1!='')
				integrationResponseObj.IntegrationResponseStatus=Status1
			else
				integrationResponseObj.IntegrationResponseStatus=scriptStatus
		 
			if(nsCreationMsg==null || nsCreationMsg=='')
				 nsCreationMsg=''
			integrationResponseObj.IntegrationResponseMessage=nsCreationMsg
	nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_RESP], [JSON.stringify(integrationResponseObj)]);		   
			var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
			var body = JSON.stringify(integrationResponseObj);
			var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'};
			//HEADERS.scriptStatus=scriptStatus
			if(CorrelationId==null || CorrelationId=='')
				CorrelationId=''
			HEADERS['NServiceBus.CorrelationId']=CorrelationId
			HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
			var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

		}
		if(usageRemaining<=1000)
	{
	nlapiScheduleScript(SCRIPT_SCHEDULED,null)
	}		   
	}
                          
	}