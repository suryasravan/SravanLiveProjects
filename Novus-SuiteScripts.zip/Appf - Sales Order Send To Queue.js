/*
* Script Name : Appf - Send Message To Queue
* Script Type : UserEvent
* Event Type  : 
* Description :
* Company     :	Appficiency Inc.
*/
 var FLD_COL_TTB_UPDATED_PROJECT='custcol_appf_ttb_update_project';
 var CUSTOMRECORD_APPF_OUT_BOUND_MEDIA_RECS='customrecord_outbound_domedia_pwp_log';
 var CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTENTS ='custrecord_appf_jsonconetnt_out_pwp';
 var CUSTOMRECORD_FLD_APPF_PWP_LINK='custrecordpwp_record';
 var CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE ='custrecord_appf_azureresponse_pwp';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME='custrecord_appf_strata_vendor_out_pwp';
function userEvent(type)
{
 if(type=='create')
	{
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var payRec=nlapiLoadRecord(recordType,recordId)
		var payRecFields=payRec.getAllFields()
			var main1={}
		for(var i=0;i<payRecFields.length;i++) 
       {
		     //var main={}
			var fundingRecId=payRecFields[i]
			var fundingRecValu=payRec.getFieldValue(fundingRecId)
			if(fundingRecValu==null)
		      fundingRecValu=''
		      main1[fundingRecId]=fundingRecValu
		} 
		
var url = 'https://novusmediallc-dev.servicebus.windows.net/mercury_orderstat_out/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'};
//var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');
//nlapiLogExecution('debug', 'responseData',responseData);
//var responseData45=responseData.getBody()
		//nlapiLogExecution('debug', ' responseData45',responseData45);
		//nlapiSendEmail(1224,'laxmikanth@cloudalp.com','test',JSON.stringify(main1),null,null,null,HEADERS)
		nlapiLogExecution('debug', ' main1',JSON.stringify(main1));
		
		var outboundRec=nlapiCreateRecord(CUSTOMRECORD_APPF_OUT_BOUND_MEDIA_RECS)
		outboundRec.setFieldValue(CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE,'')
		outboundRec.setFieldValue(CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTENTS,JSON.stringify(main1))
		outboundRec.setFieldValue(CUSTOMRECORD_FLD_APPF_PWP_LINK,recordId)
		outboundRec.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,'mercury_orderstat_out')
		nlapiSubmitRecord(outboundRec,true,true)
		
	}
	
}

