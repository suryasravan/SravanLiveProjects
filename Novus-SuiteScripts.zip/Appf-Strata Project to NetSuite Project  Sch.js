/**
*Script Name: Appf-Strata Project to Netsuite Project
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Strata Project and pushes the clients from those messages into netsuite and creates or updates as Customer records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_strata_spo_project_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecordappf_strata_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_strata_spot_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecord_appf_strata_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_strata_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_strata_project_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_response_strats_status';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_appf_ns_response';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_order_strata_correl_id';
 var CUSTOMRECORD_FLD_CONNEX_NS_RESP = 'custrecord_appf_ns_strat_projec_response';
 var FLD_LOG_BUYING_SYSTEM_ID = 'custrecord_appf_strata_buy_sys_id';
 var FLD_LOG_NETSUITE_ID = 'custrecord_appf_strata_ns_id';
 
 // Integration Relatedcustrecord_appf_order_correl_id
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
// Integration Related
 var QUEUE_CONNEX_CLIENT_INBOUND = 'novusmedia_strata_project_in';
 //novusmedia_connex_client_in
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_buyingsystem_salesorder_change';
 var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
 var FLD_BUYING_SYSTEM_ID='custentity_appf_buyingsystem_id';
   var FLD_LAST_UPDATE_DATE_TIME = 'custentity_appf_integr_lastupdatedate';

 // var NS_OB_RESPONSE_PROPERTY='Novus.Azure.WebJobs.NetSuite.Dtos.ProjectResponse'
 var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Orders.Response.NetSuite.ProjectResponseMessage'

var SCRIPT_SCHEDULED='customscript_appf_strata_project_2_ns_sc';
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

function createProjectScheduled(type) 
  {	
  var buyingSystemSearch = nlapiSearchRecord('customlist_appf_buying_system', null, new nlobjSearchFilter('isinactive', null, 'is' ,'F'), new nlobjSearchColumn('name'));
var buyingSystemObj = {};

for (var b = 0; b < buyingSystemSearch.length; b++)
buyingSystemObj[buyingSystemSearch[b].getId()] = buyingSystemSearch[b].getValue('name')
	
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
		var context = nlapiGetContext();
var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
		   var messagesFound=true
    while (messagesFound == true) 
	{
	var usageRemaining = context.getRemainingUsage();
	 var idForResponse = '';
		var buyingSystemIDResponseValue=''
		var d = new Date();
        var UTCDate= d.toISOString();
		var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
		var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
		var mainObj = responseData.getBody()+'';
            nlapiLogExecution('debug','mainObj content',mainObj);
		var CorrelationIdProp='NServiceBus.CorrelationId'
		var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

		var CorrelationId=responseData.getHeader(CorrelationIdProp)  
		var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
        var Status=''
		var Status1=''
		var scriptStatus=''
var fileData=''
        if(mainObj==null || mainObj=='')
        {
			 messagesFound=false;
			 Status='FAILED'+'(Empty Message)'
			 scriptStatus='FAILED'
			 Status1='FAILED'+'(Empty Message)'
        }
        else
        {
		   try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_BUYING_SYSTEM_ID))
					{
						buyingSystemIDResponseValue=mainObj[FLD_BUYING_SYSTEM_ID];
						nlapiLogExecution('debug', 'buyingSystemIDResponseValue:', buyingSystemIDResponseValue);
					}
					Status='SUCCESS'
			   } 
			catch (e) 
			{
			   Status='FAILED'+'(invalid JSON)'
			   scriptStatus='FAILED'
				Status1='FAILED'+'(invalid JSON)'
			}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var integrationResponseObj={}
								
		if(responseData.getCode()!='200' && responseData.getCode()!='201')
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
		   var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
		   		   integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP, 'FAILED');

			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS,'FAILED')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		    var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true)
		   }
		   
		}    
		else
        {
			var nsClientRecord='';
			var isNewRecord = true; 
           var internalId=''
		    var isUpdateRecord = true; 
			 var nsCreationMsg = '';
			 try
			   {
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsClientRecord=nlapiCreateRecord('job')
              if(mainObj.hasOwnProperty('companyname') || mainObj.hasOwnProperty('custentity_appf_buying_system'))
				 {
					 var CompanyName=mainObj['companyname']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					 var buyingSystemIDRespons=mainObj['custentity_appf_buying_system']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					if((CompanyName!=null && CompanyName!='') || (buyingSystemIDRespons!=null && buyingSystemIDRespons!=''))
					{
						      
				               var nsfils = [];
							   if(CompanyName!=null && CompanyName!='')
                                 {
                                    CompanyName=CompanyName.trim();
									 if (buyingSystemIDRespons!=null && buyingSystemIDRespons!='')
									   CompanyName = CompanyName + ' - '+ buyingSystemObj[buyingSystemIDRespons];
	                            nsfils.push(new nlobjSearchFilter('jobname',null,'is',CompanyName));
                                 }
							   
							 
							  var custRecord=nlapiSearchRecord('job', null, nsfils);
                       if (custRecord != null && custRecord != '')
							  {								
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);

var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
					}
                    }
					 
				 }
			}
			else
			{
			
				var internalId=mainObj['id']
				nlapiLogExecution('debug', 'internalId',  internalId);
				if(internalId==null || internalId=='' || internalId=='null')
				{
				  nsClientRecord=nlapiCreateRecord('job')
                  if(mainObj.hasOwnProperty('companyname') || mainObj.hasOwnProperty('custentity_appf_buying_system'))
				 {
					 var CompanyName=mainObj['companyname']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					 var buyingSystemIDRespons=mainObj['custentity_appf_buying_system']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					if((CompanyName!=null && CompanyName!='') || (buyingSystemIDRespons!=null && buyingSystemIDRespons!=''))
					{
						       
				               var nsfils = [];
							   if(CompanyName!=null && CompanyName!='')
                                 {
                                   CompanyName=CompanyName.trim();
								   if (buyingSystemIDRespons!=null && buyingSystemIDRespons!='')
									   CompanyName = CompanyName + ' - '+ buyingSystemObj[buyingSystemIDRespons];
	                            nsfils.push(new nlobjSearchFilter('jobname',null,'is',CompanyName));
								 
                                 }
							   
							 
							  var custRecord=nlapiSearchRecord('job', null, nsfils);
                       if (custRecord != null && custRecord != '')
							  {							
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);
					var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
                              }
					}
					 
				 }
				}
				else
				{
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);
					var msdate=''
				 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if(mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }
				}
			}
			   }
			    catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
					    integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP, 'SUCCESS');

			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
		   var nsClientRecordID=null;
		  
			if(Status==null || Status=='' || Status=='SUCCESS')
		   {
				try{
					 if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {	
					for (var parentProp in mainObj)
					{
						// nlapiLogExecution('debug', ' parentProp',  parentProp);
			          //  var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=nsClientRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!=''))
						 {
if(parentProp!='otherrelationships' && parentProp!='version')
							  {
								  if (parentProp != 'companyname')
								  {
			                  nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])	
								  }
						  else
						  {
							  var buyingSystemIDRespons=mainObj['custentity_appf_buying_system']
							  var revisedCompanyName = mainObj[parentProp];
							  revisedCompanyName=revisedCompanyName.trim();
							  if (buyingSystemIDRespons!=null && buyingSystemIDRespons!='')
									   revisedCompanyName = revisedCompanyName + ' - '+ buyingSystemObj[buyingSystemIDRespons];
							  
							  nsClientRecord.setFieldValue(parentProp,revisedCompanyName)	
							  
						  }
							  
							  
							  }
						  
						 }
		            }					  
		               nsClientRecordID = nlapiSubmitRecord(nsClientRecord,true,true);
					   }
					   else
					   {
						if(nsCreationMsg==null || nsCreationMsg=='')
                          {
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
                             scriptStatus='WARNING'
                          }
					   }
				}
				catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
                  
                  if (nsCreationMsg == null || nsCreationMsg == '')
					nsCreationMsg = 'Empty Error Message from Netsuite Server';
                  
                   if(nsCreationMsg.indexOf('Record has been changed') != -1)
				   {
						scriptStatus='WARNING'
				   }
				    else
				   {
					   
					    if (nsCreationMsg.indexOf('This record already exists') != -1)
					   {
						   try{
							   nsCreationMsg='';
							   var CompanyName=mainObj['companyname']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
					 var buyingSystemIDRespons=mainObj['custentity_appf_buying_system']
					nlapiLogExecution('debug', 'CompanyName:', CompanyName);
							    var nsfils = [];
							   if(CompanyName!=null && CompanyName!='')
                                 {
                                   CompanyName=CompanyName.trim();
								    if (buyingSystemIDRespons!=null && buyingSystemIDRespons!='')
									   CompanyName = CompanyName + ' - '+ buyingSystemObj[buyingSystemIDRespons];
	                            nsfils.push(new nlobjSearchFilter('jobname',null,'is',CompanyName));
								
                                 }
							   
							 
							  var custRecord=nlapiSearchRecord('job', null, nsfils);
                       if (custRecord != null && custRecord != '')
							  {			
	                          //  nlapiLogExecution('debug','custRecord',custRecord);
								
								var internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('job',internalId);
					 var msdate=''
				var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }				 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
                    }
					 if(isUpdateRecord && (custRecord != null && custRecord != ''))
					   {	
				   
				   if (integrationRecordID != null && integrationRecordID != '')
				   {
					   var integrationRecord=nlapiLoadRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
				   }
				   
				   for (var parentProp in mainObj)
					{
						// nlapiLogExecution('debug', ' parentProp',  parentProp);
			          //  var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=nsClientRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!=''))
						 {
						      if(parentProp!='otherrelationships' && parentProp!='version')
							  {
								  if (parentProp != 'companyname')
								  {
			                  nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])	
								  }
						  else
						  {
							  var buyingSystemIDRespons=mainObj['custentity_appf_buying_system']
							  var revisedCompanyName = mainObj[parentProp];
							  revisedCompanyName=revisedCompanyName.trim();
							  if (buyingSystemIDRespons!=null && buyingSystemIDRespons!='')
									   revisedCompanyName = revisedCompanyName + ' - '+ buyingSystemObj[buyingSystemIDRespons];
							  
							  nsClientRecord.setFieldValue(parentProp,revisedCompanyName)	
							  
						  }
							  
							  
							  }
						  
						 }

		            }					  
		               nsClientRecordID = nlapiSubmitRecord(nsClientRecord,true,true);
					
					   }
						
				}
				catch(e2)
				{
					scriptStatus='FAILED'
					if ( e2 instanceof nlobjError )
					nsCreationMsg = e2.getDetails();
					else
					nsCreationMsg = e2.toString();
                  
                  if (nsCreationMsg == null || nsCreationMsg == '')
					nsCreationMsg = 'Empty Error Message from Netsuite Server';
				  
                   if(nsCreationMsg.indexOf('Record has been changed') != -1)
				   {
						scriptStatus='WARNING';
				   }
				}
						   
					   }
				   }
				}                       					   
				if (nsClientRecordID != null)
				{
					var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') 
						  isInActiveRecord=true
					}
					if(!isInActiveRecord)
					{
						if (integrationRecordID)
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS,CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsClientRecordID, 'SUCCESS']);
					}
				}					   
				else
				{
					if (integrationRecordID)
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus+":"+nsCreationMsg]); 						   
				}							
				if(nsClientRecordID!=null && nsClientRecordID!='')
				{
				idForResponse=nsClientRecordID;
					
                    scriptStatus='SUCCESS'
                       
				}
            }
        }				   
		if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
		{			
			if(buyingSystemIDResponseValue==null || buyingSystemIDResponseValue=='')
				   buyingSystemIDResponseValue=''			   
			integrationResponseObj.EntityId=buyingSystemIDResponseValue
			
			if(idForResponse==null || idForResponse=='')
				idForResponse=''
			  integrationResponseObj.NetSuiteId=idForResponse
          
			if(Status1!=null && Status1!='')
				integrationResponseObj.IntegrationResponseStatus=Status1
			else
				integrationResponseObj.IntegrationResponseStatus=scriptStatus
		 
			if(nsCreationMsg==null || nsCreationMsg=='')
				 nsCreationMsg=''
			integrationResponseObj.IntegrationResponseMessage=nsCreationMsg;
			
if (idForResponse != null && idForResponse != '' && idForResponse != '0' && integrationResponseObj.IntegrationResponseStatus.toUpperCase() == 'FAILED')
			{
				integrationResponseObj.IntegrationResponseStatus = 'WARNING';
				if (integrationResponseObj.IntegrationResponseMessage == null || integrationResponseObj.IntegrationResponseMessage == '' || integrationResponseObj.IntegrationResponseMessage == ' ')
					integrationResponseObj.IntegrationResponseMessage = 'Project (Internal ID: '+idForResponse+') already exists. No updates made.';
				if (integrationRecordID)	
			    nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS], [idForResponse]);

			}
		if (integrationRecordID)		
		 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_RESP, FLD_LOG_BUYING_SYSTEM_ID, FLD_LOG_NETSUITE_ID], [JSON.stringify(integrationResponseObj), buyingSystemIDResponseValue, idForResponse]);	   

	
			var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
			var body = JSON.stringify(integrationResponseObj);
			var HEADERS = {"Authorization":signatures};
			//HEADERS.scriptStatus=scriptStatus
			if(CorrelationId==null || CorrelationId=='')
				CorrelationId=''
			HEADERS['NServiceBus.CorrelationId']=CorrelationId
			HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
			var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

		}
		if(context.getRemainingUsage()<=1000)
	{
	nlapiScheduleScript(SCRIPT_SCHEDULED,null)
       break; 
	}		   
	}
                          
	}