/*
*Script Name: Appf-PWP Generation from SO SC
*Script Type: Scheduled
*Description:
*Company 	: Appficiency Inc.

*/
var FLD_COL_LINE_ID_SO = 'custcol_appf_line_id';
var FLD_COL_LINE_ID_INV = 'custcol_appf_invoice_line_id';
var FLD_COL_LINE_ID_PO = 'custcol_appf_po_line_id';
var FLD_COL_LINE_ID_VENDOS = 'custcol_appf_vendorbill_line_id';
var FLD_COL_LINE_ID_ESTIMTS = 'custcol_appf_estimate_line_id';
var FLD_COL_LINE_PWP_RECS = 'custcol_appf_pwp_custom_record';
var FLD_COL_POP_RECEIVED = 'custcol_appf_pop_received';
var MEDIA_SEGMENT = 'cseg_appf_media_seg';
var FLD_COL_IO = 'custcol_appf_ionum';
var FLD_COL_CIRCULATION = 'custcol_appf_print_circulation';
var FLD_COL_NOVUS_UNIT_RATE= 'custcol_appf_novusunitrate';

//added 27-10-2021
var CUSTOMRECORD_SO_PRE_CLOSE='custrecord_appf_so_amount_pre_close';

var CUSTOMRECORD_PWP='customrecord_appf_pwp_wrapper_record'
var CUSTOMRECORD_SO_LINE_ID_PWP='custrecord_appf_pwp_so_line_id'
var CUSTOMRECORD_SO_LINK='custrecord_appf_pwp_so_link'
var CUSTOMRECORD_SO_LINE_AMT='custrecord_appf_pwp_so_line_amount'
var CUSTOMRECORD_PWP_LINE_OF_BUSINESS='custrecord_appf_pwp_line_of_business'
var CUSTOMRECORD_PWP_DEPARTMENT='custrecord_appf_pwp_department'
var CUSTOMRECORD_PWP_OFFICE='custrecord_appf_pwp_office'
var CUSTOMRECORD_PWP_CLIENT_LINK='custrecord_appf_pwp_client_link'
var CUSTOMRECORD_PWP_PRO='custrecord_appf_pwp_project'
var CUSTOMRECORD_PWP_POP_RECEIVED = 'custrecord_appf_pwp_pop_received';
var CUSTOMRECORD_PWP_BUYING_SYSTEM = 'custrecord_appf_pwp_buying_system';
var CUSTOMRECORD_PWP_IO = 'custrecord_appf_pwp_io_number';
var FLD_PWP_CLIENT_CURRENCY='custrecord_appf_pwp_client_currency';
var CUSTOMRECORD_PWP_CLIENTCONTRACT = 'custrecord_appf_pwp_client_contract';

var CUSTOMRECORD_PWP_IO_CIRCULATION= 'custrecord_appf_pwp_io_circulation';
var CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE= 'custrecord_appf_pwp_io_novus_unit_rate';

var FLD_NEXT_LINE_ID ='custbody_appf_next_line_number';
var FLD_PO_NEXT_LINE_ID = 'custbody_appf_next_line_number_po';
var FLD_REV_REC_LINK = 'custbody_appf_aem_rev_rec_arrangement';
var FLD_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_SO_PWP_CREATE_SCRIPT_COMPLETE = 'custbody_appf_pwp_complete';
var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_OOH_ID = 'custbody_appf_ooh_ns_sss';
var FLD_SO_SPOT_ID = 'custbody_appf_spot_ns_sss';
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';

var SPARAM_SALES_ORDER_ID = 'custscript_appf_sales_order_id';
var SPARAM_SALESORDER_SS = 'custscriptappf_sales_orders_fo_pwp_gener';
var SPARAM_INDEX = 'custscript_appf_sales_order_index';

function pwpGenerationSOScheduled(type) {
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_SALESORDER_SS);
	var lineIndex = context.getSetting('SCRIPT', SPARAM_INDEX);
	if (lineIndex == null || lineIndex == '')
		lineIndex = 1;
	var intermidateProcessing = -1;
	var searchResults=nlapiSearchRecord('transaction', ssID, null, null);
			if (searchResults != null && searchResults != '') {
              	nlapiLogExecution('DEBUG', 'searchResults', searchResults.length);

				for(var s = 0; s < searchResults.length; s++) {
					var result = searchResults[s];
					var columns = result.getAllColumns();
					var internalid = result.getValue(columns[0]);
                  //nlapiLogExecution('DEBUG', 'columns', columns);
	try{
		var recId = internalid;
		if(recId != null && recId != ''){

			var record = nlapiLoadRecord('salesorder', recId);
			//var soStatus = record.getFieldValue('status');
			var processCompleted = true;
			var soentity=record.getFieldValue('entity');
			var clientCurrency='';
			if(soentity)
			{
				clientCurrency=nlapiLookupField('customer',soentity,'currency');
			}

			//use povendor setting from order vlaidation
			try{
			    var itemCount=record.getLineItemCount('item');
	            for(var k=1;k<=itemCount;k++)
		        {

			        var existingPOVendor = record.getLineItemValue('item', 'povendor', k);
			        var vendorName = record.getLineItemValue('item', FLD_COL_VENDOR_NAME, k);
					var existingcreatepo = record.getLineItemValue('item', 'createpo', k);

			        if (vendorName == null)
			            vendorName = '';
		             nlapiLogExecution('debug', 'po vendor', vendorName + ' existingPOVendor='+existingPOVendor);
		            if (existingPOVendor != vendorName && vendorName != null && vendorName != '')
			        {
								  nlapiLogExecution('debug', 'po vendor', vendorName);
		            	record.selectLineItem('item', k);
		            	record.setCurrentLineItemValue('item', 'povendor', vendorName);
		            	record.setCurrentLineItemValue('item', 'porate', 1);

			            if (existingcreatepo == null || existingcreatepo == '')
				            record.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
			                record.commitLineItem('item');
			        }

		        }

		        nlapiSubmitRecord(record, true, true);
			}
			catch(ep)
			{

				nlapiLogExecution('debug', 'Failed to set PO Vendor', ep);
			}

			var record = nlapiLoadRecord('salesorder', recId);
			var buyingSystem = record.getFieldValue(FLD_BUYING_SYSTEM);
			var buyingSystemText = record.getFieldText(FLD_BUYING_SYSTEM);
			//v5 added 9/3/2020
	        //set client contract if buying system = OOH/Spot
	        switch(buyingSystemText){
	            case 'OOH' :  record.setFieldValue(FLD_SO_CLIENT_CONTRACT,record.getFieldValue(FLD_SO_OOH_ID));break;
	            case 'Spot' :  record.setFieldValue(FLD_SO_CLIENT_CONTRACT,record.getFieldValue(FLD_SO_SPOT_ID));break;
	        }


			var itemCount=record.getLineItemCount('item');
			nlapiLogExecution('DEBUG', 'itemCount', itemCount);
			var nextItemNumber = 0;
			var pwpObj = {};
			for(var k=lineIndex;k<=itemCount;k++)
                               {
								 var soId= record.getLineItemValue('item',FLD_COL_LINE_ID_SO,k)
								 var soAmt= record.getLineItemValue('item','amount',k)
								 var soAmt= record.getLineItemValue('item','amount',k)
								 if(soAmt != null && soAmt != '')
									 soAmt = Number(soAmt).toFixed(2);
								 var sodepartment= record.getLineItemValue('item','department',k)
								 var solocation= record.getLineItemValue('item','location',k)
								  var soPro= record.getLineItemValue('item','job',k)
								  var soclass= record.getLineItemValue('item','class',k)
								  var popReceived = record.getLineItemValue('item', FLD_COL_POP_RECEIVED,k)
								    var mediaSegment = record.getLineItemValue('item', MEDIA_SEGMENT, k)

								     var soCirculation= record.getLineItemValue('item',FLD_COL_CIRCULATION,k)
									 if (soCirculation == null || soCirculation == '')
										 soCirculation = 0;
								   var soNovusUnitRate= record.getLineItemValue('item',FLD_COL_NOVUS_UNIT_RATE,k)
								   if (soNovusUnitRate == null || soNovusUnitRate == '')
										 soNovusUnitRate = 0;
								  var io = record.getLineItemValue('item', FLD_COL_IO,k)


								 try{
								  var pwpRecLink= record.getLineItemValue('item',FLD_COL_LINE_PWP_RECS,k)

								  if (pwpRecLink == null || pwpRecLink == '')
								  {
									   var pwpFils = [];
								  pwpFils.push(new nlobjSearchFilter(CUSTOMRECORD_SO_LINE_ID_PWP, null, 'is', soId));
								  pwpFils.push(new nlobjSearchFilter(CUSTOMRECORD_SO_LINK, null, 'anyof', recId));

								  var pwpCols = [];
								  pwpCols.push(new nlobjSearchColumn('internalid').setSort(true));

								 var pwpSearch = nlapiSearchRecord(CUSTOMRECORD_PWP, null, pwpFils, pwpCols);
								  nlapiLogExecution('DEBUG', 'pwpSearch', pwpSearch);
								 if (pwpSearch != null && pwpSearch != '')
								 {
									 pwpRecLink = pwpSearch[0].getValue('internalid');
								 }
								 }
								  if(pwpRecLink==null || pwpRecLink=='')
								  {
									  var pwpRecord =nlapiCreateRecord(CUSTOMRECORD_PWP)
								      nlapiLogExecution('DEBUG', 'pwpRecord', pwpRecord);
								     pwpRecord.setFieldValue('name','PWP - '+soId);

									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_ID_PWP,soId);

									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINK,recId);

									 nlapiLogExecution('DEBUG', 'recId', recId);

									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENTCONTRACT,record.getFieldValue(FLD_SO_CLIENT_CONTRACT));



								     if(soAmt!=null && soAmt!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT,soAmt);
								     //added 27-10-2021
								   if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
								     if(sodepartment!=null && sodepartment!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT,sodepartment);
								      if(solocation!=null && solocation!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE,solocation);
								      if(soentity!=null && soentity!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK,soentity);
								      if(clientCurrency!=null && clientCurrency!='')
									pwpRecord.setFieldValue(FLD_PWP_CLIENT_CURRENCY,clientCurrency);
								    if(soPro!=null && soPro!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO,soPro);
								   if(soclass!=null && soclass!='')
								   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS,soclass);
                                    if (buyingSystem != null && buyingSystem != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM,buyingSystem);
							   if (mediaSegment != null && mediaSegment != '')
									 pwpRecord.setFieldValue(MEDIA_SEGMENT,mediaSegment);

									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION,soCirculation);
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE,soNovusUnitRate);

								 if (io != null && io != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO,io);
							   if (popReceived == 'T')
							   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED,popReceived);
							    nlapiLogExecution('DEBUG', 'popReceived', popReceived);
									var pwpRecordID= nlapiSubmitRecord(pwpRecord,true,true)
									nlapiLogExecution('DEBUG', 'pwpRecordID', pwpRecordID);
									//record.setLineItemValue('item',FLD_COL_LINE_PWP_RECS,k,pwpRecordID);

									pwpObj[soId] = pwpRecordID;
								  }
                                    else
								  {
									  pwpObj[soId] = pwpRecLink;
									  var pwpRecord = nlapiLoadRecord(CUSTOMRECORD_PWP, pwpRecLink);
									  if(soAmt!=null && soAmt!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT,soAmt);
								      //added 27-10-2021
								     if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
								     if(sodepartment!=null && sodepartment!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT,sodepartment);
								      if(solocation!=null && solocation!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE,solocation);
								      if(soentity!=null && soentity!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK,soentity);
								    if(soPro!=null && soPro!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO,soPro);
								   if(soclass!=null && soclass!='')
								   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS,soclass);
                                     if (popReceived == 'T')
							   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED,popReceived);
                                      if (buyingSystem != null && buyingSystem != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM,buyingSystem);
							   if (mediaSegment != null && mediaSegment != '')
									 pwpRecord.setFieldValue(MEDIA_SEGMENT,mediaSegment);

								 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION,soCirculation);
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE,soNovusUnitRate);


								 if (io != null && io != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO,io);
									nlapiSubmitRecord(pwpRecord,true,true)

								  }
								 }
								  catch (ex) {
                                if (ex instanceof nlobjError) {
                                    errorMessage = 'Error creating/updating PWP for line id '+soId+': '+ex.getDetails();
                                } else {
                                    errorMessage = 'Error creating/updating PWP for line id '+soId+': '+ex.toString();
                                }
                            }

							if (k%1199 == 0 && itemCount > 1200)
							{

								intermidateProcessing = k;
                                             break;
							}
		                 }

						 record = nlapiLoadRecord('salesorder', recId);
						 for (var prop in pwpObj)
						 {
							 var lineNum = record.findLineItemValue('item', FLD_COL_LINE_ID_SO, prop);
							 if (lineNum != -1)
							 {
								 record.setLineItemValue('item',FLD_COL_LINE_PWP_RECS,lineNum,pwpObj[prop]);
							 }
						 }
		                    //set client contract if buying system = OOH/Spot
					        switch(buyingSystemText){
					            case 'OOH' :  record.setFieldValue(FLD_SO_CLIENT_CONTRACT,record.getFieldValue(FLD_SO_OOH_ID));break;
					            case 'Spot' :  record.setFieldValue(FLD_SO_CLIENT_CONTRACT,record.getFieldValue(FLD_SO_SPOT_ID));break;
					        }

		                    //mark complete
					        record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE,'T');
			                var submittedRecId = nlapiSubmitRecord(record,true,true);
			                nlapiLogExecution('DEBUG', 'submittedRecId', submittedRecId);


		}
	}catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
	if (intermidateProcessing != -1)
			{
				 var params = {};
				 params[SPARAM_INDEX] = parseInt(intermidateProcessing)+1;
				 nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params)
				break;
			}
			else
			{
	                               if (context.getRemainingUsage() <= 1000 && (s+1) < searchResults.length)
                                       {
										   var params = {};
										   params[SPARAM_INDEX] = '';
                                           nlapiScheduleScript(context.getScriptId(), context.getDeploymentId())
                                             break;
                                        }
			}
				}
			}
}

function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}

		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}

function eliminateDuplicates(arr)
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}
