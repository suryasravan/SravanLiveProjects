/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : Generate Special PO for Sales Orders
* Company     : Appficiency Inc.
*/

var SPARAM_SEARCH_PARAMETER = 'custscript_appf_sched_po_savedsearch_id';
var FLD_SO_PO_VENDOR = 'custcol_appf_po_vendor_name';
var FLD_SO_PO_GENERATION_COMPLETE = 'custcol_appf_po_generation_complete';
var SPARAM_INDEX = 'custscript_appf_sched_po_search_index';
var FLD_SO_PO_GENERATION_ERROR = 'custbody_appf_po_generation_error';
var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020

function generateSpecialOrdercheduled(type) {
    var context = nlapiGetContext();
	var searchId = context.getSetting('SCRIPT', SPARAM_SEARCH_PARAMETER);

	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if (index == null || index == '')
		index = 0;
    nlapiLogExecution('debug', 'file index', index);
    
    if(searchId){
        var objSearch= nlapiLoadSearch(null, searchId);
    	var filters = objSearch.getFilters();
    	var columns = objSearch.getColumns();
    	var ssType = objSearch.getSearchType();
    	var searchResults = getAllSearchResults(ssType, filters, columns);
    	
    	if (searchResults != null && searchResults != '') {
    		for (var s=index; s<searchResults.length; s++) {
    			var result = searchResults[s];
                var recType = result.getRecordType();
                var idSalesOrder = result.getId();
                var columns = result.getAllColumns();
    			var internalid = result.getValue(columns[0]);
    	    	var idCustomer = result.getValue('entity');
    			var idVendor = result.getValue(FLD_SO_PO_VENDOR);
    			var nQty = result.getValue('quantity');
    			var i = parseInt(result.getValue('linesequencenumber')); 
    	    	
    			//log.debug('sales order:', idSalesOrder + ' idCustomer:'+idCustomer + ' idVendor:'+idVendor + ' nQty:'+nQty + ' i:'+i);
    	    	var sProcess = 'sales order:'+ idSalesOrder + ' idCustomer:'+idCustomer + ' idVendor:'+idVendor + ' nQty:'+nQty + ' i:'+i;
    					
    	    	
        		//reschedule
                if(context.getRemainingUsage() <= 1000 && parseInt(s)+1 < searchResults.length) {
                    var params = {};
                    params[SPARAM_SEARCH_PARAMETER] = searchId;
                    params[SPARAM_INDEX] = s;
                    nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                    break;
                }else{
        			var step1 = false;
        	    	var step2 = false;
        	    	var errorMsg = '';
                    //load sales order
                    
                    nlapiLogExecution('debug', 'remaining usage before', context.getRemainingUsage() + ' sProcess='+sProcess);
                    var recSO = nlapiLoadRecord(recType,idSalesOrder);
                    //recSO.setFieldValue('orderstatus','A');
                    
                    var nLines = recSO.getLineItemCount('item');
                    var idVendor = recSO.getLineItemValue('item', FLD_SO_PO_VENDOR, i);
                	var nQty = recSO.getLineItemValue('item', 'quantity', i);
                	var createdPO =recSO.getLineItemValue('item', 'createdpo', i);
                	nlapiLogExecution('debug', 'createdPO', createdPO);
                	recSO.selectLineItem('item',i);
                	if(parseInt(nQty) == 0){
                		//recSO.setLineItemValue('item', 'quantity', i, '0.01');
                		recSO.setCurrentLineItemValue('item','quantity','0.01');
                	}
                	/*recSO.setLineItemValue('item', 'povendor', i, idVendor);
                	recSO.setLineItemValue('item', 'porate', i, 1);
                	recSO.setLineItemValue('item', 'createpo', i, 'SpecOrd');*/

                    recSO.setCurrentLineItemValue('item','povendor',idVendor);
                    recSO.setCurrentLineItemValue('item','porate',1);
                    recSO.setCurrentLineItemValue('item','createpo','SpecOrd');
                    
                    // 1.4 Changes
                    //Start Date (RR) (Line) = Start Date (Actual)
                    var startdateActual = recSO.getLineItemValue('item', FLD_COL_STARTDATEACTUAL, i);
                    var startDateRR = recSO.getLineItemValue('item', FLD_COL_STARTDATERR, i);
                    if (!isNullOrEmpty(startdateActual) && isNullOrEmpty(startDateRR)) {
                    	//recSO.setCurrentLineItemValue('item', FLD_COL_STARTDATERR, startdateActual);
                    	recSO.setCurrentLineItemValue('item',FLD_COL_STARTDATERR,startdateActual);
                    }
                    var lineBusinessHeader = recSO.getFieldValue(FLD_SO_LINEBUSINESS_HEADER)
                    //v.5 9/2/2020 add
                    if(!isNullOrEmpty(lineBusinessHeader) ){
                    	//recSO.setLineItemValue('item','class',i,lineBusinessHeader);
                    	recSO.setCurrentLineItemValue('item','class',lineBusinessHeader);
                    }
                    
                    recSO.commitLineItem('item');
                	
            		try{
            			nlapiSubmitRecord(recSO);
            			nlapiLogExecution('DEBUG', 'Set PO Fields','Set PO Fields');
            			step1=true;
            		}catch(e1){
            			errorMsg = e1.message;
            			nlapiLogExecution('DEBUG', 'Error setting PO Rate and Vendor', e1.message + ' idSalesOrder='+idSalesOrder);
            		}

            		if(step1){ //generate PO
            			try{
            		    	var params = {
            		    		    'recordmode' : 'dynamic',
            		    		    'soid' : idSalesOrder,
            		    		    'specord' : 'T', 
            		    		    'custid' : idCustomer,
            		    		    'entity': idVendor,
            		    		    'poentity':idVendor
            		    		};   

            		    	var purchaseOrder = nlapiCreateRecord('purchaseorder', params);
            		    	var poId = nlapiSubmitRecord(purchaseOrder);
                			step2=true;
                			nlapiLogExecution('DEBUG', 'PO Created','PO Created');
            			}catch(e2){
            				errorMsg += '\n'+e2.message;
            				nlapiLogExecution('DEBUG', 'Error creating Special PO', e2.message + ' idSalesOrder='+idSalesOrder)
                            //save error
            				
            				//set back to 0
            				var recSO = nlapiLoadRecord(recType,idSalesOrder);
            				recSO.selectLineItem('item',i);
                            if(parseInt(nQty) == 0.01 || nQty == 0.01 || nQty == '.01' || nQty == .01){
                              recSO.setCurrentLineItemValue('item','quantity',0);
                            }
            				
            				recSO.commitLineItem('item');
            				
            				recSO.setFieldValue(FLD_SO_PO_GENERATION_ERROR, e2.message);
            				nlapiSubmitRecord(recSO);
            				//nlapiSubmitField('salesorder', idSalesOrder, FLD_SO_PO_GENERATION_ERROR, e2.message );

            			}

            		}
            		
            		if(step2){
                        //then load again to set the lines to 0
                        var recSO = nlapiLoadRecord('salesorder',idSalesOrder);
                    	var nQty = recSO.getLineItemValue('item', 'quantity', i);
                    	var createdPO =recSO.getLineItemValue('item', 'createdpo', i);
                    	nlapiLogExecution('debug', 'createdPO', createdPO);
                        
                        if(nQty == 0.01 || nQty == '.01' || nQty == .01){
                        	recSO.setLineItemValue('item', 'quantity', i, '0');
                        }
                        recSO.setLineItemValue('item', FLD_SO_PO_GENERATION_COMPLETE, i, 'T');
                    	
                		try{
                			
                			nlapiSubmitRecord(recSO);
                			nlapiLogExecution('DEBUG', 'Processed success',' idSalesOrder='+idSalesOrder)

                		}catch(e3){
                			errorMsg += '\n'+e3.message;
                			nlapiLogExecution('DEBUG', 'Error setting SO Lines to 0', e3.message + ' idSalesOrder='+idSalesOrder)
                		    //save error
                			nlapiSubmitField('salesorder', idSalesOrder, FLD_SO_PO_GENERATION_ERROR, e2.message );
                		}

            		}
                }
 
                nlapiLogExecution('debug', 'remaining usage after', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder);

    		}
    		
    	}
    }


}

function getAllSearchResults(record_type, filters, columns) {
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);

    var searchRan = search.runSearch()
    ,	bolStop = false
    ,	intMaxReg = 1000
    ,	intMinReg = 0
    ,	result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000) {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array) {
    return target.concat(array); // TODO: use _.union
}


function isNullOrEmpty(data) {
    return (data == null || data == '');
}
