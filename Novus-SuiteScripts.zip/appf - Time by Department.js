function workflowAction() {
          	nlapiLogExecution('DEBUG', 'test', 'start');
			var projectTaskValue = nlapiGetFieldValue('custcol_appf_time_project_task');
          	nlapiSetFieldValue('casetaskevent', projectTaskValue);
}

