/**
* Script Name : Appf-Auto Update Revenue Arrangements SC
* Script Type : Scheduled
* Description : 
* Company     :	Appficiency Inc.
*/

var SPARAM_SS_UPDATE_EXP_ELEMENTS = 'custscript_update_exp_elements_ss';

var FOLDER_AEM_SL_FILES= '895';

var SCRIPT_SCHEDULED='customscript_appf_update_rev_arrange_sc';
var DEPLOY_SCHEDULED='customdeploy_appf_update_rev_arrange_sc';
var SPARAM_CUSTOM_REC_ID='custscript_appf_custom_rec_id';

var CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG='customrecord_appf_aem_rev_ele_ex_log';
var FLD_TOT_RECS_PROCESSED='custrecord_appf_aem_reelf_process_rec';
var FLD_TOT_RECS_NOT_PROCESSED = 'custrecord_appf_total_recs_not_processed';
var FLD_TOT_RECS='custrecord_appf_aem_reelf_total_records';
var FLD_CREATED_BY='custrecord_appf_aem_reelf_created_by';
var FLD_AEM_STATUS='custrecord_appf_aem_reelf_status';
var FLD_PROCESS_PERCENTAGE='custrecord_appf_processed_percentage';
var FLD_ERROR_LOG='custrecord_appf_error_log';
var FLD_SRC_FROM_FIL='custrecord_appf_source_from_fil';
var FLD_SRC_TO_FIL='custrecord_appf_sorce_to_fil';
var FLD_START_DATE_PO_FIL='custrecord_appf_st_dt_po';
var FLD_END_DATE_PO_FIL='custrecord_appf_en_dt_po';
var FLD_SUBSIDIARY_FIL='custrecord_appf_subsidiary_fil';
var FLD_DATA_FILE = 'custrecord_appf_data_file';
var FLD_PROCESS_RESET = 'custrecord_appf_process_reset';

var FLD_AEM_STATUS_INPROGRESS=2;
var FLD_AEM_STATUS_COMPLETED=4;

function autoRescheduleRevenueArr2(type){
	var context=nlapiGetContext();
	var ssCreateExpElem=context.getSetting('SCRIPT',SPARAM_SS_UPDATE_EXP_ELEMENTS);
	if(ssCreateExpElem != null && ssCreateExpElem != ''){
		var search=nlapiLoadSearch(null, ssCreateExpElem);
		var filList = search.getFilters();
		var colList = search.getColumns();
		
		var searchResults=getAllSearchResults('transaction', filList, colList);
		if(searchResults != null && searchResults != ''){
			try{
			nlapiLogExecution('DEBUG' ,'searchResults.length', searchResults.length);
			var count = searchResults.length;
			var timeStamp='RevArr'+new Date().getTime();
				var ssDataFile='';
				ssDataFile += 'PO ID,';
				for(var i=0; i<colList.length; i++){
				
					if(i == (colList.length)-1){
						if (colList[i].getType() == 'select')
						{
						ssDataFile += colList[i].getLabel()+',';
						ssDataFile += colList[i].getLabel()+' ID'+'\n';
						}
						else{
							ssDataFile += colList[i].getLabel()+'\n';
						}
					}
					else
					{
						if (colList[i].getType() == 'select')
						{
						ssDataFile += colList[i].getLabel()+',';
						ssDataFile += colList[i].getLabel()+' ID'+',';
						}
						else{
							ssDataFile += colList[i].getLabel()+',';
						}
					}
				}
			for(var i=0; i<searchResults.length; i++){
				var result=searchResults[i];
				var recId=result.getId();
				ssDataFile += recId+',';				
				for(var k=0; k<colList.length; k++){ 
					if(k==(colList.length)-1){
						if (colList[k].getType() == 'select')
						{
							var colValue=result.getText(colList[k]);
							var colValue1=result.getValue(colList[k]);
							ssDataFile += colValue+',';
							ssDataFile += colValue1+'\n';
						}
						else{
							var colValue=result.getValue(colList[k]);
							ssDataFile += colValue+'\n';
						}
					}
					else{
						if (colList[k].getType() == 'select')
						{
							var colValue=result.getText(colList[k]);
							var colValue1=result.getValue(colList[k]);
							ssDataFile += colValue+',';
							ssDataFile += colValue1+',';
						}
						else{
							var colValue=result.getValue(colList[k]);
							ssDataFile += colValue+',';
						}
					}
				}
				
			}
			var ssDataFileCreate=nlapiCreateFile('ExpenseElementsData_'+timeStamp+'.csv','CSV',ssDataFile);
			ssDataFileCreate.setFolder(FOLDER_AEM_SL_FILES);
			var ssDataFileID= nlapiSubmitFile(ssDataFileCreate);

			var customRec=nlapiCreateRecord(CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG);
			customRec.setFieldValue(FLD_TOT_RECS, count);
			customRec.setFieldValue(FLD_TOT_RECS_PROCESSED, 0);
			customRec.setFieldValue(FLD_TOT_RECS_NOT_PROCESSED, 0);
			nlapiLogExecution('debug', 'nlapiGetUser()', nlapiGetUser());
			//customRec.setFieldValue(FLD_CREATED_BY, nlapiGetUser());
			customRec.setFieldValue(FLD_AEM_STATUS, FLD_AEM_STATUS_INPROGRESS);
			customRec.setFieldValue(FLD_PROCESS_PERCENTAGE, 0);
			customRec.setFieldValue(FLD_ERROR_LOG, '');
			customRec.setFieldValue(FLD_DATA_FILE, ssDataFileID);
			var revElemExecLogID=nlapiSubmitRecord(customRec, true, true);
			nlapiLogExecution('debug', 'revElemExecLogID', revElemExecLogID);
			var params={};			
			params[SPARAM_CUSTOM_REC_ID]=revElemExecLogID;
			nlapiScheduleScript(SCRIPT_SCHEDULED,null,params);
			}catch(e){
				if ( e instanceof nlobjError )
				nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
				else
				nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
		}
	}
}


function getAllSearchResults(record_type, filters, columns)
{
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);

	var searchRan = search.runSearch()
	,	bolStop = false
	,	intMaxReg = 1000
	,	intMinReg = 0
	,	result = [];

	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
	{
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);

		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000)
		{
			bolStop = true;
		}
	}

	return result;
}

 function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}