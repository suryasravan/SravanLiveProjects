/**
 *Script Name: Appf-Reprocess Strata/OCR Interim VB SC
 *Script Type: Schedule Script
 *Description: This script runs every 6 hours and reprocesses any failed Interim VB Master records and performs the PO lookup on transaction records and sends the revised status back to Azure
 *Company 	: Appficiency Inc.
 * Version       Author          Description
 * 1.1           MJ De Asis      Added discard flag and avoid redundant lines
 */
var QUEUE_CONNEX_ORDER_INBOUND = 'novusmedia_vendorbill_in';

var CUSTOMRECORD_APPF_INTERM_MASTER_LOG = 'customrecord_appf_vb_header_masters_in';
var FLD_APPF_INTERM_MASTER_LOG_INTERIM_LINK = 'custrecord_master_id';
var FLD_APPF_INTERM_MASTER_LOG_CORRELATION_ID = 'custrecordappf_correlation_id';

var CUSTOMRECORD_APPF_IN_VB = 'custrecord_appf_ivb_vendor';
var CUSTOMRECORD_APPF_IN_VB_LINE_RECS = 'recmachcustrecord_appf_interimheader';
var CUSTOMRECORD_FLD_VB_LINE_IO = 'custrecord_appf_ivbl_io_num';
var CUSTOMRECORD_FLD_VB_LINE_PO = 'custrecord_appf_ivbl_vendor_name';
var CUSTOMRECORD_FLD_VB_LINE_PO_IDS = 'custrecord_appf_ivbl_po_link';
var CUSTOMRECORD_FLD_VB_LINES = 'custrecord_appf_ivbl_po_line_id';
var CUSTOMRECORD_FLD_VB_CURRECNCY = 'custrecord_appf_ivbl_pocurrency';
var CUSTOMRECORD_FLD_VB_MEDIAS = 'cseg_appf_media_seg';
var CUSTOMRECORD_FLD_APPF_CONTENT_LINK = 'custrecord_appf_contact_jsoncontent';
var CUSTOMRECORD_FLD_APPF_LINK = 'custrecord_appf_ivbl_pwplink';
var CUST_FLD_IO = 'custcol_appf_ionum';
/// v1.2
var CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG='custrecord_appf_ivbl_discard';


var CUST_FLD_VENDOR_IDS = 'custrecord_appf_ivbl_vendor_name'
var CUSTOMRECORD_APPF_INTERM_VB = 'customrecord_appf_interim_vb';
var CUST_FLD_INTREM_TRANIDS = 'custrecord_appf_ivb_transid';

var CUST_FLD_REPROCESSINGS = 'custrecord_reprocessing_counter'

var FLD_INTERIM_HEADER_VB_CREATE = 'custrecord_appf_ivb_create';
var FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG = 'custrecord_validation_error_details';
var FLD_INTERIM_HEADER_VALIDATION_ERROR_FOUND = 'custrecord_validation_errors_found';

var FLD_INTERIM_CHILD_TRANSACTION_NET_AMOUNT = 'custrecord_appf_ivbl_vendor_net';
var FLD_INTERIM_CHILD_TRANSACTION_VB_LINK = 'custrecord_appf_ivbl_vblink';
var FLD_INTERIM_CHILD_TRANSACTION_VC_LINK = 'custrecord_appf_ivbl_vclink';
var FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE = 'custrecord_interim_child_validat_error';
var FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG = 'custrecord_appf_ivbl_errormessage';


var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_buyingsystem_vendorbill';
var URL_BASE = 'https://novusmediallc-dev.servicebus.windows.net/';

var FLD_CONNEX = 'custentity_appf_buyingsystem_id'
var NS_CLIENT = 'Novus.Framework.Models.Vendor.VendorBillResponse'
//Novus.Azure.WebJobs.Shared.Contracts.Interfaces.IVendorBillResponse

var SPARAM_CONNEX_CLIENT = 'customscript_appmercury_order_to_netsuit';
var SPARAM_INTERM_RECS_SS = 'custscript_appf_interim_vb_headers'
var SPARAM_PO_RECS_SS = 'custscript_appf_po_lookup_for_vb_intss'
var SPARAM_INDEX = 'custscript_appf_mater_index'
var SPARAM_FILE = 'custscript_appf_mater_file';




function sendInterimMaterScheduled(type) {
	var processCompleted = true;
	var context = nlapiGetContext();
	var fileindex = context.getSetting('SCRIPT', SPARAM_INDEX);
	var fileid = context.getSetting('SCRIPT', SPARAM_FILE)
	if (fileindex == null || fileindex == '')
		fileindex = 0;
	var scriptStatus = ''
	var Status1 = ''
	var invReferenceNumber = null;
	var vendorNameinVB = null;
	var integrationResponseObj = {}
	var ssID = context.getSetting('SCRIPT', SPARAM_INTERM_RECS_SS)
	var loadSS = nlapiLoadSearch(null, ssID);
	var ssType = loadSS.getSearchType();
	var ssfilts = loadSS.getFilters()
	var sscolumns = loadSS.getColumns();

	if (fileid == null || fileid == '') {
		var arr = []
		var searchResults = getAllSearchResults(ssType, ssfilts, sscolumns);
		nlapiLogExecution('debug', 'searchResults', searchResults)
		if (searchResults != null && searchResults != '') {
			for (var s = 0; s < searchResults.length; s++) {
				var searchresult = searchResults[s];
				var nsOrderRecordID = searchresult.getId()
				arr.push(nsOrderRecordID);
			}
		}
		arr = arr + '';
		var textfile = nlapiCreateFile('masterInterimHeaderDataFile.txt', 'PLAINTEXT', arr);
		textfile.setFolder('-15');
		fileid = nlapiSubmitFile(textfile);
	}
	nlapiLogExecution('debug', 'fileid', fileid);
	if (fileid != null && fileid != '') {
		var POLookupSSParam = context.getSetting('SCRIPT', SPARAM_PO_RECS_SS);

		var fileContents = nlapiLoadFile(fileid).getValue().split(',');
		for (var f = fileindex; f < fileContents.length; f++) {

			var recid = fileContents[f];
			var nsOrderRecordID = recid
			var recordId = recid;
			try {
				var recordType = CUSTOMRECORD_APPF_INTERM_VB;
				var payRec = nlapiLoadRecord(recordType, recordId);
				var validationErrorsFound = 'F';
				var custVb = payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB)
				vendorNameinVB = payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB)
				invReferenceNumber = payRec.getFieldValue(CUST_FLD_INTREM_TRANIDS)
				var custVbText = payRec.getFieldText(CUSTOMRECORD_APPF_IN_VB)
				var payRecFields = payRec.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
				var validationErrors = '';
				var createVBCount = 0;

                /// v1.2
                var hasDiscardFlag=payRec.findLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG,'T') > 0;
                var payRecFieldsCount=payRecFields + 0;

				for (var i = 1; i <= payRecFields; i++) {
					var ios = payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_IO, i);
					var netAmt = payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_TRANSACTION_NET_AMOUNT, i)
					var interimVBLink = payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_TRANSACTION_VB_LINK, i)
					var interimVCLink = payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_TRANSACTION_VC_LINK, i)

                    /// v1.2
                    var discardFlag=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG,i);
                    if (discardFlag != 'T') {
                        var nsfils = [];
    					nsfils.push(new nlobjSearchFilter(CUST_FLD_IO, null, 'is', ios));

    					var poSearchResults = nlapiSearchRecord('transaction', POLookupSSParam, nsfils, null);
    					nlapiLogExecution('debug', 'poSearchResults', poSearchResults);
    					if (poSearchResults != null && poSearchResults != '')
    						nlapiLogExecution('debug', 'poSearchResultslen', poSearchResults.length);
    					payRec.selectLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, i);
    					if (poSearchResults == null || poSearchResults == '') {

    						payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '1');
    						payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> No PO Line Found for IO# "' + ios + '".\n');
    						validationErrorsFound = 'T';
    						validationErrors += '---> No PO Line Found for IO# "' + ios + '".\n';
    					} else {
    						nlapiLogExecution('debug', 'vendorFromSearchResult', 'vendorFromSearchResult');
    						var vendorCnt = 0;
    						var vbAmt = null;
    						var poLineAmt = null;
    						var pwpLineRecID = null;
    						var poTransactionLink = null;
    						var poTransactionLineID = null;
    						for (var p = 0; p < poSearchResults.length; p++) {

    							var vData = poSearchResults[p];
    							if (vData) {
    								var vCols = vData.getAllColumns();
    								var vendorFromSearchResult = vData.getValue(vCols[1]);
    								nlapiLogExecution('debug', 'vendorFromSearchResult', vendorFromSearchResult);
    								nlapiLogExecution('debug', 'POLookupSSParam', POLookupSSParam);
    								if (custVb == vendorFromSearchResult) {
    									vendorCnt++;
    									poTransactionLink = vData.getValue(vCols[0]);
    									poTransactionLineID = vData.getValue(vCols[2]);
    									vbAmt = vData.getValue(vCols[3]);
    									if (vbAmt == null || vbAmt == '')
    										vbAmt = 0;
    									poLineAmt = vData.getValue(vCols[4]);

    									vbAmt = parseFloat(vbAmt);
    									poLineAmt = parseFloat(poLineAmt);
    									pwpLineRecID = vData.getValue(vCols[5]);


    								}
    							}
    						}

    						if (vendorCnt == 0) {
    							payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '2');
    							payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> No PO Line Found for IO# "' + ios + '" with Vendor Name "' + custVbText + '".\n');
    							validationErrorsFound = 'T';
    							validationErrors += '---> No PO Line Found for IO# "' + ios + '" with Vendor Name "' + custVbText + '".\n';
    						} else {
    							if (vendorCnt != 1) {
    								payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '3');
    								payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> Duplicate PO Lines Found for IO# "' + ios + '" with Vendor Name "' + custVbText + '".\n');
    								validationErrorsFound = 'T';
    								validationErrors += '---> Duplicate PO Lines Found for IO# "' + ios + '" with Vendor Name "' + custVbText + '".\n';

    							} else {
    								if (vbAmt >= poLineAmt) {
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '4');
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> VB Amount is >= PO Line Amount in Linked PWP record for the PO Line Found with IO# "' + ios + '" and Vendor Name "' + custVbText + '".\n');
    									validationErrorsFound = 'T';
    									validationErrors += '---> VB Amount is >= PO Line Amount in Linked PWP record for the PO Line Found with IO# "' + ios + '" and Vendor Name "' + custVbText + '".\n'
    								} else {
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_PO_IDS, poTransactionLink);
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINES, poTransactionLineID);
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_APPF_LINK, pwpLineRecID);
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '');
    									payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '');
    									if (netAmt != null && netAmt != '') {
    										if ((netAmt >= 0 && (interimVBLink == null || interimVBLink == '')) || (netAmt < 0 && (interimVCLink == null || interimVCLink == '')))
    											createVBCount++;
    									}

    								}

    							}
    						}
    					}
    					payRec.commitLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                    }
                    else {
                        if (hasDiscardFlag) {
                            payRecFieldsCount--;
                        }
                    }
				}
				payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_FOUND, validationErrorsFound);
				if (validationErrorsFound == 'T') {
					payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG, validationErrors);
					scriptStatus = 'FAILED'
					Status1 = validationErrors;
				} else {
					payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG, '');

					scriptStatus = 'SUCCESS';
					Status1 = '';
				}
				if (createVBCount == payRecFieldsCount) {
					payRec.setFieldValue(FLD_INTERIM_HEADER_VB_CREATE, 'T');
				} else
					payRec.setFieldValue(FLD_INTERIM_HEADER_VB_CREATE, 'F');


				var processesCounts = payRec.getFieldValue(CUST_FLD_REPROCESSINGS);
				if (processesCounts == null || processesCounts == '')
					processesCounts = 0

				processesCounts = parseFloat(processesCounts) + 1

				payRec.setFieldValue(CUST_FLD_REPROCESSINGS, processesCounts);

				nlapiSubmitRecord(payRec, true, true);
				if (scriptStatus != null && scriptStatus != '') {
					if (nsOrderRecordID == null || nsOrderRecordID == '')
						nsOrderRecordID = ''
					integrationResponseObj.NetsuiteId = nsOrderRecordID;

					if (vendorNameinVB == null || vendorNameinVB == '')
						vendorNameinVB = '';
					integrationResponseObj.VendorID = vendorNameinVB;

					if (invReferenceNumber == null || invReferenceNumber == '')
						invReferenceNumber = '';
					integrationResponseObj.InvoiceReferenceNumber = invReferenceNumber;

					if (scriptStatus != null && scriptStatus != '')
						integrationResponseObj.IntegrationResponseStatus = scriptStatus
					else
						integrationResponseObj.IntegrationResponseStatus = (validationErrorsFound == 'T') ? 'FAILED' : 'SUCCESS'

					integrationResponseObj.IntegrationResponseMessage = Status1;
					var url = URL_BASE + QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE + '/messages/head?api-version=2015-01';
					var body = JSON.stringify(integrationResponseObj);
					var HEADERS = {
						"Authorization": 'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'
					};

					var srchInterimMasterLogFils = [];
					srchInterimMasterLogFils.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
					srchInterimMasterLogFils.push(new nlobjSearchFilter(FLD_APPF_INTERM_MASTER_LOG_INTERIM_LINK, null, 'anyof', nsOrderRecordID));

					var srchInterimMasterLogCols = [];
					srchInterimMasterLogCols.push(new nlobjSearchColumn('internalid').setSort(true));
					srchInterimMasterLogCols.push(new nlobjSearchColumn(FLD_APPF_INTERM_MASTER_LOG_CORRELATION_ID));

					var srchInterimMasterLogSearch = nlapiSearchRecord(CUSTOMRECORD_APPF_INTERM_MASTER_LOG, null, srchInterimMasterLogFils, srchInterimMasterLogCols);
					var CorrelationId = '';
					if (srchInterimMasterLogSearch != null && srchInterimMasterLogSearch != '') {
						CorrelationId = srchInterimMasterLogSearch[0].getValue(FLD_APPF_INTERM_MASTER_LOG_CORRELATION_ID);

					}

					//HEADERS.scriptStatus=scriptStatus
					if (CorrelationId == null || CorrelationId == '')
						CorrelationId = ''
					HEADERS['NServiceBus.CorrelationId'] = CorrelationId
					HEADERS['NServiceBus.EnclosedMessageTypes'] = NS_CLIENT
					var responseData = nlapiRequestURL(url, body, HEADERS, null, 'POST');
					nlapiLogExecution('debug', 'responseData.getCode()!:', responseData.getCode());
				}
			} catch (ex) {
				if (ex instanceof nlobjError) {
					nlapiLogExecution('DEBUG', 'System Error updating:' + recordId, ex.getDetails());
					//errmsg = e.getDetails();
				} else {
					nlapiLogExecution('DEBUG', 'Unexpected Error updating:' + recordId, ex.toString());
					//errmsg = e.toString();
				}
				//recordId
				//nlapiLogExecution('debug', 'ERROR', e);
			}
			if (context.getRemainingUsage() <= 1000 && (f + 1) < fileContents.length) {
				var params = {};
				params[SPARAM_INDEX] = parseInt(f) + 1;
				params[SPARAM_FILE] = fileid;
				nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
				processCompleted = false;
				break;
			}
		}
		if (processCompleted)
			nlapiDeleteFile(fileid)

	}
}

function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);

	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];

	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);

		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}

	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}
