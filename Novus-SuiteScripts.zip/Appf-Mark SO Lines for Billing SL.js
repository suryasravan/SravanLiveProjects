/*  Script Name: Appf-Mark SO Lines for Billing SL
 *  Script Type: Suitelet
 *  Company 	 : Appficiency
 *  Version    Date            Author           Remarks
 *  1.0       27 Feb 2020     Manikanta		This script displays an UI/form with filters and columns based on Saved Search of Sales Order line items which provides users with ability to mark multiple lines as Ready for Billing
 *  1.1       04 Aug 2020    MJ De Asis      Added new filters fields such as: Bill Month, Placement # and Strata Estimate #
 */

var FLD_SL_CLIENT = 'custpage_client';
var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
var FLD_SL_PROJECT = 'custpage_project';
var FLD_SL_SERVICE_DATE_FROM = 'custpage_service_date_from';
var FLD_SL_SERVICE_DATE_TO = 'custpage_service_date_to';
var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
var FLD_SL_START_DATE_FROM= 'custpage_start_date_from';
var FLD_SL_END_DATE_TO= 'custpage_end_date_to';
var FLD_SL_END_DATE_FROM= 'custpage_end_date_from';
var FLD_SL_IO_NUM = 'custpage_io_num';
var FLD_SL_IN_NUM = 'custpage_inv_num';
var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_CURRENCY='custpage_currency';
var FLD_SL_POP_RECEIVED = 'custpage_pop_received';
var FLD_SL_TOTAL_AMOUNT = 'custpage_total_amount';
var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
// 1.1 new Filters
var FLD_SL_BILL_MONTH = 'custpage_bill_month';
var FLD_SL_PLACEMENT_NUM = 'custpage_placement_num';
var FLD_SL_STRATA_ESTIMATE_NUM = 'custpage_strata_est_num';

var FLD_PWP_PROJECT = 'custrecord_appf_pwp_project';
var FLD_COL_SO_PWP_CUSTOM_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_SO_MEDIA_SEGMENT = 'line.cseg_appf_media_seg';
var FLD_COL_SO_IO_NUM = 'custcol_appf_ionum';
// 1.1 new Filters' column
var FLD_COL_SO_BILLMONTH = 'custcol_appf_bill_month';
var FLD_COL_SO_PLACEMENTNUM = 'custcol_appf_dig_placementnum';
var FLD_COL_SO_STRATAESTIMATENUM = 'custcol_appf_strata_estimatenum';

var FLD_COL_SO_POP_RECEIVED = 'custcol_appf_pop_received';
var FLD_CONTRACT_IN_SOS='custbody_appf_client_contract'

var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
var CUSTOM_RECORD_CLIENTS = 'customrecord_appf_client_contract';

var SCRIPT_MARK_SO_LINES_BILLING_VALIDATIONS = 'customscript_appf_mark_so_lines_bill_cl';
var SPARAM_MARK_SO_LINES_FOR_BILLING_SS = 'custscript_appf_ready_for_processing_ss';
var SPARAM_MARK_SO_BILLING_FOLDER = 'custscript_appf_mark_so_lines_billing_fl';

var SL_SUBLIST = 'custpage_sl_sublist';
var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
var FLD_COL_SL_INTERNAL_ID = 'custpage_so_internal_id';
var FLD_CONTRACT_IN = 'custrecord_appf_contract_invoice_day';
var BTN_MARK_ALL = 'custpage_btn_mark_all';
var BTN_UNMARK_ALL = 'custpage_btn_unmark_all';
var BTN_APPLY_FILTER = 'custpage_apply_filters';

var SCRIPT_MARK_LINES_BILLING_SC = 'customscript_appf_mark_so_lines_bill_sc';
var SPARAM_CSV_FILE_ID = 'custscript_appf_so_lines_billing_file_id';

var FLD_GROUP_PRIMARY_INFORMATION='custpage_primary_information';
var FLD_GROUP_FILTER='custpage_filters';
var FLD_GROUP_SUMMARY='custpage_summary';

function MarkSoLinesBillingSL(request, response){
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_MARK_SO_LINES_FOR_BILLING_SS);
	var folderID = context.getSetting('SCRIPT', SPARAM_MARK_SO_BILLING_FOLDER);
	var loadSS, filts, columns, ssType;
	if(ssID!=null && ssID!='')
    {
		loadSS=nlapiLoadSearch(null, ssID);
    	filts = loadSS.getFilters();
		columns=loadSS.getColumns();
	 	ssType = loadSS.getSearchType();
	}

	if(request.getMethod() == 'GET'){
		try{

		var applyfilters = request.getParameter('applyfilters');
		var client=request.getParameter('client');
		var mediaSegment=request.getParameter('mediaSegment');
		var proj=request.getParameter('proj');
		var serviceDateFrom=request.getParameter('serviceDateFrom');
		var serviceDateTo=request.getParameter('serviceDateTo');
		var ioNum=request.getParameter('ioNum');
		var subsidiaryVal=request.getParameter('subsidiaryVal');
		var curr=request.getParameter('currency');
		var popReceived=request.getParameter('popReceived');
		var startDateFrom=request.getParameter('strtdatefrom');
		var endDateFrom=request.getParameter('enddatefrom');
		var startDateTo=request.getParameter('strtdateto');
		var endDateTo=request.getParameter('enddateto');
		var invNum=request.getParameter('invnum');
        // 1.1 new parameters
        var billMonth=request.getParameter('billmonth');
        var placementNum=request.getParameter('placementnum');
        var strataEstNum=request.getParameter('strataestnum');


		var form = nlapiCreateForm('Mark SO Lines for Billing Suitelet');
		form.setScript(SCRIPT_MARK_SO_LINES_BILLING_VALIDATIONS);
		var PrimaryInformationGroup = form.addFieldGroup(FLD_GROUP_PRIMARY_INFORMATION, 'Primary Information');
		var filternGroup = form.addFieldGroup(FLD_GROUP_FILTER, 'Filters');
		var summarySectionGroup = form.addFieldGroup(FLD_GROUP_SUMMARY, 'Summary');

		var clinetFld = form.addField(FLD_SL_CLIENT, 'select', 'Client','customer',FLD_GROUP_PRIMARY_INFORMATION);
		if(client != null && client != '')
            clinetFld.setDefaultValue(client);
			//clinetFld.setMandatory(true);

		var mediaSegFld = form.addField(FLD_SL_MEDIA_SEGMENT, 'select','Media Segment',CUSTOM_RECORD_MEDIA_SEGMENT,FLD_GROUP_FILTER);
		if(mediaSegment != null && mediaSegment != '')
			mediaSegFld.setDefaultValue(mediaSegment);

		var projectFld = form.addField(FLD_SL_PROJECT, 'select','Project', 'job',FLD_GROUP_FILTER);
		if(proj != null && proj != '')
			projectFld.setDefaultValue(proj);

		var serviceDateFromFld = form.addField(FLD_SL_SERVICE_DATE_FROM, 'date','Date Created (From)',null,FLD_GROUP_FILTER);
		if(serviceDateFrom != null && serviceDateFrom != '')
			serviceDateFromFld.setDefaultValue(serviceDateFrom);

		var serviceDateToFld = form.addField(FLD_SL_SERVICE_DATE_TO, 'date','Date Created (To)',null,FLD_GROUP_FILTER);
		if(serviceDateTo != null && serviceDateTo != '')
			serviceDateToFld.setDefaultValue(serviceDateTo);

		var startDateFromFld = form.addField(FLD_SL_START_DATE_FROM, 'date','Start Date From',null,FLD_GROUP_FILTER);
		if(startDateFrom!= null && startDateFrom!= '')
			startDateFromFld.setDefaultValue(startDateFrom);

		var startDateToFld = form.addField(FLD_SL_START_DATE_TO, 'date','Start Date To',null,FLD_GROUP_FILTER);
		if(startDateTo!= null && startDateTo!= '')
			startDateToFld.setDefaultValue(startDateTo);

		var endDateFromFld = form.addField(FLD_SL_END_DATE_FROM, 'date','End Date From',null,FLD_GROUP_FILTER);
		if(endDateFrom != null && endDateFrom != '')
			endDateFromFld.setDefaultValue(endDateFrom);

		var endDateToFld = form.addField(FLD_SL_END_DATE_TO, 'date','End Date To',null,FLD_GROUP_FILTER);
		if(endDateTo != null && endDateTo != '')
			endDateToFld.setDefaultValue(endDateTo);

		var ioNumFld = form.addField(FLD_SL_IO_NUM, 'text','IO # / BS #',null,FLD_GROUP_FILTER);
		if(ioNum != null && ioNum != '')
			ioNumFld.setDefaultValue(ioNum);

		var invFld = form.addField(FLD_SL_IN_NUM, 'select','Invoice Cycle Day of the month',null,FLD_GROUP_FILTER);
        invFld.addSelectOption('', '');
        for(var n=1; n<=28; n++){
            if(invNum != null && invNum != '' && n == invNum){
                invFld.addSelectOption(n, n, true);
            }
            else{
                invFld.addSelectOption(n, n);
            }
        }

	    var subsidiaryFld = form.addField(FLD_SL_SUBSIDIARY, 'select', 'Subsidiary','subsidiary',FLD_GROUP_PRIMARY_INFORMATION);
		//subsidiaryFld.setMandatory(true);
        if(subsidiaryVal != null && subsidiaryVal != '')
            subsidiaryFld.setDefaultValue(subsidiaryVal);
            if(client != null && client != '')
                subsidiaryFld.setDisplayType('disabled')
            else
                subsidiaryFld.setDisplayType('normal')

        var currencyFld = form.addField(SL_FLD_CURRENCY, 'select', 'Currency','currency',FLD_GROUP_PRIMARY_INFORMATION);
        currencyFld.setDisplayType('disabled');
        if(curr != null && curr != '')
            currencyFld.setDefaultValue(curr);
        currencyFld.setBreakType('startcol')

		var popReceivedFld = form.addField(FLD_SL_POP_RECEIVED, 'select', 'POP Received',null,FLD_GROUP_FILTER);
        popReceivedFld.addSelectOption('','',(popReceived==null||popReceived=='')?true:false);
        popReceivedFld.addSelectOption('T','Yes',(popReceived=='T')?true:false);
        popReceivedFld.addSelectOption('F','No',(popReceived=='F')?true:false);

        // 1.1 Start: New Filters
        var billMonthFld = form.addField(FLD_SL_BILL_MONTH, 'text', 'Bill Month', null, FLD_GROUP_FILTER);
        if (billMonth != null && billMonth != '')
            billMonthFld.setDefaultValue(billMonth);

        var placementNumFld = form.addField(FLD_SL_PLACEMENT_NUM, 'text', 'Placement #', null, FLD_GROUP_FILTER);
        if (placementNum != null && placementNum != '')
            placementNumFld.setDefaultValue(placementNum);

        var strataEstNumFld = form.addField(FLD_SL_STRATA_ESTIMATE_NUM, 'text', 'Strata Estimate #', null, FLD_GROUP_FILTER);
        if (strataEstNum != null && strataEstNum != '')
            strataEstNumFld.setDefaultValue(strataEstNum);
        // 1.1 End: New Filters

        var totalAmtFld = form.addField(FLD_SL_TOTAL_AMOUNT, 'currency', 'Total Amount',null,FLD_GROUP_SUMMARY).setDisplayType('disabled');
		var totalLines = form.addField(FLD_SL_TOTAL_LINES, 'integer', 'Total Lines',null,FLD_GROUP_SUMMARY).setDisplayType('disabled');
		if(applyfilters == 'T')
        {
            var suiteletSublist = form.addSubList(SL_SUBLIST,'list', 'Sales Orders');
            suiteletSublist.addButton(BTN_MARK_ALL, 'Mark All', 'markAll();');
            suiteletSublist.addButton(BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
            var selctedFld = suiteletSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
            selctedFld.setDisplayType('entry');
            selctedFld.setDefaultValue('T');
            //suiteletSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');
            var filters =[];
            if(client != null && client != '')
                filters.push(new nlobjSearchFilter('name', null, 'anyof', client));

            if(mediaSegment != null && mediaSegment != '')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_MEDIA_SEGMENT, null, 'anyof', mediaSegment));

            if(proj != null && proj != '')
                filters.push(new nlobjSearchFilter(FLD_PWP_PROJECT, FLD_COL_SO_PWP_CUSTOM_RECORD, 'anyof', proj));

            if(serviceDateFrom != null && serviceDateFrom != '' && serviceDateTo != null && serviceDateTo != '')
                filters.push(new nlobjSearchFilter('trandate', null, 'within', serviceDateFrom, serviceDateTo));
            if(serviceDateFrom != null && serviceDateFrom != '' && (serviceDateTo == null || serviceDateTo == ''))
                filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', serviceDateFrom));
            if((serviceDateFrom == null || serviceDateFrom == '') && serviceDateTo != null && serviceDateTo != '')
                filters.push(new nlobjSearchFilter('trandate', null, 'onorbefore', serviceDateTo));

            if(startDateFrom != null && startDateFrom != '' && startDateTo != null && startDateTo != '')
                filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'within', startDateFrom, startDateTo));
            if(startDateFrom != null && startDateFrom != '' && (startDateTo == null || startDateTo == ''))
                filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'onorafter', startDateFrom));
            if((startDateFrom == null || startDateFrom == '') && startDateTo != null && startDateTo != '')
                filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'onorbefore', startDateTo));

            if(endDateFrom != null && endDateFrom != '' && endDateTo != null && endDateTo != '')
                filters.push(new nlobjSearchFilter('custcol_appf_so_line_enddate', null, 'within', endDateFrom, serviceDateTo));
            if(endDateFrom != null && endDateFrom != '' && (endDateTo == null || endDateTo == ''))
                filters.push(new nlobjSearchFilter('custcol_appf_so_line_enddate', null, 'onorafter', endDateFrom));
            if((endDateFrom == null || endDateFrom == '') && endDateTo != null && endDateTo != '')
                filters.push(new nlobjSearchFilter('custcol_appf_so_line_enddate', null, 'onorbefore', endDateTo));

            if(ioNum != null && ioNum != '')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_IO_NUM, null, 'is', ioNum));

            if(invNum != null && invNum != '')
                filters.push(new nlobjSearchFilter(FLD_CONTRACT_IN, FLD_CONTRACT_IN_SOS, 'equalto', invNum));

            if(subsidiaryVal != null && subsidiaryVal != '')
                filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsidiaryVal));

            if(popReceived == 'T')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_POP_RECEIVED, null, 'is', popReceived));
            if(popReceived == 'F')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_POP_RECEIVED, null, 'is', 'F'));
            nlapiLogExecution('debug','filters len',(filters!=null)?filters.length:0)

            if (billMonth != null && billMonth != '')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_BILLMONTH, null, 'is', billMonth.trim()));

            if (placementNum != null && placementNum != '')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_PLACEMENTNUM, null, 'is', placementNum.trim()));

            if (strataEstNum != null && strataEstNum != '')
                filters.push(new nlobjSearchFilter(FLD_COL_SO_STRATAESTIMATENUM, null, 'is', strataEstNum.trim()));

            if(ssID != null && ssID != ''){
	 	         var colArray=[];
                 var colIndex=1;
                 var scriptfieldcounter = 1;
                 for(var c=0;c<columns.length;c++)
                 {
                     var colObj = columns[c];
                     var colName = colObj.getName();
                     var colLabel = colObj.getLabel();
                     colName = colName.replace('.', '_');
                     if(colArray.indexOf(colName) == -1)
                     {
                         colArray.push(colName);
                     }
                     else
                     {
                         colName=colName+colIndex;
                         colArray.push(colName);
                         colIndex++;
                     }
                     if (colLabel != 'Script Use DNR')
                     {
                         suiteletSublist.addField('custpage_'+colName, 'text', colLabel);
                     }
                     else
                     {
                         var scriptField = suiteletSublist.addField('custpage_scriptfield'+scriptfieldcounter, 'text', colLabel);
                         scriptField.setDisplayType('hidden');
                         scriptfieldcounter++;
                     }
                 }

                 var resultFilters = filters.concat(filts);

                 var searchResults=getAllSearchResults(ssType, resultFilters, columns);
                 if (searchResults != null && searchResults != '') {
                     for(var s = 0; s < searchResults.length; s++) {
                         var result = searchResults[s];
                         var internalid = result.getId();
                         var colIndex = 1;
                         var colArray = [];
                         var scriptfieldcounter = 1;
                         for(var c=0;c<columns.length;c++){
                             var colObj = columns[c];
                             var columnName = colObj.getName();
                             var colLabel = colObj.getLabel();
                             columnName = columnName.replace('.', '_');
                             var ssResultValue = result.getValue(colObj);
                             if(colObj.getType() == 'select')
                             {
                                 ssResultValue = result.getText(colObj);
                             }
                             if(colArray.indexOf(columnName) == -1)
                             {
                                 colArray.push(columnName);
                             }
                             else
                             {
                                 columnName=columnName+colIndex;
                                 colArray.push(columnName);
                                 colIndex++;
                             }
                             if(columnName == 'tranid'){
                                 var url=nlapiResolveURL('RECORD','salesorder',internalid);
                                 var redirect ='<a href='+url+' target="_blank">'+ssResultValue+'</a>';
                                 ssResultValue = redirect;
                             }
                             if (colLabel != 'Script Use DNR')
                             {
                                 suiteletSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
                             }
                             else
                             {
                                 suiteletSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounter, s+1, ssResultValue);
                                 scriptfieldcounter++;
                             }
                         }
                     }
                 }
             }
		}

		form.addButton(BTN_APPLY_FILTER, 'Apply Filters', 'applyFilters()');
		form.addSubmitButton('Submit');
		response.writePage(form);
	}catch (e) {
        if ( e instanceof nlobjError )
            nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
        else
            nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
        }
    }
	else{
		try{
			var count = request.getLineItemCount(SL_SUBLIST);

			if(count > 0 && columns != null && columns != ''){
                var csvData = '';
                var labelctr = 1;
                for(var cl=0; cl<columns.length; cl++){
                    var colObj = columns[cl];
                    var colLabel = colObj.getLabel();
                    if (colLabel == 'Script Use DNR')
                    {
                        colLabel += ' ' +labelctr;
                        labelctr++;
						csvData += colLabel+',';
                    }
                    
                }
                csvData = csvData.slice(0, -1)+'\n';
                for(var c=1; c<=count; c++){
                    if(request.getLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c) == 'T'){
                        var scriptfieldcounter = 1;
                        for(var cl=0; cl<columns.length; cl++){
                            var colObj = columns[cl];
							var colLabel = colObj.getLabel();
							var colName = colObj.getName();
							colName = colName.replace('.', '_');
							var colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_'+columnName, c);
							if (colLabel == 'Script Use DNR')
							{
								colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield'+scriptfieldcounter, c);
								scriptfieldcounter++;
								csvData += colValue+',';
							}
							
						}
						csvData = csvData.slice(0, -1)+'\n';
					}
				}
				var timestamp = new Date().getTime();
				var csvFile = nlapiCreateFile('SelectedSOData_'+timestamp+'.csv', 'CSV', csvData);
				csvFile.setFolder(folderID);
				var csvFileID = nlapiSubmitFile(csvFile);
				if(csvFileID != null && csvFileID != ''){
					var params = {};
					params[SPARAM_CSV_FILE_ID] = csvFileID;
					nlapiScheduleScript(SCRIPT_MARK_LINES_BILLING_SC, null, params);
					response.sendRedirect('TASKLINK', 'ADMI_IMPORTCSV_LOG');
				}
			}

		}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
	}
}

function getAllSearchResults(record_type, filters, columns)
{
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);
    var searchRan = search.runSearch()
    ,	bolStop = false
    ,	intMaxReg = 1000
    ,	intMinReg = 0
    ,	result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
    {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000)
        {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array)
{
    return target.concat(array); // TODO: use _.union
}
