/*
 *Script Name: Appf-Vendor Discrepancy Validations CL
 *Script Type: Client Script
 *Description: This script will do client side validations for Appf-Vendor Discrepancy SL
 *Company 	: Appficiency.
 */
var SL_FLD_BUYING_SYSTEM = 'custpage_buying_system';
var SL_FLD_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_DISCREPENCY_TYPE = 'custpage_discrepancy_type';
var SL_FLD_ACTION = 'custpage_action';
var SL_FLD_VB_REF = 'custpage_vb_ref';
var SL_FLD_VB_IO = 'custpage_vb_io';
var SL_FLD_VENDOR = 'custpage_vendor';
/// v1.1
var SL_FLD_CLIENT = 'custpage_client';
var SL_FLD_MEDIA_SUPPLIER = 'custpage_media_supplier';
var SL_FLD_MEDIA_SUPPLIER_STATE = 'custpage_media_supplier_state';
var SL_FLD_CORPORATE_OWNER = 'custpage_corporate_owner';
var SL_FLD_VB_PLACEMENT = 'custpage_vb_placement';
var SL_FLD_VB_BS = 'custpage_vb_bs';
var SL_FLD_VB_ESTIMATE = 'custpage_vb_estimate';
var SL_FLD_VB_LOCATION = 'custpage_vb_location';
var SCRIPT_SUITELET = 'customscript_appf_vendor_discrepancy_sl';
var DEPLOY_SUITELET = 'customdeploy_appf_vendor_discrepancy_sl';
var SL_SUBLIST = 'custpage_custom_line';
var SL_COL_UPDATE = 'custpage_update';
var SL_COL_DISCREPANCY_TYPE = 'custpage_discrepancy_type';
var VALUE_BUYING_SYSTEM_DIGITAL = '3';
var VALUE_BUYING_SYSTEM_OOH = '2';

var SL_FLD_ORIG_VB_DATE = 'custpage_orig_vb_date';
var FLD_SL_CORPORATE_OWNER = 'custpage_sl_corporate_owner';
var FLD_SL_CORPORATE_STATE = 'custpage_sl_corporate_state';


function buyingSystemFieldChange(type, name, linenum) {
	if (name == SL_FLD_BUYING_SYSTEM) {
		var buyingsystem = nlapiGetFieldValue(SL_FLD_BUYING_SYSTEM);
		var vbEstimateField = nlapiGetField(SL_FLD_VB_ESTIMATE);
		//var vbLocField = nlapiGetField(SL_FLD_VB_LOCATION);
		var vbPlacementField = nlapiGetField(SL_FLD_VB_PLACEMENT);
		var vbBSField = nlapiGetField(SL_FLD_VB_BS);
		if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) {
			vbEstimateField.setDisplayType('normal');
			//vbLocField.setDisplayType('normal');
			nlapiSetFieldValue(SL_FLD_VB_PLACEMENT, '');
			nlapiSetFieldValue(SL_FLD_VB_BS, '');
			vbPlacementField.setDisplayType('disabled');
			vbBSField.setDisplayType('disabled');
		} else if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) {
			vbPlacementField.setDisplayType('normal');
			vbBSField.setDisplayType('normal');
			nlapiSetFieldValue(SL_FLD_VB_ESTIMATE, '');
			//nlapiSetFieldValue(SL_FLD_VB_LOCATION, '');
			vbEstimateField.setDisplayType('disabled');
			//vbLocField.setDisplayType('disabled');
		} else {
			nlapiSetFieldValue(SL_FLD_VB_ESTIMATE, '');
			//nlapiSetFieldValue(SL_FLD_VB_LOCATION, '');
			nlapiSetFieldValue(SL_FLD_VB_PLACEMENT, '');
			nlapiSetFieldValue(SL_FLD_VB_BS, '');
			vbPlacementField.setDisplayType('disabled');
			vbBSField.setDisplayType('disabled');
			vbEstimateField.setDisplayType('disabled');
			//vbLocField.setDisplayType('disabled');
		}
	}
}

function applyFilters() {
	var buyingSystem = nlapiGetFieldValue(SL_FLD_BUYING_SYSTEM);
	if (buyingSystem == null) buyingSystem = '';
	var subsidiary = nlapiGetFieldValue(SL_FLD_SUBSIDIARY);
	if (subsidiary == null) subsidiary = '';
	var discrepancyType = nlapiGetFieldValue(SL_FLD_DISCREPENCY_TYPE);
	if (discrepancyType == null) discrepancyType = '';
	var vBRef = nlapiGetFieldValue(SL_FLD_VB_REF);
	if (vBRef == null) vBRef = '';
	var vBIO = nlapiGetFieldValue(SL_FLD_VB_IO);
	if (vBIO == null) vBIO = '';
	var vendor = nlapiGetFieldValue(SL_FLD_VENDOR);
	if (vendor == null) vendor = '';
	/// v1.1
	var client = nlapiGetFieldValues(SL_FLD_CLIENT);
	if (client == null) client = '';
	var mediaSupplier = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER);
	if (mediaSupplier == null) mediaSupplier = '';
	var mediaSupplierState = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER_STATE);
	if (mediaSupplierState == null) mediaSupplierState = '';
	var vBPlacement = nlapiGetFieldValue(SL_FLD_VB_PLACEMENT);
	if (vBPlacement == null) vBPlacement = '';
	var vBbS = nlapiGetFieldValue(SL_FLD_VB_BS);
	if (vBbS == null) vBbS = '';
	var vBEstimate = nlapiGetFieldValue(SL_FLD_VB_ESTIMATE);
	if (vBEstimate == null) vBEstimate = '';

	var origVBDateVal = nlapiGetFieldValue(SL_FLD_ORIG_VB_DATE);  //added 2/19/2021
	if (origVBDateVal != null && origVBDateVal != '') filtersApplied = true;  //added 2/19/2021
	
	var corporateOwner = nlapiGetFieldValue(FLD_SL_CORPORATE_OWNER);  //added 2/19/2021
	if (corporateOwner != null && corporateOwner != '') filtersApplied = true;  //added 2/19/2021
	
	var corporateState = nlapiGetFieldValue(FLD_SL_CORPORATE_STATE);  //added 2/19/2021
	if (corporateState != null && corporateState != '') filtersApplied = true;  //added 2/19/2021
	//var vBLocation = nlapiGetFieldValue(SL_FLD_VB_LOCATION);
	//if(vBLocation == null)
	//vBLocation = '';
	if (buyingSystem != null && buyingSystem != '' && subsidiary != null && subsidiary != '') {
		var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_SUITELET, DEPLOY_SUITELET);
		suiteletURL = suiteletURL + '&buysystem=' + buyingSystem + '&subs=' + subsidiary + '&discrepancytype=' + discrepancyType + '&vbref=' + vBRef + '&vbio=' + vBIO + '&vendor=' + vendor + '&mediasupp=' + mediaSupplier + '&mediasuppstate=' + mediaSupplierState + '&vbPlacementNum=' + vBPlacement + '&vbestimate=' + vBEstimate + '&vbbs=' + vBbS;

		/// v1.1
		suiteletURL += '&client=' + client;
		
		suiteletURL += '&origVBDateVal=' + origVBDateVal;
		suiteletURL += '&corporateOwner=' + corporateOwner;
		suiteletURL += '&corporateState=' + corporateState;

		window.open(suiteletURL, '_self');
	} else if (buyingSystem == '' && subsidiary != '') {
		alert('Please enter value for the field: Buying System');
	} else if (buyingSystem != '' && subsidiary == '') {
		alert('Please enter value for the field: Subsidiary');
	} else {
		alert('Please enter value(s) for the fields: Buying System, Subsidiary');
	}
}

function onSave() {
	var counter = 0;
	var isNotValid = false;
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	if (count > 0) {
		for (var i = 1; i <= count; i++) {
			var checkbox = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i);
			var isdiscrepancy = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_DISCREPANCY_TYPE, i);
			//alert(isdiscrepancy);
			if (checkbox == 'T') {
				counter++;
				if (isdiscrepancy == null || isdiscrepancy == '') {
					isNotValid = true;
				}
			}
		}
	}
	//alert(isUpdates);
	if (counter == 0) {
		alert('Please select atleast one line to proceed.');
		return false;
	} else {
		if (isNotValid) {
			alert('Set Action / New Discrepancy Type field cannot be empty for the line you are trying to update. Please select a valid value');
			return false;
		} else {
			var isOKToProceed = confirm('Selected transactions will be submitted for Discrepancy processing, Click OK to proceed');
			if (!isOKToProceed) return false;
		}
	}
	return true;
}

function unmarkAll() {
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	for (var i = 1; i <= count; i++) {
		nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i, 'F');
	}
}

function markAll() {
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	for (var i = 1; i <= count; i++) {
		nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i, 'T');
	}
}
