/**
 * Script name: Appf-Split PO into Bills UE
 * Script type: User Event
 * Event type :	Before Load
 * Description: This script checks if there are Split Vendor bill custom records for 100% and displays the button 'Create Split Bills'.
 * Company    : Appficeincy Inc.
 */
  
 var FLD_SPLIT_VEND_INVOICE_PERCENT = 'custrecord_appf_split_vendor_inv_invperc';
 var FLD_SPLIT_VEND_INVOICE_PO_LINK = 'custrecord_appf_split_vendor_inv_po_link';
 var FLD_SPLIT_INVOICE_SUB_VENDOR = 'custrecord_appf_split_vendor_inv_sub_ven';

var FLD_SPLIT_VEND_INVOICES_BACKLINK = 'custbody_appf_split_vendor_inv_link';
 
var CUSTOM_RECORD_SPLIT_VEND_INVOICE = 'customrecord_appf_split_vendor_invoicing';
 
var BTN_CREATE_SPLIT_VEND_INVOICE ='custpage_create_split_invoice';
var SCRIPT_CREATE_INVOICE_FOR_PO_SPLIT_INVOICING = 'customscript_split_vend_bills_po_sl';
var DEPLOY_CREATE_INVOICE_FOR_PO_SPLIT_INVOICING = 'customdeploy_split_vend_bills_po_sl';

function beforeLoadPOtoVB(type,form)
{
  /*if(type=='create' || type=='copy')
  {
    nlapiSetFieldValues(FLD_SPLIT_VEND_INVOICES_BACKLINK,null);
    count=nlapiGetLineItemCount('item');
    if(count>0)
      {
		for(var i=1;i<=count;i++)
          {
           nlapiSetLineItemValue('item', FLD_COL_SO_CONSOLIDATED_PO, i,'');
          }
      }
  }*/
  
  if(type=='view')
  {
	  try{
		var recordId = nlapiGetRecordId();
		var recordType = nlapiGetRecordType();
		
		var poStatus=nlapiGetFieldValue('status');
        var splitVendInvoicesBacklink = nlapiGetFieldValue(FLD_SPLIT_VEND_INVOICES_BACKLINK);
		var totalPercentage=0;
		var fils = [];
		var cols = [];
		
		fils.push(new nlobjSearchFilter(FLD_SPLIT_VEND_INVOICE_PO_LINK, null, 'anyof', [recordId]));
		fils.push(new nlobjSearchFilter(FLD_SPLIT_VEND_INVOICE_PERCENT, null, 'isnotempty'));
		
		cols.push(new nlobjSearchColumn(FLD_SPLIT_VEND_INVOICE_PERCENT));
		cols.push(new nlobjSearchColumn(FLD_SPLIT_INVOICE_SUB_VENDOR));
		
		var splitVendInvoiceResults = nlapiSearchRecord(CUSTOM_RECORD_SPLIT_VEND_INVOICE, null, fils, cols);
    
    var invoicesFils = [];
         invoicesFils.push(new nlobjSearchFilter('type', null, 'anyof', ['VendBill']));
         invoicesFils.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
         invoicesFils.push(new nlobjSearchFilter('createdfrom', null, 'anyof', [recordId]));
    
    var invoicesSearch = nlapiSearchRecord('transaction', null, invoicesFils, null);
	
	nlapiLogExecution('DEBUG', 'no of existing bills', (invoicesSearch!=null && invoicesSearch != '')?invoicesSearch.length:0);	
if(poStatus == 'Pending Bill' && (invoicesSearch == null || invoicesSearch == '') && splitVendInvoiceResults != null && splitVendInvoiceResults != '' && (splitVendInvoicesBacklink==null || splitVendInvoicesBacklink == ''))
		{
				
			for(var s=0;s<splitVendInvoiceResults.length;s++)
			{
				nlapiLogExecution('DEBUG', 'inside', 'inside');
				var splitVendInvoicePercent=splitVendInvoiceResults[s].getValue(FLD_SPLIT_VEND_INVOICE_PERCENT);
				var splitVendInvoicePercentValue=splitVendInvoicePercent.slice(0,-1);
				totalPercentage=parseFloat(totalPercentage)+parseFloat(splitVendInvoicePercentValue);
			}
          nlapiLogExecution('DEBUG', 'totalPercentage bfr round', totalPercentage);
                    totalPercentage=Math.round(totalPercentage*100)/100;
					nlapiLogExecution('DEBUG', 'totalPercentage afr round', totalPercentage);
			if(totalPercentage == 100)
			{
				var url=nlapiResolveURL('SUITELET',SCRIPT_CREATE_INVOICE_FOR_PO_SPLIT_INVOICING,DEPLOY_CREATE_INVOICE_FOR_PO_SPLIT_INVOICING);
				url+='&poRecordId='+recordId;
				form.addButton(BTN_CREATE_SPLIT_VEND_INVOICE, 'Create Split Bills','window.open(\''+url+'\',\'_self\')');
			}
		}
			}catch(e){
		if ( e instanceof nlobjError )
		nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
		nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
  }
}