/**
 *@NApiVersion 2.1
 *@NScriptType ScheduledScript
 */

/*Script Name:  appf-Create VB/VC from Master CATCH-UP SC
 
*Script Type: ScheduledScript 
*Description: This script acts as catch up script to reprocess any failed Novus master vendor invoices
* Company   : Appficiency.
*/

var SCRIPT_CREATE_VBVC = 'customscript_appf_sync_vb_vc_sch';
var DEPLOY_CREATE_VB_VC = 'customdeploy_appf_create_vb_vc_catch_up';

define( [ 'N/file', 'N/search', 'N/config', 'N/record', 'N/format', 'N/runtime', 'N/task' ], function ( file, search, config, record, format, runtime, task ) {
     const execute = ( context ) => {

          var scTask = task.create( {
               taskType: task.TaskType.SCHEDULED_SCRIPT,
               scriptId: SCRIPT_CREATE_VBVC,
               deploymentId: DEPLOY_CREATE_VB_VC,
               params: {'custscript_from_catchup_script': 'T'}
          } );

          var scTaskId = scTask.submit();
     }
     return {
          execute: execute
     };
} );