/*
* Script Name : Appf-Sync VB/VC from Interim SC
* Script Type : UserEvent
* Event Type  : After Submit
* Description : This script syncs the fields from Interim Header and Interim Child records to the header and line fields of VB or VC
* Company     :	Appficiency Inc.
*/
 var SPARAM_INTERM_RECS_SS_CHILD = 'custscript_appf_eligible_vb_interim_res';
  var SPARAM_INTERM_REC_TYPE = 'custscript_appf_interim_rec_type';
 var SPARAM_INTERM_REC_ID = 'custscript_appf_interim_rec_id';
 var SPARAM_INTERM_INDEX = 'custscript_appf_interim_lindex';
 var SPARAM_CUSTOM_FORM_NOVUS_VB_TAX='custscript_custom_form_for_vb_tax';
 var SPARAM_ITEM_GST_HST_TAX='custscript_gst_hst_tax_item';
var SPARAM_ITEM_QST_PST_TAX='custscript_qst_pst_tax_item';
var SPARAM_CUSTOM_FORM_NOVUS_VC_TAX='custscript_custom_form_for_vc_tax';

var FLD_COL_IO='custcol_appf_ionum'
var FLD_COL_PRINT_CIRCULATION='custcol_appf_print_circulation'
var FLD_COL_RATE='custcol_appf_novusunitrate'
var FLD_COL_MASTER='custcol_appf_masterlink'
var FLD_COL_LINKS='custcol_appf_childlink'
var FLD_COL_IO='custcol_appf_ionum'
var FLD_COL_PUBLISH='custcol_appf_publisher'
var FLD_COL_LINE_IDS='custcol_appf_line_id'
var FLD_COL_PP_RECS='custcol_appf_pwp_custom_record'
var FLD_COL_PO_LINES='custcol_appf_po_line_id'
 var CUSTOM_RECORD_INTERIM_CHILD='customrecord_appf_interim_vb_line'
 var FLD_IV_VB_LINKS='custrecord_appf_ivbl_vblink'
 var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'
 var SPARAM_VB_FIELDS = 'custscript_vb_header_fields_sync';
 var SPARAM_VB_LINE_FIELDS = 'custscript_vb_line_fields_sync';
 var FLD_IV_VC_LINKS='custrecord_appf_ivbl_vclink'
 var SPARAM_VC_FIELDS = 'custscript_vc_header_fields_sync';
 var SPARAM_VC_LINE_FIELDS = 'custscript_vc_line_fields_sync';
 var FLD_IV_VC_NET='custrecord_appf_ivbl_vendor_net'
 var FLD_INTERIM_PARENT_LINK = 'custrecord_appf_interimheader';
 
 var FLD_IV_GST_HST = 'custrecord_appf_ivb_gst';
 var FLD_IV_PST_QST = 'custrecord_appf_ivb_qst';
 
 
var FLD_CR_IV_ON_BASED_ID= 'custrecord_appf_ivb_onbasedocid';
var FLD_CR_IV_VENDOR_NUM='custrecord_appf_ivb_vendoraccnum'

var FLD_CR_NET_AMTS= 'custrecord_appf_ivbl_vendor_net';
var FLD_CR_PO_INTERNALID= 'custrecord_appf_ivbl_po_link';
var FLD_CR_IV_DESCRIPTIONS= 'custrecord_appf_ivbl_description';
var FLD_CR_IV_IO_NUM= 'custrecord_appf_ivbl_io_num';
var FLD_CR_IV_CIRCULATIONS= 'custrecord_appf_ivbl_circulation';
var FLD_CR_IV_UNITS='custrecord_appf_ivbl_novus_unit_rt'

var SUBLIST_INTERIM_CHILD='recmachcustrecord_appf_interimheader'
var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'
var FLD_CR_INTERIM_VENDOR = 'custrecord_appf_ivb_vendor';
var FLD_CR_PO_LINE_NOS= 'custrecord_appf_ivbl_po_line_id';

var FLD_CR_INV_TRNS= 'custrecord_appf_ivb_transid';
var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';





var FLD_CR_IV_TRANS='custrecord_appf_transactions_created';
var FLD_CR_IV_DUE_DATE='custrecord_appf_ivb_due_date';
var FLD_CR_IV_GST_HST='custrecord_appf_ivb_gst';
var FLD_CR_IV_PST_QST='custrecord_appf_ivb_qst';
var FLD_CR_IV_CURRENCY='custrecord_appf_ivb_currency';
var FLD_IV_GST_HST_VB_LINK = 'custrecord_appf_ivb_gst_hst_vb';
var FLD_IV_PST_QST_VB_LINK = 'custrecord_ivb_pst_qst_vb';
var FLD_TRANSACTIOMN_FAILURE = 'custrecord_appf_transaction_failure';
var SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP='7';

function syncRecords()
{
	var allDataProcessed = true;

 
	var context=nlapiGetContext();
	var recordType = context.getSetting('SCRIPT', SPARAM_INTERM_REC_TYPE);
	var recordId = context.getSetting('SCRIPT', SPARAM_INTERM_REC_ID);
		var line_index = context.getSetting('SCRIPT', SPARAM_INTERM_INDEX);
		if (line_index == null || line_index == '')
			line_index = 0;

	    var ssIDChild = context.getSetting('SCRIPT', SPARAM_INTERM_RECS_SS_CHILD)
         nlapiLogExecution('debug','ssIDChild',ssIDChild)
	  
	   var scriptParamVBHeaderFields = context.getSetting('SCRIPT', SPARAM_VB_FIELDS)
	   var scriptParamVBLineFields = context.getSetting('SCRIPT', SPARAM_VB_LINE_FIELDS)
	   
	   var scriptParamVCHeaderFields = context.getSetting('SCRIPT', SPARAM_VC_FIELDS)
	    var scriptParamVCLineFields = context.getSetting('SCRIPT', SPARAM_VC_LINE_FIELDS)
		var CUSTOM_FORM_NOVUS_VB_TAX =context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VB_TAX);
		var ITEM_GST_HST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_GST_HST_TAX);
	var ITEM_QST_PST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_QST_PST_TAX);
	var CUSTOM_FORM_NOVUS_VC_TAX = context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VC_TAX);
		if (recordId != null && recordId != '')
		{
			var interimParentLinkRec = nlapiLoadRecord(CUSTOM_RECORD_INTERIM, recordId);
			
			var lineCount = interimParentLinkRec.getLineItemCount(SUBLIST_INTERIM_CHILD);
			var totalAmount = 0;
			
			for (var k = 1; k <= lineCount; k++)
			{
				
				var amtLine = interimParentLinkRec.getLineItemValue(SUBLIST_INTERIM_CHILD, FLD_CR_NET_AMTS, k);
				if (amtLine == null || amtLine == '')
					amtLine = 0;
				
				totalAmount = parseFloat(totalAmount) + parseFloat(amtLine);
			}
			
			interimParentLinkRec.setFieldValue('custrecord_appf_ivb_amount', totalAmount);
			
			nlapiSubmitRecord(interimParentLinkRec, true, true);
			
		}
	
			var masterVB = nlapiLoadRecord(recordType, recordId);
			var tranName=masterVB.getFieldValue('name');
			var gsthst=masterVB.getFieldValue(FLD_CR_IV_GST_HST);
			var pstqst=masterVB.getFieldValue(FLD_CR_IV_PST_QST);
			var existingGSTLink = masterVB.getFieldValue(FLD_IV_GST_HST_VB_LINK);
			var existingPSTLink = masterVB.getFieldValue(FLD_IV_PST_QST_VB_LINK);
			var mainVendor = masterVB.getFieldValue(FLD_CR_INTERIM_VENDOR);
			var invOnbase=masterVB.getFieldValue(FLD_CR_IV_ON_BASED_ID)
			var NsaltVendor=masterVB.getFieldValue('custrecord_appp_ivb_alternatevendor');
			var invdate=masterVB.getFieldValue('custrecord_appf_ivb_date');
			var invPostingPeriod = masterVB.getFieldValue('custrecord_appf_ivb_postingperiod');
			  var dueDate = masterVB.getFieldValue('custrecord_appf_ivb_due_date');
				var terms = masterVB.getFieldValue('custrecord_appf_ivb_terms');

			  var nsOrderCounts=masterVB.getLineItemCount(CUSTOM_RECORD_REC_INTERIM)
			  var NsaltVendor=masterVB.getFieldValue('custrecord_appp_ivb_alternatevendor');
			  var mainVendor = masterVB.getFieldValue(FLD_CR_INTERIM_VENDOR);
  var paymentType = masterVB.getFieldValue('custrecord_appf_ivb_payment_type');
	if (paymentType == null)
		paymentType = '';
			  var vendorSubsidiary='';
if(mainVendor !=null && mainVendor !='')
vendorSubsidiary=nlapiLookupField('vendor',mainVendor,'subsidiary');
				var poNo=masterVB.getFieldValue(FLD_CR_IV_VENDOR_NUM)
					var apAcc=masterVB.getFieldValue('custrecord_appf_ivb_account')
				if(gsthst != null && gsthst != '' && parseFloat(gsthst)>0 && (existingGSTLink == null || existingGSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP)
				{
				var vbRec = nlapiCreateRecord('vendorbill');

				if(NsaltVendor!=null  && NsaltVendor!='')
				{
				vbRec.setFieldValue('entity',NsaltVendor)
				 }
				 else
				 {
				 vbRec.setFieldValue('entity', mainVendor);
				 
				 }
				vbRec.setFieldValue('tranid',tranName+'-GST/HST');
				vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
				vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
				vbRec.setFieldValue('custbody_appf_master_vendor_date',invdate);
				//vbRec.setFieldValue('postingperiod', invPostingPeriod);
				vbRec.setFieldValue('terms', terms);
				   vbRec.setFieldValue('duedate',dueDate);
				vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
				if (apAcc != null && apAcc != '')
				vbRec.setFieldValue('account', apAcc);
                  vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
						
				vbRec.selectNewLineItem('item');
				vbRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
				vbRec.setCurrentLineItemValue('item', 'rate', 1);
				vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(gsthst));
				vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, recordId);
				vbRec.commitLineItem('item');
				var newVBID = nlapiSubmitRecord(vbRec, true, true);
				if(newVBID != null && newVBID != ''){
				nlapiLogExecution('debug', 'newVBID', newVBID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, recordId, FLD_IV_GST_HST_VB_LINK, newVBID);
				}

				}
				if(gsthst != null && gsthst != '' && parseFloat(gsthst)<0 && (existingGSTLink == null || existingGSTLink == '')  && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP)
				{
				var vcRec = nlapiCreateRecord('vendorcredit');
				if(NsaltVendor!=null  && NsaltVendor!='')
				{
				vcRec.setFieldValue('entity',NsaltVendor)
				 }
				 else
				 {
				 vcRec.setFieldValue('entity', mainVendor);
				 
				 }
				// vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
					   vcRec.setFieldValue('tranid',tranName+'-GST/HST')
					   vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
					   vcRec.setFieldValue('custbody_appf_master_vendor_date',invdate)
					   //vbRec.setFieldValue('postingperiod', invPostingPeriod);
					   vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
                  vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
				if (apAcc != null && apAcc != '')
				vcRec.setFieldValue('account', apAcc);
				vcRec.selectNewLineItem('item');
				vcRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
				vcRec.setCurrentLineItemValue('item', 'rate', 1);
				vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(gsthst)));
				vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, recordId);
				vcRec.commitLineItem('item');

				var newVCID = nlapiSubmitRecord(vcRec, true, true);
				if(newVCID != null && newVCID != ''){
				nlapiLogExecution('debug', 'newVCID', newVCID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, recordId, FLD_IV_GST_HST_VB_LINK, newVCID);
				}

				}

				if(pstqst != null && pstqst != '' && parseFloat(pstqst)>0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP)
				{
				var vbRec = nlapiCreateRecord('vendorbill');
				if(NsaltVendor!=null  && NsaltVendor!='')
				{
				vbRec.setFieldValue('entity',NsaltVendor)
				 }
				 else
				 {
				 vbRec.setFieldValue('entity', mainVendor);
				 
				 }
				vbRec.setFieldValue('tranid',tranName+'-PST/QST');
				vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
				vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
				vbRec.setFieldValue('custbody_appf_master_vendor_date',invdate);
				//vbRec.setFieldValue('postingperiod', invPostingPeriod);
				vbRec.setFieldValue('terms', terms);
				   vbRec.setFieldValue('duedate',dueDate);
                  vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
				vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
				if (apAcc != null && apAcc != '')
				vbRec.setFieldValue('account', apAcc);
				vbRec.selectNewLineItem('item');
				vbRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
				vbRec.setCurrentLineItemValue('item', 'rate', 1);
				vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(pstqst));
				vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, recordId);
				vbRec.commitLineItem('item');

				var newVBID = nlapiSubmitRecord(vbRec, true, true);
				if(newVBID != null && newVBID != ''){
				nlapiLogExecution('debug', 'newVBID', newVBID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, recordId, FLD_IV_PST_QST_VB_LINK, newVBID);
				}

				}
				if(pstqst != null && pstqst != '' && parseFloat(pstqst)<0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP)
				{
				var vcRec = nlapiCreateRecord('vendorcredit');
				if(NsaltVendor!=null  && NsaltVendor!='')
				{
				vcRec.setFieldValue('entity',NsaltVendor)
				 }
				 else
				 {
				 vcRec.setFieldValue('entity', mainVendor);
				 
				 }
				// vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
					   vcRec.setFieldValue('tranid',tranName+'-PST/QST')
					   vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
					   vcRec.setFieldValue('custbody_appf_master_vendor_date',invdate)
					   //vbRec.setFieldValue('postingperiod', invPostingPeriod);
					   vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
                  vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
				if (apAcc != null && apAcc != '')
				vcRec.setFieldValue('account', apAcc);
				vcRec.selectNewLineItem('item');
				vcRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
				vcRec.setCurrentLineItemValue('item', 'rate', 1);
				vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(pstqst)));
				vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, recordId);
				vcRec.commitLineItem('item');

				var newVCID = nlapiSubmitRecord(vcRec, true, true);
				if(newVCID != null && newVCID != ''){
				nlapiLogExecution('debug', 'newVCID', newVCID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, recordId, FLD_IV_PST_QST_VB_LINK, newVCID);
				}

				}
			
			
			
			
			//get gst and get gst link
			var gsthst = masterVB.getFieldValue(FLD_IV_GST_HST);
			var gsthstVBLink = masterVB.getFieldValue(FLD_IV_GST_HST_VB_LINK);
			var masterVBDate=masterVB.getFieldValue('custrecord_appf_ivb_date');
			var masterVBPostingPeriod = masterVB.getFieldValue('custrecord_appf_ivb_postingperiod');
			
		
			//if both are not empty
			if(gsthst != null && gsthst != '' && gsthstVBLink != null && gsthstVBLink != ''){
				var linkedRecType = nlapiLookupField('transaction', gsthstVBLink, 'type');

				//check if gst > 0 
				if(parseFloat(gsthst) >= 0){
					nlapiLogExecution('debug', 'linkedRecType synch VB', linkedRecType);
					// check if the gst vb link is of type VB
					if(linkedRecType == 'VendBill'){
            nlapiLogExecution('debug', 'inside linkedRecType synch VB', linkedRecType);
						// then update qty to new gst
						var gsthstVBRec = nlapiLoadRecord('vendorbill', gsthstVBLink);

           nlapiLogExecution('debug', 'inside gsthstVBRec', JSON.stringify(gsthstVBRec) + ' masterVBDate='+masterVBDate);
            
						if(masterVBDate !=null && masterVBDate !='')
						gsthstVBRec.setFieldValue('custbody_appf_master_vendor_date',masterVBDate);
					    //gsthstVBRec.setFieldValue('postingperiod', masterVBPostingPeriod);
                      gsthstVBRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
						
						gsthstVBRec.selectLineItem('item', 1);
						gsthstVBRec.setCurrentLineItemValue('item', 'quantity', parseFloat(gsthst));
						gsthstVBRec.commitLineItem('item');
						// submit gst vb link (bill)
						var updatedVB = nlapiSubmitRecord(gsthstVBRec, true, true);
						nlapiLogExecution('debug', 'updated GST/HST VB', updatedVB);
					}
				
				}
				//check if gst < 0 
				if(parseFloat(gsthst) <= 0){
					nlapiLogExecution('debug', 'linkedRecType', linkedRecType);
					// check if the gst vb link is of type VC
					if(linkedRecType == 'VendCred'){
						// then update qty to new gst
						var gsthstVBRec = nlapiLoadRecord('vendorcredit', gsthstVBLink);
						if(masterVBDate !=null && masterVBDate !='')
						gsthstVBRec.setFieldValue('custbody_appf_master_vendor_date',masterVBDate);
					//gsthstVBRec.setFieldValue('postingperiod', masterVBPostingPeriod);
                      gsthstVBRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
						
						gsthstVBRec.selectLineItem('item', 1);
						gsthstVBRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(gsthst)));
						gsthstVBRec.commitLineItem('item');
						// submit gst vb link (credit)
						var updatedVB = nlapiSubmitRecord(gsthstVBRec, true, true);
						nlapiLogExecution('debug', 'updated GST/HST VB', updatedVB);
					}
				}
			
			
			
			}
			
			//check if pst > 0
			var pstqst = masterVB.getFieldValue(FLD_IV_PST_QST);
			var pstqstVBLink = masterVB.getFieldValue(FLD_IV_PST_QST_VB_LINK);
			//if both are not empty
			if(pstqst != null && pstqst != '' && pstqstVBLink != null && pstqstVBLink != ''){
				var linkedRecType = nlapiLookupField('transaction', pstqstVBLink, 'type');

				//check if gst > 0 
				if(parseFloat(pstqst) >= 0){
					nlapiLogExecution('debug', 'linkedRecType', linkedRecType);
					// check if the gst vb link is of type VB
					if(linkedRecType == 'VendBill'){
						// then update qty to new gst
						var pstqstVBRec = nlapiLoadRecord('vendorbill', pstqstVBLink);
						if(masterVBDate !=null && masterVBDate !='')
						pstqstVBRec.setFieldValue('custbody_appf_master_vendor_date',masterVBDate);
                      pstqstVBRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
						//pstqstVBRec.setFieldValue('postingperiod', masterVBPostingPeriod);
						pstqstVBRec.selectLineItem('item', 1);
						pstqstVBRec.setCurrentLineItemValue('item', 'quantity', parseFloat(pstqst));
						pstqstVBRec.commitLineItem('item');
						// submit gst vb link (bill)
						var updatedVB = nlapiSubmitRecord(pstqstVBRec, true, true);
						nlapiLogExecution('debug', 'updated PST/QST VB', updatedVB);
					}
				
				}
				//check if gst < 0 
				if(parseFloat(pstqst) <= 0){
					nlapiLogExecution('debug', 'linkedRecType', linkedRecType);
					// check if the gst vb link is of type VC
					if(linkedRecType == 'VendCred'){
						// then update qty to new gst
						var pstqstVBRec = nlapiLoadRecord('vendorcredit', pstqstVBLink);
						if(masterVBDate !=null && masterVBDate !='')
						pstqstVBRec.setFieldValue('custbody_appf_master_vendor_date',masterVBDate);
                      pstqstVBRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
					//pstqstVBRec.setFieldValue('postingperiod', masterVBPostingPeriod);
						pstqstVBRec.selectLineItem('item', 1);
						pstqstVBRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(pstqst)));
						pstqstVBRec.commitLineItem('item');
						// submit gst vb link (credit)
						var updatedVB = nlapiSubmitRecord(pstqstVBRec, true, true);
						nlapiLogExecution('debug', 'updated PST/QST VB', updatedVB);
					}
				}
			
			
			
			}
		
			
		
		 var cols_int_child = [];
		 cols_int_child.push(new nlobjSearchColumn(FLD_IV_VB_LINKS));
		 		 cols_int_child.push(new nlobjSearchColumn(FLD_IV_VC_LINKS));
				 
				 if(scriptParamVBLineFields!=null && scriptParamVBLineFields!='')
{
var vbLineFieldList = scriptParamVBLineFields.split(',');
for (var vl = 0; vl < vbLineFieldList.length; vl++)
{
var interimLineFieldID = vbLineFieldList[vl].split('|')[0];
		 		 cols_int_child.push(new nlobjSearchColumn(interimLineFieldID));

}
}
if(scriptParamVCLineFields!=null && scriptParamVCLineFields!='')
{
var vcLineFieldList = scriptParamVCLineFields.split(',');
for (var vl = 0; vl < vcLineFieldList.length; vl++)
{
var interimLineFieldID = vcLineFieldList[vl].split('|')[0];
		 		 cols_int_child.push(new nlobjSearchColumn(interimLineFieldID));

}
}

cols_int_child.push(new nlobjSearchColumn(FLD_CR_NET_AMTS));
	cols_int_child.push(new nlobjSearchColumn(FLD_CR_PO_INTERNALID));
	cols_int_child.push(new nlobjSearchColumn(FLD_CR_IV_DESCRIPTIONS));
	cols_int_child.push(new nlobjSearchColumn(FLD_CR_IV_IO_NUM));
	cols_int_child.push(new nlobjSearchColumn(FLD_CR_IV_CIRCULATIONS));
	cols_int_child.push(new nlobjSearchColumn(FLD_CR_IV_UNITS));
	
var interimHeader = nlapiLoadRecord(recordType,recordId);
  
   var paymentType = interimHeader.getFieldValue('custrecord_appf_ivb_payment_type');
	if (paymentType == null)
		paymentType = '';

	  var searchResults=nlapiSearchRecord(CUSTOM_RECORD_INTERIM_CHILD, ssIDChild,new nlobjSearchFilter('internalid',FLD_INTERIM_PARENT_LINK,'anyof',recordId),cols_int_child);
	  nlapiLogExecution('debug','searchResults',searchResults)
	  var searchResultsIds=[]
	  
	  if (searchResults != null && searchResults != '') 
          {
				for(var s = line_index; s <searchResults.length; s++) 
				{
					var searchresult = searchResults[s];
					var internalId =searchresult.getId()
					try{
					 nlapiLogExecution('debug','internalId',internalId)
					 searchResultsIds.push(internalId)
//var interimLine = nlapiLoadRecord(CUSTOM_RECORD_INTERIM_CHILD,internalId);
var vblink =searchresult.getValue(FLD_IV_VB_LINKS)
var vclink =searchresult.getValue(FLD_IV_VC_LINKS)
var poLineAmounts=searchresult.getValue(FLD_CR_NET_AMTS);
if (poLineAmounts == null || poLineAmounts == '')
	poLineAmounts = 0;
	var poid=searchresult.getValue(FLD_CR_PO_INTERNALID)
	var podescription=searchresult.getValue(FLD_CR_IV_DESCRIPTIONS)
	var ioNum=searchresult.getValue(FLD_CR_IV_IO_NUM)
	var poCurculatns=searchresult.getValue(FLD_CR_IV_CIRCULATIONS)
	var poUnit=searchresult.getValue(FLD_CR_IV_UNITS)
if (vblink != null  && vblink != '')
{
var vendorBillRecord = nlapiLoadRecord('vendorbill',vblink)
nlapiLogExecution('debug','vendorBillRecord',vendorBillRecord)
 var invOnbase=interimHeader.getFieldValue(FLD_CR_IV_ON_BASED_ID)
  var invdate=interimHeader.getFieldValue('custrecord_appf_ivb_date');
  var invPostingPeriod = interimHeader.getFieldValue('custrecord_appf_ivb_postingperiod');
  var dueDate = interimHeader.getFieldValue('custrecord_appf_ivb_due_date');
    var terms = interimHeader.getFieldValue('custrecord_appf_ivb_terms');

  	var poNo=interimHeader.getFieldValue(FLD_CR_IV_VENDOR_NUM)
	  	var apAcc=interimHeader.getFieldValue('custrecord_appf_ivb_account');
		
		
		
		
		
vendorBillRecord.setFieldValue('custbody_appf_onbase_docid',invOnbase)
	vendorBillRecord.setFieldValue('custbody_appf_master_vendor_date',invdate);
	//vendorBillRecord.setFieldValue('postingperiod', invPostingPeriod);
	vendorBillRecord.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
	vendorBillRecord.setFieldValue('terms', terms);
	vendorBillRecord.setFieldValue('duedate',dueDate);
	vendorBillRecord.setFieldValue('custbody_appf_accnum_ocr', poNo);
	if (apAcc != null && apAcc != '')
	vendorBillRecord.setFieldValue('account', apAcc);
vendorBillRecord.selectLineItem('item', 1);


vendorBillRecord.setCurrentLineItemValue('item', 'quantity', poLineAmounts);
                                                       	vendorBillRecord.setCurrentLineItemValue('item', 'rate', 1);

														vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
														vendorBillRecord.setCurrentLineItemValue('item', 'description', podescription);
														vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
														vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);


if(scriptParamVBHeaderFields!=null && scriptParamVBHeaderFields!='')
{
var vbHeaderFieldList = scriptParamVBHeaderFields.split(',');
for (var vh = 0; vh < vbHeaderFieldList.length; vh++)
{
var interimHeaderFieldID = vbHeaderFieldList[vh].split('|')[0];
var vbHeaderFieldID = vbHeaderFieldList[vh].split('|')[1];
var interimHeaderFieldValue = interimHeader.getFieldValue(interimHeaderFieldID);
vendorBillRecord.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
}
}
if(scriptParamVBLineFields!=null && scriptParamVBLineFields!='')
{
var vbLineFieldList = scriptParamVBLineFields.split(',');
for (var vl = 0; vl < vbLineFieldList.length; vl++)
{
var interimLineFieldID = vbLineFieldList[vl].split('|')[0];
var vbLineFieldID = vbLineFieldList[vl].split('|')[1];
var interimLineFieldValue = searchresult.getValue(interimLineFieldID);
vendorBillRecord.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
}
}
vendorBillRecord.commitLineItem('item');

nlapiSubmitRecord(vendorBillRecord);
}
if (vclink != null  && vclink != '')
{
var vendorCreditRecord = nlapiLoadRecord('vendorcredit',vclink)
nlapiLogExecution('debug','vendorCreditRecord',vendorCreditRecord)


vendorCreditRecord.setFieldValue('custbody_appf_onbase_docid',invOnbase)
	        vendorCreditRecord.setFieldValue('custbody_appf_master_vendor_date',invdate)
			//vendorCreditRecord.setFieldValue('postingperiod', invPostingPeriod);
			
	        vendorCreditRecord.setFieldValue('custbody_appf_accnum_ocr', poNo);
			if (apAcc != null && apAcc != '')
	vendorCreditRecord.setFieldValue('account', apAcc);
  vendorCreditRecord.setFieldValue('custbody_appf_vendor_payment_type',paymentType);

vendorCreditRecord.selectLineItem('item', 1);

vendorCreditRecord.setCurrentLineItemValue('item', 'quantity', Math.abs(poLineAmounts));
vendorCreditRecord.setCurrentLineItemValue('item', 'rate', 1);

														vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
														vendorCreditRecord.setCurrentLineItemValue('item', 'description', podescription);
														vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
														vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);

if(scriptParamVCHeaderFields!=null && scriptParamVCHeaderFields!='')
{
var vcHeaderFieldList = scriptParamVCHeaderFields.split(',');
for (var vh = 0; vh < vcHeaderFieldList.length; vh++)
{
var interimHeaderFieldID = vcHeaderFieldList[vh].split('|')[0];
var vbHeaderFieldID = vcHeaderFieldList[vh].split('|')[1];
var interimHeaderFieldValue = interimHeader.getFieldValue(interimHeaderFieldID);
vendorCreditRecord.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
}
}
if(scriptParamVCLineFields!=null && scriptParamVCLineFields!='')
{
var vcLineFieldList = scriptParamVCLineFields.split(',');
for (var vl = 0; vl < vcLineFieldList.length; vl++)
{
var interimLineFieldID = vcLineFieldList[vl].split('|')[0];
var vbLineFieldID = vcLineFieldList[vl].split('|')[1];
var interimLineFieldValue = searchresult.getValue(interimLineFieldID);
nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
nlapiLogExecution('debug','vbLineFieldID',vbLineFieldID)

    if(interimLineFieldID==FLD_IV_VC_NET)
	{
	interimLineFieldValue=(-1)*interimLineFieldValue
	nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
	}
vendorCreditRecord.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
}
}
vendorCreditRecord.commitLineItem('item');

nlapiSubmitRecord(vendorCreditRecord);
}
				}
				
catch(ex)
{
	if ( ex instanceof nlobjError )
			{
		      nlapiLogExecution( 'DEBUG', 'System Error updating VB/VC for Interim Child:'+internalId, ex.getDetails() );
			  //errmsg = e.getDetails();
			}
		    else
			{
		      nlapiLogExecution( 'DEBUG', 'Unexpected Error updating VB/VC for Interim Child:'+internalId, ex.toString() );
			  //errmsg = e.toString();
			}
	//recordId
	//nlapiLogExecution('debug', 'ERROR', e);
}
if(context.getRemainingUsage() <= 1000 && (Number(s)+1)<searchResults.length){
							allDataProcessed = false;
							var params = {};
							params[SPARAM_INTERM_INDEX] = (Number(s)+1);
							params[SPARAM_INTERM_REC_TYPE] = recordType;
							params[SPARAM_INTERM_REC_ID] = recordId;
							nlapiScheduleScript(context.getScriptId(), null, params);
							break;
						}
				}
           }
		   if (allDataProcessed)
		   {
			   nlapiSubmitField(recordType, recordId, 'custrecord_appf_sync_tran_status', '2');
			   
		   }
	   
	
}
function postingPeriod(date)
{
		date=nlapiStringToDate(date);
var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
var Dt1 = nlapiDateToString(startDate);
var Dt2 = nlapiDateToString(endDate);
var filters = new Array();
filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
//filters[4] = new nlobjSearchFilter('closed',null,'is','F');

var columns = new Array();
columns[0] = new nlobjSearchColumn('internalid');
columns[1] = new nlobjSearchColumn('closed');
var search = nlapiSearchRecord('accountingperiod', null, filters, columns);
var periodId=''
if(search!=null && search!='')
{
var isclosedperiod = search[0].getValue('closed');
if(isclosedperiod!='T')
{
periodId=search[0].getValue('internalid');
}
else
{
var filters1 = new Array();
filters1[0] = new nlobjSearchFilter('startdate', null, 'onorafter', Dt1);
filters1[1] = new nlobjSearchFilter('enddate', null, 'onorafter', Dt2);
filters1[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
filters1[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
filters1[4] = new nlobjSearchFilter('closed',null,'is','F');

var columns1 = new Array();
columns1[0] = new nlobjSearchColumn('internalid');
columns1[1] = new nlobjSearchColumn('enddate').setSort();
var search = nlapiSearchRecord('accountingperiod', null, filters1, columns1);
if(search!=null && search!='')
{
periodId=search[0].getValue('internalid');
}
}
}

return periodId;
 }



