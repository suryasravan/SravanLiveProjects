/**
	 * Script Name : Appf-VVCCP Master Batch Button UE
	 * Script Type : User Event
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			 Debendra Panigrahi		This script displays Refresh buttons
	 *
	 * Company 	 : Appficiency. 
	 */

var BTN_APPROVE='custpage_approve';
var BTN_REJECT = 'custpage_reject';
var BTN_REFRESH = 'custpage_refresh';
var SUITELET_VVCCP_APPROVE_HELPER_SCRIPT_ID='customscript_appf_vvccp_master_batch_sl';
var SUITELET_VVCCP_APPROVE_HELPER_DEPLOY_ID='customdeploy_appf_vvccp_master_batch_sl';
var CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD='customrecord_appf_vvccp_batch_master';
 	var FLD_BATCH_AUTHORIZATION_AMOUNT='custrecord_appf_vvccp_batch_auth_amt';
 	var FLD_BATCH_SUBSIDIARY='custrecord_appf_vvccp_mbatch_subsidiary';
 	var FLD_TRANSACTIONS_MOVED_UNDER_PROCESSING='custrecord_appf_transactions_under_proc';
 	var FLD_MASTER_DATA_FILE='custrecord_appf_vvccp_master_file';
 	var FLD_BILL_LINE_TO_PROCESS='custrecord_appf_vvccp_master_bills';
 	var FLD_CREDIT_LINES_TO_PROCESS='custrecord_appf_vvccp_master_credits';
 	var FLD_CREDIT_LINE_PROCESSED='custrecord_appf_vvccp_master_credsmarked';
 	var FLD_BILL_LINES_PROCESSED='custrecord_appf_vvccp_master_billsmarked';
 	var FLD_BILL_DATA_FILE='custrecord_appf_vvccp_master_bill_data';
 	var FLD_MASTER_CREDIT_DATA_FILE='custrecord_appf_vvccp_master_credit_data'
 	var FLD_PROCESSED_PERCENT='custrecord_appf_vvccp_master_processed';
 	var FLD_BILL_OR_CREDIT_UPDATE_ERROR_FILE='custrecord_appf_master_update_errorfile'
 	var FLD_NUMBER_OF_AUTHORIZATION_GENERATED='custrecord_appf_vvccp_mast_auth_created';
 	var FLD_NUMBER_OF_AUTHORIZATION_TO_GENERATE='custrecord_appf_vvccp_mast_auth_to_gen';
 	var FLD_AUTHORIZATION_CREATED_SUCCESSFULLY='custrecord_appf_vvccp_master_auth_succes';
 	var FLD_APPROVAL_STATUS='custrecord_appf_vvccp_master_approvestat';
 	var FLD_TRANSACTION_SET_TO_READY_FOR_PROCESSING='custrecord_appf_trans_ready_for_process';
 	var FLD_CREDIT_LINES_UNPROCESSED='custrecord_appf_credit_lines_unprocessed';
 	var FLD_BILLS_LINES_UNPROCESSED='custrecord_appf_bill_lines_unprocessed';
 	var FLD_REJECTION_PERCENTAGE='custrecord_appf_rejection_percentage';
 	var FLD_BILL_OR_BILLCREDIT_REVERSAL_ERROR_FILE='custrecord_appf_master_unprocess_error';
	var FLD_BILL_AND_CREDIT_DETAIL_TEXT_FILE='custrecord_appf_bill_and_credit_detail';
	var VVCCP_MASTER_BATCH_APPROVE_STATUS=2;
	var VVCCP_MASTER_BATCH_REJECT_STATUS=3;
function beforeLoad(type,form,request)
{
  	try
      {
        if(type == 'view')
		{
		 
		var recId = nlapiGetRecordId();
		var recType = nlapiGetRecordType();
		var record = nlapiLoadRecord(recType, recId);  
		var refreshURL = nlapiResolveURL('RECORD', recType, recId);
		var vendorBillToProcess=record.getFieldValue(FLD_BILL_LINE_TO_PROCESS);
		var vendorCreditToProcess=record.getFieldValue(FLD_CREDIT_LINES_TO_PROCESS);
		var vendorBillProcessed=record.getFieldValue(FLD_BILL_LINES_PROCESSED);
		var vendorCreditProcessed=record.getFieldValue(FLD_CREDIT_LINE_PROCESSED);
		var approvalStatus=record.getFieldValue(FLD_APPROVAL_STATUS);
		var underProcessingcompleted=record.getFieldValue(FLD_TRANSACTIONS_MOVED_UNDER_PROCESSING);
        var vendorBillUnProcessed=record.getFieldValue(FLD_BILLS_LINES_UNPROCESSED)
       	var vendorCreditUnProcessed=record.getFieldValue(FLD_CREDIT_LINES_UNPROCESSED);
          var readyForProcessingCompleted=record.getFieldValue(FLD_TRANSACTION_SET_TO_READY_FOR_PROCESSING);
		  var isAllauthorizationCreated=record.getFieldValue(FLD_AUTHORIZATION_CREATED_SUCCESSFULLY);
		/*if(approvalStatus != VVCCP_MASTER_BATCH_APPROVE_STATUS)
		{
			nlapiLogExecution('debug','approvalStatus:',approvalStatus);
			var url=nlapiResolveURL('SUITELET',SUITELET_VVCCP_APPROVE_HELPER_SCRIPT_ID,SUITELET_VVCCP_APPROVE_HELPER_DEPLOY_ID);
			url+='&recId='+recId;
			var rejecturl =url+ '&stype=reject';
			url += '&stype=approve';
			var approvebtn = form.addButton(BTN_APPROVE,'Approve','window.open(\''+url+'\',\'_self\')');
			var rejectbtn = form.addButton(BTN_REJECT,'Reject','window.open(\''+rejecturl+'\',\'_self\')');	
          if(underProcessingcompleted != 'T')
		  {
			approvebtn.setDisabled(true);
			rejectbtn.setDisabled(true);
		  }
          else
		  {
            approvebtn.setDisabled(false); 
			if(readyForProcessingCompleted!='T')
              rejectbtn.setDisabled(false);
            else
             rejectbtn.setDisabled(true); 
		  }
		  
		}*/
          if (underProcessingcompleted !='T'|| readyForProcessingCompleted !='T' ||isAllauthorizationCreated !='T')
				var refreshbtn = form.addButton(BTN_REFRESH,'Refresh','window.open(\''+refreshURL+'\',\'_self\')');
			//if(isAllauthorizationCreated)
				//approvebtn.setDisabled(true);
	    }
      }
  catch(e)
    {
      nlapiLogExecution( 'DEBUG', 'Error details:', e.toString());
    }
}	 