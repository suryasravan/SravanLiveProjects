/*
*Script Name: Appf-Credit Creation CL
*Script Type: Client Script
*Description: 
*Company 	: Appficiency.
*/
var SL_FLD_TYPE='custpage_type';
var SCRIPT_SUITELET='customscript_appf_credit_creation_sl';
var DEPLOY_SUITELET='customdeploy_appf_credit_creation_sl';

function typeFieldChange(type, name, linenum){
	if(name == SL_FLD_TYPE){
		var createCreditType = nlapiGetFieldValue(SL_FLD_TYPE);
		
		//alert('createCreditType '+createCreditType);
		var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_SUITELET, DEPLOY_SUITELET);
		suiteletURL=suiteletURL+'&type='+createCreditType;
		window.open(suiteletURL,'_self');
	}
}
