/**
 * Script name: Appf-EBP ACH File Generation SC
 * Script type: Scheduled Script
 * Description: This script runs on a SS of EBP records for which payments already created and generates ACH File (USD/CAD) based on specifications and links to EBP batch record
 * Company    : Appficiency Inc.
 */
 
var SPARAM_CUSTOM_RECID ='custscript_ebp_vp_process_control_id';
var SPARAM_EBP_RECORDS_AWAITING_FILE_GENERATION_SS='custscript_ebp_rec_await_file_gen_ss';
var CUSTOM_RECORD_EBP_PAYMENT_PROCESS_CONTROL='customrecord_ebpv2_processingcontrol';
var FLD_PAYMENTS_CREATED='custrecord_appf_ebp_payments_created';
var FLD_BASE_CURRENCY='custrecord_appf_base_currency';
var FLD_EFT_FILE_REFERENCE_NUMBER='custrecord__appf_eft_file_reference';
var FLD_EBP_FILE_GENERATION_ERROR_LOG='custrecord_ebp_file_gen_script_error';
var FLD_EBP_FILE_GENERATION_SCRIPT_PROCESSED='custrecord_ebp_file_gen_script_done';
var FLD_APPF_PP_COMPANY_BANK_PAYMENT_FILE ='custrecord_appf_bank_payment_file';
var FLD_EBP_PAYMENT_TYPE='custrecord_appf_ebp_payment_type';
var EBP_PAYMENT_TYPE_ACH='1';
var CURRENCY_USD = '1';
var CURRENCY_CAD = '3';
var FLD_APPF_PP_COMPANY_BANK_PAYMENT_INFO='custrecord_appf_pp_company_bank_info';


var CUSTOM_RECORD_BANK_DETAILS='customrecord_2663_bank_details'

var FLD_ACCT_NUMBERS='custpage_eft_custrecord_2663_acct_num'

var CURRENCY_CAD_STR = 'CAD';
var CURRENCY_USD_STR = 'USD';


var SPARAM_FOLDER_EBP_ACH_PAYMENT_FILES='custscript_ebp_ach_file_folder_id';
function scheduled()
{
	var context = nlapiGetContext();
    var ssID = context.getSetting('SCRIPT', SPARAM_EBP_RECORDS_AWAITING_FILE_GENERATION_SS);
	//var recID = context.getSetting('SCRIPT', SPARAM_CUSTOM_RECID);
	var loadSS=nlapiLoadSearch(null, ssID);
  	var ssType = loadSS.getSearchType();
	var ssfilts = loadSS.getFilters();
	var sscolumns=loadSS.getColumns();
	var searchResults=getAllSearchResults(ssType, ssfilts, sscolumns);
	if (searchResults != null && searchResults != '') 
	{
		nlapiLogExecution('debug','searchResults.length',searchResults.length)
		for(var s = 0; s < searchResults.length; s++) 
		{
			var searchresult = searchResults[s];
			var internalid = searchresult.getId();
			var recID = internalid;
			try
	{
		
		var customRec = nlapiLoadRecord(CUSTOM_RECORD_EBP_PAYMENT_PROCESS_CONTROL,recID);
		var referenceNumber= customRec.getFieldValue(FLD_EFT_FILE_REFERENCE_NUMBER);
		var paymentsCreated=customRec.getFieldValues(FLD_PAYMENTS_CREATED);
				var ispaymentsCreated=customRec.getFieldValue(FLD_PAYMENTS_CREATED);
				var paymentAcc=customRec.getFieldValue(FLD_APPF_PP_COMPANY_BANK_PAYMENT_INFO);

		var baseCurrency=customRec.getFieldValue(FLD_BASE_CURRENCY);
		
		var baseCurrencyText = '';
		if (baseCurrency == CURRENCY_CAD)
			baseCurrencyText = CURRENCY_CAD_STR;
		if (baseCurrency == CURRENCY_USD)
			baseCurrencyText = CURRENCY_USD_STR;
		
		
		var ebpACHFileUS='';
		var ebpACHFileCAD='';
		var paymentsList=[];
		if(ispaymentsCreated !=null && ispaymentsCreated !='')
		{
			//paymentsCreated=paymentsCreated.split(',');
			paymentsList = paymentsList.concat(paymentsCreated);
			nlapiLogExecution('debug','paymentsCreated:',paymentsList)
			for(var p=0;p<paymentsList.length;p++)
			{
				
				var paymentRecord=nlapiLoadRecord('vendorpayment',paymentsList[p]);
				var paymentDate=paymentRecord.getFieldValue('trandate');
				nlapiLogExecution('debug','paymentDate:',paymentDate)
				var dateIn_yyyy_mm_dd=formatDateInYYYYMMDD(paymentDate);
				var paymentTotal=paymentRecord.getFieldValue('total');
				var paymentAccount=paymentRecord.getFieldValue('account')+'';
				var payeeInPayment=paymentRecord.getFieldValue('entity');
				var payeeRecord=nlapiLoadRecord('vendor',payeeInPayment);
				var achAccountCountInPayee=payeeRecord.getLineItemCount('achacct');
				var payeeAccountNumber='';
				var payeeRoutingNumber='';
				var payeeLegalName=payeeRecord.getFieldValue('legalname');
				if(achAccountCountInPayee > 0)
				{
					var contractFils = [];
					contractFils.push(new nlobjSearchFilter('custrecord_2663_parent_vendor', null, 'anyof', payeeInPayment));
					contractFils.push(new nlobjSearchFilter('custrecord_2663_entity_bank_type', null, 'anyof', '1'));

					var cols = [];
					cols.push(new nlobjSearchColumn('custrecord_2663_entity_acct_no'));
					cols.push(new nlobjSearchColumn('custrecord_2663_entity_bank_no'));
	         var cutserach = nlapiSearchRecord('customrecord_2663_entity_bank_details', null, contractFils, cols);
			       if(cutserach!=null && cutserach!='')
			           {
					     payeeAccountNumber=cutserach[0].getValue('custrecord_2663_entity_acct_no');
					     payeeRoutingNumber=cutserach[0].getValue('custrecord_2663_entity_bank_no');
			           }
					   else
					   {
						   var contractFils = [];
					contractFils.push(new nlobjSearchFilter('custrecord_2663_parent_vendor', null, 'anyof', payeeInPayment));		
					var cols = [];
					cols.push(new nlobjSearchColumn('custrecord_2663_entity_acct_no'));
					cols.push(new nlobjSearchColumn('custrecord_2663_entity_bank_no'));
	            var cutserach = nlapiSearchRecord('customrecord_2663_entity_bank_details', null, contractFils, cols);
                      if(cutserach!=null && cutserach!='')
			           {
					     payeeAccountNumber=cutserach[0].getValue('custrecord_2663_entity_acct_no');
					     payeeRoutingNumber=cutserach[0].getValue('custrecord_2663_entity_bank_no');
			           }
						   
					   }
				}
				
				var paymentAccountNumber='';
				if(paymentAcc!=null && paymentAcc!='')
				{
					var account=nlapiLoadRecord(CUSTOM_RECORD_BANK_DETAILS,paymentAcc);
					paymentAccountNumber=account.getFieldValue(FLD_ACCT_NUMBERS);
				//paymentAccountNumber=nlapiLookupField('account',paymentAccount,'acctnumber');
				}
				if(baseCurrency == CURRENCY_USD)
				{
				paymentTotal=Number(paymentTotal).toFixed(2)
				ebpACHFileUS+='#';  										//Position 1
				ebpACHFileUS+='US#'; 										//Position 2
				ebpACHFileUS+='ACH#'; 										//Position 3
				ebpACHFileUS+=dateIn_yyyy_mm_dd; 
                 ebpACHFileUS+='#';                          //Position 4
				for (var e = 1; e <= 5; e++)
				ebpACHFileUS+='#';										    //Position 5 - 9
				ebpACHFileUS+=paymentTotal; 								//Position 10
				ebpACHFileUS+='##';   										//Position 11
				ebpACHFileUS+=paymentAccountNumber 							//Position 12
				for (var e = 1; e <= 13; e++)
				ebpACHFileUS+='#'; 								            //Position 13 - 24
				ebpACHFileUS+=referenceNumber								//Position 25
				for (var e = 1; e <= 19; e++)
				ebpACHFileUS+='#';						                    //Position 26 - 43
				ebpACHFileUS+=payeeAccountNumber;  							//Position 44
				ebpACHFileUS+='#';
				ebpACHFileUS+=payeeLegalName;  								//Position 45
                  ebpACHFileUS+='#';
				for (var e = 1; e <= 5; e++)
				ebpACHFileUS+='#';  									    //Position 46 - 50
				ebpACHFileUS+=payeeRoutingNumber;  							//Position 51
				for (var e = 1; e <= 34; e++)
				ebpACHFileUS+='#';                                          //Position 52 - 85
			    
				ebpACHFileUS+='\r\n';                     
				}
				if(baseCurrency == CURRENCY_CAD)
				{
				ebpACHFileCAD+='#';  										//Position 1
				ebpACHFileCAD+='CA#'; 										//Position 2
				ebpACHFileCAD+='ACH#'; 										//Position 3
				ebpACHFileCAD+=dateIn_yyyy_mm_dd; 							//Position 4
				for (var e = 1; e <= 4; e++)
				ebpACHFileCAD+='#';										    //Position 5 - 8
				ebpACHFileCAD+='CAD';										//Position 9
				ebpACHFileCAD+=paymentTotal; 								//Position 10
				ebpACHFileCAD+='##';   										//Position 11
				ebpACHFileCAD+=paymentAccountNumber 						//Position 12
				for (var e = 1; e <= 13; e++)
				ebpACHFileCAD+='#'; 							            //Position 13 - 25
				ebpACHFileCAD+=referenceNumber								//Position 26
				ebpACHFileCAD+='###';						    			//Position 27 - 29
				ebpACHFileCAD+='460';  										//Position 30
				for (var e = 1; e <= 6; e++)
				ebpACHFileCAD+='#';  									    //Position 31 - 36
				ebpACHFileCAD+='Novus Media LLC'  							//Position 37
				ebpACHFileCAD+='#';
				ebpACHFileCAD+='Novus Media LLC'  							//Position 38
				for (var e = 1; e <= 5; e++)
				ebpACHFileCAD+='#';  									    //Position 39 - 43
				ebpACHFileCAD+=payeeAccountNumber  							//Position 44
				ebpACHFileCAD+='#';
				ebpACHFileCAD+=payeeLegalName  							    //Position 45
				for (var e = 1; e <= 5; e++)
				ebpACHFileCAD+='#';  									    //Position 46- 50
				ebpACHFileCAD+=payeeRoutingNumber  							//Position 51
				for (var e = 1; e <= 34; e++)
				ebpACHFileCAD+='#';                                         //Position 52 - 85
			
			    ebpACHFileCAD+='\r\n'; 
				
				}

			}
			var filePrefix='ACH_EBP_'+baseCurrencyText+'_'+recID+'_'+referenceNumber+'_'+prefixYYYYMMDDWithHHMM();
			
			var textFile='';
			var fileid='';
			if(ebpACHFileUS !='')
			{
              ebpACHFileUS = ebpACHFileUS.slice(0,-2);
				textFile=nlapiCreateFile(filePrefix+'.txt', 'PLAINTEXT', ebpACHFileUS);
				textFile.setFolder(nlapiGetContext().getSetting('SCRIPT', SPARAM_FOLDER_EBP_ACH_PAYMENT_FILES));
				fileid = nlapiSubmitFile(textFile);
				nlapiLogExecution('DEBUG','fileid:US',fileid);
			}
			if(ebpACHFileCAD !='')
			{
              ebpACHFileCAD = ebpACHFileCAD.slice(0,-2);
				textFile=nlapiCreateFile(filePrefix+'.txt', 'PLAINTEXT', ebpACHFileCAD);
				textFile.setFolder(nlapiGetContext().getSetting('SCRIPT', SPARAM_FOLDER_EBP_ACH_PAYMENT_FILES));
				fileid = nlapiSubmitFile(textFile);
				nlapiLogExecution('DEBUG','fileid:CAD',fileid);
			}
					
					if (fileid)					
					nlapiSubmitField(CUSTOM_RECORD_EBP_PAYMENT_PROCESS_CONTROL,recID,[FLD_EBP_FILE_GENERATION_ERROR_LOG,FLD_EBP_FILE_GENERATION_SCRIPT_PROCESSED,FLD_APPF_PP_COMPANY_BANK_PAYMENT_FILE],['','T',fileid]);

		}
		
		
		
	}
	catch(e)
	{
					if ( e instanceof nlobjError )
					{
					nlapiLogExecution( 'DEBUG', 'Error processing EBP Batch ID:'+recID, e.getCode() + '\n' + e.getDetails() )
							nlapiSubmitField(CUSTOM_RECORD_EBP_PAYMENT_PROCESS_CONTROL,recID,[FLD_EBP_FILE_GENERATION_ERROR_LOG],[e.getDetails()])

					}
					else
					{
					nlapiLogExecution( 'DEBUG', 'Error processing EBP Batch ID:'+recID, e.toString() )
					nlapiSubmitField(CUSTOM_RECORD_EBP_PAYMENT_PROCESS_CONTROL,recID,[FLD_EBP_FILE_GENERATION_ERROR_LOG],[e.toString()])

					}
				
				
	}
	
	
	if((parseInt(s)+1)<(searchResults.length)){
					

					nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), null);
					break;
				}
		}
	}
	
				
}
function formatDateInYYYYMMDD(date) {
    var d = new Date(date);
    month = '' + (d.getMonth() + 1);
    day = '' + d.getDate();
    year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return year.toString()+month.toString()+day.toString();
}

function prefixYYYYMMDDWithHHMM()
{
	var date = new Date();
var utcDate=date.toISOString().split('.')[0];
//2017-01-10 00:00:00.00 +0000
    	utcDate = utcDate.replace(/T/g, ' ');
        var dtTotalPart = utcDate.split(' ')[0];
        var tmTotalPart = utcDate.split(' ')[1];
        
        var hhPart = tmTotalPart.split(':')[0];
        var minPart = tmTotalPart.split(':')[1];
        
        var mnPart = dtTotalPart.split('-')[1];
                var yrPart = dtTotalPart.split('-')[0];

        var ddPart = dtTotalPart.split('-')[2];
        var revDateTime = yrPart+mnPart+ddPart+'_'+hhPart+minPart;
	
	return revDateTime;
}
function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
