/*
* Script Name : Appf-Bill PO Lines Validations CL
* Script Type : Client
* Description : This script handles all client side validations of Bill PO Lines SL
* Company   :	Appficiency Inc.
*/

var FILTERS_GROUP='custpage_filter';
var FLD_SL_ACTION='custpage_action';
var FLD_SL_VENDOR='custpage_vendor';
var FLD_SL_PUBLISHER_MEDIA_SUPLIER='custpage_media_supplier';
var FLD_SL_MEDIA_SEGMENT='custpage_media_segment';
var FLD_PROJECT_PWP_REC='custpage_proj_pwp_rec';
var FLD_SL_START_DATE_FROM='custpage_start_date_from';
var FLD_SL_START_DATE_TO='custpage_start_date_to';
var FLD_SL_END_DATE_FROM='custpage_end_date_from';
var FLD_SL_END_DATE_TO='custpage_end_date_to';
var FLD_SL_PO_TRAN_NUM='custpage_po_tran_number';
var FLD_SL_IO_NUM = 'custpage_io_number';
var FLD_SL_LOB='custpage_line_of_bussiness';
var FLD_SL_SUBSIDIARY='custpage_subsidiary'; 
var FLD_SL_CLIENT='custpage_client';	
var FLD_SL_USE_TO_BILL='custpage_use_to_bill';
var BTN_SL_APPLY_FILTERS = 'custpage_button_apply_filters';
var COL_SL_CURRENCY = 'custpage_currency_script';
var COL_SL_UNBILLED_AMT = 'custpage_unbilled_amt';
var COL_SL_UNBILLED_AMT_DUPLICATE = 'custpage_unbilled_amt_duplicate';
var FLD_SL_VENDOR='custpage_vendor';
var COLUMNS_GROUP = 'custpage_column';
var SL_SUBLIST='custpage_sublist';
var BTN_SL_MARKALL_BUTTON='custpage_marke_all';
var BTN_SL_UN_MARKALL='custpage_un_marke_all';
var COL_SL_SELECT = 'custpage_select';
var FLD_SL_SUBSIDIARY='custpage_subsidiary';
var FLD_SL_REF_NUM = 'custpage_ref_num';
var FLD_SL_AP_ACCOUNTS_NUM = 'custpage_account_num';
var SCRIPT_BILL_PO_LINES_SL = 'customscript_appf_bill_po_lines_sl';
var DEPLOY_BILL_PO_LINES_SL = 'customdeploy_appf_bill_po_lines_sl';


function clientFieldChanged(type, name, linenum){
	
	if(name == FLD_SL_VENDOR)
	{
		var vendor=nlapiGetFieldValue(FLD_SL_VENDOR)
		if(vendor!=null && vendor!='')
		{
			var vendorRec=nlapiLoadRecord('vendor',vendor)
			var vendorNum=vendorRec.getFieldValue('payablesaccount')
			var vendorSubs=vendorRec.getFieldValue('subsidiary')
			nlapiSetFieldValue(FLD_SL_AP_ACCOUNTS_NUM,vendorNum)
			nlapiSetFieldValue(FLD_SL_SUBSIDIARY,vendorSubs)
			
			var filtersApplied = false;
  	var vend=nlapiGetFieldValue(FLD_SL_VENDOR); 
	if (vend != null && vend != '')
		filtersApplied = true;
	var mediaSupplier=nlapiGetFieldValues(FLD_SL_PUBLISHER_MEDIA_SUPLIER);
	if (mediaSupplier != null && mediaSupplier != '')
		filtersApplied = true;
	var mediaSegment=nlapiGetFieldValue(FLD_SL_MEDIA_SEGMENT);
	if (mediaSegment != null && mediaSegment != '')
		filtersApplied = true;
  	var projPWPRec=nlapiGetFieldValue(FLD_PROJECT_PWP_REC);
	if (projPWPRec != null && projPWPRec != '')
		filtersApplied = true;
          	var accountNum=nlapiGetFieldValue(FLD_SL_AP_ACCOUNTS_NUM);
	if (accountNum != null && accountNum != '')
		filtersApplied = true;
  	var stdtFrom=nlapiGetFieldValue(FLD_SL_START_DATE_FROM);
	if (stdtFrom != null && stdtFrom != '')
		filtersApplied = true;
  	var stdtTo=nlapiGetFieldValue(FLD_SL_START_DATE_TO);
	if (stdtTo != null && stdtTo != '')
		filtersApplied = true;
    var poNum=nlapiGetFieldValue(FLD_SL_PO_TRAN_NUM);
	if (poNum != null && poNum != '')
		filtersApplied = true;
	var ioNum=nlapiGetFieldValue(FLD_SL_IO_NUM);
	if (ioNum != null && ioNum != '')
		filtersApplied = true;
	var lob=nlapiGetFieldValue(FLD_SL_LOB);
	if (lob != null && lob != '')
		filtersApplied = true;
	var subsi=nlapiGetFieldValue(FLD_SL_SUBSIDIARY);
	if (subsi != null && subsi != '')
		filtersApplied = true;
	var client=nlapiGetFieldValue(FLD_SL_CLIENT);
	if (client != null && client != '')
		filtersApplied = true;
	var useToBill=nlapiGetFieldValue(FLD_SL_USE_TO_BILL);
  if(filtersApplied){
		var url=nlapiResolveURL('SUITELET',SCRIPT_BILL_PO_LINES_SL, DEPLOY_BILL_PO_LINES_SL);
  		url=url+'&vend='+vend+'&mediaSupplier='+mediaSupplier+'&mediaSegment='+mediaSegment+'&projPWPRec='+projPWPRec+'&stdtFrom='+stdtFrom+'&stdtTo='+stdtTo+'&accountNum='+accountNum;
		url=url+'&poNum='+poNum+'&ioNum='+ioNum+'&lob='+lob+'&subsi='+subsi+'&client='+client+'&useToBill='+useToBill+'&applyFils=T';
		window.open(url,'_self');
  }
		}
		
	}
  /*
	if(type == SL_SUBLIST && name == COL_SL_UNBILLED_AMT){
		var unbilledAmt = nlapiGetCurrentLineItemValue(SL_SUBLIST, COL_SL_UNBILLED_AMT);
		var origUnbilledAmt = nlapiGetCurrentLineItemValue(SL_SUBLIST, COL_SL_UNBILLED_AMT_DUPLICATE);
		if(parseFloat(unbilledAmt) > parseFloat(origUnbilledAmt)){
			alert('Amount should not exceed the Unbilled Amount ('+ parseFloat(origUnbilledAmt) + ')');
			nlapiSetCurrentLineItemValue(SL_SUBLIST, COL_SL_UNBILLED_AMT, origUnbilledAmt);
			return false;
		}
	}
  */
  }
function markAll() {
    var nCount = nlapiGetLineItemCount(SL_SUBLIST);
    var invTotalAmount=0;
    for (var i=1; i<=nCount; i++) {       
            nlapiSetLineItemValue(SL_SUBLIST, COL_SL_SELECT, i, 'T');   
              // var invoiceAmt=nlapiGetLineItemValue(FLD_COL_SUBLIST, COL_SL_NATIVE_INVOICE_LINE_AMT_MINUS_PAYMENT_AMT, i);
               //invTotalAmount=parseFloat(invTotalAmount)+parseFloat(invoiceAmt);
    }
}


function unmarkall(){
	var nCount = nlapiGetLineItemCount(SL_SUBLIST);
    for (var i=1; i<=nCount; i++) {
		nlapiSetLineItemValue(SL_SUBLIST, COL_SL_SELECT, i, 'F');
    }

}
function applyFilters(name) 
{
	var filtersApplied = false;
  	var vend=nlapiGetFieldValue(FLD_SL_VENDOR); 
	if (vend != null && vend != '')
		filtersApplied = true;
	var mediaSupplier=nlapiGetFieldValues(FLD_SL_PUBLISHER_MEDIA_SUPLIER);
	if (mediaSupplier != null && mediaSupplier != '')
		filtersApplied = true;
  	var accountNum=nlapiGetFieldValue(FLD_SL_AP_ACCOUNTS_NUM);
	if (accountNum != null && accountNum != '')
		filtersApplied = true;
	var mediaSegment=nlapiGetFieldValue(FLD_SL_MEDIA_SEGMENT);
	if (mediaSegment != null && mediaSegment != '')
		filtersApplied = true;
  	var projPWPRec=nlapiGetFieldValue(FLD_PROJECT_PWP_REC);
	if (projPWPRec != null && projPWPRec != '')
		filtersApplied = true;
  	var stdtFrom=nlapiGetFieldValue(FLD_SL_START_DATE_FROM);
	if (stdtFrom != null && stdtFrom != '')
		filtersApplied = true;
  	var stdtTo=nlapiGetFieldValue(FLD_SL_START_DATE_TO);
	if (stdtTo != null && stdtTo != '')
		filtersApplied = true;
    var poNum=nlapiGetFieldValue(FLD_SL_PO_TRAN_NUM);
	if (poNum != null && poNum != '')
		filtersApplied = true;
	var ioNum=nlapiGetFieldValue(FLD_SL_IO_NUM);
	if (ioNum != null && ioNum != '')
		filtersApplied = true;
	var lob=nlapiGetFieldValue(FLD_SL_LOB);
	if (lob != null && lob != '')
		filtersApplied = true;
	var subsi=nlapiGetFieldValue(FLD_SL_SUBSIDIARY);
	if (subsi != null && subsi != '')
		filtersApplied = true;
	var client=nlapiGetFieldValue(FLD_SL_CLIENT);
	if (client != null && client != '')
		filtersApplied = true;
	var useToBill=nlapiGetFieldValue(FLD_SL_USE_TO_BILL);
	
		var url=nlapiResolveURL('SUITELET',SCRIPT_BILL_PO_LINES_SL, DEPLOY_BILL_PO_LINES_SL);
  		url=url+'&vend='+vend+'&mediaSupplier='+mediaSupplier+'&mediaSegment='+mediaSegment+'&projPWPRec='+projPWPRec+'&stdtFrom='+stdtFrom+'&stdtTo='+stdtTo+'&accountNum='+accountNum;
		url=url+'&poNum='+poNum+'&ioNum='+ioNum+'&lob='+lob+'&subsi='+subsi+'&client='+client+'&useToBill='+useToBill+'&applyFils=T';
		window.open(url,'_self');
  
}
function onsave(){
  	var vend=nlapiGetFieldValue(FLD_SL_VENDOR); 
  if(vend==null || vend=='')
    {
      
      alert('Please select Vendor');
     return false;
    }
	 var sAction = nlapiGetFieldValue(FLD_SL_ACTION);
	    if (sAction == null || sAction == '') {
	    	nlapiSetFieldValue(FLD_SL_ACTION,'submit');
	    }
	    var lineCount=nlapiGetLineItemCount(SL_SUBLIST);
	    var count=0;
   var poCurrencyss=[]
		if(lineCount>0)
		{
	    for(var i=1;i<=lineCount;i++){
	    	var selected=nlapiGetLineItemValue(SL_SUBLIST, COL_SL_SELECT, i);
	    	if(selected == 'T'){
	    		count++;
             var poCurrencys= nlapiGetLineItemValue(SL_SUBLIST, COL_SL_CURRENCY, i);
              poCurrencyss.push(poCurrencys)
	    	}
         
	    }
		}
  if(poCurrencyss!=null && poCurrencyss!='')
  poCurrencyss=eliminateDuplicates(poCurrencyss)
		  if(count == 0) 
		  {
	       alert('Please select atleast one PO line to bill');
	    	return false;
	      }
	    else{
	    	var isOKToProceed = confirm('Selected transactions will be submitted for Bill PO Lines processing, Click OK to proceed');
	if (!isOKToProceed)
		return false;
	else
      {
     if(poCurrencyss.length>1)
       {
         alert('Please select PO Lines with only one currency');
         return false;
       }
        else
          {
		return true;
          }
        }
	    }
		/*
  var availableAmount=nlapiGetFieldValue(FLD_SL_AVAILABLE_AMOUNT);
  var paymentAmount=nlapiGetFieldValue(FLD_SL_PAYMENT_AMOUNT);
  if((parseFloat(availableAmount)-parseFloat(paymentAmount)) < 0 )
    {
      alert('Payment Amount should be less then or equal to Available Amount ('+availableAmount+')');
      return false;
    }*/
	

}
function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}