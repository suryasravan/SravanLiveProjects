/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Creates VB/VC records from missed VB Child records
 *
 * Author: Marlon Villarama
 * Date: March 11, 2021
 */
define(
    [
        'N/log',
        'N/search',
        'N/task'
    ],

    function(
        LOG,
        SEARCH,
        TASK
    ) {
        var REC_VB_MASTER_INV = 'customrecord_appf_interim_vb';
        var REC_VB_CHILD_INV = 'customrecord_appf_interim_vb_line';
        
        var SRCH_PENDING_VBVC = 'customsearch_appf_interim_pending_vbvc';
        
        var FLD_CHILD_EXEC_LOG_LINK = 'custrecord_appf_bill_po_exec_link_child';
        var FLD_CHILD_INTERIM_HEADER = 'custrecord_appf_interimheader';
        
        var SCRIPT_CREATE_VBVC = 'customscript_appf_sync_vb_vc_sch';
        var DEPLOY_CREATE_VBVC = 'customdeploy_app_sync_vbvc_sc_mr_';
        var SPARAM_IMMEDIATE_EXECUTION = 'custscript_created_from_ext_scripts';
        
        var RANGE = 20;
        var LIMIT = 20;
        
        function _getInputData () {
            var LOG_TITLE = '_getInputData ';
            LOG.debug({ title: LOG_TITLE, details: '** START **' });
            
            LOG.debug({ title: LOG_TITLE, details: '** END **' });
            var srch = SEARCH.load({ id: SRCH_PENDING_VBVC });
            var srchType = srch.searchType;
            LOG.debug({ title: LOG_TITLE, details: 'type = ' + srchType });
            
            var fils = srch.filters;
            var cols = srch.columns;
            
            LOG.debug({ title: LOG_TITLE + ' filters', details: JSON.stringify(fils) });
            LOG.debug({ title: LOG_TITLE + ' columns', details: JSON.stringify(cols) });
            
            srch = SEARCH.create({
                type: srchType,
                filters: fils,
                columns: [
                    SEARCH.createColumn({
                        name: FLD_CHILD_EXEC_LOG_LINK,
                        sort: SEARCH.Sort.DESC
                    }),
                    SEARCH.createColumn({
                        name: FLD_CHILD_INTERIM_HEADER
                    })
                ]
            });
            LOG.debug({ title: LOG_TITLE + ' new filters', details: JSON.stringify(srch.filters) });
            LOG.debug({ title: LOG_TITLE + ' new columns', details: JSON.stringify(srch.columns) });
            
            var results = srch.run().getRange({ start: 0, end: RANGE });
            LOG.debug({ title: LOG_TITLE + ' results', details: 'results = ' + results.length });
            
            var arr = [];
            var k = 1;
            if (results.length > 0) {
                for (var i = 0, n = results.length; i < RANGE && i < n; i++) {
                    // Do not process more than the LIMIT value
                    // LOG.debug({ title: LOG_TITLE, details: 'i = ' + i + ', k = ' + k });
                    if (k > LIMIT) {
                        continue;
                    }
                    
                    LOG.debug({ title: LOG_TITLE, details: 'i = ' + i + ', k = ' + k });
                    LOG.debug({ title: LOG_TITLE, details: JSON.stringify(results[i]) });
                    
                    var log = results[i].getValue({
                        name: FLD_CHILD_EXEC_LOG_LINK
                    });
                    var id = results[i].id;
                    // LOG.debug({ title: LOG_TITLE, details: 'id = ' + id + ', log = ' + log });
                    
                    if (log) {
                        arr.push({
                            id: results[i].id,
                            index: k++,
                            log: results[i].getValue({
                                name: FLD_CHILD_EXEC_LOG_LINK
                            }),
                            header: results[i].getValue({
                                name: FLD_CHILD_INTERIM_HEADER
                            })
                        });
                    }
                }
            }
            
            LOG.debug({ title: LOG_TITLE, details: JSON.stringify(arr) });
            
            return arr;
        }
        
        function _reduce (context) {
            var LOG_TITLE = '_reduce ';
            LOG.debug({ title: LOG_TITLE, details: '** START **' });
            
            try {
                var obj = JSON.parse(context.values[0]);
                LOG.debug({ title: LOG_TITLE, details: JSON.stringify(obj) });
                
                LOG.debug({
                    title: LOG_TITLE,
                    details: 'id = ' + obj.id + ', index = ' + obj.index + ', log = ' + obj.log + ', header = ' + obj.header
                });
                
                var scTask = TASK.create({
                    taskType: TASK.TaskType.SCHEDULED_SCRIPT,
                    scriptId: SCRIPT_CREATE_VBVC,
                    deploymentId: DEPLOY_CREATE_VBVC + obj.index,
                    params: {}
                });
                
                scTask.params[SPARAM_IMMEDIATE_EXECUTION] = obj.log + '_billposl_' + obj.header;
                LOG.debug({ title: LOG_TITLE, details: 'params = ' + JSON.stringify(scTask.params) });
                
                var scTaskId = scTask.submit();
                LOG.debug({ title: LOG_TITLE, details: 'Submitted Task ID = ' + scTaskId });
            }
            catch (ex) {
                LOG.error({ title: LOG_TITLE, details: 'Error: ' + ex.toString() });
            }
            
            LOG.debug({ title: LOG_TITLE, details: '** END **' });
        }
        
        function _summarize (summary) {
            var LOG_TITLE = '_summarize';
            LOG.debug({ title: LOG_TITLE, details: '** START **' });
            LOG.debug({ title: LOG_TITLE, details: '** END **' });
        }
        
        return {
            getInputData: _getInputData,
            reduce: _reduce,
            summarize: _summarize
        }
    }
);

// appf-Create VB/VC from Master SC MR 
// _app_sync_vbvc_sc_mr_
