/*
*Script Name: Appf-Update PWP Record from VB UE
*Script Type: User Event
*Description: 
*Company 	: Appficiency Inc.
* Version      Date            Author           Remarks
 * 1.00       9 March 2020                     set the Field VENDOR RECONCILIATION STATUS
*/

var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_VEND_BILL_LINE_ID = 'custcol_appf_vendorbill_line_id';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';
var FLD_COL_VEND_BILL_LINE_PAYMENT_AMOUNT = 'custcol_appf_pwp_bill_line_amt_paid';
var FLD_COL_DISCREPANTS= 'custcol_appf_discrepant';
var FLD_COL_DISCREPANCY= 'custcol_appf_discrepancy_action';
var FLD_PAYMENT_TYPE= 'custbody_appf_vendor_payment_type';

var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_VEND_BILL_LINK = 'custrecord_appf_pwp_vb_link';
var FLD_PWP_VEND_BILL_AMT = 'custrecord_appf_pwp_vb_amount';
var FLD_PWP_VEND_BILL_LINE_ID = 'custrecord_appf_pwp_vb_line_id';
var FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_bill_line_amt_paid';
var FLD_PWP_VVCCP_LINKS = 'custrecord_appf_pwp_vvccp_link';
var FLD_PWP_VEND_STATUS = 'custrecord_appf_pwp_vendor_recon_status';
var FLD_PWP_READY_FOR_PAYMENT = 'custrecord_appf_pwp_ready_for_payment';
var FLD_CM_AMT = 'custrecord_appf_pwp_ven_credit_amt';

var FLD_PWP_IO_CHECKBOX='custrecord_appf_trigger_ob_integration';

var SCRIPT_UPDATE_PWP_FROM_VB_SC = 'customscript_appf_update_pwp_rec_vb_sc';

var SPARAM_VEND_BILL_ID = 'custscript_appf_vend_bill_id'; 
var SPARAM_UPDATE_PWP_VEND_BILL_SS = 'custscript_appf_update_pwp_vend_bill_ss';

var STATUS_UN_RECONCILED='1'
var STATUS_DISCREPANTS='2'
var STATUS_RECONCILED_PENDING_UPDATES='3'
var STATUS_PENDING_AUTHORIZATION='4'
var STATUS_PAYMENT_PENDING='5'
var STATUS_PAID='6'

var SCRIPT_SYNC_PT_PTA_GENERIC_SL = 'customscript_appf_generic_sl_2';
var DEPLOY_SYNC_PT_PTA_GENERIC_SL = 'customdeploy_appf_generic_sl_2';

var SEND_TO_PAY='1'
var PAYMENT_AMEX='1'
var PAYMENT_MASTERCARDS='3'
var PAYMENT_VISA='9'
var PAYMENT_CHECK='2'
var PAYMENT_WIRE='4'
//var STATUS_PAID='7'

function updatePWPVBAfterSubmit(type) {
	var context = nlapiGetContext();
	//if(context.getExecutionContext() != 'scheduled'){
		var vbSS = context.getSetting('SCRIPT', SPARAM_UPDATE_PWP_VEND_BILL_SS);
	if(type != 'delete'){
		var recType = nlapiGetRecordType();
		var recId = nlapiGetRecordId();
		var vendBill = nlapiLoadRecord(recType, recId);
		var paymentType=vendBill.getFieldValue(FLD_PAYMENT_TYPE)
		var count = vendBill.getLineItemCount('item');
		
		if(count <= 60){
			var pwpIds = [];
			for(var i=1; i<=count; i++){
				try{
				var pwpRecId = vendBill.getLineItemValue('item', FLD_COL_PWP_RECORD, i);
				var soLineId = vendBill.getLineItemValue('item', FLD_COL_SO_LINE_ID, i);
				var discrepant = vendBill.getLineItemValue('item', FLD_COL_DISCREPANTS, i);
				var discrepancy = vendBill.getLineItemValue('item', FLD_COL_DISCREPANCY, i);
				
				if(pwpRecId != null && pwpRecId != '' && soLineId != null && soLineId != ''){				
					
					var vbIdsArr = [];
						var vbLineIdsArr = [];
						var vbAmtSum = 0;
						var vbLinePaymentAmtSum = 0;
						var vbLineIds = '';
						var isinSS = false;
					if (vbSS != null && vbSS != '')
					{
					var filters = [];
					filters.push(new nlobjSearchFilter(FLD_COL_SO_LINE_ID, null, 'is', soLineId));
										
					var vbSearchResults = nlapiSearchRecord(null, vbSS, filters, null);
					if(vbSearchResults != null && vbSearchResults != ''){
						isinSS=true;
						
						for(var j=0; j<vbSearchResults.length; j++){
							var result = vbSearchResults[j];
							var vbId = result.getId();
							var ssCols = result.getAllColumns();
							var vbLineId = result.getValue(ssCols[0]);
							var vbLinePaymentAmt = result.getValue(ssCols[2]);
							if(vbLinePaymentAmt == null || vbLinePaymentAmt == '')
								vbLinePaymentAmt = 0;
							var vbAmt = result.getValue(ssCols[1]);
							if(vbAmt == null  || vbAmt == '')
								vbAmt = 0;
							
							vbIdsArr.push(vbId);
							vbLineIdsArr.push(vbLineId);
							vbAmtSum = parseFloat(vbAmtSum) + parseFloat(vbAmt);
							vbLinePaymentAmtSum = parseFloat(vbLinePaymentAmtSum) + parseFloat(vbLinePaymentAmt);
						}	
						vbIdsArr = eliminateDuplicates(vbIdsArr);
						vbLineIdsArr = eliminateDuplicates(vbLineIdsArr);
						
						for(var l=0; l<vbLineIdsArr.length; l++){
							if(l == (vbLineIdsArr.length-1))
								vbLineIds += vbLineIdsArr[l];
							else
								vbLineIds += vbLineIdsArr[l] + ',';
						}
						
					}
					}
						var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
						if (vbIdsArr.length>0)
						pwpRecord.setFieldValues(FLD_PWP_VEND_BILL_LINK, vbIdsArr);
						pwpRecord.setFieldValue(FLD_PWP_VEND_BILL_LINE_ID, vbLineIds);
						if(vbAmtSum != null || vbAmtSum != '')
							vbAmtSum = Number(vbAmtSum).toFixed(2);
						pwpRecord.setFieldValue(FLD_PWP_VEND_BILL_AMT, vbAmtSum);
						if(vbLinePaymentAmtSum != null || vbLinePaymentAmtSum != '')
							vbLinePaymentAmtSum = Number(vbLinePaymentAmtSum).toFixed(2);
						pwpRecord.setFieldValue(FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT, vbLinePaymentAmtSum);
						var pwpvvccp=pwpRecord.getFieldValue(FLD_PWP_VVCCP_LINKS);
						var pwpStatus=pwpRecord.getFieldValue(FLD_PWP_VEND_STATUS);
						var pwpCrediAMt=pwpRecord.getFieldValue(FLD_CM_AMT);
						if (pwpCrediAMt == null || pwpCrediAMt == '')
							pwpCrediAMt = 0;
						var isCheck=false
						var readyForPayment = pwpRecord.getFieldValue(FLD_PWP_READY_FOR_PAYMENT);
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED)
						{
							    if(discrepant=='T')
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_DISCREPANTS);
							isCheck=true
						}
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED || pwpStatus==STATUS_DISCREPANTS)
						{
							    if(discrepancy==SEND_TO_PAY && readyForPayment!='T')
								{
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_RECONCILED_PENDING_UPDATES);
							   isCheck=true
								}
						}
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED || pwpStatus==STATUS_DISCREPANTS || pwpStatus==STATUS_RECONCILED_PENDING_UPDATES)
						{
							    if((paymentType==PAYMENT_AMEX || paymentType==PAYMENT_MASTERCARDS || paymentType==PAYMENT_VISA) && readyForPayment=='T')
								{
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_PENDING_AUTHORIZATION);
							    isCheck=true
								}
						}
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED || pwpStatus==STATUS_DISCREPANTS || pwpStatus==STATUS_RECONCILED_PENDING_UPDATES || pwpStatus==STATUS_PENDING_AUTHORIZATION)
						{
							    if((paymentType==PAYMENT_CHECK || paymentType==PAYMENT_WIRE ) && readyForPayment=='T')
								{
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_PAYMENT_PENDING);
								isCheck=true
								}
						}
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED || pwpStatus==STATUS_DISCREPANTS || pwpStatus==STATUS_RECONCILED_PENDING_UPDATES || pwpStatus==STATUS_PENDING_AUTHORIZATION || pwpStatus==STATUS_PAYMENT_PENDING)
						{
							if (!isinSS)
							{
								vbLinePaymentAmtSum = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT);
								if (vbLinePaymentAmtSum == null || vbLinePaymentAmtSum == '')
									vbLinePaymentAmtSum = 0;
								vbAmtSum = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_AMT);
								if (vbAmtSum == null || vbAmtSum == '')
									vbAmtSum = 0;
							}
							    if(parseFloat(vbAmtSum)==(parseFloat(vbLinePaymentAmtSum)+parseFloat(pwpCrediAMt)))
								{
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_PAID);
								isCheck=true
								}
						}
						   if(isCheck)
						   {
							pwpRecord.setFieldValue(FLD_PWP_IO_CHECKBOX, 'T');
							pwpIds.push(pwpRecId);
						   }
						var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
						nlapiLogExecution('DEBUG', 'pwpId', pwpId);
				
					
				}
			}catch(e){
				if ( e instanceof nlobjError )
					  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
					  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
			}
			
			
			var slURL =  nlapiResolveURL('SUITELET',SCRIPT_SYNC_PT_PTA_GENERIC_SL,DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external');
	slURL += '&genetricrecid='+pwpIds+'&genetricrectype='+CUSTOM_RECORD_PWP+'&isbackend=T';
    nlapiLogExecution('debug','slURL',slURL)
	try{
					nlapiRequestURL(slURL);
				  }catch (e) {
					  try{
						nlapiRequestURL(slURL);
					  }catch (ex) {
						  try{
						  nlapiRequestURL(slURL);
						  }
						  catch (ep)
						  {
							                    nlapiLogExecution('debug','error triggering Generic SL',ep);

						  }
					  }
				  }
				  
		}
		else{
			var params = {};
			params[SPARAM_VEND_BILL_ID] = recId;
			nlapiScheduleScript(SCRIPT_UPDATE_PWP_FROM_VB_SC, null, params);
		}
	}
	
}

function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}