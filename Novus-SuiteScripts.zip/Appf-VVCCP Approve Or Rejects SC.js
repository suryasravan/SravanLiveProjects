/**
	 * Script Name : Appf-VVCCP Approve Or Rejects SC
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script handles the approve and reject actions on VVCCP batch records

	 *
	 * Company 	 : Appficiency. 
	 */
	 var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
	 var FLD_DATA_FILE='custrecord_appf_vvccp_log_data_file';
	 var SPARAM_VVCCP_PROCESS_APPROVED_RECORDS='custscript_vvccp_process_approved_record';
	 var SPARAM_VVCCP_PROCESS_REJECT_RECORDS='custscript_vvccp_process_reject_records';
	 var SPARAM_DATA_FILE_OF_BILL_AND_CREDITS='custscript_bill_and_billcredit_data_file';
	 var SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
	 var SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH='customscript_vvccp_approve_custmization';
	 var SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH='customscript_appf_vvccp_scheduled_reject';
var SPARAM_VVCCP_EXECUTION_BATCH_LINK_ID='custscript_vvccp_exec_batch_id';
function schedule(type)
{
	try
	{
	var context = nlapiGetContext();
	var vvccpProcessApprovedRecordsSearchId=context.getSetting('SCRIPT',SPARAM_VVCCP_PROCESS_APPROVED_RECORDS);
	var vvccpProcessApprovedRecordsSearch=nlapiLoadSearch(null, vvccpProcessApprovedRecordsSearchId);
	var vvccpProcessApprovedRecordsSearchFilts = vvccpProcessApprovedRecordsSearch.getFilters();
	var vvccpProcessApprovedRecordsSearchColumns=vvccpProcessApprovedRecordsSearch.getColumns();
	var vvccpProcessApprovedRecordsSearchSSType = vvccpProcessApprovedRecordsSearch.getSearchType();
	var vvccpProcessApprovedRecordsSearchResults=getAllSearchResults(vvccpProcessApprovedRecordsSearchSSType, vvccpProcessApprovedRecordsSearchFilts, vvccpProcessApprovedRecordsSearchColumns);
	if(vvccpProcessApprovedRecordsSearchResults !=null && vvccpProcessApprovedRecordsSearchResults !='')
	{
		for(var s=0;s<vvccpProcessApprovedRecordsSearchResults.length;s++)
		{
			var searchresult = vvccpProcessApprovedRecordsSearchResults[s];
			var vvccpExecutionBatchREcordId = searchresult.getId();
			var dataFile=searchresult.getValue(FLD_DATA_FILE);

			nlapiLogExecution('debug','vvccpExecutionBatchREcordId:',vvccpExecutionBatchREcordId);
			nlapiLogExecution('debug','dataFile:',dataFile);
			if(vvccpExecutionBatchREcordId !=null && vvccpExecutionBatchREcordId !='' && dataFile !=null && dataFile !='')
			{
				var params = {};
				params[SPARAM_DATA_FILE_OF_BILL_AND_CREDITS] = dataFile;
				params[SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD] =vvccpExecutionBatchREcordId;
				nlapiScheduleScript(SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH, null, params);
			}
		}
	}



	var vvccpProcessRejectRecordsSearchId=context.getSetting('SCRIPT',SPARAM_VVCCP_PROCESS_REJECT_RECORDS);
	var vvccpProcessRejectRecordsSearch=nlapiLoadSearch(null, vvccpProcessRejectRecordsSearchId);
	var vvccpProcessRejectRecordsSearchFilts = vvccpProcessRejectRecordsSearch.getFilters();
	var vvccpProcessRejectRecordsSearchColumns=vvccpProcessRejectRecordsSearch.getColumns();
	var vvccpProcessRejectRecordsSearchSSType = vvccpProcessRejectRecordsSearch.getSearchType();
	var vvccpProcessRejectRecordsSearchResults=getAllSearchResults(vvccpProcessRejectRecordsSearchSSType, vvccpProcessRejectRecordsSearchFilts, vvccpProcessRejectRecordsSearchColumns);
	if(vvccpProcessRejectRecordsSearchResults !=null && vvccpProcessRejectRecordsSearchResults !='')
	{
			for(r=0;r<vvccpProcessRejectRecordsSearchResults.length;r++)
			{
				var searchresult = vvccpProcessRejectRecordsSearchResults[r];
				var vvccpBatchRecID = searchresult.getId();
				nlapiLogExecution('debug','vvccpBatchRecID',vvccpBatchRecID);
				
					var params = {};
					params[SPARAM_VVCCP_EXECUTION_BATCH_LINK_ID] =vvccpBatchRecID;
					nlapiScheduleScript(SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH, null, params);
			}
	}
	}
	catch(e)
	{
		nlapiLogExecution('debug','Error Details:',e.toString());
	}

}	