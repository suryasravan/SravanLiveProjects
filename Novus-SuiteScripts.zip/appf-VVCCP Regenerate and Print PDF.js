/*
*Script Name: Appf-VVCCP Regenerate and Print PDF UE
*Script Type: User Event
*Description: This script will display the buttons "Print PDF" and "Regenerate PDF" buttons on VVCCP record to preview the PDF and regenerate the PDF respectively
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       26 May 2022     Shravan		      v1.0
*/

function beforeLoad ( type, form ) {
     if ( type == 'view' ) {
          var recId = nlapiGetRecordId();
          var url_servlet = nlapiResolveURL( 'SUITELET', 'customscript_appf_regen_print_vvccp_pdf', 'customdeploy_appf_regen_print_vvccp_pdf' );
          url_servlet = url_servlet + '&id=' + recId;
          var refreshbtn = form.addButton( 'custpage_print', 'Print PDF', 'window.open(\'' + url_servlet + '\',\'_blank\')' );
          url_servlet = url_servlet + '&pdf=' + true;
          var refreshbtn = form.addButton( 'custpage_pdf', 'Regenerate PDF', 'window.open(\'' + url_servlet + '\',\'_self\')' );
     }
}