/*
* Script Name : Appf-Refresh Bill PO Lines Exec Log UE
* Script Type : UserEvent
* Event Type  : BeforeLoad
* Description : This script adds "Refresh" button on Bill PO LInes Execution Log Custom record, on click it updates the processing sttaus
* Company     :	Appficiency Inc.
*/

var BTN_REFRESH = 'custpage_refresh';
var FLD_BILL_PO_LINES_EXEC_LOG = 'custbody_appf_bill_po_lines_log';

var CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG = 'customrecord_appf_bill_po_lines_log';
var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';
var FLD_CR_TOTAL_POS_TO_PROCESS = 'custrecord_appf_bill_po_lines_to_process';
var FLD_CR_PROCESSED_PERCENT = 'custrecord_appf_bill_po_lines_percent';
var FLD_CR_CREATED = 'custrecord_appf_bill_po_lines_created_by';
var FLD_CR_BILL_POS_BATCH_STATUS = 'custrecord_appf_bill_po_lines_status';
var FLD_CR_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
var FLD_CR_STATUS_FILE = 'custrecord_appf_bill_po_lines_status_fil';
var FLD_CR_ERROR_LOG = 'custrecord_appf_bill_po_lines_error_log';
var FLD_CR_PO_LINK = 'custrecord_appf_bill_po_lines_po_link';
var FLD_CR_BILL_LINK = 'custrecord_appf_bill_po_lines_bill_link';

var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED_SUCCESSFULLY = '4';
var STATUS_COMPLETED_WITH_ERRORS = '5';

function userEventBeforeLoadRefresh(type, form, request)
{
	if(type == 'view')
	{
		var recId=nlapiGetRecordId();
		var recType=nlapiGetRecordType();
		var errorLog = nlapiGetFieldValue(FLD_CR_ERROR_LOG);
		var totalBillsToProcess=nlapiGetFieldValue(FLD_CR_TOTAL_BILLS_TO_PROCESS);
        var totalBillsCreated = nlapiGetFieldValue(FLD_CR_TOTAL_BILLS_CREATED);
        if(totalBillsToProcess != totalBillsCreated)
        {
			
			  
			
					form.addButton(BTN_REFRESH, 'Refresh', 'location.reload();'); 
			//var url=nlapiResolveURL('RECORD', CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG, recId);
			//form.addButton(BTN_REFRESH, 'Refresh', 'window.open(\''+url+'\',\'_self\',\'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1000,height=500\')');
		} 
	}
}

