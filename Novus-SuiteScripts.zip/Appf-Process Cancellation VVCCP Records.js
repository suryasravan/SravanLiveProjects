/**
	 * Script Name : Appf-Process Cancellation VVCCP Records
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			  Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var SPARAM_CANCEL_ACCEPTED_VVCCP_RECORDS_SEARCH='custscript_process_cancellation_vvccps';
var CUSTOM_RECORD_VIRTUAL_CREDIT_CARD='customrecord_appf_vvccp_authorized_card';
var FLD_CARD_NUMBER='custrecord_appf_vvccp_card_number';
var FLD_SECURITY_CODE='custrecord_appf_vvccp_card_code';
var FLD_EXPIRATION_DATE='custrecord_appf_vvccp_card_exp_date';
var FLD_PROVIDER='custrecord_appf_vvccp_card_provider';
var FLD_VENDOR_PAYMENT_LINK='custrecord_appf_vvccp_ven_pmt_link';
var FLD_VVCCP_LINK_REDIT_CARD='custrecord_appf_vvccp_card_vvccp_link';
var FLD_CARD_CANCELLED='custrecord_appf_vvccp_card_cancelled';
var FLD_VOID_JOURNAL='custrecord_appf_vvccp_payment_void';
var FLD_AUTHORIZATION_DATE='custrecord_appf_vvccp_authorization_date';

var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';
var CUSTOM_RECORD_PWP='customrecord_appf_pwp_wrapper_record';
var FLD_BILL_LINEAMOUNT_PAID='custrecord_appf_pwp_bill_line_amt_paid'
function schedule(type)
{
	try
	{
		var context=nlapiGetContext();
		var cancelAcceptedVVCCPSearchId=context.getSetting('SCRIPT', SPARAM_CANCEL_ACCEPTED_VVCCP_RECORDS_SEARCH);
		nlapiLogExecution('debug','cancelAcceptedVVCCPSearchId:',cancelAcceptedVVCCPSearchId);
		if(cancelAcceptedVVCCPSearchId!=null && cancelAcceptedVVCCPSearchId !='')
		{	
			var cancelAcceptedVVCCPSearch=nlapiLoadSearch(null, cancelAcceptedVVCCPSearchId);
			var cancelAcceptedVVCCPSearchFilts = cancelAcceptedVVCCPSearch.getFilters();
			var cancelAcceptedVVCCPSearchColumns=cancelAcceptedVVCCPSearch.getColumns();
			var cancelAcceptedVVCCPSearchSSType = cancelAcceptedVVCCPSearch.getSearchType();
			var cancelAcceptedStatusVVCCPSearch=getAllSearchResults(cancelAcceptedVVCCPSearchSSType, cancelAcceptedVVCCPSearchFilts, cancelAcceptedVVCCPSearchColumns);		
			//Search Result for VVCCP which status are Cancel Accepted
			if(cancelAcceptedStatusVVCCPSearch !=null && cancelAcceptedStatusVVCCPSearch !='')
			{
				var vvccpObj={}
				for(var c=0;c<cancelAcceptedStatusVVCCPSearch.length;c++)
				{
					var cancellAcceptedVVCCPSearchResults=cancelAcceptedStatusVVCCPSearch[c];
					var vvccpInternalId=cancellAcceptedVVCCPSearchResults.getId();
					var paymentLinkedToVirtualCreditCard=cancellAcceptedVVCCPSearchResults.getValue(cancelAcceptedVVCCPSearchColumns[0]);
					var cancelCheckboxOnVirtualCreditCard=cancellAcceptedVVCCPSearchResults.getValue(cancelAcceptedVVCCPSearchColumns[1]);
					var internalidOfVirtualCreditCard=cancellAcceptedVVCCPSearchResults.getValue(cancelAcceptedVVCCPSearchColumns[2]);
					//nlapiLogExecution('debug','paymentLinkedToVirtualCreditCard:',paymentLinkedToVirtualCreditCard);
					//nlapiLogExecution('debug','cancelCheckboxOnVirtualCreditCard:',cancelCheckboxOnVirtualCreditCard);
					if(!vvccpObj.hasOwnProperty(vvccpInternalId))
					{
						vvccpObj[vvccpInternalId]=vvccpInternalId;
						nlapiLogExecution('debug','vvccpInternalId:',vvccpInternalId);
						//i.Void Vendor Payment Record Linked to the Virtual Credit Card 
						if(paymentLinkedToVirtualCreditCard !=null && paymentLinkedToVirtualCreditCard!='')
						var voidingId = nlapiVoidTransaction('vendorpayment', paymentLinkedToVirtualCreditCard);
                      if(voidingId)
						nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_VOID_JOURNAL],[voidingId]);
						nlapiLogExecution('debug','voidingId:',voidingId);
					
						//ii.Unapplying the vendor credit from the vendor bills
						var filters=[];
						var columns=[];
						filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
						columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
						var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
						if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
						{
							for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
							{
								var billsearchResult=searchOnVVCCPLinkedTransactions[b];
								var vvccpLinkedTransactionInternalId=billsearchResult.getId();
								var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
								var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
								var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
								var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
								var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
								nlapiLogExecution('debug',':transactionTypes',transactionTypes);
								if(transactionTypes == 20)
								{
									//nlapiLogExecution('debug',':transactionId',transactionId);
									var vvccpLinkedTransaction=nlapiLoadRecord('vendorcredit',transactionId);
									var applylinecount=vvccpLinkedTransaction.getLineItemCount('apply');
									for(var c=1;c<=applylinecount;c++)
									{
										var type=vvccpLinkedTransaction.getLineItemValue('apply','type',c);
										var id=vvccpLinkedTransaction.getLineItemValue('apply','doc',c);
										//nlapiLogExecution('debug','id:',id);
										//nlapiLogExecution('debug','type:',type);
										if(type == 'Vendor Bill')
										{
											vvccpLinkedTransaction.selectLineItem('apply',c);
											vvccpLinkedTransaction.setCurrentLineItemValue('apply','apply','F');
											vvccpLinkedTransaction.commitLineItem('apply');
										}
									}
									var vvccpLinkedTransactionId=nlapiSubmitRecord(vvccpLinkedTransaction,true,true);
								}
								else if(transactionTypes == 17)
								{
									//iii.Update the PWP Records for Bills Linked to VVCCP Linked Transactions
									if(trnasactionLinePWP !=null && trnasactionLinePWP !='')
									{
											nlapiLogExecution('debug','trnasactionLinePWPmatching:',trnasactionLinePWP);
											var billLineAmountPaidFromPWPRecord=nlapiLookupField(CUSTOM_RECORD_PWP,trnasactionLinePWP,FLD_BILL_LINEAMOUNT_PAID);
											var amountAfterReduceTheVVCCPLineAmount=parseFloat(billLineAmountPaidFromPWPRecord)-parseFloat(trnasactionLineAmount);
											nlapiSubmitField(CUSTOM_RECORD_PWP,trnasactionLinePWP,[FLD_BILL_LINEAMOUNT_PAID],[amountAfterReduceTheVVCCPLineAmount]);
									}
								}
							}
						}	
					//iv.Update Record Type = Virtual Credit Card 
					if(internalidOfVirtualCreditCard !=null && internalidOfVirtualCreditCard !='')
					{
						nlapiLogExecution('debug','internalidOfVirtualCreditCard:',internalidOfVirtualCreditCard);
						nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_CARD_CANCELLED],['T']);
					}
				}
				}
			}
		}
	}	
	catch(e)
	{
		nlapiLogExecution('debug','Error Deatils:',e.toString());
	}
}	


function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
function searchUnion(target, array)
{
		return target.concat(array); // TODO: use _.union
}
	