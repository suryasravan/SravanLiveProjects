	/**
	 * @NApiVersion 2.0
	 * @NScriptType MapReduceScript
	 */



/**
* Script Name : Appf-Revenue Arrangements OOH(CREATE) MR
* Script Type : Scheduled
* Description : This script runs on SS of OOH Revenue elements and executes the AEM process by updating revenue arrangements and triggers Appf-Revenue Arrangnts OOH(CREATE) MR #2 to update all POs at once
* Company     :	Appficiency Inc.
*/

var SPARAM_SS_CREATE_EXP_ELEMENTS = 'custscript_ss_update_ooh_revenue_element';

var SCRIPT_ID_HELPER_SUITELET='customscript_helper_scrpt_cal_map_reduce';
var DEPLOYMENT_ID_HELPER_SUITELET='customdeploy_helper_scrpt_cal_map_reduce';

var FOLDER_AEM_SL_FILES= '895';

var SCRIPT_SCHEDULED='customscript_appf_update_rev_arrange_sc';
var DEPLOY_SCHEDULED='customdeploy_appf_update_rev_arrange_sc';
var SPARAM_CUSTOM_REC_ID='custscript_appf_custom_rec_id';

var CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG='customrecord_appf_aem_rev_ele_ex_log';
var FLD_TOT_RECS_PROCESSED='custrecord_appf_aem_reelf_process_rec';
var FLD_TOT_RECS_NOT_PROCESSED = 'custrecord_appf_total_recs_not_processed';
var FLD_TOT_RECS='custrecord_appf_aem_reelf_total_records';

var FLD_TOT_LINES='custrecord_appf_num_of_trans_lines';
var FLD_CREATED_BY='custrecord_appf_aem_reelf_created_by';
var FLD_AEM_STATUS='custrecord_appf_aem_reelf_status';
var FLD_PROCESS_PERCENTAGE='custrecord_appf_processed_percentage';
var FLD_ERROR_LOG='custrecord_appf_error_log';
var FLD_SRC_FROM_FIL='custrecord_appf_source_from_fil';
var FLD_SRC_TO_FIL='custrecord_appf_sorce_to_fil';
var FLD_START_DATE_PO_FIL='custrecord_appf_st_dt_po';
var FLD_END_DATE_PO_FIL='custrecord_appf_en_dt_po';
var FLD_SUBSIDIARY_FIL='custrecord_appf_subsidiary_fil';
var FLD_DATA_FILE = 'custrecord_appf_data_file';
var FLD_PROCESS_RESET = 'custrecord_appf_process_reset';
var FLD_CSV_LABEL_ROW = 'custrecord_csv_file_label_row';
var FLD_ERROR_FILE = 'custrecord_appf_error_file';

	var FLD_COL_SO_LINE_ID='custcol_appf_line_id';

	var FLD_COL_REV_ARRANG_PO_LINE_ID='custcol_appf_po_line_id';
	var FLD_COL_REV_ARRANG_PO_NUM='custcol_appf_po_number';
	var FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT='itemlaborcostamount';
	var FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC='laborexpenseacct';
	var FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC='labordeferredexpenseacct';

	var FLD_COL_PO_EXPENSE_REV_ELEM_LINK='custcol_appf_aem_revenue_element_link';
	var FLD_COL_PO_REV_ARRNGEMENT_LINK='custcol_appf_aem_revenue_plan_link';
	var FLD_COL_PO_REV_ELEM_EXECUTION_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_PO_LINE_ID='custcol_appf_po_line_id';


var FLD_AEM_STATUS_INPROGRESS=2;
var FLD_AEM_STATUS_COMPLETED=4;

define(['N/search','N/task', 'N/record', 'N/email', 'N/runtime', 'N/error', 'N/file'],
		function(search, task,record, email, runtime, error, file)
		{   
		function getInputData()
			{
				
						var objrevrec = {};
						var uniquePOCount = 0;

					
				var ssCreateExpElem = runtime.getCurrentScript().getParameter({name: SPARAM_SS_CREATE_EXP_ELEMENTS});

	if(ssCreateExpElem != null && ssCreateExpElem != ''){
		var searchRec=search.load({id:ssCreateExpElem});
		var filList = searchRec.filters;
		var colList = searchRec.columns;
		
		var searchResults=getSearchResults('transaction', filList, colList);
		if(searchResults != null && searchResults != ''){
			try{
			log.debug('searchResults.length', searchResults.length);
			var count = searchResults.length;
			var timeStamp='RevArr'+new Date().getTime();
				var ssDataFile='';
				var labelRow = '';
				ssDataFile += 'PO ID,';
				var csvlabelRow = labelRow + 'PO ID, Revenue Arrangement ID, Error Details';
				for(var i=0; i<colList.length; i++){
					var coljson = JSON.parse(JSON.stringify(colList[i]));
										var coljsontype = coljson.type;
					if(i == (colList.length)-1){
						if (coljsontype == 'select')
						{
						ssDataFile += colList[i].label+',';
						ssDataFile += colList[i].label+' ID'+'\n';
										labelRow = labelRow + colList[i].label+',';
				                        labelRow = labelRow + colList[i].label+' ID'+'\n';

						}
						else{
							ssDataFile += colList[i].label+'\n';
										labelRow = labelRow + colList[i].label+',';

						}
					}
					else
					{
						if (coljsontype == 'select')
						{
						ssDataFile += colList[i].label+',';
						ssDataFile += colList[i].label+' ID'+',';
						                labelRow = labelRow + colList[i].label+',';
				                        labelRow = labelRow + colList[i].label+' ID'+',';
						}
						else{
							ssDataFile += colList[i].label+',';
									    labelRow = labelRow + colList[i].label+',';

						}
					}
				}
							var customRec=record.create({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG,isDynamic:true});
			customRec.setValue({fieldId:'customform', value:'141'});//OOH Form 
			customRec.setValue({fieldId:FLD_CSV_LABEL_ROW, value:csvlabelRow});
			customRec.setValue({fieldId:FLD_TOT_LINES, value:count});
			customRec.setValue({fieldId:FLD_TOT_RECS_PROCESSED, value:0});
			customRec.setValue({fieldId:FLD_TOT_RECS_NOT_PROCESSED, value:0});
			customRec.setValue({fieldId:FLD_AEM_STATUS, value:FLD_AEM_STATUS_INPROGRESS});
			customRec.setValue({fieldId:FLD_PROCESS_PERCENTAGE, value:0});
			customRec.setValue({fieldId:FLD_ERROR_LOG, value:''});
			//customRec.setValue({fieldId:FLD_DATA_FILE, value:ssDataFileID});
			var revElemExecLogID = customRec.save({
    enableSourcing: true,
    ignoreMandatoryFields: true
});

			for(var i=0; i<searchResults.length; i++){
				var result=searchResults[i];
				var recId=result.id;
				var revrecIntid=result.getValue(colList[0]);
				ssDataFile += recId+',';	
				
			   var lineobj = {};
				   lineobj.solineid = result.getValue(colList[4]);
				   lineobj.polineid = result.getValue(colList[2]);
				    lineobj.poid = recId;
				   lineobj.amount = result.getValue(colList[8]);
				   lineobj.exprecogacc = result.getValue(colList[7]);
				   lineobj.expacc = result.getValue(colList[6]);
				   lineobj.revelem = '';
				
                  if (!objrevrec.hasOwnProperty(revrecIntid.toString()))	
				  {
                   uniquePOCount++;
                   objrevrec[revrecIntid.toString()] = {};
				  objrevrec[revrecIntid.toString()].revrecid = result.getValue(colList[0]);		
                   objrevrec[revrecIntid.toString()].crid = revElemExecLogID;				   
				   
				   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
				   objrevrec[revrecIntid.toString()].lines = lines_obj;
			   
				  }	
                  else
                  {
									                      objrevrec[revrecIntid.toString()].crid = revElemExecLogID;				   
					  				                   objrevrec[revrecIntid.toString()].revrecid = result.getValue(colList[0]);				   

					   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
					 var lines_obj_existing = objrevrec[revrecIntid.toString()].lines;
					 lines_obj = lines_obj_existing.concat(lines_obj);
					 
					 				   objrevrec[revrecIntid.toString()].lines = lines_obj;
				  }
					  
				for(var k=0; k<colList.length; k++){ 
										var coljson = JSON.parse(JSON.stringify(colList[k]));
										var coljsontype = coljson.type;

					if(k==(colList.length)-1){
						

						if (coljsontype == 'select')
						{
							var colValue=result.getText(colList[k]);
							var colValue1=result.getValue(colList[k]);
							ssDataFile += colValue+',';
							ssDataFile += colValue1+'\n';
						}
						else{
							var colValue=result.getValue(colList[k]);
							ssDataFile += colValue+'\n';
						}
					}
					else{
						if (coljsontype == 'select')
						{
							var colValue=result.getText(colList[k]);
							var colValue1=result.getValue(colList[k]);
							ssDataFile += colValue+',';
							ssDataFile += colValue1+',';
						}
						else{
							var colValue=result.getValue(colList[k]);
							ssDataFile += colValue+',';
						}
					}
				}
				
			}
			var ssDataFileCreate=file.create({name:'ExpenseElementsData_'+timeStamp+'.csv',fileType:file.Type.CSV,contents:ssDataFile});
			ssDataFileCreate.folder=FOLDER_AEM_SL_FILES;
			var ssDataFileID= ssDataFileCreate.save();
						var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG,id:revElemExecLogID,isDynamic:true});
			
			customRec.setValue({fieldId:FLD_TOT_RECS, value:uniquePOCount});
			customRec.setValue({fieldId:FLD_DATA_FILE, value:ssDataFileID});
			var revElemExecLogID = customRec.save({
    enableSourcing: true,
    ignoreMandatoryFields: true
});

			log.debug('revElemExecLogID', revElemExecLogID);
			
		
			}catch(e){
			
				log.debug('unexpected error', e.message )
			}
		}
	}
	return objrevrec;

}
function reduce(context)
			{
                 // context = JSON.parse(context);
				  								log.debug('context in map', context);
						var ssKeyinternalids=[]

				var mainValues = context.values[0];
				log.debug('mainValues', mainValues);
				mainValues = JSON.parse(mainValues);
				var customRecID = mainValues.crid;
				var revArrID = mainValues.revrecid;				
								log.debug('revArrID', revArrID);
				var results = mainValues.lines;
				log.debug('results len', results.length);
				var errorMessage = '';			
				var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(customRecID)});
					
					
				var csvLabelRow = customRec.getValue({fieldId:FLD_CSV_LABEL_ROW});	
				if (csvLabelRow == null)
				csvLabelRow = '';	
											log.debug('csvLabelRow', csvLabelRow);

	
				var progressCounter=customRec.getValue({fieldId:FLD_TOT_RECS_PROCESSED});
				if(progressCounter == null || progressCounter == '')
				progressCounter=0;
				var nonProgressCounter=customRec.getValue({fieldId:FLD_TOT_RECS_NOT_PROCESSED});
				if(nonProgressCounter == null || nonProgressCounter == '')
				nonProgressCounter=0;
				var dataFileId = customRec.getValue({fieldId:FLD_DATA_FILE});
				var errorLog=customRec.getValue({fieldId:FLD_ERROR_LOG});
				if (errorLog == null)
					errorLog = '';
				var customReset=customRec.getValue({fieldId:FLD_PROCESS_RESET});
				var total=customRec.getValue({fieldId:FLD_TOT_RECS});
				var errorFileID = customRec.getValue({fieldId:FLD_ERROR_FILE});
				var errorFileData = '';
				
				try{
						var revArrRec=record.load({type:'revenuearrangement', id:Number(revArrID), isDynamic: true});
						var revArrangeTranID = revArrRec.getValue({fieldId:'tranid'});
						//log.debug('revArrangeTranID',revArrangeTranID);
						var date=revArrRec.getValue({fieldId:'trandate'});
						revArrRec.setValue({fieldId:'contractcostaccrualdate',value:date});
						for (var r = 0; r < results.length; r++)
						{
															//log.debug('results[r].solineid', results[r].solineid);

						var revrecLine = revArrRec.findSublistLineWithValue({
						sublistId: 'revenueelement',
						fieldId: FLD_COL_SO_LINE_ID,
						value: results[r].solineid
						});
														//log.debug('revrecLine', revrecLine);

							if (revrecLine != -1)
							{
								
								revArrRec.selectLine({
								sublistId: 'revenueelement',
								line: revrecLine
								});
								var revenueElem=revArrRec.getCurrentSublistValue({
								sublistId: 'revenueelement',
								fieldId: 'revenueelement'
								});
								results[r].revelem = revenueElem;
								ssKeyinternalids.push(results[r].poid+'||'+results[r].solineid+'||'+revenueElem+'||'+results[r].polineid+'||'+customRecID+'||'+Number(revArrID))
								if(customReset == true)
								{
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT, value:''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_NUM,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG, value:customRecID});
								}
								else
								{
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT, value: Number(results[r].amount)});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC, value:results[r].exprecogacc});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC, value:results[r].expacc});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_NUM, value:results[r].poid});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID, value:results[r].polineid});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG, value:customRecID});
								}
								revArrRec.commitLine({
								sublistId: 'revenueelement'
								});
							}
						}
								
								revArrRec.save({enableSourcing: true,
									ignoreMandatoryFields: true
									});
									progressCounter++;
						}
						catch(e)
						{
							nonProgressCounter++;
							log.debug('error for PO line:'+poLineID, e.message );
							errorMessage = 'SO Line ID '+soLineID+': Run Time Failure due to: '+e.message;  
							errorFileData =revArrID+','+errorMessage;
						}
				var totalViewed = parseInt(progressCounter)+parseInt(nonProgressCounter);
				var statusAEM = FLD_AEM_STATUS_INPROGRESS;
				if(total == totalViewed)
				{
					   statusAEM = FLD_AEM_STATUS_COMPLETED;
					if (errorMessage != null && errorMessage != '')
						statusAEM = FLD_AEM_STATUS_ERRORED;
					
				}
				
				var processPercent=(parseInt(totalViewed)/parseInt(total))*100;
				processPercent = Number(processPercent).toFixed(2);
				
				//customRec.setValue({fieldId:FLD_AEM_STATUS,value:statusAEM});
				customRec.setValue({fieldId:FLD_PROCESS_PERCENTAGE,value:processPercent});
				if (errorLog == '' && (errorMessage != null && errorMessage != ''))
				{
				customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorMessage});
				}
				if (errorLog != '' && (errorMessage != null && errorMessage != ''))
				{
					
					errorLog = errorLog + '\n' + errorMessage;
					customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorLog});
				}
				customRec.setValue({fieldId:FLD_TOT_RECS_PROCESSED,value:progressCounter});
				customRec.setValue({fieldId:FLD_TOT_RECS_NOT_PROCESSED,value:nonProgressCounter});
				
				if(errorFileData != '')
				{
									
					if(errorFileID == '' || errorFileID == null)
					{
						errorFileData=csvLabelRow+'\n'+errorFileData;
					var errorFileName = 'Rev Rec Update Error File_'+customRecID+'.csv';

						var fileObj=file.create({
						name: errorFileName,
						fileType: file.Type.CSV,
						contents: errorFileData,
						encoding: file.Encoding.UTF8,
						folder: FOLDER_AEM_SL_FILES
						});
						
						var ssErrorFileID= fileObj.save();
						customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
					else
					{
						var errorFile=file.load({id:errorFileID})
						
						errorFile.appendLine({value: errorFileData});
						
						var ssErrorFileID= errorFile.save();
						//customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
				}
				ssKeyinternalids = ssKeyinternalids+'';
				var existFileID  = customRec.getValue({fieldId:'custrecord_text_file_id_hidden'});
				var fileName = 'OOH_REVREC_PO_FILE_'+new Date().getTime();
				if (existFileID != null && existFileID != '')
				{
					var existFileIDDataObj = file.load({id:existFileID});
					var existFileIDData = existFileIDDataObj.getContents();
					fileName = existFileIDDataObj.name;
					ssKeyinternalids = existFileIDData + ',' + ssKeyinternalids;
					
				}
 var fileObj=file.create({
						name: fileName,
						fileType: file.Type.PLAINTEXT,
						contents: ssKeyinternalids+'',
						encoding: file.Encoding.UTF8,
						folder: FOLDER_AEM_SL_FILES
						});
						var ssFileID= fileObj.save();
						customRec.setValue({fieldId:'custrecord_text_file_id_hidden', value: ssFileID});
				customRec.save({enableSourcing: true,ignoreMandatoryFields: true});
			/*	
          context.write({
                key: revArrID+'SEP'+customRecID,
				value: ssKeyinternalids+''
            });
			*/
			if (processPercent == 100)
			{
				var mapReduceScriptId = 'customscript_appf_update_rev_elem_mr_2';
      var mapReduceDeployId = null;

        var mrTask = task.create({
            taskType: task.TaskType.MAP_REDUCE,
            scriptId: mapReduceScriptId,
            deploymentId: mapReduceDeployId
        });
		 mrTask.params = {
        'custscript_file_stamp' : ssFileID
    };
        var mrTaskId = mrTask.submit();
			}
				
			}
			function summarize(summary)
         {
			 log.debug('summary:',JSON.stringify(summary))
			var totalFileRecords = [];
			var recid = null;
summary.output.iterator().each(function (key, value){
	if (totalFileRecords.length == 0)
	{
		recid = key.split('SEP')[1];
		
	}
    log.debug({
        title: ' summary.output.iterator',
        details: 'value: ' + value
    });
	totalFileRecords.push(value);
	
    return true;
 });
 if (recid != null && recid != '')
 {
           log.debug('totalFileRecords',totalFileRecords.length)
		   
		   var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(recid)});
					
					
						customRec.save({enableSourcing: true,ignoreMandatoryFields: true});

						
           log.debug('ssFileID:',ssFileID)


   var mapReduceScriptId = 'customscript_appf_update_rev_elem_mr_2';
      var mapReduceDeployId = null;

        var mrTask = task.create({
            taskType: task.TaskType.MAP_REDUCE,
            scriptId: mapReduceScriptId,
            deploymentId: mapReduceDeployId
        });
		 mrTask.params = {
        'custscript_file_stamp' : ssFileID
    };
        var mrTaskId = mrTask.submit();
 }
		}
function getSearchResults(rectype, fils, cols) {
 var mySearch = search.create({
        type: rectype,
        columns: cols,
        filters: fils
    });
        var resultsList = [];
        var myPagedData = mySearch.runPaged({pageSize: 1000});
        myPagedData.pageRanges.forEach(function(pageRange){
            var myPage = myPagedData.fetch({index: pageRange.index});
            myPage.data.forEach(function(result){
               resultsList.push(result);
            });
        });
        return resultsList;
    }

 function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
			return {
				getInputData: getInputData,
				reduce: reduce
			};

		});		


