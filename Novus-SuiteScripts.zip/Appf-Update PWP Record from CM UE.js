/*
*Script Name: Appf-Update PWP Record from CM UE
*Script Type: User Event
*Description: 
*Company 	: Appficiency Inc.

*/

var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var FLD_PWP_INVOICE_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_inv_line_amt_paid';
var FLD_PWP_INVOICE_STATUS = 'custrecord_appf_pwp_client_inv_status';
var FLD_PWP_INVOICED_AMT = 'custrecord_appf_pwp_inv_line_amount';

var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_CRED_MEMO_LINK = 'custrecord_appf_pwp_cm_link';
var FLD_PWP_CRED_MEMO_AMT = 'custrecord_appf_pwp_cm_amount';

var FLD_PWP_IO_CHECKBOX='custrecord_appf_trigger_ob_integration';

var SCRIPT_UPDATE_PWP_FROM_CM_SC = 'customscript_appf_update_pwp_rec_cm_sc';
var SCRIPT_SYNC_PT_PTA_GENERIC_SL = 'customscript_appf_generic_sl_2';
var DEPLOY_SYNC_PT_PTA_GENERIC_SL = 'customdeploy_appf_generic_sl_2';

var SPARAM_CRED_MEMO_ID = 'custscript_appf_cred_memo_id';
var SPARAM_UPDATE_PWP_CREDIT_MEMO_SS = 'custscript_appf_update_pwp_cms_ss';
var STATUS_PAYMENT_PENDING='4'
var STATUS_PARTIALLY_PAID='5'
var STATUS_PAID='7'
function updatePWPCMAfterSubmit(type) {
	var context = nlapiGetContext();
	
	var cmSS = context.getSetting('SCRIPT', SPARAM_UPDATE_PWP_CREDIT_MEMO_SS);
	if(type != 'delete'){
		var recType = nlapiGetRecordType();
		var recId = nlapiGetRecordId();
		var credMemo = nlapiLoadRecord(recType, recId);
		var count = credMemo.getLineItemCount('item');
		
		if(count <= 60){
			var pwpIds = [];
			for(var i=1; i<=count; i++){
				try{
				var pwpRecId = credMemo.getLineItemValue('item', FLD_COL_PWP_RECORD, i);
				var soLineId = credMemo.getLineItemValue('item', FLD_COL_SO_LINE_ID, i);
				if(pwpRecId != null && pwpRecId != '' && cmSS != null && cmSS != ''){				
					
					var filters = [];
									   filters.push(new nlobjSearchFilter('internalid', null, 'anyof', recId));

					
						
					var cmSearchResults = nlapiSearchRecord(null, cmSS, filters, null);
					if(cmSearchResults != null && cmSearchResults != ''){
						var credMemoAmtSum = 0;
						var credMemoIdsArr = [];
						for(var j=0; j<cmSearchResults.length; j++){
							var result = cmSearchResults[j];
							var credMemoId = result.getId();
							var ssCols = result.getAllColumns();
							var credMemoAmt = result.getValue(ssCols[0]);
							if(credMemoAmt == null || credMemoAmt == '')
								credMemoAmt = 0;
							credMemoAmtSum = parseFloat(credMemoAmtSum) + parseFloat(credMemoAmt);
							credMemoIdsArr.push(credMemoId);
						}
						credMemoIdsArr = eliminateDuplicates(credMemoIdsArr);
						var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
						pwpRecord.setFieldValues(FLD_PWP_CRED_MEMO_LINK, credMemoIdsArr);
						if(credMemoAmtSum != null && credMemoAmtSum != '')
							credMemoAmtSum = Number(credMemoAmtSum).toFixed(2);
						pwpRecord.setFieldValue(FLD_PWP_CRED_MEMO_AMT, credMemoAmtSum);
						var pwpStatus=getCustomerStatus(pwpRecord,FLD_PWP_CRED_MEMO_AMT,credMemoAmtSum)
						   if(pwpStatus!=null && pwpStatus!='')
						   {
						pwpRecord.setFieldValue(FLD_PWP_INVOICE_STATUS, pwpStatus);
					    pwpRecord.setFieldValue(FLD_PWP_IO_CHECKBOX, 'T');
						pwpIds.push(pwpRecId);
						   }
						
						var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
						nlapiLogExecution('DEBUG', 'pwpId', pwpId);
					}
					
				}
			}catch(e){
				if ( e instanceof nlobjError )
					  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
					  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
			}	
				var slURL =  nlapiResolveURL('SUITELET',SCRIPT_SYNC_PT_PTA_GENERIC_SL,DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external');
	slURL += '&genetricrecid='+pwpIds+'&genetricrectype='+CUSTOM_RECORD_PWP+'&isbackend=T';
    nlapiLogExecution('debug','slURL',slURL)
	try{
					nlapiRequestURL(slURL);
				  }catch (e) {
					  try{
						nlapiRequestURL(slURL);
					  }catch (ex) {
						  try{
						  nlapiRequestURL(slURL);
						  }
						  catch (ep)
						  {
							                    nlapiLogExecution('debug','error triggering Generic SL',ep);

						  }
					  }
				  }
		}
		else{
			var params = {};
			params[SPARAM_CRED_MEMO_ID] = recId;
			nlapiScheduleScript(SCRIPT_UPDATE_PWP_FROM_CM_SC, null, params);
		}
	}
	
}

function getCustomerStatus(pwpRecord,fielID,fieldValue) 
{
	                    var invAmtSum = fieldValue;
						var invLinePaymentAmtSum = fieldValue;
						var crditAmtSum = fieldValue;
						
						var crditStatus=''
						
						if(fielID!=FLD_PWP_INVOICED_AMT)
							invAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICED_AMT);
						
						if(fielID!=FLD_PWP_INVOICE_LINE_PAYMENT_AMT)
							invLinePaymentAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICE_LINE_PAYMENT_AMT);
						
						if(fielID!=FLD_PWP_CRED_MEMO_AMT)
							crditAmtSum=pwpRecord.getFieldValue(FLD_PWP_CRED_MEMO_AMT);
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{	
					if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)==0)
							crditStatus=STATUS_PAYMENT_PENDING
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && ((parseFloat(invAmtSum)-parseFloat(invLinePaymentAmtSum))>0))
							crditStatus=STATUS_PARTIALLY_PAID
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '' && crditAmtSum!=null && crditAmtSum!='')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && parseFloat(invAmtSum)==(parseFloat(invLinePaymentAmtSum)+parseFloat(crditAmtSum)))
							crditStatus=STATUS_PAID
						}
							
							return crditStatus
	
}

function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}