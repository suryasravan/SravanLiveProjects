/**
* Script Name : Appf - Refresh ConsoliatedInvExecLog UE
* Script Type : User Event
* Description : The script put a refresh button on custom record "appf-customer payment application log".
* Company     :	Appficiency Inc.
*/

var BTN_REFRESH='custpage_refresh_btn';
var SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID='customscript_client_paymt_application_sl';
var SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID='customdeploy_client_paymt_application_sl';
var BTN_PAYMENT_APPLICATION_SUITELET='custpage_payment_application_sl'
var CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG='customrecord_appf_cust_pmt_app_log';
var FLD_CUSTOMER_PAYMENT_INVOICE_LINKS='custbody_appf_pmt_appl_log_rec_links';
var FLD_TOT_CHILD_INVCS_PROCESSED='custrecord_appf_cst_pmt_inv_completed';
var FLD_TOT_CHILD_INVCS_TO_PROCESS='custrecord_appf_cst_pmt_total_inv';
var FLD_CHILD_INVCS_PROCESS_PERCENTAGE='custrecord_appf_cst_pmt_perc_processed';
var CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG='customrecord_appf_cust_pmt_app_log';
var FLD_CUSTOMER_PAYMENT_STATUS='custrecord_appf_cst_pmt_status';
var FLD_TOT_LINKED_TRANSACTIONS = 'custrecord_appf_tot_linked_trans_to_proc';

var FLD_INVOICE_DATA_FILE = 'custrecord_appf_cst_pmt_data_file';
var FLD_CREDIT_DATA_FILE = 'custrecord_appf_cst_pmt_data_file_cm';
var FLD_INVOICE_RESULT_FILE = 'custrecord_invoice_processing_resultfile';

var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_credits_processed_percen';
var FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT='custrecord_appf_inv_processed_percent';
var FLD_LINKED_TRANSACTIONS_PERCENT = 'custrecord_appf_linked_trans_prc_percent';
var FLD_BACKLINKING_PERCENT = 'custrecord_appf_backlinking_percent';

var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY=4;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS=2;
function userEventBeforeLoad(type, form, request){
	if(type == 'view'){
     
		var recId = nlapiGetRecordId();
		var processingStatus = nlapiGetFieldValue(FLD_CUSTOMER_PAYMENT_STATUS);
		/*var invoicesPrcessedPercent = nlapiGetFieldValue(FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT);
		var creditsProcessedPercent = nlapiGetFieldValue(FLD_CREDITS_PROCESSED_PERCENT);
      	var linkedTransactionPercent = nlapiGetFieldValue(FLD_LINKED_TRANSACTIONS_PERCENT);
      	var totLinkedTransactions = nlapiGetFieldValue(FLD_TOT_LINKED_TRANSACTIONS);
      	var invoiceDataFile = nlapiGetFieldValue(FLD_INVOICE_DATA_FILE);
      	var creditsDataFile = nlapiGetFieldValue(FLD_CREDIT_DATA_FILE);
      var invoiceResultFile = nlapiGetFieldValue(FLD_INVOICE_RESULT_FILE);
      
      
      
      var backlinkingPercent = nlapiGetFieldValue(FLD_BACKLINKING_PERCENT);
      
		var totalProcessed = true;
		
		if(invoiceDataFile != null && invoiceDataFile != '' && (invoicesPrcessedPercent == null || invoicesPrcessedPercent == '' || parseFloat(invoicesPrcessedPercent)<100)){
			totalProcessed = false;
		}
		if(creditsDataFile != null &&  creditsDataFile != '' && (creditsProcessedPercent == null || creditsProcessedPercent == '' || parseFloat(creditsProcessedPercent)<100)){
			totalProcessed = false;
		}
      	if(totLinkedTransactions != null && totLinkedTransactions != '' && Number(totLinkedTransactions) > 0 && (linkedTransactionPercent == null || linkedTransactionPercent == '' || parseFloat(linkedTransactionPercent)<100)){
			totalProcessed = false;
		}
      
      	
      	if(invoiceResultFile == null || invoiceResultFile == '')
			totalProcessed = false;
      
      if(backlinkingPercent == null || backlinkingPercent == '' || parseFloat(backlinkingPercent)<100)
      		totalProcessed = false;
        */
		if(processingStatus != null && processingStatus != '' && processingStatus == CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS){
			//nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, recId, [FLD_CUSTOMER_PAYMENT_STATUS], [CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS]);
			var url=nlapiResolveURL('RECORD', CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, recId);
			form.addButton(BTN_REFRESH, 'Refresh', 'window.open(\''+url+'\',\'_self\',\'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1000,height=500\')');
		}
		else{           
			nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, recId, [FLD_CUSTOMER_PAYMENT_STATUS], [CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY]);
			var suiteletUrl=nlapiResolveURL('SUITELET',SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID,SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID);
			form.addButton(BTN_PAYMENT_APPLICATION_SUITELET,'Payment Application Suitelet','window.open(\''+suiteletUrl+'\',\'_self\')')
		}
	}
}