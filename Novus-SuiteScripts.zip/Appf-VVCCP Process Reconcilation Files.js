/**
	 * Script Name : Appf-VVCCP Process Reconcilation Files
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			  Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_VVCCP_RECON_FILE='customrecord_appf_vvccp_recon_file';
var FLD_ATTACHED_VVCCP_RECORD='custrecord_appf_vvccp_link';
var FLD_RECON_FILE='custrecord_appf_vvccp_recon_file';
var FLD_AMOUNT_CHARGED='custrecord_appf_vvccp_recon_amount';
var FLD_CHARGE_DATE='custrecord_appf_vvccp_recon_charge_date';
var FLD_TRANSACTION_ID='custrecord_appf_vvccp_recon_tran_id';
var PAYMENT_CONTRA_JOURNAL_ENTRY='custrecord_appf_vvccp_card_contra_je';
var SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE='custscript_amex_contra_account';
var SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE='custscript_mastercard_contar_account';
//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';
var FLD_TOTAL_CHARGED='custrecord_appf_vvccp_total_charged';
var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var CUSTOM_RECORD_CORPORATE_CREDIT_CARDS='customrecord_appf_corp_card_table';
var FLD_CLEANING_ACCOUNT='custrecord_appf_corp_credit_card_clacc';

var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9
var VVCCP_STATUS_PARTIAL_CHARGED =10
function schedule(type)
{
	
		var context=nlapiGetContext();
		var amexResponseFile=535260;
		var mastercardResponseFile=535261;
		var amexContraAccountFromCompanyPreference=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE);
		var mastercardContraAccountFromCompanyPreference=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE);
		
		if(amexResponseFile)
		{	
		try
		{	
		var amexResponseFileData=nlapiLoadFile(amexResponseFile);
		var amexResponseFileValues=amexResponseFileData.getValue();
		amexResponseFileValues=amexResponseFileValues.split('\n');
		for(a=0;a<amexResponseFileValues.length;a++)
		{
		var firstCharFromLines=amexResponseFileValues[a].substr(0,1);
		if(Number(firstCharFromLines)== 1)
		{
		var chargeDateFromRow101=amexResponseFileValues[a].substr(573,8);
		var transactionIdFromRow111=amexResponseFileValues[a].substr(632,50);
		var amountChargedFromRow117=amexResponseFileValues[a].substr(738,15);
		var vvccpInternalIdFromRow361=amexResponseFileValues[a+1].substr(266,39);
		nlapiLogExecution('debug','chargeDateFromRow101:',chargeDateFromRow101);
		nlapiLogExecution('debug','transactionIdFromRow111:',transactionIdFromRow111);
		nlapiLogExecution('debug','amountChargedFromRow117:',amountChargedFromRow117);
		nlapiLogExecution('debug','vvccpInternalIdFromRow361:',vvccpInternalIdFromRow361);
		var subsidiaryForJournalAmex='';
		var vvccpRecordAmexType='';
		if(vvccpInternalIdFromRow361 !=null && vvccpInternalIdFromRow361 !='' && vvccpInternalIdFromRow361 !=' ')
		{
		vvccpRecordAmexType=nlapiLoadRecord(CUSTOM_RECORD_VVCCP,Number(vvccpInternalIdFromRow361));
		var vvccpRecordAmexStatus=vvccpRecordAmexType.getFieldValue(FLD_VVCCP_STATUS);
		if(vvccpRecordAmexStatus == VVCCP_STATUS_AUTHORIZED)
		{
		var VVCCPReconFileRecordForAmex=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RECON_FILE);
		VVCCPReconFileRecordForAmex.setFieldValue(FLD_RECON_FILE,amexResponseFile);
		var amexReconDateFromFile='';
		if(chargeDateFromRow101 !=null && chargeDateFromRow101 !='' && chargeDateFromRow101 !=' ')
		{
			//chargeDateFromRow101 is in CCYYMMDD format
			 var str = chargeDateFromRow101;
			 var yrPart='';
			 var mnPart='';
			 yrPart = str.slice(2,4);
			 mnPart = str.slice(4,6);
			 var ddpart=str.slice(6);
			 var currentYear = new Date().getFullYear();
			 var currentYrPart = currentYear.toString().slice(0,2);
			 var revYear = Number(currentYrPart + yrPart);
			 var revMon = Number(mnPart)-1;
			 amexReconDateFromFile =new Date(revYear,revMon,ddpart);
			 amexReconDateFromFile=nlapiDateToString(amexReconDateFromFile);
			 nlapiLogExecution('debug','amexReconDateFromFile:',amexReconDateFromFile);
			VVCCPReconFileRecordForAmex.setFieldValue(FLD_CHARGE_DATE,amexReconDateFromFile);
		}
			if(transactionIdFromRow111 !=null && transactionIdFromRow111 !='' && transactionIdFromRow111 !=' ')	
			VVCCPReconFileRecordForAmex.setFieldValue(FLD_TRANSACTION_ID,transactionIdFromRow111);
			if(amountChargedFromRow117 !=null && amountChargedFromRow117 !='' && amountChargedFromRow117 !=' ')
			VVCCPReconFileRecordForAmex.setFieldValue(FLD_AMOUNT_CHARGED,parseFloat(amountChargedFromRow117));
			VVCCPReconFileRecordForAmex.setFieldValue(FLD_ATTACHED_VVCCP_RECORD,Number(vvccpInternalIdFromRow361));
			vvccpRecordAmexTypeName=vvccpRecordAmexType.getFieldValue('name');
			var corporateCreditOnVVCCP=vvccpRecordAmexType.getFieldValue(FLD_CORPORATE_CREDIT_CARD);
			if(corporateCreditOnVVCCP !=null && corporateCreditOnVVCCP !='')
			{
				var corporateCreditCardRecord=nlapiLoadRecord(CUSTOM_RECORD_CORPORATE_CREDIT_CARDS,corporateCreditOnVVCCP);
				creditAccountForJournalAmexType=corporateCreditCardRecord.getFieldValue(FLD_CLEANING_ACCOUNT);
			}
			var vendorOnVVCCP=vvccpRecordAmexType.getFieldValue(FLD_VENDOR);
			subsidiaryForJournalAmex=nlapiLookupField('vendor',vendorOnVVCCP,'subsidiary');
			try
			{
			var journalEntry=nlapiCreateRecord('journalentry');
			if(subsidiaryForJournalAmex)
			journalEntry.setFieldValue('subsidiary',subsidiaryForJournalAmex);	
			journalEntry.selectNewLineItem('line');
			if(amexContraAccountFromCompanyPreference !=null && amexContraAccountFromCompanyPreference !='')
			journalEntry.setCurrentLineItemValue('line','account',amexContraAccountFromCompanyPreference);
			if(amountChargedFromRow117 !=null && amountChargedFromRow117 !='' && amountChargedFromRow117 !=' ')
			journalEntry.setCurrentLineItemValue('line','debit',parseFloat(amountChargedFromRow117));
			journalEntry.commitLineItem('line');
			journalEntry.selectNewLineItem('line');
			if(creditAccountForJournalAmexType !=null && creditAccountForJournalAmexType !='')
			journalEntry.setCurrentLineItemValue('line','account',creditAccountForJournalAmexType);
			if(amountChargedFromRow117 !=null && amountChargedFromRow117 !='' && amountChargedFromRow117 !=' ')
			journalEntry.setCurrentLineItemValue('line','credit',parseFloat(amountChargedFromRow117));
			journalEntry.commitLineItem('line');
			if(vvccpRecordAmexTypeName !=null && vvccpRecordAmexTypeName !='')
			journalEntry.setFieldValue('memo','('+vvccpRecordAmexTypeName+')'+'Payment Clearance Journal Entry');
			if(amexReconDateFromFile)
			journalEntry.setFieldValue('trandate',amexReconDateFromFile);
			var journalEntryId=	nlapiSubmitRecord(journalEntry,true,true);
			nlapiLogExecution('debug','journalEntryId:',journalEntryId);
			if(journalEntryId)
			VVCCPReconFileRecordForAmex.setFieldValue(PAYMENT_CONTRA_JOURNAL_ENTRY,journalEntryId);
			}
			catch(j)
			{
				nlapiLogExecution('debug','Error Deatils in Creating Journal Amex:',j.toString());
			}
			var vvccpReconcilationFileCustomRecordIdAmex=nlapiSubmitRecord(VVCCPReconFileRecordForAmex,true,true);
			nlapiLogExecution('debug','vvccpReconcilationFileCustomRecordIdAmex:',vvccpReconcilationFileCustomRecordIdAmex);
		// point2.	Update the VVCCP Record linked to the custom record
		var typeOnVVCCP=vvccpRecordAmexType.getFieldValue(FLD_TYPE);
		var maximumToSpendOnVVCCP=vvccpRecordAmexType.getFieldValue(FLD_MAXIMUM_TO_SPEND);
		if(typeOnVVCCP == VVCCP_CARD_TYPE_SINGLE_USE)
		{
			if(amountChargedFromRow117 !=null && amountChargedFromRow117 !='' && amountChargedFromRow117 !=' ')
			{
				if(parseFloat(maximumToSpendOnVVCCP) == parseFloat(amountChargedFromRow117))
				{
					vvccpRecordAmexType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTHORIZED_CLEARED);
					vvccpRecordAmexType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow117));
				}
			}
		}
		if(typeOnVVCCP == VVCCP_CARD_TYPE_MULTI_USE)
		{
			if(amountChargedFromRow117 !=null && amountChargedFromRow117 !='' && amountChargedFromRow117 !=' ')
			{
				if(parseFloat(maximumToSpendOnVVCCP) == parseFloat(amountChargedFromRow117))
				{
					vvccpRecordAmexType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTHORIZED_CLEARED);
					vvccpRecordAmexType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow117));
				}
				if(parseFloat(amountChargedFromRow117) < parseFloat(maximumToSpendOnVVCCP))
				{
					vvccpRecordAmexType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PARTIAL_CHARGED);
					vvccpRecordAmexType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow117));
				}
			}
		}
		nlapiSubmitRecord(vvccpRecordAmexType,true,true);
		}
		}
		}
		} //end of amexfile loop
		}	
		catch(e)
		{
			nlapiLogExecution('debug','Error Deatils in Amex:',e.toString());
		}
		}        //end of amex file 
		
		
		if(mastercardResponseFile)
		{
		try
		{
		var mastercardResponseFileData=nlapiLoadFile(mastercardResponseFile);
		var mastercardResponseFileValues=mastercardResponseFileData.getValue();
		mastercardResponseFileValues=mastercardResponseFileValues.split('\n');
		for(m=0;m<mastercardResponseFileValues.length;m++)
		{
			//nlapiLogExecution('debug','mastercardResponseFileValues:',mastercardResponseFileValues);
			mastercardResponseFileValuesColumns=mastercardResponseFileValues[m].split('|');
			nlapiLogExecution('debug','mastercardResponseFileValuesColumns:',mastercardResponseFileValuesColumns);
			var chargeDateFromRow21=mastercardResponseFileValuesColumns[9];
			var transactionIdFromRow12=mastercardResponseFileValuesColumns[0];
			var amountChargedFromRow22=mastercardResponseFileValuesColumns[10];
			var vvccpInternalIdFromRow23=mastercardResponseFileValuesColumns[11];
			nlapiLogExecution('debug','chargeDateFromRow21:',chargeDateFromRow21);
			nlapiLogExecution('debug','transactionIdFromRow12:',transactionIdFromRow12);
			nlapiLogExecution('debug','amountChargedFromRow22:',amountChargedFromRow22);
			nlapiLogExecution('debug','vvccpInternalIdFromRow23:',vvccpInternalIdFromRow23);
			
			var subsidiaryForJournalMasterCard='';
			var vvccpRecordMasterCardType='';
			var creditAccountForJournalMastercardType='';
			var vvccpMasterCardStatus='';
			if(vvccpInternalIdFromRow23 !=null && vvccpInternalIdFromRow23 !='' && vvccpInternalIdFromRow23 != ' ')
			{
			vvccpRecordMasterCardType=nlapiLoadRecord(CUSTOM_RECORD_VVCCP,vvccpInternalIdFromRow23);
			vvccpMasterCardStatus=vvccpRecordMasterCardType.getFieldValue(FLD_VVCCP_STATUS);
			nlapiLogExecution('debug','vvccpMasterCardStatus:',vvccpMasterCardStatus);
			if(vvccpMasterCardStatus == VVCCP_STATUS_AUTHORIZED)
			{
			var VVCCPReconFileRecordForMastercard=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RECON_FILE);
			VVCCPReconFileRecordForMastercard.setFieldValue(FLD_RECON_FILE,mastercardResponseFile);
			var masterCardreconDateFromFile='';
			if(chargeDateFromRow21 !=null && chargeDateFromRow21 !='' && chargeDateFromRow21 !=' ')
			{
				
				var str = chargeDateFromRow21;
				var yrPart = str.slice(0,4);
				var mnPart = str.slice(4,6);
				var ddpart=str.slice(6);
				var revMon = Number(mnPart)-1;
				var masterCardreconDateFromFile =new Date(yrPart,revMon,ddpart);
				masterCardreconDateFromFile=nlapiDateToString(masterCardreconDateFromFile);	
				nlapiLogExecution('debug','masterCardreconDateFromFile:',masterCardreconDateFromFile);
				VVCCPReconFileRecordForMastercard.setFieldValue(FLD_CHARGE_DATE,masterCardreconDateFromFile);
			}
			if(transactionIdFromRow12 !=null && transactionIdFromRow12 !='' && transactionIdFromRow12 !=' ')	
			VVCCPReconFileRecordForMastercard.setFieldValue(FLD_TRANSACTION_ID,transactionIdFromRow12);
			if(amountChargedFromRow22 !=null && amountChargedFromRow22 !='' && amountChargedFromRow22 !=' ')
			VVCCPReconFileRecordForMastercard.setFieldValue(FLD_AMOUNT_CHARGED,parseFloat(amountChargedFromRow22));
			VVCCPReconFileRecordForMastercard.setFieldValue(FLD_ATTACHED_VVCCP_RECORD,vvccpInternalIdFromRow23);
			
			
			var vendorOnVVCCP=vvccpRecordMasterCardType.getFieldValue(FLD_VENDOR);
			subsidiaryForJournalMasterCard=nlapiLookupField('vendor',vendorOnVVCCP,'subsidiary');
			vvccpRecordName=vvccpRecordMasterCardType.getFieldValue('name');
			var corporateCreditOnVVCCP=vvccpRecordMasterCardType.getFieldValue(FLD_CORPORATE_CREDIT_CARD);
			if(corporateCreditOnVVCCP !=null && corporateCreditOnVVCCP !='')
			{
				var corporateCreditCardRecord=nlapiLoadRecord(CUSTOM_RECORD_CORPORATE_CREDIT_CARDS,corporateCreditOnVVCCP);
				creditAccountForJournalMastercardType=corporateCreditCardRecord.getFieldValue(FLD_CLEANING_ACCOUNT);
				nlapiLogExecution('debug','creditAccountForJournalMastercardType:',creditAccountForJournalMastercardType);
			}
			nlapiLogExecution('debug','subsidiaryForJournalMasterCard:',subsidiaryForJournalMasterCard);
			nlapiLogExecution('debug','masterCardreconDateFromFile:',masterCardreconDateFromFile);
			try
			{
			var journalEntry=nlapiCreateRecord('journalentry');
			if(subsidiaryForJournalMasterCard)
			journalEntry.setFieldValue('subsidiary',subsidiaryForJournalMasterCard);
			journalEntry.selectNewLineItem('line');
			if(mastercardContraAccountFromCompanyPreference !=null && mastercardContraAccountFromCompanyPreference !='')
			journalEntry.setCurrentLineItemValue('line','account',mastercardContraAccountFromCompanyPreference);
			if(amountChargedFromRow22 !=null && amountChargedFromRow22 !='' && amountChargedFromRow22 !=' ')
			journalEntry.setCurrentLineItemValue('line','debit',parseFloat(amountChargedFromRow22));
			journalEntry.commitLineItem('line');
			journalEntry.selectNewLineItem('line');
			if(creditAccountForJournalMastercardType !=null && creditAccountForJournalMastercardType !='')
			journalEntry.setCurrentLineItemValue('line','account',creditAccountForJournalMastercardType);
			if(amountChargedFromRow22 !=null && amountChargedFromRow22 !='' && amountChargedFromRow22 !=' ')
			journalEntry.setCurrentLineItemValue('line','credit',parseFloat(amountChargedFromRow22));
			journalEntry.commitLineItem('line');
			if(vvccpRecordName !=null && vvccpRecordName !='')
			journalEntry.setFieldValue('memo',vvccpRecordName+' '+'Payment Clearance Journal Entry');
			if(masterCardreconDateFromFile)
			journalEntry.setFieldValue('trandate',masterCardreconDateFromFile);
		
			var journalEntryId=	nlapiSubmitRecord(journalEntry,true,true);
			nlapiLogExecution('debug','journalEntryId:',journalEntryId);
			
			if(journalEntryId)
			VVCCPReconFileRecordForMastercard.setFieldValue(PAYMENT_CONTRA_JOURNAL_ENTRY,journalEntryId);
			}
			catch(k)
			{
				nlapiLogExecution('debug','Error Deatils in MasterCard Journal Craeting:',k.toString());
			}
			var vvccpReconcilationFileCustomRecordIdMasterCard=nlapiSubmitRecord(VVCCPReconFileRecordForMastercard,true,true);
			nlapiLogExecution('debug','vvccpReconcilationFileCustomRecordIdMasterCard:',vvccpReconcilationFileCustomRecordIdMasterCard);
			
			var typeOnVVCCP=vvccpRecordMasterCardType.getFieldValue(FLD_TYPE);
			var maximumToSpendOnVVCCP=vvccpRecordMasterCardType.getFieldValue(FLD_MAXIMUM_TO_SPEND);
			
			if(typeOnVVCCP == VVCCP_CARD_TYPE_SINGLE_USE)
			{
				if(amountChargedFromRow22 !=null && amountChargedFromRow22 !='' && amountChargedFromRow22 !=' ')
				{
					if(parseFloat(maximumToSpendOnVVCCP) == parseFloat(amountChargedFromRow22))
					{
						vvccpRecordMasterCardType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTHORIZED_CLEARED);
						vvccpRecordMasterCardType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow22));
					}
				}
			}
		if(typeOnVVCCP == VVCCP_CARD_TYPE_MULTI_USE)
		{
			if(amountChargedFromRow22 !=null && amountChargedFromRow22 !='' && amountChargedFromRow22 !=' ')
			{
				if(parseFloat(maximumToSpendOnVVCCP) == parseFloat(amountChargedFromRow22))
				{
					vvccpRecordMasterCardType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTHORIZED_CLEARED);
					vvccpRecordMasterCardType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow22));
				}
				if(parseFloat(amountChargedFromRow22) < parseFloat(maximumToSpendOnVVCCP))
				{
					vvccpRecordMasterCardType.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PARTIAL_CHARGED);
					vvccpRecordMasterCardType.setFieldValue(FLD_TOTAL_CHARGED,parseFloat(amountChargedFromRow22));
				}
			}
		}
		var vvccpRecordId=nlapiSubmitRecord(vvccpRecordMasterCardType,true,true);
		nlapiLogExecution('debug','vvccpRecordId:',vvccpRecordId);
		}
		}
		}
		}
		catch(m)
		{
			nlapiLogExecution('debug','Error Deatils in MasterCard:',m.toString());
		}
		}
	
}	


function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		
function searchUnion(target, array)
{
		return target.concat(array); // TODO: use _.union
}
	