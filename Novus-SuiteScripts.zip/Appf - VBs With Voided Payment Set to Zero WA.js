/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Set Bills with Voided Payment column field Bill Line Payment Amount = 0.
 * 
 * Author: Roach
 * Date: Dec 17, 2020
 */
define(['N/record'],

function(record) {
   var VAL_REJECTED = 3;
   var FLD_COL_VB_LINE_PAYMENT_AMT = 'custcol_appf_pwp_bill_line_amt_paid';
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @Since 2016.1
     */
    function onAction(scriptContext) {
    	var currentRecord = scriptContext.newRecord; 
    	var recVB = record.load({type: record.Type.VENDOR_BILL,id: currentRecord.id,isDynamic: true});

    	//set all FLD_COL_VB_LINE_PAYMENT_AMT  = 0
		var lineCount = recVB.getLineCount({sublistId: 'item'});
		for(var i = 0; i < lineCount; i++) {
			recVB.selectLine({sublistId: 'item',line: i});
			recVB.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_COL_VB_LINE_PAYMENT_AMT,value: 0});
			recVB.commitLine({sublistId: 'item'});
		}
    	
    	recVB.save();

    }

    return {
        onAction : onAction
    };
    
});
