/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: This script copies the Client Contract - Non Media field value to Client Contract field when 
 *              form is Novus - Sales Order (Non-Media) and the two fields don't match.
 *              Trigger: Before Submit
 * 
 * Author: Rochelle Tapulado
 * Date: Jul 31, 2020
 */
 
define(['N/runtime'],

function(runtime) {
	var FLD_SO_CLIENTCONTRACT_NONMEDIA = 'custbody_client_contract_nm';
	var FLD_SO_CLIENTCONTRACT = 'custbody_appf_client_contract';
	var SPARAM_SO_FORM = 'custscript_appf_salesorder_form';
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) {
    	var recSO = scriptContext.newRecord;
    	//trigger script only for specific form
    	var sForm = runtime.getCurrentScript().getParameter({name: SPARAM_SO_FORM});
    	var aForm = sForm.split(',');
    	if(!isEmpty(sForm) && aForm.indexOf(recSO.getValue('customform')) !== -1/*recSO.getValue('customform') == idForm*/){
    		try{
        		//get value for Client Contract (Non-Media)
        		var idClientContractNonMedia = recSO.getValue({
        		    fieldId: FLD_SO_CLIENTCONTRACT_NONMEDIA
        		});
        		//get value for Client Contract
        		var idClientContract = recSO.getValue({
        		    fieldId: FLD_SO_CLIENTCONTRACT
        		});
        		//check if Client Contract is Empty or does not match Client Contract (Non-Media) field
        		if(!isEmpty(idClientContractNonMedia) || idClientContractNonMedia != idClientContract){	
        			recSO.setValue({
                        fieldId: FLD_SO_CLIENTCONTRACT,
                        value: idClientContractNonMedia
                    });
        			log.debug('copied value');
        		}
    		}catch(e){
    			log.error('Error saving record',e.message);
    		}

    	}

    }
    /**
     * Evaluate id value is null
     * @param stValue
     */
    function isEmpty(stValue) {
        return (
            stValue === '' ||
            stValue == null ||
            stValue == undefined ||
           (stValue.constructor === Array && stValue.length == 0) ||
           (stValue.constructor === Object &&
           (function(v) {
               for (var k in v) return false;
                   return true;
            })(stValue))
        );
    }
    return {
        beforeSubmit: beforeSubmit
    };
    
});
