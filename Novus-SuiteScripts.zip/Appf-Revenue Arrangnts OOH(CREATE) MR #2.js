	/**
	 * @NApiVersion 2.0
	 * @NScriptType MapReduceScript
	 */


/**
* Script Name : Appf-Revenue Arrangnts OOH(CREATE) MR #2
* Script Type : Map or Reduce
* Description : This script triggers from "Appf-Revenue Arrangements OOH(CREATE) MR" and finishes the AEM process execution to update all POs with revenue elements and arrangement links
* Company     :	Appficiency Inc.
*/

var SPARAM_SS_CREATE_EXP_ELEMENTS = 'custscript_appf_update_rev_elements_ss';
var SCRIPT_ID_HELPER_SUITELET='customscript_helper_scrpt_cal_map_reduce';
var DEPLOYMENT_ID_HELPER_SUITELET='customdeploy_helper_scrpt_cal_map_reduce';
var FOLDER_AEM_SL_FILES= '895';
var SCRIPT_SCHEDULED='customscript_appf_update_rev_arrange_sc';
var DEPLOY_SCHEDULED='customdeploy_appf_update_rev_arrange_sc';
var SPARAM_CUSTOM_REC_ID='custscript_appf_custom_rec_id';

var SPARAM_FILES='custscript_file_stamp';
var CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG='customrecord_appf_aem_rev_ele_ex_log';
var FLD_TOT_RECS_PROCESSED='custrecord_appf_aem_reelf_process_rec';
var FLD_TOT_RECS_NOT_PROCESSED = 'custrecord_appf_total_recs_not_processed';
var FLD_TOT_RECS='custrecord_appf_aem_reelf_total_records';

var FLD_TOT_PO_RECS_PROCESSED='custrecord_appf_proc_po_recs';
var FLD_TOT_PO_RECS_NOT_PROCESSED = 'custrecord_appf_fail_po_recs';
var FLD_PO_PROCESS_PERCENTAGE='custrecord_appf_perc_po_recs';
var FLD_PO_TOT_LINES='custrecord_appf_total_po_recs';

var FLD_TOT_LINES='custrecord_appf_num_of_trans_lines';
var FLD_CREATED_BY='custrecord_appf_aem_reelf_created_by';
var FLD_AEM_STATUS='custrecord_appf_aem_reelf_status';
var FLD_PROCESS_PERCENTAGE='custrecord_appf_processed_percentage';
var FLD_ERROR_LOG='custrecord_appf_error_log';
var FLD_SRC_FROM_FIL='custrecord_appf_source_from_fil';
var FLD_SRC_TO_FIL='custrecord_appf_sorce_to_fil';
var FLD_START_DATE_PO_FIL='custrecord_appf_st_dt_po';
var FLD_END_DATE_PO_FIL='custrecord_appf_en_dt_po';
var FLD_SUBSIDIARY_FIL='custrecord_appf_subsidiary_fil';
var FLD_DATA_FILE = 'custrecord_appf_data_file';
var FLD_PROCESS_RESET = 'custrecord_appf_process_reset';
var FLD_CSV_LABEL_ROW = 'custrecord_csv_file_label_row';
var FLD_ERROR_FILE = 'custrecord_appf_error_file';

	var FLD_COL_SO_LINE_ID='custcol_appf_line_id';

	var FLD_COL_REV_ARRANG_PO_LINE_ID='custcol_appf_po_line_id';
	var FLD_COL_REV_ARRANG_PO_NUM='custcol_appf_po_number';
	var FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT='itemlaborcostamount';
	var FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC='laborexpenseacct';
	var FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC='labordeferredexpenseacct';

	var FLD_COL_PO_EXPENSE_REV_ELEM_LINK='custcol_appf_aem_revenue_element_link';
	var FLD_COL_PO_REV_ARRNGEMENT_LINK='custcol_appf_aem_revenue_plan_link';
	var FLD_COL_PO_REV_ELEM_EXECUTION_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_PO_LINE_ID='custcol_appf_po_line_id';


var FLD_AEM_STATUS_INPROGRESS=2;
var FLD_AEM_STATUS_COMPLETED=4;

define(['N/search','N/task', 'N/record', 'N/email', 'N/runtime', 'N/error', 'N/file'],
		function(search, task,record, email, runtime, error, file)
		{   
		function getInputData()
			{
						var objPO = {};
						var uniquePOCount = 0
				var fileId = runtime.getCurrentScript().getParameter({name: SPARAM_FILES});
	if(fileId != null && fileId != ''){
			try{
					var fileObj = file.load({
    id: fileId
});
				  var fileData=fileObj.getContents();
	var selectedLines = fileData.split(',');
			var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(selectedLines[0].split('||')[4])});
				customRec.setValue({fieldId:FLD_TOT_PO_RECS_PROCESSED, value:0});
			    customRec.setValue({fieldId:FLD_TOT_PO_RECS_NOT_PROCESSED, value:0});
			    customRec.setValue({fieldId:FLD_PO_PROCESS_PERCENTAGE, value:0});
 for(var s=0; s<selectedLines.length; s++)
 {
				var line = selectedLines[s].split('||')
				var recId=line[0];
				 var lineobj = {};
				   lineobj.solineid = line[1];
				   lineobj.polineid = line[3];
				   lineobj.revelem =line[2];
				if (!objPO.hasOwnProperty(recId.toString()))	
				  {
					  uniquePOCount++
                   objPO[recId.toString()] = {};
				   objPO[recId.toString()].poid = recId.toString();	
                   objPO[recId.toString()].crid = line[4];	
				   objPO[recId.toString()].revrecid = line[5];	
				   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
				   objPO[recId.toString()].lines = lines_obj;
			   
				  }	
                  else
                  {
					  				   objPO[recId.toString()].poid = recId.toString();
					  				   objPO[recId.toString()].revrecid = line[5];				   

					   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
					 var lines_obj_existing = objPO[recId.toString()].lines;
					 lines_obj = lines_obj_existing.concat(lines_obj);
					 
					 				   objPO[recId.toString()].lines = lines_obj;
				  }
				log.debug('line',line)
				
 }
		customRec.setValue({fieldId:'custrecord_appf_total_po_recs', value:uniquePOCount});
			var revElemExecLogID = customRec.save({
    enableSourcing: true,
    ignoreMandatoryFields: true
});

			log.debug('revElemExecLogID', revElemExecLogID);
			}catch(e){
			
				log.debug('unexpected error', e.message )
			}
	}
	return objPO;
}
function reduce(context)
			{
                 // context = JSON.parse(context);
				  								log.debug('context in map', context);
				var mainValues = context.values[0];
				log.debug('mainValues', mainValues);
				mainValues = JSON.parse(mainValues);
				var customRecID = mainValues.crid;
				var revArrID = mainValues.revrecid;	
                   var poID=mainValues.poid;				
								log.debug('revArrID', revArrID);
				var results = mainValues.lines;
				log.debug('results len', results.length);
				var errorMessage = '';		
              var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(customRecID)});
			  log.debug('customRec', customRec);
				var nonProgressCounter=customRec.getValue({fieldId:FLD_TOT_PO_RECS_NOT_PROCESSED});
				if(nonProgressCounter == null || nonProgressCounter == '')
				nonProgressCounter=0;				
				var progressCounter=customRec.getValue({fieldId:FLD_TOT_PO_RECS_PROCESSED});
				if(progressCounter == null || progressCounter == '')
				progressCounter=0;
			   var total=customRec.getValue({fieldId:'custrecord_appf_total_po_recs'});
				var errorLog=customRec.getValue({fieldId:FLD_ERROR_LOG});
				if (errorLog == null)
					errorLog = '';
				log.debug('errorLog', errorLog);
				var errorFileID = customRec.getValue({fieldId:FLD_ERROR_FILE});
				var customReset=customRec.getValue({fieldId:FLD_PROCESS_RESET});
				var errorFileData = '';
				try{
					var csvlabelRow = 'PO ID, Revenue Arrangement ID, Error Details';
				var po=record.load({type:'purchaseorder', id:Number(poID),isDynamic:true});
								for (var r = 0; r < results.length; r++)
						        {
								var isPOLine = po.findSublistLineWithValue({sublistId:'item', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID, value:results[r].polineid});
								var isSOLine = po.findSublistLineWithValue({sublistId:'item', fieldId:FLD_COL_SO_LINE_ID, value:results[r].solineid});
								if (isPOLine != -1 && isSOLine != -1 && isSOLine == isPOLine)
									{
										var revenueElem = results[r].revelem;
																		log.debug('revenueElem', revenueElem);

										po.selectLine({sublistId:'item', line:isPOLine});
										 if(customReset == true){
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_EXPENSE_REV_ELEM_LINK, value:''});
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ARRNGEMENT_LINK, value:''});
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ELEM_EXECUTION_LOG, value:customRecID});
										 }
										 else
										 {
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_EXPENSE_REV_ELEM_LINK, value:revenueElem});
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ARRNGEMENT_LINK, value:revArrID});
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ELEM_EXECUTION_LOG, value:customRecID});
											 log.debug('revenueElemTest', revenueElem);
											 
										 }
										po.commitLine({sublistId:'item'});
									}
									}
									po.save({enableSourcing: true,
									ignoreMandatoryFields: true
									});
									progressCounter++
				}
				catch(e)
						{
							nonProgressCounter++;
							errorMessage = ': Run Time Failure due to: '+e.message;  
							errorFileData = poID+','+revArrID+','+errorMessage;
						}
						var totalViewed = parseInt(progressCounter)+parseInt(nonProgressCounter);
				var statusAEM = FLD_AEM_STATUS_INPROGRESS;
				if(total == totalViewed)
				{
					   statusAEM = FLD_AEM_STATUS_COMPLETED;
					if (errorMessage != null && errorMessage != '')
						statusAEM = FLD_AEM_STATUS_ERRORED;
				}
				var processPercent=(parseInt(totalViewed)/parseInt(total))*100;
				processPercent = Number(processPercent).toFixed(2);
				customRec.setValue({fieldId:FLD_PO_PROCESS_PERCENTAGE,value:processPercent});
				if (errorLog == '' && (errorMessage != null && errorMessage != ''))
				{
				customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorMessage});
				}
				if (errorLog != '' && (errorMessage != null && errorMessage != ''))
				{
					
					errorLog = errorLog + '\n' + errorMessage;
					customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorLog});
				}
				customRec.setValue({fieldId:FLD_TOT_PO_RECS_PROCESSED,value:progressCounter});
				customRec.setValue({fieldId:FLD_TOT_PO_RECS_NOT_PROCESSED,value:nonProgressCounter});
				customRec.setValue({fieldId:FLD_AEM_STATUS,value:statusAEM});
				if(errorFileData != '')
				{				
					if(errorFileID == '' || errorFileID == null)
					{
						errorFileData=csvLabelRow+'\n'+errorFileData;
					var errorFileName = 'Rev Rec Update Error File_'+customRecID+'.csv';

						var fileObj=file.create({
						name: errorFileName,
						fileType: file.Type.CSV,
						contents: errorFileData,
						encoding: file.Encoding.UTF8,
						folder: FOLDER_AEM_SL_FILES
						});
						
						var ssErrorFileID= fileObj.save();
						customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
					else
					{
						var errorFile=file.load({id:errorFileID})
						errorFile.appendLine({value: errorFileData});
						var ssErrorFileID= errorFile.save();
						//customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
				}
				customRec.save({enableSourcing: true,ignoreMandatoryFields: true});
				
         context.write({
					key: 'RevArrgmt_',
					value: poID
					}); 
				
			}
function getSearchResults(rectype, fils, cols) {
 var mySearch = search.create({
        type: rectype,
        columns: cols,
        filters: fils
    });
        var resultsList = [];
        var myPagedData = mySearch.runPaged({pageSize: 1000});
        myPagedData.pageRanges.forEach(function(pageRange){
            var myPage = myPagedData.fetch({index: pageRange.index});
            myPage.data.forEach(function(result){
               resultsList.push(result);
            });
        });
        return resultsList;
    }

 function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
			return {
				getInputData: getInputData,
				reduce: reduce
			};

		});		