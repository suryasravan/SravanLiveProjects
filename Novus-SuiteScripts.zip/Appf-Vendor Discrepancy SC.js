/*Script Name: Appf-Vendor Discrepancy Suitelet SC
 *Script Type: Scheduled
 *Description: This script update the Discrepancy type and Action for selected VB lines in Vendor Discrepancy SL
 *Company 	 : Appficiency.
 */
var SPARAM_CUSTOM_REC_ID='custscript_appf_vendor_discrepancy_log';
var CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG='customrecord_appf_vendor_discrepancy_log';
var FLD_SELECTED_VB_LINES_FILE = 'custrecord_appf_selected_vb_lines_file';
var FLD_TOTAL_VB_LINES_PROCESSED = 'custrecord_appf_tot_vb_lines_processed';
var FLD_ERROR_LOG = 'custrecord_appf_vb_lines_error_log';
var FLD_PROCESSING_FILE_STATUS = 'custrecord_appf_processing_file_status';
var CUSTOM_LIST_DISCREPANCY_TYPE='customlist_appf_discrepancy_type';
var CUSTOM_LIST_DISCREPANCY_ACTION='customlist_appf_discrepancy_action';

var IMPORT_VENDOR_BILL_LINES = 'custimport_appf_update_vendor_bill_lines';

function scheduledVendorDiscrepancySC(type){
	var context = nlapiGetContext();
	var custRecID = context.getSetting('SCRIPT',SPARAM_CUSTOM_REC_ID);
	nlapiLogExecution('debug','custRecID:',custRecID);
	if(custRecID != null && custRecID != ''){
		var vendDiscExecLogRec = nlapiLoadRecord(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG, custRecID);
		var csvFile = vendDiscExecLogRec.getFieldValue(FLD_SELECTED_VB_LINES_FILE);
		if(csvFile != null && csvFile != ''){
			try{
				
			var discTypeCol = new Array();
	discTypeCol[0] = new nlobjSearchColumn('name');
	discTypeCol[1] = new nlobjSearchColumn('internalId');
	var discrepancyList = {};
	var results = nlapiSearchRecord(CUSTOM_LIST_DISCREPANCY_TYPE, null, null, discTypeCol);
	for ( var i = 0; results != null && i < results.length; i++ ){
		  var res = results[i];
		  var listValue = res.getValue('name');
		  var listID = res.getValue('internalId');
		  discrepancyList[listValue] = listID;
	} 
	
	var actionCol = new Array();
	actionCol[0] = new nlobjSearchColumn('name');
	actionCol[1] = new nlobjSearchColumn('internalId');
	var actionList = {};
	var results = nlapiSearchRecord(CUSTOM_LIST_DISCREPANCY_ACTION, null, null, actionCol);
	for ( var i = 0; results != null && i < results.length; i++ ){
		  var res = results[i];
		  var listValue = res.getValue('name');
		  var listID = res.getValue('internalId');
		  actionList[listValue] = listID;
	} 	
				
			var fileData = nlapiLoadFile(csvFile);
			var dataLines = fileData.getValue().split('\n');
			var vendorBillData = '';
			vendorBillData += 'VB Internal ID, VB Line ID, Discrepant Type, Execution Log ID\n';
			for(var i=1; i<(dataLines.length-1); i++){
				var eachCol = dataLines[i].split(',');
				vendorBillData += eachCol[0] +','+ eachCol[1] +','+ eachCol[2] +','+ custRecID +'\n';
			}
			nlapiLogExecution('debug', 'vendorBillData', vendorBillData);
			if(vendorBillData != null && vendorBillData != ''){
				var importVendorBillLines = nlapiCreateCSVImport();
				importVendorBillLines.setMapping(IMPORT_VENDOR_BILL_LINES);
				importVendorBillLines.setPrimaryFile(vendorBillData);
				var processingJOBID = nlapiSubmitCSVImport(importVendorBillLines);
				nlapiSubmitField(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG,custRecID,[FLD_PROCESSING_FILE_STATUS],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
			}
		}catch(e){
			var errorLog = '';
			if ( e instanceof nlobjError ){
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
				  errorLog += 'System error : '+e.getDetails()+'\n';
			}
			else{
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				  errorLog += 'Unexpected error : '+e.toString()+'\n';
			}
			nlapiSubmitField(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG,custRecID,[FLD_ERROR_LOG],[errorLog]);

		}
		}
	}  
}
