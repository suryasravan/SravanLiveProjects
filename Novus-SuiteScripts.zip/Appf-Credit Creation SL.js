/*Script Name: Appf-Credit Creation SL
 *Script Type: Suitelet
 *Description: 
 *Company 	 : Appficiency.
 */
var SL_TITLE='Credit Creation Suitelet';
var SL_FLD_TYPE='custpage_type';
var SCRIPT_CLIENT = 'customscript_appf_credit_creation_cl';
var CREATE_CLIENT_CREDIT='1';
var CREATE_VENDOR_CREDIT='2';
var SCRIPT_SL_CLIENT_CREDIT_SUITELET='customscript_appf_client_credit';
var DEPLOY_SL_CLIENT_CREDIT_SUITELET='customdeploy_appf_client_credit';
var SCRIPT_SL_VENDOR_CREDIT_SUITELET='customscript_appf_vendor_credit_sl';
var DEPLOY_SL_VENDOR_CREDIT_SUITELET='customdeploy_appf_vendor_credit_sl';

function creditCreationSL(request, response){
	if(request.getMethod() == 'GET'){
		try{
		var type=request.getParameter('type');
		nlapiLogExecution('debug','type',type);
		var form = nlapiCreateForm(SL_TITLE);
		form.setScript(SCRIPT_CLIENT);
		var typeField = form.addField(SL_FLD_TYPE,'select','Type');
		typeField.addSelectOption('', '');
		typeField.addSelectOption(CREATE_CLIENT_CREDIT, 'Create Client Credit');
		typeField.addSelectOption(CREATE_VENDOR_CREDIT, 'Create Vendor Credit');
		
		if(type == CREATE_CLIENT_CREDIT)
		{
		response.sendRedirect('SUITELET',SCRIPT_SL_CLIENT_CREDIT_SUITELET,DEPLOY_SL_CLIENT_CREDIT_SUITELET)
		}
		if(type == CREATE_VENDOR_CREDIT)
		{
		response.sendRedirect('SUITELET',SCRIPT_SL_VENDOR_CREDIT_SUITELET,DEPLOY_SL_VENDOR_CREDIT_SUITELET)
	
		}
		response.writePage(form);
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}

		
	}
	
}