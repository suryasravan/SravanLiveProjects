/*
* Script Name : Appf-Vendor Credit SC #1
* Script Type : Scheduled
* Description : This script trigegrs immediately on submit of Appf - Vendor Credit SL and for VBs selected it sets the CREDIT SUITELET STATUS field as Under Processing and Checks the Credit Processing (Do Not Hide) checkbox at the line level for all lines selected on the Suitelet
* Company     : Appficiency Inc.
*/

var CUSTOM_RECORD_VENDOR_CREDIT_CREATION_LOG='customrecord_appf_vend_crd_log';
var FLD_DATA_FILE = 'custrecord_appf_vend_crd_data_file';

var FLD_VB_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var FLD_COL_VB_LINE_ID = 'custcol_appf_po_line_id';
var FLD_COL_VB_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var SL_STATUS_UNDER_PROCESSING = '1';
var FLD_COL_VB_LINE_ID='custcol_appf_po_line_id';

var SCRIPT_VENDOR_CREDIT_CREATION_SC = 'customscript_appf_vendor_credit_sc';
var SPARAM_CREDIT_CREATION_LOG_ID = 'custscript_appf_credit_creation_log_rec';

var SPARAM_CREDIT_CREATION_LOG_ID_1 = 'custscript_appf_vendor_credit_log_id';
var SAPARM_SELECTED_LINES_FILE_ID = 'custscript_appf_selected_vb_file_id';
var SPARAM_INDEX = 'custscript_appf_vendor_credit_index1';

function updateBillsScheduled(type){
	try{
		var context = nlapiGetContext();
		var custRecID = context.getSetting('SCRIPT', SPARAM_CREDIT_CREATION_LOG_ID_1);
		var billsDataFileId = context.getSetting('SCRIPT', SAPARM_SELECTED_LINES_FILE_ID);
		var index = context.getSetting('SCRIPT', SPARAM_INDEX);
		if(index == null || index == '')
			index = 0;
		var billsProcessed = true;
		if(billsDataFileId != null && billsDataFileId != ''){
				var vbRecords = {};
				var fileContent = nlapiLoadFile(billsDataFileId).getValue();
				if(fileContent != null && fileContent != ''){
					fileContent = fileContent.split('\n');
					for(var f=index; f<(fileContent.length-1); f++){					
						var vbData = fileContent[f].split('::');
						try{
							if(vbData != null && vbData != ''){						
								var vbRec = nlapiLoadRecord('purchaseorder', vbData[0]);
								vbRec.setFieldValue(FLD_VB_CREDIT_SL_STATUS, SL_STATUS_UNDER_PROCESSING);
								var vbLineIds = vbData[1];
								if(vbLineIds != null && vbLineIds != ''){
									vbLineIds = vbLineIds.split('|');
									for(var i=0; i<(vbLineIds.length-1); i++){
										var lineNum = vbRec.findLineItemValue('item', FLD_COL_VB_LINE_ID, vbLineIds[i]);
										if(lineNum != -1)
										vbRec.setLineItemValue('item', FLD_COL_VB_CREDIT_PROCESSING, lineNum, 'T');
									}
								}
								var vbId = nlapiSubmitRecord(vbRec, true, true);
								nlapiLogExecution('debug', 'vbId', vbId);
							}
						}catch(e){
								
								if ( e instanceof nlobjError )
								  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
								else
								  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
						}
						if(context.getRemainingUsage() <= 500 && (f+1) < (fileContent.length-1)){
							billsProcessed = false;
							var params = {};
							params[SPARAM_INDEX] = (f+1);
							params[SPARAM_CREDIT_CREATION_LOG_ID_1] = custRecID;
							params[SAPARM_SELECTED_LINES_FILE_ID] = billsDataFileId;
							nlapiScheduleScript(context.getScriptId(), null, params);
							break;
						}
					
					}
					
				}
				if(billsProcessed){
					if(billsDataFileId != null && billsDataFileId != '')
					nlapiDeleteFile(billsDataFileId);
				   var params = {};
				   params[SPARAM_CREDIT_CREATION_LOG_ID] = custRecID;
				   nlapiScheduleScript(SCRIPT_VENDOR_CREDIT_CREATION_SC, null, params);
				}
			}
		}catch(e){
			if ( e instanceof nlobjError )
								  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
								else
								  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
	}