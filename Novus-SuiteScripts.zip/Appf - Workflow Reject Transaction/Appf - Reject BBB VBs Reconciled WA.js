/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Set Approval Status of Vendor Bill = Reject
 * 
 * Author: Roach
 * Date: Sep 05, 2020
 */
define(['N/record'],

function(record) {
   var VAL_REJECTED = 3;
    /**
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @Since 2016.1
     */
    function onAction(scriptContext) {
    	var currentRecord = scriptContext.newRecord; 
    	var recVB = record.load({type: record.Type.VENDOR_BILL,id: currentRecord.id,isDynamic: true});
    	recVB.setValue({fieldId: 'approvalstatus',value: VAL_REJECTED});
    	recVB.save();

    }

    return {
        onAction : onAction
    };
    
});
