/**
*Script Name: Appf-Connex Vendor to NetSuite Vendor
*Script Type: Schedule Script
*Description:  This script when executed checks for any new messages in the queue related to Connex vendor and pushes the vendor from those messages into netsuite and creates or updates as vendor records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var FLD_COL_TTB_UPDATED_PROJECT='custcol_appf_ttb_update_project';
  var CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS='customrecord_appf_connex_vendor_in';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_MESSAGE ='custrecord_appf_vendor_messageid';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_CONTENT_LINK='custrecord_appf_vendor_jsoncontent';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_QUEU_NAME ='custrecord_appf_vendor_queuename';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_AZURE_RESPONSE='custrecord_appf_vendor_response';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR='custrecord_vendor_id';
  var CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_RESPONSE_STATUS='custrecord_response_vendor_status';
  var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_connex_vendor_resp_status';
 var CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP = 'custrecord_appf_netsuite_ven_send_respon';
 // Integration Related
 var QUEUE_CONNEX_VENDOR_INBOUND = 'novusmedia_connex_vendor_in';
 //novusmedia_connex_vendor_in
 var QUEUE_CONNEX_VENDOR_INBOUND_RESPONSE = 'netsuite_crm_response';
 var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
 
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
//var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
 var FLD_CONNEX_ID='custentity_appf_connexid';
 var FLD_LAST_UPDATE_DATE_TIME = 'custentity_appf_integr_lastupdatedate';

 // var NS_OB_RESPONSE_PROPERTY='Novus.Connex.Sync.NetSuite.Models.Response.VendorResponse'
 var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Response.NetSuite.VendorResponseMessage'

var SPARAM_CONNEX_VENDOR='customscript_appf_connex_vendor_2_ns_sc'
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
function createVendorScheduled(type) 
  {	
  var context = nlapiGetContext();
    var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
    if(URL_BASE!=null && URL_BASE!='')
      {
                 var messagesFound=true
                 while (messagesFound == true) {
                   var idForResponse = '';
				    var connexIDResponseValue=''
                   var usageRemaining = context.getRemainingUsage();
                    nlapiLogExecution('debug', 'usageRemaining:', usageRemaining);
				   var d = new Date();
                 var UTCDate= d.toISOString();
var url = URL_BASE+QUEUE_CONNEX_VENDOR_INBOUND+'/messages/head?api-version=2015-01';
var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
var mainObj = responseData.getBody();
var CorrelationIdProp='NServiceBus.CorrelationId'
var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

  var CorrelationId=responseData.getHeader(CorrelationIdProp)  
  var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp) 
 var responseDataAllHeaders=responseData.getAllHeaders()
  var responseData3=responseDataAllHeaders[3]
  var responseDataProp=responseData.getHeader(responseData3) 
 var integrationResponseObj={}  
                   var Status=''
				   var Status1=''
				   var scriptStatus=''
                   var fileData=''
                   if(mainObj==null || mainObj=='')
                     {
                        messagesFound=false;
                     Status='FAILED'+'(Empty Message)'
					 scriptStatus='FAILED'
					 Status1='FAILED'+'(Empty Message)'
                     }
                   else
                     {
                       try {
								mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					            mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
				      	        fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					          mainObj = JSON.parse(fileData);
					               if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
					               {
						                 connexIDResponseValue=mainObj[FLD_CONNEX_ID];
						                 nlapiLogExecution('debug', 'connexIDResponseValue:', connexIDResponseValue);
					                  }
					                Status='SUCCESS'
                           } 
						catch (e) 
						{
						   Status='FAILED'+'(invalid JSON)'
						   scriptStatus='FAILED'
							Status1='FAILED'+'(invalid JSON)'
						}
                     }

                  if(responseData.getCode()!='200' && responseData.getCode()!='201')
				   {
                     messagesFound=false
					   if (responseData.getCode()!='204')
					   {
                         var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS)
							integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_RESPONSE_STATUS,'FAILED')
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_MESSAGE,responseDataProp)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_CONTENT_LINK,fileData)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_QUEU_NAME,QUEUE_CONNEX_VENDOR_INBOUND)
					   var integrationRecordID=nlapiSubmitRecord(integrationRecord,true,true)
				
					   }
				   }
                  else
                     {
			             var nsVendorRecord='';
			             var addressbookCount=0;
                          var internalId=''
					      var nsCreationMsg = '';
						  var isUpdateRecord = true; 
					      var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS)
							integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_RESPONSE_STATUS,'SUCCESS')
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_MESSAGE,responseDataProp)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_CONTENT_LINK,fileData)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_QUEU_NAME,QUEUE_CONNEX_VENDOR_INBOUND)
					var integrationRecordID= nlapiSubmitRecord(integrationRecord,true,true)
					try
					{					
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsVendorRecord=nlapiCreateRecord('vendor')
               if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					 var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('vendor', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
                    nsVendorRecord=nlapiLoadRecord('vendor',internalId)
					addressbookCount=nsVendorRecord.getLineItemCount('addressbook')
					var msdate=''
				 var nsdate=nsVendorRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
							 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
							 
                   }  
                                  }
                        }

					}
					 
				 }
			}
			else{
                 internalId=mainObj['id']
				  nlapiLogExecution('debug', 'internalId',  internalId);
                  if(internalId==null || internalId=='')
				  {
                  nsVendorRecord=nlapiCreateRecord('vendor')
                     if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					 var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('vendor', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
                    nsVendorRecord=nlapiLoadRecord('vendor',internalId)
					addressbookCount=nsVendorRecord.getLineItemCount('addressbook')
					var msdate=''
				 var nsdate=nsVendorRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
                                  }
                        }

					}
					 
				 }
				  }
                     else
					 {
                       idForResponse=internalId
                    nsVendorRecord=nlapiLoadRecord('vendor',internalId)
					addressbookCount=nsVendorRecord.getLineItemCount('addressbook')
					var msdate=''
				 var nsdate=nsVendorRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
							 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
									
			}
			}
					}
					 catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			          var nsVendorRecordID=null;
					   
					    if(Status==null || Status=='' || Status=='SUCCESS')
                       {
						 nlapiLogExecution('debug', 'nsCreationMsg:', nsCreationMsg);
nlapiLogExecution('debug', 'isUpdateRecord:', isUpdateRecord);						 
					    try{ 
					if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {
						   nlapiLogExecution('debug', 'isUpdateRecordin:', isUpdateRecord);		
					var count = nsVendorRecord.getLineItemCount('submachine');
						 var existingSubsidiaries = [];
					for(var c=1; c<=count; c++){
						existingSubsidiaries.push(nsVendorRecord.getLineItemValue('submachine', 'subsidiary', c));
					}
					var count = nsVendorRecord.getLineItemCount('currency');
						 var existingCurrenciesList = [];
					for(var c=1; c<=count; c++){
						existingCurrenciesList.push(nsVendorRecord.getLineItemValue('currency', 'currency', c));
					}
						for (var parentProp in mainObj)
    	             {
						 //nlapiLogExecution('debug', ' parentProp',  parentProp);
			            //var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  if(parentProp==FLD_CONNEX_ID)
						 {
							 if(parentProp1==null || parentProp1=='')
								 parentProp1=''
						       connexIDResponseValue=parentProp1
						 }
						  var parentProp2=nsVendorRecord.getFieldValue(parentProp)
						  if(parentProp!='addressbook')
						 {
						 if((parentProp1!=null && parentProp1!='' && parentProp!='subsidiaries'))
						 {
							 //if(parentProp!='otherrelationships' && parentProp!='version' && parentProp!='unbilledordersprimarycurrency' && parentProp!='creditlimitcurrency' && parentProp!='balanceprimarycurrency' && parentProp!="id" && parentProp != 'custentity_appf_remittance_email_list')
			                  //nsVendorRecord.setFieldValue(parentProp,mainObj[parentProp])	
			                  
			                  //10/8/2020
							 if(parentProp!='otherrelationships' && parentProp!='version' && parentProp!='unbilledordersprimarycurrency' && parentProp!='creditlimitcurrency' && parentProp!='balanceprimarycurrency' && parentProp!="id" && parentProp != 'custentity_appf_remittance_email_list'){
								 nsVendorRecord.setFieldValue(parentProp,mainObj[parentProp])	
							 }else if (parentProp == 'custentity_appf_remittance_email_list'){
									 var invRecipients = mainObj[parentProp];
									 if (invRecipients != null && invRecipients != '')
									 {
										 invRecipients = invRecipients.split(',');
										 nsVendorRecord.setFieldValues(parentProp,invRecipients)
									 }
								 }
						 }
						 if(parentProp=='subsidiaries')
						 {
							 if(parentProp1!=null && parentProp1!='')
							 {
								 var currenciesList=[]
							 var subsidiaries=mainObj[parentProp].split(',')
							 if (idForResponse == '' || idForResponse == null)
							 nsVendorRecord.setFieldValue('subsidiary',subsidiaries[0])
                                var nscurrencyfils = [];
	                           nscurrencyfils.push(new nlobjSearchFilter('internalid',null,'anyof',subsidiaries));
							    var nscurrencyColls = [];
							  nscurrencyColls.push(new nlobjSearchColumn('currency'))
							  var CurrenySerchRecord=nlapiSearchRecord('subsidiary', null, nscurrencyfils,nscurrencyColls);
							  if(CurrenySerchRecord!=null && CurrenySerchRecord!="")
							  {
                                for (var cr = 0; cr < CurrenySerchRecord.length; cr++)
								  currenciesList.push(CurrenySerchRecord[cr].getValue('currency'))
							  }
							 for(var i=0;i<subsidiaries.length;i++)
							 {
								 var subsidiariesId=subsidiaries[i]
								 
							 if(existingSubsidiaries.indexOf(subsidiariesId) == -1){
						               nsVendorRecord.selectNewLineItem('submachine');
						               nsVendorRecord.setCurrentLineItemValue('submachine', 'subsidiary', subsidiariesId);
						                nsVendorRecord.commitLineItem('submachine');
							 }
					     }
						  for(var k=0;k<currenciesList.length;k++)
							 {
								  var currencyID=currenciesList[k]
								  if(existingCurrenciesList.indexOf(currencyID) == -1){
								   nsVendorRecord.selectNewLineItem('currency');
								   nsVendorRecord.setCurrentLineItemValue('currency', 'currency', currencyID);
								  nsVendorRecord.commitLineItem('currency');
								  }
							 }
							 }
						 }
						 }
						  else
{
	var isArray=true;
	if (parentProp1 instanceof Array) {
  isArray=true
} else {
 isArray=false
}
 if(isArray)
 {
for(var k=0;k<parentProp1.length;k++) 
       {
		   var parentPropki=parentProp1[k]
		   nlapiLogExecution('debug', ' parentPropki',  parentPropki);
		    nlapiLogExecution('debug', ' addressbookCount',  addressbookCount);
if(k+1<=addressbookCount)
			{
              nsVendorRecord.selectLineItem('addressbook',k+1)
			  nlapiLogExecution('debug', ' parentPropkiFirstr',  parentPropki);
			}
			else
                 {
                   nsVendorRecord.selectNewLineItem('addressbook')
				   nlapiLogExecution('debug', ' parentPropkiNewLine',  parentPropki);
                  }
 for (var parentPropkies in parentPropki)
    	             {
                       var parentProp145=parentPropki[parentPropkies]
					   nlapiLogExecution('debug', parentPropkies,  parentProp145);
						 if((parentPropkies!=''))
						 {
							  nlapiLogExecution('debug', 'parentPropkiesSet',  parentProp145);
							  
							  if(parentPropkies!='addrphone')
						     nsVendorRecord.setCurrentLineItemValue('addressbook',parentPropkies,parentPropki[parentPropkies])
							 
							 if(parentPropkies=='addrphone')
							 nsVendorRecord.setCurrentLineItemValue('addressbook','phone',parentPropki[parentPropkies])
						 }
                      }
nsVendorRecord.commitLineItem('addressbook')
}
 }
}
		              }
		               nsVendorRecordID=nlapiSubmitRecord(nsVendorRecord,true,true)
						nlapiLogExecution('debug', 'nsVendorRecordID', nsVendorRecordID);
		              }
					  else
					   {
						if(nsCreationMsg==null || nsCreationMsg=='')
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
					       scriptStatus='WARNING'
					   }
						}
						 catch(e1)
					   {
						   scriptStatus='FAILED'
						   if (e1 instanceof nlobjError)
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
					   }
					   
					    if (nsVendorRecordID != null)
					   {
						   var isInActiveRecord=false;
						   if(mainObj.hasOwnProperty('isinactive'))
						   {
							  if (mainObj['isinactive'] == 'T') 
								  isInActiveRecord=true
						   }
						   if(!isInActiveRecord)
						   nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR,CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_AZURE_RESPONSE], [nsVendorRecordID, 'SUCCESS']);
					   }
					   
					   else
					   {
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CONNEX_VENDOR_AZURE_RESPONSE], [scriptStatus+":"+nsCreationMsg]);
   
					   }
					   
			if(nsVendorRecordID!=null && nsVendorRecordID!='')
			{
               idForResponse=nsVendorRecordID;
				
				scriptStatus='SUCCESS'
if (responseData.getCode() == '200' || responseData.getCode() == '201')
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					  else
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
			}
			
                     }
					 }
					  if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
				   {
					   nlapiLogExecution('debug', 'nsVendorRecordID', nsVendorRecordID);
				      	
						 if(connexIDResponseValue==null || connexIDResponseValue=='')
							   connexIDResponseValue=''
						    integrationResponseObj.EntityId=connexIDResponseValue
						
		                 if(idForResponse==null || idForResponse=='')
							 idForResponse=''
						  integrationResponseObj.NetSuiteId=idForResponse
						  if(Status1!=null && Status1!='')
							   integrationResponseObj.IntegrationResponseStatus=Status1
						   else
						 integrationResponseObj.IntegrationResponseStatus=scriptStatus
					 
						  if(nsCreationMsg==null || nsCreationMsg=='')
							 nsCreationMsg=''
						  integrationResponseObj.IntegrationResponseMessage=nsCreationMsg	

nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_VENDOR_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP], [JSON.stringify(integrationResponseObj)]);
						  
var url = URL_BASE+QUEUE_CONNEX_VENDOR_INBOUND_RESPONSE+'/messages';
var body = JSON.stringify(integrationResponseObj);
var HEADERS = {"Authorization":signatures};
 if(CorrelationId==null || CorrelationId=='')
					   CorrelationId=''
                HEADERS['NServiceBus.CorrelationId']=CorrelationId
				HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST')
 nlapiLogExecution('debug', 'responseData', responseData);
					 }
                   	if(context.getRemainingUsage()<=1000)
	{
      nlapiLogExecution('debug', 'usageRemainingin :', usageRemaining);
	nlapiScheduleScript(SPARAM_CONNEX_VENDOR,null)
      break;   
	}		 
					 }
      }
		  }
               