/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var APPF_VVCCP_SFTP_SL_SCRIPT_ID='customscript_appf_vvccp_sftp_send_sl';
var APPF_VVCCP_SFTP_SL_DEPLOY_ID='customdeploy_appf_vvccp_sftp_send_sl';

var CUSTOM_RECORD_SFTP_LOGS = 'customrecord_appf_vvccp_sftp_logs';
var SPARAM_INDEX = 'custscript_sftp_file_index';
var SPARAM_FILE_ID = 'custscript_sftp_file_id';
var FLD_TYPE='custrecord_appf_vvccp_request_type';
var FLD_VVCCP_LINK_CARD='custrecord_appf_vvccp_card_provider_sftp';
var FLD_VVCCP_ERROR='custrecord_appf_vvccp_error_log';

var REQUEST= 3;

define(['N/search', 'N/runtime', 'N/sftp', 'N/format','N/keyControl', 'N/file', 'N/record', 'N/https', 'N/url','N/http', 'N/task'],
    function(search, runtime, sftp,format, keyControl, file, record, https, url,http, task) {
        function execute(context)
        {
            var cardType = context.request.parameters.creditCardType;
            log.debug('cardType : ', cardType);
            var fileID = context.request.parameters.fileID;
            log.debug('fileID : ', fileID);
            try
                {
					var date = new Date();
					var sftpLogRecord = record.create({
       type: CUSTOM_RECORD_SFTP_LOGS,
       isDynamic: true                       
   });
   sftpLogRecord.setValue({
            fieldId: FLD_TYPE,
            value: REQUEST
        });
		var userObj = runtime.getCurrentUser();
var timeZone = userObj.getPreference ({
    name: 'timezone'
});
log.debug('timeZone',timeZone);
		var dateTime = format.format({
        value: date, 
        type: format.Type.DATETIME, 
        timezone: timeZone
    }); //Returns "8/24/2015 8:27:16 pm"
		
		var filetype=''
		if(cardType==CREDIT_CARD_TYPE_AMEX)
		{
			filetype='AMEX'
		}
		else
		{
			filetype='MASTERCARD'
		}
		sftpLogRecord.setValue({
            fieldId: 'name',
            value: filetype+' '+dateTime
        });
		sftpLogRecord.setValue({
            fieldId: FLD_VVCCP_LINK_CARD,
            value: cardType
        });
		//sftpLogRecord.attach({type: 'file',id: fileID});
		
		 var recordId = sftpLogRecord.save({
            enableSourcing: false,
            ignoreMandatoryFields: false
        });
        record.attach({
    record: {
        type: 'file',
        id: fileID
    },
    to: {
        type: CUSTOM_RECORD_SFTP_LOGS,
        id: recordId
    }
});  
var url1= url.resolveScript({scriptId: APPF_VVCCP_SFTP_SL_SCRIPT_ID,deploymentId: APPF_VVCCP_SFTP_SL_DEPLOY_ID,returnExternalUrl: true});		
//url1 +='&sftp='+newRec.id+'istrigger'+'T';      
var fileurl =url1+'&sftp='+recordId+'&fileid='+fileID;
                  log.debug('fileurl : ', fileurl);
                  var suiteletResponse = https.post({
		url: fileurl
	});
                   log.debug('suiteletResponse : ', suiteletResponse);
//var suiteletResponse=http.post({url: fileurl});
			 //log.debug('suiteletResponse : ', suiteletResponse);
                  //log.debug('suiteletResponse : ', suiteletResponse.getCode);
                  
                }
                catch(ep)
                {
                    connection = null;
				}
				
            }
        return {
            onRequest: execute
        };
    });
