/**
 * Script Name : Appf-Helper VVCCP Client Script
 * Script Type : Suitelet
 * 
 * Version    Date            Author           		Remarks
 * 1.00            			  Debendra Panigrahi	This script handles all client side validations of the VVCCP Suitelet
 *
 * Company 	 : Appficiency. 
 */
var FLD_SL_ACTION='custpage_action';
var SUITELET_VVCCP_SCRIPT_ID='customscript_vvccp_suitelet';
var SUITELET_VVCCP_SCRIPT_DEPLOY_ID='customdeploy_vvccp_suitelet';
var SPARAM_VENDOR_BILL_SAVED_SEARCH='custscript_vendor_bill_search';
var SPARAM_VENDOR_CREDIT_SAVED_SEARCH='custscript_vendor_credit_search';
var TITLE_VVCCP_SUITELET='VVCCP Suitelet';
var FLD_GROUP_FILTERS='custpage_filters';
var SL_FLD_VENDOR='custpage_vendor';
var SL_FLD_PUBLISHER='custpage_publisher';
var SL_FLD_MEDIA_SEGMENT='custpage_media_segment';
var SL_FLD_PROJECT='custpage_project';
var SL_FLD_DATE_FROM='custpage_date_from';
var SL_FLD_DATE_TO='custpage_date_to';
var SL_FLD_DUE_DATE_FROM='custpage_due_date_from';
var SL_FLD_DUE_DATE_TO='custpage_due_date_to';
var SL_FLD_PURCHASEORDER='custpage_purchaseorder';
var SL_FLD_IO='custpage_io';
var SL_FLD_SUBSIDIARY='custpage_subsidiary';
var SL_FLD_DISCREPANT='custpage_discrepant';
var SL_FLD_DISCREPANCY_TYPE='custpage_discrepancy_type';
var SL_FLD_READY_FOR_PWP='custpage_ready_for_pwp';
var SL_FLD_TOTAL_VENDOR_BILLS='custpage_total_vendor_bills';
 var FLD_SL_INTREM_MASTER='custpage_intrems_masters';
var SL_FLD_TOTAL_VENDOR_CREDITS='custpage_total_vendor_credits';
var SL_FLD_TOTAL_VENDOR_AUTHORIZATION='custpage_total_vendor_authorization';
var BTN_VENDOR_BILL_MARK_ALL='custpage_vendor_bill_mark_all';
var BTN_VENDOR_BILL_UNMARK_ALL='custpage_vendor_bill_unmark_all'
var BTN_VENDOR_CREDIT_MARK_ALL='custpage_vendor_credit_mark_all';
var BTN_VENDOR_CREDIT_UNMARK_ALL='custpage_vendor_credit_unmark_all';
var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
var COL_SL_VENDOR_BILL_SUBLIST='custpage_vendor_bills';
var COL_SL_VENDOR_CREDIT_SUBLIST='custpage_vendor_credit';
var COL_SL_VENDOR_BILL_MARK='custpage_vendor_bill_checkbox';
var COL_SL_VENDOR_CREDIT_MARK='custpage_vendor_credit_checkbox';
var COL_SL_PAYMENT_AMOUNT='custpage_vendor_bil_payment_amount';
var COL_SL_VENDOR_CREDIT_AMOUNT = 'custpage_credit_amount';

function clientFieldChanged(type, name, linenum)
{
	if( (type == COL_SL_VENDOR_BILL_SUBLIST && (name == COL_SL_VENDOR_BILL_MARK || name == COL_SL_PAYMENT_AMOUNT)) || (type == COL_SL_VENDOR_CREDIT_SUBLIST && (name == COL_SL_VENDOR_CREDIT_MARK || name == COL_SL_VENDOR_CREDIT_AMOUNT))) {
		  var nCount = nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);
		  var vendorBillTotal=0;
		    for (var i=1; nCount > 0 && i<=nCount; i++) {
	        var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i);
              var vendorBillAmt=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
              var amountdue=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT+'_native', i);
			  if (vendorBillAmt != null && vendorBillAmt != '' && amountdue != null && amountdue != '')
			  {
				  
				if(parseFloat(vendorBillAmt) > parseFloat(amountdue))
                {
                  alert('Please enter Payment Amount less than or equal to Amount Due ('+amountdue+').');
				  nlapiSetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i, amountdue);
				   if (iSelected == 'T')
					  vendorBillTotal = parseFloat(vendorBillTotal) + parseFloat(amountdue);
				  
                }
				else
				{
					 if (iSelected == 'T')
					  vendorBillTotal = parseFloat(vendorBillTotal) + parseFloat(vendorBillAmt);
				}
			  }
			
			}
			nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_BILLS,vendorBillTotal.toFixed(2));
			
			var vendorCreditTotal=0;
			var nCount_credit = nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);
			for (var i=1; nCount_credit > 0 && i<=nCount_credit; i++) {
	        var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i);
              var invoiceAmt=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
              var amountdue=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT+'_native', i);
			  if (invoiceAmt != null && invoiceAmt != '' && amountdue != null && amountdue != '')
			  {
                
              if(parseFloat(invoiceAmt) > parseFloat(amountdue))
                {
                  alert('Please enter Credit Amount less than or equal to Amount ('+amountdue+').');
				  nlapiSetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i, amountdue);
				   if (iSelected == 'T'){
					  vendorBillTotal = parseFloat(vendorBillTotal) - parseFloat(amountdue);
                     vendorCreditTotal=parseFloat(vendorCreditTotal)+parseFloat(invoiceAmt);
                   }
                }
				else
				{
					 if (iSelected == 'T'){
					  vendorBillTotal = parseFloat(vendorBillTotal) - parseFloat(invoiceAmt);
                  vendorCreditTotal=parseFloat(vendorCreditTotal)+parseFloat(invoiceAmt);
                }
				}
			  }
			
			}
      		if(vendorCreditTotal < 0)
        	vendorCreditTotal=vendorCreditTotal*-1;
			nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_CREDITS,vendorCreditTotal.toFixed(2));
			
		    nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION,vendorBillTotal.toFixed(2));
	}
}
  	
function vendorcreditmarkAll() {
var creditAmountTotal=0;
   var paymentAmountTotal=0;
		var credCount = nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);

			for (var i=1; i<=credCount; i++) 
			{
				nlapiSetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i, 'T');
				var creditAmount = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
				if(creditAmount == null || creditAmount == '')
					creditAmount = 0;
				creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
			}
			var billCount = nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);

			for (var i=1; i<=billCount; i++) 
			{
				var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i);
				if(iSelected == 'T'){
				var billAmount = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
				if(billAmount == null || billAmount == '')
					billAmount = 0;
				paymentAmountTotal = Number(paymentAmountTotal) + Number(billAmount);
				}
			}
  nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_CREDITS,parseFloat(creditAmountTotal* -1).toFixed(2));
				nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION, Number(paymentAmountTotal).toFixed(2)-Number(creditAmountTotal).toFixed(2));
}
function vendorcreditunmarkAll(){
	var creditAmountTotal=0;
   var paymentAmountTotal=0;
	var credCount = nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);

			for (var i=1; i<=credCount; i++) 
			{
				nlapiSetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i, 'F');	
			}
			nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_CREDITS,'');
	var paymentAmountTotal=0;
var billCount = nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);

			for (var i=1; i<=billCount; i++) {
				var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i);
				if(iSelected == 'T'){
				var paymentAmount = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
				if(paymentAmount == null || paymentAmount == '')
					paymentAmount = 0;
				paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
				}

			}
		nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION, Number(paymentAmountTotal)-0);	

}

function vendormarkAll() {
var creditAmountTotal=0;
   var paymentAmountTotal=0;
		var billCount = nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);
			for (var i=1; i<=billCount; i++) 
			{
				nlapiSetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i, 'T');	
				var paymentAmount = nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
				if(paymentAmount == null || paymentAmount == '')
					paymentAmount = 0;
				paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
			}
  nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_BILLS,parseFloat(paymentAmountTotal).toFixed(2));
			var creditAmountTotal=0;

			var credCount = nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);

			for (var i=1; i<=credCount; i++) {
				var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i);
				if(iSelected == 'T'){
				var creditAmount = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
				if(creditAmount == null || creditAmount == '')
					creditAmount = 0;
				creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
				}

			}
			nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION, Number(paymentAmountTotal).toFixed(2)-Number(creditAmountTotal).toFixed(2));
				
}
function vendorunmarkAll(){
	var creditAmountTotal=0;
   var paymentAmountTotal=0;
	var billCount = nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);

			for (var i=1; i<=billCount; i++) 
			{
				nlapiSetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i, 'F');
				
			}
  nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_BILLS,'');
			var creditAmountTotal=0;
			var credCount = nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);
			for (var i=1; i<=credCount; i++) {
				var iSelected = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i);
				if(iSelected == 'T'){
				var creditAmount = nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
				if(creditAmount == null || creditAmount == '')
					creditAmount = 0;
				creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
				}

			}
			nlapiSetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION, 0-Number(creditAmountTotal));
	

}





function applyFilters(name) 
{
	var vendor = nlapiGetFieldValue(SL_FLD_VENDOR);
	var publisher = nlapiGetFieldValue(SL_FLD_PUBLISHER);
	var mediaSegment = nlapiGetFieldValue(SL_FLD_MEDIA_SEGMENT);
	var project = nlapiGetFieldValue(SL_FLD_PROJECT);
	var dateFrom = nlapiGetFieldValue(SL_FLD_DATE_FROM);
	var dateTo = nlapiGetFieldValue(SL_FLD_DATE_TO);
	var dueDateFrom = nlapiGetFieldValue(SL_FLD_DUE_DATE_FROM);
	var dueDateTo=nlapiGetFieldValue(SL_FLD_DUE_DATE_TO);
	var purchaseOrder = nlapiGetFieldValue(SL_FLD_PURCHASEORDER);
	var io = nlapiGetFieldValue(SL_FLD_IO);
	var subsidiary=nlapiGetFieldValue(SL_FLD_SUBSIDIARY);
	var discrepant=nlapiGetFieldValue(SL_FLD_DISCREPANT);
	var discrepancyType =nlapiGetFieldValue(SL_FLD_DISCREPANCY_TYPE);
	var readyForPwp  =nlapiGetFieldValue(SL_FLD_READY_FOR_PWP);
  var intremMater  =nlapiGetFieldValue(FLD_SL_INTREM_MASTER);
  	var fieldAction=nlapiGetFieldValue(FLD_SL_ACTION);
  if(fieldAction == null || fieldAction == '')
    fieldAction ='filter'
	var url=nlapiResolveURL('SUITELET',SUITELET_VVCCP_SCRIPT_ID,SUITELET_VVCCP_SCRIPT_DEPLOY_ID);
  url+='&vendor='+vendor+'&publisher='+publisher+'&mediaSegment='+mediaSegment+'&project='+project+'&dateFrom='+dateFrom+'&dateTo='+dateTo+'&dueDateFrom='+dueDateFrom+'&dueDateTo='+dueDateTo+'&purchaseOrder='+purchaseOrder+'&io='+io+'&subsidiary='+subsidiary+'&discrepant='+discrepant+'&discrepancyType='+discrepancyType+'&readyForPwp='+readyForPwp+'&isApplyFilterClicked ='+true+'&fieldAction='+fieldAction+'&intremMater='+intremMater;
  window.open(url,'_self');
  
  
}
function onsave(){
	 var sAction = nlapiGetFieldValue(FLD_SL_ACTION);
	    if (sAction == null || sAction == '') {
	    	nlapiSetFieldValue(FLD_SL_ACTION,'submit');
	    }
  		
	    var lineCount=nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);
	    var count=0;
	    for(var i=1;i<=lineCount;i++){
	    	var selected=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i);
	    	if(selected == 'T'){
	    		count++;
	    	}
         
	    }
  
	    if(count >0) {
			var totalamount = nlapiGetFieldValue(SL_FLD_TOTAL_VENDOR_AUTHORIZATION);
			if (totalamount <= 0)
			{
				alert('Applied credit amount should be less than applied bill amount');
				return false;
			}
			else
			{
				
				var appliedobj = {};
				var vendoridobj = {};
				
				 var lineCount=nlapiGetLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);
	    for(var i=1;i<=lineCount;i++){
	    	var selected=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i);
					var vendorBillAmount=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
					var vendor=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield4', i);
															var vendorname=nlapiGetLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield10', i);


	    	if(selected == 'T'){
				if(!appliedobj.hasOwnProperty(vendor))
				{
	    	appliedobj[vendor] = (vendorBillAmount!=null && vendorBillAmount != '')?parseFloat(vendorBillAmount):0;
			vendoridobj[vendor] = vendorname;
				}
		    else
			{
		    appliedobj[vendor] = (vendorBillAmount!=null && vendorBillAmount != '')?(parseFloat(vendorBillAmount)+parseFloat(appliedobj[vendor])):appliedobj[vendor];
			}

			}
         
	    }
		
		
		
		 var lineCountCr=nlapiGetLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);
	    for(var i=1;i<=lineCountCr;i++){
	    	var selected=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i);
					var vendorCreditAmount=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
					var vendor=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield3', i);
										var vendorname=nlapiGetLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield6', i);


	    	if(selected == 'T'){
				if(!appliedobj.hasOwnProperty(vendor))
				{
	    	appliedobj[vendor] = (vendorCreditAmount!=null && vendorCreditAmount != '')?(parseFloat(vendorCreditAmount)*-1):0;
			vendoridobj[vendor] = vendorname;
				}
		    else
			{
			appliedobj[vendor] = (vendorCreditAmount!=null && vendorCreditAmount != '')?(parseFloat(appliedobj[vendor])-parseFloat(vendorCreditAmount)):appliedobj[vendor];
			}

			}
         
	    }
		//alert(JSON.stringify(appliedobj));
		var hasVendorDiscrepancy = false;
		var vendors_error = 'Vendor bill amount should be > 0 for the following Vendors : \n';
		var vendors_list_error = [];
		for (var prop in appliedobj)
		{
			if (parseFloat(appliedobj[prop]) <= 0)
			{
				hasVendorDiscrepancy=true;
				vendors_list_error.push(vendoridobj[prop]+'\n');
				
			}
			
		}
		
		if (hasVendorDiscrepancy)
		{
			
			alert(vendors_error+vendors_list_error);
			false;
		}
		else
		{
		
		
		
										
																
				
	var submitConfirmation= confirm('Selected transactions will be processed for VVCCP Execution, Click OK to proceed.');
    if (submitConfirmation== true)
    {
		return true;
    }
   else
   {
       return false;
   }
	    }
		}
		}
	    else{
	    	alert('Please select atleast one Bill line');
	    	return false;
	    }
		

}







