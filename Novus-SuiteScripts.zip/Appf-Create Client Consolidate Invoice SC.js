/*
* Script Name : Appf-Create Client Consolidate Invoice SC
* Script Type : Scheduled
* Description :
* Company     : Appficiency Inc.
*/

var CUSTOM_RECORD_CI_EXECUTION_LOG = 'customrecord_appf_ci_execution_log';
var FLD_CI_EXEC_LOG_FILE = 'custrecord_appf_ci_file_to_process';
var FLD_CI_EXEC_LOG_TOT_LINES_TO_PROCESS = 'custrecord_appf_ci_total_lines_process';
var FLD_CI_EXEC_LOG_REMAIN_LINES_TO_PROCESS = 'custrecord_appf_ci_remain_lines_process';
var FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED = 'custrecord_appf_ci_lines_processed';
var FLD_CI_EXEC_LOG_PERCENT_PROCESSED = 'custrecord_appf_ci_percent_processed';
var FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE = 'custrecord_appf_ci_total_ci_to_create';
var FLD_CI_EXEC_LOG_POST_EXEC_CONSOL_FILE = 'custrecord_appf_ci_post_exec_file';
var FLD_CI_EXEC_LOG_PROCESSING_CONSOL_STATUS_FILE = 'custrecord_appf_ci_process_status_file';
var FLD_CI_EXEC_LOG_ERROR_LOG = 'custrecord_appf_ci_error_log';
var FLD_CI_EXEC_LOG_ERROR_FILE = 'custrecord_appf_ci_error_file';
var FLD_CI_EXEC_LOG_CREATED_BY = 'custrecord_appf_ci_log_created_by';
var FLD_CI_EXEC_LOG_TOT_CI_CREATED = 'custrecord_appf_ci_total_ci_created';
var FLD_CI_EXEC_LOG_BATCH_OPTION_1 = 'custrecord_appf_ci_exec_batch_opt_1';
var FLD_CI_EXEC_LOG_BATCH_OPTION_2 = 'custrecord_appf_ci_exec_batch_opt_2';
var FLD_CI_EXEC_LOG_BATCH_OPTION_3 = 'custrecord_appf_ci_exec_batch_opt_3';
var FLD_CI_EXEC_LOG_BATCH_OPTION_4 = 'custrecord_appf_ci_exec_batch_opt_4';
var FLD_CI_EXEC_LOG_CI_REC_LINKS = 'custrecord_appf_ci_record_links';
var FLD_CI_EXEC_LOG_CI_BATCH_STATUS = 'custrecord_appf_ci_exec_batch_status';
var FLD_CI_EXEC_LOG_INV_BACKLINK_STATUS_FILE = 'custrecord_appf_inv_backlink_status_file';
var FLD_CI_EXEC_LOG_CM_BACKLINK_STATUS_FILE = 'custrecord_cm_backlinking_status_file';

var CUSTOM_RECORD_CI = 'customrecord_appf_ci_record';
var FLD_CI_CLIENT = 'custrecord_appf_ci_client';
var FLD_CI_CONTRACT = 'custrecord_appf_ci_contract';
var FLD_CI_INVOICES = 'custrecord_appf_ci_invoices';
var FLD_CI_NO_OF_INVOICES = 'custrecord_appf_ci_number_invoices';
var FLD_CI_AMOUNT = 'custrecord_appf_ci_amount';
var FLD_CI_DISCOUNT = 'custrecord_appf_ci_discount';
var FLD_CI_TAX = 'custrecord_appf_ci_tax';
var FLD_CI_SUBTOTAL = 'custrecord_appf_ci_subtotal';
var FLD_CI_CURRENCY = 'custrecord_appf_ci_currency';
var FLD_CI_SUBSIDIARY = 'custrecord_appf_ci_subsidiary';
var FLD_CI_CREATED_BY = 'custrecord_appf_ci_created_by';
var FLD_CI_DATE_CREATED = 'custrecord_appf_ci_date_created';
var FLD_CI_DATE = 'custrecord_appf_ci_date';
var FLD_CI_TERMS = 'custrecord_appf_ci_terms';
var FLD_CI_DUE_DATE = 'custrecord_appf_ci_due_date';
var FLD_CI_RECORD = 'custrecord_ci_record';

var FLD_CI_BATCH_OPTION_1 = 'custrecord_appf_ci_batchoption_1';
var FLD_CI_BATCH_OPTION_2 = 'custrecord_appf_ci_batchoption_2';
var FLD_CI_BATCH_OPTION_3 = 'custrecord_appf_ci_batchoption_3';
var FLD_CI_BATCH_OPTION_4 = 'custrecord_appf_ci_batchoption_4';

var FLD_CI_BATCH_OPTION_1_VALUE = 'custrecord_appf_batch_option1_value';
var FLD_CI_BATCH_OPTION_2_VALUE = 'custrecord_appf_batch_option2_value';
var FLD_CI_BATCH_OPTION_3_VALUE = 'custrecord_appf_batch_option3_value';
var FLD_CI_BATCH_OPTION_4_VALUE = 'custrecord_appf_batch_option4_value';

var FLD_CI_BATCH_STATUS_NOT_STARTED = '1';
var FLD_CI_BATCH_STATUS_UNDER_PROCESSING = '2';
var FLD_CI_BATCH_STATUS_COMPLETED = '3';
var FLD_CI_BATCH_STATUS_FAILED = '4';

var FLD_COL_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';

var SPARAM_CI_EXEC_LOG_ID = 'custscript_appf_ci_execution_log_id';
var SPARAM_CI_LINE_INDEX = 'custscript_aappf_line_index';
var SPARAM_SEARCH_COLS_LENGTH = 'custscript_appf_search_columns_length';
var SPARAM_CI_EXEC_FOLDER_ID = 'custscript_appf_ci_exec_fold_id';
var SPARAM_BATCH_FILE_ID = 'custscript_appf_ci_batch_file_id';

var IMPORT_CSV_SYNC_INV_CI_RECORD = 'custimport_appf_sync_inv_ci_record';
var IMPORT_CSV_SYNC_CM_CI_RECORD = 'custimport_appf_sync_cm_ci_record';

function creteCIScheduled(type){
	var isRescheduled = false;
	var context = nlapiGetContext();
	var ciExecLogId = context.getSetting('SCRIPT', SPARAM_CI_EXEC_LOG_ID);
		var ciExecFolderId = context.getSetting('SCRIPT', SPARAM_CI_EXEC_FOLDER_ID);

				var ciBatchFileId = context.getSetting('SCRIPT', SPARAM_BATCH_FILE_ID);
	var searchColsLength = context.getSetting('SCRIPT', SPARAM_SEARCH_COLS_LENGTH);
	var index = context.getSetting('SCRIPT', SPARAM_CI_LINE_INDEX);
  nlapiLogExecution('debug', 'ciExecLogId::ciExecFolderId::ciBatchFileId::searchColsLength::index', ciExecLogId+'::'+ciExecFolderId+'::'+ciBatchFileId+'::'+searchColsLength+'::'+index);
	if(index == null || index == '')
		index = 0;
	var uniqueBatchGroupObj = '';
	if(ciExecLogId != null && ciExecLogId != ''){

		var ciExecLogRec = nlapiLoadRecord(CUSTOM_RECORD_CI_EXECUTION_LOG, ciExecLogId);

		var totCIRecordsCreated = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_TOT_CI_CREATED);
		if (totCIRecordsCreated == null || totCIRecordsCreated == '')
			totCIRecordsCreated = 0;

				totCIRecordsCreated = parseInt(totCIRecordsCreated);


			var totRecordsCompleted = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED);
		if (totRecordsCompleted == null || totRecordsCompleted == '')
			totRecordsCompleted = 0;

		var existingCIRecordLinks = ciExecLogRec.getFieldValues(FLD_CI_EXEC_LOG_CI_REC_LINKS);



		totRecordsCompleted = parseInt(totRecordsCompleted);

		var batchOpt1 = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_1);
		var batchOpt2 = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_2);
		var batchOpt3 = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_3);
		var batchOpt4 = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_4);

		var errorLog = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_ERROR_LOG);
		if(errorLog != null && errorLog != '' && errorLog != 'undefined' && errorLog != undefined)
			errorLog = errorLog + '\n';
		else
			errorLog = '';

		var totalBatchOpts = 0;
		if(batchOpt1 != null && batchOpt1 != '')
			totalBatchOpts++;
		if(batchOpt2 != null && batchOpt2 != '')
			totalBatchOpts++;
		if(batchOpt3 != null && batchOpt3 != '')
			totalBatchOpts++
		if(batchOpt4 != null && batchOpt4 != '')
			totalBatchOpts++

		var fileId = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_FILE);

		if (ciBatchFileId == null || ciBatchFileId == '')
         {
			 var fileData = nlapiLoadFile(fileId).getValue();
		if(fileData != null && fileData != ''){
			uniqueBatchGroupObj = {};
			var selectedLines = fileData.split('\n');

			var hasCreditMemos = false;
			var hasInvoices = false;
			var hasCreditMemos2 = false;
			var hasInvoices2 = false;
			var hasCreditMemos3 = false;
			var hasInvoices3 = false;


			for(var i=1; i<(selectedLines.length-1); i++){
				var line = selectedLines[i].split(',');
				var transRecId = line[0];
				var transRecType = line[7];
				var client = line[2];
				var contract = line[4];
				var amt = line[13];
				var lineId = line[16];
				var taxAmt = line[19];
				var discountAmt = line[20];
				if(taxAmt == null || taxAmt == '' || taxAmt == 'null')
					taxAmt = 0;
				if(discountAmt == null || discountAmt == '' || discountAmt == 'null')
					discountAmt = 0;
				var batchGroup = '';
				var ssCols = searchColsLength-1;
				for(var b=0; b<totalBatchOpts; b++){
					ssCols = parseInt(ssCols)+2;
					batchGroup = batchGroup+line[parseInt(ssCols)]+'||';
				}
				if(!uniqueBatchGroupObj.hasOwnProperty(batchGroup)){
					uniqueBatchGroupObj[batchGroup] = {};
					uniqueBatchGroupObj[batchGroup].client = client;
					uniqueBatchGroupObj[batchGroup].contract = contract;
					uniqueBatchGroupObj[batchGroup].amt = amt;
					uniqueBatchGroupObj[batchGroup].transRecIds = [];
					var obj = {};
					obj.recType = transRecType;
					obj.recId = transRecId;
					obj.invLineId = lineId;
					obj.taxAmt = taxAmt;
                  	obj.counter = i;
					obj.discountAmt = discountAmt;
					uniqueBatchGroupObj[batchGroup].transRecIds.push(obj);
				}
				else{
					uniqueBatchGroupObj[batchGroup].amt = parseFloat(uniqueBatchGroupObj[batchGroup].amt)+parseFloat(amt);
					var obj = {};
					obj.recType = transRecType;
					obj.recId = transRecId;
					obj.invLineId = lineId;
					obj.taxAmt = taxAmt;
                  	obj.counter = i;
					obj.discountAmt = discountAmt;
					uniqueBatchGroupObj[batchGroup].transRecIds.push(obj);
				}

			}
		}
}
		else
		{
			var batchFileData = nlapiLoadFile(ciBatchFileId).getValue();
			uniqueBatchGroupObj = JSON.parse(batchFileData);

		}

			var ciRecordLinks = [];
			if (existingCIRecordLinks != null && existingCIRecordLinks != '' && existingCIRecordLinks.length > 0)
				ciRecordLinks = ciRecordLinks.concat(existingCIRecordLinks);

			var importInvtoLinkCIExeLog = '';
			importInvtoLinkCIExeLog += 'Invoice ID, CI Batch Status, Invoice Line ID, CI Status, CI Log, CI Record\n';

			var importInvtoLinkCIExeLog2 = '';
			importInvtoLinkCIExeLog2 += 'Invoice ID, CI Batch Status, Invoice Line ID, CI Status, CI Log, CI Record\n';

			var importInvtoLinkCIExeLog3 = '';
			importInvtoLinkCIExeLog3 += 'Invoice ID, CI Batch Status, Invoice Line ID, CI Status, CI Log, CI Record\n';


			var importCMtoLinkCIExeLog = '';
			importCMtoLinkCIExeLog += 'CM ID, CI Batch Status, CM Line ID, CI Status, CI Log, CI Record\n';

			var importCMtoLinkCIExeLog2 = '';
			importCMtoLinkCIExeLog2 += 'CM ID, CI Batch Status, CM Line ID, CI Status, CI Log, CI Record\n';

			var importCMtoLinkCIExeLog3 = '';
			importCMtoLinkCIExeLog3 += 'CM ID, CI Batch Status, CM Line ID, CI Status, CI Log, CI Record\n';









			var uniqueBatchGroupArr = [];



			for(var prop in uniqueBatchGroupObj){

				var innerobj = {};
				innerobj.propname = prop;

				var obj = uniqueBatchGroupObj[prop];
				innerobj.propvalues = obj;

				uniqueBatchGroupArr.push(innerobj);

			}
      			nlapiLogExecution('debug', 'uniqueBatchGroupObj', JSON.stringify(uniqueBatchGroupArr));
			for(var p=index; p<uniqueBatchGroupArr.length; p++){

				var prop = uniqueBatchGroupArr[p].propname;

				var obj = uniqueBatchGroupArr[p].propvalues;

				var batchValuesList = prop.split('||');

				var totRecords =  obj.transRecIds;
				var recIds = [];
				var taxTotal = 0;
				var discountTotal = 0;
				if(totRecords != null && totRecords != ''){
					for(var t=0; t<totRecords.length; t++){
						var  totRecObj = totRecords[t];
						recIds.push(totRecObj.recId);
						taxTotal = parseFloat(taxTotal) + parseFloat(totRecObj.taxAmt);
						discountTotal = parseFloat(discountTotal) + parseFloat(totRecObj.discountAmt);
					}
				}
				if(recIds != null && recIds != '')
						recIds = eliminateDuplicates(recIds);
				var newCIRecord = '';
				try{
					var ciRecord = nlapiCreateRecord(CUSTOM_RECORD_CI);
					ciRecord.setFieldValue(FLD_CI_CLIENT, obj.client);
					ciRecord.setFieldValue(FLD_CI_CONTRACT, obj.contract);
					if(recIds != null && recIds != ''){
						//recIds = eliminateDuplicates(recIds);
						ciRecord.setFieldValues(FLD_CI_INVOICES, recIds);
						ciRecord.setFieldValue(FLD_CI_NO_OF_INVOICES, recIds.length);
					}
					var subtotalValue = parseFloat(obj.amt) - parseFloat(taxTotal);
					ciRecord.setFieldValue(FLD_CI_SUBTOTAL, subtotalValue);
					ciRecord.setFieldValue(FLD_CI_AMOUNT, obj.amt);
					ciRecord.setFieldValue(FLD_CI_TAX, taxTotal);
					ciRecord.setFieldValue(FLD_CI_DISCOUNT, discountTotal);
					newCIRecord = nlapiSubmitRecord(ciRecord, true, true);
					nlapiLogExecution('debug', 'newCIRecord', newCIRecord);
					if(newCIRecord != null && newCIRecord != ''){
						ciRecord = nlapiLoadRecord(CUSTOM_RECORD_CI,newCIRecord);

						var ciDate = ciRecord.getFieldValue(FLD_CI_DATE);
						var ciTerms = ciRecord.getFieldValue(FLD_CI_TERMS);
						var dueDate = ciDate;
						if(ciDate != null && ciDate != '' && ciTerms != null && ciTerms != ''){
								var termdays = nlapiLookupField('term', ciTerms, 'daysuntilnetdue');
								if(termdays != null && termdays != ''){
								dueDate = nlapiAddDays(nlapiStringToDate(ciDate), Number(termdays));
								dueDate = nlapiDateToString(dueDate);
								}

						}
						ciRecord.setFieldValue(FLD_CI_DUE_DATE, dueDate);
						ciRecord.setFieldValue(FLD_CI_RECORD, newCIRecord);
						var b = 0;
						var batchoption1 = ciRecord.getFieldValue(FLD_CI_BATCH_OPTION_1)
						if (batchoption1 != null && batchoption1 != '')
						{
							ciRecord.setFieldValue(FLD_CI_BATCH_OPTION_1_VALUE, batchValuesList[b]);
							b++;
						}
						var batchoption2 = ciRecord.getFieldValue(FLD_CI_BATCH_OPTION_2)
						if (batchoption2 != null && batchoption2 != '')
						{
							ciRecord.setFieldValue(FLD_CI_BATCH_OPTION_2_VALUE, batchValuesList[b]);
							b++;
						}
                        var batchoption3 = ciRecord.getFieldValue(FLD_CI_BATCH_OPTION_3)
						if (batchoption3 != null && batchoption3 != '')
						{
							ciRecord.setFieldValue(FLD_CI_BATCH_OPTION_3_VALUE, batchValuesList[b]);
							b++;
						}
						var batchoption4 = ciRecord.getFieldValue(FLD_CI_BATCH_OPTION_4)
						if (batchoption4 != null && batchoption4 != '')
						{
							ciRecord.setFieldValue(FLD_CI_BATCH_OPTION_4_VALUE, batchValuesList[b]);
							b++;
						}
                        nlapiSubmitRecord(ciRecord);

						totCIRecordsCreated++;
						ciRecordLinks.push(newCIRecord);
										totRecordsCompleted = parseInt(totRecordsCompleted) + parseInt(recIds.length);

									//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG, ciExecLogId, FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED, totRecordsCompleted);

					}
				}catch(e){
					totRecordsCompleted = parseInt(totRecordsCompleted) + parseInt(recIds.length);
					FLD_CI_BATCH_STATUS_COMPLETED = FLD_CI_BATCH_STATUS_FAILED;
					if ( e instanceof nlobjError ){
						errorLog = errorLog + 'System error while creating CI Record : ' + e.getDetails();
						nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
					}
					else{
						errorLog = errorLog + 'Unexpected error while creating CI Record : ' + e.toString();
						nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
					}
				}
				nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG, ciExecLogId, [FLD_CI_EXEC_LOG_TOT_LINES_PROCESSED,FLD_CI_EXEC_LOG_TOT_CI_CREATED], [totRecordsCompleted,totCIRecordsCreated]);

				if(totRecords != null && totRecords != ''){
					for(var t=0; t<totRecords.length; t++){
						var obj = totRecords[t];
						var recType = obj.recType;
						if(recType == 'CustInvc'){
				             var nDigit = parseInt(obj.recId)%10;
				             if(nDigit == 0 || nDigit == 1 || nDigit == 2){
				            	 //nlapiLogExecution('debug', 'nDigit 1', nDigit);
				            	 importInvtoLinkCIExeLog += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';
				             }else if(nDigit == 3 || nDigit == 4 || nDigit == 5){
				            	//nlapiLogExecution('debug', 'nDigit 2', nDigit);
				            	 importInvtoLinkCIExeLog2 += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';
				             }else if(nDigit == 6 || nDigit == 7 || nDigit == 8 || nDigit == 9 ){
				            	 //nlapiLogExecution('debug', 'nDigit 3', nDigit);
				            	 importInvtoLinkCIExeLog3 += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';
				             }
						}


						if(recType == 'CustCred'){
				             var nDigit = parseInt(obj.recId)%10;
				             if(nDigit == 0 || nDigit == 1 || nDigit == 2){
				            	importCMtoLinkCIExeLog += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';
				             }else if(nDigit == 3 || nDigit == 4 || nDigit == 5){
				            	importCMtoLinkCIExeLog2 += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';
				             }else if(nDigit == 6 || nDigit == 7 || nDigit == 8 || nDigit == 9 ){
				            	importCMtoLinkCIExeLog3 += obj.recId + ',' + FLD_CI_BATCH_STATUS_NOT_STARTED + ',' + obj.invLineId + ',' + FLD_CI_BATCH_STATUS_COMPLETED + ',' +ciExecLogId + ',' + newCIRecord + '\n';

				             }
						}

					}
				}

					if(importInvtoLinkCIExeLog != null && importInvtoLinkCIExeLog != ''){
						var importInvCIExecSync = nlapiCreateCSVImport();
						importInvCIExecSync.setMapping(IMPORT_CSV_SYNC_INV_CI_RECORD);
						importInvCIExecSync.setPrimaryFile(importInvtoLinkCIExeLog);
						importInvCIExecSync.setQueue(3);
						var processingJOBID = nlapiSubmitCSVImport(importInvCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}

					if(importInvtoLinkCIExeLog2 != null && importInvtoLinkCIExeLog2 != ''){
						var importInvCIExecSync = nlapiCreateCSVImport();
						importInvCIExecSync.setMapping(IMPORT_CSV_SYNC_INV_CI_RECORD);
						importInvCIExecSync.setPrimaryFile(importInvtoLinkCIExeLog2);
						importInvCIExecSync.setQueue(4);
						var processingJOBID = nlapiSubmitCSVImport(importInvCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}

					if(importInvtoLinkCIExeLog3 != null && importInvtoLinkCIExeLog3 != ''){
						var importInvCIExecSync = nlapiCreateCSVImport();
						importInvCIExecSync.setMapping(IMPORT_CSV_SYNC_INV_CI_RECORD);
						importInvCIExecSync.setPrimaryFile(importInvtoLinkCIExeLog3);
						importInvCIExecSync.setQueue(5);
						var processingJOBID = nlapiSubmitCSVImport(importInvCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}

					if(importCMtoLinkCIExeLog != null && importCMtoLinkCIExeLog != ''){
						var importCMCIExecSync = nlapiCreateCSVImport();
						importCMCIExecSync.setMapping(IMPORT_CSV_SYNC_CM_CI_RECORD);
						importCMCIExecSync.setPrimaryFile(importCMtoLinkCIExeLog);
						importCMCIExecSync.setQueue(3);
						var processingJOBID = nlapiSubmitCSVImport(importCMCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}

					if(importCMtoLinkCIExeLog2 != null && importCMtoLinkCIExeLog2 != ''){
						var importCMCIExecSync = nlapiCreateCSVImport();
						importCMCIExecSync.setMapping(IMPORT_CSV_SYNC_CM_CI_RECORD);
						importCMCIExecSync.setPrimaryFile(importCMtoLinkCIExeLog2);
						importCMCIExecSync.setQueue(4);
						var processingJOBID = nlapiSubmitCSVImport(importCMCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}

					if(importCMtoLinkCIExeLog3 != null && importCMtoLinkCIExeLog3 != ''){
						var importCMCIExecSync = nlapiCreateCSVImport();
						importCMCIExecSync.setMapping(IMPORT_CSV_SYNC_CM_CI_RECORD);
						importCMCIExecSync.setPrimaryFile(importCMtoLinkCIExeLog3);
						importCMCIExecSync.setQueue(5);
						var processingJOBID = nlapiSubmitCSVImport(importCMCIExecSync);
						//nlapiSubmitField(CUSTOM_RECORD_CI_EXECUTION_LOG,newCIExecLogRec,[FLD_CONSOLIDATION_PROCESSING_STATUS_FILE],['/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID]);
					}


					nlapiLogExecution( 'DEBUG', 'usage:P::uniqueBatchGroupArrLen', context.getRemainingUsage()+'::'+p+'::'+ uniqueBatchGroupArr.length);
					if (context.getRemainingUsage() <= 1500 && (parseInt(p)+1) < uniqueBatchGroupArr.length)
							{
								var uniqueBatchGroupObjForFile = JSON.stringify(uniqueBatchGroupObj);
			var uniqueBatchGroupObjForFileObj = nlapiCreateFile('CI_Batch_'+new Date().getTime()+'.txt', 'PLAINTEXT', uniqueBatchGroupObjForFile);
			uniqueBatchGroupObjForFileObj.setFolder(ciExecFolderId);
			var uniqueBatchGroupObjForFileID = nlapiSubmitFile(uniqueBatchGroupObjForFileObj);



								var params = {};
								params[SPARAM_CI_LINE_INDEX]=parseInt(p)+1;
								params[SPARAM_CI_EXEC_LOG_ID] = ciExecLogId;
								params[SPARAM_CI_EXEC_FOLDER_ID] = ciExecFolderId;
								params[SPARAM_SEARCH_COLS_LENGTH] = searchColsLength;
								params[SPARAM_BATCH_FILE_ID] = uniqueBatchGroupObjForFileID;
								nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
								isRescheduled = true;
								break;

							}
			}
      nlapiLogExecution( 'DEBUG', 'ciRecordLinks::isRescheduled', ciRecordLinks+'::'+isRescheduled);
	  var ciExecLogRec = nlapiLoadRecord(CUSTOM_RECORD_CI_EXECUTION_LOG, ciExecLogId);
			ciExecLogRec.setFieldValues(FLD_CI_EXEC_LOG_CI_REC_LINKS, ciRecordLinks);

			if (!isRescheduled)
			{

var totCIRecordsCreated = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_TOT_CI_CREATED);
			//ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_TOT_CI_CREATED, totCIRecordsCreated);
			var expectedCIstoCreate = ciExecLogRec.getFieldValue(FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE);
			if (expectedCIstoCreate != null && expectedCIstoCreate != '')
			{
				if (parseInt(totCIRecordsCreated) == parseInt(expectedCIstoCreate))
				{
								ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CI_BATCH_STATUS, '2');

				}
				else
				{
													ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CI_BATCH_STATUS, '3');

				}
			}

			ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_ERROR_LOG, errorLog);
			//ciExecLogRec.setFieldValues(FLD_CI_EXEC_LOG_CI_REC_LINKS, ciRecordLinks);
			//nlapiSubmitRecord(ciExecLogRec, true, true);
			}
			nlapiSubmitRecord(ciExecLogRec, true, true);
		}


}


function eliminateDuplicates(arr)
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}
