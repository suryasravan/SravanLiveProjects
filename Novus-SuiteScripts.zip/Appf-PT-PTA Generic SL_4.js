/*
* Script Name : Appf-PT-PTA Generic SL
* Script Type : Suitelet
* Description : This generic suitelet acts as UE trigger on a target record type from another UE script
* Company : Appficiency Inc.
*/


function suiteletPTPTA(request, response)
{
try{
var genericRecIds = request.getParameter('genetricrecid');
var genericRecType = request.getParameter('genetricrectype');
  var isbackend = request.getParameter('isbackend');
  var isdelete = request.getParameter('isdelete');
if(genericRecIds != null && genericRecIds != '' && genericRecType != null && genericRecType != ''){
nlapiLogExecution('DEBUG', 'genericRecId,genericRecType', genericRecIds+','+genericRecType);
  var gerecRecIDList = genericRecIds.split(',');
  for (var g = 0; g < gerecRecIDList.length; g++)
    {
       if (isdelete == 'T')
        {
      nlapiDeleteRecord(genericRecType, gerecRecIDList[g]);
        }
      else
        {
var genericRec = nlapiLoadRecord(genericRecType, gerecRecIDList[g]);
nlapiSubmitRecord(genericRec,true,true);
        }
    }
}
  if (isbackend != 'T')
    {
      var recType = request.getParameter('recType');
	var recId = request.getParameter('recId');
      response.sendRedirect('RECORD', recType, recId);
    }
  else
    {
     
      response.write('success');
    }
}catch(e){
if ( e instanceof nlobjError )
nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
else
nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
}
}