/*
* Script Name : Appf-Update Bill PO Status SC
* Script Type : Schedule Scipt
* Description : 
* Company   :	Appficiency Inc.
*/
var FLD_BILL_PO_LINE_SL_STATUS = 'custbody_appf_bill_po_line_status';
var BILL_PO_LINE_SL_STATUS_PROCESSED = '2';
var BILL_PO_LINE_SL_STATUS_READY_FOR_PROCESSING = '3';

var IMPORT_CSV_INITIATE_BILL_PO_LINES = 'custimport_initiate_bill_po_lines';
var IMPORT_CSV_UNCHECK_BILL_PO_LINES = 'custimport_appf_uncheck_bill_po_lines';
var IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS = 'custimport_appf_po_status_bill_po_line';

var SPARAM_UNIQUE_VENDOR_OBJ = 'custscript_appf_unique_vend_obj_data_3';
var SPARAM_BILL_PO_EXEC_ID = 'custscript_update_bill_po_id';


function updateBillPOStatusSC(type){
	var context = nlapiGetContext();
		var uniqueVendorsObj=context.getSetting('SCRIPT', SPARAM_UNIQUE_VENDOR_OBJ);
				var billPOLogID=context.getSetting('SCRIPT', SPARAM_BILL_PO_EXEC_ID);


	if(uniqueVendorsObj != null && uniqueVendorsObj != ''){
					nlapiLogExecution('debug', 'uniqueVendorsObj', uniqueVendorsObj);

		uniqueVendorsObj = JSON.parse(uniqueVendorsObj);
		var selectedPOs = [];
		var errorLog=''
		var totalVBsCreated=1
		for(var vend in uniqueVendorsObj){
					try{
					var poIds = uniqueVendorsObj[vend].poIds;
					poIds = eliminateDuplicates(poIds);
					for(var p=0; p< poIds.length; p++){
						selectedPOs.push(poIds[p]);
					}
						totalVBsCreated++;
					}catch(e){
							if ( e instanceof nlobjError ){
								nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
								errorLog += 'system error while creating VB for Vendor ID '+vend+' : ' + e.getDetails();
							}
							else{
								nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
								errorLog += 'unexpected error while creating VB for Vendor ID '+vend+' : ' + e.toString();
							}
					}
					
		}
		}
		if(selectedPOs!=null && selectedPOs!='')
		{
		selectedPOs = eliminateDuplicates(selectedPOs);
			nlapiLogExecution('debug', 'selectedPOs', JSON.stringify(selectedPOs));
			var poStatusFileContent = 'PO ID,SL Status,Bill PO Exec ID\n';
			var poStatusFileContent2 = 'PO ID,SL Status,Bill PO Exec ID\n';
			var poStatusFileContent3 = 'PO ID,SL Status,Bill PO Exec ID\n';
			 var hasPo = false;
			var hasPo2 = false;
			var hasPo3 = false;
			
			var poSearchForStatusFils = [];
			poSearchForStatusFils.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
			poSearchForStatusFils.push(new nlobjSearchFilter('type', null, 'anyof', 'PurchOrd'));
						poSearchForStatusFils.push(new nlobjSearchFilter('internalid', null, 'anyof', selectedPOs));

			var poSearchForStatus = nlapiSearchRecord('transaction', null, poSearchForStatusFils, new nlobjSearchColumn('status'));
			for(var s=0; s<poSearchForStatus.length; s++){
				var poStatus = poSearchForStatus[s].getValue('status');
				var po_ID = poSearchForStatus[s].getId();
				
				//nlapiLogExecution('debug', 'poStatus', poStatus);
				var billPOStatus = BILL_PO_LINE_SL_STATUS_READY_FOR_PROCESSING;
				if(poStatus == 'fullyBilled')
					billPOStatus =  BILL_PO_LINE_SL_STATUS_PROCESSED;
				
				//poStatusFileContent = poStatusFileContent + po_ID + ','+ billPOStatus + ',' + billPOLogID + '\n';
				
				//nlapiSubmitField('purchaseOrder', selectedPOs[s], FLD_BILL_PO_LINE_SL_STATUS, billPOStatus);
              var nDigit = parseInt(po_ID)%10;
					if(nDigit == 0 || nDigit == 1 || nDigit == 2){
						poStatusFileContent = poStatusFileContent+po_ID + ','+ billPOStatus + ',' + billPOLogID + '\n';
						//intiateBillPOsData += poId+','+poLine_ID+','+poAppliedAmt+','+poLineId+'\n';
            hasPo=true;
					}else if(nDigit == 3 || nDigit == 4 || nDigit == 5){
						//nlapiLogExecution('debug', 'nDigit 2', nDigit);
					poStatusFileContent2 = poStatusFileContent2 + po_ID + ','+ billPOStatus + ',' + billPOLogID + '\n';
            hasPo2=true;
					}else if(nDigit == 6 || nDigit == 7 || nDigit == 8 || nDigit == 9){
						//nlapiLogExecution('debug', 'nDigit 3', nDigit);
						poStatusFileContent3 = poStatusFileContent3 + po_ID + ','+ billPOStatus + ',' + billPOLogID + '\n';
            hasPo3=true;
					}
			}
			if(poStatusFileContent != null && poStatusFileContent != '' && hasPo){ //queue 1
		
				var importUnderProcess = nlapiCreateCSVImport();
				importUnderProcess.setMapping(IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS);
				importUnderProcess.setPrimaryFile(poStatusFileContent);
				importUnderProcess.setQueue(2);
				var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);

			}
			if(poStatusFileContent2 != null && poStatusFileContent2 != '' && hasPo2){ //queue 3
				
					var importUnderProcess = nlapiCreateCSVImport();
				importUnderProcess.setMapping(IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS);
				importUnderProcess.setPrimaryFile(poStatusFileContent2);
				importUnderProcess.setQueue(3);
				var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);

			}
			if(poStatusFileContent3 != null && poStatusFileContent3 != '' && hasPo3){ //queue 4
				
					var importUnderProcess = nlapiCreateCSVImport();
				importUnderProcess.setMapping(IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS);
				importUnderProcess.setPrimaryFile(poStatusFileContent3);
				importUnderProcess.setQueue(4);
				var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);

			}
			
			}
		
}




function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}