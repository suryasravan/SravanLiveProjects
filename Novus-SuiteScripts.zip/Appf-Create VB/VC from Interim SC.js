	/*
	* Script Name : Appf-Create VB/VC from Interim SC
	* Script Type : Schedule Scipt
	* Description : This script will check for Interim VB  header records with "Create VB/C" checked and creates vendor bill and vendor credit records and backlinks to Interim records. This script also uses sync fields script
	* Company   :	Appficiency Inc.
	*/
	var SPARAM_INTERM_REC_TYPE = 'custscript_appf_interim_rec_type';
	 var SPARAM_INTERM_REC_ID = 'custscript_appf_interim_rec_id';
	 var SPARAM_INTERM_INDEX = 'custscript_appf_interim_lindex';
	 
	 var SCRIPT_SYNC_INTERIM_TO_VBVC = 'customscript_sync_interim_vbvc_sc';
	 
	var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'
	var FLD_CR_INTERIM_VENDOR = 'custrecord_appf_ivb_vendor';
	var FLD_CR_PO_LINE_NOS= 'custrecord_appf_ivbl_po_line_id';
	var FLD_CR_NET_AMTS= 'custrecord_appf_ivbl_vendor_net';
	var FLD_CR_PO_INTERNALID= 'custrecord_appf_ivbl_po_link';
	var FLD_CR_INV_TRNS= 'custrecord_appf_ivb_transid';
	var FLD_CR_IV_ON_BASED_ID= 'custrecord_appf_ivb_onbasedocid';
	var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';
	var FLD_CR_IV_DESCRIPTIONS= 'custrecord_appf_ivbl_description';
	var FLD_CR_IV_IO_NUM= 'custrecord_appf_ivbl_io_num';
	var FLD_CR_IV_CIRCULATIONS= 'custrecord_appf_ivbl_circulation';
	var FLD_CR_IV_UNITS='custrecord_appf_ivbl_novus_unit_rt'
	var FLD_CR_IV_VENDOR_NUM='custrecord_appf_ivb_vendoraccnum'
	var FLD_CR_IV_TRANS='custrecord_appf_transactions_created';
	var FLD_CR_IV_DUE_DATE='custrecord_appf_ivb_due_date';
	var FLD_CR_IV_ORIG_VB_DATE = 'custrecord_appf_ivb_orig_vb_date';
	var FLD_CR_IV_GST_HST='custrecord_appf_ivb_gst';
	var FLD_CR_IV_PST_QST='custrecord_appf_ivb_qst';
	var FLD_CR_IV_CURRENCY='custrecord_appf_ivb_currency';
	var FLD_IV_GST_HST_VB_LINK = 'custrecord_appf_ivb_gst_hst_vb';
	var FLD_IV_PST_QST_VB_LINK = 'custrecord_ivb_pst_qst_vb';
	var FLD_TRANSACTIOMN_FAILURE = 'custrecord_appf_transaction_failure';
	 var EXTERNAL_SCRIPTS_NAMES={'billposl':'1','vendorcreditsl':'2'}

	var FLD_COL_PRINT_CIRCULATION='custcol_appf_print_circulation'
	var FLD_COL_RATE='custcol_appf_novusunitrate'
	var FLD_COL_MASTER='custcol_appf_masterlink'
	var FLD_COL_LINKS='custcol_appf_childlink'
	var FLD_COL_IO='custcol_appf_ionum'
	var FLD_COL_PUBLISH='custcol_appf_publisher'
	var FLD_COL_LINE_IDS='custcol_appf_line_id'
	var FLD_COL_PP_RECS='custcol_appf_pwp_custom_record'
	var FLD_COL_PO_LINES='custcol_appf_po_line_id'

	var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
	var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';

	var SPARAM_INTERM_RECS_SS = 'custscript_appf_interim_vb_header_recs';
	var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'

	 var CUSTOM_RECORD_REC_LINE_INTERIM='customrecord_appf_interim_vb_line'
	 var FLD_IV_VB_LINKS='custrecord_appf_ivbl_vblink'
	 var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'
	 var SPARAM_VB_FIELDS = 'custscript_vb_header_fields_sync';
	 var SPARAM_VB_LINE_FIELDS = 'custscript_vb_line_fields_sync';
	 var FLD_IV_VC_LINKS='custrecord_appf_ivbl_vclink'
	 var SPARAM_VC_FIELDS = 'custscript_vc_header_fields_sync';
	 var SPARAM_VC_LINE_FIELDS = 'custscript_vc_line_fields_sync';
	 var FLD_IV_VC_NET='custrecord_appf_ivbl_vendor_net'
	 var FLD_IV_VC_NET='custrecord_appf_ivbl_vendor_net'
	 var CUSTOM_RECORD_PO_LINES='customrecord_appf_bill_po_lines_log'
	 var FLD_PO_LINE_BILL_LINKS='custrecord_appf_bill_po_lines_bill_link'
	 var FLD_PO_LINE_INTERM_LINKS='custrecord_appf_bill_po_lines_vb_header'
	 var FLD_PO_LINE_INTERM_LINES_LINKS='custrecord_appf_bill_po_lines_vb_lines'
	 
	 var FLD_PO_BUYING_SYSTEM = 'custbody_appf_buying_system';
	 
	var SPARAM_IMMEDIATE_EXECUTION = 'custscript_created_from_ext_scripts';
	var FLD_IV_IMMEDIATE_EXECUTION = 'custrecord_created_from_ext_scripts';

	var SCRIPT_BILL_PO_LINES_WS_SL = 'customscript_appf_bill_po_lines_ws_sl';
	var DEPLOY_BILL_PO_LINES_WS_SL = 'customdeploy_appf_bill_po_lines_ws_sl';

	var STATUS_INPROGRESS = '2';
	var STATUS_COMPLETED_SUCCESSFULLY = '4';
	var STATUS_COMPLETED_WITH_ERRORS = '5';

	//var ITEM_GST_HST_TAX = '95';
	//var ITEM_QST_PST_TAX = '96';
	//var CUSTOM_FORM_NOVUS_VB_TAX = '184';
	//var CUSTOM_FORM_NOVUS_VC_TAX = '182';


	var BUYINGSYSTEM_PRINT='1'
	var BUYINGSYSTEM_OOH='2'
	var BUYINGSYSTEM_DIGI='3'
	var BUYINGSYSTEM_SPOT='4'

	var FORM_PRINT='180'
	var FORM_OOH='181'
	var FORM_DIGI='179'
	var FORM_SPOT='182'


    var SPARAM_FROM_CATCHUP_SCRIPT = 'custscript_from_catchup_script';
	var SPARAM_ITEM_GST_HST_TAX='custscript_gst_hst_tax_item';
	var SPARAM_ITEM_QST_PST_TAX='custscript_qst_pst_tax_item';
	var SPARAM_CUSTOM_FORM_NOVUS_VB_TAX='custscript_custom_form_for_vb_tax';
	var SPARAM_CUSTOM_FORM_NOVUS_VC_TAX='custscript_custom_form_for_vc_tax';
	var SPARAM_FOLDER_BILL_PO = 'custscript_appf_selected_pos_folder_id';
	var SPARAM_UNIQUE_VENDORS_OBJ_DATA = 'custscript_appf_unique_vend_obj_data';
	var SPARAM_UNIQUE_VENDOR_OBJ = 'custscript_appf_unique_vend_obj_data_3';

	var SCRIPT_UPDATE_BILL_PO_SC = 'customscript_appf_update_bill_po_status';

	var FLD_PO_LINE_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
	var FLD_BILL_PO_RESULTS_FILE = 'custrecord_appf_bill_po_results_file';	
	var FLD_PO_BACKLINKING_STATUS = 'custrecord_appf_po_backlinking_status_bp';
	var SPARAM_BILL_PO_EXEC_ID = 'custscript_update_bill_po_id';
	var SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP='7';

	function craeteVBVCfromInterim(type)
	{
        var LOG_TITLE = 'craeteVBVCfromInterim';
		var context=nlapiGetContext();
		
		var fromCatchUpScript = context.getSetting('SCRIPT',SPARAM_FROM_CATCHUP_SCRIPT);
		var uniqueVendorObjData = context.getSetting('SCRIPT',SPARAM_UNIQUE_VENDORS_OBJ_DATA);
		
		var ITEM_GST_HST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_GST_HST_TAX);
		var ITEM_QST_PST_TAX = context.getSetting('SCRIPT',SPARAM_ITEM_QST_PST_TAX);
		var CUSTOM_FORM_NOVUS_VB_TAX =context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VB_TAX);
		var CUSTOM_FORM_NOVUS_VC_TAX = context.getSetting('SCRIPT',SPARAM_CUSTOM_FORM_NOVUS_VC_TAX);
			var FOLDER_BILL_PO = context.getSetting('SCRIPT',SPARAM_FOLDER_BILL_PO);

		
		 var ssID = context.getSetting('SCRIPT', SPARAM_INTERM_RECS_SS);
         nlapiLogExecution('debug', LOG_TITLE, 'ssID = ' + ssID);
		 var context=nlapiGetContext();
			var ssIDChild = context.getSetting('SCRIPT', SPARAM_INTERM_RECS_SS_CHILD)
			 nlapiLogExecution('debug','ssIDChild',ssIDChild)
		  
		   var scriptParamVBHeaderFields = context.getSetting('SCRIPT', SPARAM_VB_FIELDS)
		   var scriptParamVBLineFields = context.getSetting('SCRIPT', SPARAM_VB_LINE_FIELDS)
		   
		   var scriptParamVCHeaderFields = context.getSetting('SCRIPT', SPARAM_VC_FIELDS)
			var scriptParamVCLineFields = context.getSetting('SCRIPT', SPARAM_VC_LINE_FIELDS)
		  var isImmediateExecution = context.getSetting('SCRIPT', SPARAM_IMMEDIATE_EXECUTION)
		  nlapiLogExecution('debug', 'isImmediateExecution', isImmediateExecution);
	   
		 var loadSS=nlapiLoadSearch(null, ssID);
		 var fils = [];
	  var extScriptname='';
	   var billPoExecLogId=''
	    
		if (fromCatchUpScript != 'T')
		{
			
			
		
		
		
		  if (isImmediateExecution != null && isImmediateExecution!='')
		 {
			
		   var externalScriptNameList=isImmediateExecution.split('_')
		  var extScriptNameID=externalScriptNameList[0]
		   extScriptname=externalScriptNameList[1]
		   var intMastID = externalScriptNameList[2]
		   if (EXTERNAL_SCRIPTS_NAMES[extScriptname])
			 {
			   if (EXTERNAL_SCRIPTS_NAMES[extScriptname] == '1')
				 {
				   billPoExecLogId = extScriptNameID;
				 }
			   
			 }
			 fils.push(new nlobjSearchFilter(FLD_IV_IMMEDIATE_EXECUTION, null, 'is', 'T')); 
			 if (intMastID != null && intMastID != '')
				fils.push(new nlobjSearchFilter('internalid', null, 'anyof', intMastID)); 
	 
		 }
		 else
		 {
			 fils.push(new nlobjSearchFilter(FLD_IV_IMMEDIATE_EXECUTION,null, 'is', 'F')); 
		 }
		}
		else
		{
						 fils.push(new nlobjSearchFilter(FLD_IV_IMMEDIATE_EXECUTION, null, 'is', 'T')); 

		}
		 
		 
		
		 
			  nlapiLogExecution('debug', 'fromCatchUpScript', fromCatchUpScript);


		 var ssType = loadSS.getSearchType();
         nlapiLogExecution('debug', LOG_TITLE, 'ssType = ' + ssType);
		 var ssfilts = loadSS.getFilters()
		 fils=fils.concat(ssfilts);
		  var sscolumns=loadSS.getColumns();
			var searchResults=getAllSearchResults(ssType, fils, sscolumns);
		 nlapiLogExecution('debug','searchResults',searchResults)
		 
			
	  if (searchResults != null && searchResults != '') 
	  {
		   var InterimIds=[]
		   var InterimLinesIds=[]
			var vbIds=[]
					 nlapiLogExecution('debug','searchResults.length',searchResults.length)
					for(var s = 0; s <searchResults.length; s++) 
					{
						//rescheduling logic, 1/14/2021
						if (context.getRemainingUsage() <= 1000) {
							nlapiScheduleScript(context.getScriptId(), context.getDeploymentId());
							break;
						}  //end rescheduling logic, 1/14/2021
                      
						var searchresult = searchResults[s];
						var internalId =searchresult.getId()
						InterimIds.push(internalId)
	  if(internalId!=null && internalId!='')
	{
	  var nsMater=nlapiLoadRecord(CUSTOM_RECORD_INTERIM,internalId);
	  var transids=nsMater.getFieldValue(FLD_CR_INV_TRNS);
	  var tranName=nsMater.getFieldValue('name');
	  var invOnbase=nsMater.getFieldValue(FLD_CR_IV_ON_BASED_ID)
	  var invdate=nsMater.getFieldValue('custrecord_appf_ivb_date');
	  var dueDate = nsMater.getFieldValue('custrecord_appf_ivb_due_date');
	  var origVBDueDate = nsMater.getFieldValue(FLD_CR_IV_ORIG_VB_DATE); 
	  
		var terms = nsMater.getFieldValue('custrecord_appf_ivb_terms');
		var paymentType = nsMater.getFieldValue('custrecord_appf_ivb_payment_type');
		if (paymentType == null)
			paymentType = '';

	  var nsOrderCounts=nsMater.getLineItemCount(CUSTOM_RECORD_REC_INTERIM)
	  var NsaltVendor=nsMater.getFieldValue('custrecord_appp_ivb_alternatevendor');
	  var mainVendor = nsMater.getFieldValue(FLD_CR_INTERIM_VENDOR);
		var poNo=nsMater.getFieldValue(FLD_CR_IV_VENDOR_NUM)
			var apAcc=nsMater.getFieldValue('custrecord_appf_ivb_account')
			var vendorSubsidiary='';
	if(mainVendor !=null && mainVendor !='')
	vendorSubsidiary=nlapiLookupField('vendor',mainVendor,'subsidiary');

	   nlapiLogExecution('debug','nsOrderCounts',nsOrderCounts)
	  var refcounter = 1;
	  var reftrans = 0;
	  var vbErrorLog = '';
	  var totalProcessed = 0;
	  
	  var resultFileData = '';
	  var dataLines=[];
	  if(billPoExecLogId != null && billPoExecLogId != ''){
		  var dataFile = nlapiLookupField(CUSTOM_RECORD_PO_LINES,billPoExecLogId, FLD_PO_LINE_DATA_FILE);
		  if(dataFile != null && dataFile != ''){
			  var dataFileContents = nlapiLoadFile(dataFile).getValue();
			  if(dataFileContents != null && dataFileContents != ''){
				  var fileDataLines = dataFileContents.split('\n');
				  if(fileDataLines != null && fileDataLines != ''){
					  resultFileData += 'Script Status, Failed Reason,'+fileDataLines[0]+'\n';
					  dataLines=dataLines.concat(fileDataLines)
				  }
				  
			  }
			  
		  }
	  }

	  for (var p = 1; p <=nsOrderCounts; p++)
	{
		var revisedTranNum =tranName+ '-'+refcounter;
		var poLineNo=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_PO_LINE_NOS,p)
		nlapiLogExecution('debug','poLineNo',poLineNo)
		var poLineAmounts=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_NET_AMTS,p)
		var poid=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_PO_INTERNALID,p)
		var podescription=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_DESCRIPTIONS,p)
		var ioNum=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_IO_NUM,p)
		var poCurculatns=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_CIRCULATIONS,p)
		var poUnit=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_UNITS,p)
		var internalLink=nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,'id',p)
		var exisingVBLink = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_IV_VB_LINKS,p);
			var exisingVCLink = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_IV_VC_LINKS,p);
	refcounter++
		InterimLinesIds.push(internalLink)
		if(poLineAmounts != null && poLineAmounts != '' && poLineAmounts>0 && (exisingVBLink == null || exisingVBLink == ''))
		{
			var vbillCreateInternal=null;
			var sErrorMsg = '';
			nlapiLogExecution('debug','poid',poid)
			try{
				nlapiLogExecution('debug','vbillCreatetrty',poid)
		var vbillCreate=nlapiTransformRecord('purchaseorder',poid,'vendorbill',{'recordmode':'dynamic'})
		nlapiLogExecution('debug','vbillCreate',vbillCreate)
		vbillCreate.setFieldValue('tranid',revisedTranNum)
		vbillCreate.setFieldValue('custbody_appf_onbase_docid',invOnbase)
		vbillCreate.setFieldValue('custbody_appf_master_vendor_date',invdate)
		vbillCreate.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
		
		vbillCreate.setFieldValue('terms', terms);
		vbillCreate.setFieldValue('duedate',dueDate);
		vbillCreate.setFieldValue('custbody_appf_accnum_ocr', poNo);
		vbillCreate.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate);  //added: 2/19/2021
		
		
		
		if (apAcc != null && apAcc != '')
		vbillCreate.setFieldValue('account', apAcc);

	if(scriptParamVBHeaderFields!=null && scriptParamVBHeaderFields!='')
	{
	var vbHeaderFieldList = scriptParamVBHeaderFields.split(',');
	for (var vh = 0; vh < vbHeaderFieldList.length; vh++)
	{
	var interimHeaderFieldID = vbHeaderFieldList[vh].split('|')[0];
	var vbHeaderFieldID = vbHeaderFieldList[vh].split('|')[1];
	var interimHeaderFieldValue = nsMater.getFieldValue(interimHeaderFieldID);
	vbillCreate.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
	}
	}

			  if(billPoExecLogId!=null && billPoExecLogId!='')
				 {
		vbillCreate.setFieldValue('custbody_appf_bill_po_lines_log', billPoExecLogId);
			}
		nlapiLogExecution('debug','vbillCreate.getLineItemCount',vbillCreate.getLineItemCount('item'))
						for(var c=1; c<=vbillCreate.getLineItemCount('item'); c++)
						{
							
							var cmInvLineId = vbillCreate.getLineItemValue('item', FLD_COL_PO_LINES, c);
							nlapiLogExecution('debug','cmInvLineId',cmInvLineId)
							if(cmInvLineId == poLineNo)
							{
									nlapiLogExecution('debug','line id matches',cmInvLineId)

															vbillCreate.selectLineItem('item', c);
															vbillCreate.setCurrentLineItemValue('item', 'quantity', poLineAmounts);
															vbillCreate.setCurrentLineItemValue('item', 'rate', 1);

															vbillCreate.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
															vbillCreate.setCurrentLineItemValue('item', 'description', podescription);
															vbillCreate.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
															vbillCreate.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
															vbillCreate.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
															vbillCreate.setCurrentLineItemValue('item', FLD_COL_LINKS, internalLink);
															
															
	if(scriptParamVBLineFields!=null && scriptParamVBLineFields!='')
	{
	var vbLineFieldList = scriptParamVBLineFields.split(',');
	for (var vl = 0; vl < vbLineFieldList.length; vl++)
	{
	var interimLineFieldID = vbLineFieldList[vl].split('|')[0];
	var vbLineFieldID = vbLineFieldList[vl].split('|')[1];
			nlapiLogExecution('debug','vbLineFieldID',vbLineFieldID)	

	var interimLineFieldValue = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM,interimLineFieldID, p);
	//vendorBillRecord.selectLineItem('item', 1);
			nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)	

	vbillCreate.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
	//vendorBillRecord.commitLineItem('item');
	}
	}
															

															vbillCreate.commitLineItem('item');
							}
							else
							{
								vbillCreate.removeLineItem('item', c);
								c--;
							}
						}
		
		try{
			vbillCreateInternal=nlapiSubmitRecord(vbillCreate,true,true)
			nlapiLogExecution('debug','ID of created bill',vbillCreateInternal)	
		}catch(errorLineVB)
		{
			if (errorLineVB.getDetails() != null && errorLineVB.getDetails() != '') /*( errorLineVB instanceof nlobjError )*/{
				nlapiLogExecution('debug','errorLineVB.getDetails() 1 ',errorLineVB.getDetails())	
				vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+errorLineVB.message() + '\n';
				resultFileData += 'Failed, '+errorLineVB.getDetails()+','+dataLines[p]+'\n';
			}else{
				//var sErrorMsg = '';
				
				if(invdate == null || invdate == '' ){
					vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'Date is missing.' + '\n';
					//resultFileData += 'Failed, '+'Date is missing.'+','+dataLines[p]+'\n';
					sErrorMsg += 'Date is missing. ';
				}
				if(ioNum == null || ioNum == '' ){
					 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
					// resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
					 sErrorMsg += 'IO # is missing. ';
					 
				}
				/*if(pwpLink == null || pwpLink == '' ){
					 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
					// resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
					 sErrorMsg += 'PWP link is missing. ';
					 
				}*/
				
				sErrorMsg = sErrorMsg + errorLineVB+'';
				
				resultFileData += 'Failed, '+sErrorMsg+','+dataLines[p]+'\n';
				nlapiLogExecution('debug','errorLineVB.getDetails() 2',errorLineVB+'')	
			}

			

		}


		if(vbillCreateInternal!=null && vbillCreateInternal!='')
		{
			
							  resultFileData += 'Success, ,'+dataLines[p]+'\n';

			vbIds.push(vbillCreateInternal)
			reftrans++
		//nsMater.setLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vblink',p,vbillCreateInternal)
		nlapiSubmitField(CUSTOM_RECORD_REC_LINE_INTERIM, internalLink, FLD_IV_VB_LINKS, vbillCreateInternal);
		
		if(NsaltVendor!=null  && NsaltVendor!='')
			{
				var vendorRec=nlapiLoadRecord('vendorbill',vbillCreateInternal);
				vendorRec.setFieldValue('entity',NsaltVendor)
				nlapiSubmitRecord(vendorRec,true,true)
			}
			 
		}
		nlapiLogExecution('debug','vbillCreateInternal',vbillCreateInternal);
			}
			
			
			
			
			catch(e1)
			{
				if ( e1 instanceof nlobjError )
				{
			vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+e1.getDetails() + '\n';
										  resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';
										  nlapiLogExecution('debug','errorLineVB.getDetails() 3 ',e1.getDetails())	
				}
			else
			{
				
			vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+sErrorMsg /*e1.toString() */ + '\n';
												  resultFileData += 'Failed, '+sErrorMsg /*e1.toString()*/+','+dataLines[p]+'\n';
												  nlapiLogExecution('debug','errorLineVB.getDetails() 4 ',e1.toString())	

			}

			}
			totalProcessed++;
			 if(billPoExecLogId!=null && billPoExecLogId!='')
				 {
					 //custrecord_appf_bill_po_lines_error_log
		var billPoExecLogIdRec=nlapiLoadRecord(CUSTOM_RECORD_PO_LINES,billPoExecLogId);
		var existingErrorLog = billPoExecLogIdRec.getFieldValue('custrecord_appf_bill_po_lines_error_log');
		if (existingErrorLog == null)
			existingErrorLog = '';
		if (vbErrorLog != null && vbErrorLog != '')
		{
			
			existingErrorLog = existingErrorLog + vbErrorLog;
							billPoExecLogIdRec.setFieldValue('custrecord_appf_bill_po_lines_error_log', existingErrorLog);

		}
		
		if (existingErrorLog != null && existingErrorLog != '')
		{
									billPoExecLogIdRec.setFieldValue('custrecord_appf_bill_po_lines_status', STATUS_COMPLETED_WITH_ERRORS);

			
		}
		
		
		if (vbillCreateInternal != null && vbillCreateInternal != '')
		{
		var existingBillsinBillPORecFound = billPoExecLogIdRec.getFieldValue('custrecord_appf_bill_po_lines_bill_link');
			var existingBillsinBillPORec = billPoExecLogIdRec.getFieldValues('custrecord_appf_bill_po_lines_bill_link');
			
			if (existingBillsinBillPORecFound != null && existingBillsinBillPORecFound != '')
			{
				var currentBills = [];
			currentBills.push(vbillCreateInternal);
			if (existingBillsinBillPORec.length>0)
				currentBills = currentBills.concat(existingBillsinBillPORec);
			}
			else
			{
				
				var currentBills = [];
			currentBills.push(vbillCreateInternal);
			}
			
			currentBills = eliminateDuplicates(currentBills);
					billPoExecLogIdRec.setFieldValues('custrecord_appf_bill_po_lines_bill_link', currentBills);

		}
			
			
			var existinginterimHeaderRecsinBillPORecFound = billPoExecLogIdRec.getFieldValue('custrecord_appf_bill_po_lines_vb_header');
			var existinginterimHeaderRecsinBillPORec = billPoExecLogIdRec.getFieldValues('custrecord_appf_bill_po_lines_vb_header');
			
			if (existinginterimHeaderRecsinBillPORecFound != null && existinginterimHeaderRecsinBillPORecFound != '')
			{
				var currentinterimHeaderRecs = [];
				currentinterimHeaderRecs.push(internalId);
				if (existinginterimHeaderRecsinBillPORec.length>0)
				currentinterimHeaderRecs = currentinterimHeaderRecs.concat(existinginterimHeaderRecsinBillPORec);
			}
			else
			{
				var currentinterimHeaderRecs = [];
				currentinterimHeaderRecs.push(internalId);
				
			}
			
			
			var existinginterimChildRecsinBillPORecFound = billPoExecLogIdRec.getFieldValue('custrecord_appf_bill_po_lines_vb_lines');
			var existinginterimChildRecsinBillPORec = billPoExecLogIdRec.getFieldValues('custrecord_appf_bill_po_lines_vb_lines');
			
			if (existinginterimChildRecsinBillPORecFound != null && existinginterimChildRecsinBillPORecFound != '')
			{
				var currentinterimChildRecs = [];
			currentinterimChildRecs.push(internalLink);
			if (existinginterimChildRecsinBillPORec.length>0)
				currentinterimChildRecs = currentinterimChildRecs.concat(existinginterimChildRecsinBillPORec);
			}
			else
			{
				var currentinterimChildRecs = [];
			currentinterimChildRecs.push(internalLink);
				
			}
			currentinterimHeaderRecs=eliminateDuplicates(currentinterimHeaderRecs);
					billPoExecLogIdRec.setFieldValues('custrecord_appf_bill_po_lines_vb_header', currentinterimHeaderRecs);
	currentinterimChildRecs = eliminateDuplicates(currentinterimChildRecs);
			billPoExecLogIdRec.setFieldValues('custrecord_appf_bill_po_lines_vb_lines', currentinterimChildRecs);
					billPoExecLogIdRec.setFieldValue('custrecord_appf_bill_po_lines_created', totalProcessed);
					
					var totalToProcess = billPoExecLogIdRec.getFieldValue('custrecord_appf_bill_po_lines_total');
					
					var percentComplete = (parseInt(totalProcessed) / parseInt(totalToProcess)) * 100;
					percentComplete = Math.round(percentComplete*100)/100;
					billPoExecLogIdRec.setFieldValue('custrecord_appf_bill_po_lines_percent', percentComplete);
					
		if(parseFloat(percentComplete) == 100)
		{
			
			billPoExecLogIdRec.setFieldValue('custrecord_appf_bill_po_lines_status', STATUS_COMPLETED_SUCCESSFULLY);
		}

			
			nlapiSubmitRecord(billPoExecLogIdRec, true, true);


		

			}
			
		}
		if (poLineAmounts != null && poLineAmounts != '' && (exisingVCLink == null || exisingVCLink == '') && poLineAmounts < 0)
		{
			var cFormVC = '';
			var poRec=nlapiLoadRecord('purchaseorder',poid)
			var poTranID = poRec.getFieldValue('tranid');
			var poentity=poRec.getFieldValue('entity')
			var pobuyingSys=poRec.getFieldValue(FLD_PO_BUYING_SYSTEM)
			var poCount=poRec.getLineItemCount('item')
			
			if(pobuyingSys==BUYINGSYSTEM_PRINT)
				cFormVC=FORM_PRINT;
			if(pobuyingSys==BUYINGSYSTEM_OOH)
				cFormVC=FORM_OOH;
			if(pobuyingSys==BUYINGSYSTEM_DIGI)
				cFormVC=FORM_DIGI;
			if(pobuyingSys==BUYINGSYSTEM_SPOT)
				cFormVC=FORM_SPOT;
			
		try{
			var vcCreateIds;
			var sErrorMsgVC = '';
			var vcCreate=nlapiCreateRecord('vendorcredit');
			refcounter++;
			//nlapiLogExecution('debug','vcCreate',vcCreate)
			if (cFormVC != '')
			vcCreate.setFieldValue('customform',cFormVC)
		vcCreate.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
			if(NsaltVendor!=null  && NsaltVendor!='')
			 {
				vcCreate.setFieldValue('entity',NsaltVendor)
			  }
			 else
		{
				vcCreate.setFieldValue('entity',poentity)
		}
				vcCreate.setFieldValue('tranid',revisedTranNum)
				vcCreate.setFieldValue('custbody_appf_onbase_docid',invOnbase)
				//sravan 9th sep 2022: setting Original VB Date
				vcCreate.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate)
				
				vcCreate.setFieldValue('custbody_appf_accnum_ocr', poNo);
				if (apAcc != null && apAcc != '')
		vcCreate.setFieldValue('account', apAcc);

	if(scriptParamVCHeaderFields!=null && scriptParamVCHeaderFields!='')
	{
	var vcHeaderFieldList = scriptParamVCHeaderFields.split(',');
	for (var vh = 0; vh < vcHeaderFieldList.length; vh++)
	{
	var interimHeaderFieldID = vcHeaderFieldList[vh].split('|')[0];
	var vbHeaderFieldID = vcHeaderFieldList[vh].split('|')[1];
	var interimHeaderFieldValue = nsMater.getFieldValue(interimHeaderFieldID);
	vcCreate.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
	}
	}
				
				var poLineNum=poRec.findLineItemValue('item','custcol_appf_po_line_id',poLineNo)
														   var poItem=poRec.getLineItemValue('item','item',poLineNum)
														   var poStrat=poRec.getLineItemValue('item','custcolappf_so_line_startdate',poLineNum)
														   var poendDat=poRec.getLineItemValue('item','custcol_appf_so_line_enddate',poLineNum)
														   var poPublishs=poRec.getLineItemValue('item',FLD_COL_PUBLISH,poLineNum)
														   var soLineIds=poRec.getLineItemValue('item',FLD_COL_LINE_IDS,poLineNum)
														   var ppLineIds=poRec.getLineItemValue('item',FLD_COL_PP_RECS,poLineNum)
														   var poLineIds=poRec.getLineItemValue('item',FLD_COL_PO_LINES,poLineNum)
														   var pocust = poRec.getLineItemValue('item','customer',poLineNum)
															vcCreate.selectNewLineItem('item');
															vcCreate.setCurrentLineItemValue('item', 'item', poItem);
															vcCreate.setCurrentLineItemValue('item', 'quantity', (-1)*poLineAmounts);
																												vcCreate.setCurrentLineItemValue('item', 'rate', 1);

															vcCreate.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
															vcCreate.setCurrentLineItemValue('item', 'description', podescription);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_PUBLISH, poPublishs);
															vcCreate.setCurrentLineItemValue('item', 'custcolappf_so_line_startdate', poStrat);
															vcCreate.setCurrentLineItemValue('item', 'custcol_appf_so_line_enddate', poendDat);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_LINE_IDS, soLineIds);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_PP_RECS, ppLineIds);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_PO_LINES, poLineIds);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
															vcCreate.setCurrentLineItemValue('item', FLD_COL_LINKS, internalLink);
															if (pocust != null && pocust != '')
															vcCreate.setCurrentLineItemValue('item', 'customer', pocust);

	if(scriptParamVCLineFields!=null && scriptParamVCLineFields!='')
	{
	var vcLineFieldList = scriptParamVCLineFields.split(',');
	for (var vl = 0; vl < vcLineFieldList.length; vl++)
	{
	var interimLineFieldID = vcLineFieldList[vl].split('|')[0];
	var vbLineFieldID = vcLineFieldList[vl].split('|')[1];

	var interimLineFieldValue = nsMater.getLineItemValue(CUSTOM_RECORD_REC_INTERIM, interimLineFieldID, p);
	nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
	nlapiLogExecution('debug','vbLineFieldID',vbLineFieldID)

		if(interimLineFieldID==FLD_IV_VC_NET)
		{
		interimLineFieldValue=Math.abs(interimLineFieldValue);
		nlapiLogExecution('debug','interimLineFieldValue',interimLineFieldValue)
		}
	vcCreate.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
	}
	}

															vcCreate.commitLineItem('item');
						
															try{
																vcCreateIds=nlapiSubmitRecord(vcCreate,true,true)
																nlapiLogExecution('debug','vcCreateIds',vcCreateIds)
															}catch(errorLineVC)
															{
																if ( errorLineVC.getDetails() != null && errorLineVC.getDetails() != '' /*errorLineVC instanceof nlobjError*/ )
																{
																	vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+errorLineVC.getDetails() + '\n';
																								  resultFileData += 'Failed, '+errorLineVC.getDetails()+','+dataLines[p]+'\n';
                                                                    nlapiLogExecution('debug', 'errorLineVC.getDetails() 1 ', errorLineVC.getDetails());
																}
																else
																{
																	//var sErrorMsg = '';
																	if(invdate == null || invdate == '' ){
																		vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+'Date is missing.' + '\n';
																		//resultFileData += 'Failed, '+'Date is missing.'+','+dataLines[p]+'\n';
																		sErrorMsgVC += 'Date is missing. ';
																	}
																	if(ioNum == null || ioNum == '' ){
																		 vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+'IO # field is empty.' + '\n';
																		// resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
																		 sErrorMsgVC += 'IO # is missing. ';
																		 
																	}
																	/*if(pwpLink == null || pwpLink == '' ){
																		 vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+'PWP link field is empty.' + '\n';
																		// resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
																		 sErrorMsgVC += 'PWP link is missing. ';
																		 
																	}*/
																	
																	//vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+errorLineVC.toString() + '\n';
																	resultFileData += 'Failed, '+sErrorMsgVC+','+dataLines[p]+'\n';
                                                                    nlapiLogExecution('debug', 'errorLineVC.getDetails() 2 ', sErrorMsgVC + ' ___ ' + errorLineVC.getDetails());
																}
																
														
															}
															
															if(vcCreateIds!=null && vcCreateIds!='')
																 {
																	 resultFileData += 'Success, ,'+dataLines[p]+'\n';

																	nlapiLogExecution('debug','vcCreateIds',vcCreateIds)	
																	 reftrans++
																	 //nsMater.setLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vclink',p,vcCreateIds)
																		nlapiSubmitField(CUSTOM_RECORD_REC_LINE_INTERIM, internalLink, FLD_IV_VC_LINKS, vcCreateIds);

																		

																	 }
																	 }
			
			catch(e1)
			{
				if ( e1 instanceof nlobjError )
				{
			vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.getDetails() + '\n';
												  resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';
                                nlapiLogExecution('debug', 'e1.getDetails() 3 ', e1.getDetails());
				}
			else
			{
			vbErrorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+ sErrorMsgVC /*e1.toString()*/ + '\n';
											  resultFileData += 'Failed, '+ sErrorMsgVC /*e1.getDetails()*/ +','+dataLines[p]+'\n';
                                nlapiLogExecution('debug', 'e1.getDetails() 4 ', sErrorMsgVC + ' ___ ' + e1.getDetails());
			}
			}
		}
		
		
		
	}
			
	if(billPoExecLogId != null && billPoExecLogId != '' && resultFileData != null && resultFileData != ''){
				var timeStamp = new Date().getTime();

						var resultFile = nlapiCreateFile('Bill_PO_Processing_Results_'+timeStamp+'.csv', 'CSV', resultFileData);
						resultFile.setFolder(FOLDER_BILL_PO);
						var newResultFileId = nlapiSubmitFile(resultFile);
						nlapiSubmitField(CUSTOM_RECORD_PO_LINES, billPoExecLogId, [FLD_BILL_PO_RESULTS_FILE, FLD_PO_BACKLINKING_STATUS], [newResultFileId, STATUS_INPROGRESS]);
					}
					
					/* Sravan: 9/27/2021 error tracking is now moved to post creation of Tax VBs
		if(vbErrorLog == '' || vbErrorLog == null)
		{
		nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['T', '', '2']);
				//nlapiScheduleScript(SCRIPT_SYNC_INTERIM_TO_VBVC, null, params);

			//syncRecords(CUSTOM_RECORD_INTERIM, internalId);
			nlapiLogExecution('debug','NsaltVendor','NsaltVendor')

		}
		else
		{
				nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['F',vbErrorLog, '2'])

		}
		*/
		
		
		var gsthst=nsMater.getFieldValue(FLD_CR_IV_GST_HST);
		var pstqst=nsMater.getFieldValue(FLD_CR_IV_PST_QST);
		var existingGSTLink = nsMater.getFieldValue(FLD_IV_GST_HST_VB_LINK);
		var existingPSTLink = nsMater.getFieldValue(FLD_IV_PST_QST_VB_LINK);
	 

		if(gsthst != null && gsthst != '' && parseFloat(gsthst)>0 && (existingGSTLink == null || existingGSTLink == '')&& vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
			var newVBID;
			var vbRec = nlapiCreateRecord('vendorbill');
			
			if(NsaltVendor!=null  && NsaltVendor!='')
			 {
				vbRec.setFieldValue('entity',NsaltVendor)
			  }
			  else
			  {
				  vbRec.setFieldValue('entity', mainVendor);
				  
			  }
			vbRec.setFieldValue('tranid',tranName+'-GST/HST');
			vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
			vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
			
			vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
			
			//sravan 9th sep 2022: setting Original VB Date
				vbRec.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate)
			//vbRec.setFieldValue('custbody_appf_master_vendor_date',invdate);
			
			vbRec.setFieldValue('terms', terms);
			vbRec.setFieldValue('duedate',dueDate);
			vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
			if (apAcc != null && apAcc != '')
		vbRec.setFieldValue('account', apAcc);
			if(billPoExecLogId!=null && billPoExecLogId!='')
			  {
			vbRec.setFieldValue('custbody_appf_bill_po_lines_log', billPoExecLogId);
			}
			vbRec.selectNewLineItem('item');
			vbRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
			vbRec.setCurrentLineItemValue('item', 'rate', 1);
			vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(gsthst));
			vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
			vbRec.commitLineItem('item');
			
			try{
				newVBID = nlapiSubmitRecord(vbRec, true, true);
			}catch(errorLineVB2)
			{
				if ( errorLineVB2 instanceof nlobjError ){
					vbErrorLog += '---> Failed to create tax Vendor Bill'+', Reason: '+errorLineVB2.getDetails() + '\n';
					//resultFileData += 'Failed, '+errorLineVB2.toString()+','+dataLines[p]+'\n';

				}else{
					vbErrorLog += '---> Failed to create tax Vendor Bill'+', Reason: '+errorLineVB2.toString() + '\n';
					//resultFileData += 'Failed, '+e1.getDetails()+','+dataLines[p]+'\n';
					/*var sErrorMsg = '';
					
					if(invdate == null || invdate == '' ){
						vbErrorLog += '---> Failed to create Vendor Bill for PO Line ID:'+poLineNo+', Reason: '+'Date is missing.' + '\n';
						//resultFileData += 'Failed, '+'Date is missing.'+','+dataLines[p]+'\n';
						sErrorMsg += 'Date is missing. ';
					}
					if(ioNum == null || ioNum == '' ){
						 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'IO # field is empty.' + '\n';
						// resultFileData += 'Failed, '+'IO # is empty.'+','+dataLines[p]+'\n';
						 sErrorMsg += 'IO # is missing. ';
						 
					}
					if(pwpLink == null || pwpLink == '' ){
						 vbErrorLog += '---> Failed to create Vendor Credit for PO Line ID:'+poLineNo+', Reason: '+'PWP link field is empty.' + '\n';
						// resultFileData += 'Failed, '+'PWP link field is empty.'+','+dataLines[p]+'\n';
						 sErrorMsg += 'PWP link is missing. ';
						 
					}
					
					resultFileData += 'Failed, '+sErrorMsg+','+dataLines[p]+'\n';*/
				}

				

			}
			
			
			
			if(newVBID != null && newVBID != ''){
				nlapiLogExecution('debug', 'newVBID', newVBID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_GST_HST_VB_LINK, newVBID);
			}
			
		}
		if(gsthst != null && gsthst != '' && parseFloat(gsthst)<0 && (existingGSTLink == null || existingGSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
			var newVCID;
			var vcRec = nlapiCreateRecord('vendorcredit');
			if(NsaltVendor!=null  && NsaltVendor!='')
			 {
				vcRec.setFieldValue('entity',NsaltVendor)
			  }
			  else
			  {
				  vcRec.setFieldValue('entity', mainVendor);
				  
			  }
			 // vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
				vcRec.setFieldValue('tranid',tranName+'-GST/HST')
				vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
				vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
				
				//sravan 9th sep 2022: setting Original VB Date
				vcRec.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate)
				//vcRec.setFieldValue('custbody_appf_master_vendor_date',invdate)
				
				vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
				if (apAcc != null && apAcc != '')
		vcRec.setFieldValue('account', apAcc);
			vcRec.selectNewLineItem('item');
			vcRec.setCurrentLineItemValue('item', 'item', ITEM_GST_HST_TAX);
			vcRec.setCurrentLineItemValue('item', 'rate', 1);
			vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(gsthst)));
			vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
					vcRec.commitLineItem('item');

					try{
						var newVCID = nlapiSubmitRecord(vcRec, true, true);
					}catch(errorNewVCID)
					{
						if ( errorNewVCID instanceof nlobjError ){
							vbErrorLog += '---> Failed to create tax Vendor Credit'+', Reason: '+errorNewVCID.getDetails() + '\n';
							//resultFileData += 'Failed, '+errorLineVB2.toString()+','+dataLines[p]+'\n';

						}else{
							vbErrorLog += '---> Failed to create tax Vendor Credit'+', Reason: '+errorNewVCID.toString() + '\n';
						}

				

					}
			
			
			if(newVCID != null && newVCID != ''){
				nlapiLogExecution('debug', 'newVCID', newVCID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_GST_HST_VB_LINK, newVCID);
			}
			
		}
		
		if(pstqst != null && pstqst != '' && parseFloat(pstqst)>0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
			var newVBID;
			var vbRec = nlapiCreateRecord('vendorbill');
			if(NsaltVendor!=null  && NsaltVendor!='')
			 {
				vbRec.setFieldValue('entity',NsaltVendor)
			  }
			  else
			  {
				  vbRec.setFieldValue('entity', mainVendor);
				  
			  }
			vbRec.setFieldValue('tranid',tranName+'-PST/QST');
			vbRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VB_TAX);
			vbRec.setFieldValue('custbody_appf_onbase_docid',invOnbase);
			vbRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
			
			//sravan 9th sep 2022: setting Original VB Date
				vbRec.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate)
			//vbRec.setFieldValue('custbody_appf_master_vendor_date',invdate);
			
			vbRec.setFieldValue('terms', terms);
			vbRec.setFieldValue('duedate',dueDate);
			vbRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
			if (apAcc != null && apAcc != '')
		vbRec.setFieldValue('account', apAcc);
			if(billPoExecLogId!=null && billPoExecLogId!='')
			  {
			vbRec.setFieldValue('custbody_appf_bill_po_lines_log', billPoExecLogId);
			}
			vbRec.selectNewLineItem('item');
			vbRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
			vbRec.setCurrentLineItemValue('item', 'rate', 1);
			vbRec.setCurrentLineItemValue('item', 'quantity', parseFloat(pstqst));
			vbRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
					vbRec.commitLineItem('item');

					
					try{
						newVBID = nlapiSubmitRecord(vbRec, true, true);
					}catch(errorNewVBID)
					{
						if ( errorNewVBID instanceof nlobjError ){
							vbErrorLog += '---> Failed to create pst tax Vendor Bill'+', Reason: '+errorNewVBID.getDetails() + '\n';
							//resultFileData += 'Failed, '+errorLineVB2.toString()+','+dataLines[p]+'\n';
			
						}else{
							vbErrorLog += '---> Failed to create pst tax Vendor Bill'+', Reason: '+errorNewVBID.toString() + '\n';
						}
			
				
			
					}
			
			if(newVBID != null && newVBID != ''){
				nlapiLogExecution('debug', 'newVBID', newVBID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_PST_QST_VB_LINK, newVBID);
			}
			
		}
		if(pstqst != null && pstqst != '' && parseFloat(pstqst)<0 && (existingPSTLink == null || existingPSTLink == '') && vendorSubsidiary == SUBSIDIARY_NOVUS_MEDIA_CANADA_CROP){
			var newVCID;
			var vcRec = nlapiCreateRecord('vendorcredit');
	if(NsaltVendor!=null  && NsaltVendor!='')
			 {
				vcRec.setFieldValue('entity',NsaltVendor)
			  }
			  else
			  {
				  vcRec.setFieldValue('entity', mainVendor);
				  
			  }
			 // vcRec.setFieldValue('customform',CUSTOM_FORM_NOVUS_VC_TAX);
				vcRec.setFieldValue('tranid',tranName+'-PST/QST')
				vcRec.setFieldValue('custbody_appf_onbase_docid',invOnbase)
				//sravan 9th sep 2022: setting Original VB Date
				vcRec.setFieldValue('custbody_appf_master_vendor_date',origVBDueDate)
				//vcRec.setFieldValue('custbody_appf_master_vendor_date',invdate)
			 vcRec.setFieldValue('custbody_appf_vendor_payment_type',paymentType);
			 
				
				vcRec.setFieldValue('custbody_appf_accnum_ocr', poNo);
				if (apAcc != null && apAcc != '')
		vcRec.setFieldValue('account', apAcc);
			vcRec.selectNewLineItem('item');
			vcRec.setCurrentLineItemValue('item', 'item', ITEM_QST_PST_TAX);
			vcRec.setCurrentLineItemValue('item', 'rate', 1);
			vcRec.setCurrentLineItemValue('item', 'quantity', Math.abs(parseFloat(pstqst)));
			vcRec.setCurrentLineItemValue('item', FLD_COL_MASTER, internalId);
							vcRec.commitLineItem('item');

							try{
								newVCID = nlapiSubmitRecord(vcRec, true, true);
							}catch(errorNewVCID)
							{
								if ( errorNewVCID instanceof nlobjError ){
									vbErrorLog += '---> Failed to create pst tax Vendor Credit'+', Reason: '+errorNewVCID.getDetails() + '\n';
									//resultFileData += 'Failed, '+errorLineVB2.toString()+','+dataLines[p]+'\n';
					
								}else{
									vbErrorLog += '---> Failed to create pst tax Vendor Credit'+', Reason: '+errorNewVCID.toString() + '\n';
								}
					
						
					
							}
			
			if(newVCID != null && newVCID != ''){
				nlapiLogExecution('debug', 'newVCID', newVCID);
				nlapiSubmitField(CUSTOM_RECORD_INTERIM, internalId, FLD_IV_PST_QST_VB_LINK, newVCID);
			}
			
		}
		
		//Sravan 9/27/2021 Error tracking which considers both child VBs as well as Tax VBs
		if(vbErrorLog == '' || vbErrorLog == null)
		{
		nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['T', '', '2']);
				//nlapiScheduleScript(SCRIPT_SYNC_INTERIM_TO_VBVC, null, params);

			//syncRecords(CUSTOM_RECORD_INTERIM, internalId);
			//nlapiLogExecution('debug','NsaltVendor','NsaltVendor')

		}
		else
		{
						nlapiLogExecution('debug', 'Error in processing NS Interim Master ID: '+internalId, vbErrorLog);

				nlapiSubmitField(CUSTOM_RECORD_INTERIM,internalId,[FLD_CR_IV_TRANS, FLD_TRANSACTIOMN_FAILURE, 'custrecord_appf_sync_tran_status'],['F',vbErrorLog, '2'])

		}
		
	}

					}
		
		}
		nlapiLogExecution('debug','uniqueVendorObjData',uniqueVendorObjData)
		if (billPoExecLogId != null && billPoExecLogId != '' && uniqueVendorObjData != null && uniqueVendorObjData != '')
		{
			nlapiLogExecution('debug','uniqueVendorObjDataScheduled1',uniqueVendorObjData)
			var params3 = {};
			params3[SPARAM_UNIQUE_VENDOR_OBJ] = uniqueVendorObjData; 
					params3[SPARAM_BILL_PO_EXEC_ID] = billPoExecLogId; 

			
			nlapiScheduleScript(SCRIPT_UPDATE_BILL_PO_SC, null, params3);
			nlapiLogExecution('debug','uniqueVendorObjDataScheduled',uniqueVendorObjData)
			
		}
		
	}

	function getAllSearchResults(record_type, filters, columns)
	{
        var LOG_TITLE = 'getAllSearchResults';
        nlapiLogExecution('debug', LOG_TITLE, 'record_type = ' + record_type);
        //nlapiLogExecution('debug', LOG_TITLE, 'filters = ' + JSON.stringify(filters));
       // nlapiLogExecution('debug', LOG_TITLE, 'columns = ' + JSON.stringify(columns));
	var searchRes = nlapiCreateSearch(record_type, filters, columns);
	searchRes.setIsPublic(true);

	var searchRan = searchRes.runSearch()
	, bolStop = false
	, intMaxReg = 1000
	, intMinReg = 0
	, result = [];

	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
	{
	// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
	var extras = searchRan.getResults(intMinReg, intMaxReg);

	result = searchUnion(result, extras);
	intMinReg = intMaxReg;
	intMaxReg += 1000;
	// If the execution reach the the last result set stop the execution
	if (extras.length < 1000)
	{
	bolStop = true;
	}
	}

	return result;
	}

	function searchUnion(target, array)
	{
	return target.concat(array); // TODO: use _.union
	}
	function eliminateDuplicates(arr) 
	{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
	obj[arr[i]]=0;
	}
	for (i in obj) {
	out.push(i);
	}
	return out;
	}
	function postingPeriod(date)
	{
			date=nlapiStringToDate(date);
	var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
	var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
	var Dt1 = nlapiDateToString(startDate);
	var Dt2 = nlapiDateToString(endDate);
	var filters = new Array();
	filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
	filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
	filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
	filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
	//filters[4] = new nlobjSearchFilter('closed',null,'is','F');

	var columns = new Array();
	columns[0] = new nlobjSearchColumn('internalid');
	columns[1] = new nlobjSearchColumn('closed');
	var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters, columns);
	var periodId=''
	if(searchAccPeriods!=null && searchAccPeriods!='')
	{
	var isclosedperiod = searchAccPeriods[0].getValue('closed');
	if(isclosedperiod!='T')
	{
	periodId=searchAccPeriods[0].getValue('internalid');
	}
	else
	{
	var filters1 = new Array();
	filters1[0] = new nlobjSearchFilter('startdate', null, 'onorafter', Dt1);
	filters1[1] = new nlobjSearchFilter('enddate', null, 'onorafter', Dt2);
	filters1[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
	filters1[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
	filters1[4] = new nlobjSearchFilter('closed',null,'is','F');

	var columns1 = new Array();
	columns1[0] = new nlobjSearchColumn('internalid');
	columns1[1] = new nlobjSearchColumn('enddate');
	columns1[1].setSort();
	var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters1, columns1);
	if(searchAccPeriods!=null && searchAccPeriods!='')
	{
	periodId=searchAccPeriods[0].getValue('internalid');
	}
	}
	}

	return periodId;
	 }