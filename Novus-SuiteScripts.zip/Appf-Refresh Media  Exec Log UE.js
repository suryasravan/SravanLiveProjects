/*
* Script Name : Appf-Refresh Bill PO Lines Exec Log UE
* Script Type : UserEvent
* Event Type  : BeforeLoad
* Description : This script adds "Refresh" button on DOMedia - Media Ocean Execution Log Custom record, on click it updates the processing sttaus
* Company     :	Appficiency Inc.
*/

var BTN_REFRESH = 'custpage_refresh';
var FLD_BILL_PO_LINES_EXEC_LOG = 'custbody_appf_bill_po_lines_log';

var CUSTOM_RECORD_OCEAN_FILE = 'customrecord_appf_media_ocean_file_log';
var CUSTOM_FLD_ACD_STATUS = 'custrecord_appf_acd_status';
var CUSTOM_FLD_OCEN_CLIENT = 'custrecord_appf_media_ocean_client';
var CUSTOM_FLD_ESTIMATE = 'custrecord_dds_estimate';
var CUSTOM_FLD_FILE = 'custrecord_med_ocean_sl_data_file';
var FLD_DOMEDIA_OCEAN_LOG_CSV_DATA_FILE = 'custrecord_domed_ocean_csv_data';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_TO_PROCESS = 'custrecord_num_lines_selected';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED = 'custrecord_domed_ocean_processed';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED = 'custrecord_domed_ocean_failed';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT = 'custrecord_demed_ocean_processed_percent';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_STATUS = 'custrecord_ocean_file_proc_status';

function userEventBeforeLoadRefresh(type, form, request)
{
	if(type == 'view')
	{
		var recId=nlapiGetRecordId();
		var recType=nlapiGetRecordType();
      var record = nlapiLoadRecord(recType, recId);
		var processPercent = record.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT);
      if (processPercent != null && processPercent != '')
        {
          processPercent = processPercent.replace('%', '');
        }
      nlapiLogExecution('debug', 'processing percent', processPercent);
	                if(Number(processPercent)!=100)
					form.addButton(BTN_REFRESH, 'Refresh', 'location.reload();'); 

	}
}

