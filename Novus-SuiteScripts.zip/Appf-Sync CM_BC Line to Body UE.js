/*
 * Script Name : Appf-Sync CM/BC Line to Body UE
 * Script Type : UserEvent
 * Event Type  : After Submit
 * Version    Date            Author           		Remarks
 * 1.00       22-Jun-2020     Laxmikanth            This script syncs line field data to respective body fields based on fields defined in company preferences    									
 *
 * Company 	 : Appficiency. 
 */

var SPARAM_CM_SYNC_LINE_TO_BODY = 'custscript_appf_cm_line_to_body';
var SPARAM_BC_SYNC_LINE_TO_BODY = 'custscript_appf_bc_line_to_body';


function syncLineToBody(type)
{
     if(type!='delete')
	{
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
		var creditRecord = nlapiLoadRecord(recordType, recordId)
		var scriptParamBCCMLineFields=''
		var context= nlapiGetContext()
		  if(recordType=='creditmemo')
		  {
	         scriptParamBCCMLineFields = context.getSetting('SCRIPT', SPARAM_CM_SYNC_LINE_TO_BODY)
		  }
		  else
		  {
	        scriptParamBCCMLineFields = context.getSetting('SCRIPT', SPARAM_BC_SYNC_LINE_TO_BODY)
		  }
		if(scriptParamBCCMLineFields!=null && scriptParamBCCMLineFields!='')
          {
var vcLineFieldList = scriptParamBCCMLineFields.split(',');
for (var i = 0; i< vcLineFieldList.length; i++)
{
var lineField = vcLineFieldList[i].split('|')[0];
var bodyField = vcLineFieldList[i].split('|')[1];
var lineFieldValue = creditRecord.getLineItemValue('item', lineField, 1);;
if (lineFieldValue == null)
	lineFieldValue = '';

	 creditRecord.setFieldValue(bodyField, lineFieldValue);
}
	 
 nlapiSubmitRecord(creditRecord,true,true);
 
		}
		}
	
}
 