/**
	 * Script Name : Appf - VVCCP Update Script 
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		The script reads data of a search on VVCCP and generates a payment file of type 
	 *													AMEX or MasterCard
	 *
	 * Company 	 : Appficiency. 
*/

var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var APPF_VVCCP_SFTP_SL_SCRIPT_ID='customscript_appf_vvccp_sftp_send_sl';
var APPF_VVCCP_SFTP_SL_DEPLOY_ID='customdeploy_appf_vvccp_sftp_send_sl';

//VVCCP
var CUSTOM_RECORD_VVCCP='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_UPDATES_RELATED_FILES_FOLDERID =979;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9
var CORPORATE_CREDIT_CARD_VVCCP='custentity_appf_vvccp_corporate_cc';
var FLD_VENDOR_PAYMENT_TYPE='custentity_appf_vendorpaymenttype';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var CUSTOM_RECORD_CORPORATE_CREDIT_CARDS='customrecord_appf_corp_card_table';
var FLD_CREDIT_CARD_TYPE='custrecord_appf_corp_credit_card_type';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias'

var SPARAM_COMPONY_EXPIRATION_DAY='custscript_appf_company_expiration_date';
var SPARAM_VVCCP_UPDATE_SEARCH='custscript_vvccp_update_search';
var TRANSACTION_TYPE_ADD='A';
var TRANSACTION_TYPE_DELETE='D';
var TRANSACTION_TYPE_MODIFY='M';

var NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID=2;
var NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID=7;

var STR_PAD_LEFT = 1;
var STR_PAD_RIGHT = 2;
var STR_PAD_BOTH = 3;

var USD=1;
var CAD=3;
var production='PRODUCTION';
var test ='3619984_SB2';

function schedule(type)
{
	try
	{
	var d = new Date();
	var mmddyyyy_hhmm=(d.getMonth()+1).toString()+d.getDate().toString()+d.getFullYear().toString()+'_'+d.getHours().toString()+d.getMinutes().toString();
	var timeStamp = d.getTime();	
	var context=nlapiGetContext();
	var expirationDayFromParam=context.getSetting('SCRIPT', SPARAM_COMPONY_EXPIRATION_DAY);
	var vvccpUpdateSearchParam=context.getSetting('SCRIPT', SPARAM_VVCCP_UPDATE_SEARCH);
	var companyInfo=nlapiLoadConfiguration('companyinformation');
	var transactionenviornment=context.getEnvironment();
	nlapiLogExecution('debug','transactionenviornment:',transactionenviornment);
	var vvccpFilters=[];
	var vvccpColumns=[];
	if(vvccpUpdateSearchParam !=null && vvccpUpdateSearchParam !='')
	{
		var vvccpUpdateSearch=nlapiLoadSearch(null, vvccpUpdateSearchParam);
		var vvccpUpdateSearchFilts = vvccpUpdateSearch.getFilters();
		var vvccpUpdateSearchColumns=vvccpUpdateSearch.getColumns();
		var vvccpUpdateSearchSSType = vvccpUpdateSearch.getSearchType();
	var vvccpRecordSearch=getAllSearchResults(vvccpUpdateSearchSSType,vvccpUpdateSearchFilts,vvccpUpdateSearchColumns);
	if(vvccpRecordSearch !=null && vvccpRecordSearch !='')
	{
		var totalvvccpLength=vvccpRecordSearch.length;
		var vendorPaymentFileMasterCardTypeUSA='';
		var vendorPaymentFileMasterCardTypeCANADA='';
		var vendorPaymentFileAmexType='';
		var fileFormatForAMEX='';
		var fileFormatForMasterCardUSA='';
		var fileFormatForMasterCardCANADA='';
		var booleanForAmex=false;
		var booleanForMasterCardUSA=false;
		var booleanForMasterCardCANADA=false;
		var totalVVCCPAMEXLength=0;
		var totalVVCCPAMEXLengthfor222=0;
		var amexTypeVVCCP=[];
		var masterCardTypeUsaVVCCP=[];
		var masterCardTypeCanadaVVCCP=[];
		var mcCounterUSA = 0;
		var mcCounterCA = 0;
		for(var v=0;v<vvccpRecordSearch.length;v++)
		{
			var vvccpRecordSearchResult=vvccpRecordSearch[v];
			var vvccpInternalId=vvccpRecordSearchResult.getId();
			var vendor=vvccpRecordSearchResult.getValue(FLD_VENDOR);
			var corporateCreditCard=vvccpRecordSearchResult.getValue(FLD_CORPORATE_CREDIT_CARD);
			
			var vvccpStatus=vvccpRecordSearchResult.getValue(FLD_VVCCP_STATUS);
			var vvccpName=vvccpRecordSearchResult.getValue('name');
			var vvccpDateCreated=vvccpRecordSearchResult.getValue('created');
			var minPurchaseAmount=vvccpRecordSearchResult.getValue(FLD_MINIMUM_TO_SPEND);
			var authorizationAmount=vvccpRecordSearchResult.getValue(FLD_MAXIMUM_TO_SPEND);
			var cardTypeSingleOrMulti=vvccpRecordSearchResult.getValue(FLD_TYPE);
			var vvccpCurrency=vvccpRecordSearchResult.getValue(FLD_CURRENCY);
			//nlapiLogExecution('debug','vvccpCurrency:',vvccpCurrency);
			var primarySubSidiaryOfVendor=vvccpRecordSearchResult.getValue('subsidiary',FLD_VENDOR,null);
			//nlapiLogExecution('debug','primarySubSidiaryOfVendor:',primarySubSidiaryOfVendor);
			var vvccpBatchLink=vvccpRecordSearchResult.getValue(FLD_VVCCP_BATCH_LINK);
			var creditCardType=vvccpRecordSearchResult.getValue(FLD_CREDIT_CARD_TYPE,FLD_CORPORATE_CREDIT_CARD);
			var cropCreditCardAlias=vvccpRecordSearchResult.getValue(FLD_CROP_CREDIT_CARD_ALIAS,FLD_CORPORATE_CREDIT_CARD);
			var dateOfVvccpBatchRec='';
			if(vvccpBatchLink !=null && vvccpBatchLink !='')
			{	
				dateOfVvccpBatchRec=nlapiLookupField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH,vvccpBatchLink,'created');
				dateOfVvccpBatchRec=nlapiStringToDate(dateOfVvccpBatchRec,'datetime');
				//nlapiLogExecution('debug','dateOfVvccpBatchRec:',dateOfVvccpBatchRec);
			}
			
			if(v == 0)
				{
					vendorPaymentFileAmexType+='0101';																			//column 8
					vendorPaymentFileAmexType+=pad(formatDate(new Date()),8 ,' ')+'\n';											//column 9
					
					if(transactionenviornment == production)
					fileFormatForAMEX='267235.'+returnDateInUtcFormat(new Date())+  randomString(5)+'.eap';
					if(transactionenviornment != production)
					fileFormatForAMEX='267326.'+returnDateInUtcFormat(new Date())+  randomString(5)+'.eap';
					
					vendorPaymentFileMasterCardTypeUSA+='ActionType,RecordId,IssuerId,UserName,IcaNumber,BankNumber,RequestId,SupplierName,MinPurchaseAmount,MaxPurchaseAmount,PurchaseCurrency,PurchaseType,VCardAlias,MultiUse,ValidFrom,ValidTo,ValidFor,CDF_PaymentAuthorizationId,CDF_PaymentAuthorizationNumber,CDF_PaymentAuthorizationCreationDate,CDF_CreditCardAlias,CDF_VendorRemittanceStreet,CDF_VendorRemittanceCity,CDF_VendorRemittanceState,CDF_VendorRemittanceZip,CDF_VendorRemittanceEmail,CDF_VendorPhone\n';
					vendorPaymentFileMasterCardTypeCANADA+='ActionType,RecordId,IssuerId,UserName,IcaNumber,BankNumber,RequestId,SupplierName,MinPurchaseAmount,MaxPurchaseAmount,PurchaseCurrency,PurchaseType,VCardAlias,MultiUse,ValidFrom,ValidTo,ValidFor,CDF_PaymentAuthorizationId,CDF_PaymentAuthorizationNumber,CDF_PaymentAuthorizationCreationDate,CDF_CreditCardAlias,CDF_VendorRemittanceStreet,CDF_VendorRemittanceCity,CDF_VendorRemittanceState,CDF_VendorRemittanceZip,CDF_VendorRemittanceEmail,CDF_VendorPhone\n';
					fileFormatForMasterCardUSA='Novutevweri_FPCR#SJA_'+mmddyyyy_hhmm;	
					fileFormatForMasterCardCANADA='Novutevweri_FPCR#SYL_'+mmddyyyy_hhmm;
					
				}
			if(creditCardType !='' && creditCardType !=null)
			{
			if(parseInt(creditCardType) == CREDIT_CARD_TYPE_AMEX)
			{
				amexTypeVVCCP.push(vvccpInternalId);
				nlapiLogExecution('debug','creditCardType in Amex condition:',creditCardType);
				booleanForAmex=true;
				vendorPaymentFileAmexType+='0201';										//column 14
				if(vvccpStatus == VVCCP_STATUS_PENDING_BATCH)
					vendorPaymentFileAmexType+=TRANSACTION_TYPE_ADD;					//column 15
				if(vvccpStatus == VVCCP_STATUS_CANCELLED)
					vendorPaymentFileAmexType+=TRANSACTION_TYPE_DELETE;					//column 15
				
				
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_SINGLE_USE)
					vendorPaymentFileAmexType+=pad('NOVUSVNG',15,' ');				//column 17
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_MULTI_USE)
					vendorPaymentFileAmexType+=	pad('NOVUSVNGMULTI', 15,' ');			//column 17
				
				vendorPaymentFileAmexType += pad(' ',87,' ');
				
				vendorPaymentFileAmexType+='N';											//column 28
				vendorPaymentFileAmexType += pad(' ',9,' ');
				vendorPaymentFileAmexType+=	pad('NOVUSBATCH',15,' ');					//column 31
				vendorPaymentFileAmexType+=	pad(vvccpName.substr(2),15,' ');			//column 33
				var addedZerosNumber='';
				var amount='';
				if(authorizationAmount !=null && authorizationAmount !='' && parseFloat(authorizationAmount) < 9999999.99)
				{
					
					var removeDecimalSyMbolFromAmount=authorizationAmount.toString().split('.')[0]+authorizationAmount.toString().split('.')[1];	
					vendorPaymentFileAmexType+=	pad(removeDecimalSyMbolFromAmount,11 ,0,STR_PAD_LEFT);		//column 35
				}
				vendorPaymentFileAmexType+=	pad(formatDate(new Date()),8 ,' ');								//column 37
				var expiredate='';
				if(expirationDayFromParam)
				{
					expiredate=addingDaysToCurrentDate(new Date(), expirationDayFromParam);
				}
				if(expiredate)
				vendorPaymentFileAmexType+=	pad(formatDate(expiredate),8 , ' ')+ pad(' ',726, ' ')+'\n';				//column 39
				else
				vendorPaymentFileAmexType+=	pad(' ',8 ,' ')+ pad(' ',726, ' ')+'\n';                                 //column 39
              
				vendorPaymentFileAmexType+=	pad('0222',4 , ' ');													//column 63
				vendorPaymentFileAmexType += pad(' ',320,' ');

				vendorPaymentFileAmexType+=	pad(vvccpInternalId,40 ,' ');											//column 72
				vendorPaymentFileAmexType+=	pad(vvccpName,40 , ' ');												//column 74
				vendorPaymentFileAmexType+=	pad(returnDateInUtcFormat(nlapiStringToDate(vvccpDateCreated,'datetime')),40 , ' ');   //column 76
				vendorPaymentFileAmexType+=	pad(' ',456 ,' ')+'\n';
				totalVVCCPAMEXLength =parseFloat(totalVVCCPAMEXLength)+1;
				totalVVCCPAMEXLengthfor222=parseFloat(totalVVCCPAMEXLengthfor222)+1
			}	
			if(parseInt(creditCardType) == CREDIT_CARD_TYPE_MASTERCARD && vvccpCurrency == 1)
			{
				masterCardTypeUsaVVCCP.push(vvccpInternalId);
				
				nlapiLogExecution('debug','creditCardType in Master condition:',creditCardType);
				booleanForMasterCardUSA=true;
				if(vvccpStatus == VVCCP_STATUS_PENDING_BATCH)
				vendorPaymentFileMasterCardTypeUSA+='CreateApprovedPurchase'+',';										//column 3
				if(vvccpStatus == TRANSACTION_TYPE_DELETE)
				vendorPaymentFileMasterCardTypeUSA+='CancelApprovedPurchase'+',';										//column 3
				mcCounterUSA = parseInt(mcCounterUSA)+1
				vendorPaymentFileMasterCardTypeUSA+=mcCounterUSA+',';															//column 4
				
				if(transactionenviornment == production)
				{
					//nlapiLogExecution('debug','transactionenviornment-production:',transactionenviornment);					
					vendorPaymentFileMasterCardTypeUSA+=4+',';															//column 5
				}
				if(transactionenviornment != production)
				{
					//nlapiLogExecution('debug','transactionenviornment-test:',transactionenviornment);
					vendorPaymentFileMasterCardTypeUSA+=5+',';												//column 5
				}
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeUSA+='0011973'+',';										//column 6
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeUSA+='0014235'+',';										//column 6
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeUSA+='2764'+',';											//column 7
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeUSA+='3939'+',';											//column 7
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeUSA+='00000001813'+',';									//column 8
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeUSA+='00000004628'+',';									//column 8
					vendorPaymentFileMasterCardTypeUSA+=vvccpName.substr(2)+',';							//column 9
					vendorPaymentFileMasterCardTypeUSA+='NOVUS Supplier'+',';								//column 10
					
					vendorPaymentFileMasterCardTypeUSA+=minPurchaseAmount+',';								//column 12
					vendorPaymentFileMasterCardTypeUSA+=authorizationAmount+',';							//column 13
				if(vvccpCurrency == USD)
					vendorPaymentFileMasterCardTypeUSA+=840+',';											//column 14
				if(vvccpCurrency == CAD)
					vendorPaymentFileMasterCardTypeUSA+=124+',';											//column 14
				vendorPaymentFileMasterCardTypeUSA+='NOVUSBATCH'+',';										//column 15
				if(cropCreditCardAlias)
					vendorPaymentFileMasterCardTypeUSA+=cropCreditCardAlias+',';							//column 16
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_SINGLE_USE)
					vendorPaymentFileMasterCardTypeUSA+='F'+',';											//column 17
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_MULTI_USE)
					vendorPaymentFileMasterCardTypeUSA+='T'+',';											//column 17
				vendorPaymentFileMasterCardTypeUSA+=returnDateInUtcFormat(new Date())+',';  //column 18
				if(expirationDayFromParam)
				{
					var expirationDateForMasterCardType=addingDaysToCurrentDate(new Date(), expirationDayFromParam)
					vendorPaymentFileMasterCardTypeUSA+=returnDateInUtcFormat(expirationDateForMasterCardType)+',';	     //column 19
					vendorPaymentFileMasterCardTypeUSA+=expirationDayFromParam+',';									     //column 20
				}
				vendorPaymentFileMasterCardTypeUSA+=vvccpInternalId+',';		//column 21
				vendorPaymentFileMasterCardTypeUSA+=vvccpName+',';				//column 22
				vendorPaymentFileMasterCardTypeUSA+=returnDateInUtcFormat(nlapiStringToDate(vvccpDateCreated,'datetime'))+',';   //column 23
				
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 24
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 25
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 26
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 27
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 28
				vendorPaymentFileMasterCardTypeUSA+=''+',';							//column 29
				vendorPaymentFileMasterCardTypeUSA+=''+'\n';						//column 30
				//nlapiLogExecution('debug','vendorPaymentFileMasterCardTypeUSA:',vendorPaymentFileMasterCardTypeUSA);	
			}
			if(parseInt(creditCardType) == CREDIT_CARD_TYPE_MASTERCARD && vvccpCurrency == 3)
			{
				masterCardTypeCanadaVVCCP.push(vvccpInternalId);
				nlapiLogExecution('debug','creditCardType in Master condition:',creditCardType);
				booleanForMasterCardCANADA=true;
				if(vvccpStatus == VVCCP_STATUS_PENDING_BATCH)
				vendorPaymentFileMasterCardTypeCANADA+='CreateApprovedPurchase'+',';					//column 3
				if(vvccpStatus == TRANSACTION_TYPE_DELETE)
				vendorPaymentFileMasterCardTypeCANADA+='CancelApprovedPurchase'+',';					//column 3
				vendorPaymentFileMasterCardTypeCANADA+=v+1+',';											//column 4
				
				if(transactionenviornment == production)				
					vendorPaymentFileMasterCardTypeCANADA+=4+',';										//column 5
				if(transactionenviornment != production)
					vendorPaymentFileMasterCardTypeCANADA+=5+',';										//column 5
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeCANADA+='0011973'+',';								//column 6
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeCANADA+='0014235'+',';								//column 6
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeCANADA+='2764'+',';									//column 7
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeCANADA+='3939'+',';									//column 7
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID)
					vendorPaymentFileMasterCardTypeCANADA+='00000001813'+',';							//column 8
				if(primarySubSidiaryOfVendor == NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID )	
					vendorPaymentFileMasterCardTypeCANADA+='00000004628'+',';							//column 8
					vendorPaymentFileMasterCardTypeCANADA+=vvccpName.substr(2)+',';						//column 9
					vendorPaymentFileMasterCardTypeCANADA+='NOVUS Supplier'+',';						//column 10
					
					vendorPaymentFileMasterCardTypeCANADA+=minPurchaseAmount+',';						//column 12
					vendorPaymentFileMasterCardTypeCANADA+=authorizationAmount+',';						//column 13
				if(vvccpCurrency == USD)
					vendorPaymentFileMasterCardTypeCANADA+=840+',';										//column 14
				if(vvccpCurrency == CAD)
					vendorPaymentFileMasterCardTypeCANADA+=124+',';										//column 14
				vendorPaymentFileMasterCardTypeCANADA+='NOVUSBATCH'+',';								//column 15
				if(cropCreditCardAlias)
					vendorPaymentFileMasterCardTypeCANADA+=cropCreditCardAlias+',';						//column 16
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_SINGLE_USE)
					vendorPaymentFileMasterCardTypeCANADA+='F'+',';										//column 17
				if(cardTypeSingleOrMulti == VVCCP_CARD_TYPE_MULTI_USE)
					vendorPaymentFileMasterCardTypeCANADA+='T'+',';										//column 17
				vendorPaymentFileMasterCardTypeCANADA+=returnDateInUtcFormat(new Date())+',';          //column 18
				if(expirationDayFromParam)
				{
					var expirationDateForMasterCardType=addingDaysToCurrentDate(new Date(), expirationDayFromParam)
					vendorPaymentFileMasterCardTypeCANADA+=returnDateInUtcFormat(expirationDateForMasterCardType)+',';	//column 19
					vendorPaymentFileMasterCardTypeCANADA+=expirationDayFromParam+',';									//column 20
				}
				vendorPaymentFileMasterCardTypeCANADA+=vvccpInternalId+',';												 //column 21
				vendorPaymentFileMasterCardTypeCANADA+=vvccpName+',';														 //column 22
				vendorPaymentFileMasterCardTypeCANADA+=returnDateInUtcFormat(nlapiStringToDate(vvccpDateCreated,'datetime'))+',';                         //column 23
				
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 24
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 25
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 26
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 27
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 28
				vendorPaymentFileMasterCardTypeCANADA+=' '+',';															//column 29
				vendorPaymentFileMasterCardTypeCANADA+=' '+'\n';														//column 30
				//nlapiLogExecution('debug','vendorPaymentFileMasterCardTypeCANADA:',vendorPaymentFileMasterCardTypeCANADA);
			}
			
			}
			if(v == vvccpRecordSearch.length -1)
				{
					vendorPaymentFileAmexType+='0999';       													//91 column 
					vendorPaymentFileAmexType+=pad(totalVVCCPAMEXLength.toString(),11,0,STR_PAD_LEFT);			//92 column											
					vendorPaymentFileAmexType+=pad(totalVVCCPAMEXLengthfor222.toString(),11,0,STR_PAD_LEFT);	//94 column
					vendorPaymentFileAmexType+=pad('00000000000',11,0,STR_PAD_LEFT);							//96 column
					vendorPaymentFileAmexType+=pad(parseFloat(totalVVCCPAMEXLength+totalVVCCPAMEXLengthfor222).toString(),11,0,STR_PAD_LEFT);	//98 column
					vendorPaymentFileAmexType+=pad(' ',852,' ');
				}
			} //main for loop for vvccp end
			nlapiLogExecution('debug','vendorPaymentFileAmexType:',vendorPaymentFileAmexType);
			var url=nlapiResolveURL('SUITELET', APPF_VVCCP_SFTP_SL_SCRIPT_ID, APPF_VVCCP_SFTP_SL_DEPLOY_ID,'external');
			nlapiLogExecution('debug','url:',url);
			nlapiLogExecution('debug','suiteletUrl:',url);
				
			if(booleanForAmex)
			{
				var fileAmexType=nlapiCreateFile(fileFormatForAMEX, 'PLAINTEXT', vendorPaymentFileAmexType);
				fileAmexType.setFolder(VVCCP_UPDATES_RELATED_FILES_FOLDERID);
				var fileAmexId=nlapiSubmitFile(fileAmexType);
				var fileurl = url + '&fileID='+fileAmexId+'&creditCardType='+CREDIT_CARD_TYPE_AMEX;
				var suiteletResponse=nlapiRequestURL(fileurl);
			if(suiteletResponse)
			nlapiLogExecution('debug','suiteletResponse:',suiteletResponse.getCode());
				if(amexTypeVVCCP !=null && amexTypeVVCCP !='')
				{
					for(var i=0;i<amexTypeVVCCP.length;i++)
					{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, amexTypeVVCCP[i], [FLD_AUTHORIZATION_REQUEST_FILE,FLD_VVCCP_STATUS], [fileAmexId,VVCCP_STATUS_PENDING_RESPONSE])
					}
				}				
			}
			if(booleanForMasterCardUSA)
			{
				var fileMasterdayTypeTypeUSA=nlapiCreateFile(fileFormatForMasterCardUSA, 'PLAINTEXT', vendorPaymentFileMasterCardTypeUSA);
				fileMasterdayTypeTypeUSA.setFolder(VVCCP_UPDATES_RELATED_FILES_FOLDERID);
				var fileMasterCardUsaId=nlapiSubmitFile(fileMasterdayTypeTypeUSA);
				var fileurl = url + '&fileID='+fileMasterCardUsaId+'&creditCardType='+CREDIT_CARD_TYPE_MASTERCARD;
				var suiteletResponse=nlapiRequestURL(fileurl);
			if(suiteletResponse)
			nlapiLogExecution('debug','suiteletResponse:',suiteletResponse.getCode());
				if(masterCardTypeUsaVVCCP !=null && masterCardTypeUsaVVCCP !='')
				{
					for(var m=0;m<masterCardTypeUsaVVCCP.length;m++)
					{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, masterCardTypeUsaVVCCP[m], [FLD_AUTHORIZATION_REQUEST_FILE,FLD_VVCCP_STATUS], [fileMasterCardUsaId,VVCCP_STATUS_PENDING_RESPONSE])
					}
				}
			}
			if(booleanForMasterCardCANADA)
			{
				var fileMasterdayTypeTypeCANADA=nlapiCreateFile(fileFormatForMasterCardCANADA, 'PLAINTEXT', vendorPaymentFileMasterCardTypeCANADA);
				fileMasterdayTypeTypeCANADA.setFolder(VVCCP_UPDATES_RELATED_FILES_FOLDERID);
				var fileMasterCardCanadaId=nlapiSubmitFile(fileMasterdayTypeTypeCANADA);
				var fileurl = url + '&fileID='+fileMasterCardCanadaId+'&creditCardType='+CREDIT_CARD_TYPE_MASTERCARD;
				var suiteletResponse=nlapiRequestURL(fileurl);
			if(suiteletResponse)
			nlapiLogExecution('debug','suiteletResponse:',suiteletResponse.getCode());				
				if(masterCardTypeCanadaVVCCP !=null && fileMasterCardUsaId !='')
				{
					for(var c=0;c<masterCardTypeCanadaVVCCP.length;c++)
					{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, masterCardTypeCanadaVVCCP[c], [FLD_AUTHORIZATION_REQUEST_FILE,FLD_VVCCP_STATUS], [fileMasterCardCanadaId,VVCCP_STATUS_PENDING_RESPONSE])
					}
				}
			}			
	}
	}
}
catch(e)
{
	nlapiLogExecution('debug','Error Deatils:',e.toString());
}
}	


function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
		


function pad(str, len, pad, dir) 
{
    if (typeof(len) == "undefined") 
	{ 
		var len = 0; 
	}
    if (typeof(pad) == "undefined") 
	{ 
		var pad = ' '; 
	}
    if (typeof(dir) == "undefined") 
	{ 
		var dir = STR_PAD_RIGHT;
	}
    if (len >= str.length) 
	{
			switch (dir)
			{
				case STR_PAD_LEFT:            
                str = Array(len + 1 - str.length).join(pad) + str;
				break;
				case STR_PAD_BOTH:
                var right = Math.ceil((padlen = len - str.length) / 2);
                var left = padlen - right;
                str = Array(left+1).join(pad) + str + Array(right+1).join(pad);
				break;
				default:
                str = str + Array(len + 1 - str.length).join(pad);
				break;
			} // switch
    }
	else
	{
		str=str.slice(0,len);
	}
    return str;
}

function formatDate(date) {
    var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear().toString().substr(-2);
	var century=d.getFullYear().toString().substr(0,2);
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return century.toString()+year.toString()+month.toString()+day.toString();
}
	
function addingDaysToCurrentDate(fromDate,days) {
    var count = 0;
    while (count < days) {
        fromDate.setDate(fromDate.getDate() + 1);
            count++;
    }
    return fromDate;
}
	
function returnDateInUtcFormat(date)
{
	var utcDate=date.toISOString().split('.')[0];
	return utcDate;
}
function randomString(length) {
	var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}	