/*
* Script Name : Appf -PWP Status Update Outbound - SCH
* Script Type : UserEvent
* Event Type  : After Submit
* Description : This script triggers on submit of PWP or status update, prepares raw JSON, makes a secured connection to Azure SB, send the json to queue and creates the custom record with linking record and response
* Company     :	Appficiency Inc.
*/

  var FLD_BUYING_SYSTEM='custrecord_appf_pwp_buying_system';
  var FLD_O_FROM='custrecord_appf_trigger_ob_integration';
  var CUSTOMRECORD_PTA='customrecord_appf_pwp_wrapper_record'
  
 var CUSTOMRECORD_APPF_OUT_BOUND_MEDIA_RECS='customrecord_appf_domedia_pwp_out';
 var CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTENTS ='custrecord_appf_jsonconetnt_out_pwp';
 var CUSTOMRECORD_FLD_APPF_PWP_LINK='custrecordpwp_record';
 var CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE ='custrecord_appf_azureresponse_pwp';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME='custrecord_appf_strata_vendor_out_pwp';
 var CUSTOMRECORD_FLD_APPF_STATUS='custrecord_domedia_status'
 
 var CUSTOMRECORD_APPF_OUT_BOUND_DIGITAL_MEDIA_RECS='customrecord_appf_pwp_wrapper_record';
 var CUSTOMRECORD_FLD_APPF_OUT_DIGITAL_MEDIA_JSON_CONTENTS ='custrecord_digital_media_jsonconetnt_out';
 var CUSTOMRECORD_FLD_APPF_DIGITAL_MEDIA_PWP_LINK='custrecord_digital_media_pwp_record';
 var CUSTOMRECORD_FLD_APPF_DIGITAL_MEDIA_AZURE_RESPONSE ='custrecord_digital_med_azureresponse_pwp';
 var CUSTOMRECORD_FLD_APPF_DIGITAL_MEDIA_QUEU_NAME='custrecord_digital_media_queue_names';
 var CUSTOMRECORD_FLD_APPF_DIGITAL_MEDIA_STATUS='custrecord_digital_media_status'
 
 var CUSTOMRECORD_APPF_OUT_BOUND_STRATA_MEDIA_RECS='customrecord_appf_strata_pwp_out';
 var CUSTOMRECORD_FLD_APPF_STRATA_OUT_JSON_CONTENTS ='custrecord_appf_jsonconetnt_out_pwp_star';
 var CUSTOMRECORD_FLD_APPF_STRATA_PWP_LINK='custrecord_appf_strata_pwp_record';
 var CUSTOMRECORD_FLD_APPF_STRATA_AZURE_RESPONSE ='custrecordappf_strata_azureresponse_pwp';
 var CUSTOMRECORD_FLD_APPF_STRATA_QUEU_NAME='custrecord_appf_strata_pwp_out';
 var CUSTOMRECORD_FLD_APPF_STRATA_MEDIA_STATUS='custrecord_appf_strata_status'
 
 var CUSTOMRECORD_APPF_OUT_BOUND_MERCURRY_MEDIA_RECS='customrecord_appf_mercury_pwp_out';
 var CUSTOMRECORD_FLD_APPF_MERCURRY_OUT_JSON_CONTENTS ='custrecord_appf_jsonconetnt_out_pwp_merc';
 var CUSTOMRECORD_FLD_APPF_MERCURRY_PWP_LINK='custrecord_appf_mercury_pwp_record';
 var CUSTOMRECORD_FLD_APPF_MERCURRY_AZURE_RESPONSE ='custrecord_appf_mercur_azureresponse_pwp';
 var CUSTOMRECORD_FLD_APPF_MERCURRY_QUEU_NAME='custrecord_appf_mercury_pwp_out';
 var CUSTOMRECORD_FLD_APPF_MERCURRY_MEDIA_STATUS='custrecord_appf_mercury_status'
 
 var FLD_PWP_BUYING_SYSTEM = 'custrecord_appf_pwp_buying_system';
 var SPARAM_UPDATE_SS ='custscript_appf_pay_when_paid_ss'
 var MERCURY='1'
 var DOMEDIA='2'
 var DIGITALMEDIA='3'
 var STRATA='4'
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

function sendMessage(type)
{
	  var context = nlapiGetContext();
  var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
	 var ssID = context.getSetting('SCRIPT', SPARAM_UPDATE_SS);
	 nlapiLogExecution('debug','ssID',ssID)
    var loadSS=nlapiLoadSearch(null, ssID);
  	var ssType = loadSS.getSearchType();
	var ssfilts = loadSS.getFilters();
	 nlapiLogExecution('debug','ssType',ssType)
	  var sscolumns=loadSS.getColumns();
	  nlapiLogExecution('debug','ssfilts',ssfilts)
	var searchResults=getAllSearchResults(ssType, ssfilts, sscolumns);
	 nlapiLogExecution('debug','searchResults',searchResults)
  if (searchResults != null && searchResults != '') 
  {
				 nlapiLogExecution('debug','searchResults.length',searchResults.length)
				for(var s = 0; s <searchResults.length; s++) 
				{
					var searchresult = searchResults[s];
					nlapiLogExecution('DEBUG','searchresult',searchresult)
					var recordId= searchresult.getId();
					try{
	    //var recordType=nlapiGetRecordType();
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var payRec=nlapiLoadRecord(CUSTOMRECORD_PTA,recordId);
	   
	   var buyingSystemName = '';
	   var buySysID = payRec.getFieldValue(FLD_PWP_BUYING_SYSTEM);
	   if (buySysID != null && buySysID != '')
         buyingSystemName = buySysID;
		   //buyingSystemName = payRec.getFieldText(FLD_PWP_BUYING_SYSTEM);
	   
		var payRecFields=payRec.getAllFields()
		var queueName='netsuite_buyingsystem_pwp'
		var queueId=payRec.getFieldValue(FLD_BUYING_SYSTEM)
		var isIO=payRec.getFieldValue(FLD_O_FROM)
			var main1={}
		for(var i=0;i<payRecFields.length;i++) 
       {
		     //var main={}
			var fundingRecFieldId=payRecFields[i]
			var fundingRecFieldValue=payRec.getFieldValue(fundingRecFieldId)
			if(fundingRecFieldValue==null)
		      fundingRecFieldValue=''
		      main1[fundingRecFieldId]=fundingRecFieldValue
		} 

var url =URL_BASE+queueName+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":signatures};          

//HEADERS['NServiceBus.EnclosedMessageTypes']='Novus.Integration.NetSuite.PwpHandler.Interfaces.INetSuitePwp';
HEADERS['NServiceBus.EnclosedMessageTypes']='Novus.Framework.Models.Finance.Pwp.Incoming.NetSuite.PwpIncomingMessage';
HEADERS[FLD_PWP_BUYING_SYSTEM]=buyingSystemName;
var response=nlapiRequestURL(url, body, HEADERS, null,'POST');
nlapiLogExecution('debug', 'response',response);
var responseData=response.getBody()
nlapiLogExecution('debug', 'responseData',responseData);
		//nlapiLogExecution('debug', ' responseData',responseData);
		//nlapiSendEmail(1224,'laxmikanth@cloudalp.com','test',JSON.stringify(main1),null,null,null,HEADERS)
		nlapiLogExecution('debug', ' main1',JSON.stringify(main1));
	
		var outboundFlowRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_OUT_BOUND_MEDIA_RECS)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE,responseData)
		if(response.getCode()=='200' || response.getCode()=='201')
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Success')
        else	
	    outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Failed')  
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTENTS,JSON.stringify(main1))
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_PWP_LINK,recordId)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,queueName)
		nlapiSubmitRecord(outboundFlowRecord,true,true)
		if(response.getCode()=='200' || response.getCode()=='201')
		{
			payRec.setFieldValue(FLD_O_FROM,'F')
			nlapiSubmitRecord(payRec,true,true)
			// nlapiLogExecution('debug','searchResults.length','submit')
		}
		 if ( context.getRemainingUsage() <= 500 && (s+1) < searchresults.length )
                      {
                         var status = nlapiScheduleScript(context.getScriptId(), context.getDeploymentId())
                           //if ( status == 'QUEUED' )
                                   break;     
                      }
					}catch(e)
					{
						
					nlapiLogExecution('debug', ' error processing:'+recordId,e);

					}
				}
  }
	
}


 function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
				 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}