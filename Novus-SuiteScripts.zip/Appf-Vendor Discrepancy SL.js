/*Script Name: Appf-Vendor Discrepancy SL
 *Script Type: Suitelet
 *Description: This script will show the Vendor Discrepancy SL with filters. on selecting and apply the filters, it will display the results in the sublist.
 *Company 	 : Appficiency.
 *	Version		Author			Date				Description
 *	1.1			MJ De Asis		Jan 08, 2021		Added client filter
 *	1.2			MJ De Asis		Jan 11, 2021		Requested by Mark Solis to remove filtering by subsidiary
 */
var BTN_APPLY_FILTER = 'custpage_apply_filters';
var CLIENT_SCRIPT = 'customscript_appf_vendor_discrepancy_cl';
var SL_FLD_BUYING_SYSTEM = 'custpage_buying_system';
var SL_FLD_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_DISCREPENCY_TYPE = 'custpage_discrepancy_type';
var SL_FLD_ACTION = 'custpage_action';
var SL_FLD_VB_REF = 'custpage_vb_ref';
var SL_FLD_VB_IO = 'custpage_vb_io';
var SL_FLD_VENDOR = 'custpage_vendor';

/// v1.1
var SL_FLD_CLIENT = 'custpage_client';

var SL_FLD_MEDIA_SUPPLIER = 'custpage_media_supplier';
var SL_FLD_MEDIA_SUPPLIER_STATE = 'custpage_media_supplier_state';
var SL_FLD_CORPORATE_OWNER = 'custpage_corporate_owner';
var SL_FLD_VB_PLACEMENT = 'custpage_vb_placement';
var SL_FLD_VB_BS = 'custpage_vb_bs';
var SL_FLD_DIG_IO = 'custpage_dig_io';
var SL_FLD_VB_ESTIMATE = 'custpage_vb_estimate';
var SL_FLD_VB_LOCATION = 'custpage_vb_location';
var SL_SUBLIST = 'custpage_custom_line';
var SL_COL_INTERNAL_ID = 'custpage_internal_id';
var SL_COL_LINE_ID = 'custpage_line_id';
var SL_COL_UPDATE = 'custpage_update';
var SL_COL_DISCREPANCY_TYPE = 'custpage_discrepancy_type';
var SL_COL_EXISTING_DISCREPANCY_TYPE = 'custpage_existing_discrepancy_type';
var SL_COL_ACTION = 'custpage_action';
var SL_COL_NS_VENDOR_BILL = 'custpage_ns_vendor_bill_number';
var SL_COL_NS_VENDOR_BILL_HIDDEN = 'custpage_ns_vendor_bill_number_hidden';
var SL_COL_PO = 'custpage_po_number';
var SL_COL_VB_LINE_ID = 'custpage_vb_line_id';
var SL_COL_BUYING_SYSTEM = 'custpage_buying_system';
var SL_COL_CLIENT = 'custpage_client';
var SL_COL_CAMPAIGN = 'custpage_campaign';
var SL_COL_CORPORATE_OWNER = 'custpage_corporate_owner';
var SL_FLD_ORIG_VB_DATE = 'custpage_orig_vb_date';
var FLD_SL_CORPORATE_OWNER = 'custpage_sl_corporate_owner';
var FLD_SL_CORPORATE_STATE = 'custpage_sl_corporate_state';
var SL_COL_VENDOR = 'custpage_vendor';
var SL_COL_MEDIA_SPPLIER = 'custpage_media_supplier';
var SL_COL_VB_IO = 'custpage_vb_io';
var SL_COL_PO_IO = 'custpage_po_io';
var SL_COL_VB_CIRC = 'custpage_vb_circ';
var SL_COL_PO_CIRC = 'custpage_po_circ';
var SL_COL_VB_CPM = 'custpage_vb_cpm';
var SL_COL_PO_CPM = 'custpage_po_cpm';
var SL_COL_VB_AMT = 'custpage_vb_amt';
var SL_COL_PO_AMT = 'custpage_po_amt';
var SL_COL_VB_PLACEMENT = 'custpage_vb_replacement';
var SL_COL_PO_REPLACEMENT = 'custpage_po_replacement';
var SL_COL_VB_BS = 'custpage_vb_sb';
var SL_COL_PO_BS = 'custpage_po_bs';
var SL_COL_VB_ESTIMATE = 'custpage_vb_estimate';
var SL_COL_PO_ESTIMATE = 'custpage_po_estimate';
var SL_COL_VB_LOCATION = 'custpage_vb_location';
var SL_COL_PO_MARKET = 'custpage_po_market';
var SL_COL_VB_TAX = 'custpage_vb_tax';
var SL_COL_PO_TAX = 'custpage_po_tax';
var SL_COL_SUBSIDIARY = 'custpage_subsidiary_sublist';
var FLD_COL_VB_MEDIA_SUPPLIER = 'custcol_appf_publisher';
var FLD_COL_CORPORATE_OWNER = 'custcol_appf_corporateowner';
var FLD_COL_IO_NUM = 'custcol_appf_ionum';
var CUSTOM_LIST_BUYING_SYSTEM = 'customlist_appf_buying_system';
var FLD_VB_BUYING_SYSTEM = 'custbody_appf_buying_system';
var SCRIPT_SUITELET = 'customscript_appf_vendor_discrepancy_sl';
var DEPLOY_SUITELET = 'customdeployappf_vendor_discrepancy_sl';
var CUSTOM_LIST_DISCREPANCY_TYPE = 'customlist_appf_discrepancy_type';
var CUSTOM_LIST_DISCREPANCY_ACTION = 'customlist_appf_discrepancy_action';
var CUSTOM_RECORD_MEDIA_SUPPLIER = 'customrecord_appf_media_supplier';
var VALUE_BUYING_SYSTEM_DIGITAL = '3';
var VALUE_BUYING_SYSTEM_OOH = '2';
var VALUE_CANADA = '7';
var FLD_MEDIA_SUPPLIER_STATE = 'custrecord_appf_ms_state';
var FLD_VEND_CORPORATE_OWNER = 'custentity_appf_connex_corporateowner';
var FLD_COL_PLACEMENT_NUMBER = 'custcol_appf_dig_placementnum';
var FLD_COL_BS_NUMBER = 'custcol_appf_dig_ionum';
var FLD_COL_ESTIMATE_NUMBER = 'custcol_appf_do_estimatenum';
var FLD_COL_DISCREPANCY_TYPE = 'custcol_appf_discrepancy_type';
var FLD_COL_ACTION = 'custcol_appf_discrepancy_action';
var SPARAM_DISCREPANT_VB_LINES_SS = 'custscript_appf_discrepant_vb_lines_ss';
var FOLDER_DISCREPANT_VB_LINES = 'custscript_appf_discrepant_vb_lines_fold';
var CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG = 'customrecord_appf_vendor_discrepancy_log';
var FLD_CUST_REC_SELECTED_VB_LINES_FILE = 'custrecord_appf_selected_vb_lines_file';
var FLD_CUST_REC_TOTAL_VB_LINES_SELECTED = 'custrecord_appf_tot_vb_lines_selected';
var FLD_CUST_REC_SELECTED_VENDOR_BILLS = 'custrecord_appf_selected_vend_bills';
var SCRIPT_VENDOR_DISCREPANCY_SC = 'customscript_appf_vendor_discrepancy_sc';
var DEPLOY_VENDOR_DISCREPANCY_SC = 'customdeploy_appf_vendor_discrepancy_sc';
var SPARAM_CUSTOM_REC_ID = 'custscript_appf_vendor_discrepancy_log';
var BTN_MARK_ALL = 'custpage_mark_All';
var BTN_UNMARK_ALL = 'custpage_unmark_All';
var DISCREPANCY_TYPE_LIST_FILTERS = ['7', '2', '10', '5', '11', '23'];
var DISCREPANCY_TYPE_LIST_COLMNS = ['21', '22'];

function vendorDiscrepancySuitelet(request, response) {
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_DISCREPANT_VB_LINES_SS);
	var folderId = context.getSetting('SCRIPT', FOLDER_DISCREPANT_VB_LINES);
	if (request.getMethod() == 'GET') {
		var discrepancyListFilterSS = nlapiSearchRecord('customlist_appf_discrepancy_type', null, new nlobjSearchFilter('internalid', null, 'anyof', DISCREPANCY_TYPE_LIST_FILTERS), new nlobjSearchColumn('name'));
		var discrepancyListColmnsSS = nlapiSearchRecord('customlist_appf_discrepancy_type', null, new nlobjSearchFilter('internalid', null, 'anyof', DISCREPANCY_TYPE_LIST_COLMNS), new nlobjSearchColumn('name'));
		var buyingsystem = request.getParameter('buysystem');
		var subsidiary = request.getParameter('subs');
		var discrepancytype = request.getParameter('discrepancytype');
		var vbref = request.getParameter('vbref');
		var vbio = request.getParameter('vbio');
		var vendor = request.getParameter('vendor');
		var mediasupp = request.getParameter('mediasupp');
		// var mediasuppstate=request.getParameter('mediasuppstate');
		var vbPlacementNum = request.getParameter('vbPlacementNum');
		var vbbs = request.getParameter('vbbs');
		var vbestimate = request.getParameter('vbestimate');
		var origVBDateVal = request.getParameter('origVBDateVal');
		var corporateOwner = request.getParameter('corporateOwner');
		var corporateState = request.getParameter('corporateState');

		/// v1.1
		var client = request.getParameter('client');

		//var vbloc=request.getParameter('vbloc');
		var form = nlapiCreateForm('Vendor Discrepancy Suitelet');
		form.setScript(CLIENT_SCRIPT);
		var buyingSystemFld = form.addField(SL_FLD_BUYING_SYSTEM, 'select', 'Buying System', CUSTOM_LIST_BUYING_SYSTEM);
		if (buyingsystem != null && buyingsystem != '') buyingSystemFld.setDefaultValue(buyingsystem);
		buyingSystemFld.setMandatory(true)
		var subsidiaryField = form.addField(SL_FLD_SUBSIDIARY, 'select', 'Subsidiary', 'subsidiary');
		if (subsidiary != null && subsidiary != '') subsidiaryField.setDefaultValue(subsidiary);
		subsidiaryField.setMandatory(true)
		var discrepancyTypeField = form.addField(SL_FLD_DISCREPENCY_TYPE, 'select', 'Discrepancy Type');
		discrepancyTypeField.addSelectOption('', '');
		if (discrepancyListFilterSS != null && discrepancyListFilterSS != '') {
			for (var v = 0; v < DISCREPANCY_TYPE_LIST_FILTERS.length; v++) {
				for (var d = 0; d < discrepancyListFilterSS.length; d++) {
					if (DISCREPANCY_TYPE_LIST_FILTERS[v] == discrepancyListFilterSS[d].getId()) {
						discrepancyTypeField.addSelectOption(discrepancyListFilterSS[d].getId(), discrepancyListFilterSS[d].getValue('name'));
						break;
					}
				}
			}
		}
		if (discrepancytype != null && discrepancytype != '') discrepancyTypeField.setDefaultValue(discrepancytype);
		var VbRefField = form.addField(SL_FLD_VB_REF, 'text', 'VB Ref#');
		if (vbref != null && vbref != '') VbRefField.setDefaultValue(vbref);
		var VbIOField = form.addField(SL_FLD_VB_IO, 'text', 'IO# / BS#');
		if (vbio != null && vbio != '') VbIOField.setDefaultValue(vbio);

		/// v1.1
		var clientField;
		clientField = form.addField(SL_FLD_CLIENT, 'multiselect', 'Client', 'customer');
		if (client != null && client != '') clientField.setDefaultValue(client);

		/// v1.2
		// if (subsidiary == null || subsidiary == '') {
		// 	clientField = form.addField(SL_FLD_CLIENT, 'select', 'Client', 'customer');
		// }
		// else {
		// 	clientField = form.addField(SL_FLD_CLIENT, 'select', 'Client');
		// 	clientField.addSelectOption('', '');
		// 	var clients = getEntityBySubsidiary(subsidiary, 'customer');
		// 	for (var index in clients) {
		// 		var client_obj = clients[index];
		// 		clientField.addSelectOption(client_obj.id, client_obj.name);
		// 	}
		// }


		var vendorField;
		vendorField = form.addField(SL_FLD_VENDOR, 'select', 'Vendor', 'vendor');
		if (vendor != null && vendor != '') vendorField.setDefaultValue(vendor);

		/// v1.2
		// if (subsidiary == null || subsidiary == '') {
		// 	vendorField = form.addField(SL_FLD_VENDOR, 'select', 'Vendor', 'vendor');
		// }
		// else {
		// 	vendorField = form.addField(SL_FLD_VENDOR, 'select', 'Vendor');
		// 	vendorField.addSelectOption('', '');
		// 	var vendors = getEntityBySubsidiary(subsidiary, 'vendor');
		// 	for (var index in vendors) {
		// 		var vendor_obj = vendors[index];
		// 		vendorField.addSelectOption(vendor_obj.id, vendor_obj.name);
		// 	}
		// }

		var mediaSuppField = form.addField(SL_FLD_MEDIA_SUPPLIER, 'select', 'Media Supplier', CUSTOM_RECORD_MEDIA_SUPPLIER);
		if (mediasupp != null && mediasupp != '') mediaSuppField.setDefaultValue(mediasupp);
		//var mediaSuppStateField = form.addField(SL_FLD_MEDIA_SUPPLIER_STATE, 'text','Media Supplier State');
		//if (mediasuppstate != null && mediasuppstate != '')
		//mediaSuppStateField.setDefaultValue(mediasuppstate);
		var VbPlacementField = form.addField(SL_FLD_VB_PLACEMENT, 'text', 'Placement #');
		VbPlacementField.setDisplayType('disabled');
		if (vbPlacementNum != null && vbPlacementNum != '') VbPlacementField.setDefaultValue(vbPlacementNum);
		var VbBSField = form.addField(SL_FLD_VB_BS, 'text', 'Digital IO #');
		VbBSField.setDisplayType('disabled');
		if (vbbs != null && vbbs != '') VbBSField.setDefaultValue(vbbs);
		if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) {
			VbPlacementField.setDisplayType('normal');
			VbBSField.setDisplayType('normal');
		}
		var VBEstimateField = form.addField(SL_FLD_VB_ESTIMATE, 'text', 'Estimate #');
		VBEstimateField.setDisplayType('disabled');
		if (vbestimate != null && vbestimate != '') VBEstimateField.setDefaultValue(vbestimate);
		//var VBLocField = form.addField(SL_FLD_VB_LOCATION, 'select','Location', 'location');
		//VBLocField.setDisplayType('disabled');
		//if (vbloc != null && vbloc != '')
		//VBLocField.setDefaultValue(vbloc);
		if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) {
			VBEstimateField.setDisplayType('normal');
			//VBLocField.setDisplayType('normal');
		}
		
		
		//2/22/2021 add filters
		var origVBDateFld = form.addField(SL_FLD_ORIG_VB_DATE, 'date', 'Original VB Date');

		if (origVBDateVal != null && origVBDateVal != '') origVBDateFld.setDefaultValue(origVBDateVal);
		
		var corporateOwnerFld = form.addField(FLD_SL_CORPORATE_OWNER, 'text', 'Corporate Owner');
		corporateOwnerFld.setDefaultValue(corporateOwner);
		
		var stateFld = form.addField(FLD_SL_CORPORATE_STATE, 'text', 'State');
		stateFld.setDefaultValue(corporateState);
		
		
		
		if (buyingsystem != null && buyingsystem != '' && subsidiary != null && subsidiary != '') {
			var suiteletSublist = form.addSubList(SL_SUBLIST, 'list', 'Vendor Bill Lines');
			suiteletSublist.addField(SL_COL_INTERNAL_ID, 'text', 'Update').setDisplayType('hidden');
			suiteletSublist.addField(SL_COL_LINE_ID, 'text', 'Update').setDisplayType('hidden');
			var updateCheckBox = suiteletSublist.addField(SL_COL_UPDATE, 'checkbox', 'Update');
			updateCheckBox.setDisplayType('entry');
			updateCheckBox.setDefaultValue('T');
			var discrepancytypeLineField = suiteletSublist.addField(SL_COL_DISCREPANCY_TYPE, 'select', 'Set Action / New Discrepancy Type').setDisplayType('entry');
			discrepancytypeLineField.addSelectOption('', '');
			if (discrepancyListColmnsSS != null && discrepancyListColmnsSS != '') {
				for (var i = 0; i < discrepancyListColmnsSS.length; i++) {
					discrepancytypeLineField.addSelectOption(discrepancyListColmnsSS[i].getId(), discrepancyListColmnsSS[i].getValue('name'));
				}
			}
			suiteletSublist.addField(SL_COL_EXISTING_DISCREPANCY_TYPE, 'text', 'Existing Discrepancy Type').setDisplayType('disabled');
			suiteletSublist.addField(SL_COL_NS_VENDOR_BILL, 'text', 'NS Vendor Bill #');
			suiteletSublist.addField(SL_COL_NS_VENDOR_BILL_HIDDEN, 'text', 'NS Vendor Bill#').setDisplayType('hidden');;
			suiteletSublist.addField(SL_COL_PO, 'text', 'PO #');
			//suiteletSublist.addField(SL_COL_VB_LINE_ID, 'text', 'VB Line ID');

			/// v1.2
			// suiteletSublist.addField(SL_COL_BUYING_SYSTEM, 'text', 'Buying System');
			// //suiteletSublist.addField(SL_COL_SUBSIDIARY, 'select', 'Subsidiary','subsidiary').setDisplayType('hidden');
			// suiteletSublist.addField(SL_COL_CLIENT, 'text', 'Client');
			// suiteletSublist.addField(SL_COL_CAMPAIGN, 'text', 'Campaign');
			// suiteletSublist.addField(SL_COL_VENDOR, 'text', 'Vendor');
			// suiteletSublist.addField(SL_COL_MEDIA_SPPLIER, 'text', 'Media Supplier');
			// suiteletSublist.addField(SL_COL_VB_IO, 'text', 'VB IO #');
			// //suiteletSublist.addField(SL_COL_PO_IO, 'text', 'PO IO #');
			// suiteletSublist.addField(SL_COL_VB_CIRC, 'text', 'VB Circ');
			// suiteletSublist.addField(SL_COL_PO_CIRC, 'text', 'PO Circ');
			// suiteletSublist.addField(SL_COL_VB_CPM, 'text', 'VB CPM');
			// suiteletSublist.addField(SL_COL_PO_CPM, 'text', 'PO CPM');
			// suiteletSublist.addField(SL_COL_VB_AMT, 'text', 'VB Amt');
			// suiteletSublist.addField(SL_COL_PO_AMT, 'text', 'PO Amt');
			var custom_columns = getCustomColumns(ssID);
			for (var index in custom_columns) {
				var column = custom_columns[index];
				suiteletSublist.addField(column.id, 'text', column.name);
			}

			if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) {
				suiteletSublist.addField(SL_COL_VB_PLACEMENT, 'text', 'Placement #');
				//suiteletSublist.addField(SL_COL_PO_REPLACEMENT, 'text', 'PO Replacement#');
				suiteletSublist.addField(SL_COL_VB_BS, 'text', 'BS #');
				//suiteletSublist.addField(SL_COL_PO_BS, 'text', 'PO BS#');
			}
			if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) {
				suiteletSublist.addField(SL_COL_VB_ESTIMATE, 'text', 'Estimate #');
				//suiteletSublist.addField(SL_COL_PO_ESTIMATE, 'text', 'PO Estimate#');
				//suiteletSublist.addField(SL_COL_VB_LOCATION, 'text', 'VB Location');
				//suiteletSublist.addField(SL_COL_PO_MARKET, 'text', 'PO Market');
			}
			//if(subsidiary == VALUE_CANADA)
			//{
			//suiteletSublist.addField(SL_COL_VB_TAX, 'text', 'VB Tax');
			//suiteletSublist.addField(SL_COL_PO_TAX, 'text', 'PO Tax');
			//}
			suiteletSublist.addButton(BTN_MARK_ALL, 'Mark All', 'markAll();')
			suiteletSublist.addButton(BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();')
			if (ssID != null && ssID != '') {
				var loadSS = nlapiLoadSearch(null, ssID);
				var filts = loadSS.getFilters();
				var cols = loadSS.getColumns();
				var ssType = loadSS.getSearchType();
				//nlapiLogExecution('debug','ssType:', ssType);
				var filters = [];
				if (buyingsystem != null && buyingsystem != '') filters.push(new nlobjSearchFilter(FLD_VB_BUYING_SYSTEM, null, 'anyof', buyingsystem));
				if (subsidiary != null && subsidiary != '') filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsidiary));
				if (discrepancytype != null && discrepancytype != '') filters.push(new nlobjSearchFilter(FLD_COL_DISCREPANCY_TYPE, null, 'anyof', discrepancytype));
				if (vbref != null && vbref != '') filters.push(new nlobjSearchFilter('tranid', null, 'is', vbref));
				if (vbio != null && vbio != '') filters.push(new nlobjSearchFilter(FLD_COL_IO_NUM, null, 'is', vbio));
				if (vendor != null && vendor != '') filters.push(new nlobjSearchFilter('name', null, 'anyof', vendor));

				/// v1.1
				//if (client != null && client != '') filters.push(new nlobjSearchFilter('parent', 'job', 'is', client));
				if (client != null && client != '') filters.push(new nlobjSearchFilter('parent', 'job', 'anyof', client));

				if (mediasupp != null && mediasupp != '') filters.push(new nlobjSearchFilter(FLD_COL_VB_MEDIA_SUPPLIER, null, 'anyof', mediasupp));
				//if(mediasuppstate != null && mediasuppstate != '')
				//filters.push(new nlobjSearchFilter(FLD_MEDIA_SUPPLIER_STATE, FLD_COL_VB_MEDIA_SUPPLIER, 'is', mediasuppstate));
				if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) {
					if (vbPlacementNum != null && vbPlacementNum != '') filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_NUMBER, null, 'is', vbPlacementNum));
					if (vbbs != null && vbbs != '') filters.push(new nlobjSearchFilter(FLD_COL_BS_NUMBER, null, 'is', vbbs));
				}
				if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) {
					if (vbestimate != null && vbestimate != '') filters.push(new nlobjSearchFilter(FLD_COL_ESTIMATE_NUMBER, null, 'is', vbestimate));
					//if(vbloc != null && vbloc != '')
					//filters.push(new nlobjSearchFilter('location', null, 'anyof',vbloc));
				}
				
				//orig vb date filter 2/22/2021
				if (origVBDateVal != null && origVBDateVal != '') filters.push(new nlobjSearchFilter('custbody_appf_master_vendor_date', null, 'on', origVBDateVal));
				
				//corporate owner
				//nlapiLogExecution('debug', title, details)
				if(corporateOwner != null && corporateOwner != ''){
					//newFilters.push(new nlobjSearchFilter(FLD_COL_MARKET, null, 'is', market));
					
					var aCorporateOwner =  corporateOwner.split(',');
					//added: 2/19/2021, use filter formula
					var strExpression = "";
					for(var v = 0; v < aCorporateOwner.length; v++){
						if(aCorporateOwner[v] != null && aCorporateOwner[v] != ''){
							
							if(aCorporateOwner[v+1] == ' LLC' || aCorporateOwner[v+1] == ' Inc.'){
								strExpression += "{custcol_appf_publisher.custrecord_appf_ms_corporateowner}= '"+aCorporateOwner[v]+','+aCorporateOwner[v+1]+"'";
								strExpression += " OR ";
							}else{
								strExpression += "{custcol_appf_publisher.custrecord_appf_ms_corporateowner}= '"+aCorporateOwner[v]+"'";
								strExpression += " OR ";
							}

						}
						
					}
					//remove last OR 
					strExpression = strExpression.slice(0, -4)
					
					//var strFormula = "case when {custcol_appf_do_market}= 'Yorkton' OR {custcol_appf_do_market}='Annapolis Royal' then 'yes' else 'no' end";
					var strFormula = "case when "+strExpression+" then 'yes' else 'no' end";
					nlapiLogExecution('debug', 'strFormula', strFormula);
					//var strFormula = "case when {custcol_appf_do_market}= 'Halifax' then 'yes' else 'no' end";
					filters.push(new nlobjSearchFilter('formulatext',null,'is','yes').setFormula(strFormula));	
				}
				
				
				
				//corporate state
				if(corporateState != null && corporateState != ''){
					//newFilters.push(new nlobjSearchFilter(FLD_COL_MARKET, null, 'is', market));
					
					var aCorporateState =  corporateState.split(',');
					//added: 2/19/2021, use filter formula
					var strExpression = "";
					for(var v = 0; v < aCorporateState.length; v++){
						if(aCorporateState[v] != null && aCorporateState[v] != ''){
							strExpression += "{custcol_appf_publisher.custrecord_appf_ms_state}= '"+aCorporateState[v]+"'";
							strExpression += " OR ";
						}
						
					}
					//remove last OR 
					strExpression = strExpression.slice(0, -4)
					
					//var strFormula = "case when {custcol_appf_do_market}= 'Yorkton' OR {custcol_appf_do_market}='Annapolis Royal' then 'yes' else 'no' end";
					var strFormula = "case when "+strExpression+" then 'yes' else 'no' end";
					nlapiLogExecution('debug', 'strFormula', strFormula);
					//var strFormula = "case when {custcol_appf_do_market}= 'Halifax' then 'yes' else 'no' end";
					filters.push(new nlobjSearchFilter('formulatext',null,'is','yes').setFormula(strFormula));	
				}
				
				
				var resultFilters = filters.concat(filts);
				var searchResults = getAllSearchResults(ssType, resultFilters, cols);
				if (searchResults != null && searchResults != '') {
					nlapiLogExecution('debug', 'searchResults length:', searchResults.length);
					var columns = searchResults[0].getAllColumns();
					for (var i = 0; i < searchResults.length; i++) {
						var internalid = searchResults[i].getId();
						var recType = searchResults[i].getRecordType();
						var searchresult = searchResults[i];
						// var memo = searchresult.getValue(columns[0]);
						var discrepancy = searchresult.getText(columns[0]);
						nlapiLogExecution('debug', 'discrepancy:', discrepancy);
						var vbID = searchresult.getValue(columns[1]);
						var poID = searchresult.getValue(columns[2]);
						var vbLineID = searchresult.getValue(columns[3]);
						var buyingSys = searchresult.getText(columns[4]);
						var client = searchresult.getText(columns[5]);
						var campaign = searchresult.getText(columns[6]);
						var vend = searchresult.getText(columns[7]);
						var mediaSupplier = searchresult.getText(columns[8]);
						var vbIOId = searchresult.getValue(columns[9]);
						var vbCirc = searchresult.getValue(columns[10]);
						var poCirc = searchresult.getValue(columns[11]);
						var vbCpm = searchresult.getValue(columns[12]);
						var poCpm = searchresult.getValue(columns[13]);
						var vbLineAmt = searchresult.getValue(columns[14]);
						var poLineAmt = searchresult.getValue(columns[15]);
						var vbPlacement = searchresult.getValue(columns[16]);
						var vbEstimate = searchresult.getValue(columns[17]);
						var vbBsDig = searchresult.getValue(columns[18]);
						var lineID = searchresult.getValue(columns[columns.length - 1]);
						//nlapiLogExecution('debug','vbServiceDate:',vbServiceDate);
						//nlapiLogExecution('debug','poLineAmt:',poLineAmt);
						suiteletSublist.setLineItemValue(SL_COL_INTERNAL_ID, i + 1, internalid);
						suiteletSublist.setLineItemValue(SL_COL_LINE_ID, i + 1, lineID);
						suiteletSublist.setLineItemValue(SL_COL_EXISTING_DISCREPANCY_TYPE, i + 1, discrepancy);
						var url = nlapiResolveURL('RECORD', 'vendorbill', internalid);
						var redirect = '<a href=' + url + ' target="_blank">' + vbID + '</a>';
						suiteletSublist.setLineItemValue(SL_COL_NS_VENDOR_BILL, i + 1, redirect);
						suiteletSublist.setLineItemValue(SL_COL_NS_VENDOR_BILL_HIDDEN, i + 1, vbID);

						suiteletSublist.setLineItemValue(SL_COL_PO, i + 1, poID);
						//suiteletSublist.setLineItemValue(SL_COL_VB_LINE_ID, i+1, vbLineID);

						/// v1.2
						// suiteletSublist.setLineItemValue(SL_COL_BUYING_SYSTEM, i + 1, buyingSys);
						// suiteletSublist.setLineItemValue(SL_COL_CLIENT, i + 1, client);
						// suiteletSublist.setLineItemValue(SL_COL_CAMPAIGN, i + 1, campaign);
						// //suiteletSublist.setLineItemValue(SL_COL_CORPORATE_OWNER, i+1, corpOwner);
						// suiteletSublist.setLineItemValue(SL_COL_VENDOR, i + 1, vend);
						// suiteletSublist.setLineItemValue(SL_COL_MEDIA_SPPLIER, i + 1, mediaSupplier);
						// suiteletSublist.setLineItemValue(SL_FLD_VB_IO, i + 1, vbIOId);
						// //suiteletSublist.setLineItemValue(SL_COL_PO_IO, i+1, poIoId);
						// suiteletSublist.setLineItemValue(SL_COL_VB_CIRC, i + 1, vbCirc);
						// suiteletSublist.setLineItemValue(SL_COL_PO_CIRC, i + 1, poCirc);
						// suiteletSublist.setLineItemValue(SL_COL_VB_CPM, i + 1, vbCpm);
						// suiteletSublist.setLineItemValue(SL_COL_PO_CPM, i + 1, poCpm);
						// suiteletSublist.setLineItemValue(SL_COL_VB_AMT, i + 1, vbLineAmt);
						// suiteletSublist.setLineItemValue(SL_COL_PO_AMT, i + 1, poLineAmt);

						for (var index in custom_columns) {
							var column = custom_columns[index];
							suiteletSublist.setLineItemValue(column.id, i+1, searchresult.getText(column.column) || searchresult.getValue(column.column));
						}


						//suiteletSublist.setLineItemValue(SL_COL_ACTION, i+1, lineAction);
						if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) {
							suiteletSublist.setLineItemValue(SL_COL_VB_PLACEMENT, i + 1, vbPlacement);
							//suiteletSublist.setLineItemValue(SL_COL_PO_REPLACEMENT, i+1, poPlacement);
							suiteletSublist.setLineItemValue(SL_COL_VB_BS, i + 1, vbBsDig);
							//suiteletSublist.setLineItemValue(SL_COL_PO_BS, i+1, poBS);
						}
						if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) {
							suiteletSublist.setLineItemValue(SL_COL_VB_ESTIMATE, i + 1, vbEstimate);
							//suiteletSublist.setLineItemValue(SL_COL_PO_ESTIMATE, i+1, poEstimate);
							//suiteletSublist.setLineItemValue(SL_COL_VB_LOCATION, i+1, vbLocation);
							//suiteletSublist.setLineItemValue(SL_COL_PO_MARKET, i+1, poMarket);
						}
						//if(subsidiary == VALUE_CANADA)
						//{
						//suiteletSublist.setLineItemValue(SL_COL_VB_TAX, i+1, vbTax);
						//suiteletSublist.setLineItemValue(SL_COL_PO_TAX, i+1, poTax);
						//}
					}
				}
			}
		}
		form.addButton(BTN_APPLY_FILTER, 'Apply Filters', 'applyFilters()');
		form.addSubmitButton('Submit Changes');
		response.writePage(form);
	} else {
		var buyingsystem = request.getParameter(SL_FLD_BUYING_SYSTEM);
		var count = request.getLineItemCount(SL_SUBLIST);
		var subsi = request.getParameter(SL_FLD_SUBSIDIARY)
		var csvData = '';
		csvData = 'Internal ID,Line ID,Set Action / New Discrepancy Type,NS Vendor Bill#,PO#,Buying System,Client,Campaign,Vendor,Media Supplier, IO #,VB CIRC,PO CIRC,VB CPM,PO CPM,VB AMT,PO AMT,';
		if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) csvData += 'Placement #,BS #,';
		if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) csvData += 'Estimate #,';
		//if(subsi == VALUE_CANADA)
		//csvData += 'VB Tax,PO Tax,';
		csvData = csvData.slice(0, -1) + '\n';
		var totalselected = 0;
		var selectedVbs = [];
		for (var c = 1; c <= count; c++) {
			var checkBox = request.getLineItemValue(SL_SUBLIST, SL_COL_UPDATE, c);
			if (checkBox == 'T') {
				var internalid = request.getLineItemValue(SL_SUBLIST, SL_COL_INTERNAL_ID, c);
				if (selectedVbs.indexOf(internalid) == -1) {
					selectedVbs.push(internalid);
				}
				var lineID = request.getLineItemValue(SL_SUBLIST, SL_COL_LINE_ID, c);
				var discrepancytype = request.getLineItemValue(SL_SUBLIST, SL_COL_DISCREPANCY_TYPE, c);
				var vendorbill = request.getLineItemValue(SL_SUBLIST, SL_COL_NS_VENDOR_BILL, c);
				var vendorbillHidden = request.getLineItemValue(SL_SUBLIST, SL_COL_NS_VENDOR_BILL_HIDDEN, c);
				var po = request.getLineItemValue(SL_SUBLIST, SL_COL_PO, c);
				// var vbLineId = request.getLineItemValue(SL_SUBLIST,SL_COL_VB_LINE_ID,c);
				var buyingsystem = request.getLineItemValue(SL_SUBLIST, SL_COL_BUYING_SYSTEM, c);
				var client = request.getLineItemValue(SL_SUBLIST, SL_COL_CLIENT, c);
				var campaign = request.getLineItemValue(SL_SUBLIST, SL_COL_CAMPAIGN, c);
				var corporateOwner = request.getLineItemValue(SL_SUBLIST, SL_COL_CORPORATE_OWNER, c);
				var vendor = request.getLineItemValue(SL_SUBLIST, SL_COL_VENDOR, c);
				var mediaSupp = request.getLineItemValue(SL_SUBLIST, SL_COL_MEDIA_SPPLIER, c);
				var vbIo = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_IO, c);
				// var poIo =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_IO,c);
				var vbCirc = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_CIRC, c);
				var poCirc = request.getLineItemValue(SL_SUBLIST, SL_COL_PO_CIRC, c);
				var vbCpm = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_CPM, c);
				var poCpm = request.getLineItemValue(SL_SUBLIST, SL_COL_PO_CPM, c);
				var vbAmt = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_AMT, c);
				var poAmt = request.getLineItemValue(SL_SUBLIST, SL_COL_PO_AMT, c);
				var vbPlacement = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_PLACEMENT, c);
				// var poPlacement =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_REPLACEMENT,c);
				var vbBs = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_BS, c);
				// var poBs =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_BS,c);
				var vbEstimate = request.getLineItemValue(SL_SUBLIST, SL_COL_VB_ESTIMATE, c);
				//var poEstimate =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_ESTIMATE,c);
				//  var vbLoc =request.getLineItemValue(SL_SUBLIST,SL_COL_VB_LOCATION,c);
				//var poMarket =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_MARKET,c);
				//var vbTax =request.getLineItemValue(SL_SUBLIST,SL_COL_VB_TAX,c);
				//var poTax =request.getLineItemValue(SL_SUBLIST,SL_COL_PO_TAX,c);
				// var subsidiary =request.getLineItemText(SL_SUBLIST,SL_COL_SUBSIDIARY,c);
				csvData += internalid + ',' + lineID + ',' + discrepancytype + ',' + vendorbillHidden + ',' + po + ',' + buyingsystem + ',' + client + ',' + campaign + ',' + vendor + ',' + mediaSupp + ',' + vbIo + ',' + vbCirc + ',' + poCirc + ',' + vbCpm + ',' + poCpm + ',' + vbAmt + ',' + poAmt + ',';
				if (buyingsystem == VALUE_BUYING_SYSTEM_DIGITAL) csvData += vbPlacement + ',' + vbBsDig + ',';
				if (buyingsystem == VALUE_BUYING_SYSTEM_OOH) csvData += vbEstimate + ',';
				// if(subsi == VALUE_CANADA)
				//csvData += vbTax+','+poTax+',';
				csvData = csvData.slice(0, -1) + '\n';
				totalselected++;
			}
		}
		var timeStamp = new Date().getTime();
		var csvFile = nlapiCreateFile('SelectedVBLines_' + timeStamp + '.csv', 'CSV', csvData)
		csvFile.setFolder(folderId);
		var fileID = nlapiSubmitFile(csvFile);
		var vendorDiscrepancyLogRec = nlapiCreateRecord(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG);
		// var vendorDiscrepancyLogRec=nlapiLoadRecord(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG, 1);
		if (fileID != null && fileID != '') vendorDiscrepancyLogRec.setFieldValue(FLD_CUST_REC_SELECTED_VB_LINES_FILE, fileID);
		if (totalselected != null && totalselected != '') vendorDiscrepancyLogRec.setFieldValue(FLD_CUST_REC_TOTAL_VB_LINES_SELECTED, totalselected);
		if (selectedVbs.length > 0) {
			vendorDiscrepancyLogRec.setFieldValues(FLD_CUST_REC_SELECTED_VENDOR_BILLS, selectedVbs);
		}
		vendorDiscrepancyLogRecID = nlapiSubmitRecord(vendorDiscrepancyLogRec, true, true);
		if (vendorDiscrepancyLogRecID != null && vendorDiscrepancyLogRecID != '') {
			var params = {};
			params[SPARAM_CUSTOM_REC_ID] = vendorDiscrepancyLogRecID;
			nlapiScheduleScript(SCRIPT_VENDOR_DISCREPANCY_SC, null, params);
			response.sendRedirect('RECORD', CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG, vendorDiscrepancyLogRecID);
		}
	}
}

function getEntityBySubsidiary(subsidiary, entity_type) {
	var clients = [];
	if (subsidiary != null && subsidiary != '') {

		var rs = getAllSearchResults(entity_type,
					[
						new nlobjSearchFilter('subsidiary', null, 'is', subsidiary)
					],
					[
						new nlobjSearchColumn('companyname').setSort(),
						new nlobjSearchColumn('altname').setSort(),
						new nlobjSearchColumn('firstname').setSort(),
						new nlobjSearchColumn('lastname')
					]);

		for (var i=0; i<rs.length; i++) {
			var client = rs[i];
			var client_name = (client.getValue('firstname') + ' ' + client.getValue('lastname')).trim();
			client_name = client_name.length == 0 ? null : client_name;
			client_name = client.getValue('companyname') || client_name || client.getValue('altname');

			clients.push({
				id: client.getId(),
				name: client_name
			});
		}
	}
	return clients;
}

//function calling
//var searchres_morethan1000 = getAllSearchResults(record_type, filters, columns);
//function definations
function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);
	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];
	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}

function getCustomColumns(search_id) {
	var columns = [];
	var rs = nlapiLoadSearch(null, search_id);
	var _cols = rs.getColumns();
	var index = 0;
	for (var i in _cols) {
		var _col = _cols[i];
		var _label = _col.getLabel().toUpperCase();
		if (_label.indexOf('(STARTCOL)') > 0 || index > 0) {
			columns.push({
				id: 'custpage_appfcol_' + index,
				name: _label.replace('(STARTCOL)', '').replace('(ENDCOL)', '').trim(),
				column: _cols[i]
			});
			index++;
		}
		if (_label.indexOf('(ENDCOL)') > 0) {
			break;
		}
	}
	return columns;
}
