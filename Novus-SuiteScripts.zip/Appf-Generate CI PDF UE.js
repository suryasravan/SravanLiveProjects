/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */

/*
* Script Name : Appf-Generate CI PDF UE
* Script Type : UserEventScript
* Description : This script will generate CI PDF on first time creation from Suitelet (will be triggered from invoices)
* Script Owner: Shravan
* Date        : 17-06-2022
* Company     : CloudAlp
*/

const VAL_PARAM_CI_ID = 'custparam_ci_id';
const VAL_PARAM_CI_PDF_LAYOUT = 'custparam_ci_pdf_layout';
const VAL_PARAM_REDIRECT = 'custparam_ci_redirect';
const FLD_CI_PDF_LAYOUT = 'custrecord_appf_ci_pdf_layout';
const FLD_CI_PDF = 'custrecord_appf_ci_pdf';
const VAL_PARAM_CI_RECORD = 'custparam_ci_create';
const CI_RECORD = "customrecord_appf_ci_record";
const VAL_PARAM_REDIRECT_SL = 'custparam_redirect_sl';

const SPARAM_SUITELET_ID = 'customscript_sl_consolidated_pdf_invoice';
const SPARAM_SUITELET_DEPLOY_ID = 'customdeploy_sl_consolidated_pdf_invoice';

const CUST_FLD_CI_RECORD = "custcol_appf_ci_record";

define( [ 'N/search', 'N/record', 'N/url', 'N/https' ], ( search, record, url, https ) => {
     const afterSubmit = ( context ) => {
          if ( context.type !== context.UserEventType.DELETE ) {
               //  log.debug( 'context.type', context.type );
               try {
                    let invoiceRecord = context.newRecord;
                    let lineCount = invoiceRecord.getLineCount( { sublistId: 'item' } )
                    let ci_RecordIds = [];
                    for ( let i = 0; i < lineCount; i++ ) {
                         let ci_ID = invoiceRecord.getSublistValue( { sublistId: 'item', fieldId: CUST_FLD_CI_RECORD, line: i } )
                         log.debug( 'ci_ID', ci_ID );
                         if ( ci_RecordIds.indexOf( ci_ID ) == -1 )
                              ci_RecordIds.push( ci_ID );
                    }
                    //  log.debug( 'ci_RecordIds', ci_RecordIds );
                    for ( let i = 0; i < ci_RecordIds.length; i++ ) {
                         let ciRecordFields = search.lookupFields( {
                              type: CI_RECORD,
                              id: Number( ci_RecordIds[ i ] ),
                              columns: [ 'custrecord_appf_ci_pdf', 'custrecord_appf_ci_pdf_layout' ]
                         } );

                         let pdf_File = ciRecordFields.custrecord_appf_ci_pdf;
                         let idPDFLayout = ciRecordFields.custrecord_appf_ci_pdf_layout[ 0 ].value;
                         //log.debug( 'pdf_File', pdf_File );
                         //log.debug( 'idPDFLayout', idPDFLayout );

                         if ( ( pdf_File == null || pdf_File == '' ) && ( idPDFLayout != null && idPDFLayout != '' ) ) {
                              var pdfSuiteletUrl = url.resolveScript( {
                                   scriptId: SPARAM_SUITELET_ID,
                                   deploymentId: SPARAM_SUITELET_DEPLOY_ID,
                                   returnExternalUrl: true
                              } );
                              pdfSuiteletUrl += '&' + VAL_PARAM_CI_ID + '=' + ci_RecordIds[ i ];
                              pdfSuiteletUrl += '&' + VAL_PARAM_CI_PDF_LAYOUT + '=' + idPDFLayout;
                              pdfSuiteletUrl += '&' + VAL_PARAM_REDIRECT_SL + '=' + true;
                              https.get( { url: pdfSuiteletUrl } )
                         }

                    }
               }
               catch ( e ) {
                    log.debug( 'failed', e );
               }
          }
     }

     return {
          afterSubmit: afterSubmit
     }
} );