	/**
	 * Script Name : Appf-VVCCP Scheduled Script #1
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script moves all the selected transactions in VVCCP suitelet as Under Processing			
	 *
	 * Company 	 : Appficiency. 
	 */

var CUSTOM_RECORD_VVCCP_BATCH ='customrecord_appf_vvccp_batch';
	 
var FLD_VVCCP_BATCH_UNDER_PROCESSING_DONE = 'custrecord_appf_vvccp_underproc_done';	 
var FLD_VVCCP_BATCH_VENDOR_BILLS = 'custrecord_appf_vvccp_vendor_bills';
var FLD_VVCCP_BATCH_VENDOR_CREDITS = 'custrecord_appf_vvccp_vendor_credits';

var FLD_VVCCP_STATUS = 'custbody_appf_vvccp_status';

var SPARAM_VVCCP_BATCH_REC_ID = 'custscript_vvccp_batch_rec_id';
	 
function scheduled()
{
	
	var context = nlapiGetContext();
	var vvccpBatchRecID = context.getSetting('SCRIPT', SPARAM_VVCCP_BATCH_REC_ID);
	nlapiLogExecution('debug','vvccpBatchRecID',vvccpBatchRecID);
	if (vvccpBatchRecID != null && vvccpBatchRecID != '')
	{
		
		var vvccpBatchRecord = nlapiLoadRecord(CUSTOM_RECORD_VVCCP_BATCH, vvccpBatchRecID);
		
		var vendorBillsFound = vvccpBatchRecord.getFieldValue(FLD_VVCCP_BATCH_VENDOR_BILLS);
			nlapiLogExecution('debug','vendorBillsFound',vendorBillsFound);

		if (vendorBillsFound != null && vendorBillsFound != '')
		{
			
			var vendorBills = vvccpBatchRecord.getFieldValues(FLD_VVCCP_BATCH_VENDOR_BILLS);
			
			for (var v = 0; v < vendorBills.length; v++)
			{
				try{
				nlapiSubmitField('vendorbill', vendorBills[v], FLD_VVCCP_STATUS, '1');
				}
				catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'Error setting Under Processing in VVCCP Status for Bill: '+vendorBills[v], e.getDetails() );
		else
			nlapiLogExecution( 'DEBUG', 'Error setting Under Processing  in VVCCP Status for Bill: '+vendorBills[v], e.toString() );
	}
				
			}
			
			
		}
		
		
		
		var vendorCreditsFound = vvccpBatchRecord.getFieldValue(FLD_VVCCP_BATCH_VENDOR_CREDITS);
					nlapiLogExecution('debug','vendorCreditsFound',vendorCreditsFound);

		if (vendorCreditsFound != null && vendorCreditsFound != '')
		{
			
			var vendorCredits = vvccpBatchRecord.getFieldValues(FLD_VVCCP_BATCH_VENDOR_CREDITS);
			
			for (var v = 0; v < vendorCredits.length; v++)
			{
				try{
				nlapiSubmitField('vendorcredit', vendorCredits[v], FLD_VVCCP_STATUS, '1');
				}
				catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'Error setting Under Processing in VVCCP Status for Credit: '+vendorCredits[v], e.getDetails() );
		else
			nlapiLogExecution( 'DEBUG', 'Error setting Under Processing  in VVCCP Status for Credit: '+vendorCredits[v], e.toString() );
	}
				
			}
			
			
		}
		
		
		nlapiSubmitField(CUSTOM_RECORD_VVCCP_BATCH, vvccpBatchRecID, FLD_VVCCP_BATCH_UNDER_PROCESSING_DONE, 'T');
		
		
	}
	
}