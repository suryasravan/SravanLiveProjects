/*
* Script Name : Appf-Bill PO Lines Processing SC
* Script Type : Schedule Scipt
* Description : 
* Company   :	Appficiency Inc.
*/

var CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG = 'customrecord_appf_bill_po_lines_log';
var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';
var FLD_CR_TOTAL_POS_TO_PROCESS = 'custrecord_appf_bill_po_lines_to_process';
var FLD_CR_PROCESSED_PERCENT = 'custrecord_appf_bill_po_lines_percent';
var FLD_CR_CREATED = 'custrecord_appf_bill_po_lines_created_by';
var FLD_CR_BILL_POS_BATCH_STATUS = 'custrecord_appf_bill_po_lines_status';
var FLD_CR_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
var FLD_CR_STATUS_FILE = 'custrecord_appf_bill_po_lines_status_fil';
var FLD_CR_ERROR_LOG = 'custrecord_appf_bill_po_lines_error_log';
var FLD_CR_PO_LINK = 'custrecord_appf_bill_po_lines_po_link';
var FLD_CR_BILL_LINK = 'custrecord_appf_bill_po_lines_bill_link';

var FLD_BILL_PO_LINE_SL_STATUS = 'custbody_appf_bill_po_line_status';
var BILL_PO_LINE_SL_STATUS_PROCESSED = '2';
var BILL_PO_LINE_SL_STATUS_READY_FOR_PROCESSING = '3';

var SPARAM_SELECTED_POS_FOLDER = 'custscript_appf_selected_pos_folder_id';
var SPARAM_CUSTOM_RECORD_ID = 'custscript_appf_bill_po_line_exec_log_id';

var IMPORT_CSV_INITIATE_BILL_PO_LINES = 'custimport_initiate_bill_po_lines';
var IMPORT_CSV_UNCHECK_BILL_PO_LINES = 'custimport_appf_uncheck_bill_po_lines';
var IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS = 'custimport_appf_po_status_bill_po_line';

var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'
var FLD_CR_PO_LINE_NOS= 'custrecord_appf_ivbl_po_line_id';
var FLD_CR_NET_AMTS= 'custrecord_appf_ivbl_vendor_net';
var FLD_CR_PO_INTERNALID= 'custrecord_appf_ivbl_po_link';
var FLD_CR_INV_TRNS= 'custrecord_appf_ivb_transid';
var FLD_CR_IV_ON_BASED_ID= 'custrecord_appf_ivb_onbasedocid';
var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';
var FLD_CR_IV_DESCRIPTIONS= 'custrecord_appf_ivbl_description';
var FLD_CR_IV_IO_NUM= 'custrecord_appf_ivbl_io_num';
var FLD_CR_IV_CIRCULATIONS= 'custrecord_appf_ivbl_circulation';
var FLD_CR_IV_UNITS='custrecord_appf_ivbl_novus_unit_rt'
var FLD_CR_IV_VENDOR_NUM='custrecord_appf_ivb_vendoraccnum'
var FLD_CR_IV_TRANS='custrecord_appf_transactions_created';
var FLD_CR_IV_TRANSACTIONS_CREATION_ERROR = 'custrecord_appf_transaction_failure';
var SPARAM_IMMEDIATE_EXECUTION = 'custscript_created_from_ext_scripts';
var SCRIPT_BILL_PO_LINES_WS_SL = 'customscript_appf_bill_po_lines_ws_sl';
var DEPLOY_BILL_PO_LINES_WS_SL = 'customdeploy_appf_bill_po_lines_ws_sl';

var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'
var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'

var FLD_CR_VENDOR_NUM = 'custrecord_vendor_ids';
var FLD_CR_VENDOR_SUBS = 'custrecord_appf_subsidiary';


var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED_SUCCESSFULLY = '4';
var STATUS_COMPLETED_WITH_ERRORS = '5';

var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';
var FLD_COL_BILL_PO_LINE = 'custcol_appf_bill_po_line';
var FLD_COL_UNBILLED_AMOUNT = 'custcol_appf_unbilled_amount';

var FLD_BILL_PO_LINES_EXEC_LOG = 'custbody_appf_bill_po_lines_log';

function billPOsSchedule(type)
{
	var context=nlapiGetContext();
	var customRecId=context.getSetting('SCRIPT', SPARAM_CUSTOM_RECORD_ID);
	var poFolderId=context.getSetting('SCRIPT', SPARAM_SELECTED_POS_FOLDER);
	if(customRecId != null && customRecId != ''){
		nlapiLogExecution('DEBUG', 'customRecId', customRecId);
		var customRec = nlapiLoadRecord(CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG, customRecId);
		var linkedPOs = customRec.getFieldValues(FLD_CR_PO_LINK);
		var dataFile = customRec.getFieldValue(FLD_CR_DATA_FILE);
		var vendorNum = customRec.getFieldValue(FLD_CR_VENDOR_NUM);
		var vendorRefNum = customRec.getFieldValue('custrecord_appf_ref_number');
		var Account = customRec.getFieldValue('custrecord_appf_ap_account');
		var Subsi = customRec.getFieldValue('custrecord_appf_subsidiary');
		
         var errorVBVC = '';	
		nlapiLogExecution('DEBUG', 'dataFile', dataFile);
		if(dataFile !=null && dataFile !='')
        {
          	var importUnderProcess = nlapiCreateCSVImport();
			importUnderProcess.setMapping(IMPORT_CSV_INITIATE_BILL_PO_LINES);
			importUnderProcess.setPrimaryFile(nlapiLoadFile(dataFile));
			var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);
			customRec.setFieldValue(FLD_CR_STATUS_FILE,'/app/setup/upload/csv/uploadlogcsv.nl?wqid='+processingJOBID);
        }
		var inv=new Date()
		inv=nlapiDateToString(inv)
		nlapiLogExecution('debug', 'inv', inv);
		var nsMater=nlapiCreateRecord(CUSTOM_RECORD_INTERIM);
		 nsMater.setFieldValue(FLD_CR_INV_TRNS,vendorRefNum)
		 nsMater.setFieldValue('custrecord_appf_ivb_create','T')
		 nsMater.setFieldValue('custrecord_appf_ivb_vendoraccnum',Account)
		 nsMater.setFieldValue('custrecord_appf_ivb_vendor',vendorNum) 
		 nsMater.setFieldValue('custrecord_appf_ivb_date',inv)
		
		var uniqueVendorsObj = {};
		var fileObj = nlapiLoadFile(dataFile);
		var fileData = fileObj.getValue();
		fileDataArr = fileData.split('\n');
		//nlapiLogExecution('debug', 'fileDataArr', fileDataArr.length);
		var uncheckBillPOsData = '';
		var totalAmt = 0;
		uncheckBillPOsData += 'PO ID,Po Line\n';
		var poLineObj = {};
		for(var d=1; d<(fileDataArr.length-1); d++){
			
			var data = fileDataArr[d].split(',');
			var poId = data[data.length-5];
			var poLineId = data[data.length-4];
			var vendorId = data[data.length-3];
			var poLine_ID = data[data.length-14];
			var poIo = data[data.length-24];
			var ppId = data[data.length-7];
			var poCurrency= data[data.length-17];
			var poAppliedAmt = data[data.length-1];
			poLineObj[poLine_ID] = Number(poAppliedAmt);
			uncheckBillPOsData += poId+','+poLineId+'\n';
			if(poAppliedAmt==null || poAppliedAmt=='')
				poAppliedAmt=0
			
			totalAmt=parseFloat(totalAmt)+parseFloat(poAppliedAmt)
		              nsMater.selectNewLineItem(CUSTOM_RECORD_REC_INTERIM);
				      nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_PO_INTERNALID,poId)
	     nsMater.setCurrentLineItemText(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_pocurrency',poCurrency)
		 nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,FLD_CR_IV_IO_NUM,poIo)
		  nsMater.setCurrentLineItemText(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_pwplink',ppId)
		   nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_po_line_id',poLine_ID)
		    nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vendor_net',poAppliedAmt)
			//nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivb_date','4/9/2020')
			
	     nsMater.setCurrentLineItemValue(CUSTOM_RECORD_REC_INTERIM,'custrecord_appf_ivbl_vendor_name',vendorNum)
	      nsMater.commitLineItem(CUSTOM_RECORD_REC_INTERIM);
		  
			if(!uniqueVendorsObj.hasOwnProperty(vendorId)){
				uniqueVendorsObj[vendorId] = {};
				uniqueVendorsObj[vendorId].poIds = [];
				if(!uniqueVendorsObj[vendorId].hasOwnProperty(poId)){
					uniqueVendorsObj[vendorId].poIds.push(poId);
				}
			}
			else{
				if(!uniqueVendorsObj[vendorId].hasOwnProperty(poId)){
						uniqueVendorsObj[vendorId].poIds.push(poId);
				}
			}
		}
		nsMater.setFieldValue('custrecord_appf_ivb_amount',totalAmt)
		nsMater.setFieldValue('custrecord_created_from_ext_scripts','T')
		
		var nsMaterId=nlapiSubmitRecord(nsMater, true, true);
		var params = {};
		params[SPARAM_IMMEDIATE_EXECUTION] = customRecId+'_billposl';
		nlapiScheduleScript('customscript_appf_sync_vb_vc_sch', 'customdeploy_vb_vc_bill_po_script',params);
		nlapiSubmitRecord(customRec, true, true);
		if(uniqueVendorsObj != null && uniqueVendorsObj != ''){
			nlapiLogExecution('debug', 'poStatus', 'poStatus');
		var selectedPOs = [];
		var errorLog=''
		var totalVBsCreated=1
		for(var vend in uniqueVendorsObj){
					try{
					var poIds = uniqueVendorsObj[vend].poIds;
					poIds = eliminateDuplicates(poIds);
					for(var p=0; p< poIds.length; p++){
						selectedPOs.push(poIds[p]);
					}
						totalVBsCreated++;
					}catch(e){
							if ( e instanceof nlobjError ){
								nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
								errorLog += 'system error while creating VB for Vendor ID '+vend+' : ' + e.getDetails();
							}
							else{
								nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
								errorLog += 'unexpected error while creating VB for Vendor ID '+vend+' : ' + e.toString();
							}
					}
					
		}
		}
		if(selectedPOs!=null && selectedPOs!='')
		{
		selectedPOs = eliminateDuplicates(selectedPOs);
			nlapiLogExecution('debug', 'selectedPOs', JSON.stringify(selectedPOs));
			var poStatusFileContent = 'PO ID,SL Status\n';
			
			var poSearchForStatusFils = [];
			poSearchForStatusFils.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
			poSearchForStatusFils.push(new nlobjSearchFilter('type', null, 'anyof', 'PurchOrd'));
						poSearchForStatusFils.push(new nlobjSearchFilter('internalid', null, 'anyof', selectedPOs));

			var poSearchForStatus = nlapiSearchRecord('transaction', null, poSearchForStatusFils, new nlobjSearchColumn('status'));
			for(var s=0; s<poSearchForStatus.length; s++){
				var poStatus = poSearchForStatus[s].getValue('status');
				var po_ID = poSearchForStatus[s].getId();
				
				//nlapiLogExecution('debug', 'poStatus', poStatus);
				var billPOStatus = BILL_PO_LINE_SL_STATUS_READY_FOR_PROCESSING;
				if(poStatus == 'fullyBilled')
					billPOStatus =  BILL_PO_LINE_SL_STATUS_PROCESSED;
				
				poStatusFileContent = poStatusFileContent + po_ID + ','+ billPOStatus + '\n';
				//nlapiSubmitField('purchaseOrder', selectedPOs[s], FLD_BILL_PO_LINE_SL_STATUS, billPOStatus);
			}
			if(poStatusFileContent !=null && poStatusFileContent !='')
			{
				var importUnderProcess = nlapiCreateCSVImport();
				importUnderProcess.setMapping(IMPORT_CSV_PO_BILL_PO_LINE_SL_STATUS);
				importUnderProcess.setPrimaryFile(poStatusFileContent);
				var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);
				
			}
			}
	}
			
			if(uncheckBillPOsData !=null && uncheckBillPOsData !='')
			{
				var importUnderProcess = nlapiCreateCSVImport();
				importUnderProcess.setMapping(IMPORT_CSV_UNCHECK_BILL_PO_LINES);
				importUnderProcess.setPrimaryFile(uncheckBillPOsData);
				var processingJOBID = nlapiSubmitCSVImport(importUnderProcess);
				
			}
		nlapiLogExecution('debug', 'poStatus', 'poStatus1452');
		
}

function callNetsuiteWebService(stSoapRequest, stSoapAction, stSessionCookie, stCookieInfo){
    var stWebServiceConsumer = 'https://3619984.suitetalk.api.netsuite.com/services/NetSuitePort_2019_2';
    if (isEmpty(stSoapRequest) || isEmpty(stSoapAction)) {
  throw nlapiCreateError('10014', 'SOAP Request and Action should not be empty.');
 }
    var stFinalCookie = stCookieInfo;
    if (isEmpty(stFinalCookie)) {
  stFinalCookie = 'NS_VER=2019.1.0';
 }
 var soapHeaders = new Array();
 soapHeaders['User-Agent-x'] = 'SuiteScript-Call';
 soapHeaders['SOAPAction'] = stSoapAction;
 soapHeaders['Host'] = "webservices.netsuite.com";
 if (!isEmpty(stSessionCookie)) {
  soapHeaders['Cookie'] = '$Version=0; ' + stFinalCookie + '; ' + stSessionCookie;
 }
 var soapResponse = nlapiRequestURL(stWebServiceConsumer, stSoapRequest, soapHeaders);
 return soapResponse;
}
function isEmpty( inputStr ) { 
 if ( null == inputStr || "" == inputStr ) 
 { return true; } 
 return false; 
}

function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}