/**
 * Script name: Appf-Create EBP Vendor Payments
 * Script type: Scheduled Script
 * Description: This script creates vendor payments for all the submitted transactions and updates them with Processed/Errored
 * Company    :Appficiency Inc.
 */
 
var SPARAM_CUSTOM_RECID = 'custscript_recid';
var SPARAM_PROCESSED_VENDOR_ARRAY = 'custscript_processed_vendor_array'; 

var SPARAM_PAYFILE_RECID = 'custscript_ebp_payfile_recid';
var SCRIPT_EBP_PAYMENT_GENERATION = 'customscript_ebp_pay_file_generation';
 
 var SPARAM_EBP_PURCHASE_TRANSACTION_SS='custscript_appf_approved_ebp_vendor_paym'
 
var CUSTOM_RECORD_SUBMITTED_PAYMENTS = 'customrecord_ebpv2_processingcontrol'; 
        var FLD_FIRST_BILL_ID = 'custrecord_first_bill_id';

var FLD_TRANSACTION_LINK_RECS_CREATED = 'custrecord_appf_tran_link_recs_created';
var FLD_APPF_SUBMITTED_PAYMENTS_TRANIDS = 'custrecord_appf_tranids';
var FLD_EBP_PAYMENTS_CREATED = 'custrecord_appf_ebp_payments_created';
var FLD_APPF_SUBMITTED_PAYMENTS_TRANTYPES = 'custrecord_appf_trantypes';
var FLD_APPF_SUBMITTED_PAYMENTS_EFT_REF = 'custrecord__appf_eft_file_reference';
var FLD_SUBMITTED_PAYMENTS_DISCOUNT_AMOUNTS='custrecord_appf_discount_amounts';
var FLD_SUBMITTED_PAYMENTS_AMOUNTS='custrecord_appf_payment_amounts';
var FLD_SUBMITTED_PAYMENTS_AGREEGATE_PAYEE = 'custrecord_appf_aggreegate_by_payee';
var FLD_SUBMITTED_PAYMENTS_IS_PROCESSED = 'custrecord_appf_is_processed';
var FLD_SUBMITTED_PAYMENTS_DATE_PROCESSED = 'custrecord_appf_date_to_be_processed';
var FLD_EBP_PROCESSING_CREATION_DATE = 'custrecord_appf_ebp_creation_date';
var FLD_SUBMITTED_PAYMENTS_POSTING_PERIOD = 'custrecord_appf_payment_posting_period';
var FLD_SUBMITTED_PAYMENTS_COST_CENTER = 'custrecord_appf_cost_center';
var FLD_SUBMITTED_PAYMENTS_LOCATION = 'custrecord_appf_location';
var FLD_SUBMITTED_BASE_CURRENCY = 'custrecord_appf_base_currency';
var FLD_SUBMITTED_NUMBER_OF_VENDORS = 'custrecord_appf_vendor_count';
var FLD_CC_SPL_HANDLE_CODE='custbody_cc_spl_handle_code';
var FLD_SUBMITTED_PAYMENT_TYPE = 'custrecord_appf_ebp_payment_type';

var CUSTOM_RECORD_BANK_DETAILS = 'customrecord_2663_bank_details'; 
var CUSTOM_RECORD_ENTITY_BANK_DETAILS = 'customrecord_2663_entity_bank_details';
var FLD_APPF_PP_COMPANY_BANK_DEATILS='custrecord_appf_pp_company_bank_info';
var FLD_EFT_CUSTRECORD_ACCT_NUMBER='custpage_eft_custrecord_2663_acct_num';
var FLD_EFT_CUSTRECORD_BANK_NUMBER='custpage_eft_custrecord_2663_bank_num';
var FLD_APPF_PP_COMPANY_BANK_PAYMENT_FILE ='custrecord_appf_bank_payment_file';
var FLD_SUBMITTED_PAYMENT_FILE = 'custrecord_payment_file';
var FLD_ENTITY_EMAIL_VENDORS = 'custentity_2663_email_address_notif';

var CUSTOM_REC_COMPANY_BANK_DETAILS = 'customrecord_2663_bank_details';
var FLD_CUSTRECORD_2663_PARENT_VENDOR ='custrecord_2663_parent_vendor';
var FLD_CUSTRECORD_2663_ACC_TYPE ='custrecord_2663_entity_bank_acct_type';
var FLD_CUSTRECORD_2663_ACC_NO ='custrecord_2663_entity_acct_no';
var FLD_CUSTRECORD_2663_BANK_NO ='custrecord_2663_entity_bank_no';
var FLD_CUSTRECORD_2663_VENDOR_BANK='custrecord_cc_vendor_bankname';
var FLD_CUSTRECORD_2663_ACH_FORMAR_PROT='custrecord_cc_ach_format_protocol';
var FLD_CUSTRECORD_2663_BANK_ACCOUNT = 'custrecord_2663_gl_bank_account';

var FLD_APPF_POSITIVE_PAY_BATCHID_STATUS = 'custrecord_appf_ebp_processing_status';
var FLD_APPF_EBP_PROCESSING_COMPLETED = 'custrecord_appf_ebp_processing_completed';
			  

var FLD_EBP_V2_PROCESS_STATUS='custbody_ebp2_processed_status';
var FLD_EBP_V2_PAYMENT_TYPE='custbody_ebpv2_paymenttype';
var FLD_EBP_DATA_PROCESSING_RECORD='custbody_appf_ebp_data_processing_rec';
var FLD_BILL_EBPV_PROCESS_STATUS_PROCESSED = '2'; // Processed 
var FLD_BILL_EBPV_PROCESS_STATUS_ERRORED = '3'; // Errored 


var CUSTOM_RECORD_TRANSACTION_LINE = 'customrecord_appf_ebp_linked_trans';
var FLD_PAYMENT_LINE_REC_PAYMENTID = 'custrecord_appf_ebp_linked_payment';
var FLD_EBP_BACKLINK = 'custrecord_appf_ebp_backlink';

var CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD='customrecord_appf_pwp_wrapper_record';
var FLD_VB_LINE_PAYMENT_AMOUNT='custrecord_appf_pwp_bill_line_amt_paid';


var transactionLineRecordFields = ['custrecord_appf_ebp_linked_transaction','','custrecord_appf_ebp_trans_vendor','','custrecord_appf_ebp_linked_tran_type','custrecord_appf_ebp_linked_linkid','custrecord_appf_ebp_linked_tran_amt','custrecord_appf_ebp_linked_trans_pwp'];



function generateVendorPayment(type)
{
  var context = nlapiGetContext();
  var existingArr = [];
  
  var ssID = context.getSetting('SCRIPT', SPARAM_EBP_PURCHASE_TRANSACTION_SS);
    var loadSS=nlapiLoadSearch(null, ssID);
  	var ssType = loadSS.getSearchType();
	var ssfilts = loadSS.getFilters();
		var sscolumns=loadSS.getColumns();
		//var resultFilters = filters.concat(ssfilts);
  var searchResults=getAllSearchResults(ssType, ssfilts, null);
  if (searchResults != null && searchResults != '') {
				 nlapiLogExecution('debug','searchResults.length',searchResults.length)
				for(var s = 0; s < searchResults.length; s++) {
					var searchresult = searchResults[s];
					var internalid = searchresult.getId();
	var recID = internalid;
	nlapiLogExecution('DEBUG','recID',recID);
 
	var processedVendorArr = context.getSetting('SCRIPT', SPARAM_PROCESSED_VENDOR_ARRAY);
	if(processedVendorArr != null && processedVendorArr != '')
	{
		existingArr = processedVendorArr.split(',');
	}
	nlapiLogExecution('DEBUG','existingArr:',existingArr.toString());
	 nlapiLogExecution('DEBUG','processedVendorArr',processedVendorArr);
	if(recID != null && recID != '')
	{
				try{
                var bankAccount = '';
                  // var bankAccountName = '';
				  var paymentsCreated = [];
				var customRec = nlapiLoadRecord(CUSTOM_RECORD_SUBMITTED_PAYMENTS,recID);
				var firstBillID = customRec.getFieldValue(FLD_FIRST_BILL_ID);
				var tranIds = customRec.getFieldValue(FLD_APPF_SUBMITTED_PAYMENTS_TRANIDS);
				var tranTypes = customRec.getFieldValue(FLD_APPF_SUBMITTED_PAYMENTS_TRANTYPES);
				var discountAmts = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_DISCOUNT_AMOUNTS);
				var paymentAmts = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_AMOUNTS);
				var eftFileRef = customRec.getFieldValue(FLD_APPF_SUBMITTED_PAYMENTS_EFT_REF);
				var agreegateByPayee = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_AGREEGATE_PAYEE);
                  var dateProcessed = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_DATE_PROCESSED);
                  var postingPeriod = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_POSTING_PERIOD);
                  var location = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_LOCATION);
                  var costCenter = customRec.getFieldValue(FLD_SUBMITTED_PAYMENTS_COST_CENTER);
                  var baseCurrency = customRec.getFieldValue(FLD_SUBMITTED_BASE_CURRENCY);
				  var vendorCount = customRec.getFieldValue(FLD_SUBMITTED_NUMBER_OF_VENDORS);
                  var paymentType = customRec.getFieldValue(FLD_SUBMITTED_PAYMENT_TYPE);
                  var companyBankDetail = customRec.getFieldValue(FLD_APPF_PP_COMPANY_BANK_DEATILS);
				
				var tranIds = customRec.getFieldValue(FLD_APPF_SUBMITTED_PAYMENTS_TRANIDS);
				var tranTypes = customRec.getFieldValue(FLD_APPF_SUBMITTED_PAYMENTS_TRANTYPES)
				   var  billsDataFileId= customRec.getFieldValue(FLD_SUBMITTED_PAYMENT_FILE);
				   var transactionLinkRecsCreated =customRec.getFieldValue(FLD_TRANSACTION_LINK_RECS_CREATED);
				   var vbintidobj = {};
                  nlapiLogExecution('DEBUG','billsDataFileId:',billsDataFileId)
		if(billsDataFileId != null && billsDataFileId != '' && transactionLinkRecsCreated != 'T')
		      {
				var fileContent = nlapiLoadFile(billsDataFileId).getValue();
				if(fileContent != null && fileContent != '')
				{
					fileContent = fileContent.split('\n');
					nlapiLogExecution('DEBUG','fileContent.length-1:',fileContent.length-1)
					for(var f=1; f<(fileContent.length); f++)
					{					
						var vbData = fileContent[f].split(',');
						try{
							if(vbData != null && vbData != '')
							{	
						
						var transactionLineRecord = nlapiCreateRecord(CUSTOM_RECORD_TRANSACTION_LINE);
						var vbintid = '';
						for(var z=0; z<(vbData.length); z++)
					{					
						//nlapiLogExecution('DEBUG','vbDataSplitinside:',vbData[z])
						if (transactionLineRecordFields[z])
						{
							var fldData = vbData[z];
							if (z == 0)
							vbintid = fldData;	
							if (z == 4)
							fldData = tranTypeToID(fldData);	
						transactionLineRecord.setFieldValue(transactionLineRecordFields[z], fldData);
						}
						
					}
					transactionLineRecord.setFieldValue(FLD_EBP_BACKLINK, recID);
					var transactionLineRecordID = nlapiSubmitRecord(transactionLineRecord);
					if (!vbintidobj.hasOwnProperty(vbintid))
					{
					vbintidobj[vbintid] = [transactionLineRecordID];
					}
					else
					{
						var extCR = vbintidobj[vbintid];
						extCR.push(transactionLineRecordID);
						vbintidobj[vbintid] = extCR;
						
					}
					
						
						nlapiLogExecution('DEBUG','transactionLineRecordID:',transactionLineRecordID)
							}
						}
						catch(e){
								nlapiLogExecution('DEBUG','Error in Payment Creation:',e.toString());
							
								}
					}
					
				   }
		       }
                  if(companyBankDetail != null && companyBankDetail != '')
                    {
                    bankAccount = nlapiLookupField(CUSTOM_REC_COMPANY_BANK_DETAILS, companyBankDetail,FLD_CUSTRECORD_2663_BANK_ACCOUNT);
                    // bankAccountName = nlapiLookupField(CUSTOM_REC_COMPANY_BANK_DETAILS, companyBankDetail,FLD_CUSTRECORD_2663_BANK_ACCOUNT,true);
 
                    }
					if(tranIds != null && tranIds != '')
				{	
				}
                 nlapiLogExecution('DEBUG','bankAccount:',bankAccount);
				if(tranIds != null && tranIds != '')
				{	
					var tranIdsObj = JSON.parse(tranIds);
					var tranTypesObj = JSON.parse(tranTypes);
					var discountAmtsObj = JSON.parse(discountAmts);
					var paymentAmtsObj = JSON.parse(paymentAmts);
					
					if(agreegateByPayee != 'T')
					{						
                        
						if(existingArr.length < vendorCount)
						{	
						for(var vendor in tranIdsObj)
						{
                          	if(existingArr.indexOf(vendor) == -1)
							{	
							var tranIdArr = tranIdsObj[vendor];
							var tranTypeArr = tranTypesObj[vendor];
							var paymentAmtArr = paymentAmtsObj[vendor];
							var discountAmtArr = discountAmtsObj[vendor];
							for(var i=0; tranIdArr.length > 0 && i < tranIdArr.length;i++)
							{
							try
							{
							var paymentID = createVendorPayment(tranTypeArr[i],tranIdArr[i],vendor,paymentAmtArr[i],discountAmtArr[i],agreegateByPayee,eftFileRef,dateProcessed,postingPeriod,location,costCenter,baseCurrency,recID,paymentType,bankAccount,null);
							nlapiLogExecution('debug', 'payment created', paymentID);
							if(paymentID != null && paymentID != '')
							{
								paymentsCreated.push(paymentID);
								nlapiSubmitField(getTranType(tranTypeArr[i]), tranIdArr[i], [FLD_EBP_V2_PROCESS_STATUS], [FLD_BILL_EBPV_PROCESS_STATUS_PROCESSED]);
								for (var n = 0; n < vbintidobj[tranIdArr[i]].length; n++)
								{
								nlapiSubmitField(CUSTOM_RECORD_TRANSACTION_LINE, vbintidobj[tranIdArr[i]][n], [FLD_PAYMENT_LINE_REC_PAYMENTID], [paymentID]);
								
								updatePWPRecord(vbintidobj[tranIdArr[i]][n]);
								}
							}
							}
							catch(e){
								nlapiLogExecution('DEBUG','Error in Payment Creation:',e.toString());
								nlapiSubmitField(getTranType(tranTypeArr[i]), tranIdArr[i], [FLD_EBP_V2_PROCESS_STATUS], [FLD_BILL_EBPV_PROCESS_STATUS_ERRORED]);
								}
							}
							existingArr.push(vendor);
                              	var params = {};
								params[SPARAM_PROCESSED_VENDOR_ARRAY] = existingArr+'';
								params[SPARAM_CUSTOM_RECID] = recID;
								nlapiScheduleScript(context.getScriptId(), null, params);
								break;
							}     
						}
					}
					
					}
					else
					{
						
						if(existingArr.length < vendorCount)
						{	
						for(var vendor in tranIdsObj)
						{
                          
							if(existingArr.indexOf(vendor) == -1)
							{	
							var tranIdArr = tranIdsObj[vendor];
							var tranTypeArr = tranTypesObj[vendor];
							var paymentAmtArr = paymentAmtsObj[vendor];
							var discountAmtArr = discountAmtsObj[vendor];
							try
							{
							var paymentID = createVendorPayment(tranTypeArr,tranIdArr,vendor,paymentAmtArr,discountAmtArr,agreegateByPayee,eftFileRef,dateProcessed,postingPeriod,location,costCenter,baseCurrency,recID,paymentType,bankAccount,firstBillID);
							nlapiLogExecution('DEBUG','Payments created for:'+recID,paymentID);
                              if(paymentID != null && paymentID != '')
							{
                             paymentsCreated.push(paymentID);
								for(var j=0; j < tranIdArr.length; j++)
								{
								nlapiSubmitField(getTranType(tranTypeArr[j]), tranIdArr[j], [FLD_EBP_V2_PROCESS_STATUS], [FLD_BILL_EBPV_PROCESS_STATUS_PROCESSED]);	
								for (var n = 0; n < vbintidobj[tranIdArr[j]].length; n++)
								{
								nlapiSubmitField(CUSTOM_RECORD_TRANSACTION_LINE, vbintidobj[tranIdArr[j]][n], [FLD_PAYMENT_LINE_REC_PAYMENTID], [paymentID]);
								updatePWPRecord(vbintidobj[tranIdArr[j]][n]);
								}
								}
							}								
							}
							catch(ex){
								nlapiLogExecution('DEBUG','Error in Payment Creation:',ex.toString());
                              	for(var j=0; j < tranIdArr.length; j++)
								nlapiSubmitField(getTranType(tranTypeArr[j]), tranIdArr[j], [FLD_EBP_V2_PROCESS_STATUS], [FLD_BILL_EBPV_PROCESS_STATUS_ERRORED]);
								}
								existingArr.push(vendor);
                              var params = {};
							params[SPARAM_PROCESSED_VENDOR_ARRAY] = existingArr+'';
							params[SPARAM_CUSTOM_RECID] = recID;
							nlapiScheduleScript(context.getScriptId(), null, params);
							break;
						}     
						}
					}
					
					}
				
				}
                  nlapiLogExecution('DEBUG','existingArr length before initiating file generation:',existingArr.length);
                if(existingArr.length == vendorCount)
                {

                 				var customRecRev = nlapiLoadRecord(CUSTOM_RECORD_SUBMITTED_PAYMENTS,recID);
                               customRecRev.setFieldValue(FLD_APPF_POSITIVE_PAY_BATCHID_STATUS, 'Payments Created::File Creation Initiated');
							                                  customRecRev.setFieldValue(FLD_APPF_EBP_PROCESSING_COMPLETED, 'T');
                    							                                  customRecRev.setFieldValues(FLD_EBP_PAYMENTS_CREATED, paymentsCreated);

					nlapiSubmitRecord(customRecRev, true, true);
					var params1 = {};
					params1[SPARAM_PAYFILE_RECID] = recID;
					//nlapiScheduleScript(SCRIPT_EBP_PAYMENT_GENERATION, null, params1);
                }  
				}
				catch(e)
				{
            
					nlapiLogExecution('DEBUG','Error in processing:',e.toString());
				}
		
	}
				}
  }
}

function createVendorPayment(tranTypeArray,tranIdArray,vendorid,paymentArray,discountAmountArray,agreegateByPayee,eftFileRef,dateProcessed,postingPeriod,location,costCenter,baseCurrency,recID,paymentType,bankAccount,firstBillID)
{
	
	nlapiLogExecution('debug', 'vendorid', vendorid);
	nlapiLogExecution('debug', 'baseCurrency', baseCurrency);
	
	var paymentId='';
  
    
	var vendorPaymentRecord=null;
	if(agreegateByPayee == 'T')
	vendorPaymentRecord = nlapiTransformRecord('vendorbill', firstBillID, 'vendorpayment', {'recordmode':'dynamic'});
    else
	vendorPaymentRecord = nlapiTransformRecord('vendorbill', tranIdArray, 'vendorpayment', {'recordmode':'dynamic'});

		
		var linecount=vendorPaymentRecord.getLineItemCount('apply');
	nlapiLogExecution('debug', 'linecount of pay', linecount);
		//var vendorPaymentRecord=nlapiCreateRecord('vendorpayment',{'recordmode':'dynamic'});
//vendorPaymentRecord.setFieldValue('entity', vendorid);
  	if(baseCurrency != null && baseCurrency != '')
    vendorPaymentRecord.setFieldValue('currency',baseCurrency);
    //vendorPaymentRecord.setFieldValue(FLD_EBP_V2_PAYMENT_TYPE,paymentType);
if(bankAccount != null && bankAccount != '')
    vendorPaymentRecord.setFieldValue('account',bankAccount);

					                  nlapiLogExecution('DEBUG','agreegateByPayee',agreegateByPayee);

	if(linecount>0)
	{
		for(var k=1;k<=linecount;k++)
		{
			var tranId=vendorPaymentRecord.getLineItemValue('apply','doc',k);
			var payment=vendorPaymentRecord.getLineItemValue('apply','amount',k);
			var type=vendorPaymentRecord.getLineItemValue('apply','type',k);
         
			if(agreegateByPayee == 'T')
			{	
				var matchedIndex = tranIdArray.indexOf(tranId);
				                 // nlapiLogExecution('DEBUG','matchedIndex',matchedIndex);

				if(matchedIndex != -1)
				{
                 // nlapiLogExecution('DEBUG','mqatxched',tranIdArray.indexOf(tranId));
                  vendorPaymentRecord.selectLineItem('apply',k);
					vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
                  var discAmt = discountAmountArray[matchedIndex];
                  if (discAmt != null && discAmt != '')
                  {  
                  discAmt = parseFloat(discAmt);
					vendorPaymentRecord.setCurrentLineItemValue('apply','discamt',discAmt);
                  }  
                  vendorPaymentRecord.setCurrentLineItemValue('apply','amount',parseFloat(paymentArray[matchedIndex]));
                  vendorPaymentRecord.commitLineItem('apply');
				}
				else
				{
					vendorPaymentRecord.selectLineItem('apply',k);
					vendorPaymentRecord.setCurrentLineItemValue('apply','apply','F');
					    vendorPaymentRecord.commitLineItem('apply');

				}
				
			}
			else
			{
				if(tranId==tranIdArray)
				{
                  //nlapiLogExecution('DEBUG','matched:',tranIdArray);
                  vendorPaymentRecord.selectLineItem('apply',k);
					vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
					var discAmt = discountAmountArray;
                  if (discAmt != null && discAmt != '')
                  {  
                  discAmt = parseFloat(discAmt);
					vendorPaymentRecord.setCurrentLineItemValue('apply','discamt',discAmt);
                  } 
                  vendorPaymentRecord.setCurrentLineItemValue('apply','amount',parseFloat(paymentArray));
                  vendorPaymentRecord.commitLineItem('apply');
				}
			}				
          
		}
      vendorPaymentRecord.setFieldValue('tobeprinted','T');
	  vendorPaymentRecord.setFieldValue('tobeprinted','F');
      	if(eftFileRef != null && eftFileRef != '')
		vendorPaymentRecord.setFieldValue('memo',eftFileRef);
      	if(costCenter != null && costCenter != '')
		vendorPaymentRecord.setFieldValue('department',costCenter);
		if(dateProcessed != null && dateProcessed != '')
		vendorPaymentRecord.setFieldValue('trandate',dateProcessed);
		if(postingPeriod != null && postingPeriod != '')
		vendorPaymentRecord.setFieldValue('postingperiod',postingPeriod);
		if(location != null && location != '')
		vendorPaymentRecord.setFieldValue('location',location);
      	if(recID != null && recID != '')
		vendorPaymentRecord.setFieldValue(FLD_EBP_DATA_PROCESSING_RECORD,recID);
	
		paymentId=nlapiSubmitRecord(vendorPaymentRecord,true,true);
      nlapiLogExecution('debug','paymentId:',paymentId);
	}
 
	return paymentId;
} 



function updatePWPRecord(trid)
{
	var tranRec = nlapiLoadRecord(CUSTOM_RECORD_TRANSACTION_LINE, trid);
	var pwpid = tranRec.getFieldValue(transactionLineRecordFields[7]);
	var amt = tranRec.getFieldValue(transactionLineRecordFields[6]);
	if (pwpid != null && pwpid != '' && amt != null && amt != '')
	{
	var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD,pwpid);
							var existingPaymentOnPWPRecord=pwpRecord.getFieldValue(FLD_VB_LINE_PAYMENT_AMOUNT);
							if(existingPaymentOnPWPRecord =='' || existingPaymentOnPWPRecord == null)
							existingPaymentOnPWPRecord =0;
							var paymentNeedToUpdateInPWPRec=parseFloat(existingPaymentOnPWPRecord)+parseFloat(amt)
							pwpRecord.setFieldValue(FLD_VB_LINE_PAYMENT_AMOUNT, paymentNeedToUpdateInPWPRec);
							
							nlapiSubmitRecord(pwpRecord);
	
	}
}



function getTranType(trantype){
	   var transaction = '';
	   if(trantype == 'CustInvc')
	   transaction = 'invoice';
	   if(trantype == 'SalesOrd')
	    transaction = 'salesorder';
	   if(trantype == 'VendBill')
	    transaction = 'vendorbill';
	   if(trantype == 'VendCred')
	    transaction = 'vendorcredit';
	   if(trantype == 'VendPymt')
		transaction = 'vendorpayment';
	   if(trantype == 'Credit Memo')
	    transaction = 'creditmemo';
	   if(trantype == 'CashSale')
	    transaction = 'cashsale';
	   if(trantype == 'InvAdjst')
	    transaction = 'inventoryadjustment';
	     if(trantype == 'ItemRcpt')
	    transaction = 'itemreceipt';
	    if(trantype == 'Journal')
	    transaction = 'journal';
	    if(trantype == 'Opprtnty')
	    transaction = 'opportunity';
	    if(trantype == 'LiaAdjst')
	    transaction = 'laibilityadjustment';
	    if(trantype == 'ExpRept')
	    transaction = 'expensereport';
	    if(trantype == 'CustPymt')
	    transaction = 'customerpayment';
	    if(trantype == 'Deposit')
	    transaction = 'deposit';
	    if(trantype == 'CardChrg')
	    transaction = 'creditcard';
	    if(trantype == 'ItemShip')
	    transaction = 'itemfullfillment';
	    if(trantype == 'CustDep')
	    transaction = 'customerdeposit';
	    if(trantype == 'PurchOrd')
	    transaction = 'purchaseorder';
	    if(trantype == 'InvTrnfr')
	    transaction = 'inventorytransfer';
	    if(trantype == 'WorkOrd')
	    transaction = 'workorder';
	    if(trantype == 'Build')
	    transaction = 'assemblybuild';
	    if(trantype == 'FxReval')
	    transaction = 'currencyrevaluation';
	    if(trantype == 'VendAuth')
	    transaction = 'vendorreturnauthorization';
	    if(trantype == 'Estimate')
	    transaction = 'estimate';
	    if(trantype == 'Commissn')
	    transaction = 'commission';
	    if(trantype == 'TrnfrOrd')
	    transaction = 'transfer';
	    if(trantype == 'BinWksht')
	    transaction = 'binputawayworkSheet';
	   if(trantype == '')
	   transaction = '';
	   return transaction;
	 }
	
function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}




function tranTypeToID(typ)
{
	var typID = '';
	
	if (typ == 'vendorcredit')
		typID = '20';
if (typ == 'vendorbill')
	typID = '17';

return typID;

}