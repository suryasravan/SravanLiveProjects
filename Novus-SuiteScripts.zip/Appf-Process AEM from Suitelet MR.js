	/**
	 * @NApiVersion 2.0
	 * @NScriptType MapReduceScript
	 */
	 var SPARAM_INDEX='custscript_appf_index';
	var SPARAM_CUSTOM_REC_ID='custscript_log_rec_id';
	var SPARAM_CUSTOM_RESET='custscript_reset';

	var FOLDER_AEM_SL_FILES= '1153';

	var FLD_PO_START_DATE = 'custbody_rx_po_startdate';
	var FLD_PO_END_DATE = 'custbody_appf_enddate';

	var CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG='customrecord_appf_aem_rev_ele_ex_log';
	var FLD_TOT_RECS_PROCESSED='custrecord_appf_aem_reelf_process_rec';
	var FLD_TOT_RECS_NOT_PROCESSED = 'custrecord_appf_total_recs_not_processed';
	var FLD_TOT_RECS='custrecord_appf_aem_reelf_total_records';
	var FLD_CREATED_BY='custrecord_appf_aem_reelf_created_by';
	var FLD_AEM_STATUS='custrecord_appf_aem_reelf_status';
	var FLD_PROCESS_PERCENTAGE='custrecord_appf_processed_percentage';
	var FLD_ERROR_LOG='custrecord_appf_error_log';
	var FLD_SRC_FROM_FIL='custrecord_appf_source_from_fil';
	var FLD_SRC_TO_FIL='custrecord_appf_sorce_to_fil';
	var FLD_START_DATE_PO_FIL='custrecord_appf_st_dt_po';
	var FLD_END_DATE_PO_FIL='custrecord_appf_en_dt_po';
	var FLD_SUBSIDIARY_FIL='custrecord_appf_subsidiary_fil';
	var FLD_DATA_FILE = 'custrecord_appf_data_file';
	var FLD_ERROR_FILE = 'custrecord_appf_error_file';
	var FLD_PROCESS_RESET = 'custrecord_appf_process_reset';
	var FLD_CSV_LABEL_ROW = 'custrecord_csv_file_label_row';


	var FLD_AEM_STATUS_INPROGRESS=2;
	var FLD_AEM_STATUS_COMPLETED=4;
	var FLD_AEM_STATUS_ERRORED=5;

	var FLD_COL_SO_LINE_ID='custcol_appf_line_id';

	var FLD_COL_REV_ARRANG_PO_LINE_ID='custcol_appf_po_line_id';
	var FLD_COL_REV_ARRANG_PO_NUM='custcol_appf_po_number';
	var FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT='itemlaborcostamount';
	var FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC='laborexpenseacct';
	var FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC='labordeferredexpenseacct';

	var FLD_COL_PO_EXPENSE_REV_ELEM_LINK='custcol_appf_aem_revenue_element_link';
	var FLD_COL_PO_REV_ARRNGEMENT_LINK='custcol_appf_aem_revenue_plan_link';
	var FLD_COL_PO_REV_ELEM_EXECUTION_LOG='custcol_app_aem_rev_ele_ex_log';
	var FLD_COL_PO_LINE_ID='custcol_appf_po_line_id';


	define(['N/search', 'N/record', 'N/email', 'N/runtime', 'N/error', 'N/file'],
		function(search, record, email, runtime, error, file)
		{   
			function getInputData()
			{
				//var dataFileId = 1251789;
				var customRecID = runtime.getCurrentScript().getParameter({name: SPARAM_CUSTOM_REC_ID});
				log.debug('customRecID', customRecID);
				var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(customRecID)});
				var dataFileId = customRec.getValue({fieldId:FLD_DATA_FILE});
				var objPO = {};
				try
				{
					var dataFile = file.load({id:dataFileId});
					var searchResults = dataFile.getContents().split('\n');
											
											var uniquePOCount = 0;

					for(var i=1; i<searchResults.length; i++){
				    var searchResult=searchResults[i];
					if (searchResult != null && searchResult != '' && searchResult != ' ')
					{
					var result = searchResult.split(',');
					
				var poID=result[0];
				var recId = poID;
				var revArrID=result[2];
				var poNum=result[3];
				var poLineID=result[4];
				var soNum=result[5]
				var soLineID=result[7];
				var item=result[9];
				var expenseAcc=result[11];
				var expenseRecogAcc=result[12];
				var amount=result[13];
				var revElemLink=result[15];
				var revArrangLink=result[17];
				
				 var lineobj = {};
				   lineobj.solineid = soLineID;
				   lineobj.polineid = poLineID;
				   lineobj.amount = amount;
				   lineobj.exprecogacc = expenseRecogAcc;
				   lineobj.expacc = expenseAcc;
				   lineobj.revelem = '';
				
				if (!objPO.hasOwnProperty(recId.toString()))	
				  {
                   uniquePOCount++;
                   objPO[recId.toString()] = {};
				   objPO[recId.toString()].poid = recId.toString();
				   objPO[recId.toString()].revrecid = revArrID;		
                   objPO[recId.toString()].crid = customRecID;				   
				   
				   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
				   objPO[recId.toString()].lines = lines_obj;
			   
				  }	
                  else
                  {
					  				   objPO[recId.toString()].poid = recId.toString();
									                      objPO[recId.toString()].crid = customRecID;				   


					  				   objPO[recId.toString()].revrecid = revArrID;				   

					   var lines_obj = [];
				   lines_obj.push(lineobj);
				   
					 var lines_obj_existing = objPO[recId.toString()].lines;
					 lines_obj = lines_obj_existing.concat(lines_obj);
					 
					 				   objPO[recId.toString()].lines = lines_obj;
				  }
					}
					}
					var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG,id:customRecID,isDynamic:true});
							var csvlabelRow = 'PO ID, Revenue Arrangement ID, Error Details';

			customRec.setValue({fieldId:FLD_TOT_RECS, value:uniquePOCount});
			customRec.setValue({fieldId:FLD_CSV_LABEL_ROW, value:csvlabelRow});
	
			var revElemExecLogID = customRec.save({
    enableSourcing: true,
    ignoreMandatoryFields: true
});
				}
				catch(e)
				{
					log.debug('err',e.message);
				}
		
					return objPO;
			}
			
			
			function reduce(context)
			{
                 // context = JSON.parse(context);
				  								log.debug('context in map', context);

				var mainValues = context.values[0];
				log.debug('mainValues', mainValues);
				mainValues = JSON.parse(mainValues);
				var customRecID = mainValues.crid;
				var poID=mainValues.poid;
				var revArrID = mainValues.revrecid;				
				
								log.debug('revArrID', revArrID);

				
				var results = mainValues.lines;
				log.debug('results len', results.length);
				var errorMessage = '';			
				var customRec=record.load({type:CUSTOM_RECORD_REVENUE_ELEM_EXEC_LOG, id:Number(customRecID)});
					
					
				var csvLabelRow = customRec.getValue({fieldId:FLD_CSV_LABEL_ROW});	
				if (csvLabelRow == null)
				csvLabelRow = '';	
											log.debug('csvLabelRow', csvLabelRow);

	
				var progressCounter=customRec.getValue({fieldId:FLD_TOT_RECS_PROCESSED});
				if(progressCounter == null || progressCounter == '')
				progressCounter=0;
				var nonProgressCounter=customRec.getValue({fieldId:FLD_TOT_RECS_NOT_PROCESSED});
				if(nonProgressCounter == null || nonProgressCounter == '')
				nonProgressCounter=0;
				var dataFileId = customRec.getValue({fieldId:FLD_DATA_FILE});
				var errorLog=customRec.getValue({fieldId:FLD_ERROR_LOG});
				if (errorLog == null)
					errorLog = '';
				var customReset=customRec.getValue({fieldId:FLD_PROCESS_RESET});
				var total=customRec.getValue({fieldId:FLD_TOT_RECS});
				var errorFileID = customRec.getValue({fieldId:FLD_ERROR_FILE});
				var errorFileData = '';
				
				try{
						var revArrRec=record.load({type:'revenuearrangement', id:Number(revArrID), isDynamic: true});
						var revArrangeTranID = revArrRec.getValue({fieldId:'tranid'});
						//log.debug('revArrangeTranID',revArrangeTranID);
						var date=revArrRec.getValue({fieldId:'trandate'});
						revArrRec.setValue({fieldId:'contractcostaccrualdate',value:date});
						
						for (var r = 0; r < results.length; r++)
						{
															//log.debug('results[r].solineid', results[r].solineid);

						var revrecLine = revArrRec.findSublistLineWithValue({
						sublistId: 'revenueelement',
						fieldId: FLD_COL_SO_LINE_ID,
						value: results[r].solineid
						});
														//log.debug('revrecLine', revrecLine);

							if (revrecLine != -1)
							{
								
								revArrRec.selectLine({
								sublistId: 'revenueelement',
								line: revrecLine
								});
								var revenueElem=revArrRec.getCurrentSublistValue({
								sublistId: 'revenueelement',
								fieldId: 'revenueelement'
								});
								results[r].revelem = revenueElem;
								if(customReset == true)
								{
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT, value:''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_NUM,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID,value: ''});
									revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG, value:customRecID});
								}
								else
								{
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_ITEM_LABOR_COST_AMT, value: Number(results[r].amount)});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_EXPENSE_ACC, value:results[r].exprecogacc});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_LABOR_DEFF_EXP_ACC, value:results[r].expacc});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_NUM, value:poID});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID, value:results[r].polineid});
								revArrRec.setCurrentSublistValue({sublistId:'revenueelement', fieldId:FLD_COL_REV_ARRANG_APPF_REV_ELEM_EX_LOG, value:customRecID});
								}
								revArrRec.commitLine({
								sublistId: 'revenueelement'
								});
							}
						}
								
								revArrRec.save({enableSourcing: true,
									ignoreMandatoryFields: true
									});
								
								var po=record.load({type:'purchaseorder', id:Number(poID),isDynamic:true});
								for (var r = 0; r < results.length; r++)
						        {
									
								var isPOLine = po.findSublistLineWithValue({sublistId:'item', fieldId:FLD_COL_REV_ARRANG_PO_LINE_ID, value:results[r].polineid});
								var isSOLine = po.findSublistLineWithValue({sublistId:'item', fieldId:FLD_COL_SO_LINE_ID, value:results[r].solineid});
																		//log.debug('isPOLine of '+results[r].polineid, isPOLine);
																		//log.debug('isSOLine of '+results[r].solineid, isSOLine);

								if (isPOLine != -1 && isSOLine != -1 && isSOLine == isPOLine)
									{
										var revenueElem = results[r].revelem;
																		//log.debug('revenueElem', revenueElem);

										po.selectLine({sublistId:'item', line:isPOLine});
										 if(customReset == true){
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_EXPENSE_REV_ELEM_LINK, value:''});
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ARRNGEMENT_LINK, value:''});
										po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ELEM_EXECUTION_LOG, value:customRecID});
										 }
										 else
										 {
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_EXPENSE_REV_ELEM_LINK, value:revenueElem});
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ARRNGEMENT_LINK, value:revArrID});
											 po.setCurrentSublistValue({sublistId:'item', fieldId:FLD_COL_PO_REV_ELEM_EXECUTION_LOG, value:customRecID});
											 
										 }
										po.commitLine({sublistId:'item'});
									}
									}
									po.save({enableSourcing: true,
									ignoreMandatoryFields: true
									});
									//log.debug('posubmitted', posubmitted);
									progressCounter++;
								
						}
						catch(e)
						{
							nonProgressCounter++;
							log.debug('error for PO line:'+poLineID, e.message );
							errorMessage = 'SO Line ID '+soLineID+': Run Time Failure due to: '+e.message;  
							errorFileData = poID+','+revArrID+','+errorMessage;
						}
				
						

			
				var totalViewed = parseInt(progressCounter)+parseInt(nonProgressCounter);
				var statusAEM = FLD_AEM_STATUS_INPROGRESS;
				if(total == totalViewed)
				{
					statusAEM = FLD_AEM_STATUS_COMPLETED;
					if (errorMessage != null && errorMessage != '')
						statusAEM = FLD_AEM_STATUS_ERRORED;
					
				}
				
				var processPercent=(parseInt(totalViewed)/parseInt(total))*100;
				//processPercent=Math.round(processPercent*10)/10;
				processPercent = Number(processPercent).toFixed(2);
				
				customRec.setValue({fieldId:FLD_AEM_STATUS,value:statusAEM});
				customRec.setValue({fieldId:FLD_PROCESS_PERCENTAGE,value:processPercent});
				if (errorLog == '' && (errorMessage != null && errorMessage != ''))
				{
				customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorMessage});
				}
				if (errorLog != '' && (errorMessage != null && errorMessage != ''))
				{
					
					errorLog = errorLog + '\n' + errorMessage;
					customRec.setValue({fieldId:FLD_ERROR_LOG,value:errorLog});
				}

			
			
				customRec.setValue({fieldId:FLD_TOT_RECS_PROCESSED,value:progressCounter});
				customRec.setValue({fieldId:FLD_TOT_RECS_NOT_PROCESSED,value:nonProgressCounter});
				
				if(errorFileData != '')
				{
									
					if(errorFileID == '' || errorFileID == null)
					{
						errorFileData=csvLabelRow+'\n'+errorFileData;
					var errorFileName = 'Rev Rec Update Error File_'+customRecID+'.csv';

						var fileObj=file.create({
						name: errorFileName,
						fileType: file.Type.CSV,
						contents: errorFileData,
						encoding: file.Encoding.UTF8,
						folder: FOLDER_AEM_SL_FILES
						});
						
						var ssErrorFileID= fileObj.save();
						customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
					else
					{
						var errorFile=file.load({id:errorFileID})
						
						errorFile.appendLine({value: errorFileData});
						
						var ssErrorFileID= errorFile.save();
						//customRec.setValue({fieldId:FLD_ERROR_FILE,value:ssErrorFileID});
					}
				}
				customRec.save({enableSourcing: true,ignoreMandatoryFields: true});
				
									context.write({
					key: 'RevArrgmt_'+revArrID,
					value: poID
					}); 
 
				
			}
function getSearchResults(rectype, fils, cols) {
 var mySearch = search.create({
        type: rectype,
        columns: cols,
        filters: fils
    });
        var resultsList = [];
        var myPagedData = mySearch.runPaged({pageSize: 1000});
        myPagedData.pageRanges.forEach(function(pageRange){
            var myPage = myPagedData.fetch({index: pageRange.index});
            myPage.data.forEach(function(result){
               resultsList.push(result);
            });
        });
        return resultsList;
    }

 function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
			

			return {
				getInputData: getInputData,
				reduce: reduce
			};
		});
