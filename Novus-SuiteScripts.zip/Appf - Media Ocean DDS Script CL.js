/*
 *Script Name: Appf - Media Ocean DDS Script CL
 *Script Type: Client
 *Company 	: Appficiency.
 * Version    Date            Author		    Remarks
 * 1.0       26 May 2020              		    This script handles client-side validations of Media Ocean suitelet
 * 1.1		11/19/2020      MJ De Asis		    Added Start Date/ End Date Range
 * 1.2		11/19/2020		MJ De Asis		    Vendor Filter
 * 1.3		06/17/2021		Marlon Villarama	Added FLD_STATUS parameter
 */
var FLD_AGENCY = 'custpage_agency';
var FLD_ACD_STATUS = 'custpage_acd_status';
var FLD_SL_DOMEDIA_PO = 'custpage_domedia_po';
var FLD_STATUS = 'custpage_status';
//var FLD_SL_PROJECT = 'custpage_project';
var FLD_SL_PRODUCT_CODE = 'custpage_ddproduct_code';
var FLD_SL_MARKET = 'custpage_market';
var FLD_SL_ESTIMATE = 'custpage_estimate';
var FLD_SL_CLIENT_CODE = 'custpage_client_code';
var FLD_SL_CLIENTS = 'custpage_client';
var SL_SUBLIST = 'custpage_sl_sublist';
var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
var FLD_SL_MEDIA_SUPPLIER = 'custpage_media_supplier';
var SCRIPT_OCEN_SL = 'customscript_appf_media_ocean_dds_script';
var DEPLOY_OCEN_SL = 'customdeployappf_media_ocean_dds_script';
var FLD_SL_START_DATE_FROM = 'custpage_start_date_from';
var FLD_SL_RATE_TYPE = 'custpage_type';
var BTN_APPLY_FILTER = 'custpage_apply_filters';
var MANDATORY_FIELDS = [FLD_AGENCY, FLD_ACD_STATUS, FLD_SL_PRODUCT_CODE, FLD_SL_ESTIMATE, FLD_SL_CLIENT_CODE, FLD_SL_CLIENTS];

/// v1.1
var FLD_SL_STARTDATERR_STARTDATE = 'custpage_startdaterr_startdate';
var FLD_SL_STARTDATERR_ENDDATE = 'custpage_startdaterr_enddate';
var FLD_SL_ENDDATERR_STARTDATE = 'custpage_enddaterr_startdate';
var FLD_SL_ENDDATERR_ENDDATE = 'custpage_enddaterr_enddate';

/// v1.2
var FLD_SL_VENDOR = 'custpage_vendor';

function applyFilters() {
	//var proj = nlapiGetFieldValue(FLD_SL_PROJECT);
	var client = nlapiGetFieldValue(FLD_SL_CLIENTS);
	var ACDStatus = nlapiGetFieldValue(FLD_ACD_STATUS);
	var ponum = nlapiGetFieldValue(FLD_SL_DOMEDIA_PO);
	var productCode = nlapiGetFieldValue(FLD_SL_PRODUCT_CODE);
	var clientCode = nlapiGetFieldValue(FLD_SL_CLIENT_CODE);
	var estimate = nlapiGetFieldValue(FLD_SL_ESTIMATE);
	var market = nlapiGetFieldValue(FLD_SL_MARKET);
	var typerate = nlapiGetFieldValue(FLD_SL_RATE_TYPE);
	var agency = nlapiGetFieldValue(FLD_AGENCY);
	var status = nlapiGetFieldValue(FLD_STATUS);
	var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_OCEN_SL, DEPLOY_OCEN_SL);
	suiteletURL = suiteletURL + '&agency=' + agency + '&client=' + client + '&ACDStatus=' + ACDStatus;
	suiteletURL += '&ponum=' + ponum + '&productCode=' + productCode + '&clientCode=' + clientCode + '&estimate=' + estimate + '&market=' + market + '&typerate=' + typerate;
	suiteletURL += '&status=' + status + '&applyfilters=T';

	/// v1.1
	var startDateStart = nlapiGetFieldValue(FLD_SL_STARTDATERR_STARTDATE);
	var startDateEnd = nlapiGetFieldValue(FLD_SL_STARTDATERR_ENDDATE);
	var endDateStart = nlapiGetFieldValue(FLD_SL_ENDDATERR_STARTDATE);
	var endDateENd = nlapiGetFieldValue(FLD_SL_ENDDATERR_ENDDATE);
	suiteletURL += '&startdaterr_startdate=' + startDateStart + '&startdaterr_enddate=' + startDateEnd;
	suiteletURL += '&enddaterr_startdate=' + endDateStart + '&enddaterr_enddate=' + endDateENd;

	/// v1.2
	var vendorVal = nlapiGetFieldValue(FLD_SL_VENDOR);
	suiteletURL += '&vendor=' + vendorVal;

	if ((client == null || client == '') && (ACDStatus == null || ACDStatus == '') && (estimate == null || estimate == '')) {
		alert('Please select any of the following fields: Client Name, ACD Status and DDS Estimate #');
		return false;
	} else {
		window.open(suiteletURL, '_self');
	}
}

function fieldChangePo(type, name, linenum) {
	if (MANDATORY_FIELDS.indexOf(name) != -1) {
		var client = nlapiGetFieldValue(FLD_SL_CLIENTS);
		var ACDStatus = nlapiGetFieldValue(FLD_ACD_STATUS);
		var ponum = nlapiGetFieldValue(FLD_SL_DOMEDIA_PO);
		var productCode = nlapiGetFieldValue(FLD_SL_PRODUCT_CODE);
		var clientCode = nlapiGetFieldValue(FLD_SL_CLIENT_CODE);
		var estimate = nlapiGetFieldValue(FLD_SL_ESTIMATE);
		var market = nlapiGetFieldValue(FLD_SL_MARKET);
		var typerate = nlapiGetFieldValue(FLD_SL_RATE_TYPE);
		var agency = nlapiGetFieldValue(FLD_AGENCY);
		var submBtnTr = document.getElementById('tr_submitter');
		var submBtnTr2 = document.getElementById('tr_secondarysubmitter');
		var submitterBtn = document.getElementById('submitter');
		var submitterBtn2 = document.getElementById('secondarysubmitter');
		if (agency != null && agency != '' && ACDStatus != null && ACDStatus != '' && estimate != null && estimate != '' && client != null && client != '' && clientCode != null && clientCode != '' && productCode != null && productCode != '') {
			/*
			if (submBtnTr)
		{
			submBtnTr.classList.toggle("pgBntBDis", false);
			submBtnTr.classList.toggle("pgBntB", true);

		}
		if (submBtnTr2)
		{
			submBtnTr2.classList.toggle("pgBntBDis", false);
			submBtnTr2.classList.toggle("pgBntB", true);
		}
		if (submitterBtn)
		{
			submitterBtn.disabled = false;
		}
		if (submitterBtn2)
		{
			submitterBtn2.disabled = false;
		}
		*/
		} else {
			if (submBtnTr) {
				submBtnTr.classList.toggle("pgBntB", false);
				submBtnTr.classList.toggle("pgBntBDis", true);
			}
			if (submBtnTr2) {
				submBtnTr2.classList.toggle("pgBntB", false);
				submBtnTr2.classList.toggle("pgBntBDis", true);
			}
			if (submitterBtn) {
				submitterBtn.disabled = true;
			}
			if (submitterBtn2) {
				submitterBtn2.disabled = true;
			}
		}
	}
	if (type == SL_SUBLIST) {
		if (name == FLD_COL_SL_SELECT) {
			var totAmt = 0;
			var totLines = 0;
			var count = nlapiGetLineItemCount(SL_SUBLIST);
			for (var c = 1; c <= count; c++) {
				var selected = nlapiGetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c);
				if (selected == 'T') {
					totLines++;
				}
			}
			nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
		}
	}
}

function onSaveVCSL() {
	var agency = nlapiGetFieldValue(FLD_AGENCY);
	var clientCode = nlapiGetFieldValue(FLD_SL_CLIENT_CODE);
	var productCode = nlapiGetFieldValue(FLD_SL_PRODUCT_CODE);
	if ((agency == null || agency == '') && (clientCode == null || clientCode == '') && (productCode == null || productCode == '')) {
		alert('Please enter Agency, DDS Client Code and DDS Product Code');
		return false;
	}
	if ((agency == null || agency == '') && (clientCode == null || clientCode == '')) {
		alert('Please enter Agency and DDS Client Code');
		return false;
	}
	if ((agency == null || agency == '') && (productCode == null || productCode == '')) {
		alert('Please enter Agency and DDS Product Code');
		return false;
	}
	if ((clientCode == null || clientCode == '') && (productCode == null || productCode == '')) {
		alert('Please enter DDS Client Code and DDS Product Code');
		return false;
	}
	if (agency == null || agency == '') {
		alert('Please enter Agency');
		return false;
	}
	if (clientCode == null || clientCode == '') {
		alert('Please enter DDS Client Code');
		return false;
	}
	if (productCode == null || productCode == '') {
		alert('Please enter DDS Product Code');
		return false;
	}
	var counter = 0;
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	if (count > 0) {
		for (var i = 1; i <= count; i++) {
			var checkbox = nlapiGetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, i);
			if (checkbox == 'T') counter++;
		}
	}
	if (counter == 0) {
		alert('Please select atleast one line to proceed.');
		return false;
	} else {
		var submitConfirmation = confirm('Selected transactions will be processed for Media Ocean DDS Suitelet, Click OK to proceed.');
		if (submitConfirmation == true) {
			return true;
		} else {
			return false;
		}
		//return true;
	}
}

function pageInit() {
	var totAmt = 0;
	var totLines = 0;
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	var markAll = false;
	for (var c = 1; c <= count; c++) {
		totLines++;
		markAll = true;
	}
	if (markAll) {
		nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
	}
}

function unmarkAll() {
	var unmarkAll = false;
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	for (var i = 1; i <= count; i++) {
		nlapiSetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, i, 'F');
		unmarkAll = true;
	}
	if (unmarkAll) {
		nlapiSetFieldValue(FLD_SL_TOTAL_LINES, '');
	}
}

function markAll() {
	var totLines = 0;
	var markAll = false;
	var count = nlapiGetLineItemCount(SL_SUBLIST);
	for (var c = 1; c <= count; c++) {
		nlapiSetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c, 'T');
		totLines++;
		markAll = true
	}
	if (markAll) {
		nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
	}
}
