/**
	 * Script Name : Appf-Process VVCCP Authorize Records
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			  Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';

//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_AUTHORIZATION_RECEIVE_DATE  ='custrecord_authorization_receive_date';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var CUSTOMRECORD_VITUAL_CREDIT_CARD_ID='custrecord_appf_vvccp_card_vvccp_link.internalid';
var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_UPDATES_RELATED_FILES_FOLDERID =979;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9
var CORPORATE_CREDIT_CARD_VVCCP='custentity_appf_vvccp_corporate_cc';
var FLD_VENDOR_PAYMENT_TYPE='custentity_appf_vendorpaymenttype';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var CUSTOM_RECORD_CORPORATE_CREDIT_CARDS='customrecord_appf_corp_card_table';
var FLD_CREDIT_CARD_TYPE='custrecord_appf_corp_credit_card_type';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias'

var CUSTOM_RECORD_PWP='customrecord_appf_pwp_wrapper_record';
var FLD_BILL_LINEAMOUNT_PAID='custrecord_appf_pwp_bill_line_amt_paid'
var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';

var SPARAM_COMPONY_EXPIRATION_DAY='custscript_appf_company_expiration_date';
var SPARAM_VVCCP_UPDATE_SEARCH='custscript_vvccp_update_search';
var TRANSACTION_TYPE_ADD='A';
var TRANSACTION_TYPE_DELETE='D';
var TRANSACTION_TYPE_MODIFY='M';

var NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID=2;
var NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID=7;

var STR_PAD_LEFT = 1;
var STR_PAD_RIGHT = 2;
var STR_PAD_BOTH = 3;

var USD=1;
var CAD=3;

var CUSTOM_RECORD_VIRTUAL_CREDIT_CARD='customrecord_appf_vvccp_authorized_card';
var FLD_CARD_NUMBER='custrecord_appf_vvccp_card_number';
var FLD_SECURITY_CODE='custrecord_appf_vvccp_card_code';
var FLD_EXPIRATION_DATE='custrecord_appf_vvccp_card_exp_date';
var FLD_PROVIDER='custrecord_appf_vvccp_card_provider';
var FLD_VENDOR_PAYMENT_LINK='custrecord_appf_vvccp_ven_pmt_link';
var FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD='custrecord_appf_vvccp_card_vvccp_link';
var FLD_CARD_CANCELLED='custrecord_appf_vvccp_card_cancelled';
var FLD_VOID_JOURNAL='custrecord_appf_vvccp_payment_void';
var FLD_AUTHORIZATION_DATE='custrecord_appf_vvccp_authorization_date';

var SPARAM_VVCCP_SEARCH_WITH_AUTHORISED_STATUS='';
var SPARAM_AMEX_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var SPARAM_MASTERCARD_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var VENDOR_PAYMENT_STATUS_APPROVEED_ID=2;
var FLD_VVCCP_BACKLINK='custbody_appf_vvccp_backlink';
var SPARAM_AUTHORIZED_VVCCP_RECORDS='custscript_process_authorize_vvccp';
var SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE='custscript_amex_contra_account';
var SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE='custscript_mastercard_contar_account';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var COL_FLD_PENDING_AUTHORIZATION_VVCCP='custcol_appf_pending_auth_vvccp';
var FLD_PENDING_AUTHORIZATION_VVCCP='custbody_appf_pending_auth_vvccp';
var FLD_VB_LINE_ID = 'custcol_appf_vendorbill_line_id';
function schedule(type)
{
	try
	{
		var context=nlapiGetContext();
		var authorisedVVCCPSearch=context.getSetting('SCRIPT', SPARAM_AUTHORIZED_VVCCP_RECORDS);
		var amexAccountFromCommanyPreference=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE);
		var masterCardAccountFromCommanyPreference=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE);
		//4.Process Authorized VVCCP Records
		var vvccpObj={}
		if(authorisedVVCCPSearch!=null && authorisedVVCCPSearch !='')
		{	
			var vvccpAuthorisedSearch=nlapiLoadSearch(null, authorisedVVCCPSearch);
			var vvccpAuthorisedSearchFilts = vvccpAuthorisedSearch.getFilters();
			var vvccpAuthorisedSearchColumns= vvccpAuthorisedSearch.getColumns();
			var vvccpAuthorisedSearchSSType = vvccpAuthorisedSearch.getSearchType();
			var searchForVVCCPWithAuthorisedStatus=getAllSearchResults(vvccpAuthorisedSearchSSType, vvccpAuthorisedSearchFilts, vvccpAuthorisedSearchColumns);		
			//Search Result for VVCCP which status are Authorised Results
			if(searchForVVCCPWithAuthorisedStatus !=null && searchForVVCCPWithAuthorisedStatus !='')
			{
				nlapiLogExecution('debug','searchForVVCCPWithAuthorisedStatus:',searchForVVCCPWithAuthorisedStatus.length);
				for(var a=0;a<searchForVVCCPWithAuthorisedStatus.length;a++)
				{
					var searchResults=searchForVVCCPWithAuthorisedStatus[a];
					var vvccpInternalId=searchResults.getId();
					nlapiLogExecution('debug','vvccpInternalId:',vvccpInternalId);
                  if(!vvccpObj.hasOwnProperty(vvccpInternalId))
					{
						vvccpObj[vvccpInternalId]=vvccpInternalId;
					var originalAuthorization=searchResults.getValue(FLD_ORIGINAL_AUTHORIZATION);
					var vendor=searchResults.getValue(FLD_VENDOR);
					nlapiLogExecution('debug','vendor:',vendor);
					var corporateCreditCard=searchResults.getValue(FLD_CORPORATE_CREDIT_CARD);
					var vvccpStatus=searchResults.getValue(FLD_VVCCP_STATUS);
					var vvccpName=searchResults.getValue('name');
					var vvccpDateCreated=searchResults.getValue('created');
					var minPurchaseAmount=searchResults.getValue(FLD_MINIMUM_TO_SPEND);
					var authorizationAmount=searchResults.getValue(FLD_MAXIMUM_TO_SPEND);
					var cardTypeSingleOrMulti=searchResults.getValue(FLD_TYPE);
					var vvccpCurrency=searchResults.getValue(FLD_CURRENCY);
					//nlapiLogExecution('debug','vvccpCurrency:',vvccpCurrency);
					var primarySubSidiaryOfVendor=searchResults.getValue('subsidiary',FLD_VENDOR,null);
					//nlapiLogExecution('debug','primarySubSidiaryOfVendor:',primarySubSidiaryOfVendor);
					var vvccpBatchLink=searchResults.getValue(FLD_VVCCP_BATCH_LINK);
					var creditCardType=searchResults.getValue(FLD_CREDIT_CARD_TYPE,FLD_CORPORATE_CREDIT_CARD);
					var cropCreditCardAlias=searchResults.getValue(FLD_CROP_CREDIT_CARD_ALIAS,FLD_CORPORATE_CREDIT_CARD);
					var responseFile=searchResults.getValue(FLD_RESPONSE_FILE);
					var virtualCreditCard=searchResults.getValue(CUSTOMRECORD_VITUAL_CREDIT_CARD_ID);
					nlapiLogExecution('debug','virtualCreditCard:',virtualCreditCard);
					var authorizationReceiveDate=searchResults.getValue(FLD_AUTHORIZATION_RECEIVE_DATE);
					var vvccpPaymentGenerated='';
					var vvccpLinkedTransactions=[]
					if(originalAuthorization == '')
					{
						var pwpRecordObj = {};
						var uniqueBills = {};
						var uniqueCredits = {};
						var filters=[];
						var columns=[];
						filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
						columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
						columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
						var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
						var vendorbillobj={};
						var vendorbillamtobj = {};
						var vendorcreditobj = {};
						var vendorcreditarr=[];
						//nlapiLogExecution('debug','searchOnVVCCPLinkedTransactions:',searchOnVVCCPLinkedTransactions);
						var billIdReqForTransform='';
						if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
						{
							for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
							{
								var billsearchResult=searchOnVVCCPLinkedTransactions[b];
								var vvccpLinkedTransactionInternalId=billsearchResult.getId();
								vvccpLinkedTransactions.push(vvccpLinkedTransactionInternalId);
								var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
								var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
								var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
								var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
								var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
								//nlapiLogExecution('debug','transactionTypes:',transactionTypes);
								
								if(transactionTypes == 17)
								{
									billIdReqForTransform=transactionId;
									pwpRecordObj[trnasactionLinePWP] = trnasactionLineAmount;
									if (!vendorbillobj.hasOwnProperty(transactionId))
									{
									vendorbillobj[transactionId] = [transactionLineId];
									vendorbillamtobj[transactionId] = parseFloat(trnasactionLineAmount);
									}
									else
									{
										var existingLineArr = vendorbillobj[transactionId];
										existingLineArr.push(transactionLineId);
										vendorbillobj[transactionId] = existingLineArr;
										var existingVBLineAmt = vendorbillamtobj[transactionId];
										existingVBLineAmt = parseFloat(existingVBLineAmt) + parseFloat(trnasactionLineAmount)
										vendorbillamtobj[transactionId] = existingVBLineAmt;
									}
									
								}
								else
								{
									if (!vendorcreditobj.hasOwnProperty(transactionId))
									{
									vendorcreditobj[transactionId] = parseFloat(trnasactionLineAmount);

									}
									else
									{
										
										var existingVCAmt = vendorcreditobj[transactionId];
										existingVCAmt = parseFloat(existingVCAmt) + parseFloat(trnasactionLineAmount)
										vendorcreditobj[transactionId] = existingVCAmt;
									}
									
									if (vendorcreditarr.indexOf(transactionId) == -1)
										vendorcreditarr.push(transactionId);
								}
							}
						}
						nlapiLogExecution('debug','vendorcreditobj:',JSON.stringify(vendorcreditobj));
						nlapiLogExecution('debug','vendorbillamtobj:',JSON.stringify(vendorbillamtobj));
						nlapiLogExecution('debug','vendorbillobj:',JSON.stringify(vendorbillobj));
						nlapiLogExecution('debug','vendorcreditarr:',vendorcreditarr);
						var paymentRecordId=null;
						try{
							var vendorPaymentRecord=nlapiTransformRecord('vendorbill', billIdReqForTransform, 'vendorpayment', {'recordmode':'dynamic'});
						//var vendorPaymentRecord=nlapiTransformRecord('vendor', vendor, 'vendorpayment',{'recordmode':'dynamic'})
						//vendorPaymentRecord.setFieldValue('entity',vendor);
						if(creditCardType == CREDIT_CARD_TYPE_AMEX && amexAccountFromCommanyPreference !=null && amexAccountFromCommanyPreference !='')
						vendorPaymentRecord.setFieldValue('account',amexAccountFromCommanyPreference);
						if(creditCardType == CREDIT_CARD_TYPE_MASTERCARD && masterCardAccountFromCommanyPreference !=null && masterCardAccountFromCommanyPreference !='')
						vendorPaymentRecord.setFieldValue('account',masterCardAccountFromCommanyPreference);
						if(authorizationReceiveDate !='' && authorizationReceiveDate !=null)
						vendorPaymentRecord.setFieldValue('trandate',authorizationReceiveDate);
						vendorPaymentRecord.setFieldValue('tranid',vvccpName);
						vendorPaymentRecord.setFieldValue('memo','VVCCP Payment Generated');
						vendorPaymentRecord.setFieldValue('approvalstatus',VENDOR_PAYMENT_STATUS_APPROVEED_ID);
						vendorPaymentRecord.setFieldValue(FLD_VVCCP_BACKLINK,vvccpInternalId);
						var linecount=vendorPaymentRecord.getLineItemCount('apply');
						nlapiLogExecution('debug','linecount:',linecount);
						if(linecount>0)
						{
							for(var k=1;k<=linecount;k++)
								{
									var tranId=vendorPaymentRecord.getLineItemValue('apply','doc',k);
									var payment=vendorPaymentRecord.getLineItemValue('apply','amount',k);
									var type=vendorPaymentRecord.getLineItemValue('apply','type',k);
									nlapiLogExecution('debug','type:',type);
									nlapiLogExecution('debug','payment:',payment);
									nlapiLogExecution('debug','tranId:',tranId);
									for(var vbprop in vendorbillamtobj)
									{
										if(parseInt(tranId) == parseInt(vbprop))
										{
											//nlapiLogExecution('debug','matching bill id:',vbprop+':_:'+vendorbillobj[vbprop].amount);
											vendorPaymentRecord.selectLineItem('apply',k);
											vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
											vendorPaymentRecord.setCurrentLineItemValue('apply','amount',parseFloat(vendorbillamtobj[vbprop]));
											vendorPaymentRecord.commitLineItem('apply');
										}
									}
									for(var vcprop in vendorcreditobj)
									{
										if(parseInt(tranId) == parseInt(vcprop))
										{
											//nlapiLogExecution('debug','matching bill credit id with Amount:',vcprop+':_:'+vendorcreditobj[vcprop].amount);
											vendorPaymentRecord.selectLineItem('apply',k);
											vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
											vendorPaymentRecord.setCurrentLineItemValue('apply','amount',-parseFloat(vendorcreditobj[vcprop]));
											vendorPaymentRecord.commitLineItem('apply');
										}
									}
								}
						}
						paymentRecordId=nlapiSubmitRecord(vendorPaymentRecord,true,true);
						}
						catch(e)
						{
													nlapiLogExecution('debug','failed to create payment for:'+vvccpInternalId,e);

						}

						/*if(vendor == 1122)
						paymentRecordId=27962;
						else if(vendor == 118848)
						paymentRecordId=27963;	
						else if(vvccpInternalId == 2918)
						paymentRecordId=27961;*/
					
						nlapiLogExecution('debug','paymentRecordId:',paymentRecordId);
						nlapiLogExecution('debug','vvccpLinkedTransactions:',vvccpLinkedTransactions);
						//4.ii(a)
						if(paymentRecordId !=null && paymentRecordId !='')
						{
							for(var v=0;vvccpLinkedTransactions.length > 0 && v<vvccpLinkedTransactions.length;v++)
								{
									nlapiSubmitField(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS,vvccpLinkedTransactions[v],[FLD_PAYMENT_LINK],[paymentRecordId]);
								}
							var filters=[];
							var columns=[];
							filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD, null, 'anyof', vvccpInternalId));
							var searchOnVirtualCreditCardRecord=getAllSearchResults(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD, filters, null);
							if(searchOnVirtualCreditCardRecord !=null && searchOnVirtualCreditCardRecord !='')
							{
								for(var vc=0;vc<searchOnVirtualCreditCardRecord.length;vc++)
								{
									var virtualCreditRecordId=searchOnVirtualCreditCardRecord[vc].getId();
									nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditRecordId,[FLD_VENDOR_PAYMENT_LINK],[paymentRecordId])
								}
							}
							
							if (vendorcreditarr.length>0)
							{
								for (var w = 0; w < vendorcreditarr.length; w++)
								{
									try{
									nlapiSubmitField('vendorcredit', vendorcreditarr[w], FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
									}
									catch(ex)
									{
									nlapiLogExecution('debug','failed to process bill credit:'+vendorcreditarr[w],e);
									}
								}
							}
							
							for (var vbprop in vendorbillobj)
							{
								try{
								var vbRecord = nlapiLoadRecord('vendorbill', vbprop);
								for (var e = 0; e < vendorbillobj[vbprop].length; e++)
								{
									var hasvbline = vbRecord.findLineItemValue('item', FLD_VB_LINE_ID, vendorbillobj[vbprop][e]);
									if (hasvbline != -1)
									{
										vbRecord.selectLineItem('item', hasvbline);
										vbRecord.setCurrentLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
										vbRecord.commitLineItem('item');
										
									}
									
								}
								nlapiSubmitRecord(vbRecord, true, true);
								}
								catch(ex)
								{
																						nlapiLogExecution('debug','failed to process bill:'+vbprop,e);

								}
							}
							
							for (var pwpprop in pwpRecordObj)
							{
								
								var vbPwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpprop);
							var currentPayAmt = parseFloat(pwpRecordObj[pwpprop]);
							var existingPayAmt = vbPwpRecord.getFieldValue(FLD_BILL_LINEAMOUNT_PAID);
							if (existingPayAmt == null || existingPayAmt == '')
								existingPayAmt = 0;
							existingPayAmt = parseFloat(existingPayAmt) + parseFloat(currentPayAmt);
							vbPwpRecord.setFieldValue(FLD_BILL_LINEAMOUNT_PAID, existingPayAmt);
							nlapiSubmitRecord(vbPwpRecord, true, true);
								
							}
							
						}
					}
					
					
				}
            }
			}
		}
	}	
	catch(e)
	{
		nlapiLogExecution('debug','Error Deatils:',e.toString());
	}
}	



function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		
function searchUnion(target, array)
{
		return target.concat(array); // TODO: use _.union
}
