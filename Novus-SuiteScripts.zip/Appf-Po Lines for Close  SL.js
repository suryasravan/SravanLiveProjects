/*Script Name: Appf - PO Lines Close Processed SL
 *Script Type: Suitelet
 *Company 	 : Appficiency
 * Version    Date            Author           Remarks
 * 1.0       15 May 2020     		          This script displays an UI/form with filters and columns based on Saved Search of  Purchase order line items which provides users with ability to mark multiple lines
 
 */
 
var FLD_SL_VENDOR = 'custpage_vendor';
var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_CURRENCY='custpage_currency';

var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment'; 
var FLD_SL_PROJECT = 'custpage_project';
var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
var FLD_SL_START_DATE_FROM= 'custpage_start_date_from';
var FLD_SL_IO_NUM = 'custpage_io_num';
var FLD_SL_MEDIA_SUPPLIER = 'custpage_media_supplier'; 

var FLD_SL_DATE_TO = 'custpage_date_to';
var FLD_SL_DATE_FROM= 'custpage_date_from';

var FLD_SL_PURCASE_ORDER_NUM = 'custpage_purchaseorder_num'; 
var FLD_SL_CLIENTS = 'custpage_client'; 

var FLD_SL_TOTAL_AMOUNT = 'custpage_total_amount';
var FLD_SL_TOTAL_LINES = 'custpage_total_lines';

var FLD_PWP_PROJECT = 'custrecord_appf_pwp_project';
var FLD_COL_PO_PWP_CUSTOM_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_PO_MEDIA_SEGMENT = 'line.cseg_appf_media_seg';
var FLD_COL_PO_IO_NUM = 'custcol_appf_ionum';
var FLD_COL_PO_MEDIA_SUPPLIERS = 'custcol_appf_publisher';

var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
var CUSTOM_FLD_CLIENT = 'custrecord_appf_pwp_client_link';

var CUSTOM_RECORD_MEDIA_SUPPLER = 'customrecord_appf_media_supplier'

var SCRIPT_MARK_PO_LINES_CLOSE_VALIDATIONS = 'customscript_appf_po_close_lines_valid';
var SPARAM_MARK_PO_LINES_FOR_CLOSE_SS = 'custscript_appf_close_po_lines_ss'; 
var SPARAM_MARK_PO_CLOSE_FOLDER= 'custscript_appf_po_lines_for_close_folde';

var SL_SUBLIST = 'custpage_sl_sublist';
var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
var FLD_COL_SL_INTERNAL_ID = 'custpage_so_internal_id';
var BTN_MARK_ALL = 'custpage_btn_mark_all';
var BTN_UNMARK_ALL = 'custpage_btn_unmark_all';
var BTN_APPLY_FILTER = 'custpage_apply_filters';

var SCRIPT_PO_LINES_CLOSE_SC = 'customscript_appf_po_lines_close_pros_sc';
var SPARAM_CSV_FILE_ID = 'custscript_appf_po_lines_close_folder';

var FLD_GROUP_PRIMARY_INFORMATION='custpage_primary_po_information';
var FLD_GROUP_FILTER='custpage_filters';
var FLD_GROUP_SUMMARY='custpage_summary';

function  POLinesSL(request, response){
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_MARK_PO_LINES_FOR_CLOSE_SS);
	var folderID = context.getSetting('SCRIPT', SPARAM_MARK_PO_CLOSE_FOLDER);
	var loadSS, filts, columns, ssType;
	if(ssID!=null && ssID!='')
    {
		loadSS=nlapiLoadSearch(null, ssID);
    	filts = loadSS.getFilters();
		columns=loadSS.getColumns();
	 	ssType = loadSS.getSearchType();		
	}	
	
	if(request.getMethod() == 'GET'){
		try{
		
		var applyfilters = request.getParameter('applyfilters');		
		 var vendorName=request.getParameter('vendorName');
		var mediaSegment=request.getParameter('mediaSegment');
		var mediaSupp=request.getParameter('mediasuppliers');
		var poNum=request.getParameter('ponum');
		var clientIo=request.getParameter('clientio');
		var proj=request.getParameter('proj');
		var fromDate=request.getParameter('fromDate');
		var toDate=request.getParameter('toDate');
		///var serviceDateFrom=request.getParameter('serviceDateFrom');
		var ioNum=request.getParameter('ioNum');
		var subsidiaryVal=request.getParameter('subsidiaryVal');
		var curr=request.getParameter('currency');
		var startDateTo=request.getParameter('strtdateto');
		var startDateFrom=request.getParameter('strtDateFrom');
		var invNum=request.getParameter('invnum');			

		var form = nlapiCreateForm('PO Lines Close Suitelet');
		form.setScript(SCRIPT_MARK_PO_LINES_CLOSE_VALIDATIONS);
		var PrimaryInformationGroup = form.addFieldGroup(FLD_GROUP_PRIMARY_INFORMATION, 'Primary Information');
		var filternGroup = form.addFieldGroup(FLD_GROUP_FILTER, 'Filters');
		var summarySectionGroup = form.addFieldGroup(FLD_GROUP_SUMMARY, 'Summary');

		var vendorFld = form.addField(FLD_SL_VENDOR, 'select', 'Vendor Name','vendor',FLD_GROUP_PRIMARY_INFORMATION);
		if(vendorName != null && vendorName != '')
			vendorFld.setDefaultValue(vendorName);
			//vendorFld.setMandatory(true);
			
		var fromDateFld = form.addField(FLD_SL_DATE_FROM, 'date','Date From', null,FLD_GROUP_FILTER);
		if(fromDate != null && fromDate != '')
			fromDateFld.setDefaultValue(fromDate);
		
		
		var toDateFld = form.addField(FLD_SL_DATE_TO, 'date','Date To', null,FLD_GROUP_FILTER);
		if(toDate != null && toDate != '')
			toDateFld.setDefaultValue(toDate);

      var mediaSuppFld = form.addField(FLD_SL_MEDIA_SUPPLIER, 'multiselect','Publisher/Media Supplier',CUSTOM_RECORD_MEDIA_SUPPLER,FLD_GROUP_FILTER);
		if(mediaSupp != null && mediaSupp != '')
			mediaSuppFld.setDefaultValue(mediaSupp);
		
		var projectFld = form.addField(FLD_SL_PROJECT, 'select','Project', 'job',FLD_GROUP_FILTER);
		if(proj != null && proj != '')
			projectFld.setDefaultValue(proj);

		
		var mediaSegFld = form.addField(FLD_SL_MEDIA_SEGMENT, 'select','Media Segment',CUSTOM_RECORD_MEDIA_SEGMENT,FLD_GROUP_FILTER);
		if(mediaSegment != null && mediaSegment != '')
			mediaSegFld.setDefaultValue(mediaSegment);
		
		var PoFld = form.addField(FLD_SL_PURCASE_ORDER_NUM, 'text','Purchase order #',null,FLD_GROUP_FILTER);
		if(poNum != null && poNum != '')
			PoFld.setDefaultValue(poNum);
	
	var startDateFromFld = form.addField(FLD_SL_START_DATE_FROM, 'date','Start Date (RR) From',null,FLD_GROUP_FILTER);
		if(startDateFrom!= null && startDateFrom!= '')
			startDateFromFld.setDefaultValue(startDateFrom); 
		
		var startDateToFld = form.addField(FLD_SL_START_DATE_TO, 'date','Start Date (RR) To',null,FLD_GROUP_FILTER);
		if(startDateTo!= null && startDateTo!= '')
			startDateToFld.setDefaultValue(startDateTo);
	
		var ioNumFld = form.addField(FLD_SL_IO_NUM, 'text','IO #',null,FLD_GROUP_FILTER);
		if(ioNum != null && ioNum != '')
			ioNumFld.setDefaultValue(ioNum);
		
		var clientFld = form.addField(FLD_SL_CLIENTS, 'select','Client','customer',FLD_GROUP_FILTER);
		if(clientIo != null && clientIo != '')
			clientFld.setDefaultValue(clientIo);
			
	    var subsidiaryFld = form.addField(FLD_SL_SUBSIDIARY, 'select', 'Subsidiary','subsidiary',FLD_GROUP_PRIMARY_INFORMATION);
		//subsidiaryFld.setMandatory(true);
	    if(subsidiaryVal != null && subsidiaryVal != '')
			subsidiaryFld.setDefaultValue(subsidiaryVal);
			if(vendorName != null && vendorName != '')
            subsidiaryFld.setDisplayType('disabled')
          else
            subsidiaryFld.setDisplayType('normal')
				
		var currencyFld = form.addField(SL_FLD_CURRENCY, 'select', 'Currency','currency',FLD_GROUP_PRIMARY_INFORMATION);
		currencyFld.setDisplayType('disabled');
	   if(curr != null && curr != '')
	    currencyFld.setDefaultValue(curr);
          currencyFld.setBreakType('startcol')
		  
		 
		
         var totalAmtFld = form.addField(FLD_SL_TOTAL_AMOUNT, 'currency', 'Total Amount',null,FLD_GROUP_SUMMARY).setDisplayType('disabled');
		var totalLines = form.addField(FLD_SL_TOTAL_LINES, 'integer', 'Total Lines',null,FLD_GROUP_SUMMARY).setDisplayType('disabled');
		if(applyfilters == 'T')
        {

		var suiteletSublist = form.addSubList(SL_SUBLIST,'list', 'Purchase Orders');
		suiteletSublist.addButton(BTN_MARK_ALL, 'Mark All', 'markAll();')
		suiteletSublist.addButton(BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();')
	    var selctedFld = suiteletSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
		selctedFld.setDisplayType('entry');
		selctedFld.setDefaultValue('T');
	    //suiteletSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');

		var filters =[];
		
		if(vendorName != null && vendorName != '')
		filters.push(new nlobjSearchFilter('name', null, 'anyof', vendorName));
		
		if(mediaSegment != null && mediaSegment != '')
		filters.push(new nlobjSearchFilter(FLD_COL_PO_MEDIA_SEGMENT, null, 'anyof', mediaSegment));
	
	    if(mediaSupp != null && mediaSupp != '')
		filters.push(new nlobjSearchFilter(FLD_COL_PO_MEDIA_SUPPLIERS, null, 'anyof', mediaSupp));
		
		if(proj != null && proj != '')
		filters.push(new nlobjSearchFilter(FLD_PWP_PROJECT, FLD_COL_PO_PWP_CUSTOM_RECORD, 'anyof', proj));
		
		
		if(fromDate != null && fromDate != '' && toDate!= null && toDate != '')
		filters.push(new nlobjSearchFilter('trandate', null, 'within', fromDate, toDate));
		if(fromDate != null && fromDate != '' && (toDate == null || toDate == ''))
		filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', fromDate));
		if((fromDate == null || fromDate == '') && toDate != null && toDate != '')
		filters.push(new nlobjSearchFilter('trandate', null, 'onorbefore', toDate));
	

      if(startDateFrom != null && startDateFrom != '' && startDateTo != null && startDateTo != '')
		filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'within', startDateFrom, startDateTo));
		if(startDateFrom != null && startDateFrom != '' && (startDateTo == null || startDateTo == ''))
		filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'onorafter', startDateFrom));
		if((startDateFrom == null || startDateFrom == '') && startDateTo != null && startDateTo != '')
		filters.push(new nlobjSearchFilter('custcolappf_so_line_startdate', null, 'onorbefore', startDateTo));
	
	  if(clientIo != null && clientIo != '')
		filters.push(new nlobjSearchFilter(CUSTOM_FLD_CLIENT, FLD_COL_PO_PWP_CUSTOM_RECORD, 'anyof', clientIo));
	
		if(ioNum != null && ioNum != '')
		filters.push(new nlobjSearchFilter(FLD_COL_PO_IO_NUM, null, 'is', ioNum));
	
	     if(poNum != null && poNum != '')
		filters.push(new nlobjSearchFilter('tranid', null, 'contains', poNum));

		if(subsidiaryVal != null && subsidiaryVal != '')
		filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsidiaryVal));
	
		if(curr != null && curr != '')
		filters.push(new nlobjSearchFilter('currency', null, 'anyof', curr));
	
		if(ssID != null && ssID != ''){	
    	 	var colArray=[];
    		var colIndex=1;
			var scriptfieldcounter = 1;
			for(var c=0;c<columns.length;c++)
			{
				var colObj = columns[c];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				colName = colName.replace('.', '_');
				if(colArray.indexOf(colName) == -1)
				{
					colArray.push(colName);
				}
				else
				{
					colName=colName+colIndex;
                  	colArray.push(colName);
					colIndex++;
				}
				if (colLabel != 'Script Use DNR')
                {
					suiteletSublist.addField('custpage_'+colName, 'text', colLabel);
                }
                else
                {
                    var scriptField = suiteletSublist.addField('custpage_scriptfield'+scriptfieldcounter, 'text', colLabel);
					scriptField.setDisplayType('hidden');
                    scriptfieldcounter++;
                }
			
		    }
			
			var resultFilters = filters.concat(filts);
		
			var searchResults=getAllSearchResults(ssType, resultFilters, columns);
			if (searchResults != null && searchResults != '') {
				for(var s = 0; s < searchResults.length; s++) {					
					var result = searchResults[s];
					var internalid = result.getId();					
					var colIndex = 1;
					var colArray = [];
					var scriptfieldcounter = 1;
					for(var c=0;c<columns.length;c++){
                      	var colObj = columns[c];
						var columnName = colObj.getName();
						var colLabel = colObj.getLabel();
						columnName = columnName.replace('.', '_');
						var ssResultValue = result.getValue(colObj);
						if(colObj.getType() == 'select')
						{
						 ssResultValue = result.getText(colObj);                        
						}
						if(colArray.indexOf(columnName) == -1)
						{
							colArray.push(columnName);
						}
						else
						{
							columnName=columnName+colIndex;
                          	colArray.push(columnName);
							colIndex++;
						}
						if(columnName == 'tranid'){
							var url=nlapiResolveURL('RECORD','purchaseorder',internalid);
							var redirect ='<a href='+url+' target="_blank">'+ssResultValue+'</a>';
							ssResultValue = redirect;
						}
						if (colLabel != 'Script Use DNR')
						{
							suiteletSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
						}
						else
						{
							suiteletSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounter, s+1, ssResultValue);								
							scriptfieldcounter++;
						}						

					}
				}
			  	
			}
		}
		}
		
		form.addButton(BTN_APPLY_FILTER, 'Apply Filters', 'applyFilters()');
		form.addSubmitButton('Submit');
		response.writePage(form);
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}		
	}
	else{
		try{
			
			
			var count = request.getLineItemCount(SL_SUBLIST);
						
			if(count > 0 && columns != null && columns != ''){					
				var csvData = '';
              var labelctr = 1;
				for(var cl=0; cl<columns.length; cl++){
					var colObj = columns[cl];
					var colLabel = colObj.getLabel();
                  if (colLabel == 'Script Use DNR')
                    {
                    colLabel += ' ' +labelctr;
                     labelctr++;
					 csvData += colLabel+',';
                    }
					
				}
				csvData = csvData.slice(0, -1)+'\n';
				for(var c=1; c<=count; c++){
					if(request.getLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c) == 'T'){					
						var scriptfieldcounter = 1;
						for(var cl=0; cl<columns.length; cl++){
							var colObj = columns[cl];
							var colLabel = colObj.getLabel();
							var colName = colObj.getName();
							colName = colName.replace('.', '_');
							var colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_'+columnName, c);
							if (colLabel == 'Script Use DNR')
							{
								colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield'+scriptfieldcounter, c);
								scriptfieldcounter++;
								csvData += colValue+',';
							}
							
						}
						csvData = csvData.slice(0, -1)+'\n';
					}
				}
				var timestamp = new Date().getTime();
				var csvFile = nlapiCreateFile('SelectedPOData_'+timestamp+'.csv', 'CSV', csvData);
				csvFile.setFolder(folderID);
				var csvFileID = nlapiSubmitFile(csvFile);
				if(csvFileID != null && csvFileID != ''){
					var params = {};
					params[SPARAM_CSV_FILE_ID] = csvFileID;
					nlapiScheduleScript(SCRIPT_PO_LINES_CLOSE_SC, null, params);
					response.sendRedirect('TASKLINK', 'ADMI_IMPORTCSV_LOG');
				}
			}	
						
		}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
	}
}

function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
	function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}