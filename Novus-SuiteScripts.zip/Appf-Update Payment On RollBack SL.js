/**
 * Script Name: Appf-Update Payment On RollBack SL
 * Script Type: Suitelet
 *
 *
 * Version    Date            Author           Remarks
 * 1.00       3 March 2020    Debendra Panigrahi The script get trigger on click of "Rollback" button and then unapply all the Invoices
 * and creditMemos attached to it and then update the "Payment Application Linked Transaction"
 * records attached with the payment records.
 *
 * Company : Appficiency.
 */
var CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION='customrecord_appf_pay_app_linked_trans';
var FLD_PAYMENT_TRANSACTION_LINK='custrecord_appf_pay_app_pmt_link';
var FLD_TRANSACTION_LINK='custrecord_appf_pay_app_tran_link'
var FLD_TRANSACTION_LINE_ID='custrecord_appf_pay_app_tran_lineid';
var FLD_TRANSACTION_LINE_AMOUNT='custrecord_appf_pay_app_tran_line_amt';
var FLD_TRANSACTION_LINE_PWP='custrecord_appf_pay_app_line_pwp';
var FLD_CREDITS_APPLIED = 'custbody_appf_credits_applied';
var FLD_TRANSACTION_LINE_APPLIED_INVOICE = 'custrecord_applied_to_invoice_link';
FLD_TRANSACTION_LINE_TRANSACTION_ID = 'custrecord_appf_pay_app_tran_link';

var CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD='customrecord_appf_pwp_wrapper_record';
var FLD_INVOICE_LINE_PAYMENT_AMOUNT='custrecord_appf_pwp_inv_line_amt_paid';

var invoiceArray = [];
var crediMemoArray=[];
function rollbackOfPayment(request,response)
{
var paymentRecordId=request.getParameter('paymentRecordId');
var customerPayment=nlapiLoadRecord('customerpayment',paymentRecordId);
var lineCountOfInvoices=customerPayment.getLineItemCount('apply');
var lineCountOfCredits=customerPayment.getLineItemCount('credit');

for(var i=1; lineCountOfInvoices > 0 && i<=lineCountOfInvoices; i++)
{
var isapplied = customerPayment.getLineItemValue('apply', 'apply', i);
var invamt = customerPayment.getLineItemValue('apply','amount', i);
if (isapplied == 'T')
{
	invoiceArray.push(customerPayment.getLineItemValue('apply','doc',i));
}


customerPayment.selectLineItem('apply',i);
customerPayment.setCurrentLineItemValue('apply','apply','F');
customerPayment.commitLineItem('apply');

}
var hasCreditsApplied = customerPayment.getFieldValue(FLD_CREDITS_APPLIED);
  var creditsApplied= [];
if(hasCreditsApplied != null && hasCreditsApplied != '')
{
	creditsApplied = customerPayment.getFieldValues(FLD_CREDITS_APPLIED);
}

//var concatedCreditAndInvoiceArray=invoiceArray.concat(crediMemoArray);
nlapiSubmitRecord(customerPayment,true,true);
var filters=[];
if(paymentRecordId !=null && paymentRecordId !='')
filters.push(new nlobjSearchFilter(FLD_PAYMENT_TRANSACTION_LINK, null, 'anyof',paymentRecordId));
filters.push(new nlobjSearchFilter('isinactive', null, 'is','F'));
var columns=[];
columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_APPLIED_INVOICE));
columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_TRANSACTION_ID));




var paymentApplicationLinkedTransactionRecSearch=nlapiSearchRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION,null,filters,columns);
if(paymentApplicationLinkedTransactionRecSearch !=null && paymentApplicationLinkedTransactionRecSearch !='')
{
	var creditmemoobj = {};
for(var s=0;s<paymentApplicationLinkedTransactionRecSearch.length;s++)
{
var pwpID=paymentApplicationLinkedTransactionRecSearch[s].getValue(FLD_TRANSACTION_LINE_PWP);
var currentPayment = paymentApplicationLinkedTransactionRecSearch[s].getValue(FLD_TRANSACTION_LINE_AMOUNT);
var appliedInv = paymentApplicationLinkedTransactionRecSearch[s].getValue(FLD_TRANSACTION_LINE_APPLIED_INVOICE);
var transactionID = paymentApplicationLinkedTransactionRecSearch[s].getValue(FLD_TRANSACTION_LINE_TRANSACTION_ID);

if (pwpID != null && pwpID != '' && currentPayment != null && currentPayment != '')
{

var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD, pwpID);
var existingInvLinePayment = pwpRecord.getFieldValue(FLD_INVOICE_LINE_PAYMENT_AMOUNT);
if (existingInvLinePayment == null || existingInvLinePayment == '')
existingInvLinePayment = 0;

existingInvLinePayment = parseFloat(existingInvLinePayment) - parseFloat(currentPayment);

pwpRecord.setFieldValue(FLD_INVOICE_LINE_PAYMENT_AMOUNT, existingInvLinePayment);
            nlapiSubmitRecord(pwpRecord);
}

if (appliedInv != null && appliedInv != '' && transactionID != null && transactionID != '')
{
	if (!creditmemoobj.hasOwnProperty(transactionID))
	{
		creditmemoobj[transactionID]=[appliedInv+'||'+currentPayment];
	}
	else
	{
		var extarr = creditmemoobj[transactionID];
		extarr.push(appliedInv+'||'+currentPayment);
		creditmemoobj[transactionID]=extarr;
	}
}
nlapiSubmitField(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paymentApplicationLinkedTransactionRecSearch[s].getId(), 'isinactive', 'T');


}
}
if(creditsApplied.length>0)
{
    nlapiLogExecution('debug', 'creditsApplied', creditsApplied+'')

for(var cmemoprop in creditmemoobj)
{
	var creditMemoRec=nlapiLoadRecord('creditmemo',cmemoprop);
	
	var applInvs = creditmemoobj[cmemoprop];
	for (var a = 0; a < applInvs.length; a++)
	{
		var hasinv = creditMemoRec.findLineItemValue('apply', 'doc', applInvs[a].split('||')[0]);
		if (hasinv != -1)
		{
			      		var isapplied=creditMemoRec.getLineItemValue('apply','apply',hasinv);
									      		var isappliedamt=creditMemoRec.getLineItemValue('apply','amount',hasinv);

						if (isapplied == 'T')
  {
	  creditMemoRec.selectLineItem('apply',hasinv)
			creditMemoRec.setCurrentLineItemValue('apply','amount', parseFloat(isappliedamt) - parseFloat(applInvs[a].split('||')[1]));
			creditMemoRec.commitLineItem('apply');
  }

		}
	}
	
	nlapiSubmitRecord(creditMemoRec,true,true);
}
}
if(paymentRecordId !=null && paymentRecordId !='')
{
response.sendRedirect('RECORD', 'customerpayment', paymentRecordId);
}

}