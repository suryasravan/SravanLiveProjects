function sched()
{
			var context=nlapiGetContext();
		var fileid =context.getSetting('SCRIPT','custscript_testfile1');
		
		//var fileobj = nlapiLoadFile(fileid);
		var cmARr = fileid.split(',');
		var index =context.getSetting('SCRIPT','custscript_testsch1');
  if (index == null || index == '')
    index = 0;
  nlapiLogExecution('debug', 'cmARr len', cmARr.length)

for (var d = index; d < cmARr.length; d++)
{
try{
var cmrec = nlapiLoadRecord('invoice', cmARr[d]);

cmrec.setLineItemValue('item', 'custcol_appf_pwp_inv_line_amt_paid', 1, 0);

nlapiSubmitRecord(cmrec, true, true);
} catch(e)
{
    nlapiLogExecution('debug', 'err', e.toString())
	break;
}


if (context.getRemainingUsage() <= 1000 && (parseInt(d)+1) < cmARr.length)
							{
  nlapiLogExecution('debug', 'cmARr[d]', cmARr[d])

								var params_pcpalt = {};
								params_pcpalt['custscript_testsch1'] = parseInt(d)+1;
								params_pcpalt['custscript_testfile1'] = fileid;
nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_pcpalt);
                              break;
							}
}
}