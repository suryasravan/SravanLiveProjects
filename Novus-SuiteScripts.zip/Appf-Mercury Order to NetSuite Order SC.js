/**
*Script Name: Appf-Mercury Order to NetSuite Order SC
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Mercury Order and pushes the Order from those messages into netsuite and creates or updates as Order records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
* Version   Author              Date                Description
* 1.1       MJ De Asis          11/18/2020          Excludes Line Item Field's Item to be updated.
*/
var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS = 'customrecord_appf_print_mercury_order_in';
var CUSTOMRECORD_FLD_APPF_MESSAGE = 'custrecord_appf_order_messageid';
var CUSTOMRECORD_FLD_APPF_CONTENT_LINK = 'custrecord_appf_order_jsoncontent';
var CUSTOMRECORD_FLD_APPF_QUEU_NAME = 'custrecord_appf_order_queuename';
var CUSTOMRECORD_FLD_APPF_NS_RESPONSE = 'custrecord_appf_order_response';
var CUSTOMRECORD_FLD_APPF_CLIENTS = 'custrecord_order_id';
var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_response_order_status';
var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_netsuite_response';
var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_order_correl_id';
var CUSTOMRECORD_FLD_CONNEX_NS_RESP = 'custrecord_appf_ns_mercu_orders_response';
// Integration Related
var addressBookFields = ['addr1', 'country', 'state', 'zip', 'city', 'addr2', 'addr3', 'attention', 'addressee'];
// Integration Related
var QUEUE_CONNEX_ORDER_INBOUND = 'novusmedia_mercury_order_in';
//novusmedia_connex_client_in
var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_buyingsystem_salesorder_change';
var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
var addressBookFields = ['addr1', 'country', 'state', 'zip', 'city', 'addr2', 'addr3', 'attention', 'addressee'];
var FLD_CONNEX = 'custentity_appf_buyingsystem_id'
var NS_CLIENT = 'Novus.Framework.Models.Orders.Response.NetSuite.SalesOrderResponseMessage'
// var NS_CLIENT = 'Novus.Azure.WebJobs.NetSuite.Dtos.SalesOrderResponse'
// var FLD_CONNEX = 'custentity_appf_buyingsystem_id'
// var NS_CLIENT = 'Novus.Azure.WebJobs.NetSuite.Dtos.SalesOrderResponse'
var SPARAM_CONNEX_CLIENT = 'customscript_appmercury_order_to_netsuit'
var SPARAM_SB3_URL_BASE = 'custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE = 'custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE = 'custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE = 'custscript_prod_signature'
var SPARAM_SB1_URL_BASE = 'custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE = 'custscript_sb1_signature'
var SPARAM_SB2_URL_BASE = 'custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE = 'custscript_sb2_signature'

function createOrderScheduled(type) {
	var context = nlapiGetContext();
	var URL_BASE = ''
	var signatures = ''
	var context = nlapiGetContext();
	var userAccountId = context.getCompany();
	if (userAccountId == '3619984_SB3') {
		URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
		signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
	}
	if (userAccountId == '3619984_SB2') {
		URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
		signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
	}
	if (userAccountId == '3619984') {
		URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
		signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
	}
	if (URL_BASE != null && URL_BASE != '') {
		var messagesFound = true
		while (messagesFound == true) {
			var usageRemaining = context.getRemainingUsage();
			var idForResponse = '';
			var pareConnex = ''
			var d = new Date();
			var UTCDate = d.toISOString();
			var url = URL_BASE + QUEUE_CONNEX_ORDER_INBOUND + '/messages/head?api-version=2015-01';
			var HEADERS = {
				"Authorization": signatures,
				"Date": UTCDate,
				"Content-Type": 'application/xml'
			};
			var responseData = nlapiRequestURL(url, null, HEADERS, 'DELETE');
			var mainObj = responseData.getBody() + '';
			nlapiLogExecution('debug', 'mainObj content', mainObj);
			var CorrelationIdProp = 'NServiceBus.CorrelationId'
			var EnclosedMessageProp = 'NServiceBus.EnclosedMessageTypes'
			var CorrelationId = responseData.getHeader(CorrelationIdProp)
			var EnclosedMessageTypes = responseData.getHeader(EnclosedMessageProp)
			var Status = ''
			var Status1 = ''
			var scriptStatus = ''
			var fileData = ''
			if (mainObj == null || mainObj == '') {
				messagesFound = false;
				Status = 'FAILED' + '(Empty Message)'
				scriptStatus = 'FAILED'
				Status1 = 'FAILED' + '(Empty Message)'
			} else {
				try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1); // to remove { if exists as first charecter
					mainObj = mainObj.slice(0, mainObj.lastIndexOf("}")); // to remove } if exists as last charecter
					fileData = '{' + mainObj + '}'; //concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if (mainObj.hasOwnProperty('custbody_appf_buyingsystem_id')) {
						pareConnex = mainObj['custbody_appf_buyingsystem_id'];
						nlapiLogExecution('debug', 'pareConnex:', pareConnex);
					}
					Status = 'SUCCESS'
				} catch (e) {
					Status = 'FAILED' + '(invalid JSON)'
					scriptStatus = 'FAILED'
					Status1 = 'FAILED' + '(invalid JSON)'
				}
			}
			var responseDataAllHeaders = responseData.getAllHeaders()
			var responseData3 = responseDataAllHeaders[3]
			var responseDataProp = responseData.getHeader(responseData3)
			var integrationResponseObj = {}
			if (responseData.getCode() != '200' && responseData.getCode() != '201') {
				messagesFound = false;
				if (responseData.getCode() != '204') {
					scriptStatus = 'FAILED'
					var integrationRecord = nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
					integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE, responseDataProp)
					integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK, fileData)
					integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME, QUEUE_CONNEX_ORDER_INBOUND)
					integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, 'FAILED')
					//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
					integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
					//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
					nlapiSubmitRecord(integrationRecord, true, true)
				}
			} else {
				var nsOrderRecord = '';
				var isNewRecord = true;
				var nsOrderCounts = 0;
				var internalId = ''
				var isUpdateRecord = true;
				var nsCreationMsg = '';
				try {
					if (!mainObj.hasOwnProperty('id')) {
						nsOrderRecord = nlapiCreateRecord('salesorder')
						if (mainObj.hasOwnProperty('custbody_appf_buyingsystem_id')) {
							var ConnexId = mainObj['custbody_appf_buyingsystem_id']
							nlapiLogExecution('debug', 'ConnexId:', ConnexId);
							if (ConnexId != null && ConnexId != '') {
								var nsfils = [];
								nsfils.push(new nlobjSearchFilter('custbody_appf_buyingsystem_id', null, 'is', ConnexId));
								nsfils.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
								nsfils.push(new nlobjSearchFilter('type', null, 'is', 'SalesOrd'));
								var custRecord = nlapiSearchRecord('transaction', null, nsfils);
								if (custRecord != null && custRecord != '') {
									nlapiLogExecution('debug', 'custRecord', custRecord);
									if (custRecord.length > 0) {
										internalId = custRecord[0].getId()
										nlapiLogExecution('debug', 'internalIdin:', internalId);
										idForResponse = internalId
										nsOrderRecord = nlapiLoadRecord('salesorder', internalId);
										var nsOrderRecordStatus = nsOrderRecord.getFieldValue('status');
										var buyingSystemText = nsOrderRecord.getFieldText('custbody_appf_buying_system');
										var orderStatusId = nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
										/*if(nsOrderRecordStatus=='Closed')  //v2 removed 9/4/2020
								{
								 Status='FAILED'
								 scriptStatus='FAILED'
								 nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
			         }*/
										if ((buyingSystemText == 'Print' || buyingSystemText == 'Digital') && orderStatusId == 5) {
											Status = 'FAILED'
											// scriptStatus = 'FAILED'
											scriptStatus = 'WARNING'
											nsCreationMsg = 'Cannot update Confirmed Cancelled orders in Netsuite'
										}
										nsOrderCounts = nsOrderRecord.getLineItemCount('item')
										if (nsOrderCounts >= 1) isNewRecord = false
										var msdate = ''
										var nsdate = nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
										if (mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate')) {
											msdate = mainObj['custbody_appf_integr_lastupdatedate']
										}
										if (nsdate != null && nsdate != '' && msdate != null && msdate != '') {
											var nsdateTm = nlapiStringToDate(nsdate, 'datetimetz')
											var MsdateTm = nlapiStringToDate(msdate, 'datetimetz')
											if (MsdateTm > nsdateTm) {
												isUpdateRecord = true;
											} else {
												isUpdateRecord = false
											}
										}
									}
								}
							}
						}
					} else {
						var internalId = mainObj['id']
						nlapiLogExecution('debug', 'internalId', internalId);
						if (internalId == null || internalId == '' || internalId == 'null') {
							nsOrderRecord = nlapiCreateRecord('salesorder')
							if (mainObj.hasOwnProperty('custbody_appf_buyingsystem_id')) {
								var ConnexId = mainObj['custbody_appf_buyingsystem_id']
								nlapiLogExecution('debug', 'ConnexId:', ConnexId);
								if (ConnexId != null && ConnexId != '') {
									var nsfils = [];
									nsfils.push(new nlobjSearchFilter('custbody_appf_buyingsystem_id', null, 'is', ConnexId));
									nsfils.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
									nsfils.push(new nlobjSearchFilter('type', null, 'is', 'SalesOrd'));
									var custRecord = nlapiSearchRecord('transaction', null, nsfils);
									if (custRecord != null && custRecord != '') {
										nlapiLogExecution('debug', 'custRecord', custRecord);
										if (custRecord.length > 0) {
											internalId = custRecord[0].getId()
											nlapiLogExecution('debug', 'internalIdin:', internalId);
											idForResponse = internalId
											nsOrderRecord = nlapiLoadRecord('salesorder', internalId);
											var nsOrderRecordStatus = nsOrderRecord.getFieldValue('status');
											var buyingSystemText = nsOrderRecord.getFieldText('custbody_appf_buying_system');
											var orderStatusId = nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
											/*if(nsOrderRecordStatus=='Closed') //v2 removed 9/4/2020
								{
								 Status='FAILED'
								 scriptStatus='FAILED'
								 nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
			         }*/
											if ((buyingSystemText == 'Print' || buyingSystemText == 'Digital') && orderStatusId == 5) {
												Status = 'FAILED'
												// scriptStatus = 'FAILED'
												scriptStatus = 'WARNING'
												nsCreationMsg = 'Cannot update Confirmed Cancelled orders in Netsuite'
											}
											nsOrderCounts = nsOrderRecord.getLineItemCount('item')
											if (nsOrderCounts >= 1) isNewRecord = false
											var msdate = ''
											var nsdate = nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
											if (mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate')) {
												msdate = mainObj['custbody_appf_integr_lastupdatedate']
											}
											if (nsdate != null && nsdate != '' && msdate != null && msdate != '') {
												var nsdateTm = nlapiStringToDate(nsdate, 'datetimetz')
												var MsdateTm = nlapiStringToDate(msdate, 'datetimetz')
												if (MsdateTm > nsdateTm) {
													isUpdateRecord = true;
												} else {
													isUpdateRecord = false
												}
											}
										}
									}
								}
							}
						} else {
							idForResponse = internalId
							nsOrderRecord = nlapiLoadRecord('salesorder', internalId);
							var nsOrderRecordStatus = nsOrderRecord.getFieldValue('status');
							var buyingSystemText = nsOrderRecord.getFieldText('custbody_appf_buying_system');
							var orderStatusId = nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
							/*if(nsOrderRecordStatus=='Closed') //v2 removed 9/4/2020
								{
								 Status='FAILED'
								 scriptStatus='FAILED'
								 nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
			         }*/
							if ((buyingSystemText == 'Print' || buyingSystemText == 'Digital') && orderStatusId == 5) {
								Status = 'FAILED'
								// scriptStatus = 'FAILED'
								scriptStatus = 'WARNING'
								nsCreationMsg = 'Cannot update Confirmed Cancelled orders in Netsuite'
							}
							nsOrderCounts = nsOrderRecord.getLineItemCount('item')
							if (nsOrderCounts >= 1) isNewRecord = false
							var msdate = ''
							var nsdate = nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
							if (mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate')) {
								msdate = mainObj['custbody_appf_integr_lastupdatedate']
							}
							if (nsdate != null && nsdate != '' && msdate != null && msdate != '') {
								var nsdateTm = nlapiStringToDate(nsdate, 'datetimetz')
								var MsdateTm = nlapiStringToDate(msdate, 'datetimetz')
								if (MsdateTm > nsdateTm) {
									isUpdateRecord = true;
								} else {
									isUpdateRecord = false
								}
							}
						}
					}
				} catch (e1) {
					scriptStatus = 'FAILED'
					if (e1 instanceof nlobjError) nsCreationMsg = e1.getDetails();
					else nsCreationMsg = e1.toString();
				}
				var integrationRecord = nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
				integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE, responseDataProp)
				integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK, fileData)
				integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME, QUEUE_CONNEX_ORDER_INBOUND)
				integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
				//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
				integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
				//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
				var integrationRecordID = nlapiSubmitRecord(integrationRecord, true, true);
				var nsOrderRecordID = null;
				if (Status == null || Status == '' || Status == 'SUCCESS') {
					try {
						if (isUpdateRecord && (nsCreationMsg == null || nsCreationMsg == '')) {
							var hasAddressBook = false;
							var addressBookObj = {};
							for (var parentProp in mainObj) {
								var parentProp = parentProp
								var parentProp1 = ''
								if (parentProp == 'items') {
									parentProp1 = mainObj[parentProp]
								}
								if (parentProp != 'items') {
									//var parentProp2=nsOrderRecord.getFieldValue(parentProp)
									if ((parentProp != null && parentProp != '')) {
										if (parentProp != 'otherrelationships' && parentProp != 'id') nsOrderRecord.setFieldValue(parentProp, mainObj[parentProp])
									}
								} else {
									var isArray = true;
									if (parentProp1 instanceof Array) {
										isArray = true
									} else {
										isArray = false
									}
									if (isArray) {
										var parentPropItems = mainObj[parentProp]
										nlapiLogExecution('debug', 'parentPropItemsmain:', parentPropItems.length);

										for (var i = 0; i < parentPropItems.length; i++) {
											//if(isNewRecord)

											/// v1.1
											//var isNewLine = false;

											var hasRevenueElementLink = 'F';
											if (i + 1 <= nsOrderCounts) {
												hasRevenueElementLink = nsOrderRecord.getLineItemValue('item', 'attachedtorevenueelement', i + 1)
												if (hasRevenueElementLink != 'T') hasRevenueElementLink = 'F';
												nsOrderRecord.selectLineItem('item', i + 1)
												//nsOrderRecord.selectNewLineItem('item')
												nlapiLogExecution('debug', 'parentPropItems:', 'test');
											} else {
												nsOrderRecord.selectNewLineItem('item')
												//nsOrderRecord.selectLineItem('item',i+1)
												//isNewLine = true;
											}
											var parentPropItemsProps = parentPropItems[i]
											for (var parentPropItem in parentPropItemsProps) {
												nlapiLogExecution('debug', 'parentPropItemstest ' + parentPropItem, parentPropItemsProps[parentPropItem]);
												var parent458785 = parentPropItemsProps[parentPropItem]
                                                ///  v1.1
												//if (parentPropItem != 'billingschedule') {
                                                if (parentPropItem != 'billingschedule') {
													if (hasRevenueElementLink == 'F') {
														nsOrderRecord.setCurrentLineItemValue('item', parentPropItem, parentPropItemsProps[parentPropItem]);
													} else {
														if (parentPropItem != 'item' && parentPropItem != 'custcolappf_so_line_startdate') nsOrderRecord.setCurrentLineItemValue('item', parentPropItem, parentPropItemsProps[parentPropItem])
													}
												}
												if (parentPropItem == 'billingschedule') nsOrderRecord.setCurrentLineItemText('item', parentPropItem, parentPropItemsProps[parentPropItem])
											}
											nsOrderRecord.commitLineItem('item')
										}
									}
								}
							}
							nsOrderRecordID = nlapiSubmitRecord(nsOrderRecord, true, true);
						} else {
							if (nsCreationMsg == null || nsCreationMsg == '') {
								nsCreationMsg = 'Last Update Date from JSON (' + msdate + ') is earlier than the Last Update Date found in Netsuite(' + nsdate + ').'
								scriptStatus = 'WARNING'
							}
						}
					} catch (e1) {
						scriptStatus = 'FAILED'
						if (e1 instanceof nlobjError) nsCreationMsg = e1.getDetails();
						else nsCreationMsg = e1.toString();
						nlapiLogExecution('DEBUG', 'FAILED', nsCreationMsg);
					}
					if (nsOrderRecordID != null) {
						var isInActiveRecord = false;
						if (mainObj.hasOwnProperty('isinactive')) {
							if (mainObj['isinactive'] == 'T') isInActiveRecord = true
						}
						if (!isInActiveRecord) nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS, CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsOrderRecordID, 'SUCCESS']);
					} else {
						nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus + ":" + nsCreationMsg]);
					}
					if (nsOrderRecordID != null && nsOrderRecordID != '') {
						idForResponse = nsOrderRecordID;
						scriptStatus = 'SUCCESS'
						// integrationResponseObj.internalId=recordId
						if (responseData.getCode() == '200' || responseData.getCode() == '201') nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
						else nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
					}
				}
			}
			if (scriptStatus != null && scriptStatus != '' && messagesFound == true) {
				if (pareConnex == null || pareConnex == '') pareConnex = ''
				integrationResponseObj.EntityId = pareConnex
				if (idForResponse == null || idForResponse == '') idForResponse = ''
				integrationResponseObj.NetSuiteId = idForResponse
				if (Status1 != null && Status1 != '') integrationResponseObj.IntegrationResponseStatus = Status1
				else integrationResponseObj.IntegrationResponseStatus = scriptStatus
				if (nsCreationMsg == null || nsCreationMsg == '') nsCreationMsg = ''
				integrationResponseObj.IntegrationResponseMessage = nsCreationMsg
				nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_RESP], [JSON.stringify(integrationResponseObj)]);
				var url = URL_BASE + QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE + '/messages';
				var body = JSON.stringify(integrationResponseObj);
				var HEADERS = {
					"Authorization": signatures
				};
				//HEADERS.scriptStatus=scriptStatus
				if (CorrelationId == null || CorrelationId == '') CorrelationId = ''
				HEADERS['NServiceBus.CorrelationId'] = CorrelationId
				HEADERS['NServiceBus.EnclosedMessageTypes'] = NS_CLIENT
				var responseData = nlapiRequestURL(url, body, HEADERS, null, 'POST');
				nlapiLogExecution('debug', 'responseData:', responseData);
			}
			if (context.getRemainingUsage() <= 1000) {
				nlapiScheduleScript(SPARAM_CONNEX_CLIENT, null)
				break;
			}
		}
	}
}