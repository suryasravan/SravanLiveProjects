/*
*Script Name: Appf-Sync SO & POs UE
*Script Type: UE Script
*Description: This script syncs the SO and its linked POs for POs count <= 30
*Company 	: Appficiency Inc.

*/

var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var FLD_SYNC_SO_PO_TRIGGER = 'custbody_appf_ssync_so_po_trigger';


var TOTAL_FORMS = 6;
var SCRIPT_SCHEDULE = 'customscript_appf_sync_so_po_sc';
var SPARAM_SO_ID = 'custscript_appf_so_id';
var FLD_SYNC_SO_PO_STATUS = 'custbody_sync_sopo_status';
var FLD_SYNC_SO_PO_ERROR = 'custbody_sync_so_po_error';
var STATUS_SYNC_SO_PO = { 'IN_PROGRESS': 1, 'SYNC_SUCCESS': 2, 'SYNC_FAILED': 3 };

var SCRIPT_SYNC_PT_PTA_GENERIC_SL = 'customscript_appf_generic_sl_1';
var DEPLOY_SYNC_PT_PTA_GENERIC_SL = 'customdeploy_appf_generic_sl_1';

//added by shravan kumar 14-03-2023
var CUST_FLD_PROCESS_COMPLETED = 'custbody_appf_close_process_completed';

function syncsopobefload ( type, form, request ) {
	if ( type == 'create' || type == 'copy' ) {
		nlapiSetFieldValue( FLD_SYNC_SO_PO_STATUS, '' );
		nlapiSetFieldValue( FLD_SYNC_SO_PO_ERROR, '' );
	}
}


function syncSOPOAfterSubmit ( type ) {
	var recordId = nlapiGetRecordId();
	if ( type != 'delete' && recordId != 734437 ) {

		var context = nlapiGetContext();


		var salesOrderRec = nlapiLoadRecord( 'salesorder', recordId );
		var syncStatus = salesOrderRec.getFieldValue( FLD_SYNC_SO_PO_STATUS );
		var syncSOPOTrigger = salesOrderRec.getFieldValue( FLD_SYNC_SO_PO_TRIGGER );
		var triggerScript = true;
		if ( syncSOPOTrigger == 'T' && context.getExecutionContext() == 'scheduled' ) {
			triggerScript = false;

		}
		if ( triggerScript ) {
			if ( syncStatus != STATUS_SYNC_SO_PO.IN_PROGRESS ) {
				var recForm = salesOrderRec.getFieldValue( 'customform' );
				var count = salesOrderRec.getLineItemCount( 'item' );
				var posObj = {};
				var totalPOs = 0;
				for ( var i = 1; i <= count; i++ ) {

					var createdPO = salesOrderRec.getLineItemValue( 'item', 'createdpo', i );
					if ( createdPO != null && createdPO != '' ) {
						if ( !posObj.hasOwnProperty( createdPO ) ) {
							totalPOs++;
							posObj[ createdPO ] = {};
							posObj[ createdPO ].vendor = salesOrderRec.getLineItemValue( 'item', FLD_COL_VENDOR_NAME, i );
							posObj[ createdPO ].solineids = [];
							posObj[ createdPO ].solineids.push( salesOrderRec.getLineItemValue( 'item', FLD_COL_SO_LINE_ID, i ) );

						}
						else {
							posObj[ createdPO ].solineids.push( salesOrderRec.getLineItemValue( 'item', FLD_COL_SO_LINE_ID, i ) );
						}
					}

				}
				nlapiLogExecution( 'DEBUG', 'posObj', JSON.stringify( posObj ) );



				var paramFields = '';
				for ( var i = 1; i <= TOTAL_FORMS; i++ ) {
					var paramForm = context.getSetting( 'SCRIPT', 'custscript_appf_form_' + i + '_id' );
					if ( paramForm == recForm ) {
						paramFields = context.getSetting( 'SCRIPT', 'custscript_appf_form_' + i + '_fields' );
					}
				}
				if ( paramFields != '' ) {
					if ( totalPOs <= 30 ) {

						var errMsg = '';
						var poArr = [];
						for ( var po in posObj ) {
							poArr.push( po );
							var soLineVend = posObj[ po ].vendor;
							try {

								var poRec = nlapiLoadRecord( 'purchaseorder', po );
								var poVendor = poRec.getFieldValue( 'entity' );

								var process = poRec.getFieldValue( CUST_FLD_PROCESS_COMPLETED );
								nlapiLogExecution( 'DEBUG', 'process', process );
								//added by shravan kumar 14-03-2023
								if ( process != 'T' ) {
									if ( poVendor != soLineVend )
										poRec.setFieldValue( 'entity', soLineVend );
									var soLines = posObj[ po ].solineids;
									if ( soLines != null && soLines != '' ) {
										for ( var l = 0; l < soLines.length; l++ ) {
											if ( paramFields != null && paramFields != '' ) {
												var fields = [];

												fields = fields.concat( paramFields.split( ',' ) );

												var lineNumber = poRec.findLineItemValue( 'item', FLD_COL_SO_LINE_ID, soLines[ l ] );
												var solinenumber = salesOrderRec.findLineItemValue( 'item', FLD_COL_SO_LINE_ID, soLines[ l ] );
												if ( lineNumber > 0 ) {

													for ( var f = 0; f < fields.length; f++ ) {
														var fldValue = salesOrderRec.getLineItemValue( 'item', fields[ f ], solinenumber );
														poRec.setLineItemValue( 'item', fields[ f ], lineNumber, fldValue );
													}

													//var jobSoLine = salesOrderRec.getLineItemValue('item', 'job', solinenumber);
													//poRec.setLineItemValue('item', 'customer', lineNumber, jobSoLine);

													//added by shravan kumar 14-03-2023
													var qtySoLine = salesOrderRec.getLineItemValue( 'item', 'quantity', solinenumber );
													poRec.setLineItemValue( 'item', 'custcol_appf_po_current_client_gross', lineNumber, qtySoLine );
													//added by shravan kumar 14-03-2023
													var vednorAllocSoLine = salesOrderRec.getLineItemValue( 'item', 'custcol_appf_vendor_allocation_amount', solinenumber );
													poRec.setLineItemValue( 'item', 'quantity', lineNumber, vednorAllocSoLine );


												}
											}
										}
									}
									nlapiSubmitRecord( poRec, true, true );
								}
							} catch ( e ) {

								if ( e instanceof nlobjError ) {
									nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
									errMsg += 'Sync with PO Internal ID: ' + po + ' failed. Reason: ' + e.getDetails() + '\n';
								}
								else {
									nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
									errMsg += 'Sync with PO Internal ID: ' + po + ' failed. Reason: ' + e.toString() + '\n';
								}

							}
							//nlapiLogExecution('DEBUG', 'poRecSubmitted', poRecSubmitted);
						}

						var slURL = nlapiResolveURL( 'SUITELET', SCRIPT_SYNC_PT_PTA_GENERIC_SL, DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external' );
						slURL += '&genetricrecid=' + poArr + '&genetricrectype=purchaseorder&isbackend=T';
						nlapiLogExecution( 'debug', 'slURL', slURL )
						try {
							nlapiRequestURL( slURL );
						} catch ( e ) {
							try {
								nlapiRequestURL( slURL );
							} catch ( ex ) {
								try {
									nlapiRequestURL( slURL );
								}
								catch ( ep ) {
									nlapiLogExecution( 'debug', 'error triggering Generic SL', ep );

								}
							}
						}
						if ( errMsg != '' ) {
							salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_STATUS, STATUS_SYNC_SO_PO.SYNC_FAILED );
							salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_ERROR, errMsg );
						}
						else {
							salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_STATUS, STATUS_SYNC_SO_PO.SYNC_SUCCESS );
							salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_ERROR, '' );
						}


					}
					else {
						salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_STATUS, STATUS_SYNC_SO_PO.IN_PROGRESS );

						var params = {};
						params[ SPARAM_SO_ID ] = recordId;
						//nlapiScheduleScript(SCRIPT_SCHEDULE, null, params);
					}
					nlapiSubmitRecord( salesOrderRec, true, true );
				}
			}

		}
		else {

			salesOrderRec.setFieldValue( FLD_SYNC_SO_PO_TRIGGER, 'F' );
			nlapiSubmitRecord( salesOrderRec, true, true );

		}
	}
}