/*Script Name: Appf-Client Credit Creation SL
 *Script Type: Suitelet
 *Description: This script will display the Client Credit Creation form with filters and results as invoice lines and creates a appf - Client Credit Creation Log Record with invoices selected
 *Company 	 : Appficiency.
 */
var SL_TITLE = 'Client Credit Suitelet';
var SL_FLD_CONSOLIDATED_INVOICE = 'custpage_consolidated_invoice';
var SL_FLD_MEDIA_SEGMENT = 'custpage_media_type';
var SL_FLD_PROJECT = 'custpage_project';
var SL_FLD_DATE_FROM = 'custpage_date_from';
var SL_FLD_DATE_TO = 'custpage_date_to';
var SL_FLD_IO = 'custpage_io';
var SL_FLD_VENDOR = 'custpage_vendor';
var SL_FLD_CURRENCY = 'custpage_currency';

var SL_FLD_MEDIA_SUPPLIER = 'custpage_media_supplier';
var SL_FLD_PARENT_CLIENT = 'custpage_parent_client';
var SL_FLD_CLIENT = 'custpage_client';
var SL_FLD_SUBSIDIARY = 'custpage_subsidiary';
var SL_SUBLIST = 'custpage_custom_line';
var SL_COL_UPDATE = 'custpage_update';
var SL_COL_INTERNAL_ID = 'custpage_internal_id';
var SL_FLD_TOTAL_CREDITS = 'custpage_total_credits';
var SL_FLD_TOTAL_CREDIT_MEMOS = 'custpage_total_credit_memos';
var SL_COL_CREDIT_AMOUNT = 'custpage_credit_amount';

var CUSTOM_RECORD_MEDIA_SUPPLIER = 'customrecord_appf_media_supplier';
var CUSTOM_RECORD_CONSOLIDATED_INVOICE = 'customrecord_nsts_ci_consolidate_invoice';
var BTN_APPLY_FILTER = 'custpage_apply_button';
var BTN_MARK_ALL = 'custpage_mark_All';
var BTN_UNMARK_ALL = 'custpage_unmark_All';
var SPARAM_CLIENT_CREDIT_SS = 'custscript_appf_client_credit_ss';
var SPARAM_CLIENT_CREDIT_FOLDER_ID = 'custscript_appf_client_credit_creatn_fld';

var FLD_SO_LINE_ID = 'custcol_appf_line_id';
var FLD_PROJECT = 'custrecord_appf_pwp_project';
var FLD_CLIENT = 'custrecord_appf_pwp_client_link';
var FLD_COL_MEDIA_SUPPLIER = 'custcol_appf_publisher';
var FLD_COL_VENDOR = 'custcol_appf_po_vendor_name';
var FLD_COL_PWP_CUSTOM_RECORD = 'custcol_appf_pwp_custom_record';
var CLIENT_SCRIPT = 'customscript_appf_client_credit_cl';

//added by shravan kumar 08-06-2023
var FLD_INV_MEDIA_SEGMENT = 'line.cseg_appf_media_seg';
var FLD_COL_INV_CI_RECORD = 'custcol_appf_ci_record';
var FLD_COL_IO = 'custcol_appf_ionum';
var FLD_COL_VB_MEDIA_SUPPLIER = 'custcol_appf_publisher';
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var FLD_COL_INV_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_COL_SO_SERVICE_DATE = 'custcol_appf_print_servicedate';

var CUS_REC_CREDIT_CREATION_LOG = 'customrecord_appf_cust_crd_log';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_cst_crd_status';
var VALUE_STATUS_IN_PROGRESS = '2';
var FLD_CREATED_BY = 'custrecord_appf_cst_crd_created_by';
var FLD_DATA_FILE = 'custrecord_appf_cst_crd_data_file';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_cst_crd_tl_pro';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_cst_crd_client';
var FLD_CURRENCY = 'custrecord_appf_cst_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_cst_crd_link';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_cst_crd_invoice_link';

var SCRIPT_SL_CLIENT_CREDIT_SUITELET = 'customscript_appf_client_credit';
var DEPLOY_SL_CLIENT_CREDIT_SUITELET = 'customdeploy_appf_client_credit';

var SCRIPT_UPDATE_INVOICES_CREDIT_CREATION_SC = 'customscript_appf_update_inv_cc_sc';
var SPARAM_CREDIT_CREATION_LOG_ID_1 = 'custscript_appf_credit_creation_log_id_1';
var SAPARM_SELECTED_LINES_FILE_ID = 'custscript_appf_selected_inv_folder_id';

function clientCreditSL ( request, response ) {

	var context = nlapiGetContext();
	var ssID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_CREDIT_SS );
	var folderID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_CREDIT_FOLDER_ID );
	nlapiLogExecution( 'debug', 'folderID', folderID );
	if ( ssID != null && ssID != '' ) {
		var loadSS = nlapiLoadSearch( null, ssID );
		var filts = loadSS.getFilters();
		var columns = loadSS.getColumns();
		var ssType = loadSS.getSearchType();
		if ( request.getMethod() == 'GET' ) {

			try {
				var applyfilter = false;
				if ( request.getParameter( 'applyFils' ) == 'T' )
					applyfilter = true;
				var consolidateInv = request.getParameter( 'consolidateInv' );
				var mediaType = request.getParameter( 'media' );
				var project = request.getParameter( 'proj' );
				var dateFrom = request.getParameter( 'dtFrom' );
				var dateTo = request.getParameter( 'dtTo' );
				var io = request.getParameter( 'io' );
				var vendor = request.getParameter( 'vendor' );
				var mediasupp = request.getParameter( 'mediasupp' );
				var parentClient = request.getParameter( 'pclient' );
				var client = request.getParameter( 'client' );
				var subsidiary = request.getParameter( 'subs' );
				var currency = request.getParameter( 'currency' );

				var form = nlapiCreateForm( SL_TITLE );
				form.setScript( CLIENT_SCRIPT );

				var parentClientFld = form.addField( SL_FLD_PARENT_CLIENT, 'select', 'Parent Client', 'customer' );
				//parentClientFld.setMandatory(true);
				if ( parentClient != null && parentClient != '' )
					parentClientFld.setDefaultValue( parentClient );
				var clientValues = [];
				if ( client != null && client != '' ) {
					var clients = client.split( '|' );
					clientValues = clientValues.concat( clients );
				}
				var clientFld = form.addField( SL_FLD_CLIENT, 'multiselect', 'Client' );
				//clientFld.setMandatory(true);
				if ( parentClient != null && parentClient != '' && clientValues.length > 0 ) {
					var clientSearchResults = nlapiSearchRecord( 'customer', null, [ new nlobjSearchFilter( 'parent', null, 'anyof', parentClient ), new nlobjSearchFilter( 'isinactive', null, 'is', 'F' ) ], [ new nlobjSearchColumn( 'entityid' ), new nlobjSearchColumn( 'companyname' ) ] );
					if ( clientSearchResults != null && clientSearchResults != '' ) {
						for ( var x = 0; x < clientSearchResults.length; x++ ) {
							var result = clientSearchResults[ x ];
							var selected = false;
							if ( clientValues.indexOf( result.getId() ) != -1 )
								selected = true;
							clientFld.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
						}
					}
				}
				if ( parentClient != null && parentClient != '' && clientValues.length == 0 ) {
					var clientSearchResults = nlapiSearchRecord( 'customer', null, [ new nlobjSearchFilter( 'parent', null, 'anyof', parentClient ), new nlobjSearchFilter( 'isinactive', null, 'is', 'F' ) ], [ new nlobjSearchColumn( 'entityid' ), new nlobjSearchColumn( 'companyname' ) ] );
					if ( clientSearchResults != null && clientSearchResults != '' ) {
						for ( var x = 0; x < clientSearchResults.length; x++ ) {
							var result = clientSearchResults[ x ];
							var selected = true;
							//if(clientValues.indexOf(result.getId()) != -1)
							//selected = true;
							clientFld.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
						}
					}
				}

				/*var consolidatedInvFld = form.addField(SL_FLD_CONSOLIDATED_INVOICE, 'select', 'Consolidated Invoice #',CUSTOM_RECORD_CONSOLIDATED_INVOICE);
				 if(consolidateInv != null && consolidateInv != '')
					 consolidatedInvFld.setDefaultValue(consolidateInv);*/

				var mediaTypeFld = form.addField( SL_FLD_MEDIA_SEGMENT, 'select', 'Media Segment', 'customrecord_cseg_appf_media_seg' );
				if ( mediaType != null && mediaType != '' )
					mediaTypeFld.setDefaultValue( mediaType );

				var projectFld = form.addField( SL_FLD_PROJECT, 'select', 'Project', 'job' );
				if ( project != null && project != '' )
					projectFld.setDefaultValue( project );

				var dateFldFrom = form.addField( SL_FLD_DATE_FROM, 'date', 'Date (From)' );
				if ( dateFrom != null && dateFrom != '' )
					dateFldFrom.setDefaultValue( dateFrom );
				var dateFldTo = form.addField( SL_FLD_DATE_TO, 'date', 'Date (To)' );
				if ( dateTo != null && dateTo != '' )
					dateFldTo.setDefaultValue( dateTo );

				var ioFld = form.addField( SL_FLD_IO, 'text', 'IO #' );
				if ( io != null && io != '' )
					ioFld.setDefaultValue( io );

				/*var vendorFld = form.addField(SL_FLD_VENDOR, 'select', 'Vendor','vendor');
				if(vendor != null && vendor != '')
					vendorFld.setDefaultValue(vendor);
			     
				var mediaSuppFld = form.addField(SL_FLD_MEDIA_SUPPLIER, 'select','Media Supplier',CUSTOM_RECORD_MEDIA_SUPPLIER);
				if(mediasupp != null && mediasupp != '')
					mediaSuppFld.setDefaultValue(mediasupp);*/

				var subsidiaryFld = form.addField( SL_FLD_SUBSIDIARY, 'select', 'Subsidiary', 'subsidiary' );
				//subsidiaryFld.setDisplayType('disabled');
				if ( subsidiary != null && subsidiary != '' )
					subsidiaryFld.setDefaultValue( subsidiary );
				var currencyFld = form.addField( SL_FLD_CURRENCY, 'select', 'Currency', 'currency' );
				currencyFld.setDisplayType( 'hidden' );
				if ( currency != null && currency != '' )
					currencyFld.setDefaultValue( currency );
				var totalCredits = form.addField( SL_FLD_TOTAL_CREDITS, 'currency', 'Total Credits' ).setDisplayType( 'disabled' );

				var totalCredMemos = form.addField( SL_FLD_TOTAL_CREDIT_MEMOS, 'integer', 'Total Credit Memos' ).setDisplayType( 'disabled' );


				if ( applyfilter == true ) {
					var filters = [];
					//if(consolidateInv != null && consolidateInv != '')
					//filters.push(new nlobjSearchFilter(FLD_COL_INV_CI_RECORD, null, 'anyof',consolidateInv));


					if ( project != null && project != '' )
						filters.push( new nlobjSearchFilter( 'internalid', 'job', 'anyof', project ) );
					if ( dateFrom != null && dateFrom != '' && dateTo != null && dateTo != '' )
						filters.push( new nlobjSearchFilter( FLD_COL_SO_SERVICE_DATE, null, 'within', dateFrom, dateTo ) );
					if ( dateFrom != null && dateFrom != '' && ( dateTo == null || dateTo != '' ) )
						filters.push( new nlobjSearchFilter( FLD_COL_SO_SERVICE_DATE, null, 'onorafter', dateFrom ) );
					if ( ( dateFrom == null || dateFrom == '' ) && dateTo != null && dateTo != '' )
						filters.push( new nlobjSearchFilter( FLD_COL_SO_SERVICE_DATE, null, 'onorbefore', dateTo ) );
					if ( io != null && io != '' )
						filters.push( new nlobjSearchFilter( FLD_COL_IO, null, 'is', io ) );
					if ( vendor != null && vendor != '' )
						filters.push( new nlobjSearchFilter( FLD_COL_VENDOR_NAME, null, 'anyof', vendor ) );

					//if(mediasupp != null && mediasupp != '')
					//filters.push(new nlobjSearchFilter(FLD_COL_VB_MEDIA_SUPPLIER, null, 'anyof',mediasupp));

					//if(parentClient != null && parentClient != '')
					//filters.push(new nlobjSearchFilter('entity', null, 'anyof',parentClient));
					nlapiLogExecution( 'DEBUG', 'CLIENT VALUES', clientValues );
					if ( clientValues != null && clientValues != '' && clientValues.length > 0 )
						filters.push( new nlobjSearchFilter( 'entity', null, 'anyof', clientValues ) );

					if ( subsidiary != null && subsidiary != '' )
						filters.push( new nlobjSearchFilter( 'subsidiary', null, 'anyof', subsidiary ) );


					var suiteletSublist = form.addSubList( SL_SUBLIST, 'list', 'Sales Orders' );
					suiteletSublist.addButton( BTN_MARK_ALL, 'Mark All', 'markAll();' );
					suiteletSublist.addButton( BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();' );
					suiteletSublist.addField( SL_COL_UPDATE, 'checkbox', 'Select' ).setDisplayType( 'entry' );
					suiteletSublist.addField( SL_COL_INTERNAL_ID, 'text', 'Internal ID' ).setDisplayType( 'normal' );


					var colArr = [];
					var colIndex = 1;
					var scriptfieldcounter = 1;
					for ( var i = 0; i < columns.length; i++ ) {
						var colObj = columns[ i ];
						var colName = colObj.getName();
						var colLabel = colObj.getLabel();

						if ( colArr.indexOf( colName ) == -1 ) {
							colArr.push( colName );
						}
						else {
							colName = colName + colIndex;
							colIndex++;
						}
						if ( colLabel.toUpperCase() == 'CLIENT CREDIT AMOUNT' ) {
							suiteletSublist.addField( SL_COL_CREDIT_AMOUNT, 'text', colLabel );
						}
						else {
							if ( colLabel != 'Script Use DNR' ) {
								suiteletSublist.addField( 'custpage_' + colName, 'text', colLabel );
							}
							else {
								var scriptField = suiteletSublist.addField( 'custpage_scriptfield' + scriptfieldcounter, 'text', colLabel );
								scriptField.setDisplayType( 'hidden' );
								scriptfieldcounter++;
							}

						}


					}

					nlapiLogExecution( 'debug', 'mediaType', mediaType );
					var mediaType_Fils = [];
					if ( mediaType != null && mediaType != '' )
						mediaType_Fils.push( new nlobjSearchFilter( FLD_INV_MEDIA_SEGMENT, null, 'anyof', mediaType ) );

					filts = filts.concat( mediaType_Fils )

					//var resultFilters = filters.concat( filts );
					filts = filts.concat( filters )

					var searchResults = getAllSearchResults( ssType, filts, columns );
					nlapiLogExecution( 'debug', 'searchResults', searchResults );
					if ( searchResults != null && searchResults != '' ) {
						for ( var s = 0; s < searchResults.length; s++ ) {

							var searchresult = searchResults[ s ];
							var internalid = searchresult.getId();
							var colArr = [];
							var colIndex = 1;
							var scriptfieldcounter = 1;
							for ( var c = 0; c < columns.length; c++ ) {
								var colObj = columns[ c ];
								var columnName = colObj.getName();
								var colLabel = colObj.getLabel();
								var ssResultValue = searchresult.getValue( colObj );
								if ( colObj.getType() == 'select' ) {
									ssResultValue = searchresult.getText( colObj );
								}
								if ( colArr.indexOf( columnName ) == -1 ) {
									colArr.push( columnName );
								}
								else {
									columnName = columnName + colIndex;
									colIndex++;
								}
								suiteletSublist.setLineItemValue( SL_COL_INTERNAL_ID, s + 1, internalid );
								if ( columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid' ) {
									var url = nlapiResolveURL( 'RECORD', 'salesorder', internalid );
									var redirect = '<a href=' + url + ' target="_blank">' + ssResultValue + '</a>';
									ssResultValue = redirect;
								}
								if ( colLabel.toUpperCase() == 'CLIENT CREDIT AMOUNT' ) {
									suiteletSublist.setLineItemValue( SL_COL_CREDIT_AMOUNT, s + 1, ssResultValue );
								}
								else {
									if ( colLabel != 'Script Use DNR' ) {
										suiteletSublist.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );
									}
									else {
										suiteletSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounter, s + 1, ssResultValue );
										scriptfieldcounter++;
									}

								}
							}
						}
					}
				}


				form.addButton( BTN_APPLY_FILTER, 'Apply Filters', 'applyFilter()' );
				form.addSubmitButton( 'Submit' );
				response.writePage( form );
			} catch ( e ) {
				if ( e instanceof nlobjError )
					nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
				else
					nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
			}


		}

		else {
			var vendor = request.getParameter( SL_FLD_VENDOR );
			var count = request.getLineItemCount( SL_SUBLIST );
			var totalCreditSelected = 0;
			var csvData = '';
			var currency = request.getParameter( SL_FLD_CURRENCY );
			var clients = request.getParameterValues( SL_FLD_CLIENT );
			var internalIdsArr = [];
			var arrayIDResult = [];
			var selectedInvoices = {};

			try {
				if ( columns != null && columns != '' ) {
					csvData += 'Internal ID,';
					for ( var c = 0; c < columns.length; c++ ) {
						var colObj = columns[ c ];
						var columnLabel = colObj.getLabel();
						csvData += columnLabel;
						csvData = csvData + ',';
					}

					csvData = csvData.slice( 0, -1 ) + '\n';

					for ( var i = 1; i <= count; i++ ) {
						var checkBox = request.getLineItemValue( SL_SUBLIST, SL_COL_UPDATE, i );

						if ( checkBox == 'T' ) {
							var internalID = request.getLineItemValue( SL_SUBLIST, SL_COL_INTERNAL_ID, i );
							internalIdsArr.push( internalID );
							if ( !selectedInvoices.hasOwnProperty( internalID ) ) {
								selectedInvoices[ internalID ] = [];
							}
							csvData += internalID + ',';
							totalCreditSelected++;
							var scriptfieldcounter = 1;
							for ( var c = 0; c < columns.length; c++ ) {
								var colObj = columns[ c ];
								var columnName = colObj.getName();
								var colLabel = colObj.getLabel();
								var colValue = request.getLineItemValue( SL_SUBLIST, 'custpage_' + columnName, i );
								if ( colValue != null && colValue != '' )
									colValue = colValue.replace( /,/g, ';' );
								if ( colLabel.toUpperCase() == 'CLIENT CREDIT AMOUNT' ) {
									colValue = request.getLineItemValue( SL_SUBLIST, SL_COL_CREDIT_AMOUNT, i );
								}
								if ( colLabel == 'Script Use DNR' ) {
									colValue = request.getLineItemValue( SL_SUBLIST, 'custpage_scriptfield' + scriptfieldcounter, i );
									scriptfieldcounter++;
								}
								if ( columnName == FLD_SO_LINE_ID ) {
									selectedInvoices[ internalID ].push( colValue );
								}
								csvData += colValue + ',';
							}
							csvData = csvData.slice( 0, -1 ) + '\n';
						}
					}

				}
				internalIdsArr = removeDuplicates( internalIdsArr );

				//nlapiLogExecution('debug','csvData',csvData);


				var timeStamp = new Date().getTime();
				var csvFile = nlapiCreateFile( 'SelectedLines_' + timeStamp + '.csv', 'CSV', csvData );
				csvFile.setFolder( folderID );
				var fileID = nlapiSubmitFile( csvFile );

				var createdBy = nlapiGetUser();
				//nlapiLogExecution('debug','createdBy',createdBy);
				// nlapiLogExecution('debug','csvData',csvData);
				// nlapiLogExecution('debug','totalCreditSelected',totalCreditSelected);

				var creditCreationLogRec = nlapiCreateRecord( CUS_REC_CREDIT_CREATION_LOG );
				//var creditCreationLogRec = nlapiLoadRecord(CUS_REC_CREDIT_CREATION_LOG, '1');
				creditCreationLogRec.setFieldValue( FLD_CREDIT_CREATION_STATUS, VALUE_STATUS_IN_PROGRESS );
				if ( createdBy != null && createdBy != '' )
					creditCreationLogRec.setFieldValue( FLD_CREATED_BY, createdBy );

				if ( totalCreditSelected != null && totalCreditSelected != '' )
					creditCreationLogRec.setFieldValue( FLD_TOT_CREDITS_TO_PROCESS, totalCreditSelected );

				if ( fileID != null && fileID != '' )
					creditCreationLogRec.setFieldValue( FLD_DATA_FILE, fileID );

				/* if(vendor != null && vendor != '')
					 creditCreationLogRec.setFieldValue(FLD_CLIENT_OR_VENDOR,vendor);*/
				if ( currency != null && currency != '' )
					creditCreationLogRec.setFieldValue( FLD_CURRENCY, currency );
				if ( internalIdsArr != null && internalIdsArr != '' )
					creditCreationLogRec.setFieldValues( FLD_INV_VEND_BILL_LINK, internalIdsArr );
				if ( clients != null && clients != '' ) {
					creditCreationLogRec.setFieldValues( FLD_CLIENT_OR_VENDOR, clients );
				}
				var custRecID = nlapiSubmitRecord( creditCreationLogRec, true, true );

				var invoicesData = '';
				for ( var invId in selectedInvoices ) {
					invoicesData += invId + '::';
					var invLineIds = selectedInvoices[ invId ];
					for ( var l = 0; l < invLineIds.length; l++ ) {
						invoicesData += invLineIds[ l ] + '|';
					}
					invoicesData = invoicesData + '\n';
				}
				//invoicesData = invoicesData.slice(0, -2);
				var invoicesDataFile = nlapiCreateFile( 'SelectedInvoicesData_' + new Date().getTime() + '.txt', 'PLAINTEXT', invoicesData );
				invoicesDataFile.setFolder( folderID );
				var invoicesDataFileID = nlapiSubmitFile( invoicesDataFile );
				nlapiLogExecution( 'debug', 'invoicesDataFileID', invoicesDataFileID );
				if ( custRecID != null && custRecID != '' ) {
					var params = {};
					params[ SPARAM_CREDIT_CREATION_LOG_ID_1 ] = custRecID;
					params[ SAPARM_SELECTED_LINES_FILE_ID ] = invoicesDataFileID;
					nlapiScheduleScript( SCRIPT_UPDATE_INVOICES_CREDIT_CREATION_SC, null, params );
					response.sendRedirect( 'RECORD', CUS_REC_CREDIT_CREATION_LOG, custRecID );

				}

			} catch ( e ) {
				if ( e instanceof nlobjError )
					nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
				else
					nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
			}
		}
	}

}
function getCurrencyID ( name ) {
	var col = new Array();
	col[ 0 ] = new nlobjSearchColumn( 'name' );
	col[ 1 ] = new nlobjSearchColumn( 'internalId' );
	var discrepancyList = {};
	var results = nlapiSearchRecord( 'currency', null, null, col );
	for ( var i = 0; results != null && i < results.length; i++ ) {
		var res = results[ i ];
		var listValue = res.getValue( 'name' );
		var listID = res.getValue( 'internalId' );
		discrepancyList[ listValue ] = listID;
	}
	return discrepancyList[ name ];
}
function removeDuplicates ( num ) {
	var x,
		len = num.length,
		out = [],
		obj = {};

	for ( x = 0; x < len; x++ ) {
		obj[ num[ x ] ] = 0;
	}
	for ( x in obj ) {
		out.push( x );
	}
	return out;
}

//function calling
//var searchres_morethan1000 = getAllSearchResults(record_type, filters, columns);
//function definations
function getAllSearchResults ( record_type, filters, columns ) {
	var search = nlapiCreateSearch( record_type, filters, columns );
	search.setIsPublic( true );

	var searchRan = search.runSearch()
		, bolStop = false
		, intMaxReg = 1000
		, intMinReg = 0
		, result = [];

	while ( !bolStop && nlapiGetContext().getRemainingUsage() > 10 ) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults( intMinReg, intMaxReg );

		result = searchUnion( result, extras );
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if ( extras.length < 1000 ) {
			bolStop = true;
		}
	}

	return result;
}

function searchUnion ( target, array ) {
	return target.concat( array ); // TODO: use _.union
}