/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
 define(['N/record', 'N/search', 'N/runtime'],

  function(record, search, runtime) {
     
    var PARAM_SSID = 'custscript_vendorcreditapplication_ss';
  
   /**
       * Evaluate id value is null
       * @param stValue
       */
      function isEmpty(stValue) {
          return (
            stValue === '' ||
              stValue === '[]' ||
              stValue === 'undefined' ||
              stValue == null ||
              stValue == undefined ||
             (stValue.constructor === Array && stValue.length == 0) ||
             (stValue.constructor === Object &&
             (function(v) {
                 for (var k in v) return false;
                     return true;
              })(stValue))
          );
      }
    
    function searchRecords(searchID)
    {
      if(searchID != null){
        var searchObj = search.load({
          id: searchID
        });
        var resultSet = searchObj.run();
        var results = [];
        var start = 0;
        var end = 1000;
        do{
          var result = resultSet.getRange(start,end);
          results = results.concat(result);
          start += 1000;
          end += 1000;
          
        }while(result.length == 1000);
        
        return results;
      }
      return null;
      
    }
  
  
      /**
       * Marks the beginning of the Map/Reduce process and generates input data.
       *
       * @typedef {Object} ObjectRef
       * @property {number} id - Internal ID of the record instance
       * @property {string} type - Record type id
       *
       * @return {Array|Object|Search|RecordRef} inputSummary
       * @since 2015.1
       */
      function getInputData() {
          var searchId = runtime.getCurrentScript().getParameter({name: PARAM_SSID});
          log.debug("Search ID", searchId);
          if(searchId){
            return search.load({
              id: searchId
            });
          }
      }
  
      /**
       * Executes when the map entry point is triggered and applies to each key/value pair.
       *
       * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
       * @since 2015.1
       */
      function map(context) {
        try{
          var key = context.key;
          var value = JSON.parse(context.value).values;
          log.debug("VALUES", context);
          log.debug("VALUES", value);
          var VENDORBILL = value.custrecord_appf_pwp_vb_link;
          var VENDORCREDIT = value.custrecord_appf_pwp_vendor_credit;

          if(VENDORBILL.length > 1 || VENDORCREDIT.length > 1){
            log.debug("MAP", "Skipping processing of this line " + key +". Vendor Credit or Vendor Bill is more than one.");
          }
          else{
            VENDORBILL = VENDORBILL.value;
            VENDORCREDIT = VENDORCREDIT.value;

            log.debug("VENDOR BILL", VENDORBILL);
            log.debug("VENDOR CREDIT", VENDORCREDIT);
            
            var VENDORCREDITAMOUNT = parseFloat(value.custrecord_appf_pwp_ven_credit_amt);
            log.debug("VENDOR CREDIT AMT", VENDORCREDITAMOUNT);
            context.write({
              key: key,
              value: {
                vendorbill: VENDORBILL,
                vendorcredit: VENDORCREDIT,
                vendorcreditamt: VENDORCREDITAMOUNT
              }
            })
            //Send to Reduce for Processing:
          }
        }
        catch(e){
          log.error("ERROR IN MAP", e.message);
        }
      }


  
      /**
       * Executes when the reduce entry point is triggered and applies to each group.
       *
       * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
       * @since 2015.1
       */
      function reduce(context) {
        try{
          var PWP_ID = context.key;
          var value = JSON.parse(context.values[0]);
  
          var VENDORBILL_ID = value.vendorbill;
          var VENDORCREDIT_ID = value.vendorcredit;
          var VENDORCREDITAMT = value.vendorcreditamt;
          //Transform Vendor Bill to Vendor Credit:
          var VENDORCREDIT_OBJ = record.load({
            type: record.Type.VENDOR_CREDIT,
            id: VENDORCREDIT_ID
          });
  
          var APPLY_COUNT = VENDORCREDIT_OBJ.getLineCount({sublistId: 'apply'});
          for(var i = 0; i < APPLY_COUNT; i++){
            var LineInternalId = VENDORCREDIT_OBJ.getSublistValue({
              sublistId: 'apply',
              line: i,
              fieldId: 'internalid'
            });
  
            if(LineInternalId == VENDORBILL_ID){
                VENDORCREDIT_OBJ.setSublistValue({
                  sublistId: 'apply',
                  fieldId: 'apply',
                  value: true,
                  line: i
                });
  
                VENDORCREDIT_OBJ.setSublistValue({
                  sublistId: 'apply',
                  fieldId: 'amount',
                  line: i,
                  value: parseFloat(VENDORCREDITAMT)
                });
                
                break;
            }
          }
  
          var vendorCreditId = VENDORCREDIT_OBJ.save();
          log.debug("Vendor Credit Saved", vendorCreditId);
  
          var paidAmount = getPaidAmount(vendorCreditId, VENDORBILL_ID);
  
          log.debug("Paid Amount", paidAmount);
  
          var VENDORBILL_OBJ = record.load({
            type: record.Type.VENDOR_BILL,
            id: VENDORBILL_ID
          });
  
          VENDORBILL_OBJ.setSublistValue({
            sublistId: 'item',
            fieldId: 'custcol_appf_pwp_bill_line_amt_paid',
            line: 0,
            value: parseFloat(paidAmount)
          });
  
          var vendorBillId = VENDORBILL_OBJ.save();
          log.debug("Vendor Bill Id Saved", vendorBillId);
        }
        catch(e){
          log.error("ERROR IN REDUCE",  e.message);
        }
       
      }
  

      function getPaidAmount(vendorCreditId, vendorBillId){
        var vendorcreditSearchObj = search.create({
          type: "vendorcredit",
          filters:
          [
             ["type","anyof","VendCred"], 
             "AND", 
             ["internalid", "anyof", vendorCreditId],
             "AND",
             ["appliedtotransaction","anyof",vendorBillId], 
             "AND", 
             ["mainline","is","T"]
          ],
          columns:
          [
             "tranid",
             "paidamount"
          ]
       });
       
       var paidAmount = 0;
       vendorcreditSearchObj.run().each(function(result){
          paidAmount = result.getValue({name: "paidamount"});
          log.debug("paidAmount", paidAmount);
          return false;
       });

       return paidAmount;
      }
  
      /**
       * Executes when the summarize entry point is triggered and applies to the result set.
       *
       * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
       * @since 2015.1
       */
      
  
       function summarize(summary) {
              var inputSummary = summary.inputSummary;
              if (inputSummary.error) {
                  log.error("Input Errors", inputSummary.error);
              }
              var reduceSummary = summary.reduceSummary;
              handleErrorInStage("Reduce", reduceSummary);
          }
      
      function handleErrorInStage(stage, summary) {
              summary.errors.iterator().each(function (key, value) {
                  var msg = 'Failure to process key: ' + key + '. Error was: ' + JSON.parse(value).message + '\n';
                  log.error(stage + " Errors", msg);
                  return true;
              });
          }
      return {
          getInputData: getInputData,
          map: map,
          reduce: reduce,
          summarize: summarize
      };
      
  });
  