/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Generates custom PDF layout depending on PDF template assigned to CI NRECORD.
 * 
 * Author: marlon
 * Date: Dec 10, 2020
 */

define(
    [
        'N/http',
        'N/log',
        'N/record',
        'N/runtime',
        'N/search',
        'N/ui/serverWidget',
        'N/url',
        'N/file',
        'N/format',
        'N/redirect',
        'N/task'
        
    ],
    
    function (
        NHTTP,
        NLOG,
        NRECORD,
        NRUNTIME,
        NSEARCH,
        NUI,
        NURL,
        NFILE,
        NFORMAT,
        NREDIRECT,
        NTASK
    ) {
        
        var FLD_SL_CLIENT = 'custpage_client';
        var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
        var FLD_SL_PROJECT = 'custpage_project';
        var FLD_SL_SERVICE_DATE_FROM = 'custpage_service_date_from';
        var FLD_SL_SERVICE_DATE_TO = 'custpage_service_date_to';
        var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
        var FLD_SL_START_DATE_FROM = 'custpage_start_date_from';
        var FLD_SL_END_DATE_TO= 'custpage_end_date_to';
        var FLD_SL_END_DATE_FROM= 'custpage_end_date_from';
        var FLD_SL_IO_NUM = 'custpage_io_num';
        var FLD_SL_IN_NUM = 'custpage_inv_num';
        var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
        var SL_FLD_CURRENCY='custpage_currency';
        var FLD_SL_POP_RECEIVED = 'custpage_pop_received';
        var FLD_SL_TOTAL_AMOUNT = 'custpage_total_amount';
        var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
        // 1.1 new Filters
        var FLD_SL_BILL_MONTH = 'custpage_bill_month';
        var FLD_SL_PLACEMENT_NUM = 'custpage_placement_num';
        var FLD_SL_STRATA_ESTIMATE_NUM = 'custpage_strata_est_num';
        var FLD_SL_URL = 'custpage_sl_url';

        var FLD_PWP_PROJECT = 'custrecord_appf_pwp_project';
        var FLD_COL_SO_PWP_CUSTOM_RECORD = 'custcol_appf_pwp_custom_record';
        var FLD_COL_SO_MEDIA_SEGMENT = 'line.cseg_appf_media_seg';
        var FLD_COL_SO_IO_NUM = 'custcol_appf_ionum';
        // 1.1 new Filters' column
        var FLD_COL_SO_BILLMONTH = 'custcol_appf_bill_month';
        var FLD_COL_SO_PLACEMENTNUM = 'custcol_appf_dig_placementnum';
        var FLD_COL_SO_STRATAESTIMATENUM = 'custcol_appf_strata_estimatenum';

        var FLD_COL_SO_POP_RECEIVED = 'custcol_appf_pop_received';
        var FLD_CONTRACT_IN_SOS='custbody_appf_client_contract'

        var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
        var CUSTOM_RECORD_CLIENTS = 'customrecord_appf_client_contract';

        var SCRIPT_MARK_SO_LINES_BILLING_VALIDATIONS = 'customscript_appf_mark_so_lines_bill_cl';
        var SPARAM_MARK_SO_LINES_FOR_BILLING_SS = 'custscript_appf_ready_for_processing_ss2';
        var SPARAM_MARK_SO_BILLING_FOLDER = 'custscript_appf_mark_so_lines_bill_fl2';

        var SL_SUBLIST = 'custpage_sl_sublist';
        var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
        var FLD_COL_SL_INTERNAL_ID = 'custpage_so_internal_id';
        var FLD_CONTRACT_IN = 'custrecord_appf_contract_invoice_day';
        var BTN_MARK_ALL = 'custpage_btn_mark_all';
        var BTN_UNMARK_ALL = 'custpage_btn_unmark_all';
        var BTN_APPLY_FILTER = 'custpage_apply_filters';

        var SCRIPT_MARK_LINES_BILLING_SC = 'customscript_appf_mark_so_lines_bill_sc';
        // var SPARAM_CSV_FILE_ID = 'custscript_appf_so_lines_billing_file_id';
        var SPARAM_CSV_FILE_ID = 'custscript_appf_so_lines_billing_file_2';

        var FLD_GROUP_PRIMARY_INFORMATION='custpage_primary_information';
        var FLD_GROUP_FILTER='custpage_filters';
        var FLD_GROUP_SUMMARY='custpage_summary';

        var SCRIPT_MARKSO_MR = 'customscript_appf_mark_so_lines_bill_mr';
        // var DEPLOY_CI_MR = 'customdeploy_appf_create_client_ci_mr_v2';
        var SCRIPT_MARK_LINES_BILLING_CL = 'SuiteScripts/Appf - Mark SO Lines for Billing V2/Appf-Mark SO Lines for Billing Validations_2_0.js';

        var CUSTOM_RECORD_RFI_EXECUTION_LOG = 'customrecord_appf_rfi_log';
        var FLD_RFI_TOTAL_LINES_TO_PROCESS = 'custrecord_appf_rfi_log_totlines';
        var FLD_RFI_CSV_FILE = 'custrecord_appf_rfi_log_csvfile';
        var FLD_RFI_STATUS = 'custrecord_appf_rfi_log_status';
        var FLD_RFI_SUBMITTED_LINE_IDS = 'custrecord_appf_rfi_log_ids';
        var FLD_RFI_CREATED_BY = 'custrecord_appf_rfi_log_createdby';
        var SPARAM_RFI_LOG_ID = 'custscript_appf_rfi_log_id';
        
        var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';
        var SEARCH_RFI_LOGS_IN_PROGRESS = 'customsearch_appf_rfi_logs_inprog';
        
        function buildFormGroupPrimaryInfo(form, parms) {
            var LOG_TITLE = 'buildFormGroupPrimaryInfo';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var fld;
            
            // Field Group
            form.addFieldGroup({ id: FLD_GROUP_PRIMARY_INFORMATION, label: 'Primary Information' });
            
            fld = form.addField({
                id: FLD_SL_CLIENT,
                type: NUI.FieldType.SELECT,
                label: 'Client',
                source: 'customer',
                container: FLD_GROUP_PRIMARY_INFORMATION
            });
            fld.defaultValue = parms.client;
            
            fld = form.addField({
                id: FLD_SL_SUBSIDIARY,
                type: NUI.FieldType.SELECT,
                label: 'Subsidiary',
                source: 'subsidiary',
                container: FLD_GROUP_PRIMARY_INFORMATION
            });
            fld.defaultValue = parms.subsidiaryVal;
            fld.updateDisplayType({ displayType: (parms.client ? NUI.FieldDisplayType.DISABLED : NUI.FieldDisplayType.NORMAL) });
            
            fld = form.addField({
                id: SL_FLD_CURRENCY,
                type: NUI.FieldType.SELECT,
                label: 'Currency',
                source: 'currency',
                container: FLD_GROUP_PRIMARY_INFORMATION
            });
            fld.updateDisplayType({ displayType: NUI.FieldDisplayType.DISABLED });
            fld.defaultValue = parms.currency;
            fld.updateBreakType({ breakType: NUI.FieldBreakType.STARTCOL });
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        function buildFormGroupFilters(form, parms) {
            var LOG_TITLE = 'buildFormGroupFilters';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var fld, val;
            
            // Contract Details (Group By)
            form.addFieldGroup({ id: FLD_GROUP_FILTER, label: 'Filters' });
            
            form.addField({
                id: FLD_SL_MEDIA_SEGMENT,
                type: NUI.FieldType.MULTISELECT,
                label: 'Media Segment',
                source: CUSTOM_RECORD_MEDIA_SEGMENT,
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.mediaSegment;
            
            form.addField({
                id: FLD_SL_PROJECT,
                type: NUI.FieldType.SELECT,
                label: 'Project',
                source: 'job',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.proj;
            
            form.addField({
                id: FLD_SL_SERVICE_DATE_FROM,
                type: NUI.FieldType.DATE,
                label: 'Date Created (From)',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.serviceDateFrom;
            
            form.addField({
                id: FLD_SL_SERVICE_DATE_TO,
                type: NUI.FieldType.DATE,
                label: 'Date Created (To)',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.serviceDateTo;
            
            form.addField({
                id: FLD_SL_START_DATE_FROM,
                type: NUI.FieldType.DATE,
                label: 'Start Date From',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.startDateFrom;
            
            form.addField({
                id: FLD_SL_START_DATE_TO,
                type: NUI.FieldType.DATE,
                label: 'Start Date To',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.startDateTo;
            
            form.addField({
                id: FLD_SL_END_DATE_FROM,
                type: NUI.FieldType.DATE,
                label: 'End Date From',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.endDateFrom;
            
            form.addField({
                id: FLD_SL_END_DATE_TO,
                type: NUI.FieldType.DATE,
                label: 'End Date To',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.endDateTo;
            
            form.addField({
                id: FLD_SL_IO_NUM,
                type: NUI.FieldType.TEXT,
                label: 'IO # / BS #',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.ioNum;
            
            fld = form.addField({
                id: FLD_SL_IN_NUM,
                type: NUI.FieldType.SELECT,
                label: 'Invoice Cycle Day of the Month',
                container: FLD_GROUP_FILTER
            });
            fld.addSelectOption({ text: '', value: '' });
            val = parms.invNum;
            for (var n=1; n<28; n++) {
                fld.addSelectOption({ text: n, value: n, isSelected: (n == parms.invNum) });
            }
            
            fld = form.addField({
                id: FLD_SL_POP_RECEIVED,
                type: NUI.FieldType.SELECT,
                label: 'Pop Received',
                container: FLD_GROUP_FILTER
            });
            fld.addSelectOption({ text: '', value: '', isSelected: (parms.popReceived == null || parms.popReceived == '') });
            fld.addSelectOption({ text: 'Yes', value: 'T', isSelected: (parms.popReceived == 'T') });
            fld.addSelectOption({ text: 'No', value: 'F', isSelected: (parms.popReceived == 'F') });
            
            form.addField({
                id: FLD_SL_BILL_MONTH,
                type: NUI.FieldType.MULTISELECT,
                label: 'Bill Month',
                source: NRECORD.Type.BILLING_SCHEDULE,
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.billMonth;
            
            form.addField({
                id: FLD_SL_PLACEMENT_NUM,
                type: NUI.FieldType.TEXT,
                label: 'Placement #',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.placementNum;
            
            form.addField({
                id: FLD_SL_STRATA_ESTIMATE_NUM,
                type: NUI.FieldType.TEXT,
                label: 'Strata Estimate #',
                container: FLD_GROUP_FILTER
            }).defaultValue = parms.strataEstNum;
            
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
        }
        
        function buildFormGroupSummary(form, parms) {
            var LOG_TITLE = 'buildFormGroupSummary';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var fld;
            
            // Summary Details
            form.addFieldGroup({ id: FLD_GROUP_SUMMARY, label: 'Summary' });
            
            fld = form.addField({
                id: FLD_SL_TOTAL_AMOUNT,
                type: NUI.FieldType.CURRENCY,
                label: 'Total Amount',
                container: FLD_GROUP_SUMMARY
            });
            fld.updateDisplayType({ displayType: NUI.FieldDisplayType.DISABLED });
            
            form.addField({
                id: FLD_SL_TOTAL_LINES,
                type: NUI.FieldType.INTEGER,
                label: 'Total Lines',
                container: FLD_GROUP_SUMMARY
            }).updateDisplayType({ displayType: NUI.FieldDisplayType.DISABLED });
            
            var script = NRUNTIME.getCurrentScript();
            fld = form.addField({
                id: FLD_SL_URL,
                type: NUI.FieldType.TEXT,
                label: 'Suitelet URL',
                container: FLD_GROUP_SUMMARY
            });
            fld.defaultValue = NURL.resolveScript({
                scriptId: script.id,
                deploymentId: script.deploymentId
            });
            fld.updateDisplayType({ displayType: NUI.FieldDisplayType.HIDDEN });
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        function buildFormFields(form, parms) {
            var LOG_TITLE = 'buildFormFields';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            buildFormGroupPrimaryInfo(form, parms);
            buildFormGroupFilters(form, parms);
            buildFormGroupSummary(form, parms);
            
            //sublist  11/28/2020
            buildFormSublist(form, parms);
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        function buildSearchFilters(parms) {
            var LOG_TITLE = 'buildSearchFilters';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var filters = [];
            var flt;
            
            NLOG.debug({ title: LOG_TITLE, details: 'client = '+ parms.client });
            if (parms.client) {
                flt = NSEARCH.createFilter({
                        name: 'entity',
                        operator: NSEARCH.Operator.ANYOF,
                        values: parms.client
                    });
                NLOG.debug({ title: LOG_TITLE + ' client', details: JSON.stringify(flt) });
                filters.push(flt);
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'mediaSegment = '+ parms.mediaSegment });
            if (parms.mediaSegment) {
                
                flt = NSEARCH.createFilter({
                        name: FLD_COL_SO_MEDIA_SEGMENT,
                        operator: NSEARCH.Operator.ANYOF,
                        values: parms.mediaSegment.split(',')
                    });
                NLOG.debug({ title: LOG_TITLE + ' mediaSegment', details: JSON.stringify(flt) });
                filters.push(flt);
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'proj = '+ parms.proj });
            if (parms.proj) {
                filters.push(
                    NSEARCH.createFilter({
                        name: FLD_PWP_PROJECT,
                        join: FLD_COL_SO_PWP_CUSTOM_RECORD,
                        operator: NSEARCH.Operator.ANYOF,
                        values: parms.proj
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'serviceDateFrom = '+ parms.serviceDateFrom + ', serviceDateTo = ' + parms.serviceDateTo });
            if (parms.serviceDateFrom && parms.serviceDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'trandate',
                        operator: NSEARCH.Operator.WITHIN,
                        values: [ parms.serviceDateFrom, parms.serviceDateTo ]
                    })
                );
            }
            else if (parms.serviceDateFrom && !parms.serviceDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'trandate',
                        operator: NSEARCH.Operator.ONORAFTER,
                        values: parms.serviceDateFrom
                    })
                );
            }
            else if (!parms.serviceDateFrom && parms.serviceDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'trandate',
                        operator: NSEARCH.Operator.ONORBEFORE,
                        values: parms.serviceDateTo
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'startDateFrom = '+ parms.startDateFrom + ', startDateTo = ' + parms.startDateTo });
            if (parms.startDateFrom && parms.startDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcolappf_so_line_startdate',
                        operator: NSEARCH.Operator.WITHIN,
                        values: [ parms.startDateFrom, parms.startDateTo ]
                    })
                );
            }
            else if (parms.startDateFrom && !parms.startDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcolappf_so_line_startdate',
                        operator: NSEARCH.Operator.ONORAFTER,
                        values: parms.startDateFrom
                    })
                );
            }
            else if (!parms.startDateFrom && parms.startDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcolappf_so_line_startdate',
                        operator: NSEARCH.Operator.ONORBEFORE,
                        values: parms.startDateTo
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'endDateFrom = '+ parms.endDateFrom + ', endDateTo = ' + parms.endDateTo });
            if (parms.endDateFrom && parms.endDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcol_appf_so_line_enddate',
                        operator: NSEARCH.Operator.WITHIN,
                        values: [ parms.endDateFrom, parms.endDateTo ]
                    })
                );
            }
            else if (parms.endDateFrom && !parms.endDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcol_appf_so_line_enddate',
                        operator: NSEARCH.Operator.ONORAFTER,
                        values: parms.endDateFrom
                    })
                );
            }
            else if (!parms.endDateFrom && parms.endDateTo) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'custcol_appf_so_line_enddate',
                        operator: NSEARCH.Operator.ONORBEFORE,
                        values: parms.endDateTo
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'ioNum = '+ parms.ioNum });
            if (parms.ioNum) {
                var ioNums = parms.ioNum.split(',');

                var ioFormula = 'CASE ';
                for (var i = 0; i < ioNums.length; i++) {
                    ioFormula += "WHEN {" + FLD_COL_SO_IO_NUM + "} = '" + ioNums[i] + "' THEN 1 ";
                }
                ioFormula += 'ELSE 0 END';

                NLOG.debug('ioFormula', ioFormula);

                filters.push(NSEARCH.createFilter({
                    name: 'formulanumeric',
                    operator: NSEARCH.Operator.EQUALTO,
                    values: 1,
                    formula: ioFormula
                }));
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'invNum = '+ parms.invNum });
            if (parms.invNum) {
                filters.push(
                    NSEARCH.createFilter({
                        name: FLD_CONTRACT_IN,
                        join: FLD_CONTRACT_IN_SOS,
                        operator: NSEARCH.Operator.EQUALTO,
                        values: parms.invNum
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'subsidiaryVal = '+ parms.subsidiaryVal });
            if (parms.subsidiaryVal) {
                filters.push(
                    NSEARCH.createFilter({
                        name: 'subsidiary',
                        operator: NSEARCH.Operator.ANYOF,
                        values: parms.subsidiaryVal
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'popReceived = '+ parms.popReceived });
            if (parms.popReceived != '' && parms.popReceived != null) {
                filters.push(
                    NSEARCH.createFilter({
                        name: FLD_COL_SO_POP_RECEIVED,
                        operator: NSEARCH.Operator.IS,
                        values: parms.popReceived
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'billMonth = '+ parms.billMonth });
            if (parms.billMonth) {
                NLOG.debug('billMonth', parms.billMonth);
                filters.push(
                    NSEARCH.createFilter({
                        name: 'billingschedule',
                        operator: NSEARCH.Operator.ANYOF,
                        values: parms.billMonth.split(',')
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'placementNum = '+ parms.placementNum });
            if (parms.placementNum) {
                filters.push(
                    NSEARCH.createFilter({
                        name: FLD_COL_SO_PLACEMENTNUM,
                        operator: NSEARCH.Operator.IS,
                        values: parms.placementNum.trim()
                    })
                );
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'strataEstNum = '+ parms.strataEstNum });
            if (parms.strataEstNum) {
                var strataEstNums = parms.strataEstNum.split(',');

                var strataFormula = 'CASE ';
                for (var i = 0; i < strataEstNums.length; i++) {
                    strataFormula += "WHEN {" + FLD_COL_SO_STRATAESTIMATENUM + "} = '" + strataEstNums[i] + "' THEN 1 ";
                }
                strataFormula += 'ELSE 0 END';

                NLOG.debug('strataFormula', strataFormula);

                filters.push(NSEARCH.createFilter({
                    name: 'formulanumeric',
                    operator: NSEARCH.Operator.EQUALTO,
                    values: 1,
                    formula: strataFormula
                }));

                /* filters.push(
                    NSEARCH.createFilter({
                        name: FLD_COL_SO_STRATAESTIMATENUM,
                        operator: NSEARCH.Operator.IS,
                        values: parms.strataEstNum.trim()
                    })
                ); */
            }

            if (parms.ioNum) {
                var ioNums = parms.ioNum.split(',');

                var ioFormula = 'CASE ';
                for (var i = 0; i < ioNums.length; i++) {
                    ioFormula += "WHEN {" + FLD_COL_SO_IO_NUM + "} = '" + ioNums[i] + "' THEN 1 ";
                }
                ioFormula += 'ELSE 0 END';

                NLOG.debug('ioFormula', ioFormula);

                filters.push(NSEARCH.createFilter({
                    name: 'formulanumeric',
                    operator: NSEARCH.Operator.EQUALTO,
                    values: 1,
                    formula: ioFormula
                }));
            }
            
            NLOG.debug({ title: LOG_TITLE + ' filters', details: JSON.stringify(filters) });
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
            return filters;
        }
        
        function buildFormSublist(form, parms){
        	var LOG_TITLE = 'buildFormSublist';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
    		var script = NRUNTIME.getCurrentScript();
            var fld;
        	
            var ssID = script.getParameter({ name: SPARAM_MARK_SO_LINES_FOR_BILLING_SS });
            var folderID = script.getParameter({ name: SPARAM_MARK_SO_BILLING_FOLDER });
            var loadSS = NSEARCH.load({ id: ssID });
            var srchFilters = loadSS.filters;
            var srchColumns = loadSS.columns;
            var srchType = loadSS.searchType;
        	
            NLOG.debug({ title: LOG_TITLE, details: 'applyfilters = ' + parms.applyfilters });
            if (parms.applyfilters == 'T' || parms.applyfilters == 'true') {
                var sublist = form.addSublist({
                    id: SL_SUBLIST,
                    type: NUI.SublistType.LIST,
                    label: 'Sales Orders'
                });
                
                sublist.addButton({
                    id : BTN_MARK_ALL,
                    label : 'Mark All',
                    functionName: 'markAll();'
                });
                sublist.addButton({
                    id : BTN_UNMARK_ALL,
                    label : 'Unmark All',
                    functionName: 'unmarkAll();'
                });
                
                fld = sublist.addField({
                    id: FLD_COL_SL_SELECT,
                    type: NUI.FieldType.CHECKBOX,
                    label: 'Select'
                });
                fld.updateDisplayType({ displayType: NUI.FieldDisplayType.ENTRY });
                fld.defaultValue = 'T';
                
                var filters = buildSearchFilters(parms).concat(srchFilters);
                NLOG.debug({ title: LOG_TITLE, details: JSON.stringify(parms) });
                NLOG.debug({ title: LOG_TITLE + ' filters', details: JSON.stringify(filters) });
                
                var columns = [];
                var colIndex = 1;
                var counter = 1;
                
                for (var c = 0; c < srchColumns.length; c++) {
                    var col = srchColumns[c];
                    
                    var colName = col.name;
                    colName = colName.replace('.', '_');
                    colName = colName.toLowerCase();
                    var colObj = {
                        name: col.name
                    }
                    
                    if (col.join) {
                        colObj.join = col.join;
                    }
                    var colLabel = col.label;
                    colObj.label = colLabel;
                    
                    if (columns.indexOf(colName) >= 0) {
                        colName = colName + (colIndex++);
                        colObj.name = colName;
                    }
                    columns.push(NSEARCH.createColumn(colObj));
                    
                    var fldName = '';
                    if (colLabel != 'Script Use DNR') {
                        fldName = 'custpage_' + colName;
                        sublist.addField({
                            id: fldName,
                            type: NUI.FieldType.TEXT,
                            label: colLabel
                        });
                    }
                    else {
                        fldName = 'custpage_scriptfield' + (counter++);
                        fld = sublist.addField({
                            id: fldName,
                            type: NUI.FieldType.TEXT,
                            label: colLabel
                        });
                        fld.updateDisplayType({ displayType: NUI.FieldDisplayType.HIDDEN });
                    }
                }
                
                var srchResults = getAllSearchResults('transaction', filters, srchColumns);
                var pendingLines = getAllPendingLines();
                var nRow = 0;
                if (srchResults != null && srchResults != '') {
                    var totalAmt = 0;
                    for (var i = 0, n = srchResults.length; i<n; i++) {
                        var res = srchResults[i];
                        var resId = res.id;
                        var colIndex = 1;
                        var colArr = [];
                        counter = 1;
                        
                        var lineID = res.getValue({name: FLD_COL_SO_LINE_ID});
                        log.debug('createClientCISuitelet', 'lineID = ' + lineID);
                        if (pendingLines.indexOf(lineID) >= 0) {
                            log.debug('lineID = ' + lineID, 'Skipping line...');
                            continue;
                        }
                        
                        for (var j = 0, l = srchColumns.length; j < l; j++) {
                            var cObj = srchColumns[j];
                            colName = cObj.name.replace('.', '_');
                            colName = colName.toLowerCase();
                            
                            colLabel = cObj.label;
                            
                            var resValue = res.getText(cObj);
                            if (resValue == null) {
                                resValue = res.getValue(cObj);
                            }
                            
                            if (colArr.indexOf(colName) < 0) {
                                colArr.push(colName);
                            }
                            else {
                                colName = colName + (colIndex++);
                                colArr.push(colName);
                            }
                            
                            if (colName == 'tranid') {
                                var url = NURL.resolveRecord({
                                    recordType: 'salesorder',
                                    recordId: res.id
                                });
                                resValue = '<a href=' + url + ' target="_blank">' + resValue + '</a>';
                            }
                            
                            var fldName = '';
                            if (colLabel != 'Script Use DNR') {
                                fldName = 'custpage_' + colName;
                                sublist.setSublistValue({
                                    id: fldName,
                                    line: nRow,
                                    value: (resValue == true ? 'Yes' : (resValue == false ? 'No' : resValue))
                                });
                            }
                            else {
                                fldName = 'custpage_scriptfield' + (counter++);
                                sublist.setSublistValue({
                                    id: fldName,
                                    line: nRow,
                                    value: (resValue == true ? 'Yes' : (resValue == false ? 'No' : resValue))
                                });
                                if (counter == 4) {
                                    totalAmt += Number(resValue);
                                }
                            }
                        }
                        
                        nRow++;
                    }
                    
                    var fld = form.getField({
                        id: FLD_SL_TOTAL_AMOUNT
                    });
                    fld.defaultValue = (Math.round(totalAmt * 100) / 100).toFixed(2);
                    
                    fld = form.getField({
                        id: FLD_SL_TOTAL_LINES
                    });
                    fld.defaultValue = srchResults.length;
                }
        	}
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        function getAllSearchResults(record_type, filters, columns) {
            var LOG_TITLE = 'fn:getAllSearchResults';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            NLOG.debug({ title: LOG_TITLE + ' record_type', details: record_type });
            NLOG.debug({ title: LOG_TITLE + ' filters', details: JSON.stringify(filters) });
            NLOG.debug({ title: LOG_TITLE + ' columns', details: JSON.stringify(columns) });
            
            var search = NSEARCH.create({ type: record_type, filters: filters, columns: columns });
            var searchRan, bolStop = false, intMaxReg = 1000, intMinReg = 0, result = [];
            
            searchRan = search.run();
            while (!bolStop && NRUNTIME.getCurrentScript().getRemainingUsage() > 100) {
                NLOG.debug({ title: LOG_TITLE, details: 'intMinReg = ' + intMinReg + ', intMaxReg = ' + intMaxReg });
                var extras = searchRan.getRange({ start: intMinReg, end: intMaxReg });
                result = searchUnion(result, extras);
                intMinReg = intMaxReg;
                intMaxReg += 1000;
                // If the execution reach the the last result set stop the execution
                if (extras.length < 1000) {
                    bolStop = true;
                }
            }
            
            NLOG.debug({ title: LOG_TITLE, details: 'Retrieved result count = ' + result.length });
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
            return result;
        }
        
        function getAllPendingLines() {
            var LOG_TITLE = 'fn:getAllPendingLines';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var srch = NSEARCH.load({ id: SEARCH_RFI_LOGS_IN_PROGRESS });
            // var srchFilters = srch.filters;
            // var srchColumns = srch.columns;
            // var srchType = srch.searchType;
            var results = getAllSearchResults(srch.searchType, srch.filters, srch.columns);
            var lineIDs = [];
            for (var i = 0, n = results.length; i < n; i++) {
                var ids = results[i].getValue({ name: 'custrecord_appf_rfi_log_ids' });
                lineIDs = lineIDs.concat(ids.split(','));
            }
            NLOG.debug({ title: LOG_TITLE + ' lineIDs', details: JSON.stringify(lineIDs) });
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
            return lineIDs;
        }
        
        function searchUnion(target, array) {
            return target.concat(array);
        }

        function onRequest(params) {
            var LOG_TITLE = 'onRequest';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var script = NRUNTIME.getCurrentScript();
            var ssID = script.getParameter({ name: SPARAM_MARK_SO_LINES_FOR_BILLING_SS });
            var folderID = script.getParameter({ name: SPARAM_MARK_SO_BILLING_FOLDER });
            
            var ssObj = NSEARCH.load({ id: ssID });
            var srchFilters = ssObj.filters;
            var srchColumns = ssObj.columns;
            var srchType = ssObj.searchType;
            
            var request = params.request;
            if (request.method == NHTTP.Method.GET) {
                try {
                    var form = NUI.createForm({ title: 'Mark SO Lines for Billing' });
                    form.clientScriptModulePath = SCRIPT_MARK_LINES_BILLING_CL;
                    form.addButton({
                        id: BTN_APPLY_FILTER,
                        label: 'Apply Filters',
                        functionName: 'applyFilters();'
                    });
                    form.addSubmitButton({ label: 'Submit' });
                    
                    buildFormFields(form, request.parameters);
                    params.response.writePage(form);
                }
                catch (e) {
                    NLOG.error({
                        title: LOG_TITLE,
                        details: JSON.stringify(e)
                    });
                }
            }
            else {
                try {
                    var count = request.getLineCount({ group: SL_SUBLIST });//FLD_SL_TOTAL_LINES;
                    NLOG.debug({ title: LOG_TITLE, details: 'count = ' + count });
                    var aOrderLines = [];
                    if(count > 0 && srchColumns != null && srchColumns != '') {
                        var csvData = '';
                        var labelctr = 1;
                        
                        for(var cl=0; cl<srchColumns.length; cl++) {
                            var colObj = srchColumns[cl];
                            var colLabel = colObj.label;
                            
                            if (colLabel == 'Script Use DNR') {
                                colLabel += ' ' + (labelctr++);
                                csvData += colLabel+',';
                            }
                        }
                        
                        csvData = csvData.slice(0, -1)+'\n';
                        for (var c = 0; c < count; c++) {
                            if(request.getSublistValue({
                                group: SL_SUBLIST,
                                name: FLD_COL_SL_SELECT,
                                line: c
                            }) == 'T') {
                                var scriptfieldcounter = 1;
                                var nScriptDNR = 0;
                                
                                for (var cl = 0; cl < srchColumns.length; cl++) {
                                    var colObj = srchColumns[cl];
                                    var colLabel = colObj.label;
                                    var colName = colObj.name.replace('.', '_');
                                    
                                    var colValue = request.getSublistValue({
                                        group: SL_SUBLIST,
                                        name: 'custpage_' + colName,
                                        line: c
                                    });
                                    
                                    if (colLabel == 'Script Use DNR') {
                                    	 
                                        colValue = request.getSublistValue({
                                            group: SL_SUBLIST,
                                            name: 'custpage_scriptfield' + (scriptfieldcounter++),
                                            line: c
                                        });
                                        csvData += colValue+',';
                                        
                                        if(nScriptDNR == 1){
                                        	aOrderLines.push(colValue);
                                        }
                                        
                                        nScriptDNR++;
                                    }
                                }
                                
                                csvData = csvData.slice(0, -1)+'\n';
                            }
                        }
                        
                        var timestamp = new Date().getTime();
                        var csvFile = NFILE.create({
                            name: 'SelectedSOData_' + timestamp + '.csv',
                            fileType: NFILE.Type.CSV,
                            contents: csvData,
                            folder: folderID,
                            isOnline: true
                        });
                        
                        var csvFileID = csvFile.save();
                        
                        var currentUser = NRUNTIME.getCurrentUser();
                        currentUser = currentUser.id;
                        
        	    		var rfiExecLogRec = NRECORD.create({type: CUSTOM_RECORD_RFI_EXECUTION_LOG,isDynamic : true});
        	    		rfiExecLogRec.setValue({fieldId: FLD_RFI_CSV_FILE,value: csvFileID });
        	    		rfiExecLogRec.setValue({fieldId: FLD_RFI_CREATED_BY,value: currentUser });

        	    		rfiExecLogRec.setValue({fieldId: FLD_RFI_STATUS,value: '1' });
        	    		rfiExecLogRec.setValue({fieldId: FLD_RFI_TOTAL_LINES_TO_PROCESS,value: aOrderLines.length });
        	    		rfiExecLogRec.setValue({fieldId: FLD_RFI_SUBMITTED_LINE_IDS,value: aOrderLines.join(',') });
    					var newRFIExecLogRec = rfiExecLogRec.save({
    					    enableSourcing: true,
    					    ignoreMandatoryFields: true
    					});
                        log.debug('newRFIExecLogRec', newRFIExecLogRec);
                        
                        if (newRFIExecLogRec != null && newRFIExecLogRec != '') {

                            var params = {};
                            params[SPARAM_RFI_LOG_ID] = newRFIExecLogRec;
                            
                            var scriptTask = NTASK.create({ taskType: NTASK.TaskType.MAP_REDUCE });
                            scriptTask.scriptId = SCRIPT_MARKSO_MR;
                            scriptTask.params = params;
                            
                            var scriptTaskId = scriptTask.submit();
                            
                            NREDIRECT.toRecord({
                                type: CUSTOM_RECORD_RFI_EXECUTION_LOG,
                                id: newRFIExecLogRec
                            });
                        }
                    }
                }
                catch (e) {
                	NLOG.debug({ title: 'Error', details: JSON.stringify(e) });
                } 
            }
        }

        return {
            onRequest: onRequest
        }
    }
);