/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Marks Sales Orders for Billing.
 *
 * Author: Marlon
 * Date: Dec 12, 2020
 */

define(
    [
        'N/file',
        'N/log',
        'N/record',
        'N/runtime'
    ],

    function(
        FILE,
        LOG,
        RECORD,
        RUNTIME
    ) {

        /* function searchMoreRecords(recordType, searchID, filters, columns) {
            if(searchID != null) {
                var searchObj = SEARCH.load({
                    id: searchID
                });
            }
            else{
                var searchObj = SEARCH.create({
                    id: searchID,
                    type: recordType,
                    filters: filters,
                    columns: columns
                });
            }

            var resultSet = searchObj.run();
            var results = [];
            var start = 0;
            var end = 1000;
            
            do {
                var result = resultSet.getRange(start,end);
                results = results.concat(result);
                start += 1000;
                end += 1000;
            } while(result.length == 1000);

            return results;
        } */

        /**
         * Marks the beginning of the Map/Reduce process and generates input data.
         *
         * @typedef {Object} ObjectRef
         * @property {number} id - Internal ID of the record instance
         * @property {string} type - Record type id
         *
         * @return {Array|Object|Search|RecordRef} inputSummary
         * @since 2015.1
         */
        function getInputData() {
            var LOG_TITLE = 'getInputData';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var SPARAM_CSV_FILE_ID = 'custscript_appf_so_lines_billing_file_2';
            var SPARAM_RFI_LOG_ID = 'custscript_appf_rfi_log_id';
            var CUSTOM_RECORD_RFI_EXECUTION_LOG = 'customrecord_appf_rfi_log';
            var FLD_RFI_TOTAL_LINES_TO_PROCESS = 'custrecord_appf_rfi_log_totlines';
            var FLD_RFI_CSV_FILE = 'custrecord_appf_rfi_log_csvfile';
            var FLD_RFI_STATUS = 'custrecord_appf_rfi_log_status';
            var FLD_RFI_SUBMITTED_LINE_IDS = 'custrecord_appf_rfi_log_ids';
            var FLD_RFI_CREATED_BY = 'custrecord_appf_rfi_log_createdby';
            var script = RUNTIME.getCurrentScript();
            //var csvFileId = script.getParameter({ name: SPARAM_CSV_FILE_ID });
            var rfiLogId = script.getParameter({ name: SPARAM_RFI_LOG_ID });
            
            
            var batches = {};
            
            if (rfiLogId) {
            	
            	var rfiExecLogRec = RECORD.load({type: CUSTOM_RECORD_RFI_EXECUTION_LOG,id: rfiLogId,isDynamic: false});

        		var csvFileId = rfiExecLogRec.getValue({
        		    fieldId: FLD_RFI_CSV_FILE
        		});
            	
        		if(csvFileId){
        			
                    var fileData = FILE.load(csvFileId).getContents();
                    
                    if (fileData) {
                        var lines = fileData.split('\n');
                        
                        // We skip the header row...
                        for (var i=1, n=lines.length; i<n; i++) {
                            if (lines[i]) {
                                var line = lines[i].split(',');
                                LOG.debug({ title: LOG_TITLE, details: 'line = ' + line });
                                
                                var tranId = line[0];
                                var lineId = line[1];
                                LOG.debug({ title: LOG_TITLE, details: 'tranId = ' + tranId + ', lineId = ' + lineId });
                                
                                if (batches[tranId]) {
                                    LOG.debug({ title: LOG_TITLE, details: 'batches[tranId] exists...' });
                                    batches[tranId].push(lineId);
                                }
                                else {
                                    LOG.debug({ title: LOG_TITLE, details: 'batches[tranId] missing...' });
                                    batches[tranId] = [ lineId ];
                                }
                            }
                        }
                    }
        			
        		}
        		
        		rfiExecLogRec.setValue({fieldId: FLD_RFI_STATUS,value: '2' });
        		try{
        			rfiExecLogRec.save({
    				    enableSourcing: true,
    				    ignoreMandatoryFields: true
    				});

        		}catch(error){
        			log.debug('error saving...', error.message);
        		}
            	

            }
            
            LOG.debug({ title: LOG_TITLE, details: JSON.stringify(batches) });
            return batches;
        }

        function reduce(context) {
            var LOG_TITLE = 'reduce';
            LOG.debug({ title: LOG_TITLE + ' START', details: context });
            
            LOG.debug({ title: LOG_TITLE, details: 'key = ' + context.key + ', value = ' + context.values[0] });
            var lines = JSON.parse(context.values[0]);
            LOG.debug({ title: LOG_TITLE, details: 'lines length = ' + lines.length + ', start = ' + new Date() });
            
            try {
                LOG.debug({ title: LOG_TITLE, details: 'Loading order ID ' + context.key });
                var so = RECORD.load({
                    type: 'salesorder',
                    id: context.key
                });
                
                var isChanged = false;
                for (var i=0, n=lines.length; i<n; i++) {
                    var lineNum = so.findSublistLineWithValue({
                        sublistId: 'item',
                        fieldId: 'custcol_appf_line_id',
                        value: lines[i]
                    });
                    LOG.debug({ title: LOG_TITLE, details: 'lineNum = ' + lineNum });
                    
                    if (lineNum >= 0) {
                        so.setSublistValue({
                            sublistId: 'item',
                            fieldId: 'custcol_appf_ready_for_invoicing',
                            value: true,
                            line: lineNum
                        });
                        isChanged = true;
                    }
                }
                
                if (isChanged == true) {
                    var soId = so.save();
                    LOG.debug({ title: LOG_TITLE, details: 'Successfully updated order ID ' + soId });
                }
            }
            catch(e) {
                LOG.debug({ title: LOG_TITLE + ' ERROR', details: JSON.stringify(e) });
            }
            
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        /**
         * Executes when the summarize entry point is triggered and applies to the result set.
         *
         * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
         * @since 2015.1
         */
        function summarize(summary) {
        	 var SPARAM_RFI_LOG_ID = 'custscript_appf_rfi_log_id';
             var CUSTOM_RECORD_RFI_EXECUTION_LOG = 'customrecord_appf_rfi_log';
             var FLD_RFI_STATUS = 'custrecord_appf_rfi_log_status';
             var script = RUNTIME.getCurrentScript();
             var rfiLogId = script.getParameter({ name: SPARAM_RFI_LOG_ID });
        	
            var LOG_TITLE = 'summarize';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            var rfiExecLogRec = RECORD.load({type: CUSTOM_RECORD_RFI_EXECUTION_LOG,id: rfiLogId,isDynamic: false});
            rfiExecLogRec.setValue({fieldId: FLD_RFI_STATUS,value: '3' });
            
    		try{
    			rfiExecLogRec.save({
				    enableSourcing: true,
				    ignoreMandatoryFields: true
				});

    		}catch(error){
    			log.debug('error saving...', error.message);
    		}

            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        return {
            getInputData: getInputData,
            reduce: reduce,
            summarize: summarize
        };
    }
);