/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define(['N/runtime', 'N/search', 'N/record'],
function(runtime, search, record) {
    //SCRIPT PARAMETERS
    const SPARAM_SEARCH_PURCHASE_ORDER = 'custscript_search_po_wo_remit_email';
    const SPARAM_SEARCH_CONTACT = 'custscript_search_contact';

    //FIELDS
    //Vendor
    const FLD_VENDOR_CONTACTS = 'custentity_appf_remittance_email_list.vendor';
    //Purchase Order
    const FLD_PO_REMITTANCE_EMAIL = 'custbody_appf_remittance_email_main';
    //Contact
    const FLD_CONTACT_ROLE = 'custentity_appf_vendor_role';

    const thisScript = runtime.getCurrentScript();

    function getInputData() {
        const poSearch = search.load({
            id: thisScript.getParameter(SPARAM_SEARCH_PURCHASE_ORDER)
        });

        return poSearch;
    }

    function map(context)
    {
        log.debug('MAP INSTANCE', '===========START===========');

        const row = JSON.parse(context.value);
        log.debug('map: row', row);

        const purchaseOrder = row.id;
        const contacts = row.values[FLD_VENDOR_CONTACTS];
        log.debug('contacts', contacts);

        let contact = '';
        if (!Array.isArray(contacts)) {
            contact = contacts.value;
        } else {
            const contactSearch = search.load({
                id: thisScript.getParameter(SPARAM_SEARCH_CONTACT)
            });
            const contactSearchFilters = contactSearch.filters;
            const contactFilter = search.createFilter({
                name: 'internalid',
                operator: search.Operator.ANYOF,
                values: contacts
            });
            contactSearchFilters.push(contactFilter);

            contactSearch.run().each(function(result) {
                log.debug('result', result);
                
                log.debug('result.getValue({name:FLD_CONTACT_ROLE})', result.getValue({
                    name: FLD_CONTACT_ROLE
                }));
                const roleList = result.getValue({
                    name: FLD_CONTACT_ROLE
                });
                log.debug('roleList', roleList);

                if (roleList.includes(1)) {
                    log.debug('roleList', 'includes 1');
                    contact = result.id;
                    return false;
                } else {
                    if(roleList.includes(2)) {
                        log.debug('roleList', 'includes 2 but not 1');
                    }
                    return true;
                }
            });
        }
        log.debug('contact', contact);

        let email = '';
        if (!isEmpty(contact)) {
            const contactFields = search.lookupFields({
                type: search.Type.CONTACT,
                id: contact,
                columns: 'email'
            });

            email = contactFields.email;
            log.debug('email', email);

            if(!isEmpty(email)) {
                context.write({
                    key: purchaseOrder,
                    value: email
                });
            }
        }

        log.debug('MAP INSTANCE', '============END============');
    }

    function reduce(context)
    {
        log.debug('REDUCE INSTANCE', '===========START===========');
        const purchaseOrder = context.key;
        const email = context.values;
        log.debug('reduce: key | value', purchaseOrder + ' | ' + email);

        try {
            const poIdUpdated = record.submitFields({
                type: record.Type.PURCHASE_ORDER,
                id: purchaseOrder,
                values: {
                    [FLD_PO_REMITTANCE_EMAIL]: email
                }
            });
            log.debug('poIdUpdated', poIdUpdated);
        }
        catch (e) {
            const errorMessage = e.message;
            log.debug('reduce: ERROR', errorMessage);
        }
        log.debug('REDUCE INSTANCE', '============END============');
    }

    function isEmpty(value) {
        return ((value === '' || value === null || value === undefined) || (value.constructor === Array && value.length === 0) || (value.constructor === Object && (function (
            v) {
            for (var k in v)
                return false;
            return true;
        })(value)));
    }

    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce
    }
});