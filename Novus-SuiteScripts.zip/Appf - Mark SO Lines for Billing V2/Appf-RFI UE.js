/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Generates custom PDF layout depending on PDF template assigned to CI NRECORD.
 * 
 * Author: marlon
 * Date: Dec 10, 2020
 */

define(
    [
        'N/log',
        'N/ui/serverWidget'        
    ],
    
    function (
        NLOG,
        NUI
    ) {
        
        function _beforeLoad(context) {
            var LOG_TITLE = '_beforeLoad';
            NLOG.debug({ title: LOG_TITLE, details: 'START' });
            
            context.form.addButton({
                id: 'custpage_rfi_refresh',
                label: 'Refresh',
                functionName: 'location.reload();return false;'
            });
            
            NLOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        return {
            beforeLoad: _beforeLoad
        };
    }
);
