/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Generates custom PDF layout depending on PDF template assigned to CI record.
 * 
 * Script Name : Appf-Create Client CI Validations CL
 * Script Type : Client
 * Description : 
 * Company     : Appficiency Inc.
 * Author      : marlon
 * Date        : Nov 19, 2020
 */

define(
    [
        'N/currentRecord',
        'N/log',
        'N/search'
    ],
    
    function (
        NCR,
        NLOG,
        NSEARCH
    ) {
        
        var FLD_SL_CLIENT = 'custpage_client';
        var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
        var FLD_SL_PROJECT = 'custpage_project';
        var FLD_SL_SERVICE_DATE_FROM = 'custpage_service_date_from';
        var FLD_SL_SERVICE_DATE_TO = 'custpage_service_date_to';
        var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
        var FLD_SL_END_DATE= 'custpage_end_date';
        var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
        var FLD_SL_START_DATE_FROM= 'custpage_start_date_from';
        var FLD_SL_END_DATE_TO= 'custpage_end_date_to';
        var FLD_SL_END_DATE_FROM= 'custpage_end_date_from';
        var FLD_SL_IN_NUM = 'custpage_inv_num';
        var FLD_SL_IO_NUM = 'custpage_io_num';
        var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
        var SL_FLD_CURRENCY='custpage_currency';
        var FLD_SL_POP_RECEIVED = 'custpage_pop_received';
        var FLD_SL_TOTAL_AMOUNT = 'custpage_total_amount';
        var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
        // 1.1 new Filters
        var FLD_SL_BILL_MONTH = 'custpage_bill_month';
        var FLD_SL_PLACEMENT_NUM = 'custpage_placement_num';
        var FLD_SL_STRATA_ESTIMATE_NUM = 'custpage_strata_est_num';
        var FLD_SL_URL = 'custpage_sl_url';

        var SL_SUBLIST = 'custpage_sl_sublist';
        var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
        var SL_COL_TOTAL_AMOUNT = 'custpage_scriptfield3';

        var SCRIPT_MARK_SO_LINES_BILLING_SL='customscript_appf_mark_so_lines_bill_sl';
        var DEPLOY_MARK_SO_LINES_BILLING_SL='customdeploy_appf_mark_so_lines_bill_sl';
        
        function clientFieldChange(context) {
            console.log('clientFieldChange');
            var cr = context.currentRecord;
            var fld;
            console.log('fieldId = ' + context.fieldId);
            
            if (context.fieldId == FLD_SL_CLIENT) {
                var client = cr.getValue({ fieldId: FLD_SL_CLIENT });
                var clientSubsidiary = '';
                console.log('fieldId = ' + cr.fieldId + ', val = ' + client);
                
                if(client != null && client != '') {
                    fld = cr.getField({ fieldId: FLD_SL_SUBSIDIARY });
                    fld.isDisabled = true;
                    
                    var clientFields = NSEARCH.lookupFields({
                        type: 'customer',
                        id: client,
                        columns: [
                            'currency',
                            'subsidiary'
                        ]
                    });
                    console.log(clientFields)
                    
                    var curr = clientFields.currency[0].value;
                    clientSubsidiary = clientFields.subsidiary[0].value;
                    
                    if (curr != null && curr != '')
                        cr.setValue({ fieldId: SL_FLD_CURRENCY, value: curr });
                }
                else {
                    cr.setValue({ fieldId: SL_FLD_CURRENCY, value: '' });
                    fld = cr.getField({ fieldId: FLD_SL_SUBSIDIARY });
                    fld.isDisabled = false;
                }
                
                if(clientSubsidiary !=null && clientSubsidiary !='') {
                    cr.setValue({ fieldId: FLD_SL_SUBSIDIARY, value: clientSubsidiary });
                }
                else {
                    cr.setValue({ fieldId: FLD_SL_SUBSIDIARY, value: '' });
                }
            }
            
            if (context.sublistId == SL_SUBLIST) {
                if (context.fieldId == FLD_COL_SL_SELECT) {
                    var totAmt = 0;
                    var totLines = 0;
                    var count = cr.getLineCount({ sublistId: SL_SUBLIST });
                    console.log('count = ' + count);
                    
                    for (var c = 0; c < count; c++) {
                        cr.selectLine({
                            sublistId: SL_SUBLIST,
                            line: c
                        });
                        var selected = cr.getCurrentSublistValue({
                            sublistId: SL_SUBLIST,
                            fieldId: FLD_COL_SL_SELECT
                        });
                        
                        if (selected == true) {
                            totLines++;
                            var totalAmount = cr.getCurrentSublistValue({
                                sublistId: SL_SUBLIST,
                                fieldId: SL_COL_TOTAL_AMOUNT
                            });
                            totAmt = Number(totAmt) + Number(totalAmount);
                        }
                    }
                    // console.log('totLines = ' + totLines + ', totAmt = ' + totAmt);
                    
                    cr.setValue({ fieldId: FLD_SL_TOTAL_AMOUNT, value: Number(totAmt) });
                    cr.setValue({ fieldId: FLD_SL_TOTAL_LINES, value: totLines });
                }
            }
        }

        function applyFilters() {
            console.log('applyFilters');
            var cr = NCR.get();
            
            var client = cr.getValue({ fieldId: FLD_SL_CLIENT });
            var mediaSegment = cr.getValue({ fieldId: FLD_SL_MEDIA_SEGMENT });
            var proj = cr.getValue({ fieldId: FLD_SL_PROJECT });
            var serviceDateFrom = cr.getText({ fieldId: FLD_SL_SERVICE_DATE_FROM });
            var serviceDateTo = cr.getText({ fieldId: FLD_SL_SERVICE_DATE_TO });
            var ioNum = cr.getValue({ fieldId: FLD_SL_IO_NUM });
            var subsidiaryVal = cr.getValue({ fieldId: FLD_SL_SUBSIDIARY });
            var popReceived = cr.getValue({ fieldId: FLD_SL_POP_RECEIVED });
            var startDateFrom = cr.getText({ fieldId: FLD_SL_START_DATE_FROM });
            var endDateFrom= cr.getText({ fieldId: FLD_SL_END_DATE_FROM });
            var startDateTo = cr.getText({ fieldId: FLD_SL_START_DATE_TO });
            var endDateTo= cr.getText({ fieldId: FLD_SL_END_DATE_TO });
            var invNum= cr.getValue({ fieldId: FLD_SL_IN_NUM });
            var curr= cr.getValue({ fieldId: SL_FLD_CURRENCY });
            var billMonth= cr.getValue({ fieldId: FLD_SL_BILL_MONTH });
            var placementNum= cr.getValue({ fieldId: FLD_SL_PLACEMENT_NUM });
            var strataEstNum= cr.getValue({ fieldId: FLD_SL_STRATA_ESTIMATE_NUM });

            var suiteletURL = cr.getValue({ fieldId: FLD_SL_URL });
            suiteletURL = suiteletURL + '&client=' + client + '&mediaSegment=' + mediaSegment +
                            '&proj=' + proj + '&serviceDateFrom=' + serviceDateFrom + '&serviceDateTo=' + serviceDateTo +
                            '&ioNum=' + ioNum + '&subsidiaryVal=' + subsidiaryVal + '&popReceived=' + popReceived;
            suiteletURL += '&startDateFrom='+startDateFrom+'&endDateFrom='+endDateFrom+'&startDateTo='+startDateTo+'&endDateTo='+endDateTo+'&invNum='+invNum+'&currency='+curr;
            suiteletURL += '&billMonth='+billMonth+'&placementNum='+placementNum+'&strataEstNum='+strataEstNum;
            suiteletURL += '&applyfilters=T';
            // console.log('suiteletURL');
            // console.log(suiteletURL);
            window.open(suiteletURL,'_self');
        }

        function onSaveVCSL(context) {
            var cr = context.currentRecord;
            var counter = 0;
            var count = cr.getLineCount({ sublistId: SL_SUBLIST });
            
            if (count > 0) {
                for(var i = 0; i < count; i++){
                    cr.selectLine({
                        sublistId: SL_SUBLIST,
                        line: i
                    });
                    var checkbox = cr.getCurrentSublistValue({
                        sublistId: SL_SUBLIST,
                        fieldId: FLD_COL_SL_SELECT
                    });
                    
                    if(checkbox == true) {
                        counter++;
                    }
                }
            }
            
            if (counter == 0){
                alert('Please Select atleast one line to Proceed.');
                return false;
            }
            else {
                var submitConfirmation = confirm('Selected transactions will be processed for Mark SO Lines for Billing Suitelet, Click OK to proceed.');
                if (submitConfirmation == true) {
                    return true;
                }
                else {
                   return false;
                }
            }
        }

        function unmarkAll() {
            var cr = NCR.get();
            
            var count = cr.getLineCount({ sublistId: SL_SUBLIST });
            var unmarked = false;
            
            for(var i = 0; i < count; i++) {
                cr.selectLine({
                    sublistId: SL_SUBLIST,
                    line: i
                });
                cr.setCurrentSublistValue({
                    sublistId: SL_SUBLIST,
                    fieldId: FLD_COL_SL_SELECT,
                    value: false,
                    ignoreFieldChange: true
                });
                cr.commitLine({
                    sublistId: SL_SUBLIST
                });
                unmarked = true;
            }
            
            if(unmarked) {
                cr.setValue({ fieldId: FLD_SL_TOTAL_AMOUNT, value: '' });
                cr.setValue({ fieldId: FLD_SL_TOTAL_LINES, value: '' });
            }
        }

        function markAll() {
            var cr = NCR.get();
            
            var totAmt = 0;
            var totLines = 0;
            var count = cr.getLineCount({ sublistId: SL_SUBLIST });
            console.log('count = ' + count);
            var marked = false;
            var amts = [];
            
            for(var c = 0; c < count; c++) {
                totLines++;
                
                cr.selectLine({
                    sublistId: SL_SUBLIST,
                    line: c
                });
                
                var totalAmount = cr.getCurrentSublistValue({
                    sublistId: SL_SUBLIST,
                    fieldId: SL_COL_TOTAL_AMOUNT
                });
                amts.push(totalAmount);
                
                cr.setCurrentSublistValue({
                    sublistId: SL_SUBLIST,
                    fieldId: FLD_COL_SL_SELECT,
                    value: true,
                    ignoreFieldChange: true
                });
                
                cr.commitLine({
                    sublistId: SL_SUBLIST
                });
                
                totAmt = Number(totAmt) + Number(totalAmount);
                marked = true;
            }
            console.log(amts);
            
            if (marked) {
                cr.setValue({ fieldId: FLD_SL_TOTAL_AMOUNT, value: Number(totAmt) });
                cr.setValue({ fieldId: FLD_SL_TOTAL_LINES, value: totLines });
            }
        }

        function pageInit(context) {
            console.log('pageInit');
            var cr = context.currentRecord;
            
            var totAmt = 0;
            var totLines = 0;
            var count = cr.getLineCount({ sublistId: SL_SUBLIST });
            var marked = false;
            
            for (var c = 0; c < count; c++) {
                totLines++;
                
                cr.selectLine({
                    sublistId: SL_SUBLIST,
                    line: c
                });
                var totalAmount = cr.getCurrentSublistValue({
                    sublistId: SL_SUBLIST,
                    fieldId: SL_COL_TOTAL_AMOUNT
                });
                totAmt = Number(totAmt) + Number(totalAmount);
                marked = true;
            }

            if(marked) {
                cr.setValue({ fieldId: FLD_SL_TOTAL_AMOUNT, value: Number(totAmt) });
                cr.setValue({ fieldId: FLD_SL_TOTAL_LINES, value: totLines });
            }
        }

        return {
            // pageInit: pageInit,
            saveRecord: onSaveVCSL,
            fieldChanged: clientFieldChange,
            applyFilters: applyFilters,
            markAll: markAll,
            unmarkAll: unmarkAll
        };
    }
);
