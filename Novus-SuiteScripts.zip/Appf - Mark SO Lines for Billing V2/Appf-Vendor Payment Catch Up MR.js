/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record', 'N/runtime'],

function(search, record, runtime) {
   
    var PARAM_SEARCHID = 'custscript_appf_vendbill_catchup_ss';
    var FLD_BILL_LINE_PAYMENT_AMOUNT = 'custcol_appf_pwp_bill_line_amt_paid';

    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
      try{
        var searchId = runtime.getCurrentScript().getParameter({name: PARAM_SEARCHID});

        return search.load({id: searchId});
      }
      catch(e){
        log.error("ERROR IN GETINPUTDATA", e.message);
      }
    }

    /**
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    function map(context) {
      try{
        var key = context.key;
        var searchResult = JSON.parse(context.value);

        log.debug("key", key);
        log.debug("value", searchResult);

        var vendBillId = searchResult.values["GROUP(internalid)"].value;
        var amountPdFx = searchResult.values["MAX(fxamountpaid)"];

        var vendBillRecord = record.load({
          type:record.Type.VENDOR_BILL,
          id: vendBillId
        })
        var itemLineCount = vendBillRecord.getLineCount({sublistId: 'item'});

        for(var i = 0; i < itemLineCount; i++){
          vendBillRecord.setSublistValue({
            sublistId: 'item',
            fieldId: FLD_BILL_LINE_PAYMENT_AMOUNT,
            line: i,
            value: parseFloat(amountPdFx)
          });
        }

        var vendBillId_submitted = vendBillRecord.save({ignoreMandatoryFields: true});
        log.debug("Vendor Bill Updated", vendBillId_submitted);

      }catch(e){
        log.error("ERROR IN MAP", e.message);
      }

    }

    /**
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
    function reduce(context) {

    }


    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {

    }

    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce,
        summarize: summarize
    };
    
});
