/**
	 * Script Name : Appf-VVCCP Manual UnProcess Response Files 
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var APPF_VVCCP_SFTP_RECEIVE_SL_SCRIPT_ID='customscript_appf_vvccp_receive_sl';
var APPF_VVCCP_SFTP_RECEIVE_SL_DEPLOY_ID='customdeploy_appf_vvccp_receive_sl';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_AMEX_RESPONSE_UNPROCESSED=1141;
var VVCCP_AMEX_RESPONSE_PROCESSED=1140;
var VVCCP_AMEX_RECON_UNPROCESSED=1139;
var VVCCP_AMEX_RECON_PROCESSED=1142;

var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;

var RESPONSE_PREFIX_AMEX = 'Response-267236';
var RECON_PREFIX_AMEX = 'Recon-267236';


var CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG='customrecord_appf_vvccp_response_proc';
var FLD_INBOUND_FILE_TYPE='custrecord_appf_vvccp_inbound_file_type';
var FLD_VVCCP_TO_PROCESS='custrecord_appf_vvccp_num_process';
var FLD_VVCCP_PROCESSED='custrecord_appf_vvccp_num_processed';
var FLD_PROCESSED_PERCENTAGE='custrecord_appf_vvccp_processed_perc';
var FLD_RESPONSE_OR_RECON_FILE='custrecord_appf_vvccp_res_rec';
var FLD_RESPONSE_OR_RECON_RESULT_FILE='custrecord_appf_vvccp_res_rec_result';
var FLD_ERROR_LOG='custrecord_appf_vvccp_res_rec_errors';
var FLD_VVCCP_RECORD_LINK='custrecord_appf_vvccp_res_rec_link';
var FLD_VIRTUAL_CARD_LINK='custrecord_appf_vvccp_res_card_link';
var	FLD_VVCCP_RECON_RECORD_LINK='custrecord_appf_vvccp_recon_record_link';
var FLD_FILE_MOVED_TO_PROCESSED_FOLDER='custrecord_appf_vvccp_res_rec_file_moved';
var FLD_RESPONSE_FILE_PROCESSED='custrecord_response_file_processed';
var FLD_CARD_PROVIDER = 'custrecord_appf_resp_recon_card_provider';
var FLD_VVCCP_FAILED='custrecord_num_vvccp_failed';
var VVCCP_INBOUND_FILE_TYPE_RESPONSE='1';
var VVCCP_INBOUND_FILE_TYPE_RECON='2';

var SPARAM_AMEX_RESPONSE_FILE_IDS = 'custscript_amex_resp_file_ids';
var SPARAM_MASTERCARD_RESPONSE_FILE_IDS = 'custscript_mc_resp_file_ids';

var SPARAM_AMEX_RECON_FILE_IDS = 'custscript_amex_rec_file_ids';
var SPARAM_MASTERCARD_RECON_FILE_IDS = 'custscript_mc_rec_file_ids';

function schedule(type)
{
	
		var context=nlapiGetContext();
		
		var fileIdsforResponseAmex = [];
		var fileIdsforReconAmex = [];
        var fileIdsforResponseMasterCard = [];
		var fileIdsforReconMasterCard = [];


var responseFilesFromParamAmex = context.getSetting('SCRIPT', SPARAM_AMEX_RESPONSE_FILE_IDS);
if (responseFilesFromParamAmex != null && responseFilesFromParamAmex != '')
{
fileIdsforResponseAmex = fileIdsforResponseAmex.concat(responseFilesFromParamAmex.split(','));

}

var responseFilesFromParamMasterCard = context.getSetting('SCRIPT', SPARAM_MASTERCARD_RESPONSE_FILE_IDS);
if (responseFilesFromParamMasterCard != null && responseFilesFromParamMasterCard != '')
{
fileIdsforResponseMasterCard = fileIdsforResponseMasterCard.concat(responseFilesFromParamMasterCard.split(','));

}

var reconFilesFromParamAmex = context.getSetting('SCRIPT', SPARAM_AMEX_RECON_FILE_IDS);
if (reconFilesFromParamAmex != null && reconFilesFromParamAmex != '')
{
fileIdsforReconAmex = fileIdsforReconAmex.concat(reconFilesFromParamAmex.split(','));

}

var reconFilesFromParamMasterCard = context.getSetting('SCRIPT', SPARAM_MASTERCARD_RECON_FILE_IDS);
if (reconFilesFromParamMasterCard != null && reconFilesFromParamMasterCard != '')
{
fileIdsforReconMasterCard = fileIdsforReconMasterCard.concat(reconFilesFromParamMasterCard.split(','));

}


                                  if (fileIdsforResponseAmex.length > 0)
								  {
								  for (var f = 0; f < fileIdsforResponseAmex.length; f++)
								  {
								     var amexResponseFileId = fileIdsforResponseAmex[f];
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
                                    nameToSetForLogRecord=nameToSetForLogRecord.replace('.csv','');
                                  nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE, VVCCP_INBOUND_FILE_TYPE_RESPONSE);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER, '2');
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
									}
									}
									
									
									if (fileIdsforResponseMasterCard.length > 0)
								  {
								  for (var f = 0; f < fileIdsforResponseMasterCard.length; f++)
								  {
								     var amexResponseFileId = fileIdsforResponseMasterCard[f];
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
                                  nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE, VVCCP_INBOUND_FILE_TYPE_RESPONSE);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER, '1');
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
									}
									}
									
									
									
									if (fileIdsforReconAmex.length > 0)
								  {
								  for (var f = 0; f < fileIdsforReconAmex.length; f++)
								  {
								     var amexResponseFileId = fileIdsforReconAmex[f];
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
                                  nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE, VVCCP_INBOUND_FILE_TYPE_RECON);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER, '2');
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
									}
									}
									
									
									if (fileIdsforReconMasterCard.length > 0)
								  {
								  for (var f = 0; f < fileIdsforReconMasterCard.length; f++)
								  {
								     var amexResponseFileId = fileIdsforReconMasterCard[f];
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
                                  nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE, VVCCP_INBOUND_FILE_TYPE_RECON);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER, '1');
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
									}
									}
				
					
		
}

function zeroFill( number, width )
{
  width -= number.toString().length;
  if ( width > 0 )
  {
    return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
  }
  return number + ""; // always return a string
}
function formatDate(date) {
    var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear().toString().substr(-2);
	var century=d.getFullYear().toString().substr(0,2);
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return century.toString()+year.toString()+month.toString()+day.toString();
}