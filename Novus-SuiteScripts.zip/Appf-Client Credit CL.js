/*
*Script Name: Appf-Client Credit CL
*Script Type: Client Script
*Description: This script will handle client side validations for Appf-Client Credit SL
*Company 	: Appficiency.
*/
var SL_FLD_CONSOLIDATED_INVOICE='custpage_consolidated_invoice';
var SL_FLD_MEDIA_TYPE='custpage_media_type';
var SL_FLD_PROJECT='custpage_project';
var SL_FLD_DATE_FROM='custpage_date_from';
var SL_FLD_DATE_TO='custpage_date_to';
var SL_FLD_IO='custpage_io';
var SL_FLD_VENDOR='custpage_vendor';
var SL_FLD_MEDIA_SUPPLIER='custpage_media_supplier';
var SL_FLD_PARENT_CLIENT='custpage_parent_client';
var SL_FLD_CLIENT='custpage_client';
var SL_FLD_CURRENCY='custpage_currency';
var SL_FLD_SUBSIDIARY='custpage_subsidiary';
var SL_FLD_TOTAL_CREDITS = 'custpage_total_credits';
var SL_FLD_TOTAL_CREDIT_MEMOS = 'custpage_total_credit_memos';

var SL_SUBLIST='custpage_custom_line';
var SL_COL_UPDATE='custpage_update';
var SL_COL_CREDIT_AMOUNT = 'custpage_credit_amount';

var SCRIPT_SL_CLIENT_CREDIT_SUITELET='customscript_appf_client_credit_sl';
var DEPLOY_SL_CLIENT_CREDIT_SUITELET='customdeploy_appf_client_credit_sl';


function parentClientFieldChange(type, name, linenum){
  if(name == SL_FLD_PARENT_CLIENT){
    var consolidatedInv = nlapiGetFieldValue(SL_FLD_CONSOLIDATED_INVOICE);
	if(consolidatedInv == null || consolidatedInv == '')
		consolidatedInv = '';
    
	var mediaType = nlapiGetFieldValue(SL_FLD_MEDIA_TYPE);
	if(mediaType == null || mediaType == '')
		mediaType = '';
	
	var project = nlapiGetFieldValue(SL_FLD_PROJECT);
	if(project == null || project == '')
		project = '';
	
	var dateFrom = nlapiGetFieldValue(SL_FLD_DATE_FROM);
	if(dateFrom == null || dateFrom == '')
		dateFrom = '';
	var dateTo = nlapiGetFieldValue(SL_FLD_DATE_TO);
	if(dateTo == null || dateTo == '')
		dateTo = '';
	var io = nlapiGetFieldValue(SL_FLD_IO);
	if(io == null || io == '')
		io = '';
	var vendor = nlapiGetFieldValue(SL_FLD_VENDOR);
	if(vendor == null || vendor == '')
		vendor = '';
	var mediaSupplier = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER);
	if(mediaSupplier == null || mediaSupplier == '')
		mediaSupplier = '';
	var parentClient = nlapiGetFieldValue(SL_FLD_PARENT_CLIENT);
	if(parentClient == null || parentClient == '')
		parentClient = '';
	var client = nlapiGetFieldValues(SL_FLD_CLIENT);
	if(client == null || client == '')
		client = '';
    var currency = nlapiGetFieldValue(SL_FLD_CURRENCY);
    
	if(currency == null || currency == '')
		currency = '';
	var subsidiary = nlapiGetFieldValue(SL_FLD_SUBSIDIARY);
	if(subsidiary == null || subsidiary == '')
		subsidiary = '';
    var parentSubsidiary = '';
    var curr = '';
    if(parentClient != null && parentClient != ''){
       curr = nlapiLookupField('customer', parentClient, 'currency');
       }
   
  
  
    
   var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_SL_CLIENT_CREDIT_SUITELET, DEPLOY_SL_CLIENT_CREDIT_SUITELET);
suiteletURL=suiteletURL+'&consolidateInv='+consolidatedInv+'&media='+mediaType+'&proj='+project+'&dtFrom='+dateFrom+'&dtTo='+dateTo+'&io='+io+'&vendor='+vendor+'&mediasupp='+mediaSupplier+'&pclient='+parentClient+'&client='+client+'&subs='+parentSubsidiary+'&currency='+curr;
	window.open(suiteletURL,'_self');
    
     }
  if(type == SL_SUBLIST){
     	if(name == SL_COL_UPDATE){
          var totCreditAmt = 0;
          var totCreditMemos = 0;
           var count = nlapiGetLineItemCount(SL_SUBLIST);
          	for(var c=1; c<=count; c++){
              var selected = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, c);
              if(selected == 'T'){
                 totCreditMemos++;
                var creditAmt = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_CREDIT_AMOUNT, c);
                totCreditAmt = Number(totCreditAmt) + Number(creditAmt);
                 }
            }
          nlapiSetFieldValue(SL_FLD_TOTAL_CREDITS, Number(totCreditAmt));
          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, totCreditMemos);
           }
     }
}

function applyFilter()
{
	var applyFilter = false;
	
	var consolidatedInv = nlapiGetFieldValue(SL_FLD_CONSOLIDATED_INVOICE);
	if(consolidatedInv == null || consolidatedInv == '')
		consolidatedInv = '';

	
	var mediaType = nlapiGetFieldValue(SL_FLD_MEDIA_TYPE);
	if(mediaType == null || mediaType == '')
		mediaType = '';
	
	var project = nlapiGetFieldValue(SL_FLD_PROJECT);
	if(project == null || project == '')
		project = '';
	
	var dateFrom = nlapiGetFieldValue(SL_FLD_DATE_FROM);
	if(dateFrom == null || dateFrom == '')
		dateFrom = '';
	var dateTo = nlapiGetFieldValue(SL_FLD_DATE_TO);
	if(dateTo == null || dateTo == '')
		dateTo = '';
  var currency = nlapiGetFieldValue(SL_FLD_CURRENCY);
	if(currency == null || currency == '')
		currency = '';
	var io = nlapiGetFieldValue(SL_FLD_IO);
	if(io == null || io == '')
		io = '';
	var vendor = nlapiGetFieldValue(SL_FLD_VENDOR);
	if(vendor == null || vendor == '')
		vendor = '';
	var mediaSupplier = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER);
	if(mediaSupplier == null || mediaSupplier == '')
		mediaSupplier = '';
	var parentClient = nlapiGetFieldValue(SL_FLD_PARENT_CLIENT);
	if(parentClient == null || parentClient == '')
		parentClient = '';
	var client = nlapiGetFieldValues(SL_FLD_CLIENT);
  	var clientVal = '';
	if(client == null || client == '')
		client = '';
  	else{
      for(var cl=0; cl<client.length; cl++){
        clientVal += client[cl] + '|'
      }
      clientVal = clientVal.slice(0,-1);
    }
	var subsidiary = nlapiGetFieldValue(SL_FLD_SUBSIDIARY);
	if(subsidiary == null || subsidiary == '')
		subsidiary = '';
	
	//if(parentClient != null && parentClient != '' && client != null && client != ''){
	var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_SL_CLIENT_CREDIT_SUITELET, DEPLOY_SL_CLIENT_CREDIT_SUITELET);
	suiteletURL=suiteletURL+'&consolidateInv='+consolidatedInv+'&media='+mediaType+'&proj='+project+'&dtFrom='+dateFrom+'&dtTo='+dateTo+'&io='+io+'&vendor='+vendor+'&mediasupp='+mediaSupplier+'&pclient='+parentClient+'&client='+clientVal+'&subs='+subsidiary+'&currency='+currency+'&applyFils=T';
	window.open(suiteletURL,'_self');
	/*
	}
	else if((parentClient != null && parentClient != '') && (client == null || client == '')){
		  alert('Please select the field value: Client');
	}
else if((parentClient == null || parentClient == '') && (client != null && client != '')){
		  alert('Please select the field value: Parent Client');
	}
    else{
       alert('Please select the field value(s) : Parent Client, Client');
    }
	*/
	
}


function onSaveCCSL() {

	var counter=0;
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	if(count > 0){
	for(var i=1; i<=count; i++){
		var checkbox=nlapiGetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i);
		if(checkbox == 'T')
			counter++;
	}
	
	}
	if(counter == 0){
		alert('Please select atleast one line to proceed');
		return false;
	}
	else{
			var submitConfirmation= confirm('Selected transactions will be processed for Client Credit Creation, Click OK to proceed.');
			if (submitConfirmation== true)
			{
				return true;
			}
		   else
		   {
			   return false;
		   }
		return true;
    }
		
}


function unmarkAll(){
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	for(var i=1; i<=count; i++){
		nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i, 'F');
	}
  nlapiSetFieldValue(SL_FLD_TOTAL_CREDITS, 0);
          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, 0);
}

function markAll(){
  	var totCreditAmt = 0;
          var totCreditMemos = 0;
           var count = nlapiGetLineItemCount(SL_SUBLIST);
          	for(var c=1; c<=count; c++){
              nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, c, 'T');
              
                 totCreditMemos++;
                var creditAmt = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_CREDIT_AMOUNT, c);
                totCreditAmt = Number(totCreditAmt) + Number(creditAmt);
                
            }
          nlapiSetFieldValue(SL_FLD_TOTAL_CREDITS, Number(totCreditAmt));
          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, totCreditMemos);
}
