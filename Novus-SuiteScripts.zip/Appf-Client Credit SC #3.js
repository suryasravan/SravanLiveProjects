/**
	 * Script Name : Appf-Client Credit SC #3
	 * Script Type : Scheduled
	 * 
	 * Version    Date			 Author			        Remarks
	 * 1.0		  										 * Company 	 : Appficiency. 
*/

var CUSTOM_RECORD_CREDIT_CREATION_LOG = 'customrecord_appf_cust_crd_log';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_cst_crd_tl_pro';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_cst_crd_inv_completed';
var FLD_TOT_LINES_FAILD = 'custrecord_appf_cst_crd_lines_failed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_cst_crd_perc_processed';
var FLD_CREATED_BY = 'custrecord_appf_cst_crd_created_by';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_cst_crd_status';
var FLD_DATA_FILE = 'custrecord_appf_cst_crd_data_file';
var FLD_STATUS_FILE  = 'custrecord_appf_cst_crd_error_file';
var FLD_ERROR_LOG = 'custrecord_appf_cst_crd_error_log';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_cst_crd_client';
var FLD_CURRENCY = 'custrecord_appf_cst_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_cst_crd_link';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_cst_crd_invoice_link';
var FLD_RESULT_FILE = 'custrecord_appf_cc_result_file';
var FLD_SO_BACKLINKING_PERCENT = 'custrecord_appf_so_backlink_percent';
var FLD_SO_BACKLINKING_STATUS = 'custrecord_appf_so_backlinking_status';

var FLD_INV_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var STATUS_INV_CREDIT_SL_READY_FOR_PROCESSING = '3';
var FLD_INV_LOG_RECORDS = 'custbody_appf_credit_log_record';
var FLD_COL_INV_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_COL_INV_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_COL_PWP_REC_SO_LINE='custcol_appf_pwp_custom_record';

var FLD_COL_CRED_MEMO_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_CRED_MEMO_PROJECT_HEADER = 'custbody_appf_project_header';

var STATUS_CR_COMPLETED_SUCCESSFULLY = '4';
var STATUS_CR_COMPLETED_WITH_ERRORS = '5';
var STATUS_CR_INPROGRESS = '2';

var SPARAM_BACKLINKING_DATA = 'custscript_appf_so_back_linking_data';
var SPARAM_CC_LOG_EXEC_ID = 'custscript_appf_client_cred_log_rec_id';
var SPARAM_SO_IDS_BACKLINKED = 'custscript_appf_so_ids_back_linked';

function backliningSOsSC(type){
	
	var context = nlapiGetContext();
	var salesOrders = context.getSetting('SCRIPT', SPARAM_BACKLINKING_DATA);
	var customRecId = context.getSetting('SCRIPT', SPARAM_CC_LOG_EXEC_ID);
	
	var processedSOs = [];
	var soIdsBackLinked = context.getSetting('SCRIPT', SPARAM_SO_IDS_BACKLINKED);
	if(soIdsBackLinked != null && soIdsBackLinked != ''){
		soIdsBackLinked = soIdsBackLinked.split(',');
		processedSOs = processedSOs.concat(soIdsBackLinked);
	}
	if(salesOrders != null && salesOrders != '' && customRecId != null && customRecId != ''){
		salesOrders = JSON.parse(salesOrders);
		
		var totalSOs = 0;
		var totalSOsBacklinked = 0;
		for(var prop in salesOrders){
			totalSOs++;
		}
		for(var prop in salesOrders){
			try{
				if(processedSOs.indexOf(prop) == -1){
				
					var salesRec = nlapiLoadRecord('salesorder', prop);
					var logRecords = salesRec.getFieldValues(FLD_INV_LOG_RECORDS);
					var newLogRecords = [];
					newLogRecords.push(customRecId);
					if(logRecords != null && logRecords != '')
						newLogRecords = newLogRecords.concat(logRecords);
					
					salesRec.setFieldValue(FLD_INV_CREDIT_SL_STATUS, STATUS_INV_CREDIT_SL_READY_FOR_PROCESSING);
					salesRec.setFieldValues(FLD_INV_LOG_RECORDS, newLogRecords);
					var salesLineIds = salesOrders[prop];
					if(salesLineIds != null && salesLineIds != ''){
						for(var v=0; v<salesLineIds.length; v++){
							var lineNum = salesRec.findLineItemValue('item', FLD_SO_LINE_ID, salesLineIds[v]);
							if(lineNum != -1)
							salesRec.setLineItemValue('item', FLD_COL_INV_CREDIT_PROCESSING, lineNum, 'F');
						}
					}
					var updatedsalesRec = nlapiSubmitRecord(salesRec, true, true);
					if(updatedsalesRec != null && updatedsalesRec != ''){
						nlapiLogExecution('debug', 'updatedsalesRec', updatedsalesRec);
						processedSOs.push(updatedsalesRec);
					}
				}
					
				}catch(e1){
						if ( e1 instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'system error e1', e1.getCode() + '\n' + e1.getDetails() )
						else
							nlapiLogExecution( 'DEBUG', 'unexpected error e1', e1.toString() )
				}
				totalSOsBacklinked++;
				
				var backlinkedPercent = parseFloat(totalSOsBacklinked)/parseFloat(totalSOs);
				if(backlinkedPercent != null && backlinkedPercent != ''){
					backlinkedPercent = parseFloat(backlinkedPercent)*100;
					if(parseFloat(backlinkedPercent) == 100)
						STATUS_CR_INPROGRESS = STATUS_CR_COMPLETED_SUCCESSFULLY;
				
				}
				try{	
					nlapiSubmitField(CUSTOM_RECORD_CREDIT_CREATION_LOG, customRecId, [FLD_SO_BACKLINKING_PERCENT, FLD_SO_BACKLINKING_STATUS], [parseFloat(backlinkedPercent), STATUS_CR_INPROGRESS]);
				}catch(e){
						if ( e instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'system error e', e.getCode() + '\n' + e.getDetails() )
						else
							nlapiLogExecution( 'DEBUG', 'unexpected error e', e.toString() )
				}
				if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				
			
		}
			
		
	}
}




function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}