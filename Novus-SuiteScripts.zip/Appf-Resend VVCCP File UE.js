/**
 *@NApiVersion 2.0
 *@NScriptType UserEventScript
 */
 
 /*
* Script Name : Appf-Resend VVCCP File UE
* Script Type : User Event
* event type  : Before Load
* Deployment  : SFTP Log Record
* Description : This script displays button 'Resend' on SFTP Log record which [provides users with flexibility to resend file to sftp server
* Company     :	Appficiency Inc.
*/


var APPF_SFTP_SL_SCRIPT_ID='customscript_appf_vvccp_sftp_send_sl';
var APPF_SFTP_SL_DEPLOY_ID='customdeploy_appf_vvccp_sftp_send_sl';

var CUSTOM_RECORD_SFTP_LOGS = 'customrecord_appf_vvccp_sftp_logs';
var SPARAM_INDEX = 'custscript_sftp_file_index';
var SPARAM_FILE_ID = 'custscript_sftp_file_id';
var FLD_TYPE='custrecord_appf_vvccp_request_type';
var FLD_VVCCP_LINK_CARD='custrecord_appf_vvccp_card_provider_sftp';
var FLD_VVCCP_ERROR='custrecord_appf_vvccp_error_log';

define(['N/record','N/search','N/url','N/runtime'],
    function(record,search,url,runtime) 
	{	
        function sftpfile(context) 
		{
            if (context.type === context.UserEventType.VIEW)
			{
					var newRec= context.newRecord;
					
					var url1= url.resolveScript({scriptId: APPF_SFTP_SL_SCRIPT_ID,deploymentId: APPF_SFTP_SL_DEPLOY_ID,returnExternalUrl: false});
			
url1 +='&sftp='+newRec.id+'&istrigger='+'T';

           var sftpRec = record.load({type: newRec.type,  id: newRec.id,isDynamic: true});
                 var types = sftpRec.getValue({fieldId:'custrecord_appf_vvccp_request_type'});
				 if(types=='3')
				 {
				context.form.addButton({
    id : 'custpage_process_files',
    label : 'Resend',
	functionName:'window.open(\''+url1+'\',\'_self\');'
});
				 }
			}
		}
        return {
			
            beforeLoad: sftpfile
			
        };
    }); 