/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Catch-up script to trigger Fee calculation for:
 * - Sales Orders
 * - Invoices
 * - Credit Memos
 *
 * Author: Marlon
 * Date: Jun 10, 2021
 */
define(
    [
        'N/log',
        'N/record',
        'N/runtime',
        'N/search'
    ],
    
    function (
        LOG,
        RECORD,
        RUNTIME,
        SEARCH
    ) {
        var PARAM_SEARCH = 'custscript_appf_feecalc_ss';
        var PARAM_TYPE = 'custscript_appf_feecalc_type';
        
        function _getAllResults(srch) {
            var LOG_TITLE = '_getAllResults';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var ISPROD = true;
            var results = [], res = [];
            
            var ixSize = ISPROD == true ? 1000 : 5;
            var limit = ISPROD == true ? -1 : 8;
            var ixStart = 0, ixEnd = ixSize;
            var runAgain = true;
            
            LOG.debug({
                title: LOG_TITLE,
                details: 'ISPROD = ' + ISPROD +
                    ', ixSize = ' + ixSize +
                    ', limit = ' + limit
            });
            
            while(runAgain == true) {
                res = srch.run().getRange({ start: ixStart, end: ixEnd });
                
                results = results.concat(res);
                
                runAgain = (
                    (res.length < ixSize) ||
                    ((limit > 0) && (results.length >= limit))
                ) == true ? false : true;
                
                ixStart += ixSize;
                ixEnd += ixSize;
                LOG.debug({
                    title: LOG_TITLE,
                    details: 'results.length = ' + results.length +
                        ', res.length = ' + res.length +
                        ', runAgain = ' + runAgain
                });
            }
            
            LOG.debug({ title: LOG_TITLE, details: 'END' });
            return results;
        }
        
        function _getInputData() {
            var LOG_TITLE = '_getInputData';
            LOG.debug({ title: LOG_TITLE, details: '*** START ***' });
            
            var script = RUNTIME.getCurrentScript();
            var ss = script.getParameter({ name: PARAM_SEARCH });
            var output = [];
            
            if (ss) {
                output = _getAllResults(SEARCH.load({ id: ss }));
            }
            
            LOG.debug({ title: LOG_TITLE, details: '*** END ***' });
            return output;
        }
        
        function _reduce(ctx) {
            var LOG_TITLE = '_reduce';
            LOG.debug({ title: LOG_TITLE, details: '*** START ***' });
            
            var script = RUNTIME.getCurrentScript();
            var type = script.getParameter({ name: PARAM_TYPE });
            
            var val = JSON.parse(ctx.values[0]);
            LOG.debug({ title: LOG_TITLE, details: ctx.values[0] });
            
            try {
                var rec = RECORD.load({
                    type: type,
                    id: val.id
                });
                rec.save();
                LOG.debug({ title: LOG_TITLE, details: 'Successfully updated ' + type + ' ' + val.id });
            }
            catch (ex) {
                LOG.error({ title: LOG_TITLE, details: ex.toString() });
            }
            
            LOG.debug({ title: LOG_TITLE, details: '*** END ***' });
        }
        
        function _summarize(context) {
            var LOG_TITLE = '_summarize';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            LOG.audit({ title: LOG_TITLE, details: 'Done executing' });
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }
        
        return {
            getInputData: _getInputData,
            reduce: _reduce,
            summarize: _summarize
        }
    }
);
