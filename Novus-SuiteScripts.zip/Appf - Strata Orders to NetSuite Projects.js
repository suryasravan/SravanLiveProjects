/**
*Script Name: Appf - Strata Orders to NetSuite Project
*Script Type: Schedule Script
*Description: 
*Company 	: Appficiency Inc.
*/
 var FLD_COL_TTB_UPDATED_PROJECT='custcol_appf_ttb_update_project';
 var CUSTOMRECORD_APPF_IN_BOUND_STRATA_SPOT_PRO_RECS='customrecord_appf_strata_spo_project_in';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_MESSAGE ='custrecordappf_strata_messageid';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_CONTENT_LINK='custrecord_appf_strata_spot_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_QUEU_NAME ='custrecord_appf_strata_queuename';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_AZURE_RESPONSE='custrecord_appf_strata_response';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO='custrecord_strata_project_id';
 var CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_RESPONSE_STATUS='custrecord_response_strats_status';
 
function createStrataProScheduled(type) 
  {	
	
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
		    try
			   {
                 var Queue=true
                 while (Queue == true) {
				   var QueueName1='novusmedia_strata_project_in'
				   var d = new Date();
                 var UTCDate= d.toISOString();
var url = 'https://novusmediallc-dev.servicebus.windows.net/'+QueueName1+'/messages/head?api-version=2015-01';
var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey',"Date":UTCDate,"Content-Type": 'application/xml'};
var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
var mainObj = responseData.getBody();
                   if(responseData.getCode()=='204')
                     Queue=false
			   nlapiLogExecution('debug', 'responseData',  responseData.getCode())
                   if(responseData.getCode()!='204')
                     {
						  var responseDataAllHeaders=responseData.getAllHeaders()
                          var responseData3=responseDataAllHeaders[3]
                          var responseDataProp=responseData.getHeader(responseData3)
			              mainObj=JSON.parse(mainObj)
			if(!mainObj.hasOwnProperty('id'))
			{
				nlapiLogExecution('debug', 'hasOwnProperty',  'hasOwnProperty');
				 var payRec=nlapiCreateRecord('job')
				 for (var parentProp in mainObj)
    	             {
						 //nlapiLogExecution('debug', ' parentProp',  parentProp);
			            var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=payRec.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!='') && (parentProp2==null || parentProp2==''))
						 {
			                  payRec.setFieldValue(parentProp,mainObj[parentProp])	
						 }
		              }
		               var id=nlapiSubmitRecord(payRec,true,true)
					
					    var clientIn=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_STRATA_SPOT_PRO_RECS)
						  if(responseData.getCode()=='200')
							clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_RESPONSE_STATUS,'Success')
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_MESSAGE,responseDataProp)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_CONTENT_LINK,mainObj)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_QUEU_NAME,QueueName1)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_AZURE_RESPONSE,responseData.getCode())
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO,id)
					   nlapiSubmitRecord(clientIn,true,true)
				
			}
			else{
                var payRec='';
                 var internalId=mainObj['id']
				  nlapiLogExecution('debug', 'internalId',  internalId);
                  if(internalId==null || internalId=='')
                  payRec=nlapiCreateRecord('job')

                     else
                    payRec=nlapiLoadRecord('job',internalId)

                   nlapiLogExecution('debug', ' payRec',  payRec);
                    for (var parentProp in mainObj)
    	             {
						 //nlapiLogExecution('debug', ' parentProp',  parentProp);
			            var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=payRec.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!='') && (parentProp2==null || parentProp2==''))
						 {
			                  payRec.setFieldValue(parentProp,mainObj[parentProp])	
						 }
		              }
		               var id=nlapiSubmitRecord(payRec,true,true)
					
					    var clientIn=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_STRATA_SPOT_PRO_RECS)
						if(responseData.getCode()=='200')
							clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_RESPONSE_STATUS,'Success')
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_MESSAGE,responseDataProp)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_CONTENT_LINK,mainObj)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_QUEU_NAME,QueueName1)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO_AZURE_RESPONSE,responseData.getCode())
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_STRATA_SPOT_PRO,id)
					 nlapiSubmitRecord(clientIn,true,true)
			}
			
			if(id!=null && id!='')
			{
				
				var recordId=id;
	    var recordType='job';
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var mediaRec=nlapiLoadRecord(recordType,recordId)
		var mediaRecFields=mediaRec.getAllFields()
		var queName='novusmedia_strata_project_in_response'
		
			var main1={}
		for(var i=0;i<mediaRecFields.length;i++) 
       {
		     //var main={}
			var mediaRecId=mediaRecFields[i]
			var mediaRecValu=mediaRec.getFieldValue(mediaRecId)
			if(mediaRecValu==null)
		      mediaRecValu=''
		      main1[mediaRecId]=mediaRecValu
		} 
		
var url = 'https://novusmediallc-dev.servicebus.windows.net/'+queName+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'};
var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST')
				
			}
			
                     }
		  }
               }
		  catch(e)
		  {
		   nlapiLogExecution('debug', 'ERROR', e);
		  }
               
	}