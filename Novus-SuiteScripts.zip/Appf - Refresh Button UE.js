/*
* Script Name : Appf-Refresh Bill PO Lines Exec Log UE
* Script Type : UserEvent
* Event Type  : BeforeLoad
* Description : This script adds "Refresh" button on Bill PO LInes Execution Log Custom record, on click it updates the processing sttaus
* Company     :	Appficiency Inc.
*/

var BTN_REFRESH = 'custpage_refresh';
var FLD_BILL_PO_LINES_EXEC_LOG = 'custbody_appf_bill_po_lines_log';

var CUSTOM_RECORD_CUTOVER_FILE = 'customrecord_appf_cutover_payment_log';
var FLD_CSV_DATA_FILE = 'custrecord_appf_csv_data_file';
var FLD_NUM_OF_LINES_TO_PROCESS = 'custrecord_appf_cutover_total';
var FLD_NUM_OF_LINES_PROCESSED = 'custrecord_appf_cutover_processed';
var FLD_NUM_OF_LINES_FAILED = 'custrecord_appf_cutover_failed';
var FLD_PROCESSING_PERCENT = 'custrecord_appf_cutover_proc_percent';
var FLD_PAYMENTS = 'custrecord_appf_cutover_payment_links';
var FLD_LOG_ERRORS = 'custrecord_domed_ocean_error_log';

function userEventBeforeLoadRefresh(type, form, request)
{
	if(type == 'view')
	{
		var recId=nlapiGetRecordId();
		var recType=nlapiGetRecordType();
		var percent = nlapiGetFieldValue(FLD_PROCESSING_PERCENT);
              if (percent == null || percent == '')
					percent = 0;
				else
					percent = percent.replace('%','');
      
				percent = parseFloat(percent);
      
	                if(percent!=100)
					form.addButton(BTN_REFRESH, 'Refresh', 'location.reload();'); 

	}
}

