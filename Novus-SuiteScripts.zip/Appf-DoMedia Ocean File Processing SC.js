/*
*Script Name: Appf - Media Ocean DDS Script Sc
*Script Type: Scheduled
*Description: This script updates selected transaction lines with Upload to doMedia unchecked and sets the processing status on batch record
*Company 	: Appficiency Inc.

*/
var CUSTOM_RECORD_OCEAN_FILE = 'customrecord_appf_media_ocean_file_log';
var CUSTOM_FLD_ACD_STATUS = 'custrecord_appf_acd_status';
var CUSTOM_FLD_OCEN_CLIENT = 'custrecord_appf_media_ocean_client';
var CUSTOM_FLD_ESTIMATE = 'custrecord_dds_estimate';
var CUSTOM_FLD_FILE = 'custrecord_med_ocean_sl_data_file';
var FLD_DOMEDIA_OCEAN_LOG_CSV_DATA_FILE = 'custrecord_domed_ocean_csv_data';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_TO_PROCESS = 'custrecord_num_lines_selected';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED = 'custrecord_domed_ocean_processed';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED = 'custrecord_domed_ocean_failed';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT = 'custrecord_demed_ocean_processed_percent';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_STATUS = 'custrecord_ocean_file_proc_status';
var FLD_DOMEDIA_OCEAN_LOG_ERRORS = 'custrecord_domed_ocean_error_log';

var FLD_COL_MEDIA_OCEAN ='custcol_appf_mediaocean_upload'

var STATUS_INPROGRESS='2';
var STATUS_COMPLETED='4';
var STATUS_COMPLETED_ERRORS='5';

var SPARAM_INDEX = 'custscript_appf_domed_ocean_index';
var SPARAM_MEDIA_OCEN_ID='custscript_appf_media_ocean_id'
function SOScheduled(type) {
	var context = nlapiGetContext();
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if (index == null || index == '')
		index = 1;
	var recId = context.getSetting('SCRIPT', SPARAM_MEDIA_OCEN_ID);
	nlapiLogExecution('DEBUG', 'mediaOcenID',recId);	

		if(recId != null && recId != '')
		{
			var doMediaOceanFileRecord = nlapiLoadRecord(CUSTOM_RECORD_OCEAN_FILE, recId);
			var errorMsg=doMediaOceanFileRecord.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_ERRORS);
			if (errorMsg == null)
				errorMsg = '';
	          var fileid=doMediaOceanFileRecord.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_CSV_DATA_FILE);
			  var totalLines = doMediaOceanFileRecord.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_TO_PROCESS);
			   var processedCount=doMediaOceanFileRecord.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED);
			 if (processedCount == null || processedCount == '')
				 processedCount = 0;
	         var failedCount=doMediaOceanFileRecord.getFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED);
			 if (failedCount == null || failedCount == '')
				 failedCount = 0;
			  if(fileid!=null && fileid!='')
			  {
				  var csvfile=nlapiLoadFile(fileid)
				  var fileString=csvfile.getValue()
				  //nlapiLogExecution('DEBUG', 'fileString',fileString);
				 fileDataArr = fileString.split('\n');
	  //nlapiLogExecution('debug', 'num of lines', fileDataArr.length-1);
	 
		for(var d=index; d < fileDataArr.length; d++)
		{
			var data = fileDataArr[d].split(',');
			var soId = data[0];
			var soLineId = data[1];
			var appfLineId = data[2];
			try
			{
			
			
			var sorecord = nlapiLoadRecord('salesorder', soId);
			var solineNum=sorecord.findLineItemValue('item','line',soLineId)
			sorecord.setLineItemValue('item',FLD_COL_MEDIA_OCEAN,solineNum,'F')
			nlapiSubmitRecord(sorecord,true,true);
			processedCount++
		     }
			 catch(e) 
			         {
		                 if ( e instanceof nlobjError )
						 {
			          nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					  errorMsg = errorMsg + '----> Failed to submit SO line '+appfLineId+'. Reason: '+ e.getDetails() + '\n';
						 }
		               else
					   {
			         nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
                     errorMsg = errorMsg + '----> Failed to submit SO line '+appfLineId+'. Reason: '+ e.toString() + '\n';

					   }
				  
				        
						 failedCount++;
	                }
					var processedPercent = (parseInt(processedCount) + parseInt(failedCount)) / parseInt(totalLines);
					processedPercent = parseFloat(processedPercent) * 100;
					processedPercent = Number(processedPercent).toFixed(2);
					var statusToSet = STATUS_INPROGRESS;
					if (processedPercent == 100 && failedCount == 0)
					{
						statusToSet = STATUS_COMPLETED;
					}
					if (processedPercent == 100 && failedCount > 0)
					{
						statusToSet = STATUS_COMPLETED_ERRORS;
					}
				  nlapiSubmitField(CUSTOM_RECORD_OCEAN_FILE,recId,[FLD_DOMEDIA_OCEAN_LOG_PROCESSING_STATUS,FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED,FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED,FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT,FLD_DOMEDIA_OCEAN_LOG_ERRORS],[statusToSet,processedCount,failedCount,processedPercent,errorMsg])
				  
				  if (context.getRemainingUsage() <= 200 && (parseInt(d)+1) < fileDataArr.length)
				  {
					  
					  var params = {};
					  params[SPARAM_INDEX] = parseInt(d)+1;
					  params[SPARAM_MEDIA_OCEN_ID] = recId;
					  nlapiScheduleScript(context.getScriptId(), null, params);
					  break;
				  }
				  
			  }
			
		}
	}
	
	                     
			
}