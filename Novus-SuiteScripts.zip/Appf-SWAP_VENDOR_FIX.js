/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : This script handles all the validations required on a 'Pending Approval' sales order from saved search results and marks as Success, sets the contract and approves the order if all validations are successful
4/24/2020 v2 Sravan Added Additional validation of PWP check on line items
5/13/2020 v3 Sravan Added logic to set PO Vendor and PO Rate to chck if this resolves Item Options Error in integration
8/10/2020 v4 MJ De Asis added Logic to copy Start Date Actual to Start Date RR
9/02/2020 v5 All Order validations are moved to saved search, remove the logic in the script and only check needed fields
9/8/2020  v6 COnvert line level error validation into summary
10/21/2020 v7 Added Validation for OOH to include make Ship To field Mandatory
* Company     : Appficiency Inc.
*/
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_CONTRACT_MEDIA_TYPE = 'custrecord_appf_contract_mediatype';
var FLD_CONTRACT_END_DATE = 'custrecord_appf_contract_end_date';
var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_SO_ORDER_VALIDATION_STATUS = 'custbody_appf_orderval_status';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020
var FLD_VENDOR_LINE = 'custcol_appf_po_vendor_name';
var FLD_BILLING_SCHEDULE_LINE = 'billingschedule';
var SPARAM_MEDIA_SALES_ORDERS_SS = 'custscript_appf_updatevendor_savedsearch';
var SPARAM_SS_FILE_ID = 'custscript_appf_updatevendor_fileid';
var SPARAM_INDEX = 'custscript_appf_updatevendor_lineindex';
var SPARAM_SS_FILE_NAME = 'custscript_appf_updatevendor_filename';
var FOLDER_ID = '-15';
var FLD_CONTRACT_DEPT = 'custrecord_appf_contract_department';
var FLD_CONTRACT_LOB = 'custrecord_appf_contract_lineofbusiness';
var FLD_CONTRACT_POP_REQUIRED = 'custrecord_appf_contract_pop_required';
var FLD_COL_POP_REQUIRED = 'custcol_appf_print_poprequired';
var FLD_COL_CORP_OWNER = 'custcol_appf_corporateowner';
var FLD_COL_PWP = 'custcol_appf_pwp_custom_record';
var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var BUYING_SYSTEM_PRINT = '1';
var PLACEHOLDER = '1122';
//Include Custom Forms ['Novus - Sales Order (Non-Media)']
var INCLUDE_CUSTOM_FORMS = ['156', '143', '149', '123', '141'];

/// v7
var BUYING_SYSTEM_OOH = '2';
var FLD_COL_SHIPTO = 'shippingaddress';
var FLD_COL_SOLINEID = 'custcol_appf_line_id';
var ITEM_FLD_CANBEFULFILLED = 'isfulfillable';

function get_or_create_CSVFile(existingDataFile, mediaSOSS, filename) {
	var mediaSOSSObj = nlapiLoadSearch(null, mediaSOSS);
	var filters = mediaSOSSObj.getFilters();
	var columns = mediaSOSSObj.getColumns();
	var ssType = mediaSOSSObj.getSearchType();
	var mediaSOSSResults = getAllSearchResults(ssType, filters, columns);
	nlapiLogExecution('debug', 'mediaSOSSResults', mediaSOSSResults.length + ' filename= '+filename);
	var fileId = null;
	if (existingDataFile == null || existingDataFile == '') {
		if (mediaSOSSResults != null && mediaSOSSResults != '') {
			//var mediaSOSSResultsData = 'Record ID, Client ID, Client Name, Date, Buying System, Buying System Name\n';
			var mediaSOSSResultsData = 'Record ID\n'; //v5 added 9/2/2020
			for (var s = 0; s < mediaSOSSResults.length; s++) {
				var col = mediaSOSSResults[s];
				var recType = 'salesorder';
				var getColumns = col.getAllColumns();
				var recId = col.getValue(getColumns[0]);
				/*var client = col.getValue('entity');
				var clientName = col.getText('entity');
				if (clientName != null && clientName != '') clientName = clientName.replace(/,/g, ';');
				var date = col.getValue('trandate');
				var buyingSys = col.getValue(FLD_SO_BUYING_SYSTEM);
				var buyingSysName = col.getText(FLD_SO_BUYING_SYSTEM);
				var propReq = col.getValue(FLD_CONTRACT_POP_REQUIRED, FLD_SO_CLIENT_CONTRACT); //v5 added 9/2/2020
				if (buyingSysName != null && buyingSysName != '') buyingSysName = buyingSysName.replace(/,/g, ';');
				//mediaSOSSResultsData += recId +','+client+','+clientName+','+date+','+buyingSys+','+buyingSysName+'\n';*/
				//mediaSOSSResultsData += recId + ',' + client + ',' + clientName + ',' + date + ',' + buyingSys + ',' + buyingSysName + ',' + propReq + '\n'; //v5 added 9/2/2020
				mediaSOSSResultsData += recId +'\n'; //v5 added 9/2/2020

			}
			nlapiLogExecution('debug', 'mediaSOSSResultsData', mediaSOSSResultsData);
			var ssResultsFile = nlapiCreateFile(filename, 'CSV', mediaSOSSResultsData);
			ssResultsFile.setFolder(FOLDER_ID);
			fileId = nlapiSubmitFile(ssResultsFile);
			nlapiLogExecution('debug', 'fileId', fileId);
		}
	} else {
		fileId = existingDataFile;
	}
	return fileId;
}

function paddedString(string_to_pad, number_to_pad) {
	var padded_string = string_to_pad + ''; // convert to string
	while (padded_string.length < number_to_pad) {
		padded_string = '0' + padded_string;
	}
	return padded_string;
}

function getVendorId(entity_name) {
	var rs = nlapiSearchRecord('vendor', null,
				[
					new nlobjSearchFilter('entityid', null, 'is', entity_name)
				], []) || [];
	if (rs.length > 0) {
		return rs[0].getId();
	}
	return null;
}

function setVendorPlaceholder(so_id) {
	var salesOrderRec = nlapiLoadRecord('salesorder', so_id, {recordmode: 'dynamic'});
	var customForm = salesOrderRec.getFieldValue('customform');
	var subsidiary = salesOrderRec.getFieldValue('subsidiary') == '7' ? 'CA':'US';
	// Check if form selected is in the script params
	//salesOrderRec.setFieldValue('orderstatus', 'A');
	
	try {
		var itemCount = salesOrderRec.getLineItemCount('item');
		for (var k = 1; k<= itemCount; k++) {
			var nQty = salesOrderRec.getLineItemValue('item', 'quantity', k);
			var fakeVendor = 'Placeholder' + subsidiary + ' ' + paddedString(k, 4);
			nlapiLogExecution('DEBUG', 'Placeholder Vendor Name', fakeVendor);
			var fakeVendorId = getVendorId(fakeVendor);
			nlapiLogExecution('DEBUG', 'Placeholder Vendor Id', fakeVendorId);

			var existingcreatepo = salesOrderRec.getLineItemValue('item', 'createpo', k);
			var existingpo = salesOrderRec.getLineItemValue('item', 'poid', k);
			nlapiLogExecution('DEBUG', 'PO ID', existingpo + ' nQty='+nQty);

			if (existingpo == null || existingpo == '' ) {
				if(parseInt(nQty) == 0 || nQty == 0 || nQty == '0'){
					salesOrderRec.selectLineItem('item', k);
					salesOrderRec.setCurrentLineItemValue('item', 'povendor', fakeVendorId);
					salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
					salesOrderRec.setCurrentLineItemValue('item', 'createpo', '');
					salesOrderRec.commitLineItem('item');
				}else{
					salesOrderRec.selectLineItem('item', k);
					salesOrderRec.setCurrentLineItemValue('item', 'povendor', fakeVendorId);
					salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
					salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
					salesOrderRec.commitLineItem('item');
				}

			}
		}
		nlapiSubmitRecord(salesOrderRec, true, true);
	}
	catch (err) {
		nlapiLogExecution('debug', 'Failed to set PO Vendor', err);
	}
}

function setPOVendorcheduled(type) {
	var context = nlapiGetContext();
	var mediaSOSS = context.getSetting('SCRIPT', SPARAM_MEDIA_SALES_ORDERS_SS);
	var existingDataFile = context.getSetting('SCRIPT', SPARAM_SS_FILE_ID);
	var fileName = context.getSetting('SCRIPT', SPARAM_SS_FILE_NAME);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if (index == null || index == '') index = 1;
	nlapiLogExecution('debug', 'file index', 'index=' + index+ 'mediaSOSS='+mediaSOSS);
	var fileId = null;
	if (mediaSOSS != null && mediaSOSS != '') {
		fileId = get_or_create_CSVFile(existingDataFile, mediaSOSS, fileName);
		nlapiLogExecution('debug', 'fileId', fileId);
		if (fileId != null && fileId != '') {
			var fileObj = nlapiLoadFile(fileId);
			var fileData = fileObj.getValue().split('\n');
			nlapiLogExecution('debug', 'fileObj', fileObj.getValue());
			nlapiLogExecution('debug', 'fileData', fileData);
			var allDataProcessed = true;
			if (fileData != null && fileData != '') {
				for (var f = index; f < (fileData.length - 1); f++) {
					var validationStatus = '';
					var line = fileData[f].split(',');
					var recId = line[0];
					/*var client = line[1];
					var clientName = line[2];
					var date = line[3];
					var buyingSys = line[4];
					var buyingSysName = line[5];
					var popRequired = line[6]; //v5 added 9/2/2020*/
					nlapiLogExecution('DEBUG', 'Sales Order Id', recId);

					

					if (context.getRemainingUsage() <= 2000 && (f + 1) < (fileData.length - 1)) {
						allDataProcessed = false;
						var params = {};
						params[SPARAM_MEDIA_SALES_ORDERS_SS] = mediaSOSS;
						params[SPARAM_SS_FILE_ID] = fileId;
						params[SPARAM_INDEX] = (f + 1);
						nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
						break;
					}else{
						setVendorPlaceholder(recId);
					}
				}
			}
			if (allDataProcessed) {
				nlapiDeleteFile(fileId);
			}
		}
	}
}

function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);
	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];
	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}

function isNullOrEmpty(data) {
	return (data == null || data == '');
}