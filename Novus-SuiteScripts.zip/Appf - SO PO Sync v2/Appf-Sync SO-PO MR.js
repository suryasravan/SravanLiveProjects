/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Sync SO & PO
 *
 * Author: Marlon
 * Date: Dec 22, 2020
 * Version: 1.0
 *
 * Author: MJ De Asis
 * Date: Jan 4, 2021
 * Version 1.1
 */

define(
    [
        'N/file',
        'N/log',
        'N/record',
        'N/runtime',
        'N/search'
    ],

    function(
        FILE,
        LOG,
        RECORD,
        RUNTIME,
        SEARCH
    ) {
        var SPARAM_SYNC_SEARCH = 'customsearch_appf_domedia_sopo_sync';

        var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
        var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

        var TOTAL_FORMS = 6;
        var SCRIPT_SCHEDULE = 'customscript_appf_sync_so_po_sc';
        var SPARAM_SO_ID = 'custscript_appf_so_id';
        var FLD_SYNC_SO_PO_STATUS = 'custbody_sync_sopo_status';
        var FLD_SYNC_SO_PO_ERROR = 'custbody_sync_so_po_error';
        var STATUS_SYNC_SO_PO = {'IN_PROGRESS':1,'SYNC_SUCCESS':2,'SYNC_FAILED':3};

        var FLD_SYNC_SO_PO_TRIGGER = 'custbody_appf_ssync_so_po_trigger';
		//added by shravan kumar 14-03-2023
var CUST_FLD_PROCESS_COMPLETED = 'custbody_appf_close_process_completed';

        function searchMoreRecords(recordType, searchID, filters, columns)
    	{
    		if(searchID != null){
    			var searchObj = SEARCH.load({
    				id: searchID
    			});
    		}else{
    			var searchObj = SEARCH.create({
    				id: searchID,
    				type: recordType,
    				filters: filters,
    				columns: columns
    			});
    		}

    		var resultSet = searchObj.run();
    		var results = [];
    		var start = 0;
    		var end = 1000;
    		do{
    			var result = resultSet.getRange(start,end);
    			results = results.concat(result);
    			start += 1000;
    			end += 1000;

    		}while(result.length == 1000);

            var resultsObject = [];
            var columns = searchObj.columns;

            var prev_id = null;
            for (var index in results) {
                var result = results[index];
                var soId = result.getValue(columns[0]);
                var poId = result.getValue(columns[1]);
                var vendorName = result.getValue(columns[2]);
                var soLineId = result.getValue(columns[3]);
                var formId = result.getValue(columns[4]);

                resultsObject.push({
                    so_id: soId,
                    po_id: poId,
                    form_id: formId,
                    vendor_id: vendorName,
                    line_id: soLineId
                });
            }

    		return resultsObject;
    	}

        function _getInputData() {
            var LOG_TITLE = '_getInputData';
            LOG.debug({ title: LOG_TITLE, details: 'START' });

            var script = RUNTIME.getCurrentScript();
            var srchId = script.getParameter({ name: 'custscript_so_po_sync_srch' });
            var results = [];

            if (srchId) {
                var srch = SEARCH.load({ id: srchId });

                // For testing, limit results to 1
                // var results = srch.run().getRange({ start: 0, end: 1 });
                results = searchMoreRecords(null, srchId, null, null);

                log.debug('Results', JSON.stringify(results));
                log.audit({ title: LOG_TITLE, details: 'Results = ' + results.length });
            }

            LOG.debug({ title: LOG_TITLE, details: 'END' });

            return results;
        }

        function _map(context) {
            var LOG_TITLE = '_map';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        function _reduce(context) {
            var LOG_TITLE = '_reduce';
            LOG.debug({ title: LOG_TITLE, details: 'START' });

            var script = RUNTIME.getCurrentScript();

            var rowObj = JSON.parse(context.values[0]);
            log.debug('Row', JSON.stringify(rowObj));

            var soRec = RECORD.load({
                type: RECORD.Type.SALES_ORDER,
                id: rowObj.so_id
            });
            
            var paramFields = '';
            for (var i=1; i<=TOTAL_FORMS; i++) {
                var paramForm = script.getParameter({name: 'custscript_appf_form_'+i+'_id'});
                if (paramForm == rowObj.form_id) {
                    paramFields = script.getParameter({name: 'custscript_appf_form_'+i+'_fields'});
                }
            }

            var errMsg = '';
            var soLineVend = rowObj.vendor_id;
            //log.debug('soLineVend', soLineVend);
            try {
                var poRec = RECORD.load({
                    type: RECORD.Type.PURCHASE_ORDER,
                    id: rowObj.po_id
                });
                var poVendor = poRec.getValue({
                    fieldId: 'entity'
                });
				
				var process = poRec.getValue( {fieldId: CUST_FLD_PROCESS_COMPLETED});
				if (process == true)
					process = 'T';
				
								log.debug('process', process );
								//added by shravan kumar 14-03-2023
						if (process != 'T') {
				
                if (poVendor != rowObj.vendor_id)
                    poRec.setValue({
                        fieldId: 'entity',
                        value: soLineVend
                    });
                var soLine = rowObj.line_id;
                if (soLine != null && soLine != '') {
                    //if (paramFields != null && paramFields != '') {
                        var fields = [];
                        fields = fields.concat(paramFields.split(','));

                        var poLineNumber = poRec.findSublistLineWithValue({
                            sublistId: 'item',
                            fieldId: FLD_COL_SO_LINE_ID,
                            value: soLine
                        });
                        //log.debug('PO Line Number', poLineNumber);

                        var soLineNumber = soRec.findSublistLineWithValue({
                            sublistId: 'item',
                            fieldId: FLD_COL_SO_LINE_ID,
                            value: soLine
                        });
                        //log.debug('SO Line Number', soLineNumber);

                        if (poLineNumber >= 0) {
                            //log.debug('Fields', JSON.stringify(fields));
                            for (var f=0; f<fields.length; f++) {
                                if (fields[f] == '') {
                                    break;
                                }
                                var fldValue = soRec.getSublistValue({
                                    sublistId: 'item',
                                    fieldId: fields[f],
                                    line: soLineNumber
                                });
                                poRec.setSublistValue({
                                    sublistId: 'item',
                                    fieldId: fields[f],
                                    line: poLineNumber,
                                    value: fldValue
                                });
                            }

                            var qtySoLine = soRec.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: soLineNumber
                            });
                            poRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_appf_po_current_client_gross',
                                line: poLineNumber,
                                value: qtySoLine
                            });

                            var vendorAllocSoLine = soRec.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'custcol_appf_vendor_allocation_amount',
                                line: soLineNumber
                            });
                            poRec.setSublistValue({
                                sublistId: 'item',
                                fieldId: 'quantity',
                                line: poLineNumber,
                                value: vendorAllocSoLine
                            });
                        }
                    //}
                }
				
								
                poRec.save({
                    enableSourcing: true,
                    ignoreMandatoryFields: true
                });
                log.audit({ title: LOG_TITLE, details: 'PO Saved = ' + rowObj.po_id + ', SO = ' + rowObj.so_id });
						}
            }
            catch (e) {
                if ( e instanceof nlobjError )
                {
                    log.debug('system error', e.getCode() + '\n' + e.getDetails());
                    errMsg += 'Sync with PO Internal ID: ' + rowObj.po_id + ' failed. Reason: '+e.getDetails() + '\n';
                }
                else
                {
                    log.debug('unexpected error', e.toString());
                    errMsg += 'Sync with PO Internal ID: ' + rowObj.po_id + ' failed. Reason: '+e.toString() + '\n';
                }
            }

            context.write({
	            so_id: rowObj.so_id,
	            po_id: rowObj.po_id,
                error_message: errMsg,
                success: errMsg == ''
	        });

            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        function _summarize(context) {
            var LOG_TITLE = '_summarize';
            LOG.debug({ title: LOG_TITLE, details: 'START' });

            context.reduceSummary.errors.iterator().each(function(key, value) {
        		log.debug('reduceSummary Error', key + ' : ' + value);
        		return true;
        	});

            var so_ids = {};
            context.output.iterator().each(function (key, value) {
                //log.debug('Key', key);
                //log.debug('Value', value);

                var keyObj = JSON.parse(key);
                so_ids[keyObj.so_id] = keyObj;

                return true;
            });
            log.debug('SO Ids', JSON.stringify(so_ids));


            for (var index in so_ids) {
                var obj = so_ids[index];

                var soValues = {};

                var soRec = RECORD.load({
                    type: RECORD.Type.SALES_ORDER,
                    id: obj.so_id
                });

                if (!obj.success)
                {
                    soValues[FLD_SYNC_SO_PO_STATUS] = STATUS_SYNC_SO_PO.SYNC_FAILED;
                    soValues[FLD_SYNC_SO_PO_ERROR] = obj.error_message;
                }
                else
                {
                    soValues[FLD_SYNC_SO_PO_STATUS] = STATUS_SYNC_SO_PO.SYNC_SUCCESS;
                    soValues[FLD_SYNC_SO_PO_ERROR] = '';
                }

                soValues[FLD_SYNC_SO_PO_TRIGGER] = true;

                RECORD.submitFields({
                    type: RECORD.Type.SALES_ORDER,
                    id: obj.so_id,
                    values: soValues,
                    options: {
                        enableSourcing: true,
                        ignoreMandatoryFields: true
                    }
                });

                log.audit({ title: LOG_TITLE, details: 'SO Updated = ' + obj.so_id });
            }

            LOG.audit({ title: LOG_TITLE, details: 'Done executing' });
            LOG.debug({ title: LOG_TITLE, details: 'END' });
        }

        return {
            getInputData: _getInputData,
            reduce: _reduce,
            /** map: _map **/
            summarize: _summarize
        };
    }
);
