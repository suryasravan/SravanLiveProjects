/*
* Script Name : Appf-Payment Application from Inv Lines SL
* Script Type : Suitelet
* Description : This script will display a UI page of Payment application through Invoice line items, It will be triggered from button 'Apply Payment' on Payment record
* Company     : Appficeincy Inc.
* 
**/

var PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING = 1;
var PAYMENT_APPLICATION_SUITELET_STATUS_PROCESSED = 2;
var PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING = 3;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS = 2;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY = 4;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS = 5;
var PAYMENT_APPLICATION_CSV_FOLDER_ID = 953;
var SPARAM_PAYMENT_APPLICATION_SAVED_SEARCH = 'custscript_client_payment_application';
var TITLE_CLIENT_PAYMENT_APPLICATION = 'Client Payment Application';
var FLD_PAYMENT_APPLICATION_LOG_LINKS = 'custbody_appf_pmt_appl_log_rec_links';

var FLD_CREDITS_APPLIED = 'custbody_appf_credits_applied';

var CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG = 'customrecord_appf_cust_pmt_app_log';
var FLD_TOT_CHILD_INVCS_TO_PROCESS = 'custrecord_appf_cst_pmt_total_inv';
var FLD_TOT_CHILD_INVCS_PROCESSED = 'custrecord_appf_cst_pmt_inv_completed';
var FLD_TOT_CHILD_INVCS_LINE_TO_PROCESS = 'custrecord_appf_cst_pmt_lines_to_process';
var FLD_CHILD_INVCS_PROCESS_PERCENTAGE = 'custrecord_appf_cst_pmt_perc_processed';
var FLD_CUSTOMER_PAYMENT_APPLICATION_FILE = 'custrecord_appf_cst_pmt_data_file';
var FLD_CUSTOMER_PAYMENT_APPLICATION_FILE_CM = 'custrecord_appf_cst_pmt_data_file_cm';
var FLD_CUSTOMER_PAYMENT_APPLICATION_CREATED_BY = 'custrecord_appf_cst_pmt_created_by';
var FLD_CUSTOMER_PAYMENT_APPLICATION_LINK = 'custrecord_appf_cst_pmt_link';
var FLD_CUSTOMER_PAYMENT_STATUS = 'custrecord_appf_cst_pmt_status';
var FLD_CUSTOMER_PAYMENT_APPLICATION_CLIENT = 'custrecord_appf_cst_pmt_client';
var FLD_CUSTOMER_PAYMENT_APPLICATION_CURRENCY = 'custrecord_appf_cst_pmt_currency';
var FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING = 'custrecord_appf_trans_to_under_process';
var FLD_TOTAL_UNDER_PROCESSING_STATUS = 'custrecord_appf_trans_under_process_stat';
var FLD_TOTAL_UNDER_PROCESSED = 'custrecord_appf_trans_under_processed';
var FLD_TOTAL_UNDER_PROCESSING_FAILED = 'custrecord_appf_trans_failed_under_proce';
var FLD_TOTAL_UNDER_PROCESSING_PENDING = 'custrecord_appf_trans_under_process_pend';
var FLD_TOTAL_UNDER_PROCESSING_PERCENT = 'custrecord_appf_trans_under_process_perc';
var FLD_TRANSACTION_INTERNAL_IDS = 'custrecord_appf_tran_internal_ids';
var FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_tot_linked_trans_to_proc';


var FLD_SL_PAYMENT_CURRENCY = 'custpage_paymet_currency';
var FLD_TOTAL_INVOICES_SELECTED = 'custrecord_appf_cst_pmt_invoice_link';

var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_tot_credits_to_process';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_tot_credits_processed';
var FLD_CREDITS_STATUS_FILE = 'custrecord_appf_credit_proc_file';

var SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION = 'customscript_update_client_paymt_applns';
var SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION_1 = 'customscript_appf_update_client_paym_sc1';
var DEPLOY_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION_1 = 'customdeploy_appf_update_client_paym_sc1';
//var SPARAM_PAYMENT_APPLICATION_INVC_CSV_FOLDER_ID=;
var VALIDATION_SCCRIPT_ID = 'customscript_payment_application_validat';
var SPARAM_CLIENT_PAYMENT_APPLICATION_SEARCH = 'custscript_client_payment_application_search';
var SPARAM_RANDOM_TEXT = 'custscript_random_text';
var SPARAM_SELECTED_INVOICE_LIST = 'custscript_selected_invoice_list';
var SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID = 'custscript_payment_application_log_id';
var SPARAM_PAYMENT_APPLICATION_FILE_ID = 'custscript_payment_under_process_file_id';
//var SPARAM_PAYMENT_APPLICATION_FILE_ID = 'custscript_payment_under_process_file_1';
//var SPARAM_PAYMENT_APPLICATION_FILE_ID_CM = 'custscript_pay_under_process_file_id_cm';
var SPARAM_PAYMENT_APPLICATION_FILE_ID_CM = 'custscript_pay_under_process_file_id_1';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID = 'custscript_payment_processed_file_id';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM = 'custscript_payment_processed_cm_file';
var SPARAM_PAYMENT_NEED_TO_UPDATE = 'custscript_payment_need_to_process';
var SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS = 'custscript_total_invoice_to_process';
var SPARAM_INVOICE_DETAIL_OBJ_FORM = 'custscript_invoice_detail_obj';
var SPARAM_CREDIT_DETAIL_OBJ_FORM = 'custscript_credit_detail_obj';
var SPARAM_TRANS_UNDER_PROCESSING = 'custscript_appf_trans_to_under_process';
var SPARAM_PAGE_SIZE = 'custscript_pmt_app_page_size';
var SPARAM_TOTAL_UNAPPLIED_INVOICES = 'custscript_pmt_app_inv_count';
var SPARAM_TOTAL_UNAPPLIED_CREDITS = 'custscript_pmt_app_cred_count';

var SPARAM_PAYMENT_APPLICATION_INV_FILE = 'custscript_pay_appl_inv_file';
var SPARAM_PAYMENT_APPLICATION_CM_FILE = 'custscript_pay_appl_cm_file';
var SPARAM_DATA_FOR_PAYMENT = 'custscript_data_for_payment';
var FLD_GROUP = 'custpage_filter';
var FLD_SL_ACTION = 'custpage_action';
var FLD_SL_CONSOLIDATED_INVOICE_NUMBER = 'custpage_consolidated_invoice';
var FLD_SL_MEDIA_TYPE = 'custpage_media_type';
var FLD_SL_INVOICE_LINE_PROJECT = 'custpage_invoice_line_project';
var FLD_SL_CM_LINE_PROJECT = 'custpage_cm_line_project';
var FLD_SL_TRAN_DATE_FROM = 'custpage_tran_date_from';
var FLD_SL_TRAN_DATE_TO = 'custpage_tran_date_to';
var FLD_SL_CM_TRAN_DATE_FROM = 'custpage_tran_date_from_cm';
var FLD_SL_CM_TRAN_DATE_TO = 'custpage_tran_date_to_cm';
var FLD_SL_INVOICE_LINE_IO = 'custpage_invoice_line_io';
var FLD_SL_CM_LINE_IO = 'custpage_cm_line_io';
var FLD_SL_VENDOR = 'custpage_invoice_line_vendor';
var FLD_SL_INVOICE_LINE_MEDIA_SUPPLIER = 'custpage_invoice_line_media_supplier';
var FLD_SL_CHILED_CLIENTS_CM = 'custpage_child_clients_cm';
var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_TRANSACTION_NUMBER = 'custpage_paymet_transaction_number';
var FLD_SL_AVAILABLE_AMOUNT = 'custpage_paymet_available_amount';
var FLD_SL_PAYMENT_AMOUNT = 'custpage_paymet_amount';
var FLD_SL_APPLIED_AMOUNT = 'custpage_applied_amount';
var FLD_SL_SRCH_TRACKER = 'custpage_srch_tracker';
var FLD_SL_TOTAL_SELECTED_LINES = 'custpage_total_selected_lines';
var FLD_SL_PAYMENT_LINK = 'custpage_payment_link';

var COL_SL_INVOICE_SUBLIST = 'custpage_invoices';
var COL_SL_CREDIT_SUBLIST = 'custpage_creditsublist';

var COL_SL_INVOICE_SUBLIST_APPLIED = 'custpage_invoices_applied';
var COL_SL_CREDIT_SUBLIST_APPLIED = 'custpage_creditsublist_appled';

var COL_SL_INVOICE_ID = 'custpage_invoice_internalid';
var COL_SL_INVOICE_LINES = 'custpage_invoice_line_checkbox';
var COL_SL_CONSOLIDATE_INVOICE_NUMBER = 'custpage_consolidate_invoice_number';
var COL_SL_CONSOLIDATE_INVOICE_CLIENT = 'custpage_consolidate_invoice_client';
var COL_SL_NATIVE_INVOICE_CLIENT = 'custpage_invoice_client';
var COL_SL_NATIVE_INVOICE = 'custpage_invoice';
var COL_SL_NATIVE_INVOICE_LINE_ID = 'custpage_custcol_appf_invoice_line_id';
var COL_SL_PAYMENT_RECORD_ID = 'custpage_payment_record_id';
var COL_SL_NATIVE_INVOICE_LINE_IO = 'custpage_invoice_line_level_io';
var COL_SL_NATIVE_INVOICE_SALES_ORDER_ID = 'custpage_sales_order_id';
var COL_SL_NATIVE_INVOICE_SALES_LINE_ID = 'custpage_sales_order_line_id';
var COL_SL_NATIVE_INVOICE_LINE_VENDOR = 'custpage_invoice_line_level_vendor';
var COL_SL_NATIVE_INVOICE_LINE_MEDIA_SUPPLIER = 'custpage_invoice_line_level_media_supplier';
var COL_SL_NATIVE_INVOICE_LINE_CURRENCY = 'custpage_invoice_line_level_currency';
var COL_SL_NATIVE_INVOICE_LINE_AMOUNT = 'custpage_invoice_line_level_amount';
var COL_SL_NATIVE_INVOICE_LINE_AMOUNT_DUE = 'custpage_invoice_line_level_amount_due';
var COL_SL_NATIVE_INVOICE_PAYMENT_AMOUNT = 'custpage_invoice_line_level_payment_amount';
var COL_APPF_PO_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var COL_APPF_PUBLISHER = 'custcol_appf_publisher';
var COL_AAPF_IO = 'custcol_appf_ionum';
var COL_SL_INVOICE_ILINE_ITEM = 'custpage_invoice_item';
var COL_SL_INVOICE_LINE_ID = 'custpage_line';
var COL_SL_INV_PAYMT_APPLICATION_LOG_RECORDS_INV = 'custpage_inv_custbody_appf_pmt_appl_log_rec_links';
var COL_SL_INV_PAYMT_APPLICATION_LOG_RECORDS_CM = 'custpage_cm_custbody_appf_pmt_appl_log_rec_links';

var COL_SL_NATIVE_INVOICE_LINE_AMT_MINUS_PAYMENT_AMT = 'custcol_line_amt_minus_payment';
var BTN_SL_MARKALL_BUTTON = 'custpage_marke_all';
var BTN_SL_UN_MARKALL = 'custpage_un_marke_all';
var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';

var FLD_SL_PAYMENT_CURRENCY = 'custpage_paymet_currency';
var FLD_SL_CONSOLIDATED_INVOICE_NUMBER = 'custpage_consolidated_invoice';
var FLD_SL_MEDIA_TYPE = 'custpage_media_type';
var FLD_SL_INVOICE_LINE_PROJECT = 'custpage_invoice_line_project';
var FLD_SL_INVOICE_LINE_IO = 'custpage_invoice_line_io';
var FLD_SL_VENDOR = 'custpage_invoice_line_vendor';
var FLD_SL_INVOICE_LINE_MEDIA_SUPPLIER = 'custpage_invoice_line_media_supplier';
var FLD_SL_CHILD_CLIENTS = 'custpage_clients';
var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_TRANSACTION_NUMBER = 'custpage_paymet_transaction_number';
var FLD_SL_PAYMENT_AMOUNT = 'custpage_paymet_amount';
var COL_SL_SUBLIST = 'custpage_invoices';
var SL_FLD_CONSOLIDATED_INVOICE = 'custpage_consolidated_invoices';
var COL_SL_INVOICE_MARK = 'custpage_checkbox_invoices';
var BTN_INVOICE_MARK_ALL = 'custpage_invoice_mark_all';
var BTN_INVOICE_UNMARK_ALL = 'custpage_invoice_unmark_all';
// added by shravan kumar 12-10-2022
var FLD_SL_EXCLUDE_CONSOL = 'custpage_exclude_from_consolidation';
//added by shravan kumar 12-10-2022
var FLD_SL_EXCLUDE_CONSOL_CM = 'custpage_exclude_from_consolidation_cm';
var CUST_COL_EXCLUDE_CONSOL = 'custcol_appf_ci_exclude_tran';
var CUST_COL_EXCLUDE_CONSOL_CM = 'custbody_nsts_ci_exclude';
// Sublist Buttons
var BTN_INVOICE_PREV_PAGE = 'custpage_invoice_prev_page';
var BTN_INVOICE_NEXT_PAGE = 'custpage_invoice_next_page';
var BTN_CREDIT_PREV_PAGE = 'custpage_credit_prev_page';
var BTN_CREDIT_NEXT_PAGE = 'custpage_credit_next_page';

var COL_SL_INVOICE_INTERNAL_ID = 'custpage_invoiceid';
var COL_SL_CREDIT_SUBLIST = 'custpage_creditsublist';
var COL_SL_CREDIT_SUBLIST_FLD_MARK = 'custpage_checkbox_credit';
var BTN_CREDIT_MARK_ALL = 'custpage_invoice_mark_all';
var BTN_CREDIT_UNMARK_ALL = 'custpage_invoice_unmark_all';
var COL_SL_CREDIT_INTERNAL_ID = 'custpage_creditid';

var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
var FLD_COL_INV_CI_RECORD = 'custcol_appf_ci_record';
var SL_TITLE = 'Client Payment Application SL';
var COL_SL_INVOICE_SUBLIST = 'custpage_invoices';
var FLD_GROUP_PAYMENT_DETAILS = 'custpage_payment_details';
var FLD_GROUP_CREDIT_FILTER = 'custpage_credit_filters';
var FLD_GROUP_INVOICE_FILTER = 'custpage_invoice_filters';
var FLD_GROUP_SUMMARY = 'custpage_summary';
var SL_FLD_CLIENT_INV = 'custpage_client_inv';
var SL_FLD_CLIENT_CM = 'custpage_client_cm';
var SL_FLD_AR_ACCOUNT = 'custpage_ar_account';
var SL_FLD_CURRENCY = 'custpage_currency';
var SL_FLD_DATE = 'custpage_date';
var SL_FLD_POSTING_PERIOD = 'custpage_posting_period';
var SL_FLD_MEMO = 'custpage_demo';
var SL_FLD_LINE_OF_BUSINESS = 'custpage_line_of_business';
var SL_FLD_DEPARTMENT = 'custpage_department';
var SL_FLD_OFFICE = 'custpage_office';
var VALIDATION_SCCRIPT_ID = 'customscript_payment_application_validat';
var SPARAM_CLIENT_INVOICE_SS = 'custscript_client_payment_application';
var SPARAM_CLIENT_CREDIT_SS = 'custscript_credit_line_pymt_application';
var SPARAM_CLIENT_INVOICE_SS_2 = 'custscriptcustscript_client_payment_ss2';
var SPARAM_CLIENT_CREDIT_SS_2 = 'custscript_credit_line_pymt_ss2';
var SPARAM_TRANS_UNDER_PROCESSING_SS = 'custscript_appf_pym_appl_under_process';
var COL_SL_PAYMENT_AMOUNT = 'custpage_invoice_line_payment_amount';
var COL_SL_LINE_FROM_PAYMENT = 'custpage_line_from_payment';
var COL_SL_CREDIT_AMOUNT = 'custpage_credit_amount';
var COL_SL_CLIENT = 'custpage_line_client';
//var CUSTOM_RECORD_PAYMENT_APPLICATION_EXEC_LOG='';

var SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION = 'customscript_update_client_paymt_applns';

var CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION = 'customrecord_appf_pay_app_linked_trans';
var FLD_PALT_PAYMENT_TRANSACTION_LINK = 'custrecord_appf_pay_app_pmt_link';
var FLD_PALT_TRANSACTION_LINK = 'custrecord_appf_pay_app_tran_link';
var FLD_PALT_TRANSACTION_LINE_ID = 'custrecord_appf_pay_app_tran_lineid';
var FLD_PALT_TRANSACTION_LINE_AMOUNT = 'custrecord_appf_pay_app_tran_line_amt';
var FLD_PALT_TRANSACTION_LINE_AMOUNT_TAX = 'custrecord_appf_pay_app_tax'
var FLD_PALT_TRANSACTION_LINE_PWP = 'custrecord_appf_pay_app_line_pwp';
var FLD_PALT_TRANSACTION_LINE_TAX = 'custrecord_appf_pay_app_tax';
var SRCH_SUMMARY = {};
// var SRCH_TYPE = '';
var SRCH_INDEX = {};


//added by shravan kumar 08-06-2023
var SPARAM_CI_RECORDS_SEARCH = 'custscript_appf_ss_ci_record';

function suitelet ( request, response ) {
	var sAction = request.getParameter( FLD_SL_ACTION );
	var client = request.getParameter( SL_FLD_CLIENT_INV );
	var arAccount = request.getParameter( SL_FLD_AR_ACCOUNT );
	var currency = request.getParameter( SL_FLD_CURRENCY );
	var date = request.getParameter( SL_FLD_DATE );
	var postingPeriod = request.getParameter( SL_FLD_POSTING_PERIOD );
	var memo = request.getParameter( SL_FLD_MEMO );
	var lineOfBusiness = request.getParameter( SL_FLD_LINE_OF_BUSINESS );
	var department = request.getParameter( SL_FLD_DEPARTMENT );
	var office = request.getParameter( SL_FLD_OFFICE );

	nlapiLogExecution( 'debug', 'action', sAction );
	if ( !sAction ) {
		var frm = suiteletform( request );
		nlapiLogExecution( 'DEBUG', 'Usage', nlapiGetContext().getRemainingUsage() );
		response.writePage( frm );
	}
	else if ( sAction == 'submit' ) {
		var customRecId = processSelectedinvoices( request, client, arAccount, currency, date, postingPeriod, memo, lineOfBusiness, department, office );
		nlapiLogExecution( 'DEBUG', 'customRecId:', customRecId );
		response.sendRedirect( 'RECORD', CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecId );
	}

}

function suiteletform ( request ) {
	try {

		//added by shravan kumar 14-03-2023
		var ciRecords_Array = [];

		var consolidateInvArr = [];
		var paymentLinkDefValue = request.getParameter( 'recId' );

		var unapplied = null;
		var dateFromPayment = '';
		var postingPeriodFromPayment = '';
		var memoFromPayment = '';
		var lineOfBusinessFromPayment = '';
		var departmentFromPayment = '';
		var officeFromPayment = '';

		var paymentApplLinkedTranInvObj = {};
		var paymentApplLinkedTranCMObj = {};

		var srchType = request.getParameter( 'srchType' );

		//if SL triggred from Payment

		if ( paymentLinkDefValue ) {
			var record = nlapiLoadRecord( 'customerpayment', paymentLinkDefValue );
			unapplied = record.getFieldValue( 'payment' );
			dateFromPayment = record.getFieldValue( 'trandate' );
			postingPeriodFromPayment = record.getFieldValue( 'postingperiod' );
			memoFromPayment = record.getFieldValue( 'memo' );
			lineOfBusinessFromPayment = record.getFieldValue( 'class' );
			departmentFromPayment = record.getFieldValue( 'department' );
			officeFromPayment = record.getFieldValue( 'location' );
			if ( unapplied == null || unapplied == '' )
				unapplied = 0;
			//search on Linked Transaction custom records for that payment
			var paltFilters = [];
			paltFilters.push( new nlobjSearchFilter( 'isinactive', null, 'is', 'F' ) );
			paltFilters.push( new nlobjSearchFilter( FLD_PALT_PAYMENT_TRANSACTION_LINK, null, 'anyof', paymentLinkDefValue ) );

			var paltColumns = [];
			paltColumns.push( new nlobjSearchColumn( FLD_PALT_TRANSACTION_LINK ) );
			paltColumns.push( new nlobjSearchColumn( FLD_PALT_TRANSACTION_LINE_ID ) );
			paltColumns.push( new nlobjSearchColumn( FLD_PALT_TRANSACTION_LINE_AMOUNT ) );
			paltColumns.push( new nlobjSearchColumn( FLD_PALT_TRANSACTION_LINE_PWP ) );
			paltColumns.push( new nlobjSearchColumn( FLD_PALT_TRANSACTION_LINE_AMOUNT_TAX ) );


			var paltResults = getAllSearchResults( CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paltFilters, paltColumns );
			if ( paltResults != null && paltResults != '' ) {
				for ( var p = 0; p < paltResults.length; p++ ) {
					var col = paltResults[ p ];
					var paltId = col.getId();
					var transId = col.getValue( FLD_PALT_TRANSACTION_LINK );
					var transLineId = col.getValue( FLD_PALT_TRANSACTION_LINE_ID );
					var transLinePWP = col.getValue( FLD_PALT_TRANSACTION_LINE_PWP );
					var transLineAmt = col.getValue( FLD_PALT_TRANSACTION_LINE_AMOUNT );
					if ( transLineAmt == null || transLineAmt == '' )
						transLineAmt = 0;
					var transLineAmtTax = col.getValue( FLD_PALT_TRANSACTION_LINE_AMOUNT_TAX );
					if ( transLineAmtTax == null || transLineAmtTax == '' )
						transLineAmtTax = 0;
					//grouping Linked Transactions based on trnsactions (INV & CM)
					if ( transLineId != null && transLineId != '' ) {
						if ( !paymentApplLinkedTranInvObj.hasOwnProperty( transLineId ) ) {
							paymentApplLinkedTranInvObj[ transLineId ] = {};
							paymentApplLinkedTranInvObj[ transLineId ].paltId = paltId;
							paymentApplLinkedTranInvObj[ transLineId ].transId = transId;
							paymentApplLinkedTranInvObj[ transLineId ].transLineAmt = transLineAmt;
							paymentApplLinkedTranInvObj[ transLineId ].transLineAmtTax = transLineAmtTax;

							paymentApplLinkedTranInvObj[ transLineId ].transLinePWP = transLinePWP;
						}
					}
					else {
						if ( !paymentApplLinkedTranCMObj.hasOwnProperty( transId ) ) {
							paymentApplLinkedTranCMObj[ transId ] = {};
							paymentApplLinkedTranCMObj[ transId ].paltIds = [];
							paymentApplLinkedTranCMObj[ transId ].paltIds.push( paltId );
							paymentApplLinkedTranCMObj[ transId ].transLineAmt = transLineAmt;
							//paymentApplLinkedTranInvObj[transLineId].transLineAmtTax = transLineAmtTax;
						}
						else {
							paymentApplLinkedTranCMObj[ transId ].paltIds.push( paltId );
							var existing = paymentApplLinkedTranCMObj[ transId ].transLineAmt;
							existing = parseFloat( existing ) + parseFloat( transLineAmt );
							paymentApplLinkedTranCMObj[ transId ].transLineAmt = existing;

							//var existingtax = paymentApplLinkedTranCMObj[transId].transLineAmtTax;
							//existingtax = parseFloat(existingtax)+parseFloat(transLineAmtTax);
							//paymentApplLinkedTranCMObj[transId].transLineAmtTax = existingtax;
						}
					}

				}
			}
		}
		//nlapiLogExecution('debug', 'paymentApplLinkedTranInvObj', JSON.stringify(paymentApplLinkedTranInvObj));
		//nlapiLogExecution('debug', 'paymentApplLinkedTranCMObj', JSON.stringify(paymentApplLinkedTranCMObj));		 
		var parentClient = request.getParameter( 'parentClient' );


		var payment = request.getParameter( 'payment' );
		var availableAmount = request.getParameter( 'availableAmount' );
		var appliedAmount = request.getParameter( 'appliedAmount' );
		var transactionNumber = request.getParameter( 'transactionid' );
		var mediaType = request.getParameter( 'mediaType' );
		var invoiceLineMediaSupplier = request.getParameter( 'invoiceLineMediaSupplier' );
		var invoiceLineVendor = request.getParameter( 'invoiceLineVendor' );
		var mediaSupplier = request.getParameter( 'mediaSupplier' );

		var filtersectionClient = request.getParameter( 'filtersectionClient' );
		var filtersectionClientArr = [];
		if ( filtersectionClient != null && filtersectionClient != '' ) {
			filtersectionClientArr = filtersectionClientArr.concat( filtersectionClient.split( '|' ) );
		}
		var filtersectionClientCM = request.getParameter( 'filtersectionClientCM' );
		var filtersectionClientCMArr = [];
		if ( filtersectionClientCM != null && filtersectionClientCM != '' ) {
			filtersectionClientCMArr = filtersectionClientCMArr.concat( filtersectionClientCM.split( '|' ) );
		}

		var invoiceTranDateFrom = request.getParameter( 'invoiceTranDateFrom' );
		var invoiceTranDateTo = request.getParameter( 'invoiceTranDateTo' );
		var invoiceLineIo = request.getParameter( 'invoiceLineIo' );
		var invoiceLineProject = request.getParameter( 'invoiceLineProject' );
		var consolidateInv = request.getParameter( 'consolidateInv' );
		if ( consolidateInv != null && consolidateInv != '' ) {
			consolidateInvArr = consolidateInvArr.concat( consolidateInv.split( '|' ) );
		}
		var clientPD = request.getParameter( 'clientPD' );
		var clientPDCM = clientPD;//request.getParameter('clientPDCM');

		//added by shravan kumar 12-10-2022
		var excludeCon = request.getParameter( 'excludeCon' );
		var excludeConCM = request.getParameter( 'excludeConCM' );



		// nlapiLogExecution('debug', 'clientPDCM', clientPDCM);
		var creditTranDateFrom = request.getParameter( 'creditTranDateFrom' );
		var creditTranDateTo = request.getParameter( 'creditTranDateTo' );
		var creditLineIo = request.getParameter( 'creditLineIo' );
		var creditLineProject = request.getParameter( 'creditLineProject' );

		// Paging parameters...
		// index=invoice:0|transaction:0|invoice__applied:0|transaction__applied:0
		var srchIndex = request.getParameter( 'srchIndex' ) || 'invoice:0|transaction:0|invoice__applied:0|creditmemo__applied:0';
		var srchIndexArr = srchIndex.split( '|' );
		for ( var i = 0, n = srchIndexArr.length; i < n; i++ ) {
			var keys = srchIndexArr[ i ].split( ':' );
			SRCH_INDEX[ keys[ 0 ] ] = keys[ 1 ];
		}

		// SRCH_TYPE = request.getParameter('srchType');
		// SRCH_INDEX = request.getParameter('srchIndex') || 0;


		var context = nlapiGetContext();
		var savedSearchId = context.getSetting( 'SCRIPT', SPARAM_PAYMENT_APPLICATION_SAVED_SEARCH );
		var invoiceSSID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_INVOICE_SS );
		var invoiceCountSSID = context.getSetting( 'SCRIPT', SPARAM_TOTAL_UNAPPLIED_INVOICES );
		var creditSSID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_CREDIT_SS );
		var creditCountSSID = context.getSetting( 'SCRIPT', SPARAM_TOTAL_UNAPPLIED_CREDITS );
		var invoiceSSID2 = context.getSetting( 'SCRIPT', SPARAM_CLIENT_INVOICE_SS_2 );
		var creditSSID2 = context.getSetting( 'SCRIPT', SPARAM_CLIENT_CREDIT_SS_2 );
		var transUnderProcessingSSID = context.getSetting( 'SCRIPT', SPARAM_TRANS_UNDER_PROCESSING_SS );
		SRCH_SUMMARY.pageSize = context.getSetting( 'SCRIPT', SPARAM_PAGE_SIZE );
		if ( !SRCH_SUMMARY.pageSize ) {
			SRCH_SUMMARY.pageSize = 2000;
		}


		//added by shravan kumar 08-06-2023
		var ciRecordSSID = context.getSetting( 'SCRIPT', SPARAM_CI_RECORDS_SEARCH );
		var ciRecordsSS = nlapiLoadSearch( null, ciRecordSSID );
		var ciRecordFils = ciRecordsSS.getFilters();
		var ciRecordCols = ciRecordsSS.getColumns();
		var ciRecordType = ciRecordsSS.getSearchType();

		var ciFils = [];
		if ( clientPD ) {
			ciFils.push( new nlobjSearchFilter( 'customersubof', null, 'anyof', clientPD ) );
		}
		ciFils = ciFils.concat( ciRecordFils )


		var loadInvoiceSS = nlapiLoadSearch( null, invoiceSSID );
		var invoicefilts1 = loadInvoiceSS.getFilters();
		var invoicecolumns = loadInvoiceSS.getColumns();
		var invoiceSSType = loadInvoiceSS.getSearchType();
		SRCH_SUMMARY[ invoiceSSType ] = {
			index: SRCH_INDEX[ invoiceSSType ] || 0,
			more: false
		};

		var loadInvoiceCountSS = nlapiLoadSearch( null, invoiceCountSSID );
		var invoiceCountFil = loadInvoiceCountSS.getFilters();
		var invoiceCountCol = loadInvoiceCountSS.getColumns();
		var invoiceCountSSType = loadInvoiceCountSS.getSearchType();

		var loadCreditSS = nlapiLoadSearch( null, creditSSID );
		var creditfilts = loadCreditSS.getFilters();
		var creditcolumns = loadCreditSS.getColumns();
		var creditSSType = loadCreditSS.getSearchType();
		SRCH_SUMMARY[ creditSSType ] = {
			index: SRCH_INDEX[ creditSSType ] || 0,
			more: false
		};

		var loadCreditCountSS = nlapiLoadSearch( null, creditCountSSID );
		var creditCountFil = loadCreditCountSS.getFilters();
		var creditCountCol = loadCreditCountSS.getColumns();
		var creditCountSSType = loadCreditCountSS.getSearchType();

		var loadInvoiceSS2 = nlapiLoadSearch( null, invoiceSSID2 );
		var invoicefilts2 = loadInvoiceSS2.getFilters();
		var invoicecolumns2 = loadInvoiceSS2.getColumns();
		var invoiceSSType2 = loadInvoiceSS2.getSearchType() + '__applied';
		/* SRCH_SUMMARY[invoiceSSType2] = {
		    index: SRCH_INDEX[invoiceSSType2] || 0,
		    more: false
		}; */

		var loadCreditSS2 = nlapiLoadSearch( null, creditSSID2 );
		var creditfilts2 = loadCreditSS2.getFilters();
		var creditcolumns2 = loadCreditSS2.getColumns();
		var creditSSType2 = loadCreditSS2.getSearchType() + '__applied';
		/* SRCH_SUMMARY[creditSSType2] = {
		    index: SRCH_INDEX[creditSSType2] || 0,
		    more: false
		}; */

		var transUnderProcessingSS = nlapiLoadSearch( null, transUnderProcessingSSID );
		var transUPFils = transUnderProcessingSS.getFilters();
		var transUPCols = transUnderProcessingSS.getColumns();
		var transUPType = transUnderProcessingSS.getSearchType();

		var transUPsearchResults = getAllSearchResults( transUPType, transUPFils, transUPCols );
		var underProcessingTransList = [];
		if ( transUPsearchResults != null && transUPsearchResults != '' && transUPsearchResults.length > 0 ) {
			for ( var g = 0; g < transUPsearchResults.length; g++ ) {
				var tranresult = transUPsearchResults[ g ];
				var transIds = tranresult.getValue( FLD_TRANSACTION_INTERNAL_IDS );
				if ( transIds != null && transIds != '' ) {
					underProcessingTransList = underProcessingTransList.concat( transIds.split( ',' ) );
				}
			}
		}
		if ( underProcessingTransList != null && underProcessingTransList != '' )
			underProcessingTransList = eliminateDuplicates( underProcessingTransList );

		nlapiLogExecution( 'debug', 'underProcessingTransList', underProcessingTransList + '' );

		var form = nlapiCreateForm( TITLE_CLIENT_PAYMENT_APPLICATION );
		form.setScript( VALIDATION_SCCRIPT_ID );
		var PaymentDetailsGroup = form.addFieldGroup( FLD_GROUP_PAYMENT_DETAILS, 'Payment Details:' );
		var InvoiceFiltersGroup = form.addFieldGroup( FLD_GROUP_INVOICE_FILTER, 'Invoice Filters:' );
		var CreditMemoFiltersGroup = form.addFieldGroup( FLD_GROUP_CREDIT_FILTER, 'Credit Memo Filters:' );
		var SummaryFiltersGroup = form.addFieldGroup( FLD_GROUP_SUMMARY, 'Summary:' );

		var paymentLinkField = form.addField( FLD_SL_PAYMENT_LINK, 'select', 'Payment Link', 'transaction', FLD_GROUP_PAYMENT_DETAILS );
		paymentLinkField.setDisplayType( 'inline' );
		if ( paymentLinkDefValue )
			paymentLinkField.setDefaultValue( paymentLinkDefValue );

		var fldAction = form.addField( FLD_SL_ACTION, 'text', '', null, FLD_GROUP_PAYMENT_DETAILS );
		fldAction.setDisplayType( 'hidden' );
		fldAction.setDefaultValue( 'submit' );
		var aRAccount = form.addField( SL_FLD_AR_ACCOUNT, 'select', 'AR Account', 'account', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			aRAccount.setDisplayType( 'disabled' );
		else
			aRAccount.setDisplayType( 'normal' );
		var currency = form.addField( SL_FLD_CURRENCY, 'select', 'Currency', 'currency', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			currency.setDisplayType( 'disabled' );
		else
			currency.setDisplayType( 'normal' );
		var date = form.addField( SL_FLD_DATE, 'date', 'Date', null, FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			date.setDefaultValue( dateFromPayment );
		var postingPeriod = form.addField( SL_FLD_POSTING_PERIOD, 'select', 'Posting Period', 'accountingperiod', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			postingPeriod.setDefaultValue( postingPeriodFromPayment );
		var memo = form.addField( SL_FLD_MEMO, 'text', 'Memo', null, FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			memo.setDefaultValue( memoFromPayment );
		var LineOfBusiness = form.addField( SL_FLD_LINE_OF_BUSINESS, 'select', 'Line Of Business', 'classification', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			LineOfBusiness.setDefaultValue( lineOfBusinessFromPayment );
		var department = form.addField( SL_FLD_DEPARTMENT, 'select', 'Department', 'department', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			department.setDefaultValue( departmentFromPayment );
		var office = form.addField( SL_FLD_OFFICE, 'select', 'Office', 'location', FLD_GROUP_PAYMENT_DETAILS );
		if ( paymentLinkDefValue )
			office.setDefaultValue( officeFromPayment );



		var clientFieldPDInv = form.addField( SL_FLD_CLIENT_INV, 'select', 'Client (Invoice)', 'customer', FLD_GROUP_INVOICE_FILTER );
		clientFieldPDInv.setMandatory( true );
		clientFieldPDInv.setDefaultValue( clientPD );
		if ( paymentLinkDefValue )
			clientFieldPDInv.setDisplayType( 'disabled' );
		else
			clientFieldPDInv.setDisplayType( 'normal' );


		var consolidatedInvFld = form.addField( SL_FLD_CONSOLIDATED_INVOICE, 'multiselect', 'Consolidated Invoice #', null, FLD_GROUP_INVOICE_FILTER );
		consolidatedInvFld.addSelectOption( '', '' );

		var invoiceLineProjects = form.addField( FLD_SL_INVOICE_LINE_PROJECT, 'select', 'Project (Invoice)', 'job', FLD_GROUP_INVOICE_FILTER );
		var tranDateFrom = form.addField( FLD_SL_TRAN_DATE_FROM, 'date', 'ServiceDate - From (Invoice)', null, FLD_GROUP_INVOICE_FILTER );
		var tranDateTo = form.addField( FLD_SL_TRAN_DATE_TO, 'date', 'ServiceDate - To (Invoice)', null, FLD_GROUP_INVOICE_FILTER );
		var invoiceLineIONumber = form.addField( FLD_SL_INVOICE_LINE_IO, 'text', 'IO # (Invoice)', null, FLD_GROUP_INVOICE_FILTER );
		var clientInFilter = form.addField( FLD_SL_CHILD_CLIENTS, 'multiselect', 'Clients (Invoice)', null, FLD_GROUP_INVOICE_FILTER );

		//added by shravan kumar 12-10-2022
		var consolidationInFilter = form.addField( FLD_SL_EXCLUDE_CONSOL, 'checkbox', 'Exclude from Consolidation', null, FLD_GROUP_INVOICE_FILTER );
		var excludeConsolidationFils = [];
		if ( excludeCon == 'T' ) {
			consolidationInFilter.setDefaultValue( 'T' );
			excludeConsolidationFils.push( new nlobjSearchFilter( CUST_COL_EXCLUDE_CONSOL, null, 'is', true ) );
		}


		if ( invoiceTranDateFrom != null && invoiceTranDateFrom != '' ) {
			tranDateFrom.setDefaultValue( invoiceTranDateFrom );
		}
		if ( invoiceTranDateTo != null && invoiceTranDateTo != '' ) {
			tranDateTo.setDefaultValue( invoiceTranDateTo );
		}
		if ( invoiceLineIo != null && invoiceLineIo != '' ) {
			invoiceLineIONumber.setDefaultValue( invoiceLineIo );
		}
		if ( invoiceLineProject != null && invoiceLineProject != '' ) {
			invoiceLineProjects.setDefaultValue( invoiceLineProject );
		}

		var clientFieldPDCM = form.addField( SL_FLD_CLIENT_CM, 'select', 'Client (Credit Memo)', 'customer', FLD_GROUP_CREDIT_FILTER );
		clientFieldPDCM.setDefaultValue( clientPDCM );
		clientFieldPDCM.setDisplayType( 'disabled' );
		var creditLineProjects = form.addField( FLD_SL_CM_LINE_PROJECT, 'select', 'Project (Credit Memo)', 'job', FLD_GROUP_CREDIT_FILTER );
		var credittranDateFromFld = form.addField( FLD_SL_CM_TRAN_DATE_FROM, 'date', 'ServiceDate - From (Credit Memo)', null, FLD_GROUP_CREDIT_FILTER );
		var credittranDateToFld = form.addField( FLD_SL_CM_TRAN_DATE_TO, 'date', 'ServiceDate - To (Credit Memo)', null, FLD_GROUP_CREDIT_FILTER );
		var creditLineIONumberFld = form.addField( FLD_SL_CM_LINE_IO, 'text', 'IO #  (Credit Memo)', null, FLD_GROUP_CREDIT_FILTER );
		var clientCreditFilter = form.addField( FLD_SL_CHILED_CLIENTS_CM, 'multiselect', 'Clients  (Credit Memo)', null, FLD_GROUP_CREDIT_FILTER );
		creditLineProjects.setDisplayType( 'hidden' );
		credittranDateFromFld.setDisplayType( 'hidden' );
		credittranDateToFld.setDisplayType( 'hidden' );
		creditLineIONumberFld.setDisplayType( 'hidden' );

		//added by shravan kumar 12-10-2022
		var consolidationInFilter_CM = form.addField( FLD_SL_EXCLUDE_CONSOL_CM, 'checkbox', 'Exclude from Consolidation', null, FLD_GROUP_CREDIT_FILTER );
		var excludeConsolidationFils_CM = [];
		if ( excludeConCM == 'T' ) {
			consolidationInFilter_CM.setDefaultValue( 'T' );
			excludeConsolidationFils_CM.push( new nlobjSearchFilter( CUST_COL_EXCLUDE_CONSOL_CM, null, 'is', true ) );
		}


		/*if(creditTranDateFrom != null && creditTranDateFrom != ''){
			credittranDateFromFld.setDefaultValue(creditTranDateFrom);
		}
		if(creditTranDateTo != null && creditTranDateTo != ''){
			credittranDateToFld.setDefaultValue(creditTranDateTo);
		}
		if(creditLineIo != null && creditLineIo != ''){
			creditLineIONumberFld.setDefaultValue(creditLineIo);
		}
		if(creditLineProject != null && creditLineProject != ''){
			creditLineProjects.setDefaultValue(creditLineProject);
		}*/

		if ( clientPD != null && clientPD != '' ) {

			var accountingInfo = nlapiLoadConfiguration( 'accountingpreferences' );
			var arAccountFromAccountingPreference = accountingInfo.getFieldValue( 'ARACCOUNT' );

			var customerRec = nlapiLoadRecord( 'customer', clientPD )
			var arAccountOfClient = customerRec.getFieldValue( 'receivablesaccount' );
			var currencyFromClient = customerRec.getFieldValue( 'currency' );
			if ( currencyFromClient != null && currencyFromClient != '' ) {
				currency.setDefaultValue( currencyFromClient );
			}
			nlapiLogExecution( 'debug', 'arAccountOfClient:', arAccountOfClient );
			if ( arAccountOfClient == -10 )
				arAccountOfClient = arAccountFromAccountingPreference;

			if ( arAccountOfClient != null && arAccountOfClient != '' ) {

				aRAccount.setDefaultValue( arAccountOfClient );
			}

			//setting Client related body fields in SL
			var clientSearchResults = getAllSearchResults( 'customer', [ new nlobjSearchFilter( 'parent', null, 'anyof', clientPD ), new nlobjSearchFilter( 'isinactive', null, 'is', 'F' ) ], [ new nlobjSearchColumn( 'entityid' ), new nlobjSearchColumn( 'companyname' ) ] );

			var clientsInitial = [];
			//var clientsFinal = [];
			if ( clientSearchResults != null && clientSearchResults != '' && filtersectionClientArr.length == 0 ) {
				for ( var x = 0; x < clientSearchResults.length; x++ ) {
					var result = clientSearchResults[ x ];
					var selected = true;
					clientInFilter.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
					clientsInitial.push( result.getId() );
				}
			}
			if ( clientSearchResults != null && clientSearchResults != '' && filtersectionClientArr.length > 0 ) {
				for ( var x = 0; x < clientSearchResults.length; x++ ) {
					var result = clientSearchResults[ x ];
					var selected = false;
					if ( filtersectionClientArr.indexOf( result.getId() ) != -1 )
						selected = true;
					clientInFilter.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
					clientsInitial.push( result.getId() );

				}
			}

			/*if ( clientsInitial.length > 0 ) {
				var tranSearchResults = getAllSearchResults( 'customrecord_appf_ci_record', [ new nlobjSearchFilter( 'custrecord_appf_ci_client', null, 'anyof', clientsInitial ), new nlobjSearchFilter( 'custrecord_appf_ci_fully_settled', null, 'is', 'F' ) ], [ new nlobjSearchColumn( 'name' ) ] );
				if ( tranSearchResults != null && tranSearchResults != '' ) {
					for ( var x = 0; x < tranSearchResults.length; x++ ) {
						var result = tranSearchResults[ x ];
						var selected = false;
						if ( consolidateInvArr.indexOf( result.getId() ) != -1 )
							selected = true;
						//consolidatedInvFld.addSelectOption( result.getId(), result.getValue( 'name' ), selected );
					}
				}
			}*/
		}


		if ( clientPDCM != null && clientPDCM != '' ) {

			//setting Client related body fields in SL
			var clientSearchResultsCM = getAllSearchResults( 'customer', [ new nlobjSearchFilter( 'parent', null, 'anyof', clientPDCM ), new nlobjSearchFilter( 'isinactive', null, 'is', 'F' ) ], [ new nlobjSearchColumn( 'entityid' ), new nlobjSearchColumn( 'companyname' ) ] );

			//var clientsInitial = [];
			//var clientsFinal = [];
			if ( clientSearchResultsCM != null && clientSearchResultsCM != '' && filtersectionClientCMArr.length == 0 ) {
				for ( var x = 0; x < clientSearchResultsCM.length; x++ ) {
					var result = clientSearchResultsCM[ x ];
					var selected = true;
					//if(filtersectionClientCMArr.indexOf(result.getId()) != -1)
					//selected = true;
					clientCreditFilter.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
					//clientsInitial.push(result.getId());
				}
			}
			if ( clientSearchResultsCM != null && clientSearchResultsCM != '' && filtersectionClientCMArr.length > 0 ) {
				for ( var x = 0; x < clientSearchResultsCM.length; x++ ) {
					var result = clientSearchResultsCM[ x ];
					var selected = false;
					if ( filtersectionClientCMArr.indexOf( result.getId() ) != -1 )
						selected = true;
					clientCreditFilter.addSelectOption( result.getId(), result.getValue( 'entityid' ) + ' ' + result.getValue( 'companyname' ), selected );
					//clientsInitial.push(result.getId());

				}
			}
		}

		nlapiLogExecution( 'debug', 'unapplied', unapplied );
		//nlapiLogExecution('debug', 'filtersectionClientCMArr', JSON.stringify(filtersectionClientCMArr));
		var availableAmt = form.addField( FLD_SL_AVAILABLE_AMOUNT, 'currency', 'Available Amount', null, FLD_GROUP_SUMMARY );
		availableAmt.setMandatory( true );
		if ( paymentLinkDefValue ) {
			availableAmt.setDisplayType( 'disabled' );
			availableAmt.setDefaultValue( unapplied );
		}
		else {
			availableAmt.setDisplayType( 'entry' );

		}

		nlapiLogExecution( 'debug', 'HERE>>>>>>>', '' );
		var appliedAmt = form.addField( FLD_SL_APPLIED_AMOUNT, 'currency', 'Applied Amount', null, FLD_GROUP_SUMMARY );
		appliedAmt.setDisplayType( 'disabled' );
		form.addButton( BTN_SL_APPLY_FILTERS, 'Apply Filters', 'applyFilters();' );

		// // Insert field for results sublist tracking
		// var fldSublistTracker=form.addField(FLD_SL_SRCH_TRACKER,'inlinehtml','Sublists',null,FLD_GROUP_SUMMARY).setDisplayType('normal');
		// fldSublistTracker.setDefaultValue(JSON.stringify(SRCH_SUMMARY));


		//if (clientPD != null && clientPD != '' && filtersectionClient != null && filtersectionClient != '')
		//{
		//Unapplied Invoice Lines Sublist
		var invoiceSublist = form.addSubList( COL_SL_INVOICE_SUBLIST, 'list', 'Unapplied Invoice Lines' );
		invoiceSublist.addField( COL_SL_INVOICE_MARK, 'checkbox', 'Select' );
		invoiceSublist.addButton( BTN_INVOICE_MARK_ALL, 'Mark All', 'invoicemarkAll();' );
		invoiceSublist.addButton( BTN_INVOICE_UNMARK_ALL, 'Unmark All', 'invoiceunmarkAll();' );
		nlapiLogExecution( 'debug', 'HERE>>>>>>>', '' );

		var colArrInvoice = [];
		var colIndexInvoice = 1;
		var scriptfieldcounterInvoice = 1;
		for ( var i = 0; i < invoicecolumns.length; i++ ) {
			var colObj = invoicecolumns[ i ];
			var colName = colObj.getName();
			var colLabel = colObj.getLabel();
			if ( colArrInvoice.indexOf( colName ) == -1 ) {
				colArrInvoice.push( colName )
			}
			else {
				colName = colName + colIndexInvoice;
				colIndexInvoice++;
			}
			if ( colLabel != 'Script Use DNR' ) {
				invoiceSublist.addField( 'custpage_' + colName, 'text', colLabel );

			}
			else {
				var typeofscriptfield = 'text';
				if ( scriptfieldcounterInvoice == 2 || scriptfieldcounterInvoice == 1 || scriptfieldcounterInvoice == 9 )
					typeofscriptfield = 'currency';

				if ( scriptfieldcounterInvoice == 11 )
					var scriptField = invoiceSublist.addField( 'custpage_scriptfield_pwp', typeofscriptfield, colLabel );
				else
					var scriptField = invoiceSublist.addField( 'custpage_scriptfield' + scriptfieldcounterInvoice, typeofscriptfield, colLabel );

				if ( scriptfieldcounterInvoice == 11 )
					scriptField.setDisplayType( 'hidden' );
				else
					scriptField.setDisplayType( 'hidden' );



				scriptfieldcounterInvoice++;
			}
		}

		nlapiLogExecution( 'debug', 'HERE>>>>>>>', '' );
		var hiddenLineFromPayInv = invoiceSublist.addField( COL_SL_LINE_FROM_PAYMENT, 'text', 'From Payment Application' );
		hiddenLineFromPayInv.setDisplayType( 'hidden' );
		hiddenLineFromPayInv.setDefaultValue( '' );
		invoiceSublist.addField( COL_SL_PAYMENT_AMOUNT, 'currency', 'Payment Amount' ).setDisplayType( 'entry' );
		invoiceSublist.addField( COL_SL_PAYMENT_AMOUNT + '_native', 'currency', 'Payment Amount Hidden' ).setDisplayType( 'hidden' );
		invoiceSublist.addField( COL_SL_PAYMENT_AMOUNT + '_tax', 'currency', 'Payment Tax Amount' ).setDisplayType( 'entry' );
		invoiceSublist.addField( COL_SL_INVOICE_INTERNAL_ID, 'integer', 'Invoice ID' ).setDisplayType( 'hidden' );

		nlapiLogExecution( 'debug', 'clientsInitial', clientsInitial );
		if ( filtersectionClient == '' || filtersectionClient == null || filtersectionClient == undefined ) {
			filtersectionClient = clientsInitial.join( '|' );
			filtersectionClientArr = clientsInitial;

			filtersectionClientCM = clientsInitial.join( '|' );
			filtersectionClientCMArr = clientsInitial;
		}

		if ( clientPD != null && clientPD != '' && filtersectionClient != null && filtersectionClient != '' ) {
			//invoiceSublist.addField(COL_SL_CLIENT, 'text', 'Client').setDisplayType('hidden');
			var invoicefilters = [];
			if ( consolidateInv != null && consolidateInv != '' )
				invoicefilters.push( new nlobjSearchFilter( FLD_COL_INV_CI_RECORD, null, 'anyof', consolidateInvArr ) );
			if ( filtersectionClient != null && filtersectionClient != '' )
				invoicefilters.push( new nlobjSearchFilter( 'entity', null, 'anyof', filtersectionClientArr ) );
			if ( invoiceLineProject != null && invoiceLineProject != '' )
				invoicefilters.push( new nlobjSearchFilter( 'internalid', 'job', 'anyof', invoiceLineProject ) );
			if ( invoiceTranDateFrom != null && invoiceTranDateFrom != '' && invoiceTranDateTo != null && invoiceTranDateTo != '' )
				invoicefilters.push( new nlobjSearchFilter( 'trandate', null, 'within', invoiceTranDateFrom, invoiceTranDateTo ) );
			if ( invoiceTranDateFrom != null && invoiceTranDateFrom != '' && ( invoiceTranDateTo == null || invoiceTranDateTo == '' ) )
				invoicefilters.push( new nlobjSearchFilter( 'trandate', null, 'onorafter', invoiceTranDateFrom ) );
			if ( invoiceTranDateTo != null && invoiceTranDateTo != '' && ( invoiceTranDateFrom == null || invoiceTranDateFrom == '' ) )
				invoicefilters.push( new nlobjSearchFilter( 'trandate', null, 'onorbefore', invoiceTranDateTo ) );
			if ( invoiceLineIo != null && invoiceLineIo != '' )
				invoicefilters.push( new nlobjSearchFilter( COL_AAPF_IO, null, 'is', invoiceLineIo ) );

			//added by shravan kumar 12-10-2022
			invoicefilters = invoicefilters.concat( excludeConsolidationFils );

			var resultFilters1 = invoicefilters.concat( invoicefilts1 );
			//var resultFilters2 = invoicefilters.concat(invoicefilts2);
			/*var isLogRecExistsInPayment = false;
				if(paymentLinkDefValue != null && paymentLinkDefValue != ''){
					var custPaymentLogRec = nlapiLookupField('customerpayment', paymentLinkDefValue, FLD_PAYMENT_APPLICATION_LOG_LINKS);
					if(custPaymentLogRec != null && custPaymentLogRec != ''){
						resultFilters2.push(new nlobjSearchFilter(FLD_PAYMENT_APPLICATION_LOG_LINKS, null, 'anyof', custPaymentLogRec));
						 isLogRecExistsInPayment = true;
				 }
				}*/



			nlapiLogExecution( 'debug', 'HERE>>>>>>>', '' );


			var invoicesearchResults = [];
			var invoicesearchResults1 = getAllSearchResults( invoiceSSType, resultFilters1, invoicecolumns );

			nlapiLogExecution( 'DEBUG', 'invoicesearchResults1', invoicesearchResults1.length );





			//var invoicesearchResults2=getAllSearchResults(invoiceSSType, resultFilters2, invoicecolumns);
			if ( invoicesearchResults1 != null && invoicesearchResults1 != '' && invoicesearchResults1.length > 0 ) {
				if ( SRCH_SUMMARY[ invoiceSSType ].index > 0 ) {
					invoiceSublist.addButton( BTN_INVOICE_PREV_PAGE, '< Previous Page', 'gotoInvPage(-1);' )
				}
				if ( SRCH_SUMMARY[ invoiceSSType ].more == true ) {
					invoiceSublist.addButton( BTN_INVOICE_NEXT_PAGE, 'Next Page >', 'gotoInvPage(1);' )
				}

				for ( var ss = 0, ssl = invoicesearchResults1.length; ss < ssl; ss++ ) {
					var searchresult = invoicesearchResults1[ ss ];
					var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
					if ( invLineId != null && invLineId != '' && !paymentApplLinkedTranInvObj.hasOwnProperty( invLineId ) )
						invoicesearchResults.push( searchresult );
				}
			}

			var invResultCountFilters = invoicefilters.concat( invoiceCountFil );
			var invoiceCountResults = getAllSearchResults( invoiceCountSSType + '__count', invResultCountFilters, invoiceCountCol );
			nlapiLogExecution( 'DEBUG', 'invoiceCountResults', invoiceCountResults.length );

			var invLinesCount = 0;
			if ( invoiceCountResults != null && invoiceCountResults != '' && invoiceCountResults.length > 0 ) {
				invLinesCount = invoiceCountResults[ 0 ].getValue( invoiceCountCol[ invoiceCountCol.length - 1 ] );
			}
			nlapiLogExecution( 'DEBUG', 'invLinesCount', invLinesCount );

			var pageNum = ( Number( SRCH_INDEX[ invoiceSSType ] ) / Number( SRCH_SUMMARY.pageSize ) );
			var pageStart = ( SRCH_SUMMARY.pageSize * pageNum ) + 1;
			var pageEnd = ( Number( pageNum ) + 1 ) * SRCH_SUMMARY.pageSize;
			if ( pageEnd > invLinesCount ) {
				pageEnd = invLinesCount
			}
			invoiceSublist.setHelpText(
				'<font style="font-size: 10pt"><b>Showing results ' +
				numberWithCommas( pageStart ) + ' to ' + numberWithCommas( pageEnd ) + ' of ' + numberWithCommas( invLinesCount ) + ' invoice lines.</b></font>' +
				'<br/>This sublist displays a maximum of ' + SRCH_SUMMARY.pageSize + ' lines.'
			);

			//if(isLogRecExistsInPayment && paymentLinkDefValue != null && paymentLinkDefValue != '' && invoicesearchResults2 != null && invoicesearchResults2 != '' && invoicesearchResults2.length>0)
			//invoicesearchResults = invoicesearchResults.concat(invoicesearchResults2);

			//nlapiLogExecution('debug','invoicesearchResults',invoicesearchResults)




			//Hidden by sravan, 30-jun-2023
			/*
			
			//03-05-2023 added by shravan kumar
			var isSecoundSearch = false;
			if ( invLinesCount >= 2000 )
				isSecoundSearch = true;
			if ( isSecoundSearch ) {
				var invoiceResultsForCI = getAllSearchResults_Final( invoiceSSType, resultFilters1, invoicecolumns );
				nlapiLogExecution( 'DEBUG', 'invoiceResultsForCI', invoiceResultsForCI.length );

				for ( var ii = 0; ii < invoiceResultsForCI.length; ii++ ) {
					//added by shravan kumar 14-03-2023
					var CiRecordId = invoiceResultsForCI[ ii ].getValue( 'custcol_appf_ci_record' );
					if ( CiRecordId )
						if ( ciRecords_Array.indexOf( CiRecordId ) == -1 )
							ciRecords_Array.push( CiRecordId )
				}
			}
			*/



			var total_selected = 0;
			var total_amount = 0;
			if ( invoicesearchResults != null && invoicesearchResults != '' && invoicesearchResults.length > 0 ) {

				var unSortedArr = [];
				for ( var s = 0; s < invoicesearchResults.length; s++ ) {

					var searchresult = invoicesearchResults[ s ];
					var internalid = searchresult.getId();
					var allCols = searchresult.getAllColumns();

					unSortedArr.push( searchresult.getValue( allCols[ ( parseInt( allCols.length ) - 7 ) ] ) + '-' + searchresult.getValue( allCols[ ( parseInt( allCols.length ) - 4 ) ] ) );

				}
				sortWithIndeces( unSortedArr );
				var originalIndexes = unSortedArr.sortIndices;
				var invoicesearchResultsSorted = [];

				for ( var s1 = 0; s1 < originalIndexes.length; s1++ ) {

					invoicesearchResultsSorted.push( invoicesearchResults[ originalIndexes[ s1 ] ] );
				}
				nlapiLogExecution( 'debug', 'invoicesearchResultsSorted Length', invoicesearchResultsSorted.length )
				var s = -1;

				for ( var s_new = 0; s_new < invoicesearchResultsSorted.length; s_new++ ) {

					var searchresult = invoicesearchResultsSorted[ s_new ];
					var internalid = searchresult.getId();
					var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
					//nlapiLogExecution('debug', 'invLineId Applied 1', invLineId);
					if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
						nlapiLogExecution( 'DEBUG', 'Skipping line...', 'internalid = ' + internalid );
						continue;
					}
					var invDueAmtRem = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 2 ] );
					if ( invDueAmtRem == null || invDueAmtRem == '' )
						invDueAmtRem = 0;
					total_selected++;
					total_amount += parseFloat( invDueAmtRem );
				}
				for ( var s_new = 0; s_new < invoicesearchResultsSorted.length; s_new++ ) {



					var searchresult = invoicesearchResultsSorted[ s_new ];
					var internalid = searchresult.getId();
					var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );



					//Hidden by sravan, 30-jun-2023
					/*
							//added by shravan kumar 03-05-2023
							if ( isSecoundSearch == false ) {
								//added by shravan kumar 14-03-2023
								var CiRecordId = searchresult.getValue( 'custcol_appf_ci_record' );
								if ( CiRecordId )
									if ( ciRecords_Array.indexOf( CiRecordId ) == -1 )
										ciRecords_Array.push( CiRecordId )
							}
					 */

					//nlapiLogExecution('debug', 'invLineId Applied 1', invLineId);
					if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
						nlapiLogExecution( 'DEBUG', 'Skipping line...', 'internalid = ' + internalid );
						continue;
					}
					s++;
					//nlapiLogExecution( 'debug', 'internalid in unapplied inv', internalid + '::' + s );

					if ( consolidateInvArr.length > 0 ) {
						invoiceSublist.setLineItemValue( COL_SL_INVOICE_MARK, s + 1, 'T' );
					}

					ssResultValue = invDueAmtRem;
					var colArrInvoice = [];
					var colIndexInvoice = 1;
					var scriptfieldcounterInvoice = 1;
					for ( var c = 0; c < invoicecolumns.length; c++ ) {
						var colObj = invoicecolumns[ c ];
						var columnName = colObj.getName();
						var colLabel = colObj.getLabel();
						var ssResultValue = searchresult.getValue( colObj );
						var itemintid = null;
						var backlinkIdValues = null;
						var pwpid = null;
						if ( scriptfieldcounterInvoice == 3 )
							itemintid = ssResultValue;
						if ( scriptfieldcounterInvoice == 11 )
							pwpid = ssResultValue;
						if ( scriptfieldcounterInvoice == 4 ) {
							backlinkIdValues = ssResultValue;
						}
						if ( colObj.getType() == 'select' ) {
							ssResultValue = searchresult.getText( colObj )
						}
						if ( colArrInvoice.indexOf( columnName ) == -1 ) {
							colArrInvoice.push( columnName )
						}
						else {
							columnName = columnName + colIndexInvoice;
							colIndexInvoice++;
						}


						invoiceSublist.setLineItemValue( COL_SL_INVOICE_INTERNAL_ID, s + 1, internalid );
						if ( colLabel != 'Script Use DNR' ) {
							if ( columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid' ) {
								var url = nlapiResolveURL( 'RECORD', 'invoice', internalid );
								var redirect = '<a href=' + url + ' target="_blank">' + ssResultValue + '</a>';
								ssResultValue = redirect;
							}

							invoiceSublist.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );

						}
						else {
							if ( scriptfieldcounterInvoice == 1 )
								invoiceSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, ssResultValue );
							if ( scriptfieldcounterInvoice == 11 )
								invoiceSublist.setLineItemValue( 'custpage_scriptfield_pwp', s + 1, pwpid );
							if ( scriptfieldcounterInvoice == 5 || scriptfieldcounterInvoice == 7 || scriptfieldcounterInvoice == 8 || scriptfieldcounterInvoice == 9 ) {

								invoiceSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, ssResultValue );

							}
							if ( scriptfieldcounterInvoice == 6 ) {
								invoiceSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, internalid );
							}
							if ( scriptfieldcounterInvoice == 2 ) {
								var invDueAmtRem = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 2 ] );
								if ( invDueAmtRem == null || invDueAmtRem == '' )
									invDueAmtRem = 0;
								var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
								//nlapiLogExecution('debug', 'invLineId Applied 2', invLineId);
								ssResultValue = invDueAmtRem;
								/*if(invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty(invLineId)){
									invoiceSublist.setLineItemValue(COL_SL_LINE_FROM_PAYMENT, s+1, paymentApplLinkedTranInvObj[invLineId].paltId);	
									invoiceSublist.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
										ssResultValue = paymentApplLinkedTranInvObj[invLineId].transLineAmt;
										if(ssResultValue == null || ssResultValue == '')
											ssResultValue = 0;
										invDueAmtRem = parseFloat(invDueAmtRem) + parseFloat(ssResultValue);
									nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT OBJ', ssResultValue);
								}*/
								//nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT SS', ssResultValue);
								invoiceSublist.setLineItemValue( COL_SL_PAYMENT_AMOUNT, s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
								invoiceSublist.setLineItemValue( COL_SL_PAYMENT_AMOUNT + '_native', s + 1, ( invDueAmtRem != null && invDueAmtRem != '' ) ? parseFloat( invDueAmtRem ) : 0 );

							}


							if ( scriptfieldcounterInvoice == 1 ) {
								var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
								//nlapiLogExecution('debug', 'invLineId @ scriptfieldcounterInvoice is 1', invLineId);

								var invDueAmtRemTax = ssResultValue;
								var invTaxRateInSS = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 3 ] );

								var amtValInSS = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 2 ] );
								/*if(invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty(invLineId)){
										//invoiceSublist.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
										amtValInSS = paymentApplLinkedTranInvObj[invLineId].transLineAmt;
								}*/
								if ( amtValInSS == null || amtValInSS == '' )
									amtValInSS = 0;
								//nlapiLogExecution('debug', 'invLineId', invLineId);
								/*if(invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty(invLineId)){
										//invoiceSublist.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
										ssResultValue = paymentApplLinkedTranInvObj[invLineId].transLineAmtTax;
										if(ssResultValue == null || ssResultValue == '')
											ssResultValue = 0;
										invDueAmtRemTax = parseFloat(invDueAmtRemTax) + parseFloat(ssResultValue);
						    nlapiLogExecution('debug', 'ssResultValue PAYMENT TAX AMT OBJ', ssResultValue);
								}*/
								//nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT SS', ssResultValue);
								if ( invTaxRateInSS ) {
									var taxAmtCalc = parseFloat( amtValInSS ) - ( parseFloat( amtValInSS ) / ( 1 + ( parseFloat( invTaxRateInSS ) / 100 ) ) );


									ssResultValue = Number( taxAmtCalc ).toFixed( 2 );
								}
								invoiceSublist.setLineItemValue( COL_SL_PAYMENT_AMOUNT + '_tax', s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
							}
							if ( scriptfieldcounterInvoice == 3 ) {
								invoiceSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, itemintid );
							}
							if ( scriptfieldcounterInvoice == 4 ) {
								invoiceSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, backlinkIdValues );

							}
							scriptfieldcounterInvoice++;
						}


					}


				}
			}
		}
		//Unapplied Credit Lines Sublist
		var creditSublist = form.addSubList( COL_SL_CREDIT_SUBLIST, 'list', 'Unapplied Credit Lines' );
		creditSublist.addField( COL_SL_CREDIT_SUBLIST_FLD_MARK, 'checkbox', 'Select' );
		creditSublist.addButton( BTN_CREDIT_MARK_ALL, 'Mark All', 'creditmarkAll();' )
		creditSublist.addButton( BTN_CREDIT_UNMARK_ALL, 'Unmark All', 'creditunmarkAll();' )
		// creditSublist.setHelpText('\nThis sublist displays a maximum of ' + SRCH_SUMMARY.pageSize + ' lines.\n');

		var colArrCredit = [];
		var colIndexCredit = 1;
		var scriptfieldcounterCredit = 1;

		for ( var i = 0; i < creditcolumns.length; i++ ) {
			var colObj = creditcolumns[ i ];
			var colName = colObj.getName();
			var colLabel = colObj.getLabel();

			if ( colArrCredit.indexOf( colName ) == -1 ) {
				colArrCredit.push( colName )
			}
			else {
				colName = colName + colIndexCredit;
				colIndexCredit++;
			}

			if ( colLabel != 'Script Use DNR' ) {
				creditSublist.addField( 'custpage_' + colName, 'text', colLabel );

			}
			else {
				var typeofscriptfield = 'text';
				if ( scriptfieldcounterInvoice == 1 )
					typeofscriptfield = 'currency';


				var scriptField = creditSublist.addField( 'custpage_scriptfield' + scriptfieldcounterCredit, typeofscriptfield, colLabel );
				scriptField.setDisplayType( 'hidden' );
				scriptfieldcounterCredit++;
			}

		}

		var hiddenLineFromPayCred = creditSublist.addField( COL_SL_LINE_FROM_PAYMENT + '_cr', 'text', 'From Payment Application' );
		hiddenLineFromPayCred.setDisplayType( 'hidden' );
		hiddenLineFromPayCred.setDefaultValue( '' );
		creditSublist.addField( COL_SL_CREDIT_AMOUNT, 'currency', 'Credit Amount' ).setDisplayType( 'entry' );
		creditSublist.addField( COL_SL_CREDIT_AMOUNT + '_native', 'currency', 'Credit Amount Hidden' ).setDisplayType( 'hidden' );
		if ( clientPDCM != null && clientPDCM != '' && filtersectionClientCM != null && filtersectionClientCM != '' ) {
			var creditfilters = [];
			//if(client != null && client != '')
			//creditfilters.push(new nlobjSearchFilter('entity', null, 'anyof',client));
			//nlapiLogExecution('debug', 'filtersectionClientCMArr', JSON.stringify(filtersectionClientCMArr));
			if ( filtersectionClientCM != null && filtersectionClientCM != '' )
				creditfilters.push( new nlobjSearchFilter( 'entity', null, 'anyof', filtersectionClientCMArr ) );

			if ( consolidateInvArr != null && consolidateInvArr != '' )
				creditfilters.push( new nlobjSearchFilter( 'custbody_appf_ci_record', null, 'anyof', consolidateInvArr ) );

			//added by shravan kumar 12-10-2022
			creditfilters = creditfilters.concat( excludeConsolidationFils_CM );

			var resultFilters1 = creditfilters.concat( creditfilts );
			//var resultFilters2 = creditfilters.concat(creditfilts2);
			/*var isLogRecExistsInPayment = false;
			if(paymentLinkDefValue != null && paymentLinkDefValue != ''){
				var custPaymentLogRec = nlapiLookupField('customerpayment', paymentLinkDefValue, FLD_PAYMENT_APPLICATION_LOG_LINKS);
				if(custPaymentLogRec != null && custPaymentLogRec != ''){
					resultFilters2.push(new nlobjSearchFilter(FLD_PAYMENT_APPLICATION_LOG_LINKS, null, 'anyof', custPaymentLogRec));
				  isLogRecExistsInPayment = true;
			 }
			}*/





			var creditsearchResults = [];

			var creditsearchResults1 = getAllSearchResults( creditSSType, resultFilters1, creditcolumns );
			//var creditsearchResults2=getAllSearchResults(creditSSType, resultFilters2, creditcolumns);

			if ( creditsearchResults1 != null && creditsearchResults1 != '' && creditsearchResults1.length > 0 ) {
				if ( SRCH_SUMMARY[ creditSSType ].index > 0 ) {
					creditSublist.addButton( BTN_CREDIT_PREV_PAGE, '< Previous Page', 'gotoCredPage(-1);' )
				}
				if ( SRCH_SUMMARY[ creditSSType ].more == true ) {
					creditSublist.addButton( BTN_INVOICE_NEXT_PAGE, 'Next Page >', 'gotoCredPage(1);' )
				}

				for ( var ss = 0; ss < creditsearchResults1.length; ss++ ) {
					var searchresult = creditsearchResults1[ ss ];
					var internalid = searchresult.getId();
					if ( internalid != null && internalid != '' && !paymentApplLinkedTranCMObj.hasOwnProperty( internalid ) )
						creditsearchResults.push( searchresult );
				}

			}

			var credResultCountFilters = creditfilters.concat( creditCountFil );
			var creditCountResults = getAllSearchResults( creditCountSSType + '__count', credResultCountFilters, creditCountCol );
			nlapiLogExecution( 'DEBUG', 'creditCountResults', creditCountResults.length );

			var credLinesCount = 0;
			if ( creditCountResults != null && creditCountResults != '' && creditCountResults.length > 0 ) {
				credLinesCount = creditCountResults[ 0 ].getValue( creditCountCol[ creditCountCol.length - 1 ] );
			}
			nlapiLogExecution( 'DEBUG', 'invLinesCount', credLinesCount );

			var pageNum = ( Number( SRCH_INDEX[ creditSSType ] ) / Number( SRCH_SUMMARY.pageSize ) );
			var pageStart = ( SRCH_SUMMARY.pageSize * pageNum ) + 1;
			var pageEnd = ( Number( pageNum ) + 1 ) * SRCH_SUMMARY.pageSize;
			if ( pageEnd > credLinesCount ) {
				pageEnd = credLinesCount;
			}
			creditSublist.setHelpText(
				'<font style="font-size: 10pt"><b>Showing results ' +
				numberWithCommas( pageStart ) + ' to ' + numberWithCommas( pageEnd ) + ' of ' + numberWithCommas( credLinesCount ) + ' credit lines.</b></font>' +
				'<br/>This sublist displays a maximum of ' + SRCH_SUMMARY.pageSize + ' lines.'
			);

			//if(isLogRecExistsInPayment && paymentLinkDefValue != null && paymentLinkDefValue != '' && creditsearchResults2 != null && creditsearchResults2 != '' && creditsearchResults2.length>0)
			//creditsearchResults = creditsearchResults.concat(creditsearchResults2);

			nlapiLogExecution( 'debug', 'creditsearchResults Length', creditsearchResults.length )
			if ( creditsearchResults != null && creditsearchResults != '' && creditsearchResults.length > 0 ) {
				var s = -1;
				for ( var s_new = 0; s_new < creditsearchResults.length; s_new++ ) {




					var searchresult = creditsearchResults[ s_new ];
					var internalid = searchresult.getId();
					if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
						continue;
					}

					for ( var c = 0; c < creditcolumns.length; c++ ) {
						var colObj = creditcolumns[ c ];
						var columnName = colObj.getName();
						var colLabel = colObj.getLabel();
						var ssResultValue = searchresult.getValue( colObj );
						if ( colLabel == 'Script Use DNR' ) {
							total_amount = total_amount - parseFloat( ssResultValue )
							break;
						}
					}
					total_selected++;
				}
				for ( var s_new = 0; s_new < creditsearchResults.length; s_new++ ) {

					var searchresult = creditsearchResults[ s_new ];

					//Hidden by sravan, 30-jun-2023
					/*

				    //added by shravan kumar 14-03-2023
				    var CiRecordId = searchresult.getValue( 'custbody_appf_ci_record' );
				    if ( CiRecordId )
					    if ( ciRecords_Array.indexOf( CiRecordId ) == -1 )
						    ciRecords_Array.push( CiRecordId )
					    */

					var internalid = searchresult.getId();
					if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
						continue;
					}
					s++;

					if ( consolidateInvArr.length > 0 ) {
						creditSublist.setLineItemValue( COL_SL_CREDIT_SUBLIST_FLD_MARK, s + 1, 'T' );
					}
					var colArrCredit = [];
					var colIndexCredit = 1;
					var scriptfieldcounterCredit = 1;
					for ( var c = 0; c < creditcolumns.length; c++ ) {
						var colObj = creditcolumns[ c ];
						var columnName = colObj.getName();
						var colLabel = colObj.getLabel();
						var ssResultValue = searchresult.getValue( colObj );
						var cmbacklinkvalues = null;
						if ( scriptfieldcounterCredit == 2 ) {
							cmbacklinkvalues = ssResultValue;

						}
						if ( colObj.getType() == 'select' ) {
							ssResultValue = searchresult.getText( colObj )
						}
						if ( colArrCredit.indexOf( columnName ) == -1 ) {
							colArrCredit.push( columnName )
						}
						else {
							columnName = columnName + colIndexCredit;
							colIndexCredit++;
						}


						if ( colLabel != 'Script Use DNR' ) {

							if ( columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid' ) {
								var url = nlapiResolveURL( 'RECORD', 'creditmemo', internalid );
								var redirect = '<a href=' + url + ' target="_blank">' + ssResultValue + '</a>';
								ssResultValue = redirect;
							}
							creditSublist.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );
						}
						else {
							if ( scriptfieldcounterCredit == 2 ) {
								creditSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, cmbacklinkvalues );

							}

							if ( scriptfieldcounterCredit == 1 ) {
								var origCreditDue = ssResultValue;
								//nlapiLogExecution('debug', 'CM internalid', internalid);
								/*if(internalid != null && internalid != '' && paymentApplLinkedTranCMObj.hasOwnProperty(internalid)){
									if(paymentApplLinkedTranCMObj[internalid].paltIds != null && paymentApplLinkedTranCMObj[internalid].paltIds != '')
									creditSublist.setLineItemValue(COL_SL_LINE_FROM_PAYMENT+'_cr', s+1, paymentApplLinkedTranCMObj[internalid].paltIds[0]);	
										creditSublist.setLineItemValue(COL_SL_CREDIT_SUBLIST_FLD_MARK, s+1, 'T');
										ssResultValue = paymentApplLinkedTranCMObj[internalid].transLineAmt;
										if(ssResultValue == null || ssResultValue == '')
											ssResultValue = 0;
										origCreditDue = parseFloat(origCreditDue) + parseFloat(ssResultValue);
								}*/
								creditSublist.setLineItemValue( COL_SL_CREDIT_AMOUNT, s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
								creditSublist.setLineItemValue( COL_SL_CREDIT_AMOUNT + '_native', s + 1, ( origCreditDue != null && origCreditDue != '' ) ? parseFloat( origCreditDue ) : 0 );
							}
							if ( scriptfieldcounterCredit == 3 ) {
								creditSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, internalid );
							}
							if ( scriptfieldcounterCredit == 4 ) {

								creditSublist.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, ssResultValue );

							}
							// creditSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounterCredit, s+1, ssResultValue);								
							scriptfieldcounterCredit++;
						}

					}

				}
			}
		}


		// Insert field for 
		var fldLinesSelected = form.addField( FLD_SL_TOTAL_SELECTED_LINES, 'integer', 'Total Lines Selected', null, FLD_GROUP_SUMMARY );
		fldLinesSelected.setDisplayType( 'disabled' );
		// fldLinesSelected.setDefaultValue(0);

		// Insert field for results sublist tracking
		var fldSublistTracker = form.addField( FLD_SL_SRCH_TRACKER, 'inlinehtml', 'Sublists', null, FLD_GROUP_SUMMARY ).setDisplayType( 'hidden' );
		fldSublistTracker.setDefaultValue( JSON.stringify( SRCH_SUMMARY ) );



		//Applied Invoice Lines Sublist
		var invoiceSublistApplied = form.addSubList( COL_SL_INVOICE_SUBLIST_APPLIED, 'list', 'Applied Invoice Lines' );
		/*invoiceSublistApplied.addField(COL_SL_INVOICE_MARK,'checkbox','Select');
		invoiceSublistApplied.addButton(BTN_INVOICE_MARK_ALL, 'Mark All', 'invoicemarkAll();')
		invoiceSublistApplied.addButton(BTN_INVOICE_UNMARK_ALL, 'Unmark All', 'invoiceunmarkAll();')*/
		var colArrInvoice = [];
		var colIndexInvoice = 1;
		var scriptfieldcounterInvoice = 1;
		for ( var i = 0; i < invoicecolumns.length; i++ ) {
			var colObj = invoicecolumns[ i ];
			var colName = colObj.getName();
			var colLabel = colObj.getLabel();
			if ( colArrInvoice.indexOf( colName ) == -1 ) {
				colArrInvoice.push( colName )
			}
			else {
				colName = colName + colIndexInvoice;
				colIndexInvoice++;
			}
			if ( colLabel != 'Script Use DNR' ) {
				invoiceSublistApplied.addField( 'custpage_' + colName, 'text', colLabel );

			}
			else {
				var typeofscriptfield = 'text';
				if ( scriptfieldcounterInvoice == 2 || scriptfieldcounterInvoice == 1 || scriptfieldcounterInvoice == 9 )
					typeofscriptfield = 'currency';


				if ( scriptfieldcounterInvoice == 11 )
					var scriptField = invoiceSublistApplied.addField( 'custpage_scriptfield_pwp', typeofscriptfield, colLabel );
				else
					var scriptField = invoiceSublistApplied.addField( 'custpage_scriptfield' + scriptfieldcounterInvoice, typeofscriptfield, colLabel );
				if ( scriptfieldcounterInvoice == 11 )
					scriptField.setDisplayType( 'hidden' );
				else
					scriptField.setDisplayType( 'hidden' );



				scriptfieldcounterInvoice++;
			}
		}
		var hiddenLineFromPayInv = invoiceSublistApplied.addField( COL_SL_LINE_FROM_PAYMENT, 'text', 'From Payment Application' );
		hiddenLineFromPayInv.setDisplayType( 'hidden' );
		hiddenLineFromPayInv.setDefaultValue( '' );
		invoiceSublistApplied.addField( COL_SL_PAYMENT_AMOUNT, 'currency', 'Payment Amount' ).setDisplayType( 'entry' );
		invoiceSublistApplied.addField( COL_SL_PAYMENT_AMOUNT + '_native', 'currency', 'Payment Amount Hidden' ).setDisplayType( 'hidden' );
		invoiceSublistApplied.addField( COL_SL_PAYMENT_AMOUNT + '_tax', 'currency', 'Payment Tax Amount' ).setDisplayType( 'entry' );
		invoiceSublistApplied.addField( COL_SL_INVOICE_INTERNAL_ID, 'integer', 'Invoice ID' ).setDisplayType( 'hidden' );

		//if(clientPD != null && clientPD != '' && filtersectionClient != null && filtersectionClient != ''){
		//invoiceSublistApplied.addField(COL_SL_CLIENT, 'text', 'Client').setDisplayType('hidden');
		var invoicefilters = [];
		/*if(consolidateInv != null && consolidateInv != '')
	    invoicefilters.push(new nlobjSearchFilter(FLD_COL_INV_CI_RECORD, null, 'anyof',consolidateInvArr));
		if(filtersectionClient != null && filtersectionClient != '')
	    invoicefilters.push(new nlobjSearchFilter('entity', null, 'anyof',filtersectionClientArr));
		if(invoiceLineProject != null && invoiceLineProject !='')
		invoicefilters.push(new nlobjSearchFilter('internalid', 'job', 'anyof', invoiceLineProject));
		//if(invoiceTranDate != null && invoiceTranDate !='')
		//invoicefilters.push(new nlobjSearchFilter('trandate', null, 'on', invoiceTranDate));
		if(invoiceLineIo != null && invoiceLineIo !='')
		invoicefilters.push(new nlobjSearchFilter(COL_AAPF_IO, null, 'is', invoiceLineIo));
		//var resultFilters1 = invoicefilters.concat(invoicefilts1);*/


		//added by shravan kumar 12-10-2022
		invoicefilters = invoicefilters.concat( excludeConsolidationFils );

		var resultFilters2 = invoicefilters.concat( invoicefilts2 );
		var isLogRecExistsInPayment = false;
		if ( paymentLinkDefValue != null && paymentLinkDefValue != '' ) {
			var custPaymentLogRec = nlapiLookupField( 'customerpayment', paymentLinkDefValue, FLD_PAYMENT_APPLICATION_LOG_LINKS );
			if ( custPaymentLogRec != null && custPaymentLogRec != '' ) {
				resultFilters2.push( new nlobjSearchFilter( FLD_PAYMENT_APPLICATION_LOG_LINKS, null, 'anyof', custPaymentLogRec ) );
				isLogRecExistsInPayment = true;
			}
		}

		var invoicesearchResults = [];


		if ( isLogRecExistsInPayment && paymentLinkDefValue != null && paymentLinkDefValue != '' ) {
			//var invoicesearchResults1=getAllSearchResults(invoiceSSType, resultFilters1, invoicecolumns);
			var invoicesearchResults2 = getAllSearchResults( invoiceSSType + '__applied', resultFilters2, invoicecolumns );
			//if(invoicesearchResults1 != null && invoicesearchResults1 != '' && invoicesearchResults1.length>0)
			//invoicesearchResults = invoicesearchResults.concat(invoicesearchResults1);




			if ( invoicesearchResults2 != null && invoicesearchResults2 != '' && invoicesearchResults2.length > 0 ) {
				for ( var ss = 0; ss < invoicesearchResults2.length; ss++ ) {
					var searchresult = invoicesearchResults2[ ss ];
					var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
					if ( invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty( invLineId ) )
						invoicesearchResults.push( searchresult );
				}
			}

		}


		//nlapiLogExecution('debug','invoicesearchResults',invoicesearchResults)
		if ( invoicesearchResults != null && invoicesearchResults != '' && invoicesearchResults.length > 0 ) {

			var unSortedArr = [];
			for ( var s = 0; s < invoicesearchResults.length; s++ ) {

				var searchresult = invoicesearchResults[ s ];
				var internalid = searchresult.getId();
				var allCols = searchresult.getAllColumns();
				unSortedArr.push( searchresult.getValue( allCols[ ( parseInt( allCols.length ) - 7 ) ] ) + '-' + searchresult.getValue( allCols[ ( parseInt( allCols.length ) - 4 ) ] ) );

			}

			sortWithIndeces( unSortedArr );
			var originalIndexes = unSortedArr.sortIndices;

			var invoicesearchResultsSorted = [];

			for ( var s1 = 0; s1 < originalIndexes.length; s1++ ) {

				invoicesearchResultsSorted.push( invoicesearchResults[ originalIndexes[ s1 ] ] );
			}
			nlapiLogExecution( 'debug', 'invoicesearchResultsSorted - 2 Length', invoicesearchResultsSorted.length );
			var s = -1;
			for ( var s_new = 0; s_new < invoicesearchResultsSorted.length; s_new++ ) {
				var searchresult = invoicesearchResultsSorted[ s_new ];

				//Hidden by sravan, 30-jun-2023
				/*
		    //added by shravan kumar 14-03-2023
		    var CiRecordId = searchresult.getValue( 'custcol_appf_ci_record' );
		    if ( CiRecordId )
			    if ( ciRecords_Array.indexOf( CiRecordId ) == -1 )
				    ciRecords_Array.push( CiRecordId )
			    */

				var internalid = searchresult.getId();
				if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
					continue;
				}
				s++;
				var colArrInvoice = [];
				var colIndexInvoice = 1;
				var scriptfieldcounterInvoice = 1;
				for ( var c = 0; c < invoicecolumns.length; c++ ) {
					var colObj = invoicecolumns[ c ];
					var columnName = colObj.getName();
					var colLabel = colObj.getLabel();
					var ssResultValue = searchresult.getValue( colObj );
					var itemintid = null;
					var backlinkIdValues = null;
					var pwpid = null;
					if ( scriptfieldcounterInvoice == 3 )
						itemintid = ssResultValue;
					if ( scriptfieldcounterInvoice == 11 )
						pwpid = ssResultValue;
					if ( scriptfieldcounterInvoice == 4 ) {
						backlinkIdValues = ssResultValue;
					}
					if ( colObj.getType() == 'select' ) {
						ssResultValue = searchresult.getText( colObj )
					}
					if ( colArrInvoice.indexOf( columnName ) == -1 ) {
						colArrInvoice.push( columnName )
					}
					else {
						columnName = columnName + colIndexInvoice;
						colIndexInvoice++;
					}


					invoiceSublistApplied.setLineItemValue( COL_SL_INVOICE_INTERNAL_ID, s + 1, internalid );
					if ( colLabel != 'Script Use DNR' ) {
						if ( columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid' ) {
							var url = nlapiResolveURL( 'RECORD', 'invoice', internalid );
							var redirect = '<a href=' + url + ' target="_blank">' + ssResultValue + '</a>';
							ssResultValue = redirect;
						}

						invoiceSublistApplied.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );

					}
					else {
						if ( scriptfieldcounterInvoice == 1 )
							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, ssResultValue );
						if ( scriptfieldcounterInvoice == 11 )
							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield_pwp', s + 1, pwpid );
						if ( scriptfieldcounterInvoice == 5 || scriptfieldcounterInvoice == 7 || scriptfieldcounterInvoice == 8 || scriptfieldcounterInvoice == 9 ) {

							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, ssResultValue );

						}
						if ( scriptfieldcounterInvoice == 6 ) {
							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, internalid );
						}
						if ( scriptfieldcounterInvoice == 2 ) {
							var invDueAmtRem = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 2 ] );
							if ( invDueAmtRem == null || invDueAmtRem == '' )
								invDueAmtRem = 0;
							var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
							//nlapiLogExecution('debug', 'invLineId unapplied 2', invLineId);
							ssResultValue = invDueAmtRem;
							if ( invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty( invLineId ) ) {
								invoiceSublistApplied.setLineItemValue( COL_SL_LINE_FROM_PAYMENT, s + 1, paymentApplLinkedTranInvObj[ invLineId ].paltId );

								//invoiceSublistApplied.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
								// ssResultValue = searchresult.getValue(invoicecolumns[invoicecolumns2.length-11]);
								ssResultValue = paymentApplLinkedTranInvObj[ invLineId ].transLineAmt;
								if ( ssResultValue == null || ssResultValue == '' )
									ssResultValue = 0;
								invDueAmtRem = parseFloat( invDueAmtRem ) + parseFloat( ssResultValue );
								//nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT OBJ', ssResultValue);
							}
							//nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT SS', ssResultValue);
							invoiceSublistApplied.setLineItemValue( COL_SL_PAYMENT_AMOUNT, s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
							invoiceSublistApplied.setLineItemValue( COL_SL_PAYMENT_AMOUNT + '_native', s + 1, ( invDueAmtRem != null && invDueAmtRem != '' ) ? parseFloat( invDueAmtRem ) : 0 );

						}


						if ( scriptfieldcounterInvoice == 1 ) {
							var invLineId = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 4 ] );
							//nlapiLogExecution('debug', 'invLineId', invLineId);

							var invDueAmtRemTax = ssResultValue;
							var invTaxRateInSS = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 3 ] );

							var amtValInSS = searchresult.getValue( invoicecolumns[ invoicecolumns.length - 2 ] );
							if ( invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty( invLineId ) ) {
								//invoiceSublistApplied.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
								amtValInSS = paymentApplLinkedTranInvObj[ invLineId ].transLineAmt;
							}
							if ( amtValInSS == null || amtValInSS == '' )
								amtValInSS = 0;
							//nlapiLogExecution('debug', 'invLineId Unapplied 3', invLineId);
							if ( invLineId != null && invLineId != '' && paymentApplLinkedTranInvObj.hasOwnProperty( invLineId ) ) {
								//invoiceSublistApplied.setLineItemValue(COL_SL_INVOICE_MARK, s+1, 'T');
								ssResultValue = paymentApplLinkedTranInvObj[ invLineId ].transLineAmtTax;
								if ( ssResultValue == null || ssResultValue == '' )
									ssResultValue = 0;
								invDueAmtRemTax = parseFloat( invDueAmtRemTax ) + parseFloat( ssResultValue );
								//nlapiLogExecution('debug', 'ssResultValue PAYMENT TAX AMT OBJ', ssResultValue);
							}
							//nlapiLogExecution('debug', 'ssResultValue PAYMENT AMT SS', ssResultValue);
							if ( invTaxRateInSS ) {
								var taxAmtCalc = parseFloat( amtValInSS ) - ( parseFloat( amtValInSS ) / ( 1 + ( parseFloat( invTaxRateInSS ) / 100 ) ) );


								ssResultValue = Number( taxAmtCalc ).toFixed( 2 );
							}
							invoiceSublistApplied.setLineItemValue( COL_SL_PAYMENT_AMOUNT + '_tax', s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
						}
						if ( scriptfieldcounterInvoice == 3 ) {
							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, itemintid );
						}
						if ( scriptfieldcounterInvoice == 4 ) {
							invoiceSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterInvoice, s + 1, backlinkIdValues );

						}
						scriptfieldcounterInvoice++;
					}


				}

				SRCH_SUMMARY.totals = {
					appInv: s + 1
				};

			}
		}
		//}


		//Applied Credit Lines Sublist
		var creditSublistApplied = form.addSubList( COL_SL_CREDIT_SUBLIST_APPLIED, 'list', 'Applied Credit lines' );
		/*creditSublistApplied.addField(COL_SL_CREDIT_SUBLIST_FLD_MARK,'checkbox','Select');
	creditSublistApplied.addButton(BTN_CREDIT_MARK_ALL, 'Mark All', 'creditmarkAll();')
	creditSublistApplied.addButton(BTN_CREDIT_UNMARK_ALL, 'Unmark All', 'creditunmarkAll();')*/

		var colArrCredit = [];
		var colIndexCredit = 1;
		var scriptfieldcounterCredit = 1;

		for ( var i = 0; i < creditcolumns.length; i++ ) {
			var colObj = creditcolumns[ i ];
			var colName = colObj.getName();
			var colLabel = colObj.getLabel();

			if ( colArrCredit.indexOf( colName ) == -1 ) {
				colArrCredit.push( colName )
			}
			else {
				colName = colName + colIndexCredit;
				colIndexCredit++;
			}

			if ( colLabel != 'Script Use DNR' ) {


				creditSublistApplied.addField( 'custpage_' + colName, 'text', colLabel );

			}
			else {
				var typeofscriptfield = 'text';
				if ( scriptfieldcounterInvoice == 1 )
					typeofscriptfield = 'currency';


				var scriptField = creditSublistApplied.addField( 'custpage_scriptfield' + scriptfieldcounterCredit, typeofscriptfield, colLabel );
				scriptField.setDisplayType( 'hidden' );


				scriptfieldcounterCredit++;
			}

		}

		var hiddenLineFromPayCred = creditSublistApplied.addField( COL_SL_LINE_FROM_PAYMENT + '_cr', 'text', 'From Payment Application' );
		hiddenLineFromPayCred.setDisplayType( 'hidden' );
		hiddenLineFromPayCred.setDefaultValue( '' );
		creditSublistApplied.addField( COL_SL_CREDIT_AMOUNT, 'currency', 'Credit Amount' ).setDisplayType( 'entry' );
		creditSublistApplied.addField( COL_SL_CREDIT_AMOUNT + '_native', 'currency', 'Credit Amount Hidden' ).setDisplayType( 'hidden' );
		//if(clientPD != null && clientPD != '' && filtersectionClient != null && filtersectionClient != ''){
		var creditfilters = [];
		/*//if(client != null && client != '')
	    //creditfilters.push(new nlobjSearchFilter('entity', null, 'anyof',client));
		if(filtersectionClient != null && filtersectionClient != '')
	    creditfilters.push(new nlobjSearchFilter('entity', null, 'anyof',filtersectionClientArr));
		//var resultFilters1 = creditfilters.concat(creditfilts);*/

		//added by shravan kumar 12-10-2022
		creditfilters = creditfilters.concat( excludeConsolidationFils_CM );

		var resultFilters2 = creditfilters.concat( creditfilts2 );
		var isLogRecExistsInPayment = false;
		if ( paymentLinkDefValue != null && paymentLinkDefValue != '' ) {
			var custPaymentLogRec = nlapiLookupField( 'customerpayment', paymentLinkDefValue, FLD_PAYMENT_APPLICATION_LOG_LINKS );
			if ( custPaymentLogRec != null && custPaymentLogRec != '' ) {
				resultFilters2.push( new nlobjSearchFilter( FLD_PAYMENT_APPLICATION_LOG_LINKS, null, 'anyof', custPaymentLogRec ) );
				isLogRecExistsInPayment = true;
			}
		}
		var creditsearchResults = [];

		//var creditsearchResults1=getAllSearchResults(creditSSType, resultFilters1, creditcolumns);
		//if(creditsearchResults1 != null && creditsearchResults1 != '' && creditsearchResults1.length>0)
		//creditsearchResults = creditsearchResults.concat(creditsearchResults1);

		if ( isLogRecExistsInPayment && paymentLinkDefValue != null && paymentLinkDefValue != '' ) {
			var creditsearchResults2 = getAllSearchResults( creditSSType, resultFilters2, creditcolumns );
			if ( creditsearchResults2 != null && creditsearchResults2 != '' && creditsearchResults2.length > 0 ) {
				for ( var ss = 0; ss < creditsearchResults2.length; ss++ ) {
					var searchresult = creditsearchResults2[ ss ];
					var internalid = searchresult.getId();
					if ( internalid != null && internalid != '' && paymentApplLinkedTranCMObj.hasOwnProperty( internalid ) )
						creditsearchResults.push( searchresult );

				}
			}
		}





		nlapiLogExecution( 'debug', 'creditsearchResults Length', creditsearchResults.length )
		if ( creditsearchResults != null && creditsearchResults != '' && creditsearchResults.length > 0 ) {
			var s = -1;
			for ( var s_new = 0; s_new < creditsearchResults.length; s_new++ ) {

				var searchresult = creditsearchResults[ s_new ];
				//Hidden by sravan, 30-jun-2023
				/*
		    //added by shravan kumar 14-03-2023
		    var CiRecordId = searchresult.getValue( 'custbody_appf_ci_record' );
		    if ( CiRecordId )
			    if ( ciRecords_Array.indexOf( CiRecordId ) == -1 )
				    ciRecords_Array.push( CiRecordId )
			    */


				var internalid = searchresult.getId();
				if ( underProcessingTransList.indexOf( internalid ) != -1 ) {
					continue;
				}
				s++;
				var colArrCredit = [];
				var colIndexCredit = 1;
				var scriptfieldcounterCredit = 1;
				for ( var c = 0; c < creditcolumns.length; c++ ) {
					var colObj = creditcolumns[ c ];
					var columnName = colObj.getName();
					var colLabel = colObj.getLabel();
					var ssResultValue = searchresult.getValue( colObj );
					var cmbacklinkvalues = null;
					if ( scriptfieldcounterCredit == 2 ) {
						cmbacklinkvalues = ssResultValue;

					}
					if ( colObj.getType() == 'select' ) {
						ssResultValue = searchresult.getText( colObj )
					}
					if ( colArrCredit.indexOf( columnName ) == -1 ) {
						colArrCredit.push( columnName )
					}
					else {
						columnName = columnName + colIndexCredit;
						colIndexCredit++;
					}


					if ( colLabel != 'Script Use DNR' ) {

						if ( columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid' ) {
							var url = nlapiResolveURL( 'RECORD', 'creditmemo', internalid );
							var redirect = '<a href=' + url + ' target="_blank">' + ssResultValue + '</a>';
							ssResultValue = redirect;
						}
						creditSublistApplied.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );
					}
					else {
						if ( scriptfieldcounterCredit == 2 ) {
							creditSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, cmbacklinkvalues );

						}

						if ( scriptfieldcounterCredit == 1 ) {
							var origCreditDue = ssResultValue;
							//nlapiLogExecution('debug', 'CM internalid', internalid);
							if ( internalid != null && internalid != '' && paymentApplLinkedTranCMObj.hasOwnProperty( internalid ) ) {
								if ( paymentApplLinkedTranCMObj[ internalid ].paltIds != null && paymentApplLinkedTranCMObj[ internalid ].paltIds != '' )
									creditSublistApplied.setLineItemValue( COL_SL_LINE_FROM_PAYMENT + '_cr', s + 1, paymentApplLinkedTranCMObj[ internalid ].paltIds[ 0 ] );
								//creditSublistApplied.setLineItemValue(COL_SL_CREDIT_SUBLIST_FLD_MARK, s+1, 'T');
								ssResultValue = paymentApplLinkedTranCMObj[ internalid ].transLineAmt;
								if ( ssResultValue == null || ssResultValue == '' )
									ssResultValue = 0;
								origCreditDue = parseFloat( origCreditDue ) + parseFloat( ssResultValue );
								if ( ssResultValue != null && ssResultValue != '' )
									ssResultValue = Number( ssResultValue ).toFixed( 2 );
								if ( origCreditDue != null && origCreditDue != '' )
									origCreditDue = Number( origCreditDue ).toFixed( 2 );
							}
							creditSublistApplied.setLineItemValue( COL_SL_CREDIT_AMOUNT, s + 1, ( ssResultValue != null && ssResultValue != '' ) ? parseFloat( ssResultValue ) : 0 );
							creditSublistApplied.setLineItemValue( COL_SL_CREDIT_AMOUNT + '_native', s + 1, ( origCreditDue != null && origCreditDue != '' ) ? parseFloat( origCreditDue ) : 0 );
						}
						if ( scriptfieldcounterCredit == 3 ) {
							creditSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, internalid );
						}
						if ( scriptfieldcounterCredit == 4 ) {

							creditSublistApplied.setLineItemValue( 'custpage_scriptfield' + scriptfieldcounterCredit, s + 1, ssResultValue );

						}
						// creditSublistApplied.setLineItemValue('custpage_scriptfield'+scriptfieldcounterCredit, s+1, ssResultValue);								
						scriptfieldcounterCredit++;
					}

				}

				SRCH_SUMMARY.totals[ 'appCred' ] = s + 1;
			}
		}
		//}

		//}
		if ( consolidateInv != null && consolidateInv != '' ) {
			nlapiLogExecution( 'DEBUG', 'amount', total_amount )
			nlapiLogExecution( 'DEBUG', 'total', total_selected )
			appliedAmt.setDefaultValue( total_amount );
			//form.setFieldValues({FLD_SL_APPLIED_AMOUNT: total_amount,FLD_SL_TOTAL_SELECTED_LINES:total_selected});
			//	form.setFieldValue(FLD_SL_TOTAL_SELECTED_LINES, total_selected,  null, true);
			fldLinesSelected.setDefaultValue( total_selected );
			//fldLinesSelected.setDefaultValue(total_selected);
		}


		//Hidden by sravan, 30-jun-2023
		/*
	//added by shravan 14-03-2023
	//nlapiLogExecution( 'DEBUG', 'shravan', ciRecords_Array )
	//added by shravan 20-03-2023
	if ( ciRecords_Array != null && ciRecords_Array != '' ) {
		nlapiLogExecution( 'DEBUG', 'ciRecords_Array length', ciRecords_Array.length )
		var tranSearchResults = getAllSearchResults( 'customrecord_appf_ci_record', [ new nlobjSearchFilter( 'internalid', null, 'anyof', ciRecords_Array ) ], [ new nlobjSearchColumn( 'name' ) ] );
		if ( tranSearchResults != null && tranSearchResults != '' ) {
			for ( var x = 0; x < tranSearchResults.length; x++ ) {
				var result = tranSearchResults[ x ];
				var selected = false;
				if ( consolidateInvArr.indexOf( result.getId() ) != -1 )
					selected = true;
				consolidatedInvFld.addSelectOption( result.getId(), result.getValue( 'name' ), selected );
			}
		}
	}
	
	*/

		//added by shravan kumar 08-06-2023

		var ciSearchResults = getAllSearchResults_Final( ciRecordType, ciFils, ciRecordCols );
		if ( ciSearchResults != null && ciSearchResults != '' ) {
			nlapiLogExecution( 'DEBUG', 'shravan', ciSearchResults.length )
			for ( var x = 0; x < ciSearchResults.length; x++ ) {
				var result = ciSearchResults[ x ];
				var ci_record = result.getValue( "custcol_appf_ci_record", null, "GROUP" )
				var ci_record_text = result.getText( "custcol_appf_ci_record", null, "GROUP" )
				var selected = false;
				if ( consolidateInvArr.indexOf( ci_record ) != -1 )
					selected = true;
				if ( ci_record_text != '- None -' )
					consolidatedInvFld.addSelectOption( ci_record, ci_record_text, selected );
			}
		}




		form.addSubmitButton( 'Submit' );
		response.writePage( form );
		return form;
	}
	catch ( e ) {
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}




function processSelectedinvoices ( request, client, arAccount, currency, date, postingPeriod, memo, lineOfBusiness, department, office ) {
	//nlapiLogExecution('debug', 'arAccount', arAccount);
	var context = nlapiGetContext();
	var currentUser = context.getUser();
	var paymentLink = request.getParameter( FLD_SL_PAYMENT_LINK );
	var slclient = request.getParameter( SL_FLD_CLIENT_INV );
	var slcurrency = request.getParameter( SL_FLD_CURRENCY );
	nlapiLogExecution( 'debug', 'slclient : slcurrency', slclient + ' : ' + slcurrency );
	//var consolInvcCSVFolderId = context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_INVC_CSV_FOLDER_ID);
	var paymentNeedToProcess = request.getLineItemValue( COL_SL_SUBLIST, COL_SL_PAYMENT_RECORD_ID, 1 );
	//var paymentClient=request.getLineItemValue(COL_SL_SUBLIST, COL_SL_NATIVE_INVOICE_CLIENT, 1);
	nlapiLogExecution( 'debug', 'paymentNeedToProcess:', paymentNeedToProcess );

	var invoiceSSID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_INVOICE_SS );
	var creditSSID = context.getSetting( 'SCRIPT', SPARAM_CLIENT_CREDIT_SS );

	var loadInvoiceSS = nlapiLoadSearch( null, invoiceSSID );
	var invoicecolumns = loadInvoiceSS.getColumns();

	var loadCreditSS = nlapiLoadSearch( null, creditSSID );
	var creditcolumns = loadCreditSS.getColumns();

	var totalSelected = 0;
	var d = new Date();
	var timeStamp = d.getTime();
	var aIndividual = [], aGrouped = {};
	var dataForPayment = '';
	dataForPayment = dataForPayment + client + '||' + arAccount + '||' + currency + '||' + date + '||' + postingPeriod + '||' + memo + '||' + lineOfBusiness + '||' + department + '||' + office;
	try {
		var transUnderProcessing = [];
		var invoiceType = '1';
		var creditMemoType = '2';
		//var ssDataFile='';
		var ssDataFileCr = '';

		var ssSuccessDataFile = '';
		var ssSuccessCreditDataFile = '';
		var ssSuccessDataFileInv = '';

		//ssDataFile += 'ID,Type\n';
		//ssDataFileCr += 'Credit ID,Status\n';

		ssSuccessDataFile += 'Invoice ID,Status,Order Line,Item ID,LINE PAYMENT AMOUNT,Back Links\n';
		ssSuccessCreditDataFile += 'Credit ID,Status,Back Links,Credit Amount\n';

		ssSuccessDataFileInv += 'Invoice ID,Line ID,Payment Amount,Invoice Line Tax Amount,PWP Record ID\n';

		var lineCount = request.getLineItemCount( COL_SL_INVOICE_SUBLIST );
		nlapiLogExecution( 'debug', 'lineCount', lineCount );
		var creditLineCount = request.getLineItemCount( COL_SL_CREDIT_SUBLIST );
		var invLineCountApplied = request.getLineItemCount( COL_SL_INVOICE_SUBLIST_APPLIED );
		var creditLineCountApplied = request.getLineItemCount( COL_SL_CREDIT_SUBLIST_APPLIED );
		var mainObj = {};
		var creditObj = {};
		var hasCreditMemos = false;
		var selectedInvoicesIdsWithPayment = '';
		var selectedCreditMemoIdsWithPayment = '';

		var totInvSelected = 0;
		var totCremMemoSelected = 0;

		var totInvoiceSelected = [];

		var dumpInvoicesFileData = '';
		var dumpCreditMemosFileData = '';

		dumpInvoicesFileData += 'Select, Internal ID,';
		for ( var ic = 0; ic < invoicecolumns.length; ic++ ) {

			dumpInvoicesFileData += invoicecolumns[ ic ].getLabel() + ',';

		}
		dumpInvoicesFileData += 'Payment Amount, Payment Tax Amount,';
		dumpInvoicesFileData = dumpInvoicesFileData.slice( 0, -1 ) + '\n';

		dumpCreditMemosFileData += 'Select, Internal ID,';
		for ( var cc = 0; cc < creditcolumns.length; cc++ ) {
			dumpCreditMemosFileData += creditcolumns[ cc ].getLabel() + ',';
		}
		dumpCreditMemosFileData += 'Credit Amount,';
		dumpCreditMemosFileData = dumpCreditMemosFileData.slice( 0, -1 ) + '\n';


		for ( var i = 1; i <= lineCount; i++ ) {
			if ( request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i ) == 'T' ) {

				var isSelect = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i );
				var invoiceid = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield6', i );
				totInvoiceSelected.push( invoiceid );
				if ( isSelect == null || isSelect == '' )
					isSelect = 'F';
				dumpInvoicesFileData += isSelect + ',' + invoiceid + ',';
				var colArrInvoice = [];
				var colIndexInvoice = 1;
				var scriptfieldcounterInvoice = 1;
				for ( var ic = 0; ic < invoicecolumns.length; ic++ ) {
					var colObj = invoicecolumns[ ic ];
					var colName = colObj.getName();
					var colLabel = colObj.getLabel();
					var colVal = '';
					if ( colArrInvoice.indexOf( colName ) == -1 ) {
						colArrInvoice.push( colName )
					}
					else {
						colName = colName + colIndexInvoice;
						colIndexInvoice++;
					}
					if ( colLabel != 'Script Use DNR' ) {
						colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_' + colName, i );
					}
					else {

						if ( scriptfieldcounterInvoice == 11 ) {
							colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield_pwp', i );
						}
						else {
							colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield' + scriptfieldcounterInvoice, i );
						}
						scriptfieldcounterInvoice++;
					}
					if ( colVal != null && colVal != '' )
						colVal = colVal.replace( /,/g, '|' );
					dumpInvoicesFileData += colVal + ',';
				}
				dumpInvoicesFileData += request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i ) + ',';
				dumpInvoicesFileData += request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT + '_tax', i ) + ',';

				dumpInvoicesFileData = dumpInvoicesFileData.slice( 0, -1 ) + '\n';


				var invoiceid = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield6', i );
				var invoiceLinePWP = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield_pwp', i );

				//var linePayment=request.getLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT+'_native', i);
				var invLineTaxAmt = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT + '_tax', i );
				if ( invLineTaxAmt == null || invLineTaxAmt == '' )
					invLineTaxAmt = 0;
				var invoiceLinePayment = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i );
				if ( invoiceLinePayment == '' || invoiceLinePayment == null )
					invoiceLinePayment = 0;

				//var amountNeedToUpadteInInvoice=parseFloat(linePayment)+parseFloat(invoiceLinePayment);
				var itemId = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield3', i );
				var lineID = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield7', i );
				var customLineID = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield8', i );


				var backlinks = request.getLineItemValue( COL_SL_INVOICE_SUBLIST, 'custpage_scriptfield4', i );
				nlapiLogExecution( 'debug', 'invoiceLinePWP:', invoiceLinePWP );

				//nlapiLogExecution('debug','invoiceid',invoiceid);
				//nlapiLogExecution('debug','invoiceLinePayment',invoiceLinePayment);
				if ( backlinks != null && backlinks != '' ) {
					backlinks = backlinks.replace( /,/g, '|' );
					ssSuccessDataFile += invoiceid + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + lineID + ',' + itemId + ',' + invoiceLinePayment + ',' + backlinks + '\n';
					ssSuccessDataFileInv += invoiceid + ',' + customLineID + ',' + invoiceLinePayment + ',' + invLineTaxAmt + ',' + invoiceLinePWP + '\n';

				}
				else {
					backlinks = '';
					ssSuccessDataFile += invoiceid + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + lineID + ',' + itemId + ',' + invoiceLinePayment + ',' + backlinks + '\n';
					ssSuccessDataFileInv += invoiceid + ',' + customLineID + ',' + invoiceLinePayment + ',' + invLineTaxAmt + ',' + invoiceLinePWP + '\n';

				}
				if ( !mainObj.hasOwnProperty( invoiceid ) ) {
					mainObj[ invoiceid ] = new Object();
					invoiceLinePayment = Number( invoiceLinePayment );

					mainObj[ invoiceid ].payment = invoiceLinePayment;
					invLineTaxAmt = Number( invLineTaxAmt );

					mainObj[ invoiceid ].invLineTaxAmt = invLineTaxAmt;

				}
				else {
					var existingobj = mainObj[ invoiceid ];
					var existingPayment = mainObj[ invoiceid ].payment
					existingPayment = parseFloat( existingPayment ) + parseFloat( invoiceLinePayment );
					existingPayment = Number( existingPayment );
					mainObj[ invoiceid ].payment = existingPayment;

					var invLineTaxAmtRev = parseFloat( mainObj[ invoiceid ].invLineTaxAmt ) + parseFloat( invLineTaxAmt );
					invLineTaxAmtRev = Number( invLineTaxAmtRev );


					mainObj[ invoiceid ].invLineTaxAmt = invLineTaxAmtRev;
				}
				totInvSelected++;

			}

		}

		for ( var i = 1; i <= creditLineCount; i++ ) {

			if ( request.getLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i ) == 'T' ) {
				var isSelect = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i );
				var creditId = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, 'custpage_scriptfield3', i );
				totInvoiceSelected.push( creditId );
				if ( isSelect == null || isSelect == '' )
					isSelect = 'F';
				dumpCreditMemosFileData += isSelect + ',' + creditId + ',';
				var colArrCredit = [];
				var colIndexCredit = 1;
				var scriptfieldcounterCredit = 1;

				for ( var cc = 0; cc < creditcolumns.length; cc++ ) {
					var colObj = creditcolumns[ cc ];
					var colName = colObj.getName();
					var colLabel = colObj.getLabel();
					var colVal = '';
					if ( colArrCredit.indexOf( colName ) == -1 ) {
						colArrCredit.push( colName )
					}
					else {
						colName = colName + colIndexCredit;
						colIndexCredit++;
					}

					if ( colLabel != 'Script Use DNR' ) {
						colVal = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, 'custpage_' + colName, i );

					}
					else {
						colVal = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, 'custpage_scriptfield' + scriptfieldcounterCredit, i );
						scriptfieldcounterCredit++;
					}
					if ( colVal != null && colVal != '' )
						colVal = colVal.replace( /,/g, '|' );
					dumpCreditMemosFileData += colVal + ',';
				}
				dumpCreditMemosFileData += request.getLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i ) + ',';
				dumpCreditMemosFileData = dumpCreditMemosFileData.slice( 0, -1 ) + '\n';



				hasCreditMemos = true;
				var creditId = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, 'custpage_scriptfield3', i );
				var creditPayment = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i );
				var amountInCredit = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT + '_native', i );

				var backlinks = request.getLineItemValue( COL_SL_CREDIT_SUBLIST, 'custpage_scriptfield2', i );
				if ( amountInCredit == null || amountInCredit == '' )
					amountInCredit = 0;
				var amountNeedToUpadteInInvoice = parseFloat( creditPayment ) + parseFloat( amountInCredit );


				if ( backlinks != null && backlinks != '' ) {
					backlinks = backlinks.replace( /,/g, '|' );
					ssSuccessCreditDataFile += creditId + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + backlinks + ',' + creditPayment + '\n';
					//ssSuccessDataFileCM += creditId+','+creditPayment+'\n';

				}
				else {
					backlinks = '';
					ssSuccessCreditDataFile += creditId + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + backlinks + ',' + creditPayment + '\n';
					//ssSuccessDataFileCM += creditId+','+creditPayment+'\n';

				}

				if ( !creditObj.hasOwnProperty( creditId ) ) {
					creditObj[ creditId ] = new Object();
					creditPayment = Number( creditPayment );
					creditObj[ creditId ].payment = creditPayment;

				}
				else {
					var existingobj = creditObj[ creditId ];
					var existingPayment = creditObj[ creditId ].payment
					existingPayment = parseFloat( existingPayment ) + parseFloat( creditPayment );
					existingPayment = Number( existingPayment );

					creditObj[ creditId ].payment = existingPayment;
				}
				totCremMemoSelected++;

			}


		}

		//Invoice Lines Applied Sublist
		for ( var i = 1; i <= invLineCountApplied; i++ ) {
			//var isSelect = request.getLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_INVOICE_MARK, i);
			var invoiceid = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield6', i );
			totInvoiceSelected.push( invoiceid );
			//if(isSelect == null || isSelect == '')
			//isSelect = 'F';
			dumpInvoicesFileData += 'T,' + invoiceid + ',';
			var colArrInvoice = [];
			var colIndexInvoice = 1;
			var scriptfieldcounterInvoice = 1;
			for ( var ic = 0; ic < invoicecolumns.length; ic++ ) {
				var colObj = invoicecolumns[ ic ];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				var colVal = '';
				if ( colArrInvoice.indexOf( colName ) == -1 ) {
					colArrInvoice.push( colName )
				}
				else {
					colName = colName + colIndexInvoice;
					colIndexInvoice++;
				}
				if ( colLabel != 'Script Use DNR' ) {
					colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_' + colName, i );
				}
				else {

					if ( scriptfieldcounterInvoice == 11 ) {
						colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield_pwp', i );
					}
					else {
						colVal = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield' + scriptfieldcounterInvoice, i );
					}
					scriptfieldcounterInvoice++;
				}
				if ( colVal != null && colVal != '' )
					colVal = colVal.replace( /,/g, '|' );
				dumpInvoicesFileData += colVal + ',';
			}
			dumpInvoicesFileData += request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i ) + ',';
			dumpInvoicesFileData += request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT + '_tax', i ) + ',';

			dumpInvoicesFileData = dumpInvoicesFileData.slice( 0, -1 ) + '\n';


			var invoiceid = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield6', i );
			var invoiceLinePWP = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield_pwp', i );

			//var linePayment=request.getLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT+'_native', i);
			var invLineTaxAmt = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT + '_tax', i );
			if ( invLineTaxAmt == null || invLineTaxAmt == '' )
				invLineTaxAmt = 0;
			var invoiceLinePayment = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i );
			if ( invoiceLinePayment == '' || invoiceLinePayment == null )
				invoiceLinePayment = 0;

			//var amountNeedToUpadteInInvoice=parseFloat(linePayment)+parseFloat(invoiceLinePayment);
			var itemId = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield3', i );
			var lineID = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield7', i );
			var customLineID = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield8', i );


			var backlinks = request.getLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, 'custpage_scriptfield4', i );
			nlapiLogExecution( 'debug', 'invoiceLinePWP:', invoiceLinePWP );

			//nlapiLogExecution('debug','invoiceid',invoiceid);
			//nlapiLogExecution('debug','invoiceLinePayment',invoiceLinePayment);
			if ( backlinks != null && backlinks != '' ) {
				backlinks = backlinks.replace( /,/g, '|' );
				ssSuccessDataFile += invoiceid + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + lineID + ',' + itemId + ',' + invoiceLinePayment + ',' + backlinks + '\n';
				ssSuccessDataFileInv += invoiceid + ',' + customLineID + ',' + invoiceLinePayment + ',' + invLineTaxAmt + ',' + invoiceLinePWP + '\n';

			}
			else {
				backlinks = '';
				ssSuccessDataFile += invoiceid + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + lineID + ',' + itemId + ',' + invoiceLinePayment + ',' + backlinks + '\n';
				ssSuccessDataFileInv += invoiceid + ',' + customLineID + ',' + invoiceLinePayment + ',' + invLineTaxAmt + ',' + invoiceLinePWP + '\n';

			}
			if ( !mainObj.hasOwnProperty( invoiceid ) ) {
				mainObj[ invoiceid ] = new Object();
				invoiceLinePayment = Number( invoiceLinePayment );

				mainObj[ invoiceid ].payment = invoiceLinePayment;
				invLineTaxAmt = Number( invLineTaxAmt );

				mainObj[ invoiceid ].invLineTaxAmt = invLineTaxAmt;

			}
			else {
				var existingobj = mainObj[ invoiceid ];
				var existingPayment = mainObj[ invoiceid ].payment
				existingPayment = parseFloat( existingPayment ) + parseFloat( invoiceLinePayment );
				existingPayment = Number( existingPayment );
				mainObj[ invoiceid ].payment = existingPayment;

				var invLineTaxAmtRev = parseFloat( mainObj[ invoiceid ].invLineTaxAmt ) + parseFloat( invLineTaxAmt );
				invLineTaxAmtRev = Number( invLineTaxAmtRev );


				mainObj[ invoiceid ].invLineTaxAmt = invLineTaxAmtRev;
			}
			totInvSelected++;



		}

		for ( var i = 1; i <= creditLineCountApplied; i++ ) {


			//var isSelect = request.getLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_SUBLIST_FLD_MARK, i);
			var creditId = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, 'custpage_scriptfield3', i );
			totInvoiceSelected.push( creditId );
			//if(isSelect == null || isSelect == '')
			//isSelect = 'F';
			dumpCreditMemosFileData += 'T,' + creditId + ',';
			var colArrCredit = [];
			var colIndexCredit = 1;
			var scriptfieldcounterCredit = 1;

			for ( var cc = 0; cc < creditcolumns.length; cc++ ) {
				var colObj = creditcolumns[ cc ];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				var colVal = '';
				if ( colArrCredit.indexOf( colName ) == -1 ) {
					colArrCredit.push( colName )
				}
				else {
					colName = colName + colIndexCredit;
					colIndexCredit++;
				}

				if ( colLabel != 'Script Use DNR' ) {
					colVal = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, 'custpage_' + colName, i );

				}
				else {
					colVal = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, 'custpage_scriptfield' + scriptfieldcounterCredit, i );
					scriptfieldcounterCredit++;
				}
				if ( colVal != null && colVal != '' )
					colVal = colVal.replace( /,/g, '|' );
				dumpCreditMemosFileData += colVal + ',';
			}
			dumpCreditMemosFileData += request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i ) + ',';
			dumpCreditMemosFileData = dumpCreditMemosFileData.slice( 0, -1 ) + '\n';



			hasCreditMemos = true;
			var creditId = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, 'custpage_scriptfield3', i );
			var creditPayment = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i );
			var amountInCredit = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT + '_native', i );

			var backlinks = request.getLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, 'custpage_scriptfield2', i );
			if ( amountInCredit == null || amountInCredit == '' )
				amountInCredit = 0;
			var amountNeedToUpadteInInvoice = parseFloat( creditPayment ) + parseFloat( amountInCredit );


			if ( backlinks != null && backlinks != '' ) {
				backlinks = backlinks.replace( /,/g, '|' );
				ssSuccessCreditDataFile += creditId + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + backlinks + ',' + creditPayment + '\n';
				//ssSuccessDataFileCM += creditId+','+creditPayment+'\n';

			}
			else {
				backlinks = '';
				ssSuccessCreditDataFile += creditId + ',' + PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING + ',' + backlinks + ',' + creditPayment + '\n';
				//ssSuccessDataFileCM += creditId+','+creditPayment+'\n';

			}

			if ( !creditObj.hasOwnProperty( creditId ) ) {
				creditObj[ creditId ] = new Object();
				creditPayment = Number( creditPayment );
				creditObj[ creditId ].payment = creditPayment;

			}
			else {
				var existingobj = creditObj[ creditId ];
				var existingPayment = creditObj[ creditId ].payment
				existingPayment = parseFloat( existingPayment ) + parseFloat( creditPayment );
				existingPayment = Number( existingPayment );

				creditObj[ creditId ].payment = existingPayment;
			}
			totCremMemoSelected++;




		}

		var totalSelected = 0;
		var mainObj1 = null;
		//nlapiLogExecution('debug','mainObj',JSON.stringify(mainObj));
		var totalTransactions = [];
		if ( mainObj != '' && mainObj != null ) {

			mainObj1 = JSON.parse( JSON.stringify( mainObj ) );
			nlapiLogExecution( 'debug', 'mainObj', JSON.stringify( mainObj ) );

			for ( prop in mainObj ) {
				totalTransactions.push( prop );
				selectedInvoicesIdsWithPayment += prop + '_';
				//ssDataFile += prop+',1\n';
				transUnderProcessing.push( prop + '__' + invoiceType );
				totalSelected = parseFloat( totalSelected ) + parseFloat( 1 );

			}
		}
		if ( hasCreditMemos ) {
			nlapiLogExecution( 'debug', 'creditObj', JSON.stringify( creditObj ) );
			for ( prop in creditObj ) {
				totalTransactions.push( prop );
				selectedCreditMemoIdsWithPayment += prop + '_';
				//ssDataFile += prop+',2\n';
				transUnderProcessing.push( prop + '__' + creditMemoType );
				totalSelected = parseFloat( totalSelected ) + parseFloat( 1 );

			}
		}

		var customerPayment = null;
		var paymentId = null;
		var creditsApplied = [];
		/*if(!hasCreditMemos)
	   {	
		if (paymentLink == null || paymentLink == '')
		customerPayment = nlapiTransformRecord('customer', client, 'customerpayment');
	    else
		customerPayment = nlapiLoadRecord('customerpayment', paymentLink);
		//customerPayment.setFieldValue('customer',client);
		if (arAccount)
		customerPayment.setFieldValue('aracct',arAccount);
				if (currency)
		customerPayment.setFieldValue('currency',currency);
				if (date)
		customerPayment.setFieldValue('trandate',date);
				if (postingPeriod)
		customerPayment.setFieldValue('postingperiod',postingPeriod);
				if (memo)
		customerPayment.setFieldValue('memo',memo);
				if (lineOfBusiness)
		customerPayment.setFieldValue('class',lineOfBusiness);
				if (department)
		customerPayment.setFieldValue('department',department);
				if (office)
		customerPayment.setFieldValue('location',office);
		
		
		var lineCountOfInvoices=customerPayment.getLineItemCount('apply');
		var lineCountOfCredits=customerPayment.getLineItemCount('credit');
		
		
	
	nlapiLogExecution('debug','coming inside credit empty:')
	for(var i=1;lineCountOfInvoices > 0 && i<=lineCountOfInvoices;i++)
	{
		var invoiceId=customerPayment.getLineItemValue('apply','doc',i);
		if (mainObj.hasOwnProperty(invoiceId))
		{
			
				customerPayment.selectLineItem('apply',i);
				customerPayment.setCurrentLineItemValue('apply','apply','T');
				customerPayment.setCurrentLineItemValue('apply','amount',parseFloat(mainObj[invoiceId].payment));
				//+parseFloat(mainObj[invoiceId].invLineTaxAmt));
				customerPayment.commitLineItem('apply');
			}
			else
			{
				customerPayment.selectLineItem('apply',i);
				customerPayment.setCurrentLineItemValue('apply','apply','F');
				//customerPayment.setCurrentLineItemValue('apply','amount',mainObj[invoiceId].payment);
				customerPayment.commitLineItem('apply');
			}
		}
	
	
	
//this forloop commented initially	
	for(var c=1;lineCountOfCredits > 0 && c<=lineCountOfCredits;c++)
	{
		var creditId=customerPayment.getLineItemValue('credit','doc',c);
			if(creditObj.hasOwnProperty(creditId))
			{
				creditsApplied.push(creditId);
				customerPayment.selectLineItem('credit',c);
				customerPayment.setCurrentLineItemValue('credit','apply','T');
				customerPayment.setCurrentLineItemValue('credit','amount',creditObj[creditId].payment);
				customerPayment.commitLineItem('credit');
			}
			else
			{
				
				customerPayment.selectLineItem('credit',c);
				customerPayment.setCurrentLineItemValue('credit','apply','F');
				//customerPayment.setCurrentLineItemValue('credit','amount',creditObj[creditId].payment);
				customerPayment.commitLineItem('credit');
		
			}
		}
		
		if (creditsApplied.length > 0)
		{
			customerPayment.setFieldValues(FLD_CREDITS_APPLIED, creditsApplied);
			
		}
	
		paymentId=nlapiSubmitRecord(customerPayment,true,true);
		nlapiLogExecution('debug','paymentId',paymentId);
		}*/

		nlapiLogExecution( 'debug', 'totalSelected', totalSelected );


		/*var ssDataFileCreate=nlapiCreateFile('Selected_Invoices_List_For_Under_Processing_'+timeStamp+'.csv','CSV',ssDataFile);
		ssDataFileCreate.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
	    var ssDataFileID= nlapiSubmitFile(ssDataFileCreate);*/


		var ssSuccessDataFileCreate = nlapiCreateFile( 'Selected_Invoices_List_For_Processing_' + timeStamp + '.csv', 'CSV', ssSuccessDataFile );
		ssSuccessDataFileCreate.setFolder( PAYMENT_APPLICATION_CSV_FOLDER_ID );
		var ssSuccessDataFileID = nlapiSubmitFile( ssSuccessDataFileCreate );

		var ssSuccessCreditsDataFileCreate = nlapiCreateFile( 'Selected_Credits_List_For_Processing_' + timeStamp + '.csv', 'CSV', ssSuccessCreditDataFile );
		ssSuccessCreditsDataFileCreate.setFolder( PAYMENT_APPLICATION_CSV_FOLDER_ID );
		var ssSuccessCreditDataFileID = nlapiSubmitFile( ssSuccessCreditsDataFileCreate );


		var invoicesforCRCreation = nlapiCreateFile( 'Payment_Application_Linked_Invoices_' + timeStamp + '.csv', 'CSV', ssSuccessDataFileInv );
		invoicesforCRCreation.setFolder( PAYMENT_APPLICATION_CSV_FOLDER_ID );
		var invoicesforCRCreationID = nlapiSubmitFile( invoicesforCRCreation );


		var totLinkedTransactionsToProcess = 0;
		for ( var cmprop in creditObj ) {
			try {
				var creditAmount = creditObj[ cmprop ].payment;
				//var creditmemorec=nlapiLoadRecord('creditmemo',cmprop);

				//var applyCountCM=creditmemorec.getLineItemCount('apply');
				if ( parseFloat( creditAmount ) == 0 ) {
					totLinkedTransactionsToProcess++;
				}
				else {
					for ( var invprop in mainObj1 ) {
						var invAmount = mainObj1[ invprop ].payment;
						var invLineTaxAmt = mainObj1[ invprop ].invLineTaxAmt;

						if ( parseFloat( creditAmount ) < parseFloat( invAmount ) && parseFloat( creditAmount ) > 0 ) {
							//for(cm=1;cm<=applyCountCM;cm++)
							//{
							//var invoiceIdOnCM=creditmemorec.getLineItemValue('apply','doc',cm);
							//if(parseInt(invprop) == parseInt(invoiceIdOnCM))
							//{
							totLinkedTransactionsToProcess++;
							var remainingInvAmount = parseFloat( invAmount ) - parseFloat( creditAmount );
							//remainingInvAmount=Math.round(remainingInvAmount*100)/100;
							mainObj1[ invprop ].payment = remainingInvAmount;
							creditAmount = 0;
							//}
							//}
						}
						else if ( parseFloat( creditAmount ) >= parseFloat( invAmount ) && parseFloat( invAmount ) > 0 ) {
							//for(cm=1;cm<=applyCountCM;cm++)
							//{
							//var invoiceIdOnCM=creditmemorec.getLineItemValue('apply','doc',cm);
							//if(parseInt(invprop) == parseInt(invoiceIdOnCM))
							//{
							totLinkedTransactionsToProcess++;
							creditAmount = parseFloat( creditAmount ) - parseFloat( invAmount );
							//creditAmount=Math.round(creditAmount*100)/100;
							mainObj1[ invprop ].payment = 0;
							//}
							//}
						}



					}
				}
			} catch ( e ) {
				if ( e instanceof nlobjError ) {
					nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
					errorLog += 'System error :\n' + e.getDetails();
				} else {
					nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
					errorLog += 'Unexpected error :\n' + e.toString();
				}
				break;
			}
		}

		var invoicesAppliedFileData = ssSuccessDataFileInv.split( '\n' );
		invoicesAppliedFileData = invoicesAppliedFileData.slice( 0, -1 );
		nlapiLogExecution( 'debug', 'invoicesAppliedFileData Length', invoicesAppliedFileData.length );

		totLinkedTransactionsToProcess = parseInt( totLinkedTransactionsToProcess ) + parseInt( invoicesAppliedFileData.length ) - 1;




		var customRec = nlapiCreateRecord( CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG );
		//var customRec=nlapiLoadRecord(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,1);
		customRec.setFieldValue( 'name', 'Update Payment Application' + timeStamp );
		customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_CREATED_BY, currentUser );
		customRec.setFieldValue( FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS, totLinkedTransactionsToProcess );

		if ( paymentId != null && paymentId != '' ) {

			customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_LINK, paymentId );

		}
		else {
			if ( paymentLink != null && paymentLink != '' )
				customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_LINK, paymentLink );
		}
		customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_STATUS, CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS );
		customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_CLIENT, slclient );
		//customRec.setFieldValue(FLD_CUSTOMER_PAYMENT_APPLICATION_CLIENT,slclient);
		customRec.setFieldValue( FLD_TOT_CHILD_INVCS_TO_PROCESS, totInvSelected );
		customRec.setFieldValue( FLD_TOT_CREDITS_TO_PROCESS, totCremMemoSelected );
		customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_CURRENCY, slcurrency );
		if ( transUnderProcessing != null && transUnderProcessing != '' ) {
			customRec.setFieldValue( FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING, transUnderProcessing.length );
			customRec.setFieldValue( FLD_TOTAL_UNDER_PROCESSING_STATUS, CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY );
			customRec.setFieldValue( FLD_TOTAL_UNDER_PROCESSED, transUnderProcessing.length );
			customRec.setFieldValue( FLD_TOTAL_UNDER_PROCESSING_FAILED, 0 );
			customRec.setFieldValue( FLD_TOTAL_UNDER_PROCESSING_PENDING, 0 );
			customRec.setFieldValue( FLD_TOTAL_UNDER_PROCESSING_PERCENT, 100 );
		}
		if ( totInvoiceSelected.length > 0 ) {
			totInvoiceSelected = eliminateDuplicates( totInvoiceSelected );
			customRec.setFieldValues( FLD_TOTAL_INVOICES_SELECTED, totInvoiceSelected );
			customRec.setFieldValue( FLD_TRANSACTION_INTERNAL_IDS, totInvoiceSelected + '' );
		}

		if ( parseFloat( totInvSelected ) > 0 ) {
			var dumpInvoicesFile = nlapiCreateFile( 'Suitelet_Invoices_' + timeStamp + '.csv', 'CSV', dumpInvoicesFileData );
			dumpInvoicesFile.setFolder( PAYMENT_APPLICATION_CSV_FOLDER_ID );
			var dumpInvoicesFileID = nlapiSubmitFile( dumpInvoicesFile );
			if ( dumpInvoicesFileID != null && dumpInvoicesFileID != '' )
				customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_FILE, dumpInvoicesFileID );
		}

		if ( parseFloat( totCremMemoSelected ) > 0 ) {
			var dumpCreditMemosFile = nlapiCreateFile( 'Suitelet_Credit_Memos_' + timeStamp + '.csv', 'CSV', dumpCreditMemosFileData );
			dumpCreditMemosFile.setFolder( PAYMENT_APPLICATION_CSV_FOLDER_ID );
			var dumpCreditMemosFileID = nlapiSubmitFile( dumpCreditMemosFile );
			if ( dumpCreditMemosFileID != null && dumpCreditMemosFileID != '' )
				customRec.setFieldValue( FLD_CUSTOMER_PAYMENT_APPLICATION_FILE_CM, dumpCreditMemosFileID );
		}

		var paymentApplicationLogID = nlapiSubmitRecord( customRec, true, true );
		nlapiLogExecution( 'debug', 'paymentApplicationLogID', paymentApplicationLogID );
		var randomNum = new Date();
		var randomText = randomNum.getTime() + 'I';


		//if(totalUpdatedToProcessing){
		var params = {};
		params[ SPARAM_RANDOM_TEXT ] = randomText;
		params[ SPARAM_INVOICE_DETAIL_OBJ_FORM ] = JSON.stringify( mainObj );
		params[ SPARAM_CREDIT_DETAIL_OBJ_FORM ] = JSON.stringify( creditObj );
		params[ SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS ] = totalSelected;
		params[ SPARAM_SELECTED_INVOICE_LIST ] = selectedInvoicesIdsWithPayment;
		params[ SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID ] = paymentApplicationLogID;
		params[ SPARAM_PAYMENT_APPLICATION_FILE_ID ] = totalTransactions; //this file should be used in SC #1, backend purpose
		params[ SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID ] = ssSuccessDataFileID; //needed for direct update, UI display
		params[ SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM ] = ssSuccessCreditDataFileID; //needed for direct update, UI display
		params[ SPARAM_PAYMENT_APPLICATION_INV_FILE ] = invoicesforCRCreationID; //other updates related to amounts, backend purpose

		if ( paymentId != null && paymentId != '' ) {
			params[ SPARAM_PAYMENT_NEED_TO_UPDATE ] = paymentId;
		}
		else {
			if ( paymentLink != null && paymentLink != '' )
				params[ SPARAM_PAYMENT_NEED_TO_UPDATE ] = paymentLink;

		}

		if ( dataForPayment )
			params[ SPARAM_DATA_FOR_PAYMENT ] = dataForPayment;
		nlapiScheduleScript( SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION, null, params );
		//}
		return paymentApplicationLogID;
	}

	catch ( e ) {
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}



function eliminateDuplicates ( arr ) {
	var i,
		len = arr.length,
		out = [],
		obj = {};

	for ( i = 0; i < len; i++ ) {
		obj[ arr[ i ] ] = 0;
	}
	for ( i in obj ) {
		out.push( i );
	}
	return out;
}


function sortWithIndeces ( toSort ) {
	for ( var i = 0; i < toSort.length; i++ ) {
		toSort[ i ] = [ toSort[ i ], i ];
	}
	toSort.sort( function ( left, right ) {
		return left[ 0 ] < right[ 0 ] ? -1 : 1;
	} );
	toSort.sortIndices = [];
	for ( var j = 0; j < toSort.length; j++ ) {
		toSort.sortIndices.push( toSort[ j ][ 1 ] );
		toSort[ j ] = toSort[ j ][ 0 ];
	}
	return toSort;
}



// 03-05-2023 added by shravan kumar
function getAllSearchResults_Final ( record_type, filters, columns ) {
	var search = nlapiCreateSearch( record_type, filters, columns );
	search.setIsPublic( true );

	var searchRan = search.runSearch()
		, bolStop = false
		, intMaxReg = 1000
		, intMinReg = 0
		, result = [];

	while ( !bolStop && nlapiGetContext().getRemainingUsage() > 10 ) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults( intMinReg, intMaxReg );

		result = searchUnion( result, extras );
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if ( extras.length < 1000 ) {
			bolStop = true;
		}
	}

	return result;
}

function getAllSearchResults ( record_type, filters, columns ) {
	var rtype = record_type;
	if ( record_type.indexOf( '__count' ) > 0 || record_type.indexOf( '__applied' ) > 0 ) {
		rtype = record_type.substring( 0, record_type.indexOf( '__' ) );
	}
	nlapiLogExecution( 'debug', 'getAllSearchResults', 'record_type = ' + record_type + ', rtype = ' + rtype );

	var search = nlapiCreateSearch( rtype, filters, columns );
	search.setIsPublic( true );

	var searchRan = search.runSearch()
		, bolStop = false
		, intPageSize = parseInt( SRCH_SUMMARY.pageSize )
		, intStepSize = 1000
		, intMaxReg = intPageSize
		, intMinReg = ( SRCH_SUMMARY.hasOwnProperty( record_type ) == true ? SRCH_SUMMARY[ record_type ].index : 0 )
		, result = [];

	if ( record_type.indexOf( '__applied' ) > 0 ) {
		intMinReg = 0;
	}

	if ( SRCH_SUMMARY.hasOwnProperty( record_type ) == true ) {
		// SRCH_SUMMARY[record_type].index = intMinReg;
		while ( bolStop == false ) {
			// var srchRec = SRCH_SUMMARY[record_type];
			// intMinReg = (record_type == SRCH_TYPE) ? SRCH_INDEX : 0; //SRCH_SUMMARY[record_type].index;

			intMaxReg = parseInt( intMinReg ) +
				parseInt(
					intPageSize > intStepSize ?
						( ( intPageSize - result.length ) >= intStepSize ? intStepSize : intPageSize ) :
						intPageSize
				);

			nlapiLogExecution( 'debug', 'getAllSearchResults',
				'1: record_type = ' + record_type +
				', intMinReg = ' + intMinReg +
				', intMaxReg = ' + intMaxReg +
				', intPageSize = ' + intPageSize +
				', intStepSize = ' + intStepSize
			);

			var extras = searchRan.getResults( intMinReg, intMaxReg );
			result = searchUnion( result, extras );

			if ( extras.length < intStepSize || result.length == intPageSize ) {
				bolStop = true;
			}
			else {
				intMinReg = parseInt( intMinReg ) + parseInt( intStepSize );
			}

			// Find out if there are more results
			if ( result.length == intPageSize ) {
				// intMinReg = intMaxReg;
				// intMaxReg += intStepSize;
				extras = searchRan.getResults( intMaxReg, intMaxReg + 1 );
				nlapiLogExecution( 'debug', 'getAllSearchResults', '2: extras.length = ' + extras.length );
				if ( extras.length > 0 ) {
					SRCH_SUMMARY[ record_type ].more = true;
				}
			}

			nlapiLogExecution( 'debug', 'getAllSearchResults', JSON.stringify( SRCH_SUMMARY ) );
		}
	}
	else {
		intMaxReg = intStepSize;
		while ( !bolStop && nlapiGetContext().getRemainingUsage() > 10 ) {
			// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
			var extras = searchRan.getResults( intMinReg, intMaxReg );

			result = searchUnion( result, extras );
			intMinReg = intMaxReg;
			intMaxReg += intStepSize;
			// If the execution reach the the last result set stop the execution
			if ( extras.length < intStepSize ) {
				bolStop = true;
			}
		}
	}

	return result;
}

function numberWithCommas ( x ) {
	return x.toString().replace( /\B(?=(\d{3})+(?!\d))/g, "," );
}

function searchUnion ( target, array ) {
	return target.concat( array ); // TODO: use _.union
}