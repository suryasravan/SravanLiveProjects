/**
	 * Script Name : Appf-VVCCP Approve Button UE
	 * Script Type : User Event
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			 Debendra Panigrahi		This script displays Approve, Reject and Refresh buttons
	 *
	 * Company 	 : Appficiency. 
	 */
var SUITELET_VVCCP_APPROVE_HELPER_SCRIPT_ID='customscript_vvccp_helper_suitelet';
var SUITELET_VVCCP_APPROVE_HELPER_DEPLOY_ID='customdeploy_vvccp_helper_suitelet';
var BTN_APPROVE='custpage_approve';
var BTN_REJECT = 'custpage_reject';
var BTN_REFRESH = 'custpage_refresh';

var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills';	
var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred';
var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
var FLD_PROCESSED_PERCENT	     			='custrecord_appf_vvccp_log_percent';
var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by';
var FLD_STATUS	     						='custrecord_appf_vvccp_log_status';
var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file';
var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file';
var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log';
var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';
var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
var FLD_APPROVAL_TRIGGERED = 'custrecord_approval_button_triggered';

var FLD_VVCCP_BATCH_UNDER_PROCESSING_DONE = 'custrecord_appf_vvccp_underproc_done';	 


var FLD_APPROVAL_STATUS_APPROVED=2;
var FLD_APPROVAL_STATUS_OPEN=11;
var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
var FLD_APPROVAL_STATUS_REJECTED=3;
function beforeLoad(type,form,request)
{
  	try
      {
        if(type == 'view')
		{
		 
		var recId = nlapiGetRecordId();
		var recType = nlapiGetRecordType();
		var record = nlapiLoadRecord(recType, recId);
		
		
		var toProcess = record.getFieldValue(FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS);
		var processed =  record.getFieldValue(FLD_TOTAL_VVCCP_RECORDS_PROCESSED);
		if (processed == null || processed == '')
			processed = 0;
		
		var approvalstatus = record.getFieldValue(FLD_APPROVAL_STATUS);
		var billAndCreditFileId=record.getFieldValue(FLD_DATA_FILE);
          var approvalTriggered = record.getFieldValue(FLD_APPROVAL_TRIGGERED);
          var underProcessingcompleted = record.getFieldValue(FLD_VVCCP_BATCH_UNDER_PROCESSING_DONE);
          
		var refreshURL = nlapiResolveURL('RECORD', recType, recId);
		/*
		if (approvalstatus != FLD_APPROVAL_STATUS_APPROVED && approvalTriggered != 'T')
		{
		var url=nlapiResolveURL('SUITELET',SUITELET_VVCCP_APPROVE_HELPER_SCRIPT_ID,SUITELET_VVCCP_APPROVE_HELPER_DEPLOY_ID);
		url+='&billAndCreditFileId='+billAndCreditFileId+'&recId='+recId;
				var rejecturl =url+ '&stype=reject';

		url += '&stype=approve';
		var approvebtn = form.addButton(BTN_APPROVE,'Approve','window.open(\''+url+'\',\'_self\')');
		var rejectbtn = form.addButton(BTN_REJECT,'Reject','window.open(\''+rejecturl+'\',\'_self\')');
				

		
				
				

		
          if (underProcessingcompleted != 'T')
		  {
          approvebtn.setDisabled(true);
		   rejectbtn.setDisabled(true);
		  }
          else
		  {
            approvebtn.setDisabled(false); 
			            rejectbtn.setDisabled(false); 

		  }
		}
		*/
          if (processed != toProcess && (approvalstatus != FLD_APPROVAL_STATUS_REJECTED))
				var refreshbtn = form.addButton(BTN_REFRESH,'Refresh','window.open(\''+refreshURL+'\',\'_self\')');
	    }
      }
  catch(e)
    {
      nlapiLogExecution( 'DEBUG', 'Error details:', e.toString());
    }
}	 