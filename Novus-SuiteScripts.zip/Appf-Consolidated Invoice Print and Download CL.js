/*Script Name: Appf-Consolidated Invoice Print/Download CL
 *Script Type: Client Script
 *Description: This script is used to do client side validations for "Appf-Consolidated Invoice Print Download" suitelet.
 *Company 	 : Appficiency.
 */

var SL_FLD_CLIENT = 'custpage_client';
var SL_FLD_PARENT_CLIENT = 'custpage_pclient';
var SL_FLD_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_MEDIA_SEGMENT = 'custpage_media_segment';
var SL_FLD_FROM_DATE = 'custpage_from_date';
var SL_FLD_TO_DATE = 'custpage_to_date';
var SL_FLD_DUE_FROM_DATE = 'custpage_from_due_date';
var SL_FLD_DUE_TO_DATE = 'custpage_to_due_date';
var SL_FLD_LINE_OF_BUSINESS = 'custpage_line_of_business';
var SL_FLD_CURRENCY = 'custpage_currency';
var SL_FLD_CONTRACT = 'custpage_contract';
var SL_FLD_PDF_TEMPLATE = 'custpage_pdf_template';
var SL_FLD_EMAIL_TEMPLATE = 'custpage_email_template';
var SL_FLD_EMAIL_SENT = 'custpage_email_sent';

var SL_SUBLIST = 'custpage_custom_line';
var SL_COL_MARK = 'custpage_mark';

var SCRIPT_SL_CONSOLIDATED_INVOICE_PDF_ZIP = 'customscript_appf_consoli_inv_pdf_zip';
var DEPLOY_SL_CONSOLIDATED_INVOICE_PDF_ZIP = 'customdeploy_appf_consoli_inv_pdf_zip';

var SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD = 'customscript_appf_consolidated_inv_pdf';
var DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD = 'customdeploy_appf_consolidated_inv_pdf';

function applyFilters () {
    var client = nlapiGetFieldValue( SL_FLD_CLIENT );
    if ( client == null || client == '' )
        client = '';
    var emailTemplate = nlapiGetFieldValue( SL_FLD_EMAIL_TEMPLATE );
    if ( emailTemplate == null || emailTemplate == '' )
        emailTemplate = '';
    var emailSent = nlapiGetFieldValue( SL_FLD_EMAIL_SENT );
    if ( emailSent == null || emailSent == '' )
        emailSent = '';

    var parentClient = nlapiGetFieldValue( SL_FLD_PARENT_CLIENT );
    if ( parentClient == null || parentClient == '' )
        parentClient = '';

    var subsidiary = nlapiGetFieldValue( SL_FLD_SUBSIDIARY );
    if ( subsidiary == null || subsidiary == '' )
        subsidiary = '';

    var mediasegment = nlapiGetFieldValue( SL_FLD_MEDIA_SEGMENT );
    if ( mediasegment == null || mediasegment == '' )
        mediasegment = '';

    var dateFrom = nlapiGetFieldValue( SL_FLD_FROM_DATE );
    if ( dateFrom == null || dateFrom == '' )
        dateFrom = '';

    var dateTo = nlapiGetFieldValue( SL_FLD_TO_DATE );
    if ( dateTo == null || dateTo == '' )
        dateTo = '';

    var fromDueDate = nlapiGetFieldValue( SL_FLD_DUE_FROM_DATE );
    if ( fromDueDate == null || fromDueDate == '' )
        fromDueDate = '';

    var toDueDate = nlapiGetFieldValue( SL_FLD_DUE_TO_DATE );
    if ( toDueDate == null || toDueDate == '' )
        toDueDate = '';

    var lineofbusiness = nlapiGetFieldValue( SL_FLD_LINE_OF_BUSINESS );
    if ( lineofbusiness == null || lineofbusiness == '' )
        lineofbusiness = '';

    var currency = nlapiGetFieldValue( SL_FLD_CURRENCY );
    if ( currency == null || currency == '' )
        currency = '';

    var contract = nlapiGetFieldValue( SL_FLD_CONTRACT );
    if ( contract == null || contract == '' )
        contract = '';

    var pdfTemplate = nlapiGetFieldValue( SL_FLD_PDF_TEMPLATE );
    if ( pdfTemplate == null || pdfTemplate == '' )
        pdfTemplate = '';

    window.onbeforeunload = null;
    var suiteletURL = nlapiResolveURL( 'SUITELET', SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD, DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD );
    suiteletURL = suiteletURL + '&subs=' + subsidiary + '&dtFrom=' + dateFrom + '&dtTo=' + dateTo + '&ddtFrom=' + fromDueDate + '&ddtTo=' + toDueDate + '&client=' + client + '&pclient=' + parentClient + '&currency=' + currency + '&mediasegment=' + mediasegment + '&lineofbusiness=' + lineofbusiness + '&contract=' + contract + '&pdftemplate=' + pdfTemplate + '&emailTemplate=' + emailTemplate + '&emailSent=' + emailSent + '&applyFils=T';
    //alert(suiteletURL);
    window.open( suiteletURL, '_self' );
}

function clientFieldChanged ( type, name, linenum ) {
    if ( name == "custpage_pageid" ) {
        var rowCount = nlapiGetFieldValue( "custpage_pageid" );
        //alert(rowCount);
        var url = window.location.href;
        //  url = url + '&pageNo=' + rowCount;
        if ( url.includes( 'pageNo' ) ) {
            var currenturl1 = url.split( '&pageNo=' );
            currenturl1 = currenturl1[ 0 ] + '&pageNo=' + parseInt( rowCount )
            window.open( currenturl1, "_self" );
        } else {
            url = url + '&pageNo=' + parseInt( rowCount )
            window.open( url, '_self' );
        }
    }
}

function unmarkAll () {
    var count = nlapiGetLineItemCount( SL_SUBLIST );
    for ( var i = 1; i <= count; i++ ) {
        nlapiSetLineItemValue( SL_SUBLIST, SL_COL_MARK, i, 'F' );
    }

}

function markAll () {
    var count = nlapiGetLineItemCount( SL_SUBLIST );
    for ( var c = 1; c <= count; c++ ) {
        nlapiSetLineItemValue( SL_SUBLIST, SL_COL_MARK, c, 'T' );

    }

}

function process ( action ) {
    var counter = 0;
    var count = nlapiGetLineItemCount( SL_SUBLIST );
    for ( var c = 1; c <= count; c++ ) {
        var selectedConter = nlapiGetLineItemValue( SL_SUBLIST, SL_COL_MARK, c );
        if ( selectedConter == 'T' )
            counter++;
    }
    if ( parseInt( counter ) > 0 ) {
        if ( action == 'email' )
            var isConfirm = confirm( "Are you sure you want to email!" );
        else
            var isConfirm = confirm( "Are you sure you want to download!" );
        if ( isConfirm ) {
            var emailTemplate = nlapiGetFieldValue( SL_FLD_EMAIL_TEMPLATE );
            if ( emailTemplate == null || emailTemplate == '' && action == 'email' ) {
                alert( 'Please select Email Template' );
            }
            else {
                var loadSS = nlapiLoadSearch( null, 1036 );
                var filts = loadSS.getFilters();
                var columns = loadSS.getColumns();
                var pdfDetailsArr = [];
                if ( columns != null && columns != '' ) {
                    var count = nlapiGetLineItemCount( SL_SUBLIST );
                    for ( var i = 1; i <= count; i++ ) {
                        var mark = nlapiGetLineItemValue( SL_SUBLIST, SL_COL_MARK, i );
                        if ( mark == 'T' ) {
                            var internalId = nlapiGetLineItemValue( SL_SUBLIST, 'custpage_internalid', i );
                            pdfDetailsArr.push( internalId );
                            /*var obj = {};
                            var scriptUseDNRIndex=1;
                            obj.internalId = nlapiGetLineItemValue(SL_SUBLIST, 'custpage_internalid', i);
                            for(var c=0;c<columns.length;c++)
                            {
                                var colObj = columns[c];
                                var columnName = colObj.getName();
                                var colLabel = colObj.getLabel();
                                if(colLabel == 'Script Use DNR')
                                {
                                    var label = 'custpage_scriptusednr'+scriptUseDNRIndex;
                                    var colValue = nlapiGetLineItemValue(SL_SUBLIST,'custpage_scriptusednr'+scriptUseDNRIndex, i);
                                     obj[label] = nlapiEscapeXML(colValue);
                                     scriptUseDNRIndex++;
                                }
                                else
                                {
                                    var colValue = nlapiGetLineItemValue(SL_SUBLIST, 'custpage_'+columnName, i); 
                                    obj[colLabel] = nlapiEscapeXML(colValue);						
                                }	
                                                     
                            }
                            pdfDetailsArr.push(obj);*/

                        }

                    }
                }

                console.log( pdfDetailsArr );
                if ( pdfDetailsArr.length > 0 ) {
                    try {
                        var url = nlapiResolveURL( 'SUITELET', SCRIPT_SL_CONSOLIDATED_INVOICE_PDF_ZIP, DEPLOY_SL_CONSOLIDATED_INVOICE_PDF_ZIP );
                        url += '&recid=' + pdfDetailsArr + '&action=' + action + '&emailTemplate=' + emailTemplate;
                        window.open( url, '_blank' );
                    } catch ( e ) { console.log( "File doesn't generated successfully." ); }
                }
            }
        }
    }
    else {
        alert( "Please select atleast one record to proceed." )
    }
}

