/*Script Name: Appf-Refresh Credit Creation Log UE
 *Script Type: User Event
 *Event Type : Before Load
 *Description: 
 *Company 	 : Appficiency.
 */

var CUSTOM_RECORD_CREDIT_CREATION_LOG='customrecord_appf_cust_crd_log';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_cst_crd_perc_processed';

var CUSTOM_RECORD_VENDOR_CREDIT_CREATION_LOG='customrecord_appf_vend_crd_log';
var FLD_VEND_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_vend_crd_perc_processed';

var BTN_REFRESH = 'custpage_refresh';
var BTN_CLIENT_CREDIT_SUITELET = 'custpage_client_credit_suitelet';
var BTN_VENDOR_CREDIT_SUITELET = 'custpage_vendor_credit_suitelet';

var SCRIPT_SL_CLIENT_CREDIT_SUITELET='customscript_appf_client_credit_sl';
var DEPLOY_SL_CLIENT_CREDIT_SUITELET='customdeploy_appf_client_credit_sl';

var SCRIPT_SL_VENDOR_CREDIT_SUITELET='customscript_appf_vendor_credit_sl';
var DEPLOY_SL_VENDOR_CREDIT_SUITELET='customdeploy_appf_vendor_credit_sl';

var FLD_SO_BACKLINKING_PERCENT = 'custrecord_appf_so_backlink_percent';
var FLD_PO_BACKLINKING_PERCENT = 'custrecord_appf_po_backlink_percent';

function refreshButton(type, form, request)
{
	
	    if(type=='view')
	    {
          try{
	    var id = nlapiGetRecordId();
	    var recType = nlapiGetRecordType();
	    nlapiLogExecution('debug','recType',recType);

	    if(recType == CUSTOM_RECORD_CREDIT_CREATION_LOG)
	    {
	    var processedPercentage=nlapiGetFieldValue(FLD_SO_BACKLINKING_PERCENT);
      
	    if(processedPercentage == null || processedPercentage == '' || parseFloat(processedPercentage) < 100){ 
		 var url=nlapiResolveURL('RECORD', CUSTOM_RECORD_CREDIT_CREATION_LOG,id);
		form.addButton(BTN_REFRESH,'Refresh','window.open(\''+url+'\',\'_self\')');
	    }
	    else{
	    	var suiteletURL=nlapiResolveURL('SUITELET', SCRIPT_SL_CLIENT_CREDIT_SUITELET,DEPLOY_SL_CLIENT_CREDIT_SUITELET);
	 		form.addButton(BTN_CLIENT_CREDIT_SUITELET,'Client Credit Suitelet','window.open(\''+suiteletURL+'\',\'_self\')');
	    }
          }
	    if(recType == CUSTOM_RECORD_VENDOR_CREDIT_CREATION_LOG)
	    {
	    	 var processedPercentage=nlapiGetFieldValue(FLD_PO_BACKLINKING_PERCENT);
	         
	 	    if(processedPercentage == null || processedPercentage == '' || parseFloat(processedPercentage) < 100){ 
	 		 var url=nlapiResolveURL('RECORD', CUSTOM_RECORD_VENDOR_CREDIT_CREATION_LOG,id);
	 		form.addButton(BTN_REFRESH,'Refresh','window.open(\''+url+'\',\'_self\')');
	 	    }
	 	    else{
	 	    	var suiteletURL=nlapiResolveURL('SUITELET', SCRIPT_SL_VENDOR_CREDIT_SUITELET,DEPLOY_SL_VENDOR_CREDIT_SUITELET);
		 		form.addButton(BTN_VENDOR_CREDIT_SUITELET,'Vendor Credit Suitelet','window.open(\''+suiteletURL+'\',\'_self\')');
	 	    }
	    }
          }catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
	}
}