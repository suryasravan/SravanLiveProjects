/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : This script handles all the validations required on a 'Pending Approval' sales order from saved search results and marks as Success, sets the contract and approves the order if all validations are successful
4/24/2020 v2 Sravan Added Additional validation of PWP check on line items
5/13/2020 v3 Sravan Added logic to set PO Vendor and PO Rate to chck if this resolves Item Options Error in integration
8/10/2020 v4 MJ De Asis added Logic to copy Start Date Actual to Start Date RR
9/02/2020 v5 All Order validations are moved to saved search, remove the logic in the script and only check needed fields
9/8/2020  v6 COnvert line level error validation into summary
10/21/2020 v7 Added Validation for OOH to include make Ship To field Mandatory
* Company     : Appficiency Inc.
*/
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_CONTRACT_MEDIA_TYPE = 'custrecord_appf_contract_mediatype';
var FLD_CONTRACT_END_DATE = 'custrecord_appf_contract_end_date';
var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_SO_ORDER_VALIDATION_STATUS = 'custbody_appf_orderval_status';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020
var FLD_VENDOR_LINE = 'custcol_appf_po_vendor_name';
var FLD_BILLING_SCHEDULE_LINE = 'billingschedule';
var SPARAM_MEDIA_SALES_ORDERS_SS = 'custscript_appf_media_type_so_ss_cu';
var SPARAM_SS_FILE_ID = 'custscript_appf_ss_file_id_cu';
var SPARAM_INDEX = 'custscript_appf_line_index_cu';
var SPARAM_SS_FILE_NAME = 'custscript_appf_ss_file_name_cu';
var FOLDER_ID = '-15';
var FLD_CONTRACT_DEPT = 'custrecord_appf_contract_department';
var FLD_CONTRACT_LOB = 'custrecord_appf_contract_lineofbusiness';
var FLD_CONTRACT_POP_REQUIRED = 'custrecord_appf_contract_pop_required';
var FLD_COL_POP_REQUIRED = 'custcol_appf_print_poprequired';
var FLD_COL_CORP_OWNER = 'custcol_appf_corporateowner';
var FLD_COL_PWP = 'custcol_appf_pwp_custom_record';
var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var BUYING_SYSTEM_PRINT = '1';
var PLACEHOLDER = '1122';
//Include Custom Forms ['Novus - Sales Order (Non-Media)']
var INCLUDE_CUSTOM_FORMS = ['156', '143', '149', '123', '141'];

var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_OOH_ID = 'custbody_appf_ooh_ns_sss';
var FLD_SO_SPOT_ID = 'custbody_appf_spot_ns_sss';

/// v7
var BUYING_SYSTEM_OOH = '2';
var FLD_COL_SHIPTO = 'shippingaddress';
var FLD_COL_SOLINEID = 'custcol_appf_line_id';
var ITEM_FLD_CANBEFULFILLED = 'isfulfillable';

function get_or_create_CSVFile(existingDataFile, mediaSOSS, filename) {
	var mediaSOSSObj = nlapiLoadSearch(null, mediaSOSS);
	var filters = mediaSOSSObj.getFilters();
	var columns = mediaSOSSObj.getColumns();
	var ssType = mediaSOSSObj.getSearchType();
	var mediaSOSSResults = getAllSearchResults(ssType, filters, columns);
	nlapiLogExecution('debug', 'mediaSOSSResults', mediaSOSSResults.length + ' filename= '+filename);
	var fileId = null;
	if (existingDataFile == null || existingDataFile == '') {
		if (mediaSOSSResults != null && mediaSOSSResults != '') {
			//var mediaSOSSResultsData = 'Record ID, Client ID, Client Name, Date, Buying System, Buying System Name\n';
			var mediaSOSSResultsData = 'Record ID, Client ID, Client Name, Date, Buying System, Buying System Name, (Client Contract)Prop Required\n'; //v5 added 9/2/2020
			for (var s = 0; s < mediaSOSSResults.length; s++) {
				var col = mediaSOSSResults[s];
				var recType = col.getRecordType();
				var recId = col.getId();
				var client = col.getValue('entity');
				var clientName = col.getText('entity');
				if (clientName != null && clientName != '') clientName = clientName.replace(/,/g, ';');
				var date = col.getValue('trandate');
				var buyingSys = col.getValue(FLD_SO_BUYING_SYSTEM);
				var buyingSysName = col.getText(FLD_SO_BUYING_SYSTEM);
				var propReq = col.getValue(FLD_CONTRACT_POP_REQUIRED, FLD_SO_CLIENT_CONTRACT); //v5 added 9/2/2020
				if (buyingSysName != null && buyingSysName != '') buyingSysName = buyingSysName.replace(/,/g, ';');
				//mediaSOSSResultsData += recId +','+client+','+clientName+','+date+','+buyingSys+','+buyingSysName+'\n';
				mediaSOSSResultsData += recId + ',' + client + ',' + clientName + ',' + date + ',' + buyingSys + ',' + buyingSysName + ',' + propReq + '\n'; //v5 added 9/2/2020
			}
			nlapiLogExecution('debug', 'mediaSOSSResultsData', mediaSOSSResultsData);
			var ssResultsFile = nlapiCreateFile(filename, 'CSV', mediaSOSSResultsData);
			ssResultsFile.setFolder(FOLDER_ID);
			fileId = nlapiSubmitFile(ssResultsFile);
			nlapiLogExecution('debug', 'fileId', fileId);
		}
	} else {
		fileId = existingDataFile;
	}
	return fileId;
}

function paddedString(string_to_pad, number_to_pad) {
	var padded_string = string_to_pad + ''; // convert to string
	while (padded_string.length < number_to_pad) {
		padded_string = '0' + padded_string;
	}
	return padded_string;
}

function getVendorId(entity_name) {
	var rs = nlapiSearchRecord('vendor', null,
				[
					new nlobjSearchFilter('entityid', null, 'is', entity_name)
				], []) || [];
	if (rs.length > 0) {
		return rs[0].getId();
	}
	return null;
}

function setVendorPlaceholder(so_id) {
	var salesOrderRec = nlapiLoadRecord('salesorder', so_id, {recordmode: 'dynamic'});
	var customForm = salesOrderRec.getFieldValue('customform');
	var subsidiary = salesOrderRec.getFieldValue('subsidiary') == '7' ? 'CA':'US';
	// Check if form selected is in the script params
	if (INCLUDE_CUSTOM_FORMS.indexOf('customForm') == -1) {
		try {
			var itemCount = salesOrderRec.getLineItemCount('item');
			for (var k = 1; k<= itemCount; k++) {
				var nQty = salesOrderRec.getLineItemValue('item', 'quantity', k);
				var fakeVendor = 'Placeholder' + subsidiary + ' ' + paddedString(k, 4);
				nlapiLogExecution('DEBUG', 'Placeholder Vendor Name', fakeVendor);
				var fakeVendorId = getVendorId(fakeVendor);
				nlapiLogExecution('DEBUG', 'Placeholder Vendor Id', fakeVendorId);

				var existingcreatepo = salesOrderRec.getLineItemValue('item', 'createpo', k);
				var existingpo = salesOrderRec.getLineItemValue('item', 'poid', k);
				nlapiLogExecution('DEBUG', 'PO ID', existingpo + ' nQty='+nQty);

				if (existingpo == null || existingpo == '' ) {
					if(parseInt(nQty) > 0){
						salesOrderRec.selectLineItem('item', k);
						salesOrderRec.setCurrentLineItemValue('item', 'povendor', fakeVendorId);
						//salesOrderRec.setCurrentLineItemText('item', 'povendor', fakeVendor);
						salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
						salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
						salesOrderRec.commitLineItem('item');
						
						nlapiLogExecution('DEBUG', 'set custom vendor', 'fakeVendorId');
					}else{
						salesOrderRec.selectLineItem('item', k);
						salesOrderRec.setCurrentLineItemValue('item', 'povendor', fakeVendorId);
						salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
						salesOrderRec.setCurrentLineItemValue('item', 'createpo', '');
						salesOrderRec.commitLineItem('item');
					}

				}
				else {
					//var purchaseOrderRec = nlapiLoadRecord('purchaseorder', existingpo, {recordmode: 'dynamic'});
					//purchaseOrderRec.setFieldValue('entity', fakeVendorId);
					//nlapiSubmitRecord(purchaseOrderRec, true, true);
					nlapiLogExecution('DEBUG', 'PO Updated', nlapiSubmitField('purchaseorder', existingpo, 'entity', fakeVendorId, true));
				}
				//fakeVendorId++;
			}
			nlapiSubmitRecord(salesOrderRec, true, true);
		}
		catch (err) {
			nlapiLogExecution('debug', 'Failed to set PO Vendor', err);
		}
	}
}

function setSpecialOrder(so_id) {
	var salesOrderRec = nlapiLoadRecord('salesorder', so_id);
	var customForm = salesOrderRec.getFieldValue('customform');
	// Check if form selected is in the script params
	if (INCLUDE_CUSTOM_FORMS.indexOf(customForm) == -1) {
		try {
			var itemCount = salesOrderRec.getLineItemCount('item');
			for (var k = 1; k <= itemCount; k++) {
				var existingPOVendor = salesOrderRec.getLineItemValue('item', 'povendor', k);
				var vendorName = salesOrderRec.getLineItemValue('item', FLD_COL_VENDOR_NAME, k);
				var existingcreatepo = salesOrderRec.getLineItemValue('item', 'createpo', k);
				
				if (vendorName == null) vendorName = '';
				// nlapiLogExecution('debug', 'po vendor', vendorName);
				if (existingPOVendor != vendorName && vendorName != null && vendorName != '') {
					salesOrderRec.selectLineItem('item', k);
					salesOrderRec.setCurrentLineItemValue('item', 'povendor', vendorName);
					salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
					if (existingcreatepo == null || existingcreatepo == '') salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
					// 1.4 Changes
					//Start Date (RR) (Line) = Start Date (Actual)
					var startdateActual = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATEACTUAL, k);
					var startDateRR = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATERR, k);
					if (!isNullOrEmpty(startdateActual) && isNullOrEmpty(startDateRR)) {
						salesOrderRec.setCurrentLineItemValue('item', FLD_COL_STARTDATERR, startdateActual);
					}
					salesOrderRec.commitLineItem('item');
				}
			}
			nlapiSubmitRecord(salesOrderRec, true, true);
		} catch (ep) {
			nlapiLogExecution('debug', 'Failed to set PO Vendor', ep);
		}
	}
}

function checkContract(salesOrderRec, client, clientName, date, buyingSys, buyingSysName, popRequired) { //added arg: popRequired
	var validationStatus = '';
	var buyingSys = salesOrderRec.getFieldValue(FLD_SO_BUYING_SYSTEM);
	var isError = false;
	var errorMsg = '';
	var errorPWPLineCount = 0;
	var errorVendorLineCount = 0;
	var errorBillingSchedCount = 0;
	var errorVendorPlaceHolderCount = 0;
	var errorLineOfBusinessCount = 0;
	var errorContract = 0;
	var lineBusinessHeader = salesOrderRec.getFieldValue(FLD_SO_LINEBUSINESS_HEADER) || lob;
	
	var idContract = salesOrderRec.getFieldValue(FLD_SO_CLIENT_CONTRACT);
	if(idContract == null || idContract == ''){
		var buyingSystemText = salesOrderRec.getFieldText(FLD_SO_BUYING_SYSTEM);

		switch (buyingSystemText) {
			case 'OOH':
				idContract = salesOrderRec.getFieldValue(FLD_SO_OOH_ID);
				salesOrderRec.setFieldValue(FLD_SO_CLIENT_CONTRACT, salesOrderRec.getFieldValue(FLD_SO_OOH_ID));
				break;
			case 'Spot':
				idContract = salesOrderRec.getFieldValue(FLD_SO_SPOT_ID)
				salesOrderRec.setFieldValue(FLD_SO_CLIENT_CONTRACT, salesOrderRec.getFieldValue(FLD_SO_SPOT_ID));
				break;
		}
	}
	nlapiLogExecution('debug', 'idContract', idContract);
	
	if (validationStatus != '') validationStatus = validationStatus + '\n';
	for (var i = 1; i <= salesOrderRec.getLineItemCount('item'); i++) {
		var vendorLine = salesOrderRec.getLineItemValue('item', FLD_VENDOR_LINE, i);
		var corporateOwner = salesOrderRec.getLineItemValue('item', FLD_COL_CORP_OWNER, i);
		var sovendor = salesOrderRec.getLineItemValue('item', 'povendor', i);
		var soCustomVendor = salesOrderRec.getLineItemValue('item', 'custcol_appf_po_vendor_name', i);
		var porate1 = salesOrderRec.getLineItemValue('item', 'porate', i);
		var createpo1 = salesOrderRec.getLineItemValue('item', 'createpo', i);
		var billingSchLine = salesOrderRec.getLineItemValue('item', FLD_BILLING_SCHEDULE_LINE, i);
		var pwpOnLine = salesOrderRec.getLineItemValue('item', FLD_COL_PWP, i);
		var nQty = salesOrderRec.getLineItemValue('item', 'quantity', i);
		nlapiLogExecution('debug', 'pwpOnLines json', pwpOnLine);
		//check contract
		if (idContract == null || idContract == '') {
			errorContract++;
		}
		if (pwpOnLine == null || pwpOnLine == '') {
			errorPWPLineCount++;
			//validationStatus += 'Failed. PWP Record Link is missing on Line #'+i+'.\n';
		} else if ((vendorLine == null || vendorLine == '') && (billingSchLine == null || billingSchLine == '')) {
			errorVendorLineCount++;
			errorBillingSchedCount++;
			//validationStatus += 'Failed. Vendor Name, Billing Schedule are missing on Line #'+i+'.\n';
		} else if ((vendorLine != null && vendorLine != '') && (billingSchLine == null || billingSchLine == '')) {
			errorBillingSchedCount++;
			//validationStatus += 'Failed. Billing Schedule is missing on Line #'+i+'.\n';
		} else if ((vendorLine == null || vendorLine == '') && (billingSchLine != null && billingSchLine != '')) {
			//validationStatus += 'Failed. Vendor Name is missing on Line #'+i+'.\n';
			errorVendorLineCount++;
		}
		if (sovendor == PLACEHOLDER) {
			//validationStatus += 'Failed.  Vendor is Placeholder on Line #'+i+'.\n';
			errorVendorPlaceHolderCount++;
		}
		salesOrderRec.selectLineItem('item', i);
		if (porate1 == null || porate1 == '' || porate1 == 0) {
			salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
		}
		//if (createpo1 == null || createpo1 == '') {
		//	salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
		//	salesOrderRec.setCurrentLineItemValue('item', 'povendor', soCustomVendor);
		//}
		//v.5 9/2/2020 add
		if (!isNullOrEmpty(lineBusinessHeader)) {
			salesOrderRec.setCurrentLineItemValue('item', 'class', lineBusinessHeader);
		}
		//v5. added 9/2/2020
		var lob = salesOrderRec.getLineItemValue('item', 'class', i); //validate
		if (lob == null || lob == '') {
			errorLineOfBusinessCount++;
			//validationStatus += 'Failed. Line of Business is missing on Line #'+i+'.\n';
		}
		// 1.4 Changes
		//Start Date (RR) (Line) = Start Date (Actual)
		var startdateActual = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATEACTUAL, i);
		var startDateRR = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATERR, i);
		if (!isNullOrEmpty(startdateActual) && isNullOrEmpty(startDateRR)) {
			salesOrderRec.setCurrentLineItemValue('item', FLD_COL_STARTDATERR, startdateActual);
		}
		//validationStatus += 'Failed. Special Order is not Selected on Create Po on Line #'+i+'.\n';
		if (buyingSys == BUYING_SYSTEM_PRINT) salesOrderRec.setCurrentLineItemValue('item', FLD_COL_POP_REQUIRED, popRequired);
		/*if(lob != null && lob != '')
		    salesOrderRec.setCurrentLineItemValue('item', 'class', lob);*/

        /// v7
        // if (buyingSys == BUYING_SYSTEM_OOH) {
        //     var shipTo = salesOrderRec.viewCurrentLineItemSubrecord('item', FLD_COL_SHIPTO);
        //     nlapiLogExecution('DEBUG', 'Ship To', shipTo);
        //     var itemId = salesOrderRec.getCurrentLineItemValue('item', 'item');
        //     nlapiLogExecution('DEBUG', 'Item Id', itemId);
        //     var isFulfillable = nlapiLookupField('item', itemId, ITEM_FLD_CANBEFULFILLED) == 'T';
        //     nlapiLogExecution('DEBUG', 'Item is Fulfillable?', isFulfillable);
        //     var soLineID = salesOrderRec.getCurrentLineItemValue('item', FLD_COL_SOLINEID);
        //     if (isFulfillable && !shipTo) {
        //         validationStatus += 'Failed. Shipping Address is missing on SO Line ID: ' + soLineID + '. \n';
        //     }
        // }

		salesOrderRec.commitLineItem('item');
	}
	//summary of errors : added 9/9/2020
	if (errorContract > 0) {
		validationStatus += 'Failed. Client Contract is missing.\n';
	}
	if (errorPWPLineCount > 0) {
		validationStatus += 'Failed. PWP Record Link is missing.\n';
	}
	if (errorVendorLineCount > 0 && errorBillingSchedCount > 0) {
		validationStatus += 'Failed. Vendor Name, Billing Schedule are missing.\n';
	} else if (errorVendorLineCount == 0 && errorBillingSchedCount > 0) {
		validationStatus += 'Failed. Billing Schedule is missing.\n';
	} else if (errorVendorLineCount > 0 && errorBillingSchedCount == 0) {
		validationStatus += 'Failed. Vendor Name is missing.\n';
	}
	if (errorVendorPlaceHolderCount > 0) {
		validationStatus += 'Failed.  Vendor is Placeholder.\n';
	}
	if (errorLineOfBusinessCount > 0) {
		//validationStatus += 'Failed. Line of Business is missing. \n';
	}
	return validationStatus;
}

function checkContractOrig(salesOrderRec, client, clientName, date, buyingSys, buyingSysName) {
	var validationStatus = '';
	var activeContracts = {};
	var contractId = salesOrderRec.getFieldValue(FLD_SO_CLIENT_CONTRACT);
	if (contractId == null || contractId == '') {
		var contractFils = [];
		contractFils.push(new nlobjSearchFilter(FLD_CONTRACT_CLIENT, null, 'anyof', client));
		contractFils.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
		var contractCols = [];
		contractCols.push(new nlobjSearchColumn(FLD_CONTRACT_MEDIA_TYPE));
		contractCols.push(new nlobjSearchColumn(FLD_CONTRACT_END_DATE));
		contractCols.push(new nlobjSearchColumn('name'));
		var contractSearchResults = getAllSearchResults(CUSTOM_RECORD_CONTRACT, contractFils, contractCols);
		if (contractSearchResults != null && contractSearchResults != '') {
			for (var a = 0; a < contractSearchResults.length; a++) {
				var result = contractSearchResults[a];
				var contractId = result.getId();
				var contractName = result.getValue('name');
				var contractMediaTypeID = result.getValue(FLD_CONTRACT_MEDIA_TYPE);
				var contractMediaType = result.getText(FLD_CONTRACT_MEDIA_TYPE);
				var contractEndDate = result.getValue(FLD_CONTRACT_END_DATE);
				if (contractMediaTypeID != null && contractMediaTypeID != '') {
					if (!activeContracts.hasOwnProperty(contractMediaType)) {
						activeContracts[contractMediaType] = [];
						var obj = {};
						obj.contractId = contractId;
						obj.contractName = contractName;
						obj.contractEndDate = contractEndDate;
						activeContracts[contractMediaType].push(obj);
					} else {
						var obj = {};
						obj.contractId = contractId;
						obj.contractName = contractName;
						obj.contractEndDate = contractEndDate;
						activeContracts[contractMediaType].push(obj);
					}
				}
			}
			nlapiLogExecution('debug', 'activeContracts json', JSON.stringify(activeContracts));
			if (activeContracts.hasOwnProperty(buyingSysName)) {
				var buyingSysArr = activeContracts[buyingSysName];
				var endDateMissing = false;
				var endDatePassed = false;
				var contractName = '';
				var allContracts = [];
				for (var b = 0; b < buyingSysArr.length; b++) {
					var obj = buyingSysArr[b];
					var endDate = obj.contractEndDate;
					if (endDate != null && endDate != '') {
						endDateMissing = false;
						if (nlapiStringToDate(date).getTime() < nlapiStringToDate(endDate).getTime()) {
							endDatePassed = false;
							var contract = obj.contractId;
							if (allContracts.indexOf(contract) == -1) {
								allContracts.push(contract);
							}
						} else {
							endDatePassed = true;
							contractName = obj.contractName;
						}
					} else {
						endDateMissing = true;
						contractName = obj.contractName;
					}
				}
				if (endDateMissing == true) {
					validationStatus = 'Failed. Contract ' + contractName + ' End Date missing.';
				} else if (endDatePassed == true) {
					validationStatus = 'Failed. Contract ' + contractName + ' has expired. Please create a new contract.';
				} else if (allContracts.length > 0) {
					if (allContracts.length > 1) {
						validationStatus = 'Failed. Multiple active contracts found for ' + clientName + ' and ' + buyingSysName + '.';
					} else {
						var contractId = allContracts[0];
						salesOrderRec.setFieldValue(FLD_SO_CLIENT_CONTRACT, contractId);
					}
				}
			} else {
				validationStatus = 'Failed. No Contract found for ' + buyingSysName + '.';
			}
		} else {
			validationStatus = 'Failed. No Contract found for ' + clientName + ' and ' + buyingSysName + '.';
		}
	}
	var contract = contractId;
	var buyingSys = salesOrderRec.getFieldValue(FLD_SO_BUYING_SYSTEM);
	var isError = false;
	var errorMsg = '';
	if (contract != null && contract != '') {
		var contractRec = nlapiLoadRecord(CUSTOM_RECORD_CONTRACT, contract);
		var dept = contractRec.getFieldValue(FLD_CONTRACT_DEPT);
		var lob = contractRec.getFieldValue(FLD_CONTRACT_LOB);
		var popRequired = contractRec.getFieldValue(FLD_CONTRACT_POP_REQUIRED);
		var contractName = contractRec.getFieldValue('name');
		var errorPWPLineCount = 0;
		var errorVendorLineCount = 0;
		var errorBillingSchedCount = 0;
		var errorVendorPlaceHolderCount = 0;
		//if(dept != null && dept != '')
		//salesOrderRec.setFieldValue('department', dept);
		if (validationStatus != '') validationStatus = validationStatus + '\n';
		//if(lob != null && lob != '')
		//salesOrderRec.setFieldValue('class', lob);
		for (var i = 1; i <= salesOrderRec.getLineItemCount('item'); i++) {
			var vendorLine = salesOrderRec.getLineItemValue('item', FLD_VENDOR_LINE, i);
			var corporateOwner = salesOrderRec.getLineItemValue('item', FLD_COL_CORP_OWNER, i);
			var sovendor = salesOrderRec.getLineItemValue('item', 'povendor', i);
			var soCustomVendor = salesOrderRec.getLineItemValue('item', 'custcol_appf_po_vendor_name', i);
			var porate1 = salesOrderRec.getLineItemValue('item', 'porate', i);
			var createpo1 = salesOrderRec.getLineItemValue('item', 'createpo', i);
			var billingSchLine = salesOrderRec.getLineItemValue('item', FLD_BILLING_SCHEDULE_LINE, i);
			var pwpOnLine = salesOrderRec.getLineItemValue('item', FLD_COL_PWP, i);
			nlapiLogExecution('debug', 'pwpOnLines json', pwpOnLine);
			if (pwpOnLine == null || pwpOnLine == '') {
				errorPWPLineCount++;
				//validationStatus += 'Failed. PWP Record Link is missing on Line #'+i+'.\n';
			} else if ((vendorLine == null || vendorLine == '') && (billingSchLine == null || billingSchLine == '')) {
				//validationStatus += 'Failed. Vendor Name, Billing Schedule are missing on Line #'+i+'.\n';
				errorVendorLineCount++;
				errorBillingSchedCount++;
			} else if ((vendorLine != null && vendorLine != '') && (billingSchLine == null || billingSchLine == '')) {
				//validationStatus += 'Failed. Billing Schedule is missing on Line #'+i+'.\n';
				errorBillingSchedCount++;
			} else if ((vendorLine == null || vendorLine == '') && (billingSchLine != null && billingSchLine != '')) {
				//validationStatus += 'Failed. Vendor Name is missing on Line #'+i+'.\n';
				errorVendorLineCount++;
			}
			//else if ((vendorLine == null || vendorLine == '') && (billingSchLine == null || billingSchLine == ''))
			//validationStatus += 'Failed. Vendor Name and Billing Schedule are missing on Line #'+i+'.\n';
			//else if ((vendorLine != null && vendorLine != '') && (billingSchLine == null || billingSchLine == ''))
			//validationStatus += 'Failed. Billing Schedule Owner are missing on Line #'+i+'.\n';
			//else if ((vendorLine == null || vendorLine == '') && (billingSchLine != null && billingSchLine != ''))
			//validationStatus += 'Failed. Vendor Name are missing on Line #'+i+'.\n';
			//else if ((vendorLine != null && vendorLine != '') && (billingSchLine != null && billingSchLine != ''))
			//validationStatus += 'Failed. Corporate Owner is missing on Line #'+i+'.\n';
			if (sovendor == PLACEHOLDER) {
				//validationStatus += 'Failed.  Vendor is Placeholder on Line #'+i+'.\n';
				errorVendorPlaceHolderCount++;
			}
			salesOrderRec.selectLineItem('item', i);
			if (porate1 == null || porate1 == '' || porate1 == 0) {
				salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);
			}
			//if (createpo1 == null || createpo1 == '') {
			//	salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');
			//	salesOrderRec.setCurrentLineItemValue('item', 'povendor', soCustomVendor);
			//}
			// 1.4 Changes
			//Start Date (RR) (Line) = Start Date (Actual)
			var startdateActual = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATEACTUAL, i);
			var startDateRR = salesOrderRec.getLineItemValue('item', FLD_COL_STARTDATERR, i);
			if (!isNullOrEmpty(startdateActual) && isNullOrEmpty(startDateRR)) {
				salesOrderRec.setCurrentLineItemValue('item', FLD_COL_STARTDATERR, startdateActual);
			}
			//validationStatus += 'Failed. Special Order is not Selected on Create Po on Line #'+i+'.\n';
			if (buyingSys == BUYING_SYSTEM_PRINT) salesOrderRec.setCurrentLineItemValue('item', FLD_COL_POP_REQUIRED, popRequired);
			if (lob != null && lob != '') salesOrderRec.setCurrentLineItemValue('item', 'class', lob);
			salesOrderRec.commitLineItem('item');
			//if(contractName != null && contractName != '')
			//salesOrderRec.setLineItemValue('item', FLD_COL_CORP_OWNER, i, contractName);
		}
	}
	//summary of errors : added 9/9/2020
	if (errorPWPLineCount > 0) {
		validationStatus += 'Failed. PWP Record Link is missing.\n';
	}
	if (errorVendorLineCount > 0 && errorBillingSchedCount > 0) {
		validationStatus += 'Failed. Vendor Name, Billing Schedule are missing.\n';
	} else if (errorVendorLineCount == 0 && errorBillingSchedCount > 0) {
		validationStatus += 'Failed. Billing Schedule is missing.\n';
	} else if (errorVendorLineCount > 0 && errorBillingSchedCount == 0) {
		validationStatus += 'Failed. Vendor Name is missing.\n';
	}
	if (errorVendorPlaceHolderCount) {
		validationStatus += 'Failed.  Vendor is Placeholder.\n';
	}
	return validationStatus;
}

function setContractSOScheduled(type) {
	var context = nlapiGetContext();
	var mediaSOSS = context.getSetting('SCRIPT', SPARAM_MEDIA_SALES_ORDERS_SS);
	var existingDataFile = context.getSetting('SCRIPT', SPARAM_SS_FILE_ID);
	var fileName = context.getSetting('SCRIPT', SPARAM_SS_FILE_NAME);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if (index == null || index == '') index = 1;
	nlapiLogExecution('debug', 'file index', 'index=' + index+ 'mediaSOSS='+mediaSOSS);
	var fileId = null;
	if (mediaSOSS != null && mediaSOSS != '') {
		fileId = get_or_create_CSVFile(existingDataFile, mediaSOSS, fileName);
		nlapiLogExecution('debug', 'fileId', fileId);
		if (fileId != null && fileId != '') {
			var fileObj = nlapiLoadFile(fileId);
			var fileData = fileObj.getValue().split('\n');
			nlapiLogExecution('debug', 'fileObj', fileObj.getValue());
			nlapiLogExecution('debug', 'fileData', fileData);
			var allDataProcessed = true;
			if (fileData != null && fileData != '') {
				for (var f = index; f < (fileData.length - 1); f++) {
					var validationStatus = '';
					var line = fileData[f].split(',');
					var recId = line[0];
					var client = line[1];
					var clientName = line[2];
					var date = line[3];
					var buyingSys = line[4];
					var buyingSysName = line[5];
					var popRequired = line[6]; //v5 added 9/2/2020
					nlapiLogExecution('DEBUG', 'Sales Order Id', recId);

					//
					//setSpecialOrder(recId);
					//
					setVendorPlaceholder(recId);

					try {
						var salesOrderRec = nlapiLoadRecord('salesorder', recId);
						validationStatus = checkContract(salesOrderRec, client, clientName, date, buyingSys, buyingSysName, popRequired); //v5 added 9/2/2020, added arg popRequired
						if (validationStatus == null || validationStatus == '') {
							salesOrderRec.setFieldValue(FLD_SO_ORDER_VALIDATION_STATUS, 'Success');
							salesOrderRec.setFieldValue('orderstatus', 'B');
						} else {
							salesOrderRec.setFieldValue(FLD_SO_ORDER_VALIDATION_STATUS, validationStatus);
						}
						nlapiSubmitRecord(salesOrderRec, true, true);
					} catch (e) {
						var err_order_val = '';
						if (e instanceof nlobjError) {
							nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails())
							err_order_val = e.getDetails();
						} else {
							nlapiLogExecution('DEBUG', 'unexpected error', e.toString())
							err_order_val = e.toString();
						}
						try {
							nlapiSubmitField('salesorder', recId, FLD_SO_ORDER_VALIDATION_STATUS, err_order_val)
						} catch (ex) {
							nlapiLogExecution('DEBUG', 'unexpected error', ex);
						}
					}
					if (context.getRemainingUsage() <= 500 && (f + 1) < (fileData.length - 1)) {
						allDataProcessed = false;
						var params = {};
						params[SPARAM_MEDIA_SALES_ORDERS_SS] = mediaSOSS;
						params[SPARAM_SS_FILE_ID] = fileId;
						params[SPARAM_INDEX] = (f + 1);
						nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
						break;
					}
				}
			}
			if (allDataProcessed) {
				nlapiDeleteFile(fileId);
			}
		}
	}
}

function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);
	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];
	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}

function isNullOrEmpty(data) {
	return (data == null || data == '');
}