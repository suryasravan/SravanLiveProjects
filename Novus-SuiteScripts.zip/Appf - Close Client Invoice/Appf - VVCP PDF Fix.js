{
    var VVCPLINK_RECTYPE = 'customrecord_appf_vvccp_linked_trans';
    var VVCPLINK_FLD_TRANSACTION = 'custrecord_appf_vvccp_linked_transaction';
    var VVCPLINK_FLD_PWP = 'custrecord_appf_vvccp_linked_trans_pwp';
    var VVCPLINK_FLD_ORDERREF = 'custrecord_appf_vvccp_linked_order_ref';
    var VVCPLINK_FLD_SERVICEDATE = 'custrecord_appf_vvccp_linked_servicedate';
    var VVCPLINK_FLD_CLIENT = 'custrecord_appf_vvccp_linked_client';

    var VBILL_RECTYPE = 'vendorbill';
    var VBILL_FLD_BUYINGSYSTEM = 'custbody_appf_buying_system';
    var VBILL_LINEITEM = 'item';
    var VBILL_LINEITEM_CLIENT = 'customer';
    var VBILL_LINEITEM_SERVICEDATE = 'custcol_sii_service_date';
    var VBILL_LINEITEM_ENDDATERR = 'custcol_appf_so_line_enddate';
    var VBILL_LINEITEM_IO = 'custcol_appf_ionum';

    var VAL_BUYINGSYSTEM_PRINT = '1';
}

function beforeSubmit_VVCPPDF(type) {
    if (type == 'create' || type == 'edit') {
        var tran_id = nlapiGetFieldValue(VVCPLINK_FLD_TRANSACTION);
        var pwp_id = nlapiGetFieldValue(VVCPLINK_FLD_PWP);
        var order_ref = nlapiGetFieldValue(VVCPLINK_FLD_ORDERREF);
        if (!isNullOrEmpty(tran_id) && !isNullOrEmpty(pwp_id)) {

            var service_date = nlapiGetFieldValue(VVCPLINK_FLD_SERVICEDATE);
            var client = nlapiGetFieldValue(VVCPLINK_FLD_CLIENT);
            // Load record only when any of the fields above is empty
            if (isNullOrEmpty(service_date) || isNullOrEmpty(client)) {

                var tran_rectype = nlapiLookupField('transaction', tran_id, 'recordtype');
                if (tran_rectype == 'vendorbill') {
                    var tran_rec = nlapiLoadRecord(tran_rectype, tran_id);
                    if (tran_rec) {
                        // Not all VVCP linked has Order Ref in them but usually it's the first line
                        var index = 1;
                        if (!isNullOrEmpty(order_ref)) {
                            tran_rec.findLineItemValue(VBILL_LINEITEM, VBILL_LINEITEM_IO, order_ref);
                            nlapiLogExecution('DEBUG', 'IO Index', index);
                        }

                        if (index > 0) {
                            //Source Client
                            if (isNullOrEmpty(client)) {
                                client = tran_rec.getLineItemValue(VBILL_LINEITEM, VBILL_LINEITEM_CLIENT, index);
                                nlapiSetFieldValue(VVCPLINK_FLD_CLIENT, client);
                                nlapiLogExecution('DEBUG', 'Client', client);
                            }

                            //Get Buying System then set service date
                            if (isNullOrEmpty(service_date)) {
                                var buying_system = tran_rec.getFieldValue(VBILL_FLD_BUYINGSYSTEM);
                                if (buying_system == VAL_BUYINGSYSTEM_PRINT) {
                                    service_date = tran_rec.getLineItemValue(VBILL_LINEITEM, VBILL_LINEITEM_SERVICEDATE, index);
                                }
                                else {
                                    service_date = tran_rec.getLineItemValue(VBILL_LINEITEM, VBILL_LINEITEM_ENDDATERR, index);
                                }
                                nlapiSetFieldValue(VVCPLINK_FLD_SERVICEDATE, service_date);
                                nlapiLogExecution('DEBUG', 'Service Date', service_date);
                            }
                        }

                    }
                }

            }

        }
    }
}


function isNullOrEmpty(data) {
    return (data == null || data == '');
}
