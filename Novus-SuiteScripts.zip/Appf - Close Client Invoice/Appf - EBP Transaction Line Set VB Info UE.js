{
    CUSTRECORD_EBP = 'customrecord_appf_ebp_linked_trans';
    FLD_EBP_LINKEDTRANS = 'custrecord_appf_ebp_linked_transaction';
    FLD_EBP_INVOICENUMBER = 'custrecord_appf_ebp_invoicerefnumber'; //VB's tranid
    FLD_EBP_ORDERNUMBER = 'custrecord_appf_ebp_ordernumber'; // VB's Order Reference
    FLD_EBP_SERVICEDATE = 'custrecord_appf_ebp_servicedate'; // VB Line's End Date
    FLD_EBP_MEDIASUPPLIER = 'custrecord_appf_ebp_mediasupstation'; // if VB's Buying System = Spot, then source from Vendor Bill's Station else from VB's Publisher/Media Supplier
    FLD_EBP_CLIENT = 'custrecord_appf_ebp_client'; // VB Line's Customer
    FLD_EBP_AMOUNT = 'custrecord_appf_ebp_amount'; // VP's Amount
    FLD_EBP_VENDORPAYMENT = 'custrecord_appf_ebp_linked_payment';

    FLD_VB_TRANID = 'tranid';
    FLD_VB_ORDERNUMBER = 'custbody_appf_orderreference';
    FLD_VB_BUYINGSYSTEM = 'custbody_appf_buying_system';
    FLD_VB_STATION = 'custbody_appf_strata_station';
    FLD_VB_LINEITEM = 'item';
    FLD_VB_LINEITEM_ENDDATERR = 'custcol_appf_so_line_enddate';
    FLD_VB_LINEITEM_MEDIASUPPLIER = 'custcol_appf_publisher';
    FLD_VB_LINEITEM_CUSTOMER = 'customer';

    FLD_VP_AMOUNT = 'total';

    FLD_VAL_BUYINGSYSTEM_SPOT = '4';
}

function beforeSubmit_setVBInfo(type) {
    if (type == 'create' || type == 'edit') {
        var linked_transaction = nlapiGetFieldValue(FLD_EBP_LINKEDTRANS);
        if (!isNullOrEmpty(linked_transaction)) {

            var linked_rectype = nlapiLookupField('transaction', linked_transaction, 'recordtype');
            if (linked_rectype == 'vendorbill') {
                var vendorbill_rec = nlapiLoadRecord('vendorbill', linked_transaction);
                if (vendorbill_rec) {
                    nlapiSetFieldValue(FLD_EBP_INVOICENUMBER, vendorbill_rec.getFieldValue(FLD_VB_TRANID));
                    nlapiSetFieldValue(FLD_EBP_ORDERNUMBER, vendorbill_rec.getFieldValue(FLD_VB_ORDERNUMBER));

                    var count = vendorbill_rec.getLineItemCount(FLD_VB_LINEITEM);
                    if (count > 0) {
                        var enddaterr = vendorbill_rec.getLineItemValue(FLD_VB_LINEITEM, FLD_VB_LINEITEM_ENDDATERR, 1);
                        nlapiSetFieldValue(FLD_EBP_SERVICEDATE, enddaterr);

                        var client = vendorbill_rec.getLineItemValue(FLD_VB_LINEITEM, FLD_VB_LINEITEM_CUSTOMER, 1);
                        if (!isNullOrEmpty(client)) {
                            client = nlapiLookupField('job', client, 'customer');
                            nlapiSetFieldValue(FLD_EBP_CLIENT, client);
                        }

                        var buying_system = vendorbill_rec.getFieldValue(FLD_VB_BUYINGSYSTEM);
                        if (buying_system == FLD_VAL_BUYINGSYSTEM_SPOT) {
                            nlapiSetFieldValue(FLD_EBP_MEDIASUPPLIER, vendorbill_rec.getFieldValue(FLD_VB_STATION));
                        }
                        else {
                            var media_supplier = vendorbill_rec.getLineItemText(FLD_VB_LINEITEM, FLD_VB_LINEITEM_MEDIASUPPLIER, 1);
                            nlapiSetFieldValue(FLD_EBP_MEDIASUPPLIER, media_supplier);
                        }
                    }
                }
            }

            var payment_transaction = nlapiGetFieldValue(FLD_EBP_VENDORPAYMENT);
            if (!isNullOrEmpty(payment_transaction)) {
                var payment_amount = nlapiLookupField('vendorpayment', payment_transaction, FLD_VP_AMOUNT);
                payment_amount = Math.abs(parseFloat(payment_amount));
                nlapiSetFieldValue(FLD_EBP_AMOUNT, payment_amount);
            }

        }

    }
}

function isNullOrEmpty(data) {
    return (data == null || data == '');
}
