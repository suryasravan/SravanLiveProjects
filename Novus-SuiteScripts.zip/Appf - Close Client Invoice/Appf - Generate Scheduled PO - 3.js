/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : Generate Special PO for Sales Orders
* Company     : Appficiency Inc.
*/
var SPARAM_SEARCH_PARAMETER = 'custscript_appf_sparam_sosavedsearch_s3';
var SPARAM_SEARCH_INDEX = 'custscript_appf_sparam_searchindex_s3';
var SPARAM_SO_LINE_INDEX = 'custscript_appf_sparam_lineindex_s3';

var FLD_SO_PO_VENDOR = 'custcol_appf_po_vendor_name';
var FLD_SO_PO_GENERATION_COMPLETE = 'custcol_appf_po_generation_complete';
var FLD_SO_PO_GENERATION_ERROR = 'custbody_appf_po_generation_error';

var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020

var FLD_SO_SCHED_PO_STATUS = 'custbody_appf_sched_po_status';

var startTime = new Date().getTime();

function scheduled_generatePOStep3(type) {
    var context = nlapiGetContext();
	var searchId = context.getSetting('SCRIPT', SPARAM_SEARCH_PARAMETER);
	var nLineIndex = context.getSetting('SCRIPT', SPARAM_SO_LINE_INDEX) || 1;

    var index = context.getSetting('SCRIPT', SPARAM_SEARCH_INDEX);
	if (index == null || index == '')
		index = 0;
    //nlapiLogExecution('debug', 'file index', index);

	var lineIndex = context.getSetting('SCRIPT', SPARAM_SO_LINE_INDEX);
	if (lineIndex == null || lineIndex == '')
		lineIndex = 1;

    if(searchId){
        var objSearch= nlapiLoadSearch(null, searchId);
    	var filters = objSearch.getFilters();
    	var columns = objSearch.getColumns();
    	var ssType = objSearch.getSearchType();
    	var searchResults = getAllSearchResults(ssType, filters, columns);

    	if (searchResults != null && searchResults != '') {
    		for (var s=index; s<searchResults.length; s++) {
    			var result = searchResults[s];
                var recType = result.getRecordType();
                var idSalesOrder = result.getId();
                var columns = result.getAllColumns();
    			var idSalesOrder = result.getValue(columns[0]);
    			//var idLine = result.getValue(columns[1]);
    			recType= 'salesorder';

    			//log.debug('sales order:', idSalesOrder);
    			nlapiLogExecution('DEBUG', 'sales order:',idSalesOrder);
                //check time
                var endTime = new Date().getTime();
                //Calculate the Time Elapsed between End Time and Start Time

                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                //nlapiLogExecution('DEBUG', 'TIME ELAPSED Outside',timeElapsed);
                if( timeElapsed > 1500 || (context.getRemainingUsage() <= 1000 /*&& parseInt(s)+1 < searchResults.length*/) ) {
                    var params = {};
                    params[SPARAM_SEARCH_PARAMETER] = searchId;
                    params[SPARAM_SEARCH_INDEX] = s;  //(s+1);
                    nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                    break;
                }else{
                	//var scriptStep = 1;
        	    	var errorMsg = '';
                    //load sales order
                    //nlapiLogExecution('debug', 'remaining usage before', context.getRemainingUsage());

        	    	try{

            			//check time
                        var timeElapsed = (endTime*0.001) - (startTime*0.001);

                        nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 3 before loading',timeElapsed);

                        if(timeElapsed > 1500){ //25 minutes
                            var params = {};
                            params[SPARAM_SEARCH_PARAMETER] = searchId;
                            params[SPARAM_SEARCH_INDEX] = s;
                            nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                            break;
                        }else{
                            var recSO = nlapiLoadRecord(recType,idSalesOrder);
                            //var status = recSO.getFieldValue(FLD_SO_SCHED_PO_STATUS);
                            //nlapiLogExecution('DEBUG', 'step 2 status',status + ' errorPOMsg='+errorPOMsg);

                            //if(status == 1){
                            var nLines = recSO.getLineItemCount('item');
                            if (nLines > 0) {
                            	for(var i = nLineIndex; i <= nLines; i++){
                                    recSO.selectLineItem('item', i);
                                    var nQty = recSO.getCurrentLineItemValue('item', 'quantity');
                                    var idPO = recSO.getCurrentLineItemValue('item', 'poid');

                                    if ((nQty == 0.01 || nQty == '0.01') && !isNullOrEmpty(idPO)) {
                                        recSO.setCurrentLineItemValue('item', 'quantity', '0');
                                        recSO.setCurrentLineItemValue('item', FLD_SO_PO_GENERATION_COMPLETE, 'T');
                                        recSO.commitLineItem('item');
                                    }
                                    //check time
                                    var endTime = new Date().getTime();
                                    //Calculate the Time Elapsed between End Time and Start Time
                                    var timeElapsed = (endTime*0.001) - (startTime*0.001);

                                    //nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE step 1',timeElapsed);
                                    if(timeElapsed > 1500){ //25 minutes
                                    	//reschedule

                                        //recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, '');
                                        //save record then reschedule
                                        nlapiSubmitRecord(recSO);

                                        params[SPARAM_SEARCH_PARAMETER] = searchId;
                                        params[SPARAM_SEARCH_INDEX] = s;
                                        params[SPARAM_SO_LINE_INDEX] = x;
                                        params[SPARAM_ERROR_PO_MSG] = '';
                                        params[SPARAM_STATUS] = '';
                                        params[SPARAM_SCRIPT_STEP] = 1;

                                        nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                        break;

                                    }else{
                                    	if(i == nLines){  //if last line, set status
                                    		//check time
                                    		//recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, 1);

                                            //check time
                                            var endTime = new Date().getTime();
                                            //Calculate the Time Elapsed between End Time and Start Time

                                            var timeElapsed = (endTime*0.001) - (startTime*0.001);

                                            //nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 1',timeElapsed);

                                            if(timeElapsed > 1500){ //25 minutes
                                            	//reschedule only
                                                params[SPARAM_SEARCH_PARAMETER] = searchId;
                                                params[SPARAM_SEARCH_INDEX] = s;
                                                params[SPARAM_SO_LINE_INDEX] = x;
                                                params[SPARAM_ERROR_PO_MSG] = '';
                                                params[SPARAM_STATUS] = '';
                                                params[SPARAM_SCRIPT_STEP] = 1;
                                                nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                                break;
                                            }else{
                                        		try{
                                        			//recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, 1);
                                        			nlapiSubmitRecord(recSO);
                                        			nlapiLogExecution('DEBUG', 'Set PO Fields','Set PO Fields');
                                        			scriptStep = 2;
                                        		}catch(e1){
                                        			errorMsg = e1.message;
                                        			nlapiLogExecution('DEBUG', 'Error setting PO Rate and Vendor', e1.message + ' idSalesOrder='+idSalesOrder);
                                        		}
                                            }
                                    	}
                                    }
                                }


                            }



                          // }

                            /*
                			//check time
                            var timeElapsed = (endTime*0.001) - (startTime*0.001);

                            nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 3',timeElapsed);

                            if(timeElapsed > 1500){ //25 minutes
                                var params = {};
                                params[SPARAM_SEARCH_PARAMETER] = searchId;
                                params[SPARAM_SEARCH_INDEX] = s;
                                nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                break;
                            }else{
                                if (nlapiSubmitRecord(recSO)) {
                                    nlapiLogExecution('DEBUG', 'Updated SO: ', idSalesOrder);
                                }
                            } */

                        }
        	    	}catch(errorMsg){
        	    		 nlapiLogExecution('debug', 'error', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder + 'errorMSg='+errorMsg.message);

        	    	}

                    //}
                }
    			//check time
                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                nlapiLogExecution('debug', 'remaining usage after', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder + ' timeElapsed='+timeElapsed);
    		}

        }
    }
}


function getAllSearchResults(record_type, filters, columns) {
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);

    var searchRan = search.runSearch()
    ,	bolStop = false
    ,	intMaxReg = 1000
    ,	intMinReg = 0
    ,	result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000) {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array) {
    return target.concat(array); // TODO: use _.union
}


function isNullOrEmpty(data) {
    return (data == null || data == '');
}
