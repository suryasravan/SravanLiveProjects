/**
 * Module Description
 * This script displays the "Close" button in Invoice record when
 *  a. Invoice is Open
 *  b. CI Status is Not Started
 *  c. CI Record is empty
 *  d. At least one Close Processed line item is unchecked
 *  Upon submission, the Invoice record is updated to:
 *  a. Copy the Client Gross Allocation to Pre-close Amount
 *  b. Zero the Client Gross Allocation
 *  c. Set Close Processed to True
 *  PWP is also updated where:
 *  a. Invoice Amount is set to 0
 * Version    Date            Author           Remarks
 * 1.00       31 Jul 2020     zark
 *
 */
{
    var VAL_CLOSEBTN_TITLE = 'Close';
    var VAL_CLOSEBTN_ID = 'custpage_closeinvoice';

    // INVOICE RECORD FIELDS AND LINE ITEM FIELDS
    var FLD_INV_ITEM = 'item';
    var FLD_INV_LINEITEM_CLIENTGROSSALLOC = 'quantity';
    var FLD_INV_LINEITEM_AMOUNT = 'amount';
    var FLD_INV_LINEITEM_PRECLOSEAMOUNT = 'custcol_appf_pre_close_amt';
    var FLD_INV_LINEITEM_CLOSEPROCESSED = 'custcol_appf_close_processed';
    var FLD_INV_LINEITEM_PWPRECORD = 'custcol_appf_pwp_custom_record';
    var FLD_INV_LINEITEM_CISTATUS = 'custcol_appf_ci_status';
    var FLD_INV_LINEITEM_CIRECORD = 'custcol_appf_ci_record';

    var FLD_INV_ORDERSTATUS = 'status';
    var VAL_ORDERSTATUS_OPEN = 'Open';
    var VAL_LINEITEM_CISTATUS_NOTSTARTED = 1;


    //PWP CUSTOM RECORD
    var RECTYPE_PWP = 'customrecord_appf_pwp_wrapper_record';
    var FLD_PWP_INVOICEDAMOUNT = 'custrecord_appf_pwp_inv_line_amount';

    var RECPARAM_CLOSEINVOICE = 'custparam_closeinvoice';
}

function beforeLoad_closeClientInvoice(type, form, request) {
    var record_id = nlapiGetRecordId();
    var record_type = nlapiGetRecordType();
    var record_link = nlapiResolveURL('RECORD', record_type, record_id);
    var order_status = nlapiGetFieldValue(FLD_INV_ORDERSTATUS);

    if (type == 'edit' || type == 'view') {
        var rec_invoice = nlapiLoadRecord(record_type, record_id);
        if (order_status == VAL_ORDERSTATUS_OPEN && checkAnyLineItemToClose(rec_invoice)) {
            record_link += '&' + RECPARAM_CLOSEINVOICE + '=T';
            form.addButton(VAL_CLOSEBTN_ID, VAL_CLOSEBTN_TITLE, "window.open('"+ record_link +"', '_self');");
        }
    }

    if (request && request.getParameter(RECPARAM_CLOSEINVOICE) == 'T' && order_status == VAL_ORDERSTATUS_OPEN) {
        var rec_invoice = nlapiLoadRecord(record_type, record_id, {recordmode: 'dynamic'});
        if (updateInvoiceAndPWP(rec_invoice)) {
            nlapiSetRedirectURL('RECORD', record_type, record_id);
        }
    }
}

// This function iterate through line items to:
// a. Copy the Client Gross Allocation to Pre-Close Amount
// b. Set Client Gross Allocation to 0
// c. Set Close Processed to True
// then updates the PWP on that line item to:
// a. Set Invoiced Amount to 0
function updateInvoiceAndPWP(rec_invoice) {
    var successful = true;
    var lineitem_count = rec_invoice.getLineItemCount(FLD_INV_ITEM);
    var pwp_ids = [];

    // Update PWP's Invoiced Amount is wrapped to try/ catch
    // As this might throw an error if in case the record does not exist
    try {
        for (var i=1; i<=lineitem_count; i++) {
            rec_invoice.selectLineItem(FLD_INV_ITEM, i);

            var preclose_amount = rec_invoice.getCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_AMOUNT);
            rec_invoice.setCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_PRECLOSEAMOUNT, preclose_amount);

            //rec_invoice.setCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_AMOUNT, 0);
            rec_invoice.setCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_CLIENTGROSSALLOC, 0);
            rec_invoice.setCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_CLOSEPROCESSED, 'T');

            var pwp_customrecord = rec_invoice.getCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_PWPRECORD);
            if (!isNullOrEmpty(pwp_customrecord) && !exists(pwp_ids, pwp_customrecord)) {
                pwp_ids.push(pwp_customrecord);
            }
            rec_invoice.commitLineItem(FLD_INV_ITEM);
        }
        //Update PWP after updating the Invoice
        if (nlapiSubmitRecord(rec_invoice)) {
            for (var i=0; i<pwp_ids.length; i++) {
                nlapiSubmitField(RECTYPE_PWP, pwp_ids[i], [], []);
            }
        }
    }
    catch (err) {
        successful = false;
        nlapiLogExecution('DEBUG', 'Unable to update related PWP Custom Record', err.name + ' : ' + err.message);
    }
    return successful;
}

// This function evaluates whether the invoice satisfies the following criteria to display
// a. CI status is not started
// b. CI Record is empty
// c. At least one line is Close Processed unchecked
function checkAnyLineItemToClose(rec_invoice) {
    var show_button = false;
    var lineitem_count = rec_invoice.getLineItemCount(FLD_INV_ITEM);
    for (var i=1; i<=lineitem_count; i++) {
        rec_invoice.selectLineItem(FLD_INV_ITEM, i);
        var val_ci_status = rec_invoice.getCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_CISTATUS);
        var val_ci_record = rec_invoice.getCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_CIRECORD);
        var val_close_processed = rec_invoice.getCurrentLineItemValue(FLD_INV_ITEM, FLD_INV_LINEITEM_CLOSEPROCESSED);

        if (val_ci_status == VAL_LINEITEM_CISTATUS_NOTSTARTED && isNullOrEmpty(val_ci_record) && val_close_processed != 'T') {
            show_button = true;
            break;
        }
    }
    return show_button;
}

function exists(list, key) {
    for (var index in list) {
        if (list[index] == key) {
            return true;
        }
    }
    return false;
}

function isNullOrEmpty(data) {
    return (data == null || data == '');
}
