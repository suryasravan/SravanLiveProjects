/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : Generate Special PO for Sales Orders
* Company     : Appficiency Inc.
*/

var SPARAM_SEARCH_PARAMETER = 'custscript_appf_sparam_sosavedsearch_s2';
var SPARAM_SEARCH_INDEX = 'custscript_appf_sparam_searchindex_s2';
var SPARAM_SO_LINE_INDEX = 'custscript_appf_sparam_lineindex_s2';
var SPARAM_ERROR_PO_MSG = 'custscript_appf_sparam_errormsg_s2';
var SPARAM_STATUS = 'custscript_appf_sched_po_status';


var FLD_SO_PO_VENDOR = 'custcol_appf_po_vendor_name';
var FLD_SO_PO_GENERATION_COMPLETE = 'custcol_appf_po_generation_complete';
var FLD_SO_PO_GENERATION_ERROR = 'custbody_appf_po_generation_error';

var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020

var FLD_SO_SCHED_PO_STATUS = 'custbody_appf_sched_po_status';

var startTime = new Date().getTime();


/// Callback
var SPARAM_CALLBACK_SCRIPT = 'custscript_appf_sparam_step2cb_script';
var SPARAM_CALLBACK_DEPLOY = 'custscript_appf_sparam_step2cb_deploy';

function scheduled_generatePOStep2(type) {
    var context = nlapiGetContext();
	var searchId = context.getSetting('SCRIPT', SPARAM_SEARCH_PARAMETER);
	var nLineIndex = context.getSetting('SCRIPT', SPARAM_SO_LINE_INDEX) || 1;

	var index = context.getSetting('SCRIPT', SPARAM_SEARCH_INDEX);
	if (index == null || index == '')
		index = 0;
    //nlapiLogExecution('debug', 'file index', index);

	var lineIndex = context.getSetting('SCRIPT', SPARAM_SO_LINE_INDEX);
	if (lineIndex == null || lineIndex == '')
		lineIndex = 1;

	var errorPOMsg = context.getSetting('SCRIPT', SPARAM_ERROR_PO_MSG) || '';
	var status = context.getSetting('SCRIPT', SPARAM_STATUS) || '';

    var callbackScript = context.getSetting('SCRIPT', SPARAM_CALLBACK_SCRIPT);
    var callbackDeploy = context.getSetting('SCRIPT', SPARAM_CALLBACK_DEPLOY);

    if(searchId){
        var objSearch= nlapiLoadSearch(null, searchId);
    	var filters = objSearch.getFilters();
    	var columns = objSearch.getColumns();
    	var ssType = objSearch.getSearchType();
    	var searchResults = getAllSearchResults(ssType, filters, columns);

    	if (searchResults != null && searchResults != '') {
    		for (var s=index; s<searchResults.length; s++) {
    			var result = searchResults[s];
                var recType = 'salesorder'; //result.getRecordType();
                var idSalesOrder = result.getId();
                var columns = result.getAllColumns();
    			var idSalesOrder = result.getValue(columns[0]);
    			var idCustomer = result.getValue(columns[1]);
    			recType= 'salesorder';

    			//log.debug('sales order:', idSalesOrder);
    			nlapiLogExecution('DEBUG', 'sales order:',idSalesOrder);
                //check time
                var endTime = new Date().getTime();
                //Calculate the Time Elapsed between End Time and Start Time

                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                //nlapiLogExecution('DEBUG', 'TIME ELAPSED Outside',timeElapsed);
                if( timeElapsed > 1500 || (context.getRemainingUsage() <= 1000 /*&& parseInt(s)+1 < searchResults.length*/) ) {
                    var params = {};
                    params[SPARAM_SEARCH_PARAMETER] = searchId;
                    params[SPARAM_SEARCH_INDEX] = s; //(s+1);
                    nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                    break;
                }else{
                	//var scriptStep = 1;
        	    	var errorMsg = '';
                    //load sales order
                    //nlapiLogExecution('debug', 'remaining usage before', context.getRemainingUsage());
        	    	try{

            			//check time
                        var timeElapsed = (endTime*0.001) - (startTime*0.001);

                        nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 3 before loading',timeElapsed);

                        if(timeElapsed > 1500){ //25 minutes
                            var params = {};
                            params[SPARAM_SEARCH_PARAMETER] = searchId;
                            params[SPARAM_SEARCH_INDEX] = s;
                            nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                            break;
                        }else{
                            var recSO = nlapiLoadRecord(recType,idSalesOrder);
                            var status = recSO.getFieldValue(FLD_SO_SCHED_PO_STATUS);
                            nlapiLogExecution('DEBUG', 'step 2 status',status + ' errorPOMsg='+errorPOMsg);

                            //if(status == 1){
                                //get all vendor
                                 var nLines = recSO.getLineItemCount('item');
                                 var aVendors = [];

                                 if(errorPOMsg == null || errorPOMsg == ''){
                                     var oHashedData = new Object();
                                     for(var x = nLineIndex; x <= nLines; x++) {
                                         try {
                                             var idVendor = recSO.getLineItemValue('item', 'povendor', x);
                                             var poId = recSO.getLineItemValue('item', 'poid', x);
                                             var getSOLineID = recSO.getLineItemValue('item', 'custcol_appf_line_id', x);
                                             if (isNullOrEmpty(poId)) {
                                                 var params = {
                                                     'recordmode' : 'dynamic',
                                                     'soid' : idSalesOrder,
                                                     'specord' : 'T',
                                                     'custid' : idCustomer,
                                                     'entity': idVendor,
                                                     'poentity':idVendor
                                                 };


                                     			//check time
                                                 var timeElapsed = (endTime*0.001) - (startTime*0.001);
                                                 if(timeElapsed > 1500){ //25 minutes
                                                     var params = {};
                                                     params[SPARAM_SEARCH_PARAMETER] = searchId;
                                                     params[SPARAM_SEARCH_INDEX] = s;
                                                     params[SPARAM_SO_LINE_INDEX] = x;
                                                     nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                                     break;
                                                 }else{
                                                     if( (context.getRemainingUsage() <= 1000 /*&& parseInt(s)+1 < searchResults.length */) ) {
                                                         var params = {};
                                                         params[SPARAM_SEARCH_PARAMETER] = searchId;
                                                         params[SPARAM_SEARCH_INDEX] = s;
                                                         params[SPARAM_SO_LINE_INDEX] = x;
                                                         nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                                         break;
                                                     }else{
                                                         nlapiLogExecution('DEBUG', 'Create PO Params', JSON.stringify(params));
                                                         var purchaseOrder = nlapiCreateRecord('purchaseorder', params);

                                                         var nPOLines = purchaseOrder.getLineItemCount('item');
                                                         nlapiLogExecution('DEBUG', 'nPOLines', nPOLines);
                                                         //delete other nLines
                                                         for(var z = nPOLines; z >= 1; z--) {

                                               					     var getLineId = purchaseOrder.getLineItemValue('item', 'custcol_appf_line_id', z);

                                               					   	 if(getLineId != getSOLineID) {

                                               							     purchaseOrder.removeLineItem('item', z);

                                               						   }

                                               					}

                                                         var poId = nlapiSubmitRecord(purchaseOrder);
                                                         nlapiLogExecution('DEBUG', 'PO Created',poId);
                                                     }
                                                 }
                                             }
                                         }
                                         catch (err) {
                                             nlapiLogExecution('DEBUG', 'Unable to Create PO', err.name + ' : ' + err.message);
                                         }
                                     }
                                 }
                            //}

                        }

        	    	}catch(errorMsg){
        	    		 nlapiLogExecution('debug', 'error', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder + 'errorMSg='+errorMsg.message);

        	    	}

                }
    			//check time
                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                nlapiLogExecution('debug', 'remaining usage after', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder + ' timeElapsed='+timeElapsed);
    		}

            if (!isNullOrEmpty(callbackScript) && !isNullOrEmpty(callbackDeploy)) {
                nlapiScheduleScript(callbackScript, callbackDeploy);
            }

        }
    }
}

function getAllSearchResults(record_type, filters, columns) {
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);

    var searchRan = search.runSearch()
    ,	bolStop = false
    ,	intMaxReg = 1000
    ,	intMinReg = 0
    ,	result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000) {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array) {
    return target.concat(array); // TODO: use _.union
}


function isNullOrEmpty(data) {
    return (data == null || data == '');
}