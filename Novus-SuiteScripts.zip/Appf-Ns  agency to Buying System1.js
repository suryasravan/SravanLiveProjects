/*
* Script Name : Appf - NS Contact To Buying System - UE
* Script Type : UserEvent
* Event Type  : After Submit
* Description : This script triggers on submit of Contact, prepares raw JSON, makes a secured connection to Azure SB, send the json to queue and creates the custom record with linking record and response
* Company     :	Appficiency Inc.
*/

 var CUSTOMRECORD_APPF_OUT_BOUND_BYING_CONTRACT_RECS='customrecord_appf_buying_syst_agency_out';
 var CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTRACT ='custrecord_appf_jsonconetnt_out_agency';
 var CUSTOMRECORD_FLD_APPF_CONTRACT_LINK='custrecord_agency_record';
 var CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_CONTRACT ='custrecord_appf_azureresponse_agency';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME_CONTRACT='custrecord_appfstrata_agency_queue_names';
 var CUSTOMRECORD_FLD_APPF_STATUS='custrecord_agency_status'
 // var NS_OB_RESPONSE_PROPERTY='Novus.Integration.NetSuite.Interfaces.INetSuiteAgency'
 var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Incoming.NetSuite.AgencyIncomingMessage'
 var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
 
function agencyMessage(type)
{
 if(type!='delete' )
	{
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
      var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
      // && nlapiGetContext().getExecutionContext() != 'scheduled'
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var customerRec=nlapiLoadRecord(recordType,recordId)
	   var contract=customerRec.getFieldValue('parent')
	   if(contract==null || contract=='')
	   {
		var customerRecFields=customerRec.getAllFields()
		var queueName='netsuite_crm_agency'
        
			var main1={}
		for(var i=0;i<customerRecFields.length;i++) 
       {
		     //var main={}
			var customerRecFieldId=customerRecFields[i]
			var customerRecFieldValue=customerRec.getFieldValue(customerRecFieldId)
			if(customerRecFieldValue==null)
		      customerRecFieldValue=''
		      main1[customerRecFieldId]=customerRecFieldValue
		} 
var addressbookCount=customerRec.getLineItemCount('addressbook')
var addressbookCount1=customerRec.getAllLineItemFields('addressbook')
if(addressbookCount>=1)
{
var addressbookaddr1=customerRec.getLineItemValue('addressbook','addr1',1)
                     if(addressbookaddr1==null)
		      addressbookaddr1=''
			  var addressbookaddr2=customerRec.getLineItemValue('addressbook','addr2',1)
                     if(addressbookaddr2==null)
		      addressbookaddr2=''
			  var addressbookaddr3=customerRec.getLineItemValue('addressbook','addr3',1)
                     if(addressbookaddr3==null)
		      addressbookaddr3=''
			  var addressbookZip=customerRec.getLineItemValue('addressbook','zip',1)
                     if(addressbookZip==null)
		      addressbookZip=''
			   var addressbookState=customerRec.getLineItemValue('addressbook','state',1)
                     if(addressbookState==null)
		      addressbookState=''
			   var addressbookCty=customerRec.getLineItemValue('addressbook','city',1)
                     if(addressbookCty==null)
		      addressbookCty=''
		    var addressbookCountry=customerRec.getLineItemValue('addressbook','country',1)
                     if(addressbookCountry==null)
		      addressbookCountry=''
     var phoneaddr=customerRec.getLineItemValue('addressbook','phone',1)
                     if(phoneaddr==null)
		      phoneaddr=''
		    var addressbookattention=customerRec.getLineItemValue('addressbook','attention',1)
                     if(addressbookattention==null)
		      addressbookattention=''
		    var addressbookaddressee=customerRec.getLineItemValue('addressbook','addressee',1)
                     if(addressbookaddressee==null)
		      addressbookaddressee=''
		      //addressbookInternalOb.addr1=addressbookaddr1
			    main1.addr1=addressbookaddr1
			    main1.addr2=addressbookaddr2
			    main1.addr3=addressbookaddr3
			    main1.zip=addressbookZip
                 main1.phoneaddr=phoneaddr
			    main1.attention=addressbookattention
			    main1.addressee=addressbookaddressee
			    main1.state=addressbookState
			    main1.city=addressbookCty
			    main1.country=addressbookCountry
}
         if(URL_BASE!=null && URL_BASE!='')
           {
var url = URL_BASE+queueName+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":signatures};
         HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
var response=nlapiRequestURL(url, body, HEADERS, null,'POST');
nlapiLogExecution('debug', 'response',response);
var responseData=response.getBody()
		//nlapiLogExecution('debug', ' responseData',responseData);
		//nlapiSendEmail(1224,'laxmikanth@cloudalp.com','test',JSON.stringify(main1),null,null,null,HEADERS)
		nlapiLogExecution('debug', ' main1',JSON.stringify(main1));
		
		
		
		var outboundFlowRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_OUT_BOUND_BYING_CONTRACT_RECS)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_CONTRACT,responseData)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_OUT_JSON_CONTRACT,JSON.stringify(main1))
		if(response.getCode()=='200' || response.getCode()=='201')
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Success')
        else	
	    outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Failed')  
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTRACT_LINK,recordId)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME_CONTRACT,queueName)
		nlapiSubmitRecord(outboundFlowRecord,true,true)
	   }
       }
	}
	
}

