/*
*Script Name: Appf- PO Lines Close Processed SC
*Script Type: Scheduled
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       15 may 2020     		         This script handles the backend processing of marking Close Processed  checkbox on all selected SO lines from PO Lines Close Processed SL through CSV import
*/

var SPARAM_CSV_FILE_ID = 'custscript_appf_po_lines_close_folder';
var IMPORT_CSV_PO_LINES = 'custimport_close_processed_po_script';

function POLinesCloseSC(type){
	try{
	var context = nlapiGetContext();
	var csvFileId = context.getSetting('SCRIPT', SPARAM_CSV_FILE_ID);
	 nlapiLogExecution( 'DEBUG', 'csvFileId', csvFileId)
		
		
		if(csvFileId != null && csvFileId != ''){
			var csvFile = nlapiLoadFile(csvFileId);
			nlapiLogExecution( 'DEBUG', 'csvFile', csvFile)
			
				var importSILines = nlapiCreateCSVImport();
				importSILines.setMapping(IMPORT_CSV_PO_LINES);
				importSILines.setPrimaryFile(csvFile);
				var processingJOBID = nlapiSubmitCSVImport(importSILines);
				nlapiLogExecution( 'DEBUG', 'processingJOBID', processingJOBID)
	
		
	}
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
}