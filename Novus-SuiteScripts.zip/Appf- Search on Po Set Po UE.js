/*
* Script Name : Appf - Send Vendors Message To Queue
* Script Type : UserEvent
* Event Type  : 
* Description :
* Company     :	Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_VB='customrecord_appf_interim_vb_line';
 var CUSTOMRECORD_APPF_IN_VB_LINE_RECS='recmachcustrecord_appf_interimheader';
 var CUSTOMRECORD_FLD_VB_LINE_IO ='custrecord_appf_ivbl_io_num';
 var CUSTOMRECORD_FLD_VB_LINE_PO ='custrecord_appf_ivbl_vendor_name';
 var CUSTOMRECORD_FLD_VB_LINE_PO_IDS ='custrecord_appf_ivbl_po_link';
 var CUSTOMRECORD_FLD_VB_LINES='custrecord_appf_ivbl_po_line_id';
 var CUSTOMRECORD_FLD_VB_CURRECNCY='custrecord_appf_ivbl_pocurrency';
 var CUSTOMRECORD_FLD_VB_MEDIAS='cseg_appf_media_seg';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_contact_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_LINK='custrecord_appf_ivbl_pwplink';
 
 var CUST_FLD_MEDIASUPPS='custcol_appf_publisher'
 var CUST_FLD_MEDIASEG='cseg_appf_media_seg'
 var CUST_FLD_IO='custcol_appf_ionum'
 
 var CUST_FLD_VENDOR_IDS='custrecord_appf_ivbl_vendor_name'
 
 var SPARAM_POS='custcol_appf_ionum'
 var SPARAM_POS='custcol_appf_ionum'
function posetMessage(type)
{
 if(type!='delete')
	{
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var payRec=nlapiLoadRecord(recordType,recordId)
	   nlapiLogExecution('debug','payRec',payRec); 
	//  var custVb= payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB)
		var payRecFields=payRec.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS)
		for(var i=1;i<=payRecFields;i++) 
        {
		   var ios=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_IO,i)
		  // var meddias=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_MEDIAS,i)
		   var custVb=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUST_FLD_VENDOR_IDS,i)
		                        var nsfils = [];
	                            nsfils.push(new nlobjSearchFilter('type',null,'is','PurchOrd'));
							    nsfils.push(new nlobjSearchFilter('mainline',null,'is','F'));
									if(custVb!=null && custVb!='')
								nsfils.push(new nlobjSearchFilter('entity',null,'is',custVb));
							   if(ios!=null && ios!='')
								nsfils.push(new nlobjSearchFilter(CUST_FLD_IO,null,'is',ios));
							
							 var nscolms = [];
							nscolms.push(new nlobjSearchColumn('custcol_appf_po_line_id'));
							nscolms.push(new nlobjSearchColumn('currency'));
							nscolms.push(new nlobjSearchColumn('custcol_appf_pwp_custom_record'));
							
							  var custRecord=nlapiSearchRecord('transaction', null, nsfils,nscolms);
							  if(custRecord!=null && custRecord!='')
							  {
	                              nlapiLogExecution('debug','custRecord',custRecord[0].getId()); 
                                  payRec.selectLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,i)
			                      payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINES,custRecord[0].getValue('custcol_appf_po_line_id'))
			                      payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_PO_IDS,custRecord[0].getId())
								  payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_CURRECNCY,custRecord[0].getValue('currency'))
								  payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_APPF_LINK,custRecord[0].getValue('custcol_appf_pwp_custom_record'))
			                      payRec.commitLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS)	
							  }			
		   
		} 
		 nlapiSubmitRecord(payRec,true,true)
		 
		  var payRec=nlapiLoadRecord(recordType,recordId)
	   nlapiLogExecution('debug','payRec',payRec); 
	  var custVb= payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB)
		var payRecFields=payRec.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS)
		 var totaPos=0
		for(var i=1;i<=payRecFields;i++) 
        {
			 var poIds=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_PO_IDS,i)
		     var ioNos=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINES,i)
			 if((poIds!=null && poIds!='') && (ioNos!=null && ioNos!=''))
				 totaPos=totaPos+1
		}
	}
	
}
