/*
* Script Name : Appf - NS Vendors To Buying System - UE
* Script Type : UserEvent
* Event Type  : After Submit
* Description : This script triggers on submit of Vendor, prepares raw JSON, makes a secured connection to Azure SB, send the json to queue and creates the custom record with linking record and response
* Company     :	Appficiency Inc.
*/

 var CUSTOMRECORD_APPF_OUT_BOUND_BYING_VENDOR_RECS='customrecord_appf_buying_syst_vendor_out';
 var CUSTOMRECORD_FLD_APPF_OUT_JSON_VENDORS ='custrecord_appf_jsonconetnt_out_vendor';
 var CUSTOMRECORD_FLD_APPF_VENDORS_LINK='custrecordvendor_record';
 var CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_VENDORS ='custrecord_appf_azureresponse_vendors';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME_VENDORS='custrecord_appf_buying_system_queuename';
 var CUSTOMRECORD_FLD_APPF_STATUS='custrecord_status';
// var NS_OB_RESPONSE_PROPERTY='Novus.Integration.NetSuite.Interfaces.INetSuiteVendor'
var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Incoming.NetSuite.VendorIncomingMessage'
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

 
function vendorMessage(type)
{
 if(type!='delete')
	{
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var vendorRec=nlapiLoadRecord(recordType,recordId)
		var vendorRecFields=vendorRec.getAllFields()
		var queName='netsuite_crm_vendor'
		var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
			var main1={}
		for(var i=0;i<vendorRecFields.length;i++) 
       {
		     //var main={}
			var vendorRecFieldId=vendorRecFields[i]
			var vendorRecFieldValue=vendorRec.getFieldValue(vendorRecFieldId)
			if(vendorRecFieldValue==null)
		      vendorRecFieldValue=''
		      main1[vendorRecFieldId]=vendorRecFieldValue
		}
var addressbookCount=vendorRec.getLineItemCount('addressbook')
	  if(addressbookCount>=1)
	  {
        var addressbook1=[]
        for(var i=1;i<=addressbookCount;i++) 
       {
         var addressbook={}
var addressbookaddr1=vendorRec.getLineItemValue('addressbook','addr1',i)
                     if(addressbookaddr1==null)
		      addressbookaddr1=''
			  var addressbookaddr2=vendorRec.getLineItemValue('addressbook','addr2',i)
                     if(addressbookaddr2==null)
		      addressbookaddr2=''
			  var addressbookaddr3=vendorRec.getLineItemValue('addressbook','addr3',i)
                     if(addressbookaddr3==null)
		      addressbookaddr3=''
			  var addressbookZip=vendorRec.getLineItemValue('addressbook','zip',i)
                     if(addressbookZip==null)
		      addressbookZip=''
			   var addressbookState=vendorRec.getLineItemValue('addressbook','state',i)
                     if(addressbookState==null)
		      addressbookState=''
			   var addressbookCty=vendorRec.getLineItemValue('addressbook','city',i)
                     if(addressbookCty==null)
		      addressbookCty=''
		  
		    var addressbookattention=vendorRec.getLineItemValue('addressbook','attention',i)
                     if(addressbookattention==null)
		      addressbookattention=''
		    var addressbookaddressee=vendorRec.getLineItemValue('addressbook','addressee',i)
                     if(addressbookaddressee==null)
		      addressbookaddressee=''	 
         
           var addressbookisresidential=vendorRec.getLineItemValue('addressbook','isresidential',i)
                     if(addressbookisresidential==null)
		      addressbookisresidential=''
         
           var defaultshipping=vendorRec.getLineItemValue('addressbook','defaultshipping',i)
                     if(defaultshipping==null)
		      defaultshipping=''
         
           var defaultbilling=vendorRec.getLineItemValue('addressbook','defaultbilling',i)
                     if(defaultbilling==null)
		      defaultbilling=''
         
           var addressbookphone=vendorRec.getLineItemValue('addressbook','phone',i)
                     if(addressbookphone==null)
		      addressbookphone=''
          var addressbooklabel=vendorRec.getLineItemValue('addressbook','label',i)
                     if(addressbooklabel==null)
		      addressbooklabel=''
           var addressbookCountry=vendorRec.getLineItemValue('addressbook','country',i)
                     if(addressbookCountry==null)
		      addressbookCountry=''
		      addressbook.addr1=addressbookaddr1
			addressbook.addr2=addressbookaddr2
			 addressbook.addr3=addressbookaddr3
			 addressbook.zip=addressbookZip
			  addressbook.attention=addressbookattention
			   addressbook.addressee=addressbookaddressee
			 addressbook.state=addressbookState
			  addressbook.city=addressbookCty
			  addressbook.country=addressbookCountry
          addressbook.defaultshipping=defaultshipping
          addressbook.defaultbilling=defaultbilling
          addressbook.label=addressbooklabel
         addressbook.addrphone=addressbookphone
          addressbook.isresidential=addressbookisresidential
         addressbook1.push(addressbook)
       
       }
        main1.addressbook=addressbook1
	  }	
      if(URL_BASE!=null && URL_BASE!='')
        {
var url = URL_BASE+queName+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":signatures};
      HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
var response=nlapiRequestURL(url, body, HEADERS, null,'POST');
nlapiLogExecution('debug', 'response code',response.getCode());
var responseData=response.getBody()
		nlapiLogExecution('debug', ' responseData',responseData);
		//nlapiSendEmail(1224,'laxmikanth@cloudalp.com','test',JSON.stringify(main1),null,null,null,HEADERS)
		nlapiLogExecution('debug', ' main1',JSON.stringify(main1));
		
		
		
		var outboundFlowRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_OUT_BOUND_BYING_VENDOR_RECS)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_VENDORS,responseData)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_OUT_JSON_VENDORS,JSON.stringify(main1))
		if(response.getCode()=='200' || response.getCode()=='201')
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Success')
        else	
	    outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_STATUS,'Failed')  
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_VENDORS_LINK,recordId)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME_VENDORS,queName)
		nlapiSubmitRecord(outboundFlowRecord,true,true)
		
	}
    }
      
	
}

