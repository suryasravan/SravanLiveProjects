/*Script Name: Appf-Consolidated Invoice Email/Download SL
 *Script Type: Suitelet
 *Description: a. This script is used to display all the CI Records from the saved search "appf - Consolidated Invoices Print and Download Suitelet (Script - DNU)" as a list with all 						available filters.
                b. Upon selecting the lines, it sends to another suitelet for email or download the consolidated PDFs.
                Author: Nazish
 *Company 	 : Appficiency.
 */
var SL_FLD_CLIENT = 'custpage_client';
var SL_FLD_PARENT_CLIENT = 'custpage_pclient';
var SL_FLD_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_MEDIA_SEGMENT = 'custpage_media_segment';
var SL_FLD_FROM_DATE = 'custpage_from_date';
var SL_FLD_TO_DATE = 'custpage_to_date';
var SL_FLD_DUE_FROM_DATE = 'custpage_from_due_date';
var SL_FLD_DUE_TO_DATE = 'custpage_to_due_date';
var SL_FLD_LINE_OF_BUSINESS = 'custpage_line_of_business';
var SL_FLD_CURRENCY = 'custpage_currency';
var SL_FLD_CONTRACT = 'custpage_contract';
var SL_FLD_PDF_TEMPLATE = 'custpage_pdf_template';
var SL_FLD_EMAIL_TEMPLATE = 'custpage_email_template';
var SL_FLD_EMAIL_SENT = 'custpage_email_sent';

var CUSTOM_RECORD_MEDIA_SUPPLIER = 'customrecord_appf_media_supplier';
var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
var CUSTOM_RECORD_CI_RECORD = 'customrecord_appf_ci_record';

var SL_SUBLIST = 'custpage_custom_line';
var SL_COL_MARK = 'custpage_mark';
var BTN_MARK_ALL = 'custpage_mark_All';
var BTN_UNMARK_ALL = 'custpage_unmark_All';
var BTN_APPLY_FILTER = 'custpage_apply_filters';
var BTN_DOWNLOAD_PDF = 'custpage_download_pdf';
var BTN_SEND_PDF = 'custpage_send_pdf';

var SPARAM_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD_SL_SS = 'custscript_appf_consolidated_inv_ss';
var CLIENT_SCRIPT = 'customscript_appf_consolidated_inv_cl';

var CUSTOM_RECORD_INVOICE_LAYOUT_SETUP = 'customrecord_appf_invoice_layout_setup';
var FLD_INVOICE_LAYOUT_SETUP_RECORD_PDF_LAYOUT = 'custrecord_appf_ils_pdflayout';
var FLD_CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CI_RECORD_CLIENT = 'custrecord_appf_ci_client';
var FLD_CI_RECORD_PARENT_CLIENT = 'custrecord_appf_ci_parent';
var FLD_CI_RECORD_SUBSIDIARY = 'custrecord_appf_ci_subsidiary';
var FLD_CI_RECORD_DATE = 'custrecord_appf_ci_date';
var FLD_CI_RECORD_DUE_DATE = 'custrecord_appf_ci_due_date';
var FLD_CI_RECORD_CURRENCY = 'custrecord_appf_ci_currency';
var FLD_CI_RECORD_CONTRACT = 'custrecord_appf_ci_contract';
var FLD_CONTRACT_LINE_OF_BUSINESS = 'custrecord_appf_contract_lineofbusiness';
var FLD_CONTRACT_MEDIA_SEGMENT = 'cseg_appf_media_seg';
var FLD_CI_RECORD_PDF_TEMPLATE = 'custrecord_appf_ci_pdf_template';
var FLD_CI_RECORD_EMAIL_SENT = 'custrecord_appf_ci_email_sent';

var SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD = 'customscript_appf_consolidated_inv_pdf';
var DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD = 'customdeploy_appf_consolidated_inv_pdf';

var SENDER = 'lreddy@appficiencyinc.com';
var RECIPIENT = 'nansari@appficiencyinc.com';

var CI_RECORD_TEMPLATE = '115';

var pageSize = 15;


function consolidatedInvPrintDownloadSL ( request, response ) {
    var context = nlapiGetContext();
    var ssID = context.getSetting( 'SCRIPT', SPARAM_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD_SL_SS );
    var loadSS = nlapiLoadSearch( null, ssID );
    var filts = loadSS.getFilters();
    var columns = loadSS.getColumns();
    var ssType = loadSS.getSearchType();
    if ( request.getMethod() == 'GET' ) {
        /* var params = request.getAllParameters();
   for ( param in params )
   {
       nlapiLogExecution('DEBUG', 'parameter: value', param +'========='+params[param]);
   } */
        try {
            var applyFilters = request.getParameter( 'applyFils' );
            var client = request.getParameter( 'client' );
            var parentClient = request.getParameter( 'pclient' );
            var subsidiary = request.getParameter( 'subs' );
            var fromDate = request.getParameter( 'dtFrom' );
            var toDate = request.getParameter( 'dtTo' );
            var fromDueDate = request.getParameter( 'ddtFrom' );
            var toDueDate = request.getParameter( 'ddtTo' );
            var currency = request.getParameter( 'currency' );
            var contract = request.getParameter( 'contract' );
            var mediaSegment = request.getParameter( 'mediasegment' );
            var lineofbusiness = request.getParameter( 'lineofbusiness' );
            //	var pdfTemplate=request.getParameter('pdftemplate');
            var emailTemplate = request.getParameter( 'emailTemplate' );
            var emailSent = request.getParameter( 'emailSent' );




            var form = nlapiCreateForm( 'Consolidated Invoice Print and Download Suitelet' );
            var firstTab = form.addSubTab( 'custpage_customtab', 'List' );
            // var secondTab = form.addSubTab( 'custpage_studentcontacttab', 'Student Contact' );
            form.setScript( CLIENT_SCRIPT );

            var clientFld = form.addField( SL_FLD_CLIENT, 'select', 'Client', 'customer' );
            if ( client != null && client != '' )
                clientFld.setDefaultValue( client );

            var pClientFld = form.addField( SL_FLD_PARENT_CLIENT, 'select', 'Parent Client', 'customer' );
            if ( parentClient != null && parentClient != '' )
                pClientFld.setDefaultValue( parentClient );

            var subsidiaryFld = form.addField( SL_FLD_SUBSIDIARY, 'select', 'Subsidiary', 'subsidiary' );
            if ( subsidiary != null && subsidiary != '' )
                subsidiaryFld.setDefaultValue( subsidiary );

            var mediaSegmentFld = form.addField( SL_FLD_MEDIA_SEGMENT, 'select', 'Media Segment', CUSTOM_RECORD_MEDIA_SEGMENT );
            if ( mediaSegment != null && mediaSegment != '' )
                mediaSegmentFld.setDefaultValue( mediaSegment );

            var fromDateFld = form.addField( SL_FLD_FROM_DATE, 'date', 'Date (From)' );
            if ( fromDate != null && fromDate != '' )
                fromDateFld.setDefaultValue( fromDate );
            //05-12-2023 added by shravan kumar by default adding today date to date From field 
            else {
                var compPrefs = nlapiLoadConfiguration( 'companyinformation' );
                var timezone = compPrefs.getFieldValue( 'timezone' );
                var date = nlapiDateToString( new Date(), timezone )
                fromDateFld.setDefaultValue( date );
            }

            var toDateFld = form.addField( SL_FLD_TO_DATE, 'date', 'Date (To)' );
            if ( toDate != null && toDate != '' )
                toDateFld.setDefaultValue( toDate );

            var due_fromDateFld = form.addField( SL_FLD_DUE_FROM_DATE, 'date', 'Due Date (From)' );
            if ( fromDueDate != null && fromDueDate != '' )
                due_fromDateFld.setDefaultValue( fromDueDate );

            var due_toDateFld = form.addField( SL_FLD_DUE_TO_DATE, 'date', 'Due Date (To)' );
            if ( toDueDate != null && toDueDate != '' )
                due_toDateFld.setDefaultValue( toDueDate );

            var lineOfBusinessFld = form.addField( SL_FLD_LINE_OF_BUSINESS, 'select', 'Line Of Business', 'classification' );
            if ( lineofbusiness != null && lineofbusiness != '' )
                lineOfBusinessFld.setDefaultValue( lineofbusiness );

            var currencyFld = form.addField( SL_FLD_CURRENCY, 'select', 'Currency', 'currency' );
            if ( currency != null && currency != '' )
                currencyFld.setDefaultValue( currency );

            var contractFld = form.addField( SL_FLD_CONTRACT, 'select', 'Contract', CUSTOM_RECORD_CONTRACT );
            if ( contract != null && contract != '' )
                contractFld.setDefaultValue( contract );

            //  var pdfTemplateFld = form.addField(SL_FLD_PDF_TEMPLATE, 'select', 'PDF Template',CUSTOM_RECORD_INVOICE_LAYOUT_SETUP);
            //  if(pdfTemplate != null && pdfTemplate != '')
            //	  pdfTemplateFld.setDefaultValue(pdfTemplate);
            var emailTemplateFld = form.addField( SL_FLD_EMAIL_TEMPLATE, 'select', 'Email Template', 'emailtemplate' );
            if ( emailTemplate != null && emailTemplate != '' )
                emailTemplateFld.setDefaultValue( emailTemplate );
            var emailSentFld = form.addField( SL_FLD_EMAIL_SENT, 'checkbox', 'Email Sent' );
            if ( emailSent != null && emailSent != '' )
                emailSentFld.setDefaultValue( emailSent );

            if ( applyFilters == 'T' ) {
                var suiteletSublist = form.addSubList( SL_SUBLIST, 'list', 'List', 'custpage_customtab' );
                suiteletSublist.addField( SL_COL_MARK, 'checkbox', 'Mark' ).setDisplayType( 'entry' );
                suiteletSublist.addField( 'custpage_internalid', 'text', 'Internal ID' ).setDisplayType( 'hidden' );
                suiteletSublist.addButton( BTN_MARK_ALL, 'Mark All', 'markAll();' );
                suiteletSublist.addButton( BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();' );

                var filters = [];
                if ( client != null && client != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_CLIENT, null, 'anyof', client ) );
                if ( emailSent != null && emailSent != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_EMAIL_SENT, null, 'is', emailSent ) );
                if ( emailSent == null || emailSent == '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_EMAIL_SENT, null, 'is', 'F' ) );
                if ( parentClient != null && parentClient != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_PARENT_CLIENT, null, 'anyof', parentClient ) );

                if ( subsidiary != null && subsidiary != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_SUBSIDIARY, null, 'is', subsidiary ) );

                if ( fromDate != null && fromDate != '' && toDate != null && toDate != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DATE, null, 'within', fromDate, toDate ) );
                else if ( ( fromDate != null && fromDate != '' ) && ( toDate == null || toDate == '' ) )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DATE, null, 'onorafter', fromDate ) );
                else if ( ( fromDate == null || fromDate == '' ) && ( toDate != null && toDate != '' ) )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DATE, null, 'onorbefore', toDate ) );

                if ( fromDueDate != null && fromDueDate != '' && toDueDate != null && toDueDate != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DUE_DATE, null, 'within', fromDueDate, toDueDate ) );
                else if ( ( fromDueDate != null && fromDueDate != '' ) && ( toDueDate == null || toDueDate == '' ) )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DUE_DATE, null, 'onorafter', fromDueDate ) );
                else if ( ( fromDueDate == null || fromDueDate == '' ) && ( toDueDate != null && toDueDate != '' ) )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_DUE_DATE, null, 'onorbefore', toDueDate ) );

                if ( currency != null && currency != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_CURRENCY, null, 'is', currency ) );
                ;
                if ( contract != null && contract != '' )
                    filters.push( new nlobjSearchFilter( FLD_CI_RECORD_CONTRACT, null, 'anyof', contract ) );

                if ( mediaSegment != null && mediaSegment != '' )
                    filters.push( new nlobjSearchFilter( FLD_CONTRACT_MEDIA_SEGMENT, FLD_CI_RECORD_CONTRACT, 'anyof', mediaSegment ) );

                if ( lineofbusiness != null && lineofbusiness != '' )
                    filters.push( new nlobjSearchFilter( FLD_CONTRACT_LINE_OF_BUSINESS, FLD_CI_RECORD_CONTRACT, 'anyof', lineofbusiness ) );

                //     if(pdfTemplate != null && pdfTemplate != '')
                //	filters.push(new nlobjSearchFilter(FLD_CI_RECORD_PDF_TEMPLATE, null, 'anyof', pdfTemplate));

                var resultFilters = filters.concat( filts );

                var colArr = [];
                var colIndex = 1;
                var scriptUseDNRIndex = 1;
                for ( var i = 0; i < columns.length; i++ ) {
                    var colObj = columns[ i ];
                    var colName = colObj.getName();
                    var colLabel = colObj.getLabel();

                    if ( colArr.indexOf( colName ) == -1 ) {
                        colArr.push( colName )
                    }
                    else {
                        colName = colName + colIndex;
                        colIndex++;
                    }
                    if ( colLabel == 'Script Use DNR' ) {
                        suiteletSublist.addField( 'custpage_scriptusednr' + scriptUseDNRIndex, 'text', colLabel ).setDisplayType( 'hidden' );
                        scriptUseDNRIndex++;
                    }
                    else {
                        suiteletSublist.addField( 'custpage_' + colName, 'text', colLabel );
                    }

                }
                var pageId = request.getParameter( 'pageNo' );
                nlapiLogExecution( 'DEBUG', 'Value of Custom Field custbody1: ', pageId );
                var searchResultsDataObj = getAllSearchResults( ssType, resultFilters, columns );
                //   nlapiLogExecution( 'DEBUG', 'searchResults', searchResults.length );
                var totalRows = searchResultsDataObj.length;
                if ( searchResultsDataObj != null && searchResultsDataObj != '' && searchResultsDataObj.length > 0 ) {
                    // var retrieveSearch = getResultsValue(ssType,resultFilters,columns, pageSize);
                    nlapiLogExecution( 'DEBUG', 'searchResultsDataObj.length', searchResultsDataObj.length );
                    var pagenum = Math.ceil( totalRows / pageSize );
                    // nlapiLogExecution('pageCount',pageCount);
                    var dataDropObj = {}
                    for ( var j = 0; j < pagenum; j++ ) {
                        var strtpage = ( j * pageSize ) + 1;
                        var endpage = ( j * pageSize ) + ( pageSize - 1 ) + 1;
                        if ( endpage >= totalRows ) {
                            endpage = totalRows - 1;
                        }
                        if ( j == ( pagenum - 1 ) )
                            endpage = endpage + 1;
                        dataDropObj[ j ] = ( parseInt( strtpage ) ) + ' - ' + ( parseInt( endpage ) );
                    }
                    // nlapiLogExecution( 'DEBUG', 'dropdownObj', JSON.stringify( dataDropObj ) );
                    var selectOptions = form.addField( 'custpage_pageid', 'select', 'Page Index', null, 'custpage_customtab' );

                    selectOptions.setLayoutType( 'endrow' );
                    //  var text1 = form.addField( 'custpage_page_text', 'text', 'Page text', null, 'custpage_customtab' );
                    for ( var page in dataDropObj ) {
                        if ( page == pageId )
                            selectOptions.addSelectOption( page, dataDropObj[ page ], true );
                        else
                            selectOptions.addSelectOption( page, dataDropObj[ page ] );
                    }
                    var startPage = 0;
                    var endPage = 14;
                    if ( pageId != null && pageId != '' ) {
                        var pages = dataDropObj[ pageId ]
                        if ( pages ) {
                            var pageNum = pages.split( '-' );
                            startPage = parseInt( pageNum[ 0 ] )
                            startPage = parseInt( startPage ) - 1;
                            endPage = parseInt( pageNum[ 1 ] )
                            endPage = parseInt( endPage ) - 1;
                        }

                    }
                    endPage = parseFloat( endPage ) + 1
                    //  nlapiLogExecution( 'DEBUG', 'startPage', startPage + '  : ' + endPage );
                    var searchResults = searchResultsDataObj.slice( startPage, endPage );

                    for ( var s = 0; s < searchResults.length; s++ ) {
                        var searchresult = searchResults[ s ];
                        var internalid = searchresult.getId();
                        var colArr = [];
                        var colIndex = 1;
                        var scriptUseDNRIndex = 1;
                        for ( var c = 0; c < columns.length; c++ ) {
                            var colObj = columns[ c ];
                            var columnName = colObj.getName();
                            var colLabel = colObj.getLabel();
                            var ssResultValue = searchresult.getValue( colObj );
                            if ( colObj.getType() == 'select' ) {
                                ssResultValue = searchresult.getText( colObj )
                            }
                            if ( colArr.indexOf( columnName ) == -1 ) {
                                colArr.push( columnName )
                            }
                            else {
                                columnName = columnName + colIndex;
                                colIndex++;
                            }
                            suiteletSublist.setLineItemValue( 'custpage_internalid', s + 1, internalid );
                            if ( colLabel == 'Script Use DNR' ) {
                                suiteletSublist.setLineItemValue( 'custpage_scriptusednr' + scriptUseDNRIndex, s + 1, ssResultValue );
                                scriptUseDNRIndex++;
                            } else {
                                if ( columnName == 'custrecord_ci_record' ) {
                                    var recLink = nlapiResolveURL( 'RECORD', CUSTOM_RECORD_CI_RECORD, internalid, 'VIEW' );
                                    suiteletSublist.setLineItemValue( 'custpage_' + columnName, s + 1, '<a href="' + recLink + '" >' + ssResultValue + '</a>' );
                                }
                                else {
                                    suiteletSublist.setLineItemValue( 'custpage_' + columnName, s + 1, ssResultValue );
                                }
                            }
                        }
                    }
                }
            }
            var url = nlapiResolveURL( 'SUITELET', SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD, DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD );
            form.addButton( BTN_DOWNLOAD_PDF, 'Download PDFs', 'var action = \'download\';process(action);' );
            form.addButton( BTN_SEND_PDF, 'Send PDFs', 'var action = \'email\';process(action);' );
            form.addButton( BTN_APPLY_FILTER, 'Apply Filters', 'applyFilters()' );


            response.writePage( form );
        } catch ( e ) {
            if ( e instanceof nlobjError )
                nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
            else
                nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
        }
    }

}

function getAllSearchResults ( record_type, filters, columns ) {
    var search = nlapiCreateSearch( record_type, filters, columns );
    search.setIsPublic( true );

    var searchRan = search.runSearch()
        , bolStop = false
        , intMaxReg = 1000
        , intMinReg = 0
        , result = [];

    while ( !bolStop && nlapiGetContext().getRemainingUsage() > 10 ) {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults( intMinReg, intMaxReg );

        result = searchUnion( result, extras );
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if ( extras.length < 1000 ) {
            bolStop = true;
        }
    }

    return result;
}

function searchUnion ( target, array ) {
    return target.concat( array ); // TODO: use _.union
}

function getObjectlength ( myobj ) {
    var count = 0;
    for ( var k in myobj ) {
        if ( myobj.hasOwnProperty( k ) )
            ++count;
    }
    return count;
}

