/**
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 */

/**
 * Script Name: Appf - Update Segment Header MR <customscript_appf_mr_update_seg_header>
 * 
 * @file        This Map/Reduce will populate header-level LOB and custom segment fields
 *              of Invoice and Credit Memo transactions. This will run on a daily basis.
 * @company     Appficiency Inc.
 * 
 * @author      Krizzia Jane Rivera <krivera@appficiencyinc.com>
 * @date        May 13, 2024
 * @version     1.0     krivera     Initial
 */
 define(['N/record', 'N/search', './utils/appf_CommonUtils.js'], function(record, search, utils) {

    // Global variables
    const SCRIPT_FILE_NAME = 'Appf - Update Segment Header MR.js';
    const SPARAM_SS = 'custscript_appf_mr_update_seg_header_ss';
    const SPARAM_MAP = 'custscript_appf_mr_update_seg_header_map';

    let objEvents = {};
    objEvents.config = {
        retryCount: 3,
        exitOnError: false
    }

    objEvents.getInputData = () => {
        log.debug(SCRIPT_FILE_NAME, 'getInputData');
        try {
            let srchId = utils.getScriptParamValue(SPARAM_SS);
            return search.load({
                id: srchId
            })
        } catch (e) {
            log.error(SCRIPT_FILE_NAME, 'Error in getInputData: ' + e);
        }
    }

    objEvents.map = (context) => {
        log.audit(SCRIPT_FILE_NAME, 'Remaining Usage: START map > ' + utils.getUsage());
        try {
            let result = JSON.parse(context.value);
            log.debug(SCRIPT_FILE_NAME, 'map context ' + JSON.stringify(result));

            let recObj = record.load({
                id: result.id,
                type: result.recordType
            });

            let mappings = utils.getScriptParamValue(SPARAM_MAP) ? (utils.getScriptParamValue(SPARAM_MAP)).replace(' ', '').split(',') : [];

            mappings.forEach( mapping => {
                let map = mapping.split('|');
                let fromField = map[0];
                let toField = map[1];
                
                if (!utils.isEmpty(fromField) && !utils.isEmpty(toField)) {
                    let value = result.values[fromField].value || result.values[fromField];
                    recObj.setValue({
                        fieldId: toField,
                        value: value
                    });

                    log.debug(SCRIPT_FILE_NAME, 'Set Value ' + JSON.stringify({
                        fromField: fromField,
                        toField: toField,
                        value: value
                    }));
                }
            });

            try {
                let recId = recObj.save({
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                });
                log.audit(SCRIPT_FILE_NAME, 'Record successfully updated: type = ' + result.recordType + ', id = ' + recId);
            } catch (e) {
                log.error(SCRIPT_FILE_NAME, 'Error updating: type = ' + result.recordType + ', id = ' + result.id);
            }
        } catch (e) {
            log.error(SCRIPT_FILE_NAME, 'Error in map. ERROR: '+ e);
        }
        log.audit(SCRIPT_FILE_NAME, 'Remaining Usage: END map > ' + utils.getUsage());
    }

    return objEvents;
});
