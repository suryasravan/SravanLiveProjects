/*
*Script Name: Appf-Update Client Payment Application SC #1
*Script Type: Scheduled
*Description: 
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       06 May 2020     Manikanta		
*/

var PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING=1;
var PAYMENT_APPLICATION_SUITELET_STATUS_PROCESSED=2;
var PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING=3;

var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS=2;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY=4;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS=5;

var FLD_CUSTOMER_PAYMENT_STATUS_IN_INVOICE='custbody_appf_cst_pmt_status';

var SPARAM_CLIENT_PAYMENT_APPLICATION_SEARCH='custscript_client_payment_application_search';
var SPARAM_RANDOM_TEXT='custscript_random_text';
var SPARAM_SELECTED_INVOICE_LIST='custscript_selected_invoice_list';
var SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID='custscript_payment_application_log_id';
var SPARAM_PAYMENT_APPLICATION_FILE_ID='custscript_payment_under_process_file_id';
var SPARAM_PAYMENT_APPLICATION_FILE_ID_CM = 'custscript_pay_under_process_file_id_cm';
var SPARAM_PAYMENT_APPLICATION_FILE_ID_1='custscript_payment_under_process_file_1';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID='custscript_payment_processed_file_id';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM = 'custscript_payment_processed_cm_file';
var SPARAM_PAYMENT_NEED_TO_UPDATE='custscript_payment_need_to_process';
var SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS='custscript_total_invoice_to_process';
var SPARAM_INVOICE_DETAIL_OBJ_FORM='custscript_invoice_detail_obj';
var SPARAM_CREDIT_DETAIL_OBJ_FORM='custscript_credit_detail_obj';
var SPARAM_TRANS_UNDER_PROCESSING = 'custscript_appf_trans_to_under_process';

var SPARAM_PAYMENT_APPLICATION_INV_FILE = 'custscript_pay_appl_inv_file';
var SPARAM_PAYMENT_APPLICATION_CM_FILE = 'custscript_pay_appl_cm_file';
var SPARAM_DATA_FOR_PAYMENT='custscript_data_for_payment';
var SPARAM_PROCESSING_INDEX = 'custscript_appf_processing_index';

var SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION='customscript_update_client_paymt_applns';

var CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG='customrecord_appf_cust_pmt_app_log';
var FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_tot_linked_trans_to_proc';
var FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG = 'custrecord_appf_cst_pmt_error_log';
var FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING = 'custrecord_appf_trans_to_under_process';
var FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING = 'custrecord_appf_trans_under_processed';
var FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING = 'custrecord_appf_trans_failed_under_proce';
var FLD_TOTAL_TRANSACTIONS_PENDING_UNDER_PROCESSING = 'custrecord_appf_trans_under_process_pend';
var FLD_TOTAL_UNDER_PROCESSING_PERCENT = 'custrecord_appf_trans_under_process_perc';
var FLD_TOTAL_UNDER_PROCESSING_STATUS = 'custrecord_appf_trans_under_process_stat';

function underProcessInvSS(type){
	var context=nlapiGetContext();
	
	var index=context.getSetting('SCRIPT',SPARAM_PROCESSING_INDEX);
	if(index == null || index == '')
		index = 0;
	nlapiLogExecution('debug', 'index', index);
	var selectedInvoicesIdsWithPayment=context.getSetting('SCRIPT',SPARAM_SELECTED_INVOICE_LIST+'_1');
	var totalTransToUnderProcessing=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_FILE_ID_1);
		var totalSelected=context.getSetting('SCRIPT',SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS+'_1');
		var paymentApplicationLogID=context.getSetting('SCRIPT',SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID+'_1');
		nlapiLogExecution('debug', 'paymentApplicationLogID', paymentApplicationLogID);
		var ssSuccessDataFileID=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID+'_1');
		var ssSuccessCreditDataFileID=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM+'_1');
		var invoicesforCRCreationID=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_INV_FILE+'_1');
		var paymentId=context.getSetting('SCRIPT',SPARAM_PAYMENT_NEED_TO_UPDATE+'_1');
		var dataForPayment=context.getSetting('SCRIPT',SPARAM_DATA_FOR_PAYMENT+'_1');
		
		var randomText=context.getSetting('SCRIPT',SPARAM_RANDOM_TEXT+'_1');
		var mainObj=context.getSetting('SCRIPT',SPARAM_INVOICE_DETAIL_OBJ_FORM+'_1');
		var creditObj = context.getSetting('SCRIPT',SPARAM_CREDIT_DETAIL_OBJ_FORM+'_1');
		var transUnderProcessing = context.getSetting('SCRIPT',SPARAM_TRANS_UNDER_PROCESSING);
		
		var totLinkedTransactionsToProcess = 0;
		var selectedInvoiceObj=JSON.parse(mainObj);
		
		var totalUpdatedToProcessing = true;
		var errorLog = '';
		var existingLinkedTransToProcessVal = 0;
		var logRecFields1 = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG, FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS]);
		if(logRecFields1 != null && logRecFields1 != ''){
			errorLog = logRecFields1[FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG];
			existingLinkedTransToProcessVal = logRecFields1[FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS];
			if(existingLinkedTransToProcessVal == null || existingLinkedTransToProcessVal == '')
				existingLinkedTransToProcessVal = 0;
			if(errorLog != null && errorLog != '')
				errorLog = errorLog+'\n';
			else
				errorLog = '';
		}
		if(Number(existingLinkedTransToProcessVal)==0 &&  creditObj != null && creditObj != '' && creditObj != '{}')
		{
			var selectedCreditObj = JSON.parse(creditObj);
			for(var cmprop in selectedCreditObj)
			{
				try{
					var creditAmount=selectedCreditObj[cmprop].payment;
					//var creditmemorec=nlapiLoadRecord('creditmemo',cmprop);
					
					//var applyCountCM=creditmemorec.getLineItemCount('apply');
					if(parseFloat(creditAmount) == 0){
							totLinkedTransactionsToProcess++;
						}
						else{
					for(var invprop in selectedInvoiceObj)
					{
						var invAmount=selectedInvoiceObj[invprop].payment;
						var invLineTaxAmt=selectedInvoiceObj[invprop].invLineTaxAmt;
						
						if(parseFloat(creditAmount) < parseFloat(invAmount) && parseFloat(creditAmount) > 0)
						{
							//for(cm=1;cm<=applyCountCM;cm++)
							//{
								//var invoiceIdOnCM=creditmemorec.getLineItemValue('apply','doc',cm);
								//if(parseInt(invprop) == parseInt(invoiceIdOnCM))
								//{
									totLinkedTransactionsToProcess++;
									var remainingInvAmount=parseFloat(invAmount)- parseFloat(creditAmount);
									//remainingInvAmount=Math.round(remainingInvAmount*100)/100;
									selectedInvoiceObj[invprop].payment=remainingInvAmount;
									creditAmount=0;
								//}
							//}
						}
						else if(parseFloat(creditAmount) >= parseFloat(invAmount) && parseFloat(invAmount) > 0)
						{
							//for(cm=1;cm<=applyCountCM;cm++)
							//{
								//var invoiceIdOnCM=creditmemorec.getLineItemValue('apply','doc',cm);
								//if(parseInt(invprop) == parseInt(invoiceIdOnCM))
								//{
									totLinkedTransactionsToProcess++;
									creditAmount=parseFloat(creditAmount)- parseFloat(invAmount);
									//creditAmount=Math.round(creditAmount*100)/100;
									selectedInvoiceObj[invprop].payment=0;
								//}
							//}
						}
						
						
					
					}
						}
				}catch(e){
					totalUpdatedToProcessing = false;
					if ( e instanceof nlobjError ){
						nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
						errorLog += 'System error :\n'+e.getDetails();
					}else{
						nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
						errorLog += 'Unexpected error :\n'+e.toString();
					}
					break;
				}
			}
		}
		nlapiLogExecution('debug','totLinkedTransactionsToProcess',totLinkedTransactionsToProcess);
		if(totalUpdatedToProcessing && invoicesforCRCreationID != null && invoicesforCRCreationID != '' && Number(existingLinkedTransToProcessVal)==0){
			var invoicesAppliedFileObj=nlapiLoadFile(invoicesforCRCreationID);
				var invoicesAppliedFileData=invoicesAppliedFileObj.getValue();
				invoicesAppliedFileData=invoicesAppliedFileData.split('\n');
				invoicesAppliedFileData=invoicesAppliedFileData.slice(0,-1);	
				nlapiLogExecution('debug','invoicesAppliedFileData Length',invoicesAppliedFileData.length);
				for(var i=1;i<invoicesAppliedFileData.length;i++)
				{
					totLinkedTransactionsToProcess++;
				}
		}
		if(totalUpdatedToProcessing && paymentApplicationLogID != null && paymentApplicationLogID != '' && Number(existingLinkedTransToProcessVal)==0)
			nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS, Number(totLinkedTransactionsToProcess));
		
			var totalTransProcessed = 0;
			var totalTransFailed = 0;
			var totalTransPending = 0;
			var transUnderProcessPercent = 0;
			var errorLog = '';
		
			if(totalUpdatedToProcessing && transUnderProcessing != null && transUnderProcessing != ''){
				
					var totalLines = transUnderProcessing.split(',');
					for(var t=0; t<=totalLines.length-1; t++){
						
							var lineData = totalLines[t];
							if(lineData != null && lineData != ''){
								var recId = lineData.split('__')[0];
							}
					}
					nlapiLogExecution('debug', 'totalLines', totalLines.length);
					//var totalTransToUnderProcess = totalLines.length-2;
					//nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING, Number(totalTransToUnderProcess));
					
					
					for(var t=index; t<=totalLines.length-1; t++){
						try{
							var lineData = totalLines[t];
							if(lineData != null && lineData != ''){
								var recId = lineData.split('__')[0];
								var recType = lineData.split('__')[1];
								if(recType == '1')
									recType = 'invoice';
								else
									recType = 'creditmemo';
								
								nlapiSubmitField(recType, recId, FLD_CUSTOMER_PAYMENT_STATUS_IN_INVOICE, PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING);
								totalTransProcessed=parseInt(totalTransProcessed)+1;
							}
						}catch(e){
							totalTransFailed=parseInt(totalTransFailed)+1;
							totalUpdatedToProcessing = false;
							if ( e instanceof nlobjError ){
								nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
								errorLog+='System error :\n'+e.getDetails();
							}else{
								nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
								errorLog+='Unexpected error :\n'+e.toString();
							}
						}
						
						if(context.getRemainingUsage() <= 1000 && (parseInt(t)+1)<(totalLines.length-1)){
							totalUpdatedToProcessing = false;
							params1 = {};
							params1[SPARAM_RANDOM_TEXT+'_1'] = randomText;
							params1[SPARAM_INVOICE_DETAIL_OBJ_FORM+'_1'] =mainObj;
							params1[SPARAM_CREDIT_DETAIL_OBJ_FORM+'_1'] =creditObj;
							params1[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS+'_1']=totalSelected;
							params1[SPARAM_SELECTED_INVOICE_LIST+'_1'] =selectedInvoicesIdsWithPayment;
							params1[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID+'_1']=paymentApplicationLogID;
							params1[SPARAM_PAYMENT_APPLICATION_FILE_ID_1]=totalTransToUnderProcessing; 
							params1[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID+'_1']=ssSuccessDataFileID; 
							params1[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM+'_1']=ssSuccessCreditDataFileID; 
							params1[SPARAM_PAYMENT_APPLICATION_INV_FILE+'_1']=invoicesforCRCreationID;
							params1[SPARAM_TRANS_UNDER_PROCESSING]=transUnderProcessing+'';
							
							params1[SPARAM_PAYMENT_NEED_TO_UPDATE+'_1'] = paymentId;
							params1[SPARAM_PROCESSING_INDEX] = parseInt(t)+1;
							if(dataForPayment)
							params1[SPARAM_DATA_FOR_PAYMENT+'_1']=dataForPayment;	
							nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params1);
							break;
						}
					}
					var logtotalTransProcessed = 0;
					var logtotalTransFailed = 0;
					var logtotalTransToProcess = 0;
					var logRecFields = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG, FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING]);
					if(logRecFields != null && logRecFields != ''){
						errorLog = logRecFields[FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG];
						logtotalTransToProcess = logRecFields[FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING];
						logtotalTransProcessed = logRecFields[FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING];
						logtotalTransFailed = logRecFields[FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING];
						if(logtotalTransProcessed == null || logtotalTransProcessed == '')
							logtotalTransProcessed = 0;
						else
							logtotalTransProcessed = parseInt(logtotalTransProcessed);
						if(logtotalTransFailed == null || logtotalTransFailed == '')
							logtotalTransFailed = 0;
						else
							logtotalTransFailed = parseInt(logtotalTransFailed);
						if(errorLog != null && errorLog != '')
							errorLog = errorLog+'\n';
						else
							errorLog = '';
						
					}
					
					totalTransProcessed = parseInt(totalTransProcessed)+parseInt(logtotalTransProcessed);
					totalTransFailed = parseInt(totalTransFailed)+parseInt(logtotalTransFailed);
					
					if(totalTransProcessed == null || totalTransProcessed == '')
						totalTransProcessed = 0;
					if(totalTransFailed == null || totalTransFailed == '')
						totalTransFailed = 0;
					totalTransPending = Number(logtotalTransToProcess)-(Number(totalTransProcessed)+Number(totalTransFailed));
					if(totalTransPending == null || totalTransPending == '')
						totalTransPending = 0;
					transUnderProcessPercent = ((Number(totalTransProcessed)+Number(totalTransFailed))/Number(logtotalTransToProcess))*100;
					if(transUnderProcessPercent == null || transUnderProcessPercent == '')
						transUnderProcessPercent = 0;
					var fields = [FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING, FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG, FLD_TOTAL_UNDER_PROCESSING_PERCENT, FLD_TOTAL_TRANSACTIONS_PENDING_UNDER_PROCESSING];
					var values = [Number(totalTransProcessed), Number(totalTransFailed), errorLog, Number(transUnderProcessPercent), Number(totalTransPending)];
					try{
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, fields, values);
					}catch(e1){
						try{
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, fields, values);
						}catch(e2){
							try{
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, fields, values);
							}catch(e3){
								try{
									nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, fields, values);
								}catch(e4){
									if ( e4 instanceof nlobjError ){
										nlapiLogExecution( 'DEBUG', 'system error', e4.getCode() + '\n' + e4.getDetails() );
										errorLog+='System error :\n'+e4.getDetails();
									}else{
										nlapiLogExecution( 'DEBUG', 'unexpected error', e4.toString() );
									}
								}
							}
						}
					}
					
					var logRecFields = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG, FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING]);
					if(logRecFields != null && logRecFields != ''){
						var logtotalTransToProcess = logRecFields[FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING];
						var errorLog = logRecFields[FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG];
						var logtotalTransProcessed = logRecFields[FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING];
						var logtotalTransFailed = logRecFields[FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING];
						if(logtotalTransProcessed == null || logtotalTransProcessed == '')
							logtotalTransProcessed = 0;
						else
							logtotalTransProcessed = parseInt(logtotalTransProcessed);
						if(logtotalTransFailed == null || logtotalTransFailed == '')
							logtotalTransFailed = 0;
						else
							logtotalTransFailed = parseInt(logtotalTransFailed);
						if(errorLog != null && errorLog != '')
							errorLog = errorLog+'\n';
						else
							errorLog = '';
						if(Number(logtotalTransToProcess) == (Number(logtotalTransProcessed)+Number(logtotalTransFailed))){
							totalUpdatedToProcessing = true;
							var logStatus = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY;
							if(Number(logtotalTransFailed) > 0)
								logStatus = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS;
							try{
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_TOTAL_UNDER_PROCESSING_STATUS, FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [logStatus, errorLog]);
							}catch(a1){
								try{
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_TOTAL_UNDER_PROCESSING_STATUS, FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [logStatus, errorLog]);
								}catch(a2){
									nlapiLogExecution('debug', 'Error @ end of SC #1 Deployment', a2.toString());
								}
							}
						}else{
							totalUpdatedToProcessing = false;
						}
						
					}
					
					
					
			}
		if(!totalUpdatedToProcessing && totalTransToUnderProcessing != null && totalTransToUnderProcessing != ''){
			var allTransactionsList = totalTransToUnderProcessing.split(',');
			
			var tranFilters = [];
			tranFilters.push(new nlobjSearchFilter('type', null, 'anyof', ['CustInvc', 'CustCred']));
			tranFilters.push(new nlobjSearchFilter('mainline', null, 'is', 'T'));
			tranFilters.push(new nlobjSearchFilter(FLD_CUSTOMER_PAYMENT_STATUS_IN_INVOICE, null, 'anyof', [PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING]));
			tranFilters.push(new nlobjSearchFilter('internalid', null, 'anyof', allTransactionsList));
			
			var tranColumns = [];
			tranColumns[0] = new nlobjSearchColumn('internalid', null, 'count');
			
			var tranSS = nlapiSearchRecord('transaction', null, tranFilters, tranColumns);
			
			var tranSSLen = 0;
			
			if (tranSS)
			{
				
				tranSSLen = tranSS[0].getValue('internalid', null, 'count');
			}
			



			
			var logRecFields = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG, FLD_TOTAL_TRANSACTIONS_IN_PROGRESS_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING, FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING]);
					if(logRecFields != null && logRecFields != ''){
						var logtotalTransToProcess = logRecFields[FLD_TOTAL_TRANSACTIONS_TO_UNDER_PROCESSING];
						var errorLog = logRecFields[FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG];
						var logtotalTransFailed = logRecFields[FLD_TOTAL_TRANSACTIONS_FAILED_UNDER_PROCESSING];
						
							var logtotalTransProcessed = parseInt(tranSSLen);
						if(logtotalTransFailed == null || logtotalTransFailed == '')
							logtotalTransFailed = 0;
						else
							logtotalTransFailed = parseInt(logtotalTransFailed);
						if(errorLog != null && errorLog != '')
							errorLog = errorLog+'\n';
						else
							errorLog = '';
						if(Number(logtotalTransToProcess) == (Number(logtotalTransProcessed)+Number(logtotalTransFailed))){
							totalUpdatedToProcessing = true;
							var logStatus = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY;
							if(Number(logtotalTransFailed) > 0)
								logStatus = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS;
							try{
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_TOTAL_UNDER_PROCESSING_STATUS, FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [logStatus, errorLog]);
							}catch(a1){
								try{
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, paymentApplicationLogID, [FLD_TOTAL_UNDER_PROCESSING_STATUS, FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [logStatus, errorLog]);
								}catch(a2){
									nlapiLogExecution('debug', 'Error @ end of SC #1 Deployment', a2.toString());
								}
							}
						}else{
							totalUpdatedToProcessing = false;
						}
						
					}
		}
		
		if(totalUpdatedToProcessing){
			var params = {};
			params[SPARAM_RANDOM_TEXT] = randomText;
      		params[SPARAM_INVOICE_DETAIL_OBJ_FORM] =mainObj;
			params[SPARAM_CREDIT_DETAIL_OBJ_FORM] =creditObj;
			params[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalSelected;
			params[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesIdsWithPayment;
			params[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=paymentApplicationLogID;
			params[SPARAM_PAYMENT_APPLICATION_FILE_ID]=totalTransToUnderProcessing; //this file should be used in SC #1, backend purpose
			params[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=ssSuccessDataFileID; //needed for direct update, UI display
			params[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=ssSuccessCreditDataFileID; //needed for direct update, UI display
			params[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesforCRCreationID; //other updates related to amounts, backend purpose
			
			params[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentId;
			
			if(dataForPayment)
			params[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
			nlapiScheduleScript(SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION, null, params);
		}
		
}