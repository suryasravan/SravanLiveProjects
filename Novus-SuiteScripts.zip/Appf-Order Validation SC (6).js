/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : This script handles all the validations required on a 'Pending Approval' sales order from saved search results and marks as Success, sets the contract and approves the order if all validations are successful
4/24/2020 v2 Sravan Added Additional validation of PWP check on line items
5/13/2020 v3 Sravan Added logic to set PO Vendor and PO Rate to chck if this resolves Item Options Error in integration

* Company     : Appficiency Inc.
*/
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';

var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_CONTRACT_MEDIA_TYPE = 'custrecord_appf_contract_mediatype';
var FLD_CONTRACT_END_DATE = 'custrecord_appf_contract_end_date';


var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_SO_ORDER_VALIDATION_STATUS = 'custbody_appf_orderval_status';

var FLD_VENDOR_LINE = 'custcol_appf_po_vendor_name';
var FLD_BILLING_SCHEDULE_LINE = 'billingschedule';

var SPARAM_MEDIA_SALES_ORDERS_SS = 'custscript_appf_media_type_so_ss';
var SPARAM_SS_FILE_ID = 'custscript_appf_ss_file_id';
var SPARAM_INDEX = 'custscript_appf_line_index';
var FOLDER_ID = '-15';

var FLD_CONTRACT_DEPT = 'custrecord_appf_contract_department';
var FLD_CONTRACT_LOB = 'custrecord_appf_contract_lineofbusiness';
var FLD_CONTRACT_POP_REQUIRED = 'custrecord_appf_contract_pop_required';


var FLD_COL_POP_REQUIRED = 'custcol_appf_print_poprequired';
var FLD_COL_CORP_OWNER = 'custcol_appf_corporateowner';
var FLD_COL_PWP = 'custcol_appf_pwp_custom_record';

var BUYING_SYSTEM_PRINT = '1';

function setContractSOScheduled(type){

	var context = nlapiGetContext();
	var mediaSOSS = 1146;
	var existingDataFile = null;
	var index = '';
	if(index == null || index == '')
		index = 1;
  nlapiLogExecution('debug', 'file index', index);
	var fileId =null;
	if(mediaSOSS != null && mediaSOSS != ''){		
		var mediaSOSSObj = nlapiLoadSearch(null, mediaSOSS);
		var filters = mediaSOSSObj.getFilters();
		var columns = mediaSOSSObj.getColumns();
		var ssType = mediaSOSSObj.getSearchType();
		var mediaSOSSResults = getAllSearchResults(ssType, filters, columns);
		if (existingDataFile == null || existingDataFile == '')
		{
		if(mediaSOSSResults != null && mediaSOSSResults != ''){
			var mediaSOSSResultsData = 'Record ID, Client ID, Client Name, Date, Buying System, Buying System Name\n';
			for(var s=0; s<mediaSOSSResults.length; s++){
				
				var col = mediaSOSSResults[s];
				var recType = col.getRecordType();
				var recId = col.getId();
				var client = col.getValue('entity');
				var clientName = col.getText('entity');
				if(clientName!=null && clientName!='')
				clientName=clientName.replace(/,/g, ';');
				var date = col.getValue('trandate');
				var buyingSys = col.getValue(FLD_SO_BUYING_SYSTEM);
				var buyingSysName = col.getText(FLD_SO_BUYING_SYSTEM);
				if(buyingSysName!=null && buyingSysName!='')
				buyingSysName=buyingSysName.replace(/,/g, ';');
				mediaSOSSResultsData += recId +','+client+','+clientName+','+date+','+buyingSys+','+buyingSysName+'\n';
			}
			var ssResultsFile = nlapiCreateFile('SS Results.csv', 'CSV', mediaSOSSResultsData);
			ssResultsFile.setFolder(FOLDER_ID);
			fileId = nlapiSubmitFile(ssResultsFile);
			nlapiLogExecution('debug', 'fileId', fileId);
		}
		}
		else
		{
			fileId = existingDataFile;
		}
			
			if(fileId != null && fileId != ''){
				var fileObj = nlapiLoadFile(fileId);
				var fileData = fileObj.getValue().split('\n');
				nlapiLogExecution('debug', 'fileData', fileData.length);
				var allDataProcessed = true;
				if(fileData != null && fileData != ''){
														

				for(var f=index; f<(fileData.length-1); f++){
							var validationStatus = '';

				var line = fileData[f].split(',');
				var recId = line[0];
				var client = line[1];
				var clientName = line[2];
				var date = line[3];
				var buyingSys = line[4];
				var buyingSysName = line[5];
				
				var activeContracts = {};
				var salesOrderRec = nlapiLoadRecord('salesorder', recId);
				try{
				var itemCount=salesOrderRec.getLineItemCount('item');
		for(var k=1;k<=itemCount;k++)
        {
		
                      var existingPOVendor = salesOrderRec.getLineItemValue('item', 'povendor', k);
            var vendorName = salesOrderRec.getLineItemValue('item', FLD_COL_VENDOR_NAME, k);
                      var existingcreatepo = salesOrderRec.getLineItemValue('item', 'createpo', k);

            if (vendorName == null)
            vendorName = '';
		   // nlapiLogExecution('debug', 'po vendor', vendorName);
		  if (existingPOVendor != vendorName && vendorName != null && vendorName != '')
            {
            salesOrderRec.selectLineItem('item', k);
            salesOrderRec.setCurrentLineItemValue('item', 'povendor', vendorName);
                          salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);

              if (existingcreatepo == null || existingcreatepo == '')
               salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');                  
            salesOrderRec.commitLineItem('item');	
            }
								   
	    }
		
		nlapiSubmitRecord(salesOrderRec, true, true);
				}
				catch(ep)
				{
					
					nlapiLogExecution('debug', 'Failed to set PO Vendor', ep);
				}
				var salesOrderRec = nlapiLoadRecord('salesorder', recId);
				try{
					var contractId=salesOrderRec.getFieldValue(FLD_SO_CLIENT_CONTRACT)
					if(contractId==null || contractId=='')
					{
					var contractFils = [];
					contractFils.push(new nlobjSearchFilter(FLD_CONTRACT_CLIENT, null, 'anyof', client));
					contractFils.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
					
					var contractCols = [];
					contractCols.push(new nlobjSearchColumn(FLD_CONTRACT_MEDIA_TYPE));
					contractCols.push(new nlobjSearchColumn(FLD_CONTRACT_END_DATE));
					contractCols.push(new nlobjSearchColumn('name'));
					
					var contractSearchResults = getAllSearchResults(CUSTOM_RECORD_CONTRACT, contractFils, contractCols);
					if(contractSearchResults != null && contractSearchResults != ''){

						for(var a=0; a<contractSearchResults.length; a++){
							var result = contractSearchResults[a];
							var contractId = result.getId();
							var contractName = result.getValue('name');
																					var contractMediaTypeID = result.getValue(FLD_CONTRACT_MEDIA_TYPE);

							var contractMediaType = result.getText(FLD_CONTRACT_MEDIA_TYPE);
							var contractEndDate = result.getValue(FLD_CONTRACT_END_DATE);
							if(contractMediaTypeID != null && contractMediaTypeID != '')
							{
								
								if (!activeContracts.hasOwnProperty(contractMediaType)){
								activeContracts[contractMediaType] = [];
								var obj = {};
								obj.contractId = contractId;
								obj.contractName = contractName;
								obj.contractEndDate = contractEndDate;
								activeContracts[contractMediaType].push(obj);
							}
							else{
								var obj = {};
								obj.contractId = contractId;
								obj.contractName = contractName;
								obj.contractEndDate = contractEndDate;
								activeContracts[contractMediaType].push(obj);
							}
							}
						}
						
						nlapiLogExecution('debug', 'activeContracts json', JSON.stringify(activeContracts));
						if(activeContracts.hasOwnProperty(buyingSysName)){
							var buyingSysArr = activeContracts[buyingSysName];
							var endDateMissing = false;
							var endDatePassed = false;
							var contractName = '';
							var allContracts = [];
							for(var b=0; b<buyingSysArr.length; b++){
								var obj = buyingSysArr[b];
								var endDate = obj.contractEndDate;
								if(endDate != null && endDate != ''){
									endDateMissing = false;
									if(nlapiStringToDate(date).getTime() < nlapiStringToDate(endDate).getTime()){
										endDatePassed = false;
										var contract = obj.contractId;
										if(allContracts.indexOf(contract) == -1){
											allContracts.push(contract);
										}
									}
									else{
										endDatePassed = true;
										contractName = obj.contractName;
									}
								}
								else{
									endDateMissing = true;
									contractName = obj.contractName;
								}
							}
							
							
							if(endDateMissing == true)
							{
								validationStatus = 'Failed. Contract '+contractName+' End Date missing.';
							}
							else if(endDatePassed == true)
							{
								validationStatus = 'Failed. Contract '+contractName+' has expired. Please create a new contract.';
							}
							else if(allContracts.length > 0) {
							if (allContracts.length > 1)
							{
							    validationStatus = 'Failed. Multiple active contracts found for '+clientName+' and '+buyingSysName+'.';
							}
	                        else
							{
								
									var contractId = allContracts[0];
									salesOrderRec.setFieldValue(FLD_SO_CLIENT_CONTRACT, contractId);
									
							}
							
							}
						}
						else{
							validationStatus='Failed. No Contract found for '+buyingSysName+'.';
						}
					}
					else{
						validationStatus='Failed. No Contract found for '+clientName+' and '+buyingSysName+'.' ;
					    }
					}
							
							var contract = contractId;
		var buyingSys = salesOrderRec.getFieldValue(FLD_SO_BUYING_SYSTEM);
		var isError = false;
		var errorMsg = '';
		
		if(contract != null && contract != ''){
			
			var contractRec = nlapiLoadRecord(CUSTOM_RECORD_CONTRACT, contract);
			var dept = contractRec.getFieldValue(FLD_CONTRACT_DEPT);
			var lob = contractRec.getFieldValue(FLD_CONTRACT_LOB);
			var popRequired = contractRec.getFieldValue(FLD_CONTRACT_POP_REQUIRED);
			var contractName = contractRec.getFieldValue('name');
			
			//if(dept != null && dept != '')
				//salesOrderRec.setFieldValue('department', dept);
			if(validationStatus != '')
				validationStatus = validationStatus+'\n';
			//if(lob != null && lob != '')
				//salesOrderRec.setFieldValue('class', lob);
			for(var i=1; i<=salesOrderRec.getLineItemCount('item'); i++){
				var vendorLine = salesOrderRec.getLineItemValue('item', FLD_VENDOR_LINE, i);
				
							var corporateOwner = salesOrderRec.getLineItemValue('item', FLD_COL_CORP_OWNER, i);
							
								var billingSchLine = salesOrderRec.getLineItemValue('item', FLD_BILLING_SCHEDULE_LINE, i);
                                var pwpOnLine = salesOrderRec.getLineItemValue('item', FLD_COL_PWP, i);
								nlapiLogExecution('debug', 'pwpOnLines json', pwpOnLine);
                                if (pwpOnLine == null || pwpOnLine == '')
                                validationStatus += 'Failed. PWP Record Link is missing on Line #'+i+'.\n';
								else if ((vendorLine == null || vendorLine == '') && (billingSchLine == null || billingSchLine == ''))
								validationStatus += 'Failed. Vendor Name, Billing Schedule are missing on Line #'+i+'.\n';
							    else if ((vendorLine != null && vendorLine != '') && (billingSchLine == null || billingSchLine == ''))
								validationStatus += 'Failed. Billing Schedule is missing on Line #'+i+'.\n';
								else if ((vendorLine == null || vendorLine == '') && (billingSchLine != null && billingSchLine != ''))
								validationStatus += 'Failed. Vendor Name is missing on Line #'+i+'.\n';
								//else if ((vendorLine == null || vendorLine == '') && (billingSchLine == null || billingSchLine == ''))
								//validationStatus += 'Failed. Vendor Name and Billing Schedule are missing on Line #'+i+'.\n';
								//else if ((vendorLine != null && vendorLine != '') && (billingSchLine == null || billingSchLine == ''))
								//validationStatus += 'Failed. Billing Schedule Owner are missing on Line #'+i+'.\n';
								//else if ((vendorLine == null || vendorLine == '') && (billingSchLine != null && billingSchLine != ''))
								//validationStatus += 'Failed. Vendor Name are missing on Line #'+i+'.\n';
								//else if ((vendorLine != null && vendorLine != '') && (billingSchLine != null && billingSchLine != ''))
								//validationStatus += 'Failed. Corporate Owner is missing on Line #'+i+'.\n';
							
							
				if(buyingSys == BUYING_SYSTEM_PRINT)
					salesOrderRec.setLineItemValue('item', FLD_COL_POP_REQUIRED, i, popRequired);
				
				    if(lob != null && lob != '')
					salesOrderRec.setLineItemValue('item', 'class', i, lob);
				//if(contractName != null && contractName != '')
					//salesOrderRec.setLineItemValue('item', FLD_COL_CORP_OWNER, i, contractName);
			}
		}
										
					
					
					
					if(validationStatus == null || validationStatus == ''){
					salesOrderRec.setFieldValue(FLD_SO_ORDER_VALIDATION_STATUS, 'Success');
					
		
		
					salesOrderRec.setFieldValue('orderstatus', 'B');
				}
else
{
					salesOrderRec.setFieldValue(FLD_SO_ORDER_VALIDATION_STATUS, validationStatus);

}	
		
		nlapiSubmitRecord(salesOrderRec, true, true);
				}catch(e){
                  var err_order_val = '';
					if ( e instanceof nlobjError )
                      {
						nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
                         err_order_val = e.getDetails();
                      }
					else
                      {
						nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
err_order_val = e.toString();
                      }
                  try{
                         nlapiSubmitField('salesorder', recId, FLD_SO_ORDER_VALIDATION_STATUS, err_order_val)
                  }
                  catch(ex)
                    {
                      						nlapiLogExecution( 'DEBUG', 'unexpected error', ex);

                    }

				}
				if(context.getRemainingUsage() <= 500 && (f+1) < (fileData.length-1)){
						allDataProcessed = false;
						var params = {};
						params[SPARAM_MEDIA_SALES_ORDERS_SS] = mediaSOSS;
						params[SPARAM_SS_FILE_ID] = fileId;
						params[SPARAM_INDEX] = (f+1);
						nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
						break;
					}
				}
			}
			if(allDataProcessed){
				nlapiDeleteFile(fileId);		
			}
			}
				
	}
}

function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
function searchUnion(target, array)
	{
		return target.concat(array); // TODO: use _.union
	}
	
	