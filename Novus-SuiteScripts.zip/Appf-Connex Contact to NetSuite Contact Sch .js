/**
*Script Name: Appf-Connex Contact to NetSuite Contact
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Connext Contact and pushes the Contact from those messages into netsuite and creates or updates as Contact records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_connex_contact_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecord_appf_contact_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_contact_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecord_appf_contant_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_contant_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_contact_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_response_status';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_connex_contact_resp_status';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_appf_contact_correlid';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS = 'custrecord_appf_queuemsg_property';
 var CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP = 'custrecord_appf_netsuite_cont_send_resp';
 // Integration Related
 var QUEUE_CONNEX_CLIENT_INBOUND = 'novusmedia_connex_contact_in';
 //novusmedia_connex_client_in
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_crm_response';
 var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
 
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee','phoneaddr'];
 var FLD_CONNEX_ID='custentity_appf_connexid';
 var FLD_LAST_UPDATE_DATE_TIME = 'custentity_appf_integr_lastupdatedate';

 // var NS_OB_RESPONSE_PROPERTY='Novus.Connex.Sync.NetSuite.Models.Response.ContactResponse'
 var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Response.NetSuite.ContactResponseMessage'
 var SPARAM_CONNEX_CONTACT='customscript_appf_connex_contact_2_ns_sc'

 var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

function createContactScheduled(type) 
  {	
		var context = nlapiGetContext();
              var messagesFound=true
              var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
    if(URL_BASE!=null && URL_BASE!='')
      {
    while (messagesFound == true) 
	{
      var usageRemaining = context.getRemainingUsage();
      var idForResponse = '';
		var connexIDResponseValue=''
		var d = new Date();
        var UTCDate= d.toISOString();
		var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
		var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
		var mainObj = responseData.getBody()+'';
            nlapiLogExecution('debug','mainObj content',mainObj);
		var CorrelationIdProp='NServiceBus.CorrelationId'
		var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

		var CorrelationId=responseData.getHeader(CorrelationIdProp)  
		var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
        var Status=''
		var Status1=''
		var scriptStatus=''
         var fileData=''
        if(mainObj==null || mainObj=='')
        {
			 messagesFound=false;
			 Status='FAILED'+'(Empty Message)'
			 scriptStatus='FAILED'
			 Status1='FAILED'+'(Empty Message)'
        }
        else
        {
		   try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
					{
						connexIDResponseValue=mainObj[FLD_CONNEX_ID];
						nlapiLogExecution('debug', 'connexIDResponseValue:', connexIDResponseValue);
					}
					Status='SUCCESS'
			   } 
			catch (e) 
			{
			   Status='FAILED'+'(invalid JSON)'
			   scriptStatus='FAILED'
				Status1='FAILED'+'(invalid JSON)'
			}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var main1={}
								
		if(responseData.getCode()!='200' && responseData.getCode()!='201')
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
		   var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS,'FAILED')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   nlapiSubmitRecord(integrationRecord,true,true)
		   }
		   
		}    
		else
        {
			var nsClientRecord='';
			var isNewRecord = true;  
          var internalId=''
          var isUpdateRecord=true;
          
		   var nsCreationMsg = '';
		   try
		   {
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsClientRecord=nlapiCreateRecord('contact')
               if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('contact', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                     idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('contact',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				
				var msdate=''
				var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }						 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                   else
                     {
                       isUpdateRecord=false;
                     }
                   }  
                                  }
                        }
					}
				 }
			}
			else
			{
			
				internalId=mainObj['id']
				nlapiLogExecution('debug', 'internalId',  internalId);
				if(internalId==null || internalId=='' || internalId=='null')
				{
				  nsClientRecord=nlapiCreateRecord('contact')
                   if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('contact', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                     idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('contact',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				
				var msdate=''
				var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                    else
                     {
                       isUpdateRecord=false;
                     }
                   }  
                                  }
                        }
					}
				 }
				}
				else
				{
                  idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('contact',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				
				var msdate=''
				var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                    else
                     {
                       isUpdateRecord=false;
                     }
                   }  
				}
			}
		   }
		   catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
		   var nsClientRecordID=null;
		  
			if(Status==null || Status=='' || Status=='SUCCESS')
		   {
				try{
					 if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {		   
					var hasAddressBook =false;
					var addressBookObj = {};
						   
					   //var nsClientRecord=nlapiCreateRecord('customer')
					for (var parentProp in mainObj)
					{
						 if (addressBookFields.indexOf(parentProp) != -1)
						 {
							 hasAddressBook =  true;
							 addressBookObj[parentProp] = mainObj[parentProp];
						 }
						// nlapiLogExecution('debug', ' parentProp',  parentProp);
			          //  var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						 
						
						  var parentProp2=nsClientRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!=''))
						 {
			                  //start
						      /*if(parentProp!='otherrelationships' && parentProp!='version' && parentProp!='id')
			                  nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])	*/ //updated 9/15/2020
							 
							 if(parentProp!='otherrelationships' && parentProp!='version' && parentProp!='id' && parentProp != 'custentity_appf_vendor_role' && parentProp != 'custentity_appf_client_role' && parentProp != 'custentity_appf_contact_company' && parentProp != 'custentity_appf_ms_company'){
								 nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])
							 }else if (parentProp == 'custentity_appf_vendor_role' || parentProp == 'custentity_appf_client_role' || parentProp == 'custentity_appf_contact_company' || parentProp == 'custentity_appf_ms_company'){
								 var invRecipients = mainObj[parentProp];
								 if (invRecipients != null && invRecipients != '')
								 {
									 invRecipients = invRecipients.split(',');
									 nsClientRecord.setFieldValues(parentProp,invRecipients)
								 }
							 }

			                  //end
						  
						 }
		            }					  
					if(hasAddressBook)
					{
						  if (isNewRecord)
						  {
							  nsClientRecord.selectNewLineItem('addressbook');
						  }						  
						  else
						  {
							   nsClientRecord.selectLineItem('addressbook', 1);
						  }
						  for (var addrprop in addressBookObj)
						  {
							  if(addrprop!='phoneaddr')
							  nsClientRecord.setCurrentLineItemValue('addressbook', addrprop, addressBookObj[addrprop]);
						    if(addrprop=='phoneaddr')
							  nsClientRecord.setCurrentLineItemValue('addressbook', 'phone', addressBookObj[addrprop]);
						  }
						  
						  nsClientRecord.commitLineItem('addressbook');
					}
		               nsClientRecordID = nlapiSubmitRecord(nsClientRecord,true,true);
					   }
					   else
					   {
						if(nsCreationMsg==null || nsCreationMsg=='')
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
					        scriptStatus='WARNING'
					   }
				}
				catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				}                       					   
				if (nsClientRecordID != null)
				{
					var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') 
						  isInActiveRecord=true
					}
					if(!isInActiveRecord)
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS,CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsClientRecordID, 'SUCCESS']);
				}					   
				else
				{
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus+":"+nsCreationMsg]); 						   
				}							
				if(nsClientRecordID!=null && nsClientRecordID!='')
				{
				idForResponse=nsClientRecordID;
					
                    scriptStatus='SUCCESS'
                        // main1.internalId=recordId  				 				  
					if (responseData.getCode() == '200' || responseData.getCode() == '201')
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					  else
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
					
				}
            }
        }				   
		if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
		{			
			if(connexIDResponseValue==null || connexIDResponseValue=='')
				   connexIDResponseValue=''			   
			main1.EntityId=connexIDResponseValue
			
			if(idForResponse==null || idForResponse=='')
				 idForResponse=''
			  main1.NetSuiteId=idForResponse
			if(Status1!=null && Status1!='')
				main1.IntegrationResponseStatus=Status1
			else
				main1.IntegrationResponseStatus=scriptStatus
		 
			if(nsCreationMsg==null || nsCreationMsg=='')
				 nsCreationMsg=''
			main1.IntegrationResponseMessage=nsCreationMsg
			nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP], [JSON.stringify(main1)]); 	   
			var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
			var body = JSON.stringify(main1);
			var HEADERS = {"Authorization":signatures};
			//HEADERS.scriptStatus=scriptStatus
			if(CorrelationId==null || CorrelationId=='')
				CorrelationId=''
			HEADERS['NServiceBus.CorrelationId']=CorrelationId
			HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
			var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

		}
		if(context.getRemainingUsage()<=1000)
	{
	nlapiScheduleScript(SPARAM_CONNEX_CONTACT,null)
      break;  
	}		  		   
	}
      }
		  }
           