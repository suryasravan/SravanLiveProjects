/**
 * Script name: Appf-Create Split Bills from PO SL
 * Script type: Suitelet
 * Description: This script will be triggered from 'Create Split Bills' button action and creates vendor bills for PO for sub vendor based on number of split vendor bill records
 * Company    : Appficeincy Inc.
 */

 var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';
 
 var FLD_SPLIT_VEND_INVOICES_BACKLINK = 'custbody_appf_split_vendor_inv_link';
 var FLD_SALES_ORDER_BACKLINK = 'custbody_rx_salesorderlink';
 
var FLD_SPLIT_INVOICE_PERCENT = 'custrecord_appf_split_billing_invpercent';
 var FLD_SPLIT_INVOICE_SO_LINK = 'custrecord_appf_split_invoice_solink';
 var FLD_SPLIT_INVOICE_SUB_CLIENT = 'custrecord_appf_split_invoice_sub_client';

var CUSTOM_RECORD_SPLIT_VEND_INVOICE = 'customrecord_appf_split_vendor_invoicing';
var FLD_SPLIT_VEND_INVOICE_PERCENT = 'custrecord_appf_split_vendor_inv_invperc';
 var FLD_SPLIT_VEND_INVOICE_PO_LINK = 'custrecord_appf_split_vendor_inv_po_link';
 var FLD_SPLIT_INVOICE_SUB_VENDOR = 'custrecord_appf_split_vendor_inv_sub_ven';

 var FLD_SPLIT_VEND_INVOICING_LINK='custrecord_appf_split_vendor_inv_bill';
 var FLD_SPLIT_VEND_INV_CUSTOM_REC_BACKLINK = 'custbody_appf_split_vendor_inv_link';

function createVendBills(request,response)
{
	var poRecordId=request.getParameter('poRecordId');
	var purchOrdRec = nlapiLoadRecord('purchaseorder', poRecordId);
	var purchOrdVend = purchOrdRec.getFieldValue('entity');
	//var startDate = purchOrdRec.getFieldValue('startdate');
	//var endDate = purchOrdRec.getFieldValue('enddate');
	try {
		var fils = [];
		var cols = [];
		
		fils.push(new nlobjSearchFilter(FLD_SPLIT_VEND_INVOICE_PO_LINK, null, 'anyof', [poRecordId]));
		fils.push(new nlobjSearchFilter(FLD_SPLIT_VEND_INVOICE_PERCENT, null, 'isnotempty'));
		
		cols.push(new nlobjSearchColumn(FLD_SPLIT_VEND_INVOICE_PERCENT));
		cols.push(new nlobjSearchColumn(FLD_SPLIT_INVOICE_SUB_VENDOR));
		
		var splitVendInvoiceResults = nlapiSearchRecord(CUSTOM_RECORD_SPLIT_VEND_INVOICE, null, fils, cols);
		var vendBillList = [];
		var subClients = [];
	    for(var i=0;i<splitVendInvoiceResults.length;i++)
	    {
			var splitPercent = splitVendInvoiceResults[i].getValue(FLD_SPLIT_VEND_INVOICE_PERCENT);
			splitPercent = splitPercent.slice(0,-1);
			var subClient = splitVendInvoiceResults[i].getValue(FLD_SPLIT_INVOICE_SUB_VENDOR);
			var SplitRecId=splitVendInvoiceResults[i].getId();
			
			var vendRecord=nlapiTransformRecord('purchaseorder',poRecordId,'vendorbill',{recordmode:'dynamic'});
		//	vendRecord.setFieldValue('entity', purchOrdVend);
			vendRecord.setFieldValue(FLD_SPLIT_VEND_INV_CUSTOM_REC_BACKLINK, SplitRecId);

			var vendBillId=nlapiSubmitRecord(vendRecord,true,true);
			
			if (vendBillId != null && vendBillId != '')
			{
				nlapiSubmitField(CUSTOM_RECORD_SPLIT_VEND_INVOICE,SplitRecId,FLD_SPLIT_VEND_INVOICING_LINK,vendBillId);
				//vendBillList.push(vendBillId);
				var vendBillRec = nlapiLoadRecord('vendorbill', vendBillId);
				vendBillRec.setFieldValue('entity', subClient);
				vendBillRec.setFieldValue(FLD_SPLIT_VEND_INV_CUSTOM_REC_BACKLINK, SplitRecId);
							var count=vendBillRec.getLineItemCount('item');
			for(var j=1;j<=count;j++)
			{
				var poLineID = vendBillRec.getLineItemValue('item',FLD_COL_PO_LINE_ID,j);
				var vbLine = purchOrdRec.findLineItemValue('item', FLD_COL_PO_LINE_ID, poLineID);
				if(vbLine != -1){
					var poItem=purchOrdRec.getLineItemValue('item','item',vbLine);
					var poProj=purchOrdRec.getLineItemValue('item','job',vbLine);
					var poRate=purchOrdRec.getLineItemValue('item','rate',vbLine);
					var quantity=purchOrdRec.getLineItemValue('item','quantity',vbLine);
					var newQuantity=(parseFloat(quantity)*parseFloat(splitPercent))/100;
					//nlapiLogExecution('DEBUG', 'poRate', poRate);
					vendBillRec.selectLineItem('item', j);
					//vendRecord.setCurrentLineItemValue('item','item',poItem);
					vendBillRec.setCurrentLineItemValue('item','job',poProj);
					
					vendBillRec.setCurrentLineItemValue('item','quantity',newQuantity);
                    vendBillRec.setCurrentLineItemValue('item','rate',poRate);
					vendBillRec.commitLineItem('item');
				}
			}
				nlapiSubmitRecord(vendBillRec, true, true);
			}
        }
    	
		nlapiLogExecution('DEBUG','vendBillList:',vendBillList);
	
      
	}catch (e)
	{
		nlapiLogExecution('debug', 'Failed to process split Bills for PO ID:'+poRecordId, e.toString());
	}
  response.sendRedirect('RECORD', 'purchaseorder', poRecordId);
}