/*Script Name: Appf-Sync Contract & SO UE
 *Script Type: User Event
 *Event Type : After Submit
 *Description: 
 *Company 	 : Appficiency.
*/

var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_CONTRACT_MEDIA_TYPE = 'custrecord_appf_contract_media_type';
var FLD_CONTRACT_END_DATE = 'custrecord_appf_contract_end_date';
var FLD_CONTRACT_DEPT = 'custrecord_appf_contract_department';
var FLD_CONTRACT_LOB = 'custrecord_appf_contract_lineofbusiness';
var FLD_CONTRACT_POP_REQUIRED = 'custrecord_appf_contract_pop_required';

var FLD_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_ORDER_VALIDATION_STATUS = 'custbody_appf_orderval_status';
var FLD_COL_POP_REQUIRED = 'custcol_appf_print_poprequired';
var FLD_COL_CORP_OWNER = 'custcol_appf_corporateowner';

var BUYING_SYSTEM_PRINT = '1';

function syncContractSOAfterSubmit(type){
	if(type != 'delete'){
		var recType = nlapiRecordType();
		var recId = nlapiRecordId();
		var soRec = nlapiLoadRecord(recType, recId);
		var contract = soRec.getFieldValue(FLD_CLIENT_CONTRACT);
		var validationStatus = soRec.getFieldValue(FLD_ORDER_VALIDATION_STATUS);
		var buyingSys = soRec.getFieldValue(FLD_BUYING_SYSTEM);
		var isError = false;
		var errorMsg = '';
		if(contract != null && contract != ''){
			try{
			var contractRec = nlapiLoadRecord(CUSTOM_RECORD_CONTRACT, contract);
			var dept = contractRec.getFieldValue(FLD_CONTRACT_DEPT);
			var lob = contractRec.getFieldValue(FLD_CONTRACT_LOB);
			var popRequired = contractRec.getFieldValue(FLD_CONTRACT_POP_REQUIRED);
			var contractName = contractRec.getFieldValue('name');
			
			if(dept != null && dept != '')
				soRec.setFieldValue('department', dept);
			if(lob != null && lob != '')
				soRec.setFieldValue('class', lob);
			for(var i=1; i<=soRec.getLineItemCount('item'); i++){
				if(buyingSys == BUYING_SYSTEM_PRINT && popRequired != null && popRequired != '')
					soRec.setLineItemValue('item', FLD_COL_POP_REQUIRED, i, popRequired);
				if(contractName != null && contractName != '')
					soRec.setLineItemValue('item', FLD_COL_CORP_OWNER, i, contractName);
			}
			}catch(e){
				isError = true;
				if ( e instanceof nlobjError ){
					nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
					errorMsg += e.getDetails();
				}
				else{
					nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
					errorMsg += e.toString();
				}
			}
			if(isError){
				soRec.setFieldValue(FLD_ORDER_VALIDATION_STATUS, 'Failed. '+errorMsg);
			}
			else{
				if(validationStatus != null && validationStatus != ''){
					soRec.setFieldValue(FLD_ORDER_VALIDATION_STATUS, 'Success');
					//soRec.setFieldValue('orderstatus', '');
				}					
			}
			nlapiSubmitRecord(soRec, true, true);
		}
	}
}