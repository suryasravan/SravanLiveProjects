/**
* Script Name : Appf-VVCCP Refresh Button UE
* Script Type : User Event Script
* 
* Version    Date            Author           		Remarks
* 1.00            			 Debendra Panigrahi		
*
* Company 	 : Appficiency. 
*/

var BTN_REFRESH='custpage_refresh_btn';
var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
		var FLD_APPROVAL_STATUS_APPROVED=2;
		var FLD_APPROVAL_STATUS_OPEN=11;
		var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
		var FLD_APPROVAL_STATUS_REJECTED=3;
		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED=2
		var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978;
		var BILL_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_bill_vvccp';
		var CREDIT_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_cred_vvccp';
		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED_FOR_TRANSACTIONS=2
		
		
		var STATUS_FOR_VVCCP_STATUS_IN_PROGRESS=2
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_SUCCESSFULLY=4
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_WITH_ERRORS=5
		
		//VVCCP Execution Batch
		var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills';	
		var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred';
		var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
		var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
		var FLD_PROCESSED_PERCENT	     			='custrecord_appf_vvccp_log_percent';
		var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by';
		var FLD_VVCCP_LOG_STATUS	     			='custrecord_appf_vvccp_log_status';
		var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file';
		var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file';
		var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log';
		var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';
		var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
		var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
		var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
		var FLD_BILL_DATA_FILES						='custrecord_appf_vvccp_bill_data_files';
		var FLD_CREDIT_DATA_FILE					='custrecord_appf_credit_data_file';

		var FLD_BILL_AND_CREDIT_BODY_VVCCP_LOG='custbody_appf_pending_auth_vvccp';
function userEventBeforeLoad(type, form, request){
	if(type == 'view'){
		var id=nlapiGetRecordId();
      nlapiLogExecution('debug','internalid:',id);
		var totalVvccpNeedsToProcess=nlapiGetFieldValue(FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS);
		var totalVvccpNeedsToProcessed=nlapiGetFieldValue(FLD_TOTAL_VVCCP_RECORDS_PROCESSED);
        if(totalVvccpNeedsToProcess != totalVvccpNeedsToProcessed)
        {
           try
        {
          nlapiLogExecution( 'DEBUG', 'recordid:', id);
      var name=nlapiGetFieldValue('name');
          nlapiLogExecution( 'DEBUG', 'name:', name);
      var totalBillAndBilllCreditProcessed=0;
       if(id !=null && id !='')
       {
      var filters=[];
      var columns=[]
      filters.push(new nlobjSearchFilter('type',null,'anyof',['VendBill','VendCred']));
      filters.push(new nlobjSearchFilter(FLD_BILL_AND_CREDIT_BODY_VVCCP_LOG,null,'anyof',id));
      filters.push(new nlobjSearchFilter('mainline',null,'is','T'));
      var billAndBillCreditSearc=nlapiSearchRecord('transaction',null,filters,columns);
      if(billAndBillCreditSearc !=null && billAndBillCreditSearc !='')
        {
          nlapiLogExecution( 'DEBUG', 'billAndBillCreditSearc:', billAndBillCreditSearc.length); 
          totalBillAndBilllCreditProcessed=parseFloat(totalBillAndBilllCreditProcessed)+parseFloat(billAndBillCreditSearc.length);
          nlapiLogExecution( 'DEBUG', 'totalBillAndBilllCreditProcessed:', totalBillAndBilllCreditProcessed); 
          var percentageValue=percentage(totalBillAndBilllCreditProcessed,totalVvccpNeedsToProcess);
          nlapiLogExecution( 'DEBUG', 'percentageValue:', percentageValue); 
          nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH,id,[FLD_TOTAL_VVCCP_RECORDS_PROCESSED,FLD_PROCESSED_PERCENT],[totalBillAndBilllCreditProcessed,percentageValue]);
   if(totalVvccpNeedsToProcess == totalBillAndBilllCreditProcessed)
      {
      nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH,id,[FLD_TOTAL_VVCCP_RECORDS_PROCESSED,FLD_PROCESSED_PERCENT,FLD_VVCCP_LOG_STATUS],[totalBillAndBilllCreditProcessed,percentageValue,STATUS_FOR_VVCCP_STATUS_COMPLETED_SUCCESSFULLY]);
      }
        }
        }
        }
        
      catch(e)
        {
          nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString());
        }
		var url=nlapiResolveURL('RECORD', CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, id);
		form.addButton(BTN_REFRESH, 'Refresh', 'window.open(\''+url+'\',\'_self\',\'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=1000,height=500\')');
        }   
	}
}
function percentage(partialValue, totalValue) {
   return (100 * partialValue) / totalValue;
}