/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 */
 
/*
* Script Name : Appf - Script 2.0 gzip SL
* Script Type : Suitelet
* Description :
* Company : Appficiency Inc.
*/


define(['N/encode','N/search','N/record','N/ui/serverWidget','N/runtime','N/url','N/task','N/file','N/https','N/render','Gunzip Files - Integration/pako.js','Gunzip Files - Integration/base64.js'],
    function (encode,search,record,serverWidget,runtime,url,task,file,https,render,pako,test)
    {
	
        function onRequest(context)
        {   
try{
//var genericRecIds = request.getParameter('genetricrecid');
var b64fileId =context.request.parameters.fileid;
var b64file=file.load({'id':b64fileId});
var b64Data=b64file.getContents();

log.debug( 'b64Data',b64Data)
var strData     = atob(b64Data);
   // var strData     = CryptoJS.enc.Base64.parse(b64Data);
	log.debug( 'strData',strData)
    // Convert binary string to character-number array
    var charData    = strData.split('').map(function(x){return x.charCodeAt(0);});
    // Turn number array into byte-array
    //var binData     = new Uint8Array(charData);
	//log.debug( 'binData',binData)
    // Pako magic
	log.debug( 'charData',charData)
 
     var data =  pako.inflate(charData);
  log.debug( 'data',data)
    //var data = pako.inflate(charData);
    // Convert gunzipped byteArray back to ascii string:
    var finalData     = String.fromCharCode.apply(null, data);
	finalData=finalData.replace(/^[^-]+{/,"{");
  log.debug( 'finalData',finalData)
  context.response.write(finalData)
    // Output to console



}catch(e){
if ( e instanceof nlobjError )
log.debug( 'system error', e.getCode() + '\n' + e.getDetails() )
else
log.debug( 'unexpected error', e.toString() )
}
}
 return {
            onRequest: onRequest
        };
		
		
		function arrayBufferToString(buffer){
    var bufView =new Uint16Array(buffer);
    var length = bufView.length;
    var result = '';
    var addition = Math.pow(2,16)-1;

    for(var i = 0;i<length;i+=addition){

        if(i + addition > length){
            addition = length - i;
        }
        result += String.fromCharCode.apply(null, bufView.subarray(i,i+addition));
    }

    return result;

}

	});