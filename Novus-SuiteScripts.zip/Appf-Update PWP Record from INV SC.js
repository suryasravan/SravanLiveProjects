/*
*Script Name: Appf-Update PWP Record from INV SC
*Script Type: Scheduled
*Description: 
*Company 	: Appficiency Inc.
* Version      Date            Author           Remarks
 * 1.00       5 March 2020     
*/

var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_INV_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_COL_INV_LINE_PAYMENT_AMT = 'custcol_appf_pwp_inv_line_amt_paid';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_INVOICE_LINK = 'custrecord_appf_pwp_inv_link';
var FLD_PWP_INVOICED_AMT = 'custrecord_appf_pwp_inv_line_amount';
var FLD_PWP_INVOICE_LINE_ID = 'custrecord_appf_pwp_invoice_line_id';
var FLD_PWP_INVOICE_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_inv_line_amt_paid';
var FLD_PWP_READY_FOR_PAYMENT = 'custrecord_appf_pwp_ready_for_payment';

var FLD_PWP_IO_CHECKBOX='custrecord_appf_trigger_ob_integration';

var FLD_PWP_INVOICE_STATUS = 'custrecord_appf_pwp_client_inv_status';
var FLD_PWP_CRED_MEMO_AMT = 'custrecord_appf_pwp_cm_amount';
//var FLD_PWP_READY_CM_PAYMENT = 'custrecord_appf_pwp_cm_amount';

var SPARAM_INVOICE_ID = 'custscript_appf_invoice_id';
var SPARAM_INDEX = 'custscript_appf_invoice_line_index';
var SPARAM_UPDATE_PWP_INVOICES_SS = 'custscript_appf_update_pwp_invs_ss';
var STATUS_PAYMENT_PENDING='4'
var STATUS_PARTIALLY_PAID='5'
var STATUS_PAID='7'
function updatePWPInvScheduled(type) {
	var context = nlapiGetContext();
	try{
		var recId = context.getSetting('SCRIPT',SPARAM_INVOICE_ID);
		var index = context.getSetting('SCRIPT',SPARAM_INDEX);
		var invSS = context.getSetting('SCRIPT', SPARAM_UPDATE_PWP_INVOICES_SS);
		if(index == null || index == '')
			index  = 1;
		
		if(recId != null && recId != ''){
			var inv = nlapiLoadRecord('invoice', recId);
			var count = inv.getLineItemCount('item');
			
			for(var i=index; i<=count; i++){
				try{
				var pwpRecId = inv.getLineItemValue('item', FLD_COL_PWP_RECORD, i);
				var soLineId = inv.getLineItemValue('item', FLD_COL_SO_LINE_ID, i);
				if(pwpRecId != null && pwpRecId != '' && soLineId != null && soLineId != '' && invSS != null && invSS != ''){				
					
					var filters = [];
					filters.push(new nlobjSearchFilter(FLD_COL_SO_LINE_ID, null, 'is', soLineId));
						
						
					var invSearchResults = nlapiSearchRecord(null, invSS, filters, null);
					if(invSearchResults != null && invSearchResults != ''){
						var invAmtSum = 0;
						var invLinePaymentAmtSum = 0;
						var invInternalIdsArr = [];
						var invLineIdsArr = [];
						for(var j=0; j<invSearchResults.length; j++){
							var result = invSearchResults[j];
							var invId = result.getId();
							var ssCols = result.getAllColumns();
							var invLineId = result.getValue(ssCols[0]);
							var invLinePaymentAmt = result.getValue(ssCols[2]);
							if(invLinePaymentAmt == null || invLinePaymentAmt == '')
								invLinePaymentAmt = 0;
							//nlapiLogExecution('DEBUG', 'invLinePaymentAmt in for', invLinePaymentAmt);
							var invAmt = result.getValue(ssCols[1]);
							if(invAmt == null || invAmt == '')
								invAmt = 0;
							
							invAmtSum = parseFloat(invAmtSum) + parseFloat(invAmt);
							invLinePaymentAmtSum = parseFloat(invLinePaymentAmtSum) + parseFloat(invLinePaymentAmt);
							invInternalIdsArr.push(invId);
							invLineIdsArr.push(invLineId);
						}
						invInternalIdsArr = eliminateDuplicates(invInternalIdsArr);
						invLineIdsArr = eliminateDuplicates(invLineIdsArr);
						
						var invLineIds = '';
						for(var l=0; l<invLineIdsArr.length; l++){
							if(l == (invLineIdsArr.length-1))
								invLineIds += invLineIdsArr[l];
							else
								invLineIds += invLineIdsArr[l] + ',';
						}
						var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
						pwpRecord.setFieldValues(FLD_PWP_INVOICE_LINK, invInternalIdsArr);
						pwpRecord.setFieldValue(FLD_PWP_INVOICE_LINE_ID, invLineIds);
                      if(invAmtSum != null && invAmtSum != '')
						pwpRecord.setFieldValue(FLD_PWP_INVOICED_AMT, invAmtSum.toFixed(2));
                      if(invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						pwpRecord.setFieldValue(FLD_PWP_INVOICE_LINE_PAYMENT_AMT, invLinePaymentAmtSum.toFixed(2));
						
						if(invAmtSum == invLinePaymentAmtSum)
							pwpRecord.setFieldValue(FLD_PWP_READY_FOR_PAYMENT, 'T');
						
						var pwpStatus=getCustomerStatus(pwpRecord,FLD_PWP_INVOICED_AMT,invAmtSum)
						   if(pwpStatus!=null && pwpStatus!='')
                             {
							pwpStatus.setFieldValue(FLD_PWP_INVOICE_STATUS, pwpStatus);
						    pwpRecord.setFieldValue(FLD_PWP_IO_CHECKBOX, 'T');
                               
                             }
                      
						var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
						nlapiLogExecution('DEBUG', 'pwpId', pwpId);
					}
					
				}
				}catch(e){
				if ( e instanceof nlobjError )
					  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
					  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
				if(count > (i+1) && context.getRemainingUsage() <= 9970){
					var params = {};
					params[SPARAM_INVOICE_ID] = recId;
					params[SPARAM_INDEX] = (i+1);
					nlapiScheduleScript(context.getScriptId(), null, params);
					break;
				}
			}
		}
	}catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}

function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		function getCustomerStatus(pwpRecord,fielID,fieldValue) 
{
	                    var invAmtSum = fieldValue;
						var invLinePaymentAmtSum = fieldValue;
						var crditAmtSum = fieldValue;
						
						var crditStatus=''
						
						if(fielID!=FLD_PWP_INVOICED_AMT)
							invAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICED_AMT);
						
						if(fielID!=FLD_PWP_INVOICE_LINE_PAYMENT_AMT)
							invLinePaymentAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICE_LINE_PAYMENT_AMT);
						
						if(fielID!=FLD_PWP_CRED_MEMO_AMT)
							crditAmtSum=pwpRecord.getFieldValue(FLD_PWP_CRED_MEMO_AMT);
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{	
					if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)==0)
							crditStatus=STATUS_PAYMENT_PENDING
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && ((parseFloat(invAmtSum)-parseFloat(invLinePaymentAmtSum))>0))
							crditStatus=STATUS_PARTIALLY_PAID
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '' && crditAmtSum!=null && crditAmtSum!='')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && parseFloat(invAmtSum)==(parseFloat(invLinePaymentAmtSum)+parseFloat(crditAmtSum)))
							crditStatus=STATUS_PAID
						}
							
							return crditStatus
	
}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
		
function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}

