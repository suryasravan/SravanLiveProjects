/*
* Script Name : Appf-Client Credit SC #1
* Script Type : Scheduled
* Description : This script trigegrs immediately on submit of Appf - Client Credit SL and for invoice selected it sets the CREDIT SUITELET STATUS field as Under Processing and Checks the Credit Processing (Do Not Hide) checkbox at the line level for all lines selected on the Suitelet
* Company     : Appficiency Inc.
*/

var FLD_INV_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var FLD_COL_INV_LINE_ID ='custcol_appf_invoice_line_id';
var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_COL_INV_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var SL_STATUS_UNDER_PROCESSING = '1';

var SCRIPT_CLIENT_CREDIT_CREATION_SC = 'customscript_appf_client_credit_creation';
var SPARAM_CREDIT_CREATION_LOG_ID = 'custscript_appf_credit_creation_log_id';

var SPARAM_CREDIT_CREATION_LOG_ID_1 = 'custscript_appf_credit_creation_log_id_1';
var SAPARM_SELECTED_LINES_FILE_ID = 'custscript_appf_selected_inv_folder_id';
var SPARAM_INDEX = 'custscript_appf_client_index';

function updateInvScheduled(type){
	try{
	var context = nlapiGetContext();
	var custRecID = context.getSetting('SCRIPT', SPARAM_CREDIT_CREATION_LOG_ID_1);
	var salesDataFileId = context.getSetting('SCRIPT', SAPARM_SELECTED_LINES_FILE_ID);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if(index == null || index == '')
		index = 0;
	var invoicesProcessed = true;
	if(salesDataFileId != null && salesDataFileId != ''){
			var invoiceRecords = {};
			var fileContent = nlapiLoadFile(salesDataFileId).getValue();
			if(fileContent != null && fileContent != ''){
				fileContent = fileContent.split('\n');
				for(var f=0; f<(fileContent.length-1); f++){					
					var salesOrderData = fileContent[f].split('::');
					try{
						if(salesOrderData != null && salesOrderData != ''){						
							var salesRec = nlapiLoadRecord('salesorder', salesOrderData[0]);
							salesRec.setFieldValue(FLD_INV_CREDIT_SL_STATUS, SL_STATUS_UNDER_PROCESSING);
							var soLineIds = salesOrderData[1];
							if(soLineIds != null && soLineIds != ''){
								soLineIds = soLineIds.split('|');
								for(var i=0; i<(soLineIds.length-1); i++){
									var lineNum = salesRec.findLineItemValue('item', FLD_SO_LINE_ID, soLineIds[i]);
									if(lineNum != -1)
									salesRec.setLineItemValue('item', FLD_COL_INV_CREDIT_PROCESSING, lineNum, 'T');
								}
							}
							var salesRecId = nlapiSubmitRecord(salesRec, true, true);
							nlapiLogExecution('debug', 'salesRecId:', salesRecId);
						}
					}catch(e){
							
							if ( e instanceof nlobjError )
							  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
							else
							  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
					}
					if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				
				}
				
			}
				if(salesDataFileId != null && salesDataFileId != '')
				nlapiDeleteFile(salesDataFileId);
			   var params = {};
			   params[SPARAM_CREDIT_CREATION_LOG_ID] = custRecID;
			   nlapiScheduleScript(SCRIPT_CLIENT_CREDIT_CREATION_SC, null, params);
			
		}
	}catch(e){
		if ( e instanceof nlobjError )
							  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
							else
							  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}



function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}