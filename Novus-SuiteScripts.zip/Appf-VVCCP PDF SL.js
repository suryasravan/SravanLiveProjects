/*Script Name: Appf - VVCCP PDF SL
 *Script Type: Suitelet
 *Company 	 : Appficiency
 * Version    Date            Author           Remarks
 * 1.0       26 May 2020     		          This script displays an UI/form with filters and columns based on Saved Search of  Sales Orders line items which provides users with ability to mark multiple lines
 * 2.0       04 Nov 2020      Roach           Set created file to Available without login
 * 2.1		 23 Jan 2021	  MJ			  Fixing table alignment
 * 2.2		 25 Jan 2021	  MJ			  Added GST and PST
 * 2.3		 05	Feb 2021	  MJ			  Dynamic Address and Logo by Subsidiary
 */
var FLD_VVCCP_CARD_VVCCP_LINK = 'custrecord_appf_vvccp_card_vvccp_link';
var FLD_VVCCP_AUTHORIZTION_DATE = 'custrecord_appf_vvccp_authorization_date';
var FLD_VVCCP_CARD_NUMBER = 'custrecord_appf_vvccp_card_number';
var FLD_VVCCP_CARD_PROVIDER = 'custrecord_appf_vvccp_card_provider';
var FLD_VVCCP_CARD_EXP_DATE = 'custrecord_appf_vvccp_card_exp_date';
var FLD_VVCCP_CARD_CODE = 'custrecord_appf_vvccp_card_code';
var FLD_VVCCP_CARD_NUMBER = 'custrecord_appf_vvccp_card_number';
var CUSTOMRECORD_VVCCP_BACK_LINK = 'custrecord_appf_vvccp_backlink'
var FLD_VVCCP_LINKED_TRAN_TYPE = 'custrecord_appf_vvccp_linked_tran_type';
var FLD_VVCCP_LINKED_ORDER_REF = 'custrecord_appf_vvccp_linked_order_ref';
var FLD_VVCCP_LINKED_SERVICE_DATE = 'custrecord_appf_vvccp_linked_servicedate';
var FLD_VVCCP_LINKED_BILL_REF_NO = 'custrecord_appf_vvccp_linked_bill_ref_no';
var FLD_VVCCP_LINKED_TRAN_AMT = 'custrecord_appf_vvccp_linked_tran_amt';
var FLD_VVCCP_LINKED_BILL_REF_NO = 'custrecord_appf_vvccp_linked_bill_ref_no';
var FLD_VVCCP_LINKED_BILL_REF_NO = 'custrecord_appf_vvccp_linked_bill_ref_no';
var CUSTOMRECORD_VVCCP_LINKED_TRANS = 'customrecord_appf_vvccp_linked_trans';
var FLD_VVCCP_MAX_SPEND_AMT = 'custrecord_appf_vvccp_max_spend_amt';
var FLD_VVCCP_CURRENCY = 'custrecord_appf_vvccp_currency';
var FLD_VVCCP_LINKED_CLIENT_NAME = 'custrecord_appf_vvccp_linked_client';
var FLD_VVCCP_LINKED_PUBLISHER = 'custrecord_appf_vvccp_linked_publisher';
var CUSTOM_RECORD_CORPORATE_CREDIT_CARD = 'customrecord_appf_corp_card_table';
var FLD_CREDIT_CARD_TYPE = 'custrecord_appf_corp_credit_card_type';
var CUSTOMRECORD_VVCCP = 'customrecord_appf_vvccp_record'
var CUSTOMRECORD_VVCCP_AUTHORIZED_CARD = 'customrecord_appf_vvccp_authorized_card';
var FLD_CORPORATE_CREDIT_CARD = 'custrecord_appf_vvccp_corp_card';
var month_names = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
var monthnumber = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ];
var COLOR_TABLE_BORDER = '#D3D3D3';
var FOLDER_VVCCP_PDF = '1147';

/// v2.2
var FLD_VVCCP_LINKED_TRANSID = 'custrecord_appf_vvccp_linked_transaction';

//added by shravan kumar 12-10-2022
var FLD_VVCCP_VENDERNAME = 'custrecord_appf_vvccp_vendor';

function pdfsuitelet ( internalid ) {
	var fileid = '';
	var vcpRec = nlapiLoadRecord( CUSTOMRECORD_VVCCP, internalid );
	var corporateCreditcardOnVVCCP = vcpRec.getFieldValue( FLD_CORPORATE_CREDIT_CARD );

	//added by shravan kumar 12-10-2022
	var payee = vcpRec.getFieldText( FLD_VVCCP_VENDERNAME );
	if ( payee )
		payee = nlapiEscapeXML( payee )
	var cardType = '';
	if ( corporateCreditcardOnVVCCP ) {
		var ccRec = nlapiLoadRecord( CUSTOM_RECORD_CORPORATE_CREDIT_CARD, corporateCreditcardOnVVCCP )
		cardType = ccRec.getFieldText( FLD_CREDIT_CARD_TYPE );
	}
	var vvccpname = '';
	if ( vcpRec != null && vcpRec != '' ) {
		vvccpname = vcpRec.getFieldValue( 'name' );

		var filters = [];
		var columns = [];
		filters.push( new nlobjSearchFilter( FLD_VVCCP_CARD_VVCCP_LINK, null, 'anyof', internalid ) );
		columns.push( new nlobjSearchColumn( FLD_VVCCP_AUTHORIZTION_DATE ) );
		columns.push( new nlobjSearchColumn( FLD_VVCCP_CARD_NUMBER ) );
		//columns.push(new nlobjSearchColumn(FLD_VVCCP_CARD_PROVIDER));
		columns.push( new nlobjSearchColumn( FLD_VVCCP_CARD_EXP_DATE ) );
		columns.push( new nlobjSearchColumn( FLD_VVCCP_CARD_CODE ) );
		//columns.push(new nlobjSearchColumn('custrecord_appf_vvccp_max_spend_amt'));
		columns.push( new nlobjSearchColumn( 'internalid' ).setSort() )
		var customerSearch = nlapiSearchRecord( CUSTOMRECORD_VVCCP_AUTHORIZED_CARD, null, filters, columns );
		var incomingDateChnge1 = '';
		var paymentDateString = ''
		var incomingDateString = ''
		var cardNum = '';
		var providers = '';
		var cardExpDate = '';
		var secCode = '';
		if ( customerSearch != '' && customerSearch != null ) {
			var authDate = customerSearch[ 0 ].getValue( FLD_VVCCP_AUTHORIZTION_DATE );
			cardNum = customerSearch[ 0 ].getValue( FLD_VVCCP_CARD_NUMBER );
			providers = cardType;
			var cardExpDate1 = customerSearch[ 0 ].getValue( FLD_VVCCP_CARD_EXP_DATE );
			secCode = customerSearch[ 0 ].getValue( FLD_VVCCP_CARD_CODE );
			//var Amount=customerSearch[0].getValue('custrecord_appf_vvccp_max_spend_amt');
			if ( cardExpDate1 != null && cardExpDate1 != '' ) {
				var cardExpDateString = nlapiStringToDate( cardExpDate1 );
				var cardExpDateMonth = cardExpDateString.getMonth();
				var cardExpDateMonthString = monthnumber[ cardExpDateMonth ]
				if ( cardExpDateMonthString < 10 ) {
					cardExpDateMonthString = '0' + cardExpDateMonthString;
				}
				var cardExpDateYear = cardExpDateString.getFullYear();
				cardExpDate = cardExpDateMonthString + '/' + cardExpDateYear
			}
			if ( authDate != null && authDate != '' ) {
				var incomingDateChnge = nlapiStringToDate( authDate );
				var incomingDate = nlapiAddDays( incomingDateChnge, 90 )
				incomingDateString = nlapiDateToString( incomingDate )
				paymentDateString = nlapiDateToString( incomingDateChnge )
				var incomingDay = incomingDateChnge.getDate();
				var incomingMonth = incomingDateChnge.getMonth();
				var incomingYear = incomingDateChnge.getFullYear();
				if ( incomingDay < 10 ) {
					incomingDay = '0' + incomingDay;
				}
				incomingDateChnge1 = month_names[ incomingMonth ] + ' ' + incomingDay + ', ' + incomingYear + ' ';
			}
		}
		incomingDateChnge1 = incomingDateChnge1 + 'Payment Authorization';
		var filtersCredits = [];
		var columnsCredits = [];
		filtersCredits.push( new nlobjSearchFilter( CUSTOMRECORD_VVCCP_BACK_LINK, null, 'anyof', internalid ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_TRAN_TYPE ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_ORDER_REF ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_SERVICE_DATE ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_TRAN_AMT ) );
		columnsCredits.push( new nlobjSearchColumn( 'altname', FLD_VVCCP_LINKED_CLIENT_NAME ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_BILL_REF_NO ) );
		columnsCredits.push( new nlobjSearchColumn( FLD_VVCCP_LINKED_PUBLISHER ) );

		/// v2.2
		columnsCredits.push( new nlobjSearchColumn( 'tranid', FLD_VVCCP_LINKED_TRANSID ) );

		/// v2.3
		columnsCredits.push( new nlobjSearchColumn( 'Subsidiary', FLD_VVCCP_LINKED_TRANSID ) );
		var logourl = "http://shopping.na3.netsuite.com/core/media/media.nl?id=709039&amp;c=3619984&amp;h=58af7aed46e56a5acf34";
		var address = '';

		//added by sravan 5/18/2022
		var logoHeight = '100%';
		var logoWidth = '200px';

		var creditSearch = nlapiSearchRecord( CUSTOMRECORD_VVCCP_LINKED_TRANS, null, filtersCredits, columnsCredits );
		if ( creditSearch != '' && creditSearch != null ) {
			nlapiLogExecution( 'DEBUG', 'creditSearch.length', JSON.stringify( creditSearch.length ) )
			var vbDataobj = {}

			var prev_tran_id = null;

			for ( var c = 0; c < creditSearch.length; c++ ) {
				var cols = creditSearch[ c ]
				var tranType = nlapiEscapeXML( cols.getText( FLD_VVCCP_LINKED_TRAN_TYPE ) );
				var refNum = cols.getValue( FLD_VVCCP_LINKED_ORDER_REF );
				var billrefNum = cols.getValue( FLD_VVCCP_LINKED_BILL_REF_NO );

				var servicedate = cols.getValue( FLD_VVCCP_LINKED_SERVICE_DATE );
				var tranAmt = cols.getValue( FLD_VVCCP_LINKED_TRAN_AMT );
				if ( tranAmt == null || tranAmt == '' ) tranAmt = 0
				var customer = nlapiEscapeXML( cols.getValue( 'altname', FLD_VVCCP_LINKED_CLIENT_NAME ) );
				var medisup = nlapiEscapeXML( cols.getText( FLD_VVCCP_LINKED_PUBLISHER ) );
				//var Amount=customerSearch[0].getValue('custrecord_appf_vvccp_max_spend_amt');




				/// v2.2
				var tranId = cols.getValue( 'tranid', FLD_VVCCP_LINKED_TRANSID ) || '';

				// Updated by Sai 5/23/2022
				var intID = cols.getId();
				// Updated by Sai 5/23/2022
				if ( intID != prev_tran_id ) {
					if ( !vbDataobj.hasOwnProperty( billrefNum ) ) {
						if ( tranType == 'Vendor Bill' ) {
							tranAmt = tranAmt;
							//nlapiLogExecution( 'DEBUG', 'tranAmt', JSON.stringify(tranAmt))
						}
						if ( tranType == 'Vendor Bill Credit' ) {
							tranAmt = ( -1 ) * tranAmt;
							//nlapiLogExecution( 'DEBUG', 'tranAmt', JSON.stringify(tranAmt))
						}
						var innerobj = {}
						var lines = {}
						innerobj.tranAmt = tranAmt
						lines.servicedate = servicedate
						lines.refNum = refNum
						lines.amount = tranAmt
						lines.customer = customer
						lines.medisup = medisup

						/// v2.2
						lines.tranid = tranId;
						// Updated by Sai 5/23/2022
						lines.intID = intID;

						lines.is_gst = tranId.indexOf( 'GST' ) > -1;
						lines.is_pst = tranId.indexOf( 'PST' ) > -1;

						innerobj.lines = [ lines ]
						vbDataobj[ billrefNum ] = innerobj;
					} else {
						if ( tranType == 'Vendor Bill' ) {
							tranAmt = tranAmt;
							//nlapiLogExecution( 'DEBUG', 'tranAmt', JSON.stringify(tranAmt))
						}
						if ( tranType == 'Vendor Bill Credit' ) {
							tranAmt = ( -1 ) * tranAmt;
							//nlapiLogExecution( 'DEBUG', 'tranAmt', JSON.stringify(tranAmt))
						}
						var lines = {}
						lines.servicedate = servicedate
						lines.refNum = refNum
						lines.amount = tranAmt
						lines.customer = customer
						lines.medisup = medisup

						/// v2.2
						lines.tranid = tranId;
						// Updated by Sai 5/23/2022
						lines.intID = intID;
						lines.is_gst = tranId.indexOf( 'GST' ) > -1;
						lines.is_pst = tranId.indexOf( 'PST' ) > -1;

						var existingobj1 = vbDataobj[ billrefNum ][ 'lines' ];
						var existingAmount = vbDataobj[ billrefNum ][ 'tranAmt' ];
						//nlapiLogExecution( 'DEBUG', 'vbDataobj[billrefNum]', JSON.stringify(vbDataobj[billrefNum]))
						existingAmount = parseFloat( existingAmount ) + parseFloat( tranAmt )
						//nlapiLogExecution( 'DEBUG', 'existingAmount', JSON.stringify(existingAmount))
						existingobj1.push( lines )
						vbDataobj[ billrefNum ][ 'lines' ] = existingobj1;
						vbDataobj[ billrefNum ][ 'tranAmt' ] = existingAmount;
					}
					nlapiLogExecution( 'DEBUG', 'vbDataobj', JSON.stringify( vbDataobj ) );
				}

				// Updated by Sai 5/23/2022
				prev_tran_id = intID;
				/// v2.3
				if ( address == '' ) {
					var subsidiary_id = cols.getValue( 'subsidiary', FLD_VVCCP_LINKED_TRANSID );
					if ( subsidiary_id != null && subsidiary_id != '' ) {
						var subsidiary_rec = nlapiLoadRecord( 'subsidiary', subsidiary_id );
						var subsidiary_logo = subsidiary_rec.getFieldValue( 'custrecord_appf_vvccp_logo' );
						var subsidiary_addr = subsidiary_rec.getFieldValue( 'mainaddress_text' );
						var subsidiary_name = subsidiary_rec.getFieldValue( 'name' );
						subsidiary_addr = nlapiEscapeXML( subsidiary_addr );

						//.replace(/\n|\r\n/gim, '<br/>')

						address = subsidiary_addr.replace( subsidiary_name, '' ).trim();

						address = address.replace( /\r\n/g, '<br/>' )
						address = address.replace( /\n/g, '<br/>' )


						logourl = 'https://system.netsuite.com' + nlapiLookupField( 'file', subsidiary_logo, 'url' );
						logourl = nlapiEscapeXML( logourl );

						//added by sravan 5/18/2022
						if ( subsidiary_id == 7 ) {
							logoHeight = '40%';
							logoWidth = '40%';
						}

						nlapiLogExecution( 'DEBUG', 'MJ Address', address );
						nlapiLogExecution( 'DEBUG', 'MJ Logo URL', logourl );
					}
				}
			}
			nlapiLogExecution( 'DEBUG', 'vbDataobj', JSON.stringify( vbDataobj ) )
		}
		var currencyRec = nlapiLoadRecord( 'currency', vcpRec.getFieldValue( FLD_VVCCP_CURRENCY ) )
		var currencyCode = ''
		var currencySymbal = ''
		if ( currencyRec != null && currencyRec != '' ) {
			currencyCode = currencyRec.getFieldValue( 'symbol' )
			currencySymbal = currencyRec.getFieldValue( 'displaysymbol' )
		}

		//added by shravan kumar 12-10-2022
		if ( payee ) {
			if ( payee.slice( 0, 3 ) == 've_' )
				payee = payee.slice( payee.indexOf( ' ' ) + 1 );
		}


		var pdf_code = '<?xml version="1.0"?><!DOCTYPE pdf PUBLIC "-//big.faceless.org//report" "report-1.1.dtd">' +
			'<pdf>' +
			'<head>' +
			'<style type="text/css">' +
			'* {' +
			'font-family: Calibri, Helvetica, sans-serif;' +
			'font-size: 12px;' +
			'}' +
			'.bRight { border-right: 1px solid #333;}' +
			'</style>' +
			'</head>' +
			'<body padding="0.5in 0.5in 0.5in 0.5in" size="Letter" style="border:1px solid; margin:30px; padding:15px;">' +
			'<table width="100%" cellspacing="0" cellpadding="2">' +
			'<tr>' +
			'<td width="100%" align="left" valign="top">' +
			'<img src="' + logourl + '" width="' + logoWidth + '" height="' + logoHeight + '" />' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="100%" align="left" valign="top">' +
			'<b style="font-size: 12px">' + incomingDateChnge1 + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="100%" align="left" valign="top">' +
			'<b style="font-size: 20px;">*** Please note this authorization is valid until: ' + incomingDateString + ' ***</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="100%" align="left" valign="top">' +
			'<table width="100%" cellspacing="2" cellpadding="0">' +
			'<tr>' +
			'<td width="100%" colspan="2">' +
			'<b>Please process payment using the following payment information</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Credit Card Number:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + cardNum + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			"Card Holder's Name:" +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>Dan Dykstra</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Credit Card Type:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + providers + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Expiration Date:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + cardExpDate + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'SEC Code:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + secCode + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Billing Address:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + address + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Main Phone:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>(612) 758 - 8600</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Payment Authorization Number:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + nlapiEscapeXML( vcpRec.getFieldValue( 'name' ) ) + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Payment Authorization Date:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + paymentDateString + '</b>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Amount Authorized:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + currencySymbal + "" + vcpRec.getFieldValue( FLD_VVCCP_MAX_SPEND_AMT ) + "  " + currencyCode + '</b>' +
			'</td>' +
			'</tr>' +

			//added by shravan kumar 12-10-2022
			'<tr>' +
			'<td width="30%" align="left" valign="top">' +
			'Payee:' +
			'</td>' +
			'<td width="70%" align="left" valign="top">' +
			'<b>' + payee + '</b>' +
			'</td>' +
			'</tr>' +

			'</table>' +
			'</td>' +
			'</tr>' +
			'<tr>' +
			'<td width="100%" colspan="2" style="font-size: 5px;">' +
			'&nbsp;' +
			'</td>' +
			'</tr>' +
			'<tr style="background-color: #e3e3e3;">' +
			'<td width="100%" align="left" valign="top">' +
			'<b>The following buys are included in payment authorization: ' + nlapiEscapeXML( vcpRec.getFieldValue( 'name' ) ) + '</b>' +
			'</td>' +
			'</tr>';

		pdf_code += '</table>';


		for ( var inv_prop in vbDataobj ) {
			var inv_line_arr = vbDataobj[ inv_prop ];
			var lineAmtSo = inv_line_arr.tranAmt;
			//lineAmtSo=lineAmtSo.toFixed(2)
			var symbalSo = ''
			if ( lineAmtSo > 0 ) {
				lineAmtSo = parseFloat( lineAmtSo ).toFixed( 2 );
				symbalSo = currencySymbal
			} else {
				lineAmtSo = ( -1 ) * lineAmtSo
				lineAmtSo = parseFloat( lineAmtSo ).toFixed( 2 );
				lineAmtSo = '(' + currencySymbal + '' + lineAmtSo + ')'
			}
			nlapiLogExecution( 'DEBUG', 'inv_line_arr', JSON.stringify( inv_line_arr ) )
			nlapiLogExecution( 'DEBUG', 'inv_prop', JSON.stringify( inv_prop ) )

			var lineCount = inv_line_arr.lines;

			// START OF INVOICE TABLE
			pdf_code += '<table width="100%" cellspacing="0" cellpadding="2" style="table-layout: fixed; margin-bottom: 10px;">' +
				'<tr style="border-bottom: 1px solid #333;">' +
				'<td align="left" valign="top" width="17%">' +
				'&nbsp;' +
				'</td>' +
				'<td align="left" valign="top" width="15%">' +
				'&nbsp;' +
				'</td>' +
				'<td align="right" valign="top" width="18%">' +
				'&nbsp;' +
				'</td>' +
				'<td align="left" valign="top" width="30%">' +
				'&nbsp;' +
				'</td>' +
				'<td align="left" valign="top" width="30%">' +
				'&nbsp;' +
				'</td>' +
				'</tr>' +
				'<tr style="border-bottom: 1px solid #333; border-right: 1px solid #333; border-left: 1px solid #333;">' +
				'<td width="100%" align="left" valign="top" colspan="5" style="border-right: 1px solid #333; border-left: 1px solid #333;">' +
				'<table width="100%" cellspacing="0" cellpadding="0">' +
				'<tr style="background-color: #e3e3e3;">' +
				'<td width="50%" align="left" valign="top" style="padding: 5px 0;">' +
				'<b>Invoice: </b>' +
				'<span style="font-weight: bold; margin-left: 10px;">' + nlapiEscapeXML( inv_prop ) + '</span>' +
				'</td>' +
				'<td width="50%" align="left" valign="top" style="padding: 5px 0;">' +
				'<b>Total: </b>' +
				'<span style="font-weight: bold; margin-left: 10px;">' + symbalSo + '' + lineAmtSo + '</span>' +
				'</td>' +
				'</tr>' +
				'</table>' +
				'</td>' +
				'</tr>' +
				'<tr style="border-bottom: 1px solid #333;">' +
				'<td align="left" valign="top" class="bRight" width="8%" style="border-left: 1px solid #333;">' +
				'<b>Order Reference</b>' +
				'</td>' +
				'<td align="left" valign="top" class="bRight" width="8%">' +
				'<b>Service Date</b>' +
				'</td>' +
				'<td align="right" valign="top" class="bRight" width="14%">' +
				'<b>Amount</b>' +
				'</td>' +
				'<td align="left" valign="top" class="bRight" width="35%">' +
				'<b>Client Name</b>' +
				'</td>' +
				'<td align="left" valign="top" width="35%" style="border-right: 1px solid #333;">' +
				'<b>Media Supplier Name</b>' +
				'</td>' +
				'</tr>';

			///v2.2
			var prev_tran_id = null;

			for ( var m = 0; m < lineCount.length; m++ ) {
				var inv_line_obj_m = lineCount[ m ]
				var lineAmt = inv_line_obj_m.amount
				lineAmt = parseFloat( lineAmt ).toFixed( 2 );
				nlapiLogExecution( 'DEBUG', 'lineAmt', JSON.stringify( lineAmt ) )
				var symbalSo = ''
				if ( lineAmt > 0 ) {
					symbalSo = currencySymbal
				} else {
					lineAmt = ( -1 ) * lineAmt
					lineAmt = parseFloat( lineAmt ).toFixed( 2 );
					lineAmt = '(' + currencySymbal + '' + lineAmt + ')'
				}

				// Updated by Sai 5/23/2022
				if ( prev_tran_id != inv_line_obj_m.intID ) {
					var rowName = inv_line_obj_m.refNum;
					var is_gst_or_pst = false;
					if ( inv_line_obj_m.is_gst ) {
						rowName = 'GST/HST';
						is_gst_or_pst = true;
					}
					else if ( inv_line_obj_m.is_pst ) {
						rowName = 'PST/QST';
						is_gst_or_pst = true;
					}

					//START OF LINE ITEM
					pdf_code += '<tr style="border-bottom: 1px solid #333;">' +
						'<td align="left" valign="top" class="bRight" width="8%" style="border-left: 1px solid #333;">' +
						rowName +
						'</td>' +
						'<td align="left" valign="top" class="bRight" width="8%">' +
						( is_gst_or_pst ? '' : inv_line_obj_m.servicedate ) +
						'</td>' +
						'<td align="right" valign="top" class="bRight" width="14%">' +
						symbalSo + '' + lineAmt +
						'</td>' +
						'<td align="left" valign="top" class="bRight" width="35%">' +
						( is_gst_or_pst ? '' : inv_line_obj_m.customer ) +
						'</td>' +
						'<td align="left" valign="top" width="35%" style="border-right: 1px solid #333;">' +
						( is_gst_or_pst ? '' : inv_line_obj_m.medisup ) +
						'</td>' +
						'</tr>';
					//END OF LINE ITEM;

					// Updated by Sai 5/23/2022
					prev_tran_id = inv_line_obj_m.intID;
				}

			}

			//END OF INVOICE TABLE

			pdf_code += '</table>';
		}

		pdf_code += '</body>' +
			'</pdf>';
		// END OF PDF

		//var fileObj = nlapiCreateFile('TEST_MJ.html', 'HTMLDOC', pdf_code);
		//fileObj.setFolder(12329);
		//nlapiSubmitFile(fileObj);

		var file = nlapiXMLToPDF( pdf_code );
		var fileObj = nlapiCreateFile( 'VVCCP_' + vvccpname + '.pdf', 'PDF', file.getValue() );
		fileObj.setFolder( FOLDER_VVCCP_PDF );
		fileObj.setIsOnline( true ); //added 11/04/2020
		fileid = nlapiSubmitFile( fileObj );
		nlapiLogExecution( 'debug', 'fileid:', fileid );
	}
	return fileid;
}

function getMasterVB_GST_PST ( ref_num ) {
	var gst = null, pst = null;
	var result = {};
	if ( ref_num != null && ref_num != '' ) {
		var rs = nlapiSearchRecord( CUSTOMRECORD_MASTER_VB, null,
			[
				new nlobjSearchFilter( FLD_MASTERVB_NAME, null, 'is', ref_num )
			],
			[
				new nlobjSearchColumn( FLD_MASTERVB_GST_LINK ),
				new nlobjSearchColumn( FLD_MASTERVB_GST_AMOUNT ),
				new nlobjSearchColumn( FLD_MASTERVB_PST_LINK ),
				new nlobjSearchColumn( FLD_MASTERVB_PST_AMOUNT )
			] ) || [];
		if ( rs.length > 0 ) {
			var gst_link = rs[ 0 ].getValue( FLD_MASTERVB_GST_LINK );
			var gst_amount = rs[ 0 ].getValue( FLD_MASTERVB_GST_AMOUNT );
			var pst_link = rs[ 0 ].getValue( FLD_MASTERVB_PST_LINK );
			var pst_amount = rs[ 0 ].getValue( FLD_MASTERVB_PST_AMOUNT );
			if ( ( gst_link != null && gst_link != '' ) || ( pst_link != null && pst_link != '' ) ) {
				if ( gst_link != null && gst_link != '' ) {
					result.gst_amount = gst_amount || 0;
					result.gst_link = gst_link;
				}
				if ( pst_link != null && pst_link != '' ) {
					result.pst_amount = pst_amount || 0;
					result.pst_link = pst_link;
				}
				return result;
			}
		}
	}
	return null;
}

function formate ( yy ) {
	var x = new Date( yy );
	var y = x.getFullYear().toString();
	var m = ( x.getMonth() + 1 ).toString();
	var d = x.getDate().toString();
	( d.length == 1 ) && ( d = '0' + d );
	( m.length == 1 ) && ( m = '0' + m );
	var yyyymmdd = y + m + d;
	return yyyymmdd;
}
