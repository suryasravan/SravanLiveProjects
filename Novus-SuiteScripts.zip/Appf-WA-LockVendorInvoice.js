/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 * 
 * Appficiency Copyright 2020
 * 
 * Description : This custom action locks the Master Vendor Invoice and 
 * Company     : Appficiency Inc.
 * Version		Date			Author			    Description
 * 1.0			12/07/2020		Marlon Villarama	
 */
 
define(
    [
        'N/log',
        'N/search'
    ],
    function (
        LOG,
        SEARCH
    ) {
        
        function onAction(context) {
            var LOG_TITLE = 'onAction';
            LOG.debug({ title: LOG_TITLE, details: 'START' });
            
            var period, periodInfo;
            
            var rec = context.newRecord;
            LOG.debug({ title: LOG_TITLE, details: 'type = ' + rec.type });
            
            if (rec.type == 'customrecord_appf_interim_vb') {
                LOG.debug({ title: LOG_TITLE + ' - periodInfo', details: 'Master Vendor Invoice' });
                period = rec.getValue({ fieldId: 'custrecord_appf_ivb_postingperiod' });
                periodInfo = SEARCH.lookupFields({
                    type: 'accountingperiod',
                    id: period,
                    columns: [ 'aplocked' ]
                });
                LOG.debug({ title: LOG_TITLE + ' - periodInfo', details: JSON.stringify(periodInfo) });
                
                return periodInfo.aplocked == true ? 'T' : 'F';
            }
            else if (rec.type == 'customrecord_appf_interim_vb_line') {
                LOG.debug({ title: LOG_TITLE + ' - periodInfo', details: 'Child Vendor Invoice' });
                var vbheader = rec.getValue({ fieldId: 'custrecord_appf_interimheader' });
                LOG.debug({ title: LOG_TITLE, details: 'vbheader = ' + vbheader });
                
                var srch = SEARCH.create({
                    type: 'customrecord_appf_interim_vb',
                    filters: [{
                        name: 'internalid', operator: 'anyof', values: [ vbheader ]
                    }],
                    columns: [
                        'custrecord_appf_ivb_postingperiod.aplocked'
                    ]
                });
                var results = srch.run().getRange({ start: 0, end: 1000 });
                LOG.debug({ title: LOG_TITLE + ' results', details: JSON.stringify(results) });
                
                if (results.length > 0) {
                    var res = results[0];
                    var periodInfo = res.getValue({ name: 'aplocked', join: 'custrecord_appf_ivb_postingperiod' });
                }
                
                LOG.debug({ title: LOG_TITLE + ' - periodInfo', details: periodInfo });
                return periodInfo == true ? 'T' : 'F';
            }
        }
        
        return {
            onAction: onAction
        };
        
    }
);
