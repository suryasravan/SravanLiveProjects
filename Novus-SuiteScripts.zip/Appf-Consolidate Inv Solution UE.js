/*
* Script Name : Appf-Consolidate Inv Solution UE
* Script Type : User Event
* Event Type  : After Submit
*Description  : This script updates date of invoice linked with CI Record.
* company     : Appficiency.
* */

var FLD_CI_RECORD_DATE='custrecord_appf_ci_date';
var FLD_CI_RECORD_INVOICES='custrecord_appf_ci_invoices';

function onAfterSubmitOnCI(type)
{
if(type != 'delete')
{
  
	    var recordType = nlapiGetRecordType();
		var recordId = nlapiGetRecordId();
		var record = nlapiLoadRecord(recordType, recordId);
		
		var dateCI = record.getFieldValue(FLD_CI_RECORD_DATE);
		var invoices = record.getFieldValues(FLD_CI_RECORD_INVOICES);
    		var hasinvoices = record.getFieldValue(FLD_CI_RECORD_INVOICES);

		if(hasinvoices != null && hasinvoices != '' && dateCI != null && dateCI != '')
		{
			for(var i=0; i<invoices.length; i++)
			{
              try
  {
              nlapiSubmitField('invoice', invoices[i] ,'trandate',dateCI)	
  }
              catch (e) {
			if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
			}
		}

				
    
	
	
   }
}
