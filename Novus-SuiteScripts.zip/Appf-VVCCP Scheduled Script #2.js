	/**
	 * Script Name : Appf-VVCCP Scheduled Script #2
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script creates VVCCP main record and VVCCP sub records for selected transactions and mark status of transactions back to Ready for Processing	
	 *
	 * Company 	 : Appficiency. 
	 */

		var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
		var FLD_APPROVAL_STATUS_APPROVED=2;
		var FLD_APPROVAL_STATUS_OPEN=11;
		var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
		var FLD_APPROVAL_STATUS_REJECTED=3;
		
		var FLD_VVCCP_BATCH_APPROVAL_STATUS = 'custrecord_appf_vvccp_batch_approval';
        var FLD_BATCH_RECS_LINKS = 'custbody_appf_vvccp_batch';
		
		var FLD_VVCCCP_PROCESSING_STATUS = 'custbody_appf_vvccp_status';
		var FLD_VB_LINE_ID = 'custcol_appf_vendorbill_line_id';
		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED=2
		var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978;
		var BILL_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_bill_vvccp';
		var CREDIT_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_cred_vvccp';
		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED_FOR_TRANSACTIONS=2
		
		
		var STATUS_FOR_VVCCP_STATUS_IN_PROGRESS=2
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_SUCCESSFULLY=4
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_WITH_ERRORS=5
		
		//VVCCP Execution Batch
		var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills';	
		var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred';
		var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
		var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
		var FLD_PROCESSED_PERCENT	     			='custrecord_appf_vvccp_log_percent';
		var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by';
		var FLD_VVCCP_LOG_STATUS	     			='custrecord_appf_vvccp_log_status';
		var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file';
		var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file';
		var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log';
		var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';
		var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
		var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
		var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
		var FLD_BILL_DATA_FILES						='custrecord_appf_vvccp_bill_data_files';
		var FLD_CREDIT_DATA_FILE					='custrecord_appf_credit_data_file';
		var FLD_APPROVAL_TRIGGERED					='custrecord_approval_button_triggered';
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9

//VVCCP
var CUSTOM_RECORD_VVCCP='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';	 
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;

var CORPORATE_CREDIT_CARD_VVCCP     ='custentity_appf_vvccp_corporate_cc';

var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var COL_FLD_PENDING_AUTHORIZATION_VVCCP='custcol_appf_pending_auth_vvccp';
var FLD_PENDING_AUTHORIZATION_VVCCP='custbody_appf_pending_auth_vvccp';


var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';

var CUSTOM_RECORD_CORPORATE_CREDIT_CARD_VENDOR_PAYMENT='customrecord_appf_corp_card_table';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias';
var FLD_CORPORATE_CREDIT_CARD_IS_MULTI='custrecord_appf_corp_credit_card_multi';
var SPARAM_DATA_FILE_OF_BILL_AND_CREDITS='custscript_bill_and_billcredit_data_file';
var SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
var SPARAM_VVCCP_SCRIPT_INDEX = 'custscript_vvccp_script_index';

function schedule(type)
{
	
	var context=nlapiGetContext();
	var dataFile=context.getSetting('SCRIPT',SPARAM_DATA_FILE_OF_BILL_AND_CREDITS);
	var vvccpExecutionBatchREcordId=context.getSetting('SCRIPT',SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD);
	var scriptIndex = context.getSetting('SCRIPT',SPARAM_VVCCP_SCRIPT_INDEX);
	if (scriptIndex == null || scriptIndex == '')
		scriptIndex = 0;
	var vvccpRecordLinks=[];
	
	var processingComplete = true; 
	
	if(dataFile !=null && dataFile !='' && vvccpExecutionBatchREcordId != null && vvccpExecutionBatchREcordId != '')
	{
		var fileRec=nlapiLoadFile(dataFile);
		var fileDetails=fileRec.getValue();

		//nlapiLogExecution('debug','fileDetails:',fileDetails);
	
		var mainArr=JSON.parse(fileDetails);
		nlapiLogExecution('debug','mainArr:',JSON.stringify(mainArr));
		
		var vvccpObj={};
		var errorWhileProcessingBatch='';
for(var i = scriptIndex; i < mainArr.length; i++)
		{
			
			var errorLog = '';
			var mainObj = mainArr[i].data;
			var prop = mainArr[i].vendorid;
			var currency = mainArr[i].currency;
			
			try{
			
			var vendorRec=nlapiLoadRecord('vendor',prop);
			var corporateCreditCardVvccp=vendorRec.getFieldValue(CORPORATE_CREDIT_CARD_VVCCP);
			var isMultiUse = null;
			if(corporateCreditCardVvccp !=null && corporateCreditCardVvccp !='')
			{
			isMultiUse =nlapiLookupField(CUSTOM_RECORD_CORPORATE_CREDIT_CARD_VENDOR_PAYMENT ,corporateCreditCardVvccp,FLD_CORPORATE_CREDIT_CARD_IS_MULTI);
			if (isMultiUse == 'T')
				isMultiUse = true;
			else
				isMultiUse = false;
			}
			var sumOfVendorBills=0;
			var sumOfVendorCredits=0;
			var pwpLinks = [];
			var vendorbills=mainObj['vendorbill'];
			var vendorcredits=mainObj['vendorcredit'];
			var totalvvccpProcessed = 0;
			var minimumToSpend=0;
			var maximumToSpend=0;
			
			var uniqueBills = {};
			var uniqueCredits = {};
			
			if(vendorbills !=null && vendorbills !='')
			{
				for(var v=0;v<vendorbills.length;v++)
				{	
					var amountInVendorBill=vendorbills[v].payment;
					var vbid = vendorbills[v].id;
					var vbid_line = vendorbills[v].lineid;
					if (!uniqueBills.hasOwnProperty(vbid))
					{
						uniqueBills[vbid] = [];
					}
					var existingBillLineIds = uniqueBills[vbid];
					existingBillLineIds.push(vbid_line);
					uniqueBills[vbid] = existingBillLineIds;
					
					sumOfVendorBills =parseFloat(sumOfVendorBills)+parseFloat(amountInVendorBill);	
					var pwp = vendorbills[v].pwp;
					pwpLinks.push(pwp);
				}
			}
			
			if(vendorcredits !=null && vendorcredits !='')
			{
				for(var c=0;c<vendorcredits.length;c++)
				{	
					var amountInVendorCredit=vendorcredits[c].payment;
					var vcid = vendorcredits[c].id;
					if (!uniqueCredits.hasOwnProperty(vcid))
					{
						uniqueCredits[vcid] = vcid;
					}
					
					
					sumOfVendorCredits =parseFloat(sumOfVendorCredits)+parseFloat(amountInVendorCredit);
				}
			}	
			if(!isMultiUse)
			minimumToSpend =parseFloat(sumOfVendorBills) - parseFloat(sumOfVendorCredits);
			else
			minimumToSpend = 1;
		
			maximumToSpend = parseFloat(sumOfVendorBills) - parseFloat(sumOfVendorCredits);
			try
			{
				
			var vvccpRecord=nlapiCreateRecord(CUSTOM_RECORD_VVCCP);
			
			var nameForVvccp='PA'+randomString(14);
  var intid = vvccpExecutionBatchREcordId.toString();
  var intidlenforsplit = intid.length*-1;
  //var intidlen=intid.length;
 nameForVvccp = nameForVvccp.slice(0, intidlenforsplit)+''+intid;
 
			vvccpRecord.setFieldValue('name', nameForVvccp);
			if(!isMultiUse)
			vvccpRecord.setFieldValue(FLD_TYPE,VVCCP_CARD_TYPE_SINGLE_USE);
			else
			vvccpRecord.setFieldValue(FLD_TYPE,VVCCP_CARD_TYPE_MULTI_USE);
			vvccpRecord.setFieldValue(FLD_MINIMUM_TO_SPEND,parseFloat(minimumToSpend).toFixed(2));
			nlapiLogExecution('debug','maximumToSpend:',maximumToSpend);
			vvccpRecord.setFieldValue(FLD_MAXIMUM_TO_SPEND,parseFloat(maximumToSpend).toFixed(2));
			vvccpRecord.setFieldValues(FLD_PWP_RECORD_LINKS, pwpLinks);
			vvccpRecord.setFieldValue(FLD_VVCCP_BATCH_LINK,vvccpExecutionBatchREcordId);
			vvccpRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PENDING_BATCH);
              vvccpRecord.setFieldValue(FLD_CURRENCY,currency);
			vvccpRecord.setFieldValue(FLD_VENDOR,prop);
			if (corporateCreditCardVvccp)
			vvccpRecord.setFieldValue(FLD_CORPORATE_CREDIT_CARD,corporateCreditCardVvccp);
			var vvccpRecordId=nlapiSubmitRecord(vvccpRecord,true,true);
			
			nlapiLogExecution('debug','vvccpRecordId:',vvccpRecordId);
			
			
			
		}
		catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+'\nReason: '+e.toString()+'\n\n';
		}
		if (vvccpRecordId)
		{
		if(vendorbills !=null && vendorbills !='')
			{
				for(var v=0;v<vendorbills.length;v++)
				{	
					
					var vendorBillId=vendorbills[v].id;
					var vendorBillLineId=vendorbills[v].lineid;
					var amountInVendorBill=vendorbills[v].payment;
					var transactionType=17;
					var billLinePWP=vendorbills[v].pwp;
					try
					{
						
						var vvccpLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS);
						
						vvccpLinkedTransactionRec.setFieldValue(FLD_VVCCP_LINK, vvccpRecordId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,vendorBillId);
						if(vendorBillLineId !=null && vendorBillLineId !='')
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_ID,vendorBillLineId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,parseFloat(amountInVendorBill).toFixed(2));
						if(billLinePWP !=null && billLinePWP !='')
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_PWP,billLinePWP)
						vvccpLinkedTransactionRec.setFieldValue(FLD_LINKED_TRANSACTION_TYPE,transactionType);
						var vvccpLinkedTransactionRecId=nlapiSubmitRecord(vvccpLinkedTransactionRec,true,true);
						
					}
					catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB Line ID: '+vendorBillLineId+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB Line ID: '+vendorBillLineId+'\nReason: '+e.toString()+'\n\n';
		}
					
				}
				
				for (var vbprop in uniqueBills)
				{

					
					try{
						
						var vbRec = nlapiLoadRecord('vendorbill', vbprop);
					var vb_lines = uniqueBills[vbprop];
					
					
					var vbbatchRecLinks = [];
					vbbatchRecLinks.push(vvccpExecutionBatchREcordId);
					if (vbRec.getFieldValue(FLD_BATCH_RECS_LINKS))
					{
					var existingBatchLinks = vbRec.getFieldValues(FLD_BATCH_RECS_LINKS);
					vbbatchRecLinks = vbbatchRecLinks.concat(existingBatchLinks);
					}
					
					for (var j = 0; j < vb_lines.length; j++)
					{
						
						var matchedline = vbRec.findLineItemValue('item', FLD_VB_LINE_ID, vb_lines[j]);
						if (matchedline > 0)
						{
							vbRec.setLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, matchedline, 'T');
							
						}
					}
					
					vbRec.setFieldValue(FLD_VVCCCP_PROCESSING_STATUS, '3');
					
					vbRec.setFieldValues(FLD_BATCH_RECS_LINKS, vbbatchRecLinks);
					
					nlapiSubmitRecord(vbRec);
					}
					catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB ID: '+vbprop+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB ID: '+vbprop+'\nReason: '+e.toString()+'\n\n';
		}
				}
				
			}
			
			
			if(vendorcredits !=null && vendorcredits !='')
			{
				var sumOfVendorCredits=0;
				for(var c=0;c<vendorcredits.length;c++)
				{
					var transactionType=20;
					var vendorCreditId=vendorcredits[c].id;	
					var amountInVendorCredit=vendorcredits[c].payment;
					try
					{
						var vvccpLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS);
						vvccpLinkedTransactionRec.setFieldValue(FLD_VVCCP_LINK, vvccpRecordId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,vendorCreditId)
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,parseFloat(amountInVendorCredit).toFixed(2));
						vvccpLinkedTransactionRec.setFieldValue(FLD_LINKED_TRANSACTION_TYPE,transactionType);					
						var vvccpLinkedTransactionRecId=nlapiSubmitRecord(vvccpLinkedTransactionRec,true,true);
					}
					catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit: '+vendorCreditId+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit: '+vendorCreditId+'\nReason: '+e.toString()+'\n\n';
		}
				}
				
				
				for (var vcprop in uniqueCredits)
				{
					try{
					var vcRec = nlapiLoadRecord('vendorcredit', vcprop);	
var vcbatchRecLinks = [];
					vcbatchRecLinks.push(vvccpExecutionBatchREcordId);
					if (vcRec.getFieldValue(FLD_BATCH_RECS_LINKS))
					{
					var existingBatchLinks = vcRec.getFieldValues(FLD_BATCH_RECS_LINKS);
					vcbatchRecLinks = vcbatchRecLinks.concat(existingBatchLinks);
					}					
					vcRec.setFieldValue(FLD_VVCCCP_PROCESSING_STATUS, '3');
					vcRec.setFieldValue(FLD_PENDING_AUTHORIZATION_VVCCP, 'T');
					vcRec.setFieldValues(FLD_BATCH_RECS_LINKS, vcbatchRecLinks);
					nlapiSubmitRecord(vcRec);
					}
					catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit ID: '+vcprop+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit ID: '+vcprop+'\nReason: '+e.toString()+'\n\n';
		}
				}
				
			}
		

		
					
				}
			}
			catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+' for vendor id '+prop+' & currency '+currency+'\nReason: '+e.getDetails()+'\n\n';
		else
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+' for vendor id '+prop+' & currency '+currency+'\nReason: '+e.toString()+'\n\n';
		}
				
				
				
			
			var vvccpBatchFields = [FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS,FLD_TOTAL_VVCCP_RECORDS_PROCESSED];
			var vvccpBatchValues = nlapiLookupField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, vvccpBatchFields);
			var toProcess = vvccpBatchValues[FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS];
			var processed = vvccpBatchValues[FLD_TOTAL_VVCCP_RECORDS_PROCESSED];
			if (processed == null || processed == '')
				processed = 0
			processed++;
			
			nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, [FLD_TOTAL_VVCCP_RECORDS_PROCESSED,FLD_ERROR_LOG], [processed,errorLog]);
			
			if (context.getRemainingUsage() <= 1000 && (parseInt(i)+1) < mainArr.length)
				{
					processingComplete = false;
					var sparams = {};
					sparams[SPARAM_DATA_FILE_OF_BILL_AND_CREDITS] = dataFile;
					sparams[SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD] = vvccpExecutionBatchREcordId;
					sparams[SPARAM_VVCCP_SCRIPT_INDEX] = parseInt(i)+1;
					
					nlapiScheduleScript(context.getScriptId(), null, sparams);
				}
		
	}
	
	if (processingComplete)
	{
		
					nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, FLD_APPROVAL_TRIGGERED, 'T');

	}
}	 
	
}	





function randomString(length) {
	var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}
