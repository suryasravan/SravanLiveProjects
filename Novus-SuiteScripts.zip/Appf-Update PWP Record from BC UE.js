/*
*Script Name: Appf-Update PWP Record from BC UE
*Script Type: User Event
*Description: 
*Company 	: Appficiency Inc.

*/

var SCRIPT_SYNC_PT_PTA_GENERIC_SL='customscript_appf_generic_sl_3';
var DEPLOY_SYNC_PT_PTA_GENERIC_SL='customdeploy_appf_generic_sl_3';
var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_BILL_CRED_LINK = 'custrecord_appf_pwp_vendor_credit';
var FLD_PWP_BILL_CRED_AMT = 'custrecord_appf_pwp_ven_credit_amt';
var FLD_PWP_IO_CHECKBOX='custrecord_appf_trigger_ob_integration';


var SCRIPT_UPDATE_PWP_FROM_BC_SC = 'customscript_appf_update_pwp_rec_bc_sc';

var SPARAM_BILL_CRED_ID = 'custscript_appf_bill_credit_id';
var SPARAM_UPDATE_PWP_BILL_CRED_SS = 'custscript_appf_update_pwp_bill_cred_ss';

var FLD_PWP_VEND_STATUS = 'custrecord_appf_pwp_vendor_recon_status';

var FLD_PWP_VEND_BILL_AMT = 'custrecord_appf_pwp_vb_amount';
var FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_bill_line_amt_paid';

var SPARAM_VEND_BILL_ID = 'custscript_appf_vend_bill_id'; 
var SPARAM_UPDATE_PWP_VEND_BILL_SS = 'custscript_appf_update_pwp_vend_bill_ss';


var STATUS_UN_RECONCILED='1'
var STATUS_DISCREPANTS='2'
var STATUS_RECONCILED_PENDING_UPDATES='3'
var STATUS_PENDING_AUTHORIZATION='4'
var STATUS_PAYMENT_PENDING='5'
var STATUS_PAID='6'

var SEND_TO_PAY='1'
var PAYMENT_AMEX='1'
var PAYMENT_MASTERCARDS='3'
var PAYMENT_VISA='9'
var PAYMENT_CHECK='2'
var PAYMENT_WIRE='4'

function updatePWPBCAfterSubmit(type) {
	var context = nlapiGetContext();
	
		var bcSS = context.getSetting('SCRIPT', SPARAM_UPDATE_PWP_BILL_CRED_SS);

	if(type != 'delete'){
		var recType = nlapiGetRecordType();
		var recId = nlapiGetRecordId();
		var billCred = nlapiLoadRecord(recType, recId);
		var count = billCred.getLineItemCount('item');
		if(count <= 60){
			var pwpIds = [];
			for(var i=1; i<=count; i++){
				try{
				var pwpRecId = billCred.getLineItemValue('item', FLD_COL_PWP_RECORD, i);
				var soLineId = billCred.getLineItemValue('item', FLD_COL_SO_LINE_ID, i);
				if(pwpRecId != null && pwpRecId != '' && soLineId != null && soLineId != ''){				
					var isinSS=false;
					
						var billCredIdsArr = [];
						var billCredAmtSum = 0;
						var vbLinePaymentAmtSum = 0;
						var vbAmtSum = 0;
						
					 if( bcSS != null && bcSS != '')
					 {
					var filters = [];
					filters.push(new nlobjSearchFilter(FLD_COL_SO_LINE_ID, null, 'is', soLineId));
					
						
					var bcSearchResults = nlapiSearchRecord(null, bcSS, filters, null);
					if(bcSearchResults != null && bcSearchResults != ''){
						isinSS = true;
					
						
						for(var j=0; j<bcSearchResults.length; j++){
							var result = bcSearchResults[j];
							var billCredId = result.getId();
							var ssCols = result.getAllColumns();
							var billCredAmt = result.getValue(ssCols[0]);
							if(billCredAmt == null || billCredAmt == '')
								billCredAmt  = 0;
							
							billCredIdsArr.push(billCredId);
							billCredAmtSum = parseFloat(billCredAmtSum) + parseFloat(billCredAmt);
						}
						billCredIdsArr = eliminateDuplicates(billCredIdsArr);
						
						
					}
					 }
						var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
												var pwpStatus=pwpRecord.getFieldValue(FLD_PWP_VEND_STATUS);

						pwpRecord.setFieldValues(FLD_PWP_BILL_CRED_LINK, billCredIdsArr);
						if(billCredAmtSum != null && billCredAmtSum != '')
							billCredAmtSum = Number(billCredAmtSum).toFixed(2);
						pwpRecord.setFieldValue(FLD_PWP_BILL_CRED_AMT, billCredAmtSum);
						if(pwpStatus==null || pwpStatus=='' || pwpStatus==STATUS_UN_RECONCILED || pwpStatus==STATUS_DISCREPANTS || pwpStatus==STATUS_RECONCILED_PENDING_UPDATES || pwpStatus==STATUS_PENDING_AUTHORIZATION || pwpStatus==STATUS_PAYMENT_PENDING)
						{
							if (!isinSS)
							{
								
								billCredAmtSum = pwpRecord.getFieldValue(FLD_PWP_BILL_CRED_AMT);
								if (billCredAmtSum == null || billCredAmtSum == '')
									billCredAmtSum = 0;
							}
							
							vbLinePaymentAmtSum = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT);
								if (vbLinePaymentAmtSum == null || vbLinePaymentAmtSum == '')
									vbLinePaymentAmtSum = 0;
								vbAmtSum = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_AMT);
								if (vbAmtSum == null || vbAmtSum == '')
									vbAmtSum = 0;
								
							    if(parseFloat(vbAmtSum)==(parseFloat(vbLinePaymentAmtSum)+parseFloat(billCredAmtSum)))
								{
								pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS,STATUS_PAID);
							    pwpRecord.setFieldValue(FLD_PWP_IO_CHECKBOX, 'T');
								pwpIds.push(pwpRecId);
								}
						}
						
						var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
						nlapiLogExecution('DEBUG', 'pwpId', pwpId);
					
					
				}
			}catch(e){
				if ( e instanceof nlobjError )
					  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
					  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
			}
			
			var slURL =  nlapiResolveURL('SUITELET',SCRIPT_SYNC_PT_PTA_GENERIC_SL,DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external');
	slURL += '&genetricrecid='+pwpIds+'&genetricrectype='+CUSTOM_RECORD_PWP+'&isbackend=T';
    nlapiLogExecution('debug','slURL',slURL)
	try{
					nlapiRequestURL(slURL);
				  }catch (e) {
					  try{
						nlapiRequestURL(slURL);
					  }catch (ex) {
						  try{
						  nlapiRequestURL(slURL);
						  }
						  catch (ep)
						  {
							                    nlapiLogExecution('debug','error triggering Generic SL',ep);

						  }
					  }
				  }
		}
		else{
			var params = {};
			params[SPARAM_BILL_CRED_ID] = recId;
			nlapiScheduleScript(SCRIPT_UPDATE_PWP_FROM_BC_SC, null, params);
		}
	}
	
}

function eliminateDuplicates(arr) 
{
	var i,
	len=arr.length,
	out=[],
	obj={};

	for (i=0;i<len;i++) {
		obj[arr[i]]=0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}