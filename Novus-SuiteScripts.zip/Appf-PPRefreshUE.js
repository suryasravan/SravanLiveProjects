/**
 * Script Name: Appf- EBP Positive Pay UE
 * Script Type: User Event
 * Deployed On: Positive Pay Batch
 * 
 * Version    Date            Author           		Remarks
 * 1.00            									The script creates a button "Refresh" on the Positive Pay Batch record
 *
 * Company 	 : Appficiency. 
 */
var BTN_ROLL_BACK='custpage_refresh';
var FLD_PROCESSING_COMPLETED = 'custrecord_appf_pp_processing_completed';
function beforeLoad(type,form,request)
{
       if(type == 'view')
		{
          var isProcessed=nlapiGetFieldValue(FLD_PROCESSING_COMPLETED);
          if(isProcessed!='T')
            {
		form.addButton(BTN_ROLL_BACK,'Refresh','location.reload(true)');
            }
	    }
}
 