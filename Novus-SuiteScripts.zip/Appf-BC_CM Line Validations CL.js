/**
 * Script name: Appf-BC/CM Line Validations CL
 * Script type: Client
 * Description: This script checks and restricts addition of more than 1 item and expense lines on credit records
 * Company    : Appficiency Inc.
 */

function restrictSecondLineAdditionVL(type)
{
  if (nlapiGetRole() != '3')
      {
	if (type == 'item')
	{
	  var count = nlapiGetLineItemCount('item');
		if (count > 1)
		{
			alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			return false;
		}
		else if (count == 1)
		{
			
			if (nlapiGetCurrentLineItemIndex('item') != 1)
			{
				
				alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			    return false;   
			}
		}
	}
		if (nlapiGetRecordType() == 'vendorcredit' && type == 'expense')
		{
			
			var count = nlapiGetLineItemCount('expense');
		if (count > 1)
		{
			alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			return false;
		}
		else if (count == 1)
		{
			
			if (nlapiGetCurrentLineItemIndex('expense') != 1)
			{
				
				alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			    return false;   
			}
		}
		}
}
return true;
	}
	
	
function restrictSecondLineAdditionSave()
{
  if (nlapiGetRole() != '3')
      {
	
	  var count = nlapiGetLineItemCount('item');
		if (count > 1)
		{
			alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			return false;
		}
		
	
		if (nlapiGetRecordType() == 'vendorcredit')
		{
			
			var expcount = nlapiGetLineItemCount('expense');
		if (expcount > 1)
		{
			alert('You are entering a credit with more than 1 line which will cause your pay when paid validations to fail. Kindly create a separate credit transaction for the second line.');
			return false;
		}
		
		}
      }
return true;
	}

