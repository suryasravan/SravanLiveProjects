/**
*Script Name: Appf-Strata/OCR VB to NS VB SC
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Vendor Bill and pushes the Bill from those messages into netsuite and creates or updates as Vendor Bill records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company : Appficiency Inc.
* Version       Author          Description
* 1.1           MJ De Asis      Added checker for negative values whereas when (VB Amount - VC Amount) > PO Line Amount, should return validation error.
* 1.2           MJ De Asis      Added discard flag and avoid redundant lines
* 1.3           MJ De Asis      Return Status Failed and Error Message "Transaction created against this vendor Invoice already. Hence the record will not be updated.” When Vendor Invoice and Invoice Number already exists and Transaction Created is checked.
* 1.4           MJ De Asis      Add Response Message for VB With Discard Flag
*/

var CUSTOM_RECORD_INTERIM_VB_HEADER = 'customrecord_appf_interim_vb';

var CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS='customrecord_appf_vb_header_masters_in';
var CUSTOMRECORD_FLD_APPF_MASTER_MESSAGE ='custrecord_appf_master_messageid';
var CUSTOMRECORD_FLD_APPF_MASTER_CONTENT_LINK='custrecord_appf_masters_jsoncontent';
var CUSTOMRECORD_FLD_APPF_MASTER_QUEU_NAME ='custrecord_appf_master_queue_name';
var CUSTOMRECORD_FLD_APPF_MASTER_NS_RESPONSE='custrecord_appf_masters_response';
var CUSTOMRECORD_FLD_APPF_MASTER_CLIENTS='custrecord_master_id';
var CUSTOMRECORD_FLD_CONNEX_MASTER_INTEGRATION_STATUS = 'custrecord_master_status';
var CUSTOMRECORD_FLD_CONNEX_MASTER_INTEGRATION_STATUS_RESP = 'custrecord_appf_netsuite_master_response';
var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecordappf_correlation_id';
var CUSTOMRECORD_FLD_CONNEX_NS_RESP = 'custrecord_appf_ns_mercu_orders_response';

var CUSTOMRECORD_APPF_IN_VB='custrecord_appf_ivb_vendor';
var CUSTOMRECORD_APPF_IN_VB_LINE_RECS='recmachcustrecord_appf_interimheader';
var CUSTOMRECORD_FLD_VB_LINE_IO ='custrecord_appf_ivbl_io_num';
var CUSTOMRECORD_FLD_VB_LINE_PO ='custrecord_appf_ivbl_vendor_name';
var CUSTOMRECORD_FLD_VB_LINE_PO_IDS ='custrecord_appf_ivbl_po_link';
var CUSTOMRECORD_FLD_VB_LINES='custrecord_appf_ivbl_po_line_id';
var CUSTOMRECORD_FLD_VB_CURRECNCY='custrecord_appf_ivbl_pocurrency';
var CUSTOMRECORD_FLD_VB_MEDIAS='cseg_appf_media_seg';
var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_contact_jsoncontent';
var CUSTOMRECORD_FLD_APPF_LINK='custrecord_appf_ivbl_pwplink';
/// v1.2
var CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG='custrecord_appf_ivbl_discard';

var CUSTOMRECORD_FLD_POSTING='custrecord_appf_ivb_postingperiod';
var CUSTOMRECORD_FLD_DATE='custrecord_appf_ivb_date';

var FLD_INTERIM_HEADER_VB_CREATE = 'custrecord_appf_ivb_create';
var FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG = 'custrecord_validation_error_details';
var FLD_INTERIM_HEADER_VALIDATION_ERROR_FOUND = 'custrecord_validation_errors_found';

var FLD_INTERIM_CHILD_TRANSACTION_NET_AMOUNT = 'custrecord_appf_ivbl_vendor_net';
var FLD_INTERIM_CHILD_TRANSACTION_VB_LINK = 'custrecord_appf_ivbl_vblink';
var FLD_INTERIM_CHILD_TRANSACTION_VC_LINK = 'custrecord_appf_ivbl_vclink';
var FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE = 'custrecord_interim_child_validat_error';
var FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG = 'custrecord_appf_ivbl_errormessage';

var CUST_FLD_MEDIASUPPS='custcol_appf_publisher';
var CUST_FLD_MEDIASEG='cseg_appf_media_seg';
var CUST_FLD_IO='custcol_appf_ionum';

var CUST_FLD_VENDOR_IDS='custrecord_appf_ivbl_vendor_name';
var CUST_FLD_INV_TRANIDS='custrecord_appf_ivb_transid';

var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
var NS_CLIENT='Novus.Framework.Models.Finance.AccountsPayable.VendorBill.Response.NetSuite.VendorBillResponseMessage';
// var NS_CLIENT='Novus.Framework.Models.Vendor.VendorBillResponse';

var SPARAM_CONNEX_CLIENT='customscript_strata_ocr_vendorbill';
var QUEUE_CONNEX_ORDER_INBOUND = 'novusmedia_vendorbill_in';
var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_buyingsystem_vendorbill';

var emptyUserDefinedNSMessage = 'Data entered for one or more fields is not valid or the field value is not in exact data type as of field type';
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

function createMasterRecs(type)
{
    var context = nlapiGetContext();
  var URL_BASE=''
	var signatures=''

	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
    var POLookupSSParam = context.getSetting('SCRIPT', 'custscript_appf_po_lookup_for_vb_interis');
    nlapiLogExecution('debug','POLookupSSParam',POLookupSSParam);
    var messagesFound=true;
    while (messagesFound == true)
    {
        var usageRemaining = context.getRemainingUsage();
        var idForResponse = '';
        var pareConnex='';
        var d = new Date();
        var UTCDate= d.toISOString();
        var url = URL_BASE+QUEUE_CONNEX_ORDER_INBOUND+'/messages/head?api-version=2015-01';
        var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
        var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
        var mainObj = responseData.getBody()+'';
        nlapiLogExecution('debug','mainObj content',mainObj);
        var CorrelationIdProp='NServiceBus.CorrelationId';
        var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes';
        var CorrelationId=responseData.getHeader(CorrelationIdProp);
        var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)
        var Status='';
        var Status1='';
        var scriptStatus='';
        var fileData='';
        var invReferenceNumber = null;
        var vendorNameinVB = null;
        // START: 1: Get Message and convert to JSON
        if (mainObj==null || mainObj=='')
        {
            messagesFound=false;
            Status='FAILED'+'(Empty Message)';
            scriptStatus='FAILED';
            Status1='FAILED'+'(Empty Message)';
        }
        else
        {
            try
            {
                mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
                mainObj = mainObj.slice(0,mainObj.lastIndexOf("}")); // to remove } if exists as last charecter
                fileData= '{'+mainObj+'}'; //concatinating to make perfect JSON
                mainObj = JSON.parse(fileData);
                Status='SUCCESS';
            }
            catch (e)
            {
                Status='FAILED'+'(Invalid JSON)';
                scriptStatus='FAILED';
                Status1='FAILED'+'(Invalid JSON)';
            }
        }
        // END: 1: Get Message and convert to JSON


        var responseDataAllHeaders=responseData.getAllHeaders();
        var responseData3=responseDataAllHeaders[3];
        var responseDataProp=responseData.getHeader(responseData3);
        var integrationResponseObj={};

        if (responseData.getCode()!='200' && responseData.getCode()!='201')
        {
            /// 2.a: If response code is not success
            /// Create Integration Status Failed
            messagesFound=false;
            if (responseData.getCode()!='204')
            {
                scriptStatus='FAILED';
                var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS);
                integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_MESSAGE,responseDataProp);
                integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_CONTENT_LINK,fileData);
                integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_QUEU_NAME,QUEUE_CONNEX_ORDER_INBOUND);
                integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_MASTER_INTEGRATION_STATUS,'FAILED');
                //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID);
                integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
                //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
                nlapiSubmitRecord(integrationRecord,true,true);
            }
        }
        else
        {
            /// 2.b: If response code is success
            /// Create Novus Master and Child Record if all of the following conditions are met:
            /// a. Vendor Name is populated
            /// b. IO exists
            /// c. PO line exists
            if (mainObj.hasOwnProperty(CUST_FLD_INV_TRANIDS))
            {
                invReferenceNumber = mainObj[CUST_FLD_INV_TRANIDS]
            }
            if (mainObj.hasOwnProperty(CUSTOMRECORD_APPF_IN_VB))
            {
                vendorNameinVB = mainObj[CUSTOMRECORD_APPF_IN_VB];
            }
            var nsOrderRecord='';
            var isNewRecord = true;
            var nsOrderCounts=0;
            var internalId='';
            var isUpdateRecord = true;
            var nsCreationMsg = '';
            var nsOrderRecordID=null;
            try
            {
                var hasVendor = false;
                var hasIO = false;
                if (mainObj.hasOwnProperty(CUSTOMRECORD_APPF_IN_VB))
                {
                    if (mainObj[CUSTOMRECORD_APPF_IN_VB] != null && mainObj[CUSTOMRECORD_APPF_IN_VB] != '')
                        hasVendor = true;
                }
                if (mainObj.hasOwnProperty('lines'))
                {
                    var linectr = 0;
                    for (var l = 0; l < mainObj.lines.length; l++)
                    {
                        if (mainObj.lines[l].hasOwnProperty(CUSTOMRECORD_FLD_VB_LINE_IO))
                        {
                            if (mainObj.lines[l][CUSTOMRECORD_FLD_VB_LINE_IO] != null && mainObj.lines[l][CUSTOMRECORD_FLD_VB_LINE_IO] != '')
                                linectr++;
                        }
                    }
                    if ( mainObj.lines.length == linectr)
                        hasIO = true;
                }

                if (!hasVendor)
                {
                    Status='FAILED'+'(No Vendor Name present)';
                    scriptStatus='FAILED';
                    Status1='FAILED'+'(No Vendor Name present)';
                }
                else if (!hasIO)
                {
                    Status='FAILED'+'( IO# is missing in one or more of the Interim VB Line - Child records )';
                    scriptStatus='FAILED';
                    Status1='FAILED'+'( IO# is missing in one or more of the Interim VB Line - Child records )';
                }
                else if (isLocked(invReferenceNumber, vendorNameinVB)) {
                    Status='FAILED'+'( Transaction created against this vendor Invoice already. Hence the record will not be updated. )';
                    scriptStatus='FAILED';
                    Status1='FAILED'+'( Transaction created against this vendor Invoice already. Hence the record will not be updated. )';
                }
                else
                {
                    if (!mainObj.hasOwnProperty('id'))
                    {
                        nsOrderRecord=nlapiCreateRecord(CUSTOM_RECORD_INTERIM_VB_HEADER, {recordmode:'dynamic'});
                        Status='';
                        //Sravan: Do saved search on Interim header with vendor and inv ref number, if found use load record
                        if(mainObj.hasOwnProperty(CUST_FLD_INV_TRANIDS) && mainObj.hasOwnProperty(CUSTOMRECORD_APPF_IN_VB))
                        {
                            var InvId=mainObj[CUST_FLD_INV_TRANIDS];
                            nlapiLogExecution('debug', 'InvId:', InvId);
                            var ivbId=mainObj[CUSTOMRECORD_APPF_IN_VB];
                            nlapiLogExecution('debug', 'ivbId:', ivbId);
                            nsOrderRecord.setFieldValue('name', InvId+' - '+ivbId);
                            if ((InvId!=null && InvId!='') && (ivbId!=null && ivbId!=''))
                            {
                                var nsfils = [];
                                nsfils.push(new nlobjSearchFilter(CUST_FLD_INV_TRANIDS,null,'is',InvId));
                                nsfils.push(new nlobjSearchFilter('isinactive',null,'is','F'));
                                nsfils.push(new nlobjSearchFilter(CUSTOMRECORD_APPF_IN_VB,null,'anyof',ivbId));

                                var custRecord=nlapiSearchRecord(CUSTOM_RECORD_INTERIM_VB_HEADER, null, nsfils);
                                if (custRecord!=null && custRecord!='')
                                {
                                    nlapiLogExecution('debug','custRecord',custRecord);
                                    if (custRecord.length>0)
                                    {
                                        internalId=custRecord[0].getId();
                                        nlapiLogExecution('debug', 'internalIdin:',internalId);
                                        idForResponse=internalId;
                                        nsOrderRecordID=idForResponse;
                                        nsOrderRecord=nlapiLoadRecord(CUSTOM_RECORD_INTERIM_VB_HEADER,internalId);
                                        nsOrderCounts=nsOrderRecord.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);

                                        if(nsOrderCounts>=1)
                                            isNewRecord=false
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        var internalId=mainObj['id'];
                        nlapiLogExecution('debug', 'internalId',  internalId);
                        if (internalId==null || internalId=='' || internalId=='null')
                        {
                            nsOrderRecord=nlapiCreateRecord(CUSTOM_RECORD_INTERIM_VB_HEADER);
                            Status='';
                            if (mainObj.hasOwnProperty(CUST_FLD_INV_TRANIDS) && mainObj.hasOwnProperty(CUSTOMRECORD_APPF_IN_VB))
                            {
                                var InvId=mainObj[CUST_FLD_INV_TRANIDS];
                                nlapiLogExecution('debug', 'InvId:', InvId);

                                var ivbId=mainObj[CUSTOMRECORD_APPF_IN_VB];
                                nlapiLogExecution('debug', 'ivbId:', ivbId);
                                nsOrderRecord.setFieldValue('name', InvId+' - '+ivbId);
                                if ((InvId!=null && InvId!='') && (ivbId!=null && ivbId!=''))
                                {
                                    var nsfils = [];
                                    nsfils.push(new nlobjSearchFilter(CUST_FLD_INV_TRANIDS,null,'is',InvId));
                                    nsfils.push(new nlobjSearchFilter('isinactive',null,'is','F'));
                                    nsfils.push(new nlobjSearchFilter(CUSTOMRECORD_APPF_IN_VB,null,'anyof',ivbId));

                                    var custRecord=nlapiSearchRecord(CUSTOM_RECORD_INTERIM_VB_HEADER, null, nsfils);
                                    if (custRecord!=null && custRecord!='')
                                    {
                                        nlapiLogExecution('debug','custRecord',custRecord);
                                        if (custRecord.length>0)
                                        {
                                            internalId=custRecord[0].getId();
                                            nlapiLogExecution('debug', 'internalIdin:',internalId);
                                            idForResponse=internalId;
                                            nsOrderRecordID=idForResponse;
                                            nsOrderRecord=nlapiLoadRecord(CUSTOM_RECORD_INTERIM_VB_HEADER,internalId);
                                            nsOrderCounts=nsOrderRecord.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);

                                            if(nsOrderCounts>=1)
                                                isNewRecord=false;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            idForResponse=internalId;
                            nsOrderRecord=nlapiLoadRecord(CUSTOM_RECORD_INTERIM_VB_HEADER,internalId);
                            nsOrderRecordID=idForResponse;
                            nsOrderCounts=nsOrderRecord.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                            if (nsOrderCounts>=1)
                                isNewRecord=false;
                        }
                    }
                }
            }
            catch(e1)
            {
                scriptStatus='FAILED';
                if ( e1 instanceof nlobjError )
                    nsCreationMsg = e1.getCode()+'-'+e1.getDetails();
                else
                    nsCreationMsg = e1.toString();

                if (nsCreationMsg == '' || nsCreationMsg == '-')
                {
                    nsCreationMsg = emptyUserDefinedNSMessage;
                }
                Status1 = nsCreationMsg;
            }

            var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS);
            integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_MESSAGE,responseDataProp);
            integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_CONTENT_LINK,fileData);
            integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MASTER_QUEU_NAME,QUEUE_CONNEX_ORDER_INBOUND);
            integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_MASTER_INTEGRATION_STATUS, Status);
            //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
            integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
            //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
            var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);

            if (Status==null || Status=='' || Status=='SUCCESS')
            {
                try
                {
                    var totalAmount = 0;
                    var hasAddressBook =false;
                    var addressBookObj = {};
                    for (var parentProp in mainObj)
                    {
                        var parentProp=parentProp;
                        var parentProp1='';
                        if (parentProp=='lines')
                        {
                            parentProp1=mainObj[parentProp];
                        }
                        if (parentProp!='lines')
                        {
                            if ((parentProp!=null && parentProp!=''))
                            {
                                if (parentProp!='id' && parentProp!='internalid')
                                    nsOrderRecord.setFieldValue(parentProp,mainObj[parentProp]);

                                var ivbId=mainObj[CUSTOMRECORD_APPF_IN_VB];
                                nlapiLogExecution('debug', 'ivbId:', ivbId);
                                if (ivbId!=null && ivbId!='')
                                {
                                    var paymentType=nlapiLookupField('vendor',ivbId,'custentity_appf_vendorpaymenttype');
                                    nsOrderRecord.setFieldValue('custrecord_appf_ivb_payment_type',paymentType);
                                }

                                if (parentProp==CUSTOMRECORD_FLD_DATE)
                                {
                                    var parentPropDate=mainObj[parentProp];
                                    if (parentPropDate!=null && parentPropDate!='')
                                    {
                                        var parentPropDate1=postingPeriod(parentPropDate);
                                        nsOrderRecord.setFieldValue(CUSTOMRECORD_FLD_POSTING,parentPropDate1);
                                    }
                                }
                            }
                        }
                        else
                        {
                            var isArray=true;
                            if (parentProp1 instanceof Array) {
                                isArray=true;
                            } else {
                                isArray=false
                            }

                            if(isArray)
                            {
                                var parentPropItems=mainObj[parentProp];
                                nlapiLogExecution('debug', 'parentPropItemsmain:', parentPropItems.length);
                                for(var i=0;i<parentPropItems.length;i++)
                                {
                                    /// v1.2
                                    var vbLineIO = null;
                                    vbLineIndex = 0;
                                    if (parentPropItems[i] && parentPropItems[i][CUSTOMRECORD_FLD_VB_LINE_IO]) {
                                        vbLineIO = parentPropItems[i][CUSTOMRECORD_FLD_VB_LINE_IO];
                                        if (vbLineIO != null && vbLineIO != '') {
                                            vbLineIndex = nsOrderRecord.findLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_IO, vbLineIO);
                                        }
                                    }
                                    nlapiLogExecution('DEBUG', 'IO Number v1.2', vbLineIO);
                                    nlapiLogExecution('DEBUG', 'IO Number Index v1.2', vbLineIndex);
                                    if (vbLineIndex > 0) {
                                        nsOrderRecord.selectLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,vbLineIndex);
                                    }
                                    else if (i+1<=nsOrderCounts)
                                    {
                                        nsOrderRecord.selectLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,i+1);
                                        nlapiLogExecution('debug', 'parentPropItems:', 'test');
                                    }
                                    else
                                    {
                                        nsOrderRecord.selectNewLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                                        nlapiLogExecution('debug', 'parentPropItemsselect:', 'testselect');
                                    }

                                    var parentPropItemsProps=parentPropItems[i];
                                    for (var parentPropItem in parentPropItemsProps)
                                    {
                                        nlapiLogExecution('debug','line item Prop',parentPropItem);
                                        nlapiLogExecution('debug','line item Value',parentPropItemsProps[parentPropItem]);
                                        nsOrderRecord.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,parentPropItem,parentPropItemsProps[parentPropItem]);
                                        if (parentPropItem == 'custrecord_appf_ivbl_vendor_net')
                                        {
                                            var amtInChild = parentPropItemsProps[parentPropItem];
                                            if (amtInChild == null || amtInChild == '')
                                                amtInChild = 0;
                                            totalAmount = parseFloat(totalAmount) + parseFloat(Number(amtInChild));
                                        }
                                    }
                                    nsOrderRecord.commitLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                                }
                            }
                        }
                    }
                    nsOrderRecord.setFieldValue('custrecord_appf_ivb_amount', totalAmount);
                    nsOrderRecordID = nlapiSubmitRecord(nsOrderRecord,true,true);
                    nlapiLogExecution('debug', 'record int id submitted', nsOrderRecordID);

                    if (nsOrderRecordID!=null && nsOrderRecordID!='')
                    {
                        var isInActiveRecord=false;
                        if (mainObj.hasOwnProperty('isinactive'))
                        {
                            if (mainObj['isinactive'] == 'T')
                                isInActiveRecord=true;
                        }
                        if (!isInActiveRecord)
                            nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_MASTER_CLIENTS,CUSTOMRECORD_FLD_APPF_MASTER_NS_RESPONSE], [nsOrderRecordID, 'SUCCESS']);
                        var recordId=nsOrderRecordID;
                        var recordType=CUSTOM_RECORD_INTERIM_VB_HEADER;
                        //var estimateRec=nlapiLoadRecord(recordType,recordId)
                        //Validations with PO Loookup starts here ....
                        var payRec=nlapiLoadRecord(recordType,recordId);

                        var validationErrorsFound = 'F';
                        nlapiLogExecution('debug','payRec',payRec);
                        var custVb= payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB);
                        var custVbText= payRec.getFieldText(CUSTOMRECORD_APPF_IN_VB);

                        var payRecFields=payRec.getLineItemCount(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                        /// v1.2
                        var hasDiscardFlag=payRec.findLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG,'T') > 0;
                        var payRecFieldsCount=payRecFields + 0;
                        //var custVb=payRec.getFieldValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUST_FLD_VENDOR_IDS,i);
                        var validationErrors = '';
                        var createVBCount = 0;
                        for (var i=1;i<=payRecFields;i++)
                        {
                            var ios=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_IO,i);
                            var netAmt=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,FLD_INTERIM_CHILD_TRANSACTION_NET_AMOUNT,i);
                            var interimVBLink=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,FLD_INTERIM_CHILD_TRANSACTION_VB_LINK,i);
                            var interimVCLink=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,FLD_INTERIM_CHILD_TRANSACTION_VC_LINK,i);
                            /// v1.2
                            var discardFlag=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_DISCARDFLAG,i);
                            if (discardFlag != 'T') {
                                // var meddias=payRec.getLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_MEDIAS,i)
                                var nsfils = [];
                                nsfils.push(new nlobjSearchFilter(CUST_FLD_IO,null,'is',ios));

                                var poSearchResults=nlapiSearchRecord('transaction', POLookupSSParam, nsfils, null);
                                nlapiLogExecution('debug','poSearchResults',poSearchResults);
                                if (poSearchResults!=null && poSearchResults!='')
                                    nlapiLogExecution('debug','poSearchResultslen',poSearchResults.length);
                                payRec.selectLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, i);
                                if (poSearchResults == null || poSearchResults == '')
                                {
                                    payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '1');
                                    payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> No PO Line Found for IO# "'+ios+'".\n');
                                    validationErrorsFound = 'T';
                                    validationErrors += '---> No PO Line Found for IO# "'+ios+'".\n';
                                }
                                else
                                {
                                    nlapiLogExecution('debug','vendorFromSearchResult','vendorFromSearchResult');
                                    var vendorCnt = 0;
                                    var vbAmt = null;
                                    var vcAmt = null;
                                    var poLineAmt = null;
                                    var pwpLineRecID = null;
                                    var poTransactionLink = null;
                                    var poTransactionLineID = null;
                                    for (var p = 0; p < poSearchResults.length; p++)
                                    {
                                        var vData = poSearchResults[p];
                                        if (vData)
                                        {
                                            var vCols = vData.getAllColumns();
                                            var vendorFromSearchResult = vData.getValue(vCols[1]);
                                            nlapiLogExecution('debug','vendorFromSearchResult',vendorFromSearchResult);
                                            nlapiLogExecution('debug','POLookupSSParam',POLookupSSParam);
                                            if (custVb == vendorFromSearchResult)
                                            {
                                                vendorCnt++;
                                                poTransactionLink = vData.getValue(vCols[0]);
                                                poTransactionLineID = vData.getValue(vCols[2]);
                                                vbAmt = vData.getValue(vCols[3]);
                                                if (vbAmt == null || vbAmt == '')
                                                    vbAmt = 0;
                                                vcAmt = vData.getValue(vCols[6]);
                                                if (vcAmt == null || vcAmt == '')
                                                    vcAmt = 0;
                                                if (netAmt == null || netAmt == '')
                                                    netAmt = 0;
                                                netAmt = parseFloat(netAmt);
                                                poLineAmt = vData.getValue(vCols[4]);
                                                vbAmt = parseFloat(vbAmt);
                                                vcAmt = parseFloat(vcAmt);
                                                poLineAmt = parseFloat(poLineAmt);
                                                pwpLineRecID = vData.getValue(vCols[5]);

                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINE_PO_IDS, poTransactionLink);
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_VB_LINES, poTransactionLineID);
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, CUSTOMRECORD_FLD_APPF_LINK, pwpLineRecID);
                                            }
                                        }
                                    }

                                    if (vendorCnt == 0)
                                    {
                                        payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '2');
                                        payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> No PO Line Found for IO# "'+ios+'" with Vendor Name "'+custVbText+'".\n');
                                        validationErrorsFound = 'T';
                                        validationErrors += '---> No PO Line Found for IO# "'+ios+'" with Vendor Name "'+custVbText+'".\n';
                                    }
                                    else
                                    {
                                        if (vendorCnt != 1)
                                        {
                                            payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '3');
                                            payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> Duplicate PO Lines Found for IO# "'+ios+'" with Vendor Name "'+custVbText+'".\n');
                                            validationErrorsFound = 'T';
                                            validationErrors += '---> Duplicate PO Lines Found for IO# "'+ios+'" with Vendor Name "'+custVbText+'".\n';
                                        }
                                        else
                                        {
                                            if ((netAmt >= 0) && ((vbAmt >= poLineAmt) && (vbAmt > 0 && vcAmt > 0)))
                                            {
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '4');
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> VB Amount is >= PO Line Amount in Linked PWP record for the PO Line Found with IO# "'+ios+'" and Vendor Name "'+custVbText+'".\n');
                                                validationErrorsFound = 'T';
                                                validationErrors += '---> VB Amount is >= PO Line Amount in Linked PWP record for the PO Line Found with IO# "'+ios+'" and Vendor Name "'+custVbText+'".\n'
                                            }
                                            else if ((netAmt < 0) && ((vbAmt - vcAmt) <= poLineAmt)) {
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '4');
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '---> Incorrect overbill scenario for vendor credit in Linked PWP record for the PO Line Found with IO# "'+ios+'" and Vendor Name "'+custVbText+'".\n');
                                                validationErrorsFound = 'T';
                                                validationErrors += '---> Incorrect overbill scenario for vendor credit in Linked PWP record for the PO Line Found with IO# "'+ios+'" and Vendor Name "'+custVbText+'".\n'
                                            }
                                            else
                                            {
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_TYPE, '');
                                                payRec.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS, FLD_INTERIM_CHILD_VALIDATION_ERROR_MSG, '');

                                                if (netAmt != null && netAmt != '')
                                                {
                                                    if ((netAmt >= 0 && (interimVBLink == null || interimVBLink == '')) || (netAmt < 0 && (interimVCLink == null || interimVCLink == '')))
                                                        createVBCount++;
                                                }
                                            }
                                        }
                                    }
                                }
                                payRec.commitLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS);
                            }
                            else {
                                if (hasDiscardFlag) {
                                    payRecFieldsCount--;
                                }
                            }
                        }
                        payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_FOUND, validationErrorsFound);
                        if (validationErrorsFound == 'T')
                        {
                            payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG, validationErrors);
                            scriptStatus='FAILED';
                            Status1 = validationErrors;
                        }
                        else
                        {
                            payRec.setFieldValue(FLD_INTERIM_HEADER_VALIDATION_ERROR_MSG, '');
                            scriptStatus='SUCCESS';
                            Status1 = '';

                            /// v1.4
                            if (hasDiscardFlag) {
                                Status1 = 'This Master Invoice '+ invReferenceNumber +' has been marked for delete.';
                            }

                        }
                        if (createVBCount == payRecFieldsCount)
                        {
                            payRec.setFieldValue(FLD_INTERIM_HEADER_VB_CREATE, 'T');
                        }
                        else
                            payRec.setFieldValue(FLD_INTERIM_HEADER_VB_CREATE, 'F');
                        nlapiSubmitRecord(payRec, true, true);

                        //Validations with PO Loookup ends here ....
                        //Sravan: Now update Integration Log record with relevant status and send the response as below
                        /*
                        Internal id of Interim Header - Master
                        Inv Reference Num of Interim Header - Master
                        Vendor Name of Interim Header - Master
                        IntegrationResponseStatus = (validationErrorsFound == 'T')?'FAILED':'SUCCESS'
                        IntegrationResponseMessage = {validationErrors}
                        */
                    }
                    else
                    {
                        nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_MASTER_NS_RESPONSE], [scriptStatus+":"+nsCreationMsg]);
                    }
                }
                catch(e1)
                {
                    scriptStatus='FAILED';
                    if ( e1 instanceof nlobjError )
                        nsCreationMsg = e1.getCode()+'-'+e1.getDetails();
                    else
                        nsCreationMsg = e1.toString();

                    if (nsCreationMsg == '' || nsCreationMsg == '-')
                    {
                        nsCreationMsg = emptyUserDefinedNSMessage;
                    }
                    Status1 = nsCreationMsg;
                }
            }
        }

        if (scriptStatus!=null && scriptStatus!='' && messagesFound==true)
        {
            if (nsOrderRecordID==null ||nsOrderRecordID=='')
                nsOrderRecordID='';
            integrationResponseObj.NetsuiteId=nsOrderRecordID;

            if (vendorNameinVB == null || vendorNameinVB == '')
                vendorNameinVB = '';
            integrationResponseObj.VendorID=vendorNameinVB;

            if(invReferenceNumber == null || invReferenceNumber == '')
                invReferenceNumber = '';
            integrationResponseObj.InvoiceReferenceNumber=invReferenceNumber;

            if (scriptStatus!=null && scriptStatus!='')
                integrationResponseObj.IntegrationResponseStatus=scriptStatus;
			else
				integrationResponseObj.IntegrationResponseStatus=(validationErrorsFound == 'T')?'FAILED':'SUCCESS';

            integrationResponseObj.IntegrationResponseMessage=Status1;
            nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_MASTER_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_MASTER_INTEGRATION_STATUS_RESP], [JSON.stringify(integrationResponseObj)]);
            var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
            var body = JSON.stringify(integrationResponseObj);
            var HEADERS = {"Authorization":signatures};
            //HEADERS.scriptStatus=scriptStatus
            if (CorrelationId==null || CorrelationId=='')
                CorrelationId='';
                HEADERS['NServiceBus.CorrelationId']=CorrelationId;
                HEADERS['NServiceBus.EnclosedMessageTypes']=NS_CLIENT;
                var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');
                nlapiLogExecution('debug', 'responseData.getCode()!:', responseData.getCode());
            }

        if (usageRemaining<=1000)
        {
            nlapiScheduleScript(SPARAM_CONNEX_CLIENT,null);
        }
    }
}

function postingPeriod(date)
{
    date=new Date(date);
    var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
    var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    var Dt1 = nlapiDateToString(startDate);
    var Dt2 = nlapiDateToString(endDate);
    var filters = new Array();
    filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
    filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
    filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
    filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
	//filters[4] = new nlobjSearchFilter('closed',null,'is','F');

    var columns = new Array();
    columns[0] = new nlobjSearchColumn('internalid');
    columns[1] = new nlobjSearchColumn('closed');
    var searchAcctPeriods = nlapiSearchRecord('accountingperiod', null, filters, columns);
    var periodId='';
    if (searchAcctPeriods!=null && searchAcctPeriods!='')
    {
        var isclosedperiod = searchAcctPeriods[0].getValue('closed');
        if (isclosedperiod!='T')
        {
            periodId=searchAcctPeriods[0].getValue('internalid');
        }
        else
        {
            var filters1 = new Array();
            filters1[0] = new nlobjSearchFilter('startdate', null, 'onorafter', Dt1);
            filters1[1] = new nlobjSearchFilter('enddate', null, 'onorafter', Dt2);
            filters1[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
            filters1[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
            filters1[4] = new nlobjSearchFilter('closed',null,'is','F');

            var columns1 = new Array();
            columns1[0] = new nlobjSearchColumn('internalid');
            columns1[1] = new nlobjSearchColumn('enddate').setSort();
            var searchAcctPeriods1 = nlapiSearchRecord('accountingperiod', null, filters1, columns1);
            if (searchAcctPeriods1!=null && searchAcctPeriods1!='')
            {
                periodId=searchAcctPeriods1[0].getValue('internalid');
            }
        }
    }
    return periodId;
}

function getAllSearchResults(record_type, filters, columns)
{
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);

    var searchRan = search.runSearch()
    , bolStop = false
    , intMaxReg = 1000
    , intMinReg = 0
    , result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
    {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000)
        {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array)
{
    return target.concat(array); // TODO: use _.union
}

/// v1.3
function isLocked(inv_ref_number, vendor_id) {
    if (!isNullOrEmpty(inv_ref_number) && !isNullOrEmpty(vendor_id)) {
        var rs = nlapiSearchRecord(CUSTOM_RECORD_INTERIM_VB_HEADER, null,
                    [
                        new nlobjSearchFilter('internalidnumber', CUSTOMRECORD_APPF_IN_VB, 'equalto', Number(vendor_id)),
                        new nlobjSearchFilter(CUST_FLD_INV_TRANIDS, null, 'is', inv_ref_number),
                        new nlobjSearchFilter('custrecord_appf_transactions_created', null, 'is', 'T')
                    ], []) || [];
        return (rs.length > 0);
    }
    return false;
}

function isNullOrEmpty(data) {
    return (data == null || data == '');
}
