/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */

/*
* Script Name : Appf-Print EBP Payment UE
* Script Type : UserEventScript
* Description : This script will display "Print" button on Payment record that generates PDF of EBP details of transactions grouped by tranid for ACH and Wire
* Script Owner: Shravan
* Date        : 18-07-2022
* Company     : Appf
*/

const SPARAM_SUITELET_ID = 'customscript_appf_print_vbp_sl';
const SPARAM_SUITELET_DEPLOY_ID = 'customdeploy_appf_print_vbp_sl';

const CUST_FLD_VENDOR_PAYMENT_TYPE = "custbody_appf_vendor_payment_type";

const PAYMENT_TYPE_ACH = 4;
const PAYMENT_TYPE_WIRE = 5;

define( [ 'N/search', 'N/record', 'N/url', 'N/https' ], ( search, record, url, https ) => {
     const beforeLoad = ( context ) => {
          if ( context.type == context.UserEventType.VIEW ) {
               try {
                    let venderBP = context.newRecord;
                    let venderBPID = venderBP.id;
                    let paymentType = venderBP.getValue( { fieldId: CUST_FLD_VENDOR_PAYMENT_TYPE } );
                    var pdfSuiteletUrl = url.resolveScript( {
                         scriptId: SPARAM_SUITELET_ID,
                         deploymentId: SPARAM_SUITELET_DEPLOY_ID,
                         returnExternalUrl: false
                    } );
                    pdfSuiteletUrl = pdfSuiteletUrl + '&vbpId=' + venderBPID;
                    if ( paymentType == PAYMENT_TYPE_ACH || paymentType == PAYMENT_TYPE_WIRE ) {
                         context.form.addButton( {
                              id: 'custpage_print_pdf',
                              label: 'Print',
                              functionName: 'window.open(\'' + pdfSuiteletUrl + '\',\'_blank\' )'
                         } );
                    }
               }
               catch ( e ) {
                    log.debug( 'failed', e );
               }

          }
     }


     return {
          beforeLoad: beforeLoad,
     }
} );