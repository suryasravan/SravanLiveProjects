/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/record','N/search','N/runtime','N/format'],

function(record,search,runtime,format) {
	var SCRIPTFLD_SEARCH_PARAMETER = 'custscript_appf_cutover_inv_search2';
	var REC_TYPE_APPF_CUTOVER_CREDIT_INV = 'customrecordappf_cutover_invoice';
	var REC_TYPE_APPF_CI_RECORD = 'customrecord_appf_ci_record';

	var FLD_INV_CUTOVER_AR_RECORD = 'custbody_appf_cutover_ar_record';
	var FLD_INV_IS_CUTOVER_TRANSACTION = 'custbody_appf_cutover_transaction';

	var FLD_CUSTOMREC_CUTOVER_INVOICE_LINK = 'custrecord_appf_cutover_invoicelink';
	var FLD_CUSTOMREC_CUTOVER_INVOICE_CREATED = 'custrecord_appf_cutover_invcreated';
	var FLD_CUSTOMREC_CUTOVER_STATUS = 'custrecord_appf_cutover_scriptstatus';
	var FLD_CUSTOMREC_CUTOVER_STATUS_LOG = 'custrecord_appf_cutover_scriptlog';
	var FLD_CUSTOMREC_CUTOVER_SO_LINE_ID = 'custrecord_appf_cutover_so_line_id';
	var FLD_CUSTOMREC_CUTOVER_CI_RECORD = 'custrecord_appf_cutover_ci_link';
	var FLD_CUSTOMREC_CUTOVER_CI_DISCOUNT   = 'custrecord_appf_cutover_discount';

	var FLD_CUSTOMREC_CI_RECORD_INVOICES = 'custrecord_appf_ci_invoices';

	var FLD_TRAN_LINE_SO_LINE_ID = 'custcol_appf_line_id';
	var FLD_TRAN_LINE_CUTOVER_REC_ID = 'custcol_appf_cutover_record';
	var FLD_TRAN_LINE_CI_REC_LINK = 'custcol_appf_ci_record';
	var FLD_TRAN_LINE_CI_REC_STATUS = 'custcol_appf_ci_status';

	var SCRIPT_STATUS_INPROGRESS = 2;
	var SCRIPT_STATUS_COMPLETED = 3;
	var SCRIPT_STATUS_FAILED = 4;
	var invApprovedSatus = 2;
	var VAL_DISC_ITEM = 80;
	
	
	function searchMoreRecords(recordType, searchID, filters, columns)
	{
		if(searchID != null){
			var searchObj = search.load({
				id: searchID
			});
		}else{
			var searchObj = search.create({
				id: searchID,
				type: recordType,
				filters: filters,
				columns: columns
			});
		}

		var resultSet = searchObj.run();
		var results = [];
		var start = 0;
		var end = 1000;
		do{
			var result = resultSet.getRange(start,end);
			results = results.concat(result);
			start += 1000;
			end += 1000;
			
		}while(result.length == 1000);
		
		return results;
	}
	
    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
    	var getSavedSearchId = runtime.getCurrentScript().getParameter({name: SCRIPTFLD_SEARCH_PARAMETER});
    	//Code to load the saved search
    	var loadsearch = searchMoreRecords(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getSavedSearchId, null, null);
    	log.debug('loadsearch',loadsearch);
    	
    	
    	//group by sales order
    	var oGroupedCutOver = new Object();
    	 for (var s = nIndex; s < searchResult.length; s++) {
             var getCutoverRecId = searchResult[s].id;
             var getDate = searchResult[s].getValue({name: 'custrecord_appf_cutover_date'});
             var getDueDate = searchResult[s].getValue({name: 'custrecord_appf_cutover_duedate'});
             var getTotalAmount = searchResult[s].getValue({name: 'custrecord_appf_cutover_amount'}); 
             var getMemoLine = searchResult[s].getValue({name: 'custrecord_appf_cutover_memoline'});
             var getMemoMain = searchResult[s].getValue({name: 'custrecord_appf_cutover_memomain'});
             var getSOID = searchResult[s].getValue({name: 'custrecord_appf_cutover_salesorder'});   
             var getSOLineID = searchResult[s].getValue({name: 'custrecord_appf_cutover_so_line_id'});
             var getCIRecord = searchResult[s].getValue({name: 'custrecord_appf_cutover_ci_link'});
             var getCIStatus = searchResult[s].getValue({name: 'custrecord_appf_ci_status'});   
             var getDiscountRate = searchResult[s].getValue({name: 'custrecord_appf_cutover_discount'});
             var getCreatedInvoice = searchResult[s].getValue({name: 'custrecord_appf_cutover_invcreated'});
             var getInvoiceLinked = searchResult[s].getValue({name: 'custrecord_appf_cutover_invoicelink'});   
             
             var oCols = new Object();
             oCols['getSOID'] = getSOID;
             oCols['getCutoverRecId'] = getCutoverRecId;
             oCols['getDate'] = getDate;
             oCols['getDueDate'] = getDueDate;
             oCols['getTotalAmount'] = getTotalAmount;
             oCols['getMemoLine'] = getMemoLine;
             oCols['getMemoMain'] = getMemoMain;
             oCols['getSOID'] = getSOID;
             oCols['getSOLineID'] = getSOLineID;
             oCols['getCIRecord'] = getCIRecord;
             oCols['getCIStatus'] = getCIStatus;
             oCols['getDiscountRate'] = getDiscountRate;
             oCols['getCreatedInvoice'] = getCreatedInvoice;
             oCols['getInvoiceLinked'] = getInvoiceLinked;

             var aDataDetails = oGroupedCutOver[getSOID] || new Array();
         	 aDataDetails.push(oCols);
         	 oGroupedCutOver[getSOID] = aDataDetails;
             
    	 }
    	
    	 //loop contents
         for(var idKey in oGroupedCutOver){
     	    var aRows = oGroupedCutOver[idKey];
     	    for(var j = 0; j < aRows.length; j++){
     	    	var oCol = aRows[j];
     	    	log.debug('SO ID = ' + oCol['getSOID']);
     	    	log.debug('getCutoverRecId = ' + oCol['getCutoverRecId']);
     	    	log.debug('getSOLineID = ' + oCol['getSOLineID']);
     	    }


         }
    	 
    	 
    	 //send contents
    	 return oGroupedCutOver;
    }

    /**
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    
    function reduce(context){
    	var rowJson = JSON.parse(context.values[0]);
    	log.debug('rowJson', rowJson);
    	log.debug('key', rowJson.id);
    	
    	
    	
    }
    function reduce2(context) {
    	var rowJson = JSON.parse(context.values[0]);

    	log.debug('key', rowJson.id);
    	var columnError = '';
    	var discItem = VAL_DISC_ITEM;
    	
    	try{
    		try{
    			var getCutoverRecId = rowJson.id;
    			var getDate = rowJson.values["custrecord_appf_cutover_date"];
    			var getDueDate = rowJson.values["custrecord_appf_cutover_duedate"];
    			var getTotalAmount = rowJson.values["custrecord_appf_cutover_amount"];
    			var getMemoLine = rowJson.values["custrecord_appf_cutover_memoline"];
    			var getMemoMain = rowJson.values["custrecord_appf_cutover_memomain"];
    			var getSOID = rowJson.values["custrecord_appf_cutover_salesorder"][0].value;
    			var getSOLineID = rowJson.values["custrecord_appf_cutover_so_line_id"];
    			var getCIRecord = rowJson.values["custrecord_appf_cutover_ci_link"][0].value;
    			var getCIStatus = rowJson.values["custrecord_appf_ci_status"][0].value;
				var getDiscountRate = rowJson.values["custrecord_appf_cutover_discount"];  //getCurrentObj.getValue(FLD_CUSTOMREC_CUTOVER_CI_DISCOUNT);
				var getCreatedInvoice = rowJson.values["custrecord_appf_cutover_invcreated"];  //getCurrentObj.getValue(FLD_CUSTOMREC_CUTOVER_INVOICE_CREATED);
				var getInvoiceLinked = rowJson.values["custrecord_appf_cutover_invoicelink"][0].value; //getCurrentObj.getValue(FLD_CUSTOMREC_CUTOVER_INVOICE_LINK);
    			
    		}catch(e2){
    			columnError = '\nEmpty reference value to saved search column. Make sure to check the saved search for the script deployment or contact administrator';
    		}
    		log.debug('getCutoverRecId', getCutoverRecId + ' getSOID='+getSOID + ' getSOLineID='+getSOLineID + 'getDiscountRate='+getDiscountRate + 'getInvoiceLinked='+getInvoiceLinked + 'getCreatedInvoice='+getCreatedInvoice);
    		if((getCreatedInvoice != true && getCreatedInvoice != 'T') && (getInvoiceLinked == null || getInvoiceLinked == '') ){
    			record.submitFields({
    			    type: REC_TYPE_APPF_CUTOVER_CREDIT_INV,
    			    id: getCutoverRecId,
    			    values: {
    			    	'custrecord_appf_cutover_scriptstatus': SCRIPT_STATUS_INPROGRESS
    			    }
    			});
    			//Transform Sales Order to Invoice.

    			var transformRecord = record.transform({
    			    fromType: record.Type.SALES_ORDER,
    			    fromId: getSOID,
    			    toType: record.Type.INVOICE,
    			    isDynamic: true
    			});
    			//log.debug('getDate',getDate);
    			getDate = format.parse({
    				  value: getDate,
    				  type: format.Type.DATE
    				});
    			transformRecord.setValue({fieldId: 'trandate',value: getDate});
    			//log.debug('getDueDate',getDueDate);
    			getDueDate = format.parse({
    				  value: getDueDate,
    				  type: format.Type.DATE
    				});
    			transformRecord.setValue({fieldId: 'duedate',value: getDueDate});
    			transformRecord.setValue({fieldId: 'memo',value: getMemoMain});
    			
				//set getDiscountRate
    			//log.debug('getDiscountRate', getDiscountRate + ' parseFloat(getDiscountRate)='+parseFloat(getDiscountRate));
				
				if(discItem != null && discItem != '' && (getDiscountRate != null && getDiscountRate != '') && parseFloat(getDiscountRate) > 0){
					transformRecord.setValue({fieldId: 'discountitem',value: discItem});
					getDiscountRate = parseFloat(getDiscountRate).toFixed(2)*-1;
					var formattedDiscountRate = getDiscountRate+'%';
					transformRecord.setValue({fieldId: 'discountrate',value: formattedDiscountRate});
				}
    			
    			
    			
    			
    			transformRecord.setValue({fieldId: 'approvalstatus',value: invApprovedSatus});
    			transformRecord.setValue({fieldId: FLD_INV_CUTOVER_AR_RECORD,value: getCutoverRecId});
    			transformRecord.setValue({fieldId: FLD_INV_IS_CUTOVER_TRANSACTION,value: true});
    			
      			var getLineCount = transformRecord.getLineCount({sublistId: 'item'});
    			for(var i = getLineCount-1; i >= 0; i--) {		
    				var getLineId = transformRecord.getSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_SO_LINE_ID,line: i});
    				
    				//remove any space from string
    				getLineId =  getLineId.replace(/\s+/g,'');;
    				getSOLineID = getSOLineID.replace(/\s+/g,'');;
    				
    				if(getLineId != getSOLineID) {
    					transformRecord.removeLine({sublistId: 'item',line: i});
    				}
    				else if(getLineId == getSOLineID) {
    					log.debug('match='+getLineId + ':'+getSOLineID );
    					
    					transformRecord.selectLine({sublistId: 'item',line: i});
    					transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'memo',value: getMemoLine});
    					
    					transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'quantity',value: getTotalAmount});

    					transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CUTOVER_REC_ID,value: getCutoverRecId});

    					transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_LINK,value: getCIRecord});

    					transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_STATUS,value: getCIStatus});

    					transformRecord.commitLine({sublistId: 'item'});
    					
    					//static
    					//transformRecord.selectLine({sublistId: 'item',line: i});
    					//transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'memo',value: getMemoLine});
    					/*transformRecord.setSublistValue({sublistId: 'item',fieldId: 'memo',line: i,value: getMemoLine});
    					//transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: 'quantity',value: getTotalAmount});
    					transformRecord.setSublistValue({sublistId: 'item',fieldId: 'quantity',line: i,value: getTotalAmount});
    					//transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CUTOVER_REC_ID,value: getCutoverRecId});
    					transformRecord.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CUTOVER_REC_ID,line: i,value: getCutoverRecId});
    					//transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_LINK,value: getCIRecord});
    					transformRecord.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_LINK,line: i,value: getCIRecord});
    					//transformRecord.setCurrentSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_STATUS,value: getCIStatus});
    					transformRecord.setSublistValue({sublistId: 'item',fieldId: FLD_TRAN_LINE_CI_REC_STATUS,line: i,value: getCIStatus});
    					//transformRecord.commitLine({sublistId: 'item'});
    					*/
    					
    				}
    				
    			}

    			var submitRecord = transformRecord.save();
    			/*var submitRecord = transformRecord.save({
    			    enableSourcing: false,
    			    ignoreMandatoryFields: true
    			});*/
    			log.debug('submitRecord invoice =',submitRecord  + ' from SO = ' + getSOID + '  line id = ' + getSOLineID );
    			
    			if(submitRecord) {
    				record.submitFields({
    				    type: REC_TYPE_APPF_CUTOVER_CREDIT_INV,
    				    id: getCutoverRecId,
    				    values: {
    				    	'custrecord_appf_cutover_invoicelink': submitRecord,
    				    	'custrecord_appf_cutover_invcreated': true,
    				    	'custrecord_appf_cutover_scriptstatus': SCRIPT_STATUS_COMPLETED,
    				    	'custrecord_appf_cutover_scriptlog': ''
    				    }
    				});
    				
    			}
    		}
    		
    		

    		
    	}catch(error){
    		log.debug('error error.message' + error.message);
    		var sError = '';
    		if( error.message == 'You must enter at least one line item for this transaction.'){
    			log.debug('no line');
    			sError = error.message + '\n This may be caused by one of the following: \n 1. This cutover record maybe a duplicate for the same sales order line ID.'
    			sError += '\n 2. This cutover record matching sales order line ID client gross allocation is 0,therefore cannot bill/invoice this line.'
    		}
    		
			record.submitFields({
			    type: REC_TYPE_APPF_CUTOVER_CREDIT_INV,
			    id: getCutoverRecId,
			    values: {
			    	'custrecord_appf_cutover_scriptstatus': SCRIPT_STATUS_FAILED,
			    	'custrecord_appf_cutover_scriptlog': sError +''+columnError
			    }
			});
    	}
    	


    }

    /**
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
   /* function reduce(context) {

    }*/


    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {

    }

    return {
        getInputData: getInputData,
        /*map: map,*/
        reduce: reduce,
        summarize: summarize
    };
    
});
