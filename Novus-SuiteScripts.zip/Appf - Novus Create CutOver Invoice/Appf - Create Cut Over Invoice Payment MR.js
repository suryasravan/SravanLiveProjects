/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 *
 * Appficiency Copyright 2020
 *
 * Description: Creates invoice/trasform matching invoice into payment.
 *
 * Author: Roach
 * Date: Oct 20, 2020
 *
 */
define(['N/record','N/search','N/runtime','N/format'],

function(record,search,runtime,format) {
	var SCRIPTFLD_SEARCH_PARAMETER = 'custscript_appf_cutover_payment_search';
	var SCRIPTFLD_ACCOUNT_ID = 'custscript_cutover_account_id';
	var REC_TYPE_APPF_CUTOVER_CREDIT_INV = 'customrecordappf_cutover_invoice';
	var FLD_INV_CUTOVER_AR_RECORD = 'custbody_appf_cutover_ar_record';
	var FLD_INV_IS_CUTOVER_TRANSACTION = 'custbody_appf_cutover_transaction';
	var FLD_CUSTOMREC_CUTOVER_PAYMENT_LINK = 'custrecord_appf_cutover_paymentlink';
	var FLD_CUSTOMREC_CUTOVER_PAYMENT_CREATED = 'custrecord_appf_cutover_pmtcreated';
	var FLD_CUSTOMREC_CUTOVER_STATUS = 'custrecord_appf_cutover_scriptstatus';
	var FLD_CUSTOMREC_CUTOVER_STATUS_LOG = 'custrecord_appf_cutover_scriptlog_pmt';
	var FLD_INV_COL_AMOUNT_PAID = 'custcol_appf_pwp_inv_line_amt_paid';
	var FLD_TRAN_LINE_SO_LINE_ID = 'custcol_appf_line_id';
	var FLD_TRAN_LINE_CUTOVER_REC_ID = 'custcol_appf_cutover_record';
	var FLD_TRAN_LINE_CI_REC_LINK = 'custcol_appf_ci_record';
	var FLD_TRAN_LINE_CI_REC_STATUS = 'custcol_appf_ci_status';
	var SCRIPT_STATUS_INPROGRESS = 2;
	var SCRIPT_STATUS_COMPLETED = 3;
	var SCRIPT_STATUS_FAILED = 4;


	function searchMoreRecords(recordType, searchID, filters, columns)
	{
		if(searchID != null){
			var searchObj = search.load({
				id: searchID
			});
		}else{
			var searchObj = search.create({
				id: searchID,
				type: recordType,
				filters: filters,
				columns: columns
			});
		}

		var resultSet = searchObj.run();
		var results = [];
		var start = 0;
		var end = 1000;
		do{
			var result = resultSet.getRange(start,end);
			results = results.concat(result);
			start += 1000;
			end += 1000;

		}while(result.length == 1000);

		return results;
	}

    /**
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {
    	var getSavedSearchId = runtime.getCurrentScript().getParameter({name: SCRIPTFLD_SEARCH_PARAMETER});
    	//Code to load the saved search
    	var searchResult = searchMoreRecords(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getSavedSearchId, null, null);
    	log.debug('searchResult',searchResult);


    	//group by sales order
    	var oGroupedCutOver = new Object();
    	 for (var s = 0; s < searchResult.length; s++) {
			 var getCutoverRecId = searchResult[s].id;
			 var getSOID = searchResult[s].getValue({name: 'custrecord_appf_cutover_salesorder'});
             var getSOLineID = searchResult[s].getValue({name: 'custrecord_appf_cutover_so_line_id'});
			 var getDate = searchResult[s].getValue({name: 'custrecord_appf_cutover_date'});
			 var getPaymentRef = searchResult[s].getValue({name: 'custrecord_appf_cutover_paymentref'});
			 var getAmountPaid = searchResult[s].getValue({name: 'custrecord_appf_payment_amount'});
			 var getInvID = searchResult[s].getValue({name: 'custrecord_appf_cutover_invoicelink'});
			 var getPaymentAcc = searchResult[s].getValue({name: 'custrecord_appf_payment_account'});
			 var getPaymentDate = searchResult[s].getValue({name: 'custrecord_appf_cutover_pmt_date'});
			 var getCreatedPayment = searchResult[s].getValue({name: 'custrecord_appf_cutover_pmtcreated'});
			 var getPaymentLinked = searchResult[s].getValue({name: 'custrecord_appf_cutover_paymentlink'});
			 //log.debug('getInvID=' + getInvID + 'getCutoverRecId = ' + getCutoverRecId );



             var oCols = new Object();
             oCols['getInvID'] = getInvID;
             oCols['getCutoverRecId'] = getCutoverRecId;
             oCols['getDate'] = getDate;
             oCols['getSOLineID'] = getSOLineID;
             oCols['getPaymentRef'] = getPaymentRef;
             oCols['getAmountPaid'] = getAmountPaid;
             oCols['getInvID'] = getInvID;
             oCols['getPaymentAcc'] = getPaymentAcc;
             oCols['getPaymentDate'] = getPaymentDate;
             oCols['getCreatedPayment'] = getCreatedPayment;
             oCols['getPaymentLinked'] = getPaymentLinked;

             var aDataDetails = oGroupedCutOver[getInvID] || new Array();
         	 aDataDetails.push(oCols);
         	 oGroupedCutOver[getInvID] = aDataDetails;

    	 }

    	 //loop contents
         for(var idKey in oGroupedCutOver){
     	    var aRows = oGroupedCutOver[idKey];
     	    for(var j = 0; j < aRows.length; j++){
     	    	var oCol = aRows[j];
     	    	log.debug('getInvID= ' + oCol['getInvID'] + 'getCutoverRecId = ' + oCol['getCutoverRecId'] + 'getSOLineID = ' + oCol['getSOLineID']);
     	    	//log.debug('getCutoverRecId = ' + oCol['getCutoverRecId']);
     	    	//log.debug('getSOLineID = ' + oCol['getSOLineID']);
     	    }


         }


    	 //send contents
    	 return oGroupedCutOver;
    }

    /**
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    function map(context) {
    	var rowJson = JSON.parse(context.value);
    	log.debug('rowJson map', rowJson);
    	log.debug('key map', rowJson.id);

    	//return

    }

    function reduce(context){
    	var rowJson = JSON.parse(context.values[0]);
    	var aData = rowJson;
    	//log.debug('rowJson reduce', rowJson );
    	//log.debug('aData length='+aData.length + ' start = '+ new Date());
    	//transform whole invoice to payment
    	//time
		var transformRecord = record.transform({
		    fromType: record.Type.INVOICE,
		    fromId: aData[0].getInvID,
		    toType: 'customerpayment',
		    isDynamic: true
		});
		log.debug('transformRecord',transformRecord);
		if(aData[0].getPaymentDate != null && aData[0].getPaymentDate != ''){
			var getPaymentDate = format.parse({
				  value: aData[0].getPaymentDate,
				  type: format.Type.DATE
				});
			transformRecord.setValue({fieldId: 'trandate',value: getPaymentDate});
		}



		if(aData[0].getPaymentAcc != '' && aData[0].getPaymentAcc != null)
		    transformRecord.setValue({fieldId: 'account',value: aData[0].getPaymentAcc});
		transformRecord.setValue({fieldId: 'checknum',value: aData[0].getPaymentRef});
		//transformRecord.setFieldValue('payment', getAmountPaid);

		//transformRecord.setFieldValue(FLD_INV_CUTOVER_AR_RECORD, getCutoverRecId);
		//transformRecord.setFieldValue(FLD_INV_IS_CUTOVER_TRANSACTION, 'T');
		transformRecord.setValue({fieldId: FLD_INV_IS_CUTOVER_TRANSACTION,value: true});

		var fTotalAmountPaid = 0;
		var aCutOver = [];
		var aProcessedCutOver = [];
		var aUnProcessedCutOver = [];


		//var loadInvoice = record.load({type: record.Type.INVOICE,id: aData[0].getInvID,isDynamic: false});
		//log.debug('loadInvoice',loadInvoice);
		for(var k = 0; k < aData.length; k++){
				//find index for so id
				var getAmountPaid = aData[k].getAmountPaid;

				fTotalAmountPaid += parseFloat(getAmountPaid);
				aCutOver.push(aData[k].getCutoverRecId);
				aProcessedCutOver.push(aData[k].getCutoverRecId);
				//log.debug('getAmountPaid',getAmountPaid + ' aData[k].getSOLineID = '+ aData[k].getSOLineID);
				/*var i = loadInvoice.findSublistLineWithValue({
				    sublistId: 'item',
				    fieldId: FLD_TRAN_LINE_SO_LINE_ID,
				    value: aData[k].getSOLineID
				});

				if(i > 0){
					//log.debug('aData[k].getSOLineID',aData[k].getSOLineID + ' i: ' + i);
					loadInvoice.setSublistValue({
					    sublistId: 'item',
					    fieldId: FLD_INV_COL_AMOUNT_PAID,
					    line: i,
					    value: getAmountPaid
					});
				}*/
		}

		var getLineCount = transformRecord.getLineCount({sublistId: 'apply'});
		log.debug('getLineCount',getLineCount);

		for(var i = 0; i < getLineCount; i++) {
			transformRecord.selectLine({sublistId: 'apply',line: i});
			//var getIsApplied = transformRecord.getCurrentLineItemValue('apply', 'apply');
			var getIsApplied = transformRecord.getCurrentSublistValue({
			    sublistId: 'apply',
			    fieldId: 'apply'
			});

			if(getIsApplied == true) {
				log.debug('fTotalAmountPaid',fTotalAmountPaid);
				transformRecord.setCurrentSublistValue({sublistId: 'apply',fieldId: 'amount',value: fTotalAmountPaid});
				transformRecord.commitLine({sublistId: 'apply'});
			}

		}

		//transformRecord.setValue({fieldId: FLD_INV_CUTOVER_AR_RECORD,value: aProcessedCutOver});

		try{
			var aProcessedCutOver = [];
			var submitRecord = transformRecord.save();

			log.debug('submitRecord payment =',submitRecord  + ' from invoice = ' + aData[0].getInvID + 'remaining usage = ' + runtime.getCurrentScript().getRemainingUsage() + ' date end='+ new Date());

			if(submitRecord){
				var loadInvoice = record.load({type: record.Type.INVOICE,id: aData[0].getInvID,isDynamic: false});
				log.debug('loadInvoice',loadInvoice);
                log.debug('aData', aData);

				for(var k = 0; aData && k < aData.length; k++){
					//find index for so id

                    log.debug('aData[k].getSOLineID', aData[k].getSOLineID);

					var getSOLineID = aData[k].getSOLineID;
					log.debug('before getSOLineID.length ='+getSOLineID.length);
					getSOLineID =  getSOLineID.replace(/\s+/g,'');
					log.debug(' after getSOLineID.length ='+getSOLineID.length);
					var i = loadInvoice.findSublistLineWithValue({
					    sublistId: 'item',
					    fieldId: FLD_TRAN_LINE_SO_LINE_ID,
					    value: aData[k].getSOLineID
					});
					log.debug('debug','aData[k].getSOLineID', aData[k].getSOLineID + ' i = '+ i);

					if(i >= 0){
						log.debug('aData[k].getSOLineID',aData[k].getSOLineID + ' i: ' + i + ' amount paid = ' + aData[k].getAmountPaid);
						var getAmountPaid = aData[k].getAmountPaid;
						/*loadInvoice.setSublistValue({
						    sublistId: 'item',
						    fieldId: FLD_INV_COL_AMOUNT_PAID,
						    line: i,
						    value: getAmountPaid
						});*/
						aProcessedCutOver.push(aData[k].getCutoverRecId);
					}else{
						aUnProcessedCutOver.push(aData[k].getCutoverRecId);
					}
				}
				//var submitInv = loadInvoice.save();

				//log.debug('submitInv', submitInv);

				//set payment link
				record.submitFields({
				    type: 'customerpayment',
				    id: submitRecord,
				    values: {
				    	'custbody_appf_cutover_ar_record': aProcessedCutOver
				    }
				});
			}

			//load invoice and set amount paid
			/*var loadInv = nlapiLoadRecord('invoice', getInvID);
			loadInv.setLineItemValue('item', FLD_INV_COL_AMOUNT_PAID, 1, getAmountPaid);
			var submitInv = nlapiSubmitRecord(loadInv);
			nlapiLogExecution('Debug', 'submitInv', submitInv);*/



			//update rest of cutover records
            log.debug('aProcessedCutOver', aProcessedCutOver);
			for(var k = 0; aProcessedCutOver && k < aProcessedCutOver.length; k++){
				record.submitFields({
				    type: REC_TYPE_APPF_CUTOVER_CREDIT_INV,
				    id: aProcessedCutOver[k],
				    values: {
				    	'custrecord_appf_cutover_paymentlink': submitRecord,
				    	'custrecord_appf_cutover_pmtcreated': true,
				    	'custrecord_appf_cutover_scriptstatus': SCRIPT_STATUS_COMPLETED,
				    	'custrecord_appf_cutover_scriptlog_pmt': ''
				    }
				});
			}

			if(aUnProcessedCutOver){
				for(var k = 0; k < aUnProcessedCutOver.length; k++){
					record.submitFields({
					    type: REC_TYPE_APPF_CUTOVER_CREDIT_INV,
					    id: aUnProcessedCutOver[k],
					    values: {
					    	'custrecord_appf_cutover_paymentlink': '',
					    	'custrecord_appf_cutover_pmtcreated': false,
					    	'custrecord_appf_cutover_scriptstatus': SCRIPT_STATUS_FAILED,
					    	'custrecord_appf_cutover_scriptlog_pmt': 'No Matching line. Please check if has matching line in sales order and if the sales order client gross application is greater than 0.'
					    }
					});
					//log.debug('saving...' + ' aUnProcessedCutOver[k] = '+ aUnProcessedCutOver[k]);

				}
			}

		}catch(e){
			log.debug('Error', e.message);
		}

    	//call another map reduce to update the lines

    }

    /**
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
   /* function reduce(context) {

    }*/


    /**
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {

    }

    return {
        getInputData: getInputData,
        /*map: map,*/
        reduce: reduce,
        summarize: summarize
    };

});
