/*
*Script Name: Appf-Sync SO & POs SC
*Script Type: Scheduled Script
*Description: This script syncs the SO and its linked POs for POs count > 30
*Company 	: Appficiency Inc.

* V2.0  Nov 20 2020   Set rate to 1
*/

var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';

var TOTAL_FORMS = 6;
var SCRIPT_SCHEDULE = 'customscript_appf_sync_so_po_sc';
var SPARAM_SO_ID = 'custscript_appf_so_id';
var FLD_SYNC_SO_PO_STATUS = 'custbody_sync_sopo_status';
var FLD_SYNC_SO_PO_ERROR = 'custbody_sync_so_po_error';
var STATUS_SYNC_SO_PO = {'IN_PROGRESS':1,'SYNC_SUCCESS':2,'SYNC_FAILED':3};

var FLD_SYNC_SO_PO_TRIGGER = 'custbody_appf_ssync_so_po_trigger';


function syncSOPOScheduled() {


		var context = nlapiGetContext();

		var recordId = context.getSetting('SCRIPT', SPARAM_SO_ID);
  nlapiLogExecution('debug','so id',recordId)
		var salesOrderRec = nlapiLoadRecord('salesorder', recordId);
		var recForm = salesOrderRec.getFieldValue('customform');
		var count = salesOrderRec.getLineItemCount('item');
		var posObj = {};
		var poArr = [];
		var lastPO = null;
		for(var i=1; i<=count; i++){

			var createdPO = salesOrderRec.getLineItemValue('item', 'createdpo', i);
			if(createdPO != null && createdPO != ''){
								lastPO=createdPO;
				if(!posObj.hasOwnProperty(createdPO)){
					posObj[createdPO] = {};
					posObj[createdPO].id=createdPO;
					posObj[createdPO].vendor = salesOrderRec.getLineItemValue('item', FLD_COL_VENDOR_NAME, i);
					posObj[createdPO].solineids = [];
					posObj[createdPO].solineids.push(salesOrderRec.getLineItemValue('item', FLD_COL_SO_LINE_ID, i));

				}
				else{
					posObj[createdPO].solineids.push(salesOrderRec.getLineItemValue('item', FLD_COL_SO_LINE_ID, i));
				}



			}

		}
		nlapiLogExecution('DEBUG', 'posObj', JSON.stringify(posObj));



			var paramFields = '';
			for(var i=1; i<=TOTAL_FORMS; i++){
				var paramForm = context.getSetting('SCRIPT','custscript_appf_form_'+i+'_id');
				if(paramForm == recForm){
					paramFields = context.getSetting('SCRIPT','custscript_appf_form_'+i+'_fields');
				}
			}
			var errMsg = '';

			for(var po in posObj){
								  nlapiLogExecution( 'DEBUG', 'processing PO', po)

				var soLineVend = posObj[po].vendor;
				try{
				var poRec = nlapiLoadRecord('purchaseorder', po, {recordmode:'dynamic'});
				var poVendor = poRec.getFieldValue('entity');
				if(poVendor != soLineVend)
					poRec.setFieldValue('entity', soLineVend);
				var soLines = posObj[po].solineids;
				if(soLines != null && soLines != ''){
					for(var l=0; l<soLines.length; l++){
						if(paramFields != null && paramFields != ''){
							var fields = [];

								fields = fields.concat(paramFields.split(','));

							var lineNumber = poRec.findLineItemValue('item', FLD_COL_SO_LINE_ID, soLines[l]);
                          var solinenumber = salesOrderRec.findLineItemValue('item', FLD_COL_SO_LINE_ID, soLines[l]);
							if(lineNumber > 0){
								for(var f=0; f<fields.length; f++){
									var fldValue = salesOrderRec.getLineItemValue('item', fields[f], solinenumber);
									poRec.setLineItemValue('item', fields[f], lineNumber, fldValue);
								}
                              //var jobSoLine = salesOrderRec.getLineItemValue('item', 'job', solinenumber);
                                //poRec.setLineItemValue('item', 'customer', lineNumber, jobSoLine);

								var qtySoLine = salesOrderRec.getLineItemValue('item', 'quantity', solinenumber);
								poRec.setLineItemValue('item', 'custcol_appf_po_current_client_gross', lineNumber, qtySoLine);

								var vednorAllocSoLine = salesOrderRec.getLineItemValue('item', 'custcol_appf_vendor_allocation_amount', solinenumber);
								poRec.setLineItemValue('item', 'quantity', lineNumber, vednorAllocSoLine);
								poRec.setLineItemValue('item', 'rate', lineNumber, 1);  //added: 11/20/2020
							}
						}
					}
				}
				nlapiSubmitRecord(poRec, true, true);
				}catch(ex){
					try{
						var poRec = nlapiLoadRecord('purchaseorder', po, {recordmode:'dynamic'});
				var poVendor = poRec.getFieldValue('entity');
				if(poVendor != soLineVend)
					poRec.setFieldValue('entity', soLineVend);
				var soLines = posObj[po].solineids;
				if(soLines != null && soLines != ''){
					for(var l=0; l<soLines.length; l++){
						if(paramFields != null && paramFields != ''){
							var fields = [];

								fields = fields.concat(paramFields.split(','));

							var lineNumber = poRec.findLineItemValue('item', FLD_COL_SO_LINE_ID, soLines[l]);
                          var solinenumber = salesOrderRec.findLineItemValue('item', FLD_COL_SO_LINE_ID, soLines[l]);
							if(lineNumber > 0){
								for(var f=0; f<fields.length; f++){
									var fldValue = salesOrderRec.getLineItemValue('item', fields[f], solinenumber);
									poRec.setLineItemValue('item', fields[f], lineNumber, fldValue);
								}
                              //var jobSoLine = salesOrderRec.getLineItemValue('item', 'job', solinenumber);
                                //poRec.setLineItemValue('item', 'customer', lineNumber, jobSoLine);

								var qtySoLine = salesOrderRec.getLineItemValue('item', 'quantity', solinenumber);
								poRec.setLineItemValue('item', 'custcol_appf_po_current_client_gross', lineNumber, qtySoLine);

								var vednorAllocSoLine = salesOrderRec.getLineItemValue('item', 'custcol_appf_vendor_allocation_amount', solinenumber);
								poRec.setLineItemValue('item', 'quantity', lineNumber, vednorAllocSoLine);
								poRec.setLineItemValue('item', 'rate', lineNumber, 1);  //added: 11/20/2020
							}
						}
					}
				}
				nlapiSubmitRecord(poRec, true, true);
					}
					catch (e)
					{

				if ( e instanceof nlobjError )
				{
				  nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
				  errMsg += 'Sync with PO Internal ID: '+po+' failed. Reason: '+e.getDetails() + '\n';
				}
				else
				{
				  nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				 errMsg += 'Sync with PO Internal ID: '+po+' failed. Reason: '+e.toString() + '\n';
				}
					}

			}
if(context.getRemainingUsage() < 1000 && lastPO != po) {
				  nlapiLogExecution( 'DEBUG', 'reschedule block', 'po:'+po )

					setRecoveryPoint();
					checkGovernance();
					}
					}
			try{
								  nlapiLogExecution( 'DEBUG', 'final  block', 'so:'+recordId )

			salesOrderRec = nlapiLoadRecord('salesorder', recordId);
			if (errMsg != '')
			{
			salesOrderRec.setFieldValue(FLD_SYNC_SO_PO_STATUS, STATUS_SYNC_SO_PO.SYNC_FAILED);
			salesOrderRec.setFieldValue(FLD_SYNC_SO_PO_ERROR, errMsg);
			}
			else
			{
			salesOrderRec.setFieldValue(FLD_SYNC_SO_PO_STATUS, STATUS_SYNC_SO_PO.SYNC_SUCCESS);
			salesOrderRec.setFieldValue(FLD_SYNC_SO_PO_ERROR, '');
			}



salesOrderRec.setFieldValue(FLD_SYNC_SO_PO_TRIGGER, 'T');
		nlapiSubmitRecord(salesOrderRec, true, true);
			}
catch(ex)
{

				if ( ex instanceof nlobjError )
				{
				  nlapiLogExecution( 'DEBUG', 'system error', ex.getDetails() )
				  //errMsg += 'Sync with PO Internal ID: '+po+' failed. Reason: '+e.getDetails() + '\n';
				}
				else
				{
				  nlapiLogExecution( 'DEBUG', 'unexpected error', ex.toString() )
				 //errMsg += 'Sync with PO Internal ID: '+po+' failed. Reason: '+e.toString() + '\n';
				}

}

}





function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint();

    if(state.status == 'SUCCESS')
        return;
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);
    }
}

function checkGovernance() {
    var context = nlapiGetContext();

    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}
