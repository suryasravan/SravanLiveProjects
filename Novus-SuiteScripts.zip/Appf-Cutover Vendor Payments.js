/*
 *Script Name: Appf-Create Cutover Vendor Payment Sc
 *Script Type: Scheduled
 *Description:
 *Company 	: Appficiency Inc.
 * Version		Date			Author			Description
 * 1.1			11/01/2020		MJ De Asis		GST and PST payment will only be created when GST/ PST cutover is ticked on, tick on the CUtover checkbox when payment and bill is created.
 */
var CUSTOM_RECORD_CUTOVER_LOG_RECORD = 'customrecord_appf_cutover_payment_log';
var FLD_TAX_VENDOR_PAYMENT_LINKS = 'custrecord_appf_tax_vbp';
var FLD_CSV_DATA_FILE = 'custrecord_appf_csv_data_file';
var FLD_NUM_OF_LINES_TO_PROCESS = 'custrecord_appf_cutover_total';
var FLD_NUM_OF_LINES_PROCESSED = 'custrecord_appf_cutover_processed';
var FLD_NUM_OF_LINES_FAILED = 'custrecord_appf_cutover_failed';
var FLD_PROCESSING_PERCENT = 'custrecord_appf_cutover_proc_percent';
var FLD_PAYMENTS = 'custrecord_appf_cutover_payment_links';
var FLD_LOG_ERRORS = 'custrecord_domed_ocean_error_log';
var FLD_COL_MEDIA_OCEAN = 'custcol_appf_mediaocean_upload'
var FLD_COL_PWP_BILL_AMT = 'custcol_appf_pwp_bill_line_amt_paid'
//custcol_appf_pwp_bill_line_amt_paid
var FLD_CUTOVER_PAYMENT_LOG = 'custbody_appf_cutover_payment_log'
var FLD_CUTOVER_INTREMS = 'custbody_appf_cutover_vb_child_link'
var FLD_CUTOVER_TRANS = 'custbody_appf_cutover_transaction'
var CUSTOM_RECORD_INTERIM_RECORD = 'customrecord_appf_interim_vb';
var FLD_TAX_PAYMENT_CUTOVER_LINK = 'custrecord_appf_tax_cutoverpay';
var FLD_GST_HST_BILL_LINK = 'custrecord_appf_ivb_gst_hst_vb';
var FLD_PST_QST_BILL_LINK = 'custrecord_ivb_pst_qst_vb';
var FLD_INTERIM_RECORD_MEMO = 'custrecord_appf_ivb_memo';
var FLD_GST_AMOUNT = 'custrecord_appf_ivb_gst';
var FLD_PST_AMOUNT = 'custrecord_appf_ivb_qst';
var FLD_CUTOVER_TRANSACTION = 'custrecord_appf_ivb_cutover_transaction';
var FLD_AP_ACCOUNT = 'custrecord_appf_ivb_account';
var CUSTOM_RECORD_INTERIM_CHILD_RECORD = 'customrecord_appf_interim_vb_line'
var FLD_PAYMENT_LINK = 'custrecord_appf_ivbl_paymentlink';
var FLD_INTERIM_CHILD_CUTOVER_PAYMENT_LOG = 'custrecord_appf_cutover_payment_log';
var FLD_PAYMENT_CREATION_ERROR = 'custrecord_appf_ivbl_payment_error';
var FLD_VENDOR_PAYMENT_TYPE = 'custbody_appf_vendor_payment_type';
var STATUS_APPR = '2'
var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED = '4';
var STATUS_COMPLETED_ERRORS = '5';
var SPARAM_INDEX = 'custscript_appf_file_idex';
var SPARAM_PAYMENT_ID = 'custscript_appf_cutover_payment_creatio'
var SPARAM_CSV_ID = 'custscript_appf_csv_file_no'
var SPARAM_CUTOVER_SCRIPT_SS = 'custscript_appf_cutover_vendor_payment_s';
var SPARAM_CUTOVER_SCRIPT_TAX_SS = 'custscript_appf_cutover_vend_tax_payment';

/// v1.1
var FLD_CUTOVER_GST_PAYMENT = 'custrecord_appf_gst_cutoverpay';
var FLD_CUTOVER_PST_PAYMENT = 'custrecord_appf_pst_cutoverpay';
var TRANS_FLD_CUTOVERTRANSACTION = 'custbody_appf_cutover_transaction';

function SOScheduled(type) {
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_CUTOVER_SCRIPT_SS);
	var taxSSID = context.getSetting('SCRIPT', SPARAM_CUTOVER_SCRIPT_TAX_SS);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX)
	var FilecsvDataID1 = context.getSetting('SCRIPT', SPARAM_CSV_ID)
	if (index == null || index == '') index = 1;
	var custRecID = context.getSetting('SCRIPT', SPARAM_PAYMENT_ID)
	if (custRecID == null || custRecID == '') {
		var loadSS, filts, columns, ssType;
		if (ssID != null && ssID != '') {
			loadSS = nlapiLoadSearch(null, ssID);
			filts = loadSS.getFilters();
			columns = loadSS.getColumns();
			ssType = loadSS.getSearchType();
		}
		var loadTaxSS, taxfilts, taxcolumns, taxssType;
		if (taxSSID != null && taxSSID != '') {
			loadTaxSS = nlapiLoadSearch(null, taxSSID);
			taxfilts = loadTaxSS.getFilters();
			taxcolumns = loadTaxSS.getColumns();
			taxssType = loadTaxSS.getSearchType();
		}
		var taxsearchResults = getAllSearchResults(taxssType, taxfilts, taxcolumns);
		var taxPaymentLinksArray = [];
		var vendorBillObj = [];
		if (taxsearchResults != null && taxsearchResults != '') {
			for (var p = 0; p < taxsearchResults.length; p++) {
				var result = taxsearchResults[p];
				var taxPaymentLinksCutoverArray = [];
				var internalid = result.getId();
				var vendorBillIdGST = result.getValue(FLD_GST_HST_BILL_LINK);
				var vendorBillIdPST = result.getValue(FLD_PST_QST_BILL_LINK);
				var vendorBillIdGSTName = result.getText(FLD_GST_HST_BILL_LINK);
				var vendorBillIdPSTName = result.getText(FLD_PST_QST_BILL_LINK);
				var existingMemo = result.getValue(FLD_INTERIM_RECORD_MEMO);
				var gstAmount = result.getValue(FLD_GST_AMOUNT);
				var pstAmount = result.getValue(FLD_PST_AMOUNT);
				var apAccount = result.getValue(FLD_AP_ACCOUNT);
				var BillObjGST = {};
				var BillObjPST = {};

				/// v1.1
				var gstPaymentAmount = result.getValue(FLD_CUTOVER_GST_PAYMENT);
				var pstPaymentAmount = result.getValue(FLD_CUTOVER_PST_PAYMENT);

				//if ((vendorBillIdGST != null && vendorBillIdGST != '') && (gstPaymentAmount != null && gstPaymentAmount != '')) { //11/11/2020
				if ( ((vendorBillIdGST != null && vendorBillIdGST != '') && (gstPaymentAmount != null && gstPaymentAmount != '')) && (parseFloat(gstPaymentAmount) > 0) ) {
					var vendorPaymentGST = nlapiTransformRecord('vendorbill', vendorBillIdGST, 'vendorpayment', {
						recordmode: 'dynamic'
					});
					gstPaymentAmount = parseFloat(gstPaymentAmount);
					if (apAccount != null && apAccount != '') vendorPaymentGST.setFieldValue('apacct', apAccount)
					vendorPaymentGST.setFieldValue(FLD_CUTOVER_TRANS, 'T');
					vendorPaymentGST.setFieldValue('approvalstatus', '2');
					var polineNum = vendorPaymentGST.findLineItemValue('apply', 'internalid', vendorBillIdGST)
					nlapiLogExecution('DEBUG', 'internalid=', internalid + ' polineNum=', polineNum)
					if (polineNum != -1) {
						vendorPaymentGST.selectLineItem('apply', polineNum)
						vendorPaymentGST.setCurrentLineItemValue('apply', 'apply', 'T');
						vendorPaymentGST.setCurrentLineItemValue('apply', 'amount', gstPaymentAmount);
						vendorPaymentGST.commitLineItem('apply');
					}
					try {
						var vendorPaymentGSTId = nlapiSubmitRecord(vendorPaymentGST, true, true);
					} catch (errorVendorPaymentGST) {
						if (errorVendorPaymentGST instanceof nlobjError) {
							nlapiLogExecution('DEBUG', 'system error', errorVendorPaymentGST.getCode() + '\n' + errorVendorPaymentGST.getDetails())
							//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
						} else {
							nlapiLogExecution('DEBUG', 'unexpected error', errorVendorPaymentGST.toString())
							// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
						}
						//failedCount++;
					}
					if (vendorPaymentGSTId) {
						var refNumberOfTaxPayment = nlapiLoadRecord('vendorpayment', vendorPaymentGSTId).getFieldValue('transactionnumber');
						BillObjGST.id = vendorBillIdGST;
						BillObjGST.payment = gstAmount;
						vendorBillObj.push(BillObjGST);
						taxPaymentLinksCutoverArray.push(vendorPaymentGSTId);
						if (existingMemo == null || existingMemo == '') {
							existingMemo = 'Cutover Payment for ' + vendorBillIdGSTName + ': ' + refNumberOfTaxPayment;
						} else {
							existingMemo = existingMemo + '\nCutover Payment for ' + vendorBillIdGSTName + ': ' + refNumberOfTaxPayment;
						}
						taxPaymentLinksArray.push(vendorPaymentGSTId)
					}
				}
				if ( ((vendorBillIdPST != null && vendorBillIdPST != '') && (pstPaymentAmount != null && pstPaymentAmount != '')) && (parseFloat(pstPaymentAmount) > 0)   ) {
					var vendorPaymentPST = nlapiTransformRecord('vendorbill', vendorBillIdPST, 'vendorpayment', {
						recordmode: 'dynamic'
					});
					pstPaymentAmount = parseFloat(pstPaymentAmount);
					if (apAccount != null && apAccount != '') vendorPaymentPST.setFieldValue('apacct', apAccount)
					vendorPaymentPST.setFieldValue(FLD_CUTOVER_TRANS, 'T');
					vendorPaymentPST.setFieldValue('approvalstatus', '2')
					var polineNum = vendorPaymentPST.findLineItemValue('apply', 'internalid', vendorBillIdPST)
					nlapiLogExecution('DEBUG', 'internalid=', internalid + ' polineNum=', polineNum)
					if (polineNum != -1) {
						vendorPaymentPST.selectLineItem('apply', polineNum)
						vendorPaymentPST.setCurrentLineItemValue('apply', 'apply', 'T');
						vendorPaymentPST.setCurrentLineItemValue('apply', 'amount', pstPaymentAmount);
						vendorPaymentPST.commitLineItem('apply');
					}
					try {
						var vendorPaymentPSTId = nlapiSubmitRecord(vendorPaymentPST, true, true);
					} catch (errorVendorPaymentPST) {
						if (errorVendorPaymentPST instanceof nlobjError) {
							nlapiLogExecution('DEBUG', 'system error', errorVendorPaymentPST.getCode() + '\n' + errorVendorPaymentPST.getDetails())
							//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
						} else {
							nlapiLogExecution('DEBUG', 'unexpected error', errorVendorPaymentPST.toString())
							// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
						}
						//failedCount++;
					}
					if (vendorPaymentPSTId) {
						var refNumberOfTaxPayment = nlapiLoadRecord('vendorpayment', vendorPaymentPSTId).getFieldValue('transactionnumber');
						BillObjPST.id = vendorBillIdPST;
						BillObjPST.payment = pstAmount;
						vendorBillObj.push(BillObjPST);
						taxPaymentLinksCutoverArray.push(vendorPaymentPSTId);
						if (existingMemo == null || existingMemo == '') {
							existingMemo = 'Cutover Payment for ' + vendorBillIdPSTName + ': ' + refNumberOfTaxPayment;
						} else {
							existingMemo = existingMemo + '\nCutover Payment for ' + vendorBillIdPSTName + ': ' + refNumberOfTaxPayment;
						}
						taxPaymentLinksArray.push(vendorPaymentPSTId)
					}
				}
				nlapiLogExecution('debug', 'taxPaymentLinksCutoverArray:', JSON.stringify(taxPaymentLinksCutoverArray));
				if(taxPaymentLinksCutoverArray){
					    nlapiLogExecution('debug', 'set backlinking:', 'vendorPaymentGSTId='+vendorPaymentGSTId + ' vendorPaymentPSTId='+vendorPaymentPSTId);
              var bBackLink = false;
							for(var q = 0; q < taxPaymentLinksCutoverArray.length; q++){
							    	if( (taxPaymentLinksCutoverArray.indexOf(vendorPaymentGSTId) > -1)  || (taxPaymentLinksCutoverArray.indexOf(vendorPaymentPSTId) > -1) ){
									      bBackLink = true;
										}
							}
							nlapiLogExecution('debug', 'bBackLink:', bBackLink);
							if(bBackLink){
							    nlapiSubmitField(CUSTOM_RECORD_INTERIM_RECORD, internalid, [FLD_TAX_PAYMENT_CUTOVER_LINK, FLD_INTERIM_RECORD_MEMO], [taxPaymentLinksCutoverArray, existingMemo]);
							  	taxPaymentLinksCutoverArray = [];
							}

							taxPaymentLinksCutoverArray = [];

				}

			}
			nlapiLogExecution('debug', 'taxPaymentLinksArray:', taxPaymentLinksArray);
			nlapiLogExecution('debug', 'vendorBillObj:', vendorBillObj.length);
			if (vendorBillObj.length > 0) {
				nlapiLogExecution('debug', 'vendorBillObj:', JSON.stringify(vendorBillObj));
				for (var v = 0; v < vendorBillObj.length; v++) {
					var billId = vendorBillObj[v].id;
					var billPayment = vendorBillObj[v].payment;
					var billRec = nlapiLoadRecord('vendorbill', billId);
					var vendorbillPaymt = billRec.getLineItemValue('item', FLD_COL_PWP_BILL_AMT, 1);
					if (vendorbillPaymt == null || vendorbillPaymt == '') vendorbillPaymt = 0
					vendorbillPaymt = parseFloat(vendorbillPaymt) + parseFloat(billPayment);
					billRec.setLineItemValue('item', FLD_COL_PWP_BILL_AMT, 1, vendorbillPaymt);

					/// v1.1
					billRec.setFieldValue(TRANS_FLD_CUTOVERTRANSACTION, 'T');

					try {
						nlapiSubmitRecord(billRec, true, true);
					} catch (errorBillRec) {
						if (errorBillRec instanceof nlobjError) {
							nlapiLogExecution('DEBUG', 'system error', errorBillRec.getCode() + '\n' + errorBillRec.getDetails())
							//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
						} else {
							nlapiLogExecution('DEBUG', 'unexpected error', errorBillRec.toString())
							// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
						}
						//failedCount++;
					}
				}
			}
		}
		var searchResults = getAllSearchResults(ssType, filts, columns);
		if (searchResults != null && searchResults != '') {
			var csvData = 'Internal ID,Vendor Internal ID,Vendor Name,Payment Date,VB Header,Vendor Bill Internal ID,Payment Reference,Payment Account,Vendor Bill Number,Amount,Vendor Payment Type \n';

			/// v1.2
			var csvLines = [];

			for (var s = 0; s < searchResults.length; s++) {
				var result = searchResults[s];
				var internalid = result.getId();
				var scriptfieldcounter = 1;

				/// v1.2
				var csvLineData = [];

				for (var c = 0; c < columns.length; c++) {
					var colObj = columns[c];
					var columnName = colObj.getName();
					var colLabel = colObj.getLabel();
					columnName = columnName.replace('.', '_');
					var ssResultValue = result.getValue(colObj);
					if (colObj.getType() == 'select' && columnName != 'custrecord_appf_ivbl_paymentacc') {
						ssResultValue = result.getText(colObj);
					}
					// nlapiLogExecution( 'DEBUG', 'columnName', columnName)
					if (colLabel == 'Script Use DNR') {
						ssResultValue = ssResultValue.replace(/,/gim, ';');
						//csvData += '"' + ssResultValue + '",';
						csvLineData.push(ssResultValue);
					}
				}

				/// v1.2
				//csvData += csvLineData.join(',') + '\n';
				csvLines.push(csvLineData.join(','));

			}
			var timestamp = new Date().getTime();

			/// v1.2
			//csvData = csvData.slice(0, -1);
			csvData += csvLines.join('\n');

			var csvDataFile = nlapiCreateFile('CutoverInterimChildRecordsForPaymentCreation_' + timestamp + '.csv', 'CSV', csvData);
			csvDataFile.setFolder('1152');
			FilecsvDataID1 = nlapiSubmitFile(csvDataFile);
		}
		if ((searchResults != null && searchResults != '') || (taxPaymentLinksArray.length > 0)) {
			var custRec = nlapiCreateRecord(CUSTOM_RECORD_CUTOVER_LOG_RECORD)
			custRec.setFieldValue(FLD_CSV_DATA_FILE, FilecsvDataID1)
			if (searchResults != null && searchResults != '') custRec.setFieldValue(FLD_NUM_OF_LINES_TO_PROCESS, searchResults.length);
			if (taxPaymentLinksArray.length > 0) custRec.setFieldValues(FLD_TAX_VENDOR_PAYMENT_LINKS, taxPaymentLinksArray);
			try {
				custRecID = nlapiSubmitRecord(custRec, true, true);
			} catch (errorCustRec) {
				if (errorCustRec instanceof nlobjError) {
					nlapiLogExecution('DEBUG', 'system error', errorCustRec.getCode() + '\n' + errorCustRec.getDetails())
					//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
				} else {
					nlapiLogExecution('DEBUG', 'unexpected error', errorCustRec.toString())
					// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
				}
				//failedCount++;
			}
		}
	}
	if ((FilecsvDataID1 != null && FilecsvDataID1 != '') && (custRecID != null && custRecID != '')) {
		if (custRecID != null && custRecID != '') {
			var cutoverPaymentLogRecord = nlapiLoadRecord(CUSTOM_RECORD_CUTOVER_LOG_RECORD, custRecID);
			var fileid = cutoverPaymentLogRecord.getFieldValue(FLD_CSV_DATA_FILE);
			if (fileid != null && fileid != '') {
				var processedCount = cutoverPaymentLogRecord.getFieldValue(FLD_NUM_OF_LINES_PROCESSED);
				var failedCount = cutoverPaymentLogRecord.getFieldValue(FLD_NUM_OF_LINES_FAILED);
				var totalLinesCount = cutoverPaymentLogRecord.getFieldValue(FLD_NUM_OF_LINES_TO_PROCESS);
				var existingVendorPayments = [];
				var hasPayments = cutoverPaymentLogRecord.getFieldValue(FLD_PAYMENTS);
				if (hasPayments != null && hasPayments != '') {
					var payemntLinks = cutoverPaymentLogRecord.getFieldValues(FLD_PAYMENTS);
					existingVendorPayments = existingVendorPayments.concat(payemntLinks);
				}
				var csvfile = nlapiLoadFile(fileid)
				var fileString = csvfile.getValue()
				nlapiLogExecution('DEBUG', 'fileString', fileString);
				fileDataArr = fileString.split('\n');
				nlapiLogExecution('debug', 'fileDataArr length', fileDataArr.length);
				for (var d = index; d < (fileDataArr.length); d++) {
					var ErrorMsg = ''
					var vendorPaymentId = ''
					var data = fileDataArr[d].split(',');
					var internalId = data[5];
					var paymentDt = data[3];
					var amt = data[9];
					var paymentAccount = data[7];
					var paymtRef = data[6];
					var intermNo = data[0];
					var vendorPaymentType = data[10];
					try {
                        nlapiLogExecution('DEBUG', 'vb internalId', internalId);
						var vendorPayment = nlapiTransformRecord('vendorbill', internalId, 'vendorpayment')
						if (paymentDt != null && paymentDt != '' && paymentDt != 'null') vendorPayment.setFieldValue('trandate', paymentDt)
						vendorPayment.setFieldValue('tranid', paymtRef)
						if (paymentAccount != null && paymentAccount != '' && paymentAccount != 'null') vendorPayment.setFieldValue('account', paymentAccount);
						vendorPayment.setFieldValue(FLD_CUTOVER_TRANS, 'T')
						vendorPayment.setFieldValue('approvalstatus', '2')
						nlapiLogExecution('DEBUG', 'Interim internalId', intermNo);
						vendorPayment.setFieldValue(FLD_CUTOVER_INTREMS, intermNo)
						vendorPayment.setFieldValue(FLD_CUTOVER_PAYMENT_LOG, custRecID)
						vendorPayment.setFieldText(FLD_VENDOR_PAYMENT_TYPE, vendorPaymentType)
						var polineNum = vendorPayment.findLineItemValue('apply', 'doc', internalId)
						nlapiLogExecution('DEBUG', 'internalid=', internalid + ' polineNum=', polineNum)
						if (polineNum != -1) {
							vendorPayment.selectLineItem('apply', polineNum)
							vendorPayment.setCurrentLineItemValue('apply', 'apply', 'T');
							vendorPayment.setCurrentLineItemValue('apply', 'amount', amt);
							vendorPayment.commitLineItem('apply');
						}
						try {
							vendorPaymentId = nlapiSubmitRecord(vendorPayment, true, true);
						} catch (errorVendorPayment) {
							if (errorVendorPayment instanceof nlobjError) {
								nlapiLogExecution('DEBUG', 'errorVendorPayment system error', errorVendorPayment.getCode() + '\n' + errorVendorPayment.getDetails())
								//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
							} else {
								nlapiLogExecution('DEBUG', 'unexpected error', errorVendorPayment.toString())
								// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
							}
							//failedCount++;
						}
						if (vendorPaymentId != null && vendorPaymentId != '') {
							existingVendorPayments.push(vendorPaymentId);
							var vendorbillRec = nlapiLoadRecord('vendorbill', internalId)
							vendorbillRec.setFieldValue(FLD_CUTOVER_PAYMENT_LOG, custRecID)
							var vendorbillPaymt = vendorbillRec.getLineItemValue('item', FLD_COL_PWP_BILL_AMT, 1);
							if (vendorbillPaymt == null || vendorbillPaymt == '') vendorbillPaymt = 0
							vendorbillPaymt = parseFloat(vendorbillPaymt) + parseFloat(amt);
							vendorbillRec.setLineItemValue('item', FLD_COL_PWP_BILL_AMT, 1, vendorbillPaymt);
							try {
								nlapiSubmitRecord(vendorbillRec, true, true)
							} catch (errorVendorbillRec) {
								if (errorVendorbillRec instanceof nlobjError) {
									nlapiLogExecution('DEBUG', 'errorVendorbillRec system error', errorVendorbillRec.getCode() + '\n' + errorVendorbillRec.getDetails())
									//ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.getDetails();
								} else {
									nlapiLogExecution('DEBUG', 'unexpected error', errorVendorbillRec.toString())
									// ErrorMsg='Failed processing Interim Child Record: '+intermNo+'. Reason: '+e.toString();
								}
								//failedCount++;
							}
						}
						// nlapiSubmitField(CUSTOM_RECORD_INTERIM_CHILD_RECORD,intermNo,[FLD_PAYMENT_LINK,FLD_PAYMENT_CREATION_ERROR],[vendorPaymentId,])
						processedCount++
					} catch (e) {
						if (e instanceof nlobjError) {
							nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails())
							ErrorMsg = 'Failed processing Interim Child Record: ' + intermNo + '. Reason: ' + e.getDetails();
						} else {
							nlapiLogExecution('DEBUG', 'unexpected error', e.toString())
							ErrorMsg = 'Failed processing Interim Child Record: ' + intermNo + '. Reason: ' + e.toString();
						}
						failedCount++;
					}
					var processedPercent = (parseInt(processedCount) + parseInt(failedCount)) / parseInt(totalLinesCount);
					processedPercent = parseFloat(processedPercent) * 100;
					processedPercent = Number(processedPercent).toFixed(2);
					nlapiSubmitField(CUSTOM_RECORD_CUTOVER_LOG_RECORD, custRecID, [FLD_PAYMENTS, FLD_NUM_OF_LINES_PROCESSED, FLD_NUM_OF_LINES_FAILED, FLD_PROCESSING_PERCENT], [existingVendorPayments, processedCount, failedCount, processedPercent])
					nlapiSubmitField(CUSTOM_RECORD_INTERIM_CHILD_RECORD, intermNo, [FLD_INTERIM_CHILD_CUTOVER_PAYMENT_LOG, FLD_PAYMENT_LINK, FLD_PAYMENT_CREATION_ERROR], [custRecID, vendorPaymentId, ErrorMsg])
					if (context.getRemainingUsage() <= 1000 && (parseInt(d) + 1) < fileDataArr.length) {
						var params = {};
						params[SPARAM_INDEX] = parseInt(d) + 1;
						params[SPARAM_CSV_ID] = FilecsvDataID1;
						params[SPARAM_PAYMENT_ID] = custRecID;
						nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
						break;
					}
				}
			}
		}
	}
}

function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);
	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];
	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}
