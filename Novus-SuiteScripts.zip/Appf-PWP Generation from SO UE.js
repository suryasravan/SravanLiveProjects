/*
 * Script Name : Appf-PWP Generation from SO UE
 * Script Type : User Event Script
 * Event Type  : afterSubmit
 * Deployed On : Sales Order
 * Description : On Sale Order submit script checks if status is Pending Approval and creates or updates PWP records from line items
 *     Sravan 04/16/2020 Setting PO Vendor from Vendor Name (Custom) during creation
5/13/2020 v3 Sravan removed logic to set PO Vendor and PO Rate to chck if this resolves Item Options Error in integration and added that logic in Order Validation script

 * Company     : Appficiency Inc.
 */
var FLD_COL_LINE_ID_SO = 'custcol_appf_line_id';
var FLD_COL_LINE_ID_INV = 'custcol_appf_invoice_line_id';
var FLD_COL_LINE_ID_PO = 'custcol_appf_po_line_id';
var FLD_COL_LINE_ID_VENDOS = 'custcol_appf_vendorbill_line_id';
var FLD_COL_LINE_ID_ESTIMTS = 'custcol_appf_estimate_line_id';
var FLD_COL_LINE_PWP_RECS = 'custcol_appf_pwp_custom_record';
var FLD_COL_POP_RECEIVED = 'custcol_appf_pop_received';
var MEDIA_SEGMENT = 'cseg_appf_media_seg';
var FLD_COL_IO = 'custcol_appf_ionum';
var FLD_COL_CIRCULATION = 'custcol_appf_print_circulation';
var FLD_COL_NOVUS_UNIT_RATE= 'custcol_appf_novusunitrate';

var CUSTOMRECORD_PWP='customrecord_appf_pwp_wrapper_record'
var CUSTOMRECORD_SO_LINE_ID_PWP='custrecord_appf_pwp_so_line_id'
var CUSTOMRECORD_SO_LINK='custrecord_appf_pwp_so_link'
var CUSTOMRECORD_SO_LINE_AMT='custrecord_appf_pwp_so_line_amount'

//added 27-10-2021
var CUSTOMRECORD_SO_PRE_CLOSE='custrecord_appf_so_amount_pre_close';

var CUSTOMRECORD_PWP_LINE_OF_BUSINESS='custrecord_appf_pwp_line_of_business'
var CUSTOMRECORD_PWP_DEPARTMENT='custrecord_appf_pwp_department'
var CUSTOMRECORD_PWP_OFFICE='custrecord_appf_pwp_office'
var CUSTOMRECORD_PWP_CLIENT_LINK='custrecord_appf_pwp_client_link'
var CUSTOMRECORD_PWP_PRO='custrecord_appf_pwp_project'
var CUSTOMRECORD_PWP_POP_RECEIVED = 'custrecord_appf_pwp_pop_received';
var CUSTOMRECORD_PWP_BUYING_SYSTEM = 'custrecord_appf_pwp_buying_system';
var CUSTOMRECORD_PWP_IO = 'custrecord_appf_pwp_io_number';
var FLD_PWP_CLIENT_CURRENCY='custrecord_appf_pwp_client_currency';


var CUSTOMRECORD_PWP_IO_CIRCULATION= 'custrecord_appf_pwp_io_circulation';
var CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE= 'custrecord_appf_pwp_io_novus_unit_rate';

var FLD_NEXT_LINE_ID ='custbody_appf_next_line_number';
var FLD_PO_NEXT_LINE_ID = 'custbody_appf_next_line_number_po';
var FLD_REV_REC_LINK = 'custbody_appf_aem_rev_rec_arrangement';
var FLD_BUYING_SYSTEM = 'custbody_appf_buying_system';

var SCRIPT_PWP_GENERATION_SO_SC = 'customscript_appf_pwp_generation_so_sc';

var SPARAM_SALES_ORDER_ID = 'custscript_appf_sales_order_id';
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';

//Include Custom Forms ['Novus - Sales Order (Non-Media)']
var INCLUDE_CUSTOM_FORMS = ['156'];


/* after submit function*/
function pwpGeneration(type)
{
	var context = nlapiGetContext();
	//if(context.getExecutionContext() != 'scheduled'){
	if (type != 'delete') 
	    {
			var pwpObj = {};
			var inPWPLogic = false;
		var recId = nlapiGetRecordId();
	    var recType = nlapiGetRecordType();
		var salesOrderRec = nlapiLoadRecord(recType, recId);
		var customForm = salesOrderRec.getFieldValue('customform');
        if (INCLUDE_CUSTOM_FORMS.indexOf(customForm) != -1)
			{
				//use povendor setting from order vlaidation
				try{
				var itemCount=salesOrderRec.getLineItemCount('item');
		for(var k=1;k<=itemCount;k++)
			{
			
						  var existingPOVendor = salesOrderRec.getLineItemValue('item', 'povendor', k);
				var vendorName = salesOrderRec.getLineItemValue('item', FLD_COL_VENDOR_NAME, k);
						  var existingcreatepo = salesOrderRec.getLineItemValue('item', 'createpo', k);

				if (vendorName == null)
				vendorName = '';
			   // nlapiLogExecution('debug', 'po vendor', vendorName);
			  if (existingPOVendor != vendorName && vendorName != null && vendorName != '')
				{
				salesOrderRec.selectLineItem('item', k);
				salesOrderRec.setCurrentLineItemValue('item', 'povendor', vendorName);
							  salesOrderRec.setCurrentLineItemValue('item', 'porate', 1);

				  if (existingcreatepo == null || existingcreatepo == '')
				   salesOrderRec.setCurrentLineItemValue('item', 'createpo', 'SpecOrd');                  
				salesOrderRec.commitLineItem('item');	
				}
									   
			}
		
			nlapiSubmitRecord(salesOrderRec, true, true);
				}
				catch(ep)
				{
					
					nlapiLogExecution('debug', 'Failed to set PO Vendor', ep);
				}
                                        
            }
          
          var record = nlapiLoadRecord(recType, recId);
		//var soStatus = record.getFieldValue('status');
		var clientOnInvoice=record.getFieldValue('entity');
		var clientCurrency='';
		if(clientOnInvoice)
		{
			clientCurrency=nlapiLookupField('customer',clientOnInvoice,'currency');
		}
		
		
		var itemCount=record.getLineItemCount('item');
		var soentity=record.getFieldValue('entity')
		var buyingSystem = record.getFieldValue(FLD_BUYING_SYSTEM);
		
			                for(var k=1;k<=itemCount;k++)
                               {
								    nlapiLogExecution('debug', 'in line #', k);
								 var soId= record.getLineItemValue('item',FLD_COL_LINE_ID_SO,k)
								 var soAmt= record.getLineItemValue('item','amount',k)
								 if(soAmt != null && soAmt != '')
									 soAmt = Number(soAmt).toFixed(2);
								 var sodepartment= record.getLineItemValue('item','department',k)
								 var solocation= record.getLineItemValue('item','location',k)
								  var soPro= record.getLineItemValue('item','job',k)
								  var soclass= record.getLineItemValue('item','class',k)
								    var soCirculation= record.getLineItemValue('item',FLD_COL_CIRCULATION,k)
									 if (soCirculation == null || soCirculation == '')
										 soCirculation = 0;
								   var soNovusUnitRate= record.getLineItemValue('item',FLD_COL_NOVUS_UNIT_RATE,k)
								   if (soNovusUnitRate == null || soNovusUnitRate == '')
										 soNovusUnitRate = 0;
								  var popReceived = record.getLineItemValue('item', FLD_COL_POP_RECEIVED,k)
								    var mediaSegment = record.getLineItemValue('item', MEDIA_SEGMENT, k)

								  var io = record.getLineItemValue('item', FLD_COL_IO,k)
                                 
								 
								 try{
								  var pwpRecLink= record.getLineItemValue('item',FLD_COL_LINE_PWP_RECS,k);
								  if(pwpRecLink!=null && pwpRecLink!='')
								  {
									  var pwpRecord = nlapiLoadRecord(CUSTOMRECORD_PWP, pwpRecLink);
									  if(soAmt!=null && soAmt!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT,soAmt);
									  
									 //added 27-10-2021
									  if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
									  
								     if(sodepartment!=null && sodepartment!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT,sodepartment);
								      if(solocation!=null && solocation!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE,solocation);
								      if(soentity!=null && soentity!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK,soentity);
								    if(soPro!=null && soPro!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO,soPro);
								   if(soclass!=null && soclass!='')
								   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS,soclass);
                                     if (popReceived == 'T')
							         pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED,popReceived);
                                      if (buyingSystem != null && buyingSystem != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM,buyingSystem);
							   if (mediaSegment != null && mediaSegment != '')
									 pwpRecord.setFieldValue(MEDIA_SEGMENT,mediaSegment);
								 
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION,soCirculation);
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE,soNovusUnitRate);   
								 
								 if (io != null && io != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO,io);
									nlapiSubmitRecord(pwpRecord,true,true)
			
								  }
								  else
								  {
									  if (INCLUDE_CUSTOM_FORMS.indexOf(customForm) != -1)
									  {
										 
									  var pwpRecord =nlapiCreateRecord(CUSTOMRECORD_PWP)
								      nlapiLogExecution('DEBUG', 'pwpRecord', pwpRecord);
								     pwpRecord.setFieldValue('name','PWP - '+soId);
								    
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_ID_PWP,soId);
							
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINK,recId);
									 
									 nlapiLogExecution('DEBUG', 'recId', recId);
									 
								     if(soAmt!=null && soAmt!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT,soAmt);
									 
									 //added 27-10-2021
									 if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
									 																	 
								     if(sodepartment!=null && sodepartment!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT,sodepartment);
								      if(solocation!=null && solocation!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE,solocation);
								      if(soentity!=null && soentity!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK,soentity);
								      if(clientCurrency!=null && clientCurrency!='')
									pwpRecord.setFieldValue(FLD_PWP_CLIENT_CURRENCY,clientCurrency); 
								    if(soPro!=null && soPro!='')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO,soPro);
								   if(soclass!=null && soclass!='')
								   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS,soclass);
                                    if (buyingSystem != null && buyingSystem != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM,buyingSystem);
							   if (mediaSegment != null && mediaSegment != '')
									 pwpRecord.setFieldValue(MEDIA_SEGMENT,mediaSegment);
								 
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION,soCirculation);
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE,soNovusUnitRate);
								 
								 if (io != null && io != '')
									 pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO,io);
							   if (popReceived == 'T')
							   pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED,popReceived);
							    nlapiLogExecution('DEBUG', 'popReceived', popReceived);
									var pwpRecordID= nlapiSubmitRecord(pwpRecord,true,true)
									nlapiLogExecution('DEBUG', 'pwpRecordID', pwpRecordID);
									//record.setLineItemValue('item',FLD_COL_LINE_PWP_RECS,k,pwpRecordID);
									inPWPLogic = true;
									pwpObj[soId] = pwpRecordID;
								  
										  
									  }
									  
								  }
								 }
								  catch (ex) {
                                if (ex instanceof nlobjError) {
                                    errorMessage = 'Error creating/updating PWP for line id '+soId+': '+ex.getDetails();
                                } else {
                                    errorMessage = 'Error creating/updating PWP for line id '+soId+': '+ex.toString();
                                }
                            }
		                        }
								
								
								if (inPWPLogic)
								{
									var record = nlapiLoadRecord('salesorder', recId);
						 for (var prop in pwpObj)
						 {
							 var lineNum = record.findLineItemValue('item', FLD_COL_LINE_ID_SO, prop);
							 if (lineNum != -1)
							 {
								 record.selectLineItem('item', lineNum);
								 record.setCurrentLineItemValue('item',FLD_COL_LINE_PWP_RECS,pwpObj[prop]);
								 record.commitLineItem('item');
							 }
						 }
			var submittedRecId = nlapiSubmitRecord(record,true,true);
									
								}
								
								
		}
	
}

	