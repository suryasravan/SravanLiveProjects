function sched()
{
			var context=nlapiGetContext();

		var invoicesAppliedFile =context.getSetting('SCRIPT','custscript_testsch');
  if (invoicesAppliedFile == null || invoicesAppliedFile == '')
    invoicesAppliedFile = 0;

var cmARr = [16075232,16075233,16075234,16075235,16075236,16075237,16075238,16075239,16075240,16075241,16075242,16075243,16075244,16075245,16075246,16075247,16075248,16075249,16075250,16075251,16075252,16075253];




for (var d = invoicesAppliedFile; d < cmARr.length; d++)
{
try{
var cmrec = nlapiLoadRecord('creditmemo', cmARr[d], {recordmode:'dynamic'});
cmrec.setFieldValue('custbody_appf_cst_pmt_status', '3');
var cmcount = cmrec.getLineItemCount('apply');
for (var c = 1; c <= cmcount; c++)
{
var isApply = cmrec.getLineItemValue('apply', 'apply', c);
if (isApply == 'T')
{
cmrec.selectLineItem('apply', c);
cmrec.setCurrentLineItemValue('apply', 'apply', 'F');
cmrec.commitLineItem('apply');
}

}


nlapiSubmitRecord(cmrec, true, true);
} catch(e)
{
  
}


if (context.getRemainingUsage() <= 1000 && (parseInt(d)+1) < cmARr.length)
							{
								var params_pcpalt = {};
								params_pcpalt['custscript_testsch'] = parseInt(d)+1;
nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_pcpalt);
                              break;
							}
}
}