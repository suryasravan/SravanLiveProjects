/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       29 Apr 2020     rutikamore      Script and Deployment Id: _ss_create_cutover_payments
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */

var SCRIPTFLD_SEARCH_PARAMETER = 'custscript_cutover_payment_saved_search';
var SCRIPTFLD_ACCOUNT_ID = 'custscript_cutover_account_id';
var REC_TYPE_APPF_CUTOVER_CREDIT_INV = 'customrecordappf_cutover_invoice';
var FLD_INV_CUTOVER_AR_RECORD = 'custbody_appf_cutover_ar_record';
var FLD_INV_IS_CUTOVER_TRANSACTION = 'custbody_appf_cutover_transaction';
var FLD_CUSTOMREC_CUTOVER_PAYMENT_LINK = 'custrecord_appf_cutover_paymentlink';
var FLD_CUSTOMREC_CUTOVER_PAYMENT_CREATED = 'custrecord_appf_cutover_pmtcreated';
var FLD_CUSTOMREC_CUTOVER_STATUS = 'custrecord_appf_cutover_scriptstatus';
var FLD_CUSTOMREC_CUTOVER_STATUS_LOG = 'custrecord_appf_cutover_scriptlog_pmt';
var FLD_INV_COL_AMOUNT_PAID = 'custcol_appf_pwp_inv_line_amt_paid';
var SCRIPT_STATUS_INPROGRESS = 2;
var SCRIPT_STATUS_COMPLETED = 3;
var SCRIPT_STATUS_FAILED = 4;

function scheduled(type) {
	
	var context = nlapiGetContext();
	var getSavedSearchId = context.getSetting('SCRIPT', SCRIPTFLD_SEARCH_PARAMETER);
	
	//Code to load the saved search
	var loadsearch = searchMoreRecords(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getSavedSearchId, null, null);
	
	if(loadsearch != '' && loadsearch != null) {
		
		for(var a = 0; a < loadsearch.length; a++) {
			
			try {
				
				if (context.getRemainingUsage() <= 500){
					nlapiYieldScript();
				}
				
				var getCurrentObj = loadsearch[a];
				var getColumns = getCurrentObj.getAllColumns();
				var getCutoverRecId = getCurrentObj.getId();
				var getDate = getCurrentObj.getValue(getColumns[1]);
				var getPaymentRef = getCurrentObj.getValue(getColumns[2]);
				var getAmountPaid = getCurrentObj.getValue(getColumns[3]);
				var getInvID = getCurrentObj.getValue(getColumns[4]);
				var getPaymentAcc = getCurrentObj.getValue(getColumns[5]);
				var getPaymentDate = getCurrentObj.getValue(getColumns[6]);
				
				nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, FLD_CUSTOMREC_CUTOVER_STATUS, SCRIPT_STATUS_INPROGRESS);
				
				/*nlapiLogExecution('Debug', 'getCutoverRecId', getCutoverRecId);
				nlapiLogExecution('Debug', 'getDate', getDate);
				nlapiLogExecution('Debug', 'getPaymentRef', getPaymentRef);
				nlapiLogExecution('Debug', 'getAmountPaid', getAmountPaid);
				nlapiLogExecution('Debug', 'getInvID', getInvID);
				nlapiLogExecution('Debug', 'getPaymentAcc', getPaymentAcc);*/
				
				//Transform Sales Order to Invoice.
				var transformRecord = nlapiTransformRecord('invoice', getInvID, 'customerpayment');
				transformRecord.setFieldValue('trandate', getPaymentDate);
				if(getPaymentAcc != '' && getPaymentAcc != null)
					transformRecord.setFieldValue('account', getPaymentAcc);
				transformRecord.setFieldValue('checknum', getPaymentRef);
				//transformRecord.setFieldValue('payment', getAmountPaid);
				
				transformRecord.setFieldValue(FLD_INV_CUTOVER_AR_RECORD, getCutoverRecId);
				transformRecord.setFieldValue(FLD_INV_IS_CUTOVER_TRANSACTION, 'T');
				
				var getLineCount = transformRecord.getLineItemCount('apply');
				//nlapiLogExecution('Debug', 'getLineCount', getLineCount);
				
				for(var i = 1; i <= getLineCount; i++) {
					
					transformRecord.selectLineItem('apply', i);
					
					var getIsApplied = transformRecord.getCurrentLineItemValue('apply', 'apply');
					
					if(getIsApplied == 'T') {
						
						transformRecord.setCurrentLineItemValue('apply', 'amount', getAmountPaid);
						transformRecord.commitLineItem('apply');
						
					}
					
				}
				
				var submitRecord = nlapiSubmitRecord(transformRecord);
				nlapiLogExecution('Debug', 'submitRecord', submitRecord);
				
				if(submitRecord) {
					
					nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, [FLD_CUSTOMREC_CUTOVER_PAYMENT_LINK, FLD_CUSTOMREC_CUTOVER_PAYMENT_CREATED, FLD_CUSTOMREC_CUTOVER_STATUS, FLD_CUSTOMREC_CUTOVER_STATUS_LOG], [submitRecord, 'T', SCRIPT_STATUS_COMPLETED, '']);
					
					var loadInv = nlapiLoadRecord('invoice', getInvID);
					loadInv.setLineItemValue('item', FLD_INV_COL_AMOUNT_PAID, 1, getAmountPaid);
					var submitInv = nlapiSubmitRecord(loadInv);
					nlapiLogExecution('Debug', 'submitInv', submitInv);
					
				}
				
			}
			catch(error) {
				
				nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, [FLD_CUSTOMREC_CUTOVER_STATUS, FLD_CUSTOMREC_CUTOVER_STATUS_LOG], [SCRIPT_STATUS_FAILED, error.toString()]);
				
			}
		}
		
	}
	
}

function searchMoreRecords(recordType, searchID, filters, columns)
{

	// create search; alternatively nlapiLoadSearch() can be used to load a saved search
	var searchRecords = null;
	if(searchID != null)
		searchRecords = nlapiLoadSearch(recordType, searchID);
	else
		searchRecords = nlapiCreateSearch(recordType, filters, columns);

	var searchResults = searchRecords.runSearch();

	// resultIndex points to record starting current resultSet in the entire results array 
	var resultIndex = 0; 
	var resultStep = 1000; // Number of records returned in one step (maximum is 1000)
	var resultSet; // temporary variable used to store the result set
	var mergedResults = [];
	do 
	{
		// fetch one result set
		resultSet = searchResults.getResults(resultIndex, resultIndex + resultStep);
		mergedResults  = mergedResults.concat(resultSet);
		// increase pointer
		resultIndex = resultIndex + resultStep;

		// process or log the results
		// once no records are returned we already got all of them
	} while (resultSet.length > 0);
	return mergedResults;
}