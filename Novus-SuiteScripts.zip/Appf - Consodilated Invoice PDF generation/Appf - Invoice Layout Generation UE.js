/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/record', 'N/url', 'N/config'],
	
	function(record, url, config) {
	
		function beforeLoad(context) {
			
        	//Display button on if the record is open in View mode
            if (context.type == context.UserEventType.VIEW) {
            	
            	//Get the Suitelet URL which will open the PDF Layout
            	var getURL = url.resolveScript({
            	    scriptId: 'customscript_sl_invoice_designgeneration',
            	    deploymentId: 'customdeploy_sl_invoice_designgeneration',
            	    returnExternalUrl: false
            	});
            	log.debug('URL', getURL);
            	
            	//Get dynamic company url to append it in the suitelet URL as prefix.
            	//Suitelet returns URL from /app.... due to which the prefix with company details have to be fetched dynamically from Company Information page.
            	var configCompanyInfo = config.load({
            	    type: config.Type.COMPANY_INFORMATION
            	});
            	var prefixDefaultCompanyURL = configCompanyInfo.getValue({
            		fieldId: 'appurl'
            	});
            	log.debug('prefixDefaultCompanyURL', prefixDefaultCompanyURL);
            	
            	//Get current record internal id
            	var recObj = context.newRecord;
            	var recInternalId = recObj.id
            	log.debug('recInternalId', recInternalId);
            	
            	//Combine both the URL's to form one main URL to be called. Adding the current records internal id to the parameter.
            	var mainURL = prefixDefaultCompanyURL + getURL;
            	mainURL += '&recId='+recInternalId;
            	log.debug('mainURL', mainURL);
            	
            	//Adding the Print button to the form and the URL is set.
            	var form = context.form;
            	form.addButton({
            		id : "custpage_printbutton",
            		label : "Print",
            		functionName: "window.open('"+mainURL+"')"
            	});
            	
            }
            
        }
        
        function beforeSubmit(context) {
            
        }
        function afterSubmit(context) {
            
        }
        return {
            beforeLoad: beforeLoad,
            //beforeSubmit: beforeSubmit,
            //afterSubmit: afterSubmit
        };
    }); 