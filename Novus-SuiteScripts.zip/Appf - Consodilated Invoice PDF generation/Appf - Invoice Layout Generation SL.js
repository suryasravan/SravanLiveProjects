function suitelet(request, response) {
	
	var context = nlapiGetContext();
	
	//Get CI Record ID from the URL and load the record for all the required data from the CI Record and attach the load object to renderer.
	var getRecId = request.getParameter('recId');
	var loadRecord = nlapiLoadRecord('customrecord_appf_ci_record', getRecId);
	var getParentClient = loadRecord.getFieldValue('custrecord_appf_ci_parent');
	var getChildClient = loadRecord.getFieldValue('custrecord_appf_ci_client');
	var getClientSubsidiary = loadRecord.getFieldValue('custrecord_appf_ci_subsidiary');
	var getInvoicePDFLayout = loadRecord.getFieldValue('custrecord_appf_ci_pdf_template');
	var getCIDocumentNumber = loadRecord.getFieldValue('name');
	var getPDFTemplate = nlapiLookupField('customrecord_appf_invoice_layout_setup', getInvoicePDFLayout, 'custrecord_appf_ils_pdflayout');
	var invoiceIds = nlapiLookupField('customrecord_appf_ci_record', getRecId, 'custrecord_appf_ci_invoices');
	
	//Form new array for all the invoice internal id's.
	var newInvoiceArray = new Array();
	
	if(invoiceIds != '') {
		
		var splitInvoiceId = invoiceIds.split(',');
		
		for(var iid = 0; iid < splitInvoiceId.length; iid++) {
			
			if(splitInvoiceId[iid] != '' && splitInvoiceId[iid] != null)
				newInvoiceArray.push(splitInvoiceId[iid]);
			
		}
		
	}
	
	nlapiLogExecution('Debug', 'getPDFTemplate', getPDFTemplate);
	nlapiLogExecution('Debug', 'getRecId', getRecId);
	nlapiLogExecution('Debug', 'getClientSubsidiary', getClientSubsidiary);
	nlapiLogExecution('Debug', 'getParentClient', getParentClient);
	nlapiLogExecution('Debug', 'getChildClient', getChildClient);
	nlapiLogExecution('Debug', 'invoiceIds', invoiceIds);
	nlapiLogExecution('Debug', 'newInvoiceArray', newInvoiceArray);
	
	//Load the PDF Template attached to the CI Record to replace the object with dynamic value.
	var fileObj = nlapiLoadFile(getPDFTemplate);
	var fileContent = fileObj.getValue();
	
	//Subsidiary to access fields from subsidiary
	var loadsubsidiary = nlapiLoadRecord('subsidiary', getClientSubsidiary);
	
	//General object to store the customer record loaded information.
	var loadCustomer;
	
	//Load customer record to access address from there.
	if(getParentClient != '' && getParentClient != null) {
		loadCustomer = nlapiLoadRecord('customer', getParentClient);
	}
	else {
		loadCustomer = nlapiLoadRecord('customer', getChildClient);
	}
	
	//Generic data objects to attach data to the renderer.
	var loadSearch;
	var JSONOfTotals = [];
	var loadTotalsSearch;
	
	//Pass Invoice Internal Id dynamically to filter records.
	if(newInvoiceArray != '' && newInvoiceArray != null) {
		var filterTran = new Array();
		filterTran.push(new nlobjSearchFilter('internalid', null, 'anyof', newInvoiceArray));
		loadSearch = nlapiSearchRecord(null, 'customsearch_ci_sublist_script', filterTran, null);
		
	}
	else {
		
		var errorMessage = 'There are no transactions attached to this CI Record. Please verify if the data is correct or contact your Administrator.';
		throw errorMessage;
		return true;
	}
	
	nlapiLogExecution('Debug', 'loadSearch', JSON.stringify(loadSearch));
	
	//Create renderer to add all the records, searches and other data required for print.
	var renderer = nlapiCreateTemplateRenderer();
	renderer.setTemplate(fileContent);
	renderer.addRecord('record', loadRecord);
	renderer.addRecord('customer', loadCustomer);
	renderer.addRecord('subsidiary', loadsubsidiary);
	//renderer.addSearchResults('TOTALSAMOUNT', loadTotalsSearch);
	renderer.addSearchResults('SEARCH', loadSearch);
	
	//renderer.addCustomDataSource("JSON", JSON, JSONOfTotals);
	
	var newTemplate = renderer.renderToString();
	var file = nlapiXMLToPDF(newTemplate);
	response.setContentType('PDF', 'CI '+getCIDocumentNumber+'.pdf', 'inline');
	response.write(file.getValue());
	
}