/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       29 Apr 2020     rutikamore      Script and Deployment Id: _ss_create_cutover_invoice
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */

var SCRIPTFLD_SEARCH_PARAMETER = 'custscript_cutover_invoice_saved_search';
var REC_TYPE_APPF_CUTOVER_CREDIT_INV = 'customrecordappf_cutover_invoice';
var REC_TYPE_APPF_CI_RECORD = 'customrecord_appf_ci_record';

var FLD_INV_CUTOVER_AR_RECORD = 'custbody_appf_cutover_ar_record';
var FLD_INV_IS_CUTOVER_TRANSACTION = 'custbody_appf_cutover_transaction';

var FLD_CUSTOMREC_CUTOVER_INVOICE_LINK = 'custrecord_appf_cutover_invoicelink';
var FLD_CUSTOMREC_CUTOVER_INVOICE_CREATED = 'custrecord_appf_cutover_invcreated';
var FLD_CUSTOMREC_CUTOVER_STATUS = 'custrecord_appf_cutover_scriptstatus';
var FLD_CUSTOMREC_CUTOVER_STATUS_LOG = 'custrecord_appf_cutover_scriptlog';
var FLD_CUSTOMREC_CUTOVER_SO_LINE_ID = 'custrecord_appf_cutover_so_line_id';
var FLD_CUSTOMREC_CUTOVER_CI_RECORD = 'custrecord_appf_cutover_ci_link';

var FLD_CUSTOMREC_CI_RECORD_INVOICES = 'custrecord_appf_ci_invoices';

var FLD_TRAN_LINE_SO_LINE_ID = 'custcol_appf_line_id';
var FLD_TRAN_LINE_CUTOVER_REC_ID = 'custcol_appf_cutover_record';
var FLD_TRAN_LINE_CI_REC_LINK = 'custcol_appf_ci_record';
var FLD_TRAN_LINE_CI_REC_STATUS = 'custcol_appf_ci_status';

var SCRIPT_STATUS_INPROGRESS = 2;
var SCRIPT_STATUS_COMPLETED = 3;
var SCRIPT_STATUS_FAILED = 4;
var invApprovedSatus = 2;

function scheduled(type) {
	
	var context = nlapiGetContext();
	var getSavedSearchId = context.getSetting('SCRIPT', SCRIPTFLD_SEARCH_PARAMETER);
	
	//Code to load the saved search
	var loadsearch = searchMoreRecords(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getSavedSearchId, null, null);
	
	if(loadsearch != '' && loadsearch != null) {
		
		for(var a = 0; a < loadsearch.length; a++) {
			
			try {
				
				if (context.getRemainingUsage() <= 500){
					nlapiYieldScript();
				}
				
				var getCurrentObj = loadsearch[a];
				var getColumns = getCurrentObj.getAllColumns();
				var getCutoverRecId = getCurrentObj.getId();
				var getDate = getCurrentObj.getValue(getColumns[1]);
				var getDueDate = getCurrentObj.getValue(getColumns[2]);
				var getTotalAmount = getCurrentObj.getValue(getColumns[4]);
				var getMemoLine = getCurrentObj.getValue(getColumns[5]);
				var getMemoMain = getCurrentObj.getValue(getColumns[6]);
				var getSOID = getCurrentObj.getValue(getColumns[7]);
				var getSOLineID = getCurrentObj.getValue(getColumns[8]);
				var getCIRecord = getCurrentObj.getValue(getColumns[9]);
				var getCIStatus = getCurrentObj.getValue(getColumns[10]);
				
				nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, FLD_CUSTOMREC_CUTOVER_STATUS, SCRIPT_STATUS_INPROGRESS);
				
				//Transform Sales Order to Invoice.
				var transformRecord = nlapiTransformRecord('salesorder', getSOID, 'invoice');
				transformRecord.setFieldValue('trandate', getDate);
				transformRecord.setFieldValue('duedate', getDueDate);
				transformRecord.setFieldValue('memo', getMemoMain);
				transformRecord.setFieldValue('approvalstatus', invApprovedSatus);
				transformRecord.setFieldValue(FLD_INV_CUTOVER_AR_RECORD, getCutoverRecId);
				transformRecord.setFieldValue(FLD_INV_IS_CUTOVER_TRANSACTION, 'T');
				
				var getLineCount = transformRecord.getLineItemCount('item');
				
				for(var i = getLineCount; i >= 1; i--) {
					
					var getLineId = transformRecord.getLineItemValue('item', FLD_TRAN_LINE_SO_LINE_ID, i);
					
					if(getLineId != getSOLineID) {
						
						transformRecord.removeLineItem('item', i);
						
					}
					else if(getLineId == getSOLineID) {
						
						transformRecord.selectLineItem('item', i);
						//transformRecord.setCurrentLineItemValue('item', 'description', getMemoLine);
						transformRecord.setCurrentLineItemValue('item', 'memo', getMemoLine);
						transformRecord.setCurrentLineItemValue('item', 'quantity', getTotalAmount);
						transformRecord.setCurrentLineItemValue('item', FLD_TRAN_LINE_CUTOVER_REC_ID, getCutoverRecId);
						transformRecord.setCurrentLineItemValue('item', FLD_TRAN_LINE_CI_REC_LINK, getCIRecord);
						transformRecord.setCurrentLineItemValue('item', FLD_TRAN_LINE_CI_REC_STATUS, getCIStatus);
						transformRecord.commitLineItem('item');
						
					}
					
				}
				
				var submitRecord = nlapiSubmitRecord(transformRecord);
				nlapiLogExecution('Debug', 'submitRecord', submitRecord);
				
				if(submitRecord) {
					
					var loadSO = nlapiLoadRecord('salesorder', getSOID);
					
					var lineItemCount = loadSO.getLineItemCount('item');
					//nlapiLogExecution('Debug', 'lineItemCount', lineItemCount);
					
					for(var j = 1; j <= lineItemCount; j++) {
						
						var getLineId = loadSO.getLineItemValue('item', FLD_TRAN_LINE_SO_LINE_ID, j);
						
						if(getLineId == getSOLineID) {
							
							loadSO.selectLineItem('item', j);
							loadSO.setCurrentLineItemValue('item', FLD_TRAN_LINE_CUTOVER_REC_ID, getCutoverRecId);
							loadSO.commitLineItem('item');
							
						}
						
					}
					
					var submitSORecord = nlapiSubmitRecord(loadSO);
					nlapiLogExecution('Debug', 'submitSORecord', submitSORecord);
					
					nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, [FLD_CUSTOMREC_CUTOVER_INVOICE_LINK, FLD_CUSTOMREC_CUTOVER_INVOICE_CREATED, FLD_CUSTOMREC_CUTOVER_STATUS, FLD_CUSTOMREC_CUTOVER_STATUS_LOG], [submitRecord, 'T', SCRIPT_STATUS_COMPLETED, '']);
					
					
				}
				
			}
			catch(error) {
				
				nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, [FLD_CUSTOMREC_CUTOVER_STATUS, FLD_CUSTOMREC_CUTOVER_STATUS_LOG], [SCRIPT_STATUS_FAILED, error.toString()]);
				
			}
			
		}
		
	}
	
}

function searchMoreRecords(recordType, searchID, filters, columns)
{

	// create search; alternatively nlapiLoadSearch() can be used to load a saved search
	var searchRecords = null;
	if(searchID != null)
		searchRecords = nlapiLoadSearch(recordType, searchID);
	else
		searchRecords = nlapiCreateSearch(recordType, filters, columns);

	var searchResults = searchRecords.runSearch();

	// resultIndex points to record starting current resultSet in the entire results array 
	var resultIndex = 0; 
	var resultStep = 1000; // Number of records returned in one step (maximum is 1000)
	var resultSet; // temporary variable used to store the result set
	var mergedResults = [];
	do 
	{
		// fetch one result set
		resultSet = searchResults.getResults(resultIndex, resultIndex + resultStep);
		mergedResults  = mergedResults.concat(resultSet);
		// increase pointer
		resultIndex = resultIndex + resultStep;

		// process or log the results
		// once no records are returned we already got all of them
	} while (resultSet.length > 0);
	return mergedResults;
}