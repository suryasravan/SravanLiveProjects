/**
 * Module Description
 * 
 * Version    Date            Author           Remarks
 * 1.00       29 Apr 2020     rutikamore      Script and Deployment Id: _ss_link_cutover_invoice_ci
 * 2.00       20 Aug 2020     roach           Fixed SCRIPTFLD_SEARCH_PARAMETER value and undefined submitRecord variable
 *
 */

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */

var SCRIPTFLD_SEARCH_PARAMETER = 'custscript_cutover_invoice_link_ss'; /*'custscript_cutover_invoice_saved_search';*/
var REC_TYPE_APPF_CUTOVER_CREDIT_INV = 'customrecordappf_cutover_invoice';
var REC_TYPE_APPF_CI_RECORD = 'customrecord_appf_ci_record';

var FLD_CUSTOMREC_CUTOVER_STATUS = 'custrecord_appf_cutover_scriptstatus';
var FLD_CUSTOMREC_CUTOVER_STATUS_LOG = 'custrecord_appf_cutover_scriptlog';
var FLD_CUSTOMREC_CUTOVER_LINKBACK_CI = 'custrecord_appf_cutover_backlink_ci';

var FLD_CUSTOMREC_CI_RECORD_INVOICES = 'custrecord_appf_ci_invoices';

var SCRIPT_STATUS_INPROGRESS = 2;
var SCRIPT_STATUS_COMPLETED = 3;
var SCRIPT_STATUS_FAILED = 4;
var invApprovedSatus = 2;

function scheduled(type) {
	
	var context = nlapiGetContext();
	var getSavedSearchId = context.getSetting('SCRIPT', SCRIPTFLD_SEARCH_PARAMETER);
	
	//Code to load the saved search
	var loadsearch = searchMoreRecords(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getSavedSearchId, null, null);
	
	if(loadsearch != '' && loadsearch != null) {
		
		for(var a = 0; a < loadsearch.length; a++) {
			
			try {
				
				if (context.getRemainingUsage() <= 500){
					nlapiYieldScript();
				}
				
				var getCurrentObj = loadsearch[a];
				var getColumns = getCurrentObj.getAllColumns();
				var getCutoverRecId = getCurrentObj.getId();
				var getCIRecord = getCurrentObj.getValue(getColumns[9]);
				var getCIStatus = getCurrentObj.getValue(getColumns[10]);
                var getInvoiceId = getCurrentObj.getValue(getColumns[11]); //added: 8/20/2020 fix
				
				if(getCIRecord != '' && getCIRecord != null) {
					
					var loadRecCI = nlapiLoadRecord(REC_TYPE_APPF_CI_RECORD, getCIRecord);
					var getCIInvoices = loadRecCI.getFieldValues(FLD_CUSTOMREC_CI_RECORD_INVOICES);
					nlapiLogExecution('Debug', 'getCIInvoices', getCIInvoices);
					
					if(getCIInvoices == '' || getCIInvoices == null || getCIInvoices == undefined)
						nlapiSubmitField(REC_TYPE_APPF_CI_RECORD, getCIRecord, FLD_CUSTOMREC_CI_RECORD_INVOICES, getInvoiceId);
					else {
						
						var invoiceArray = new Array();
						//invoiceArray = getCIInvoices;
						
						for(var k = 0; k < getCIInvoices.length; k++) {
							
							if(getCIInvoices[k] != '' && getCIInvoices[k] != null)
								invoiceArray.push(getCIInvoices[k]);
							
						}
						
						invoiceArray.push(getInvoiceId);
						
						nlapiLogExecution('Debug', 'invoiceArray', invoiceArray);
						
						nlapiSubmitField(REC_TYPE_APPF_CI_RECORD, getCIRecord, FLD_CUSTOMREC_CI_RECORD_INVOICES, invoiceArray);
						
						nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId,FLD_CUSTOMREC_CUTOVER_LINKBACK_CI, 'T');
						
					}
					
				}
				
			}
			catch(error) {
				
				nlapiSubmitField(REC_TYPE_APPF_CUTOVER_CREDIT_INV, getCutoverRecId, [FLD_CUSTOMREC_CUTOVER_STATUS, FLD_CUSTOMREC_CUTOVER_STATUS_LOG], [SCRIPT_STATUS_FAILED, error.toString()]);
				
			}
			
		}
		
	}
	
}

function searchMoreRecords(recordType, searchID, filters, columns)
{

	// create search; alternatively nlapiLoadSearch() can be used to load a saved search
	var searchRecords = null;
	if(searchID != null)
		searchRecords = nlapiLoadSearch(recordType, searchID);
	else
		searchRecords = nlapiCreateSearch(recordType, filters, columns);

	var searchResults = searchRecords.runSearch();

	// resultIndex points to record starting current resultSet in the entire results array 
	var resultIndex = 0; 
	var resultStep = 1000; // Number of records returned in one step (maximum is 1000)
	var resultSet; // temporary variable used to store the result set
	var mergedResults = [];
	do 
	{
		// fetch one result set
		resultSet = searchResults.getResults(resultIndex, resultIndex + resultStep);
		mergedResults  = mergedResults.concat(resultSet);
		// increase pointer
		resultIndex = resultIndex + resultStep;

		// process or log the results
		// once no records are returned we already got all of them
	} while (resultSet.length > 0);
	return mergedResults;
}