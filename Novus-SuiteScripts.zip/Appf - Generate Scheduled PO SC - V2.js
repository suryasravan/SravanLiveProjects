/*
* Script Name : Appf-Set Contract to SO SC
* Script Type : Scheduled
* Description : Generate Special PO for Sales Orders
* Company     : Appficiency Inc.
*/

var SPARAM_SEARCH_PARAMETER = 'custscript_appf_sched_po_savedsearch_id2';
var SPARAM_SEARCH_INDEX = 'custscript_appf_sched_po_search_index2';
var SPARAM_SO_LINE_INDEX = 'custscript_appf_so_line_index';
var SPARAM_ERROR_PO_MSG = 'custscript_appf_error_po_msg';
var SPARAM_STATUS = 'custscript_appf_sched_po_status';
var SPARAM_SCRIPT_STEP = 'custscript_appf_script_step';


var FLD_SO_PO_VENDOR = 'custcol_appf_po_vendor_name';
var FLD_SO_PO_GENERATION_COMPLETE = 'custcol_appf_po_generation_complete';
var FLD_SO_PO_GENERATION_ERROR = 'custbody_appf_po_generation_error';

var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_STARTDATEACTUAL = 'custcol_appf_startdate_custom';
var FLD_SO_LINEBUSINESS_HEADER = 'custbody_appf_lob_sourced'; //v5 addded 9/2/2020

var FLD_SO_SCHED_PO_STATUS = 'custbody_appf_sched_po_status';

var startTime = new Date().getTime();

function generateSpecialOrdercheduled(type) {
    var context = nlapiGetContext();
	var searchId = context.getSetting('SCRIPT', SPARAM_SEARCH_PARAMETER);

	var index = context.getSetting('SCRIPT', SPARAM_SEARCH_INDEX);
	if (index == null || index == '')
		index = 0;
    //nlapiLogExecution('debug', 'file index', index);
	
	var lineIndex = context.getSetting('SCRIPT', SPARAM_SO_LINE_INDEX);
	if (lineIndex == null || lineIndex == '')
		lineIndex = 1;
	
	var errorPOMsg = context.getSetting('SCRIPT', SPARAM_ERROR_PO_MSG) || '';
	var status = context.getSetting('SCRIPT', SPARAM_STATUS) || '';
	var scriptStep = context.getSetting('SCRIPT', SPARAM_SCRIPT_STEP) || 1;
	
    
    if(searchId){
        var objSearch= nlapiLoadSearch(null, searchId);
    	var filters = objSearch.getFilters();
    	var columns = objSearch.getColumns();
    	var ssType = objSearch.getSearchType();
    	var searchResults = getAllSearchResults(ssType, filters, columns);
    	
    	if (searchResults != null && searchResults != '') {
    		for (var s=index; s<searchResults.length; s++) {
    			var result = searchResults[s];
                var recType = result.getRecordType();
                var idSalesOrder = result.getId();
                var columns = result.getAllColumns();
    			var idSalesOrder = result.getValue(columns[0]);
    			var idCustomer = result.getValue(columns[1]);
    			recType= 'salesorder';
    			
    			//log.debug('sales order:', idSalesOrder);
    			nlapiLogExecution('DEBUG', 'sales order:',idSalesOrder);
                //check time
                var endTime = new Date().getTime();
                //Calculate the Time Elapsed between End Time and Start Time

                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                //nlapiLogExecution('DEBUG', 'TIME ELAPSED Outside',timeElapsed);
                if( timeElapsed > 1500 || (context.getRemainingUsage() <= 1000 && parseInt(s)+1 < searchResults.length) ) {
                    var params = {};
                    params[SPARAM_SEARCH_PARAMETER] = searchId;
                    params[SPARAM_SEARCH_INDEX] = (s+1);
                    nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                    break;
                }else{
                	//var scriptStep = 1;
        	    	var errorMsg = '';
                    //load sales order
                    //nlapiLogExecution('debug', 'remaining usage before', context.getRemainingUsage());
                    var recSO = nlapiLoadRecord(recType,idSalesOrder);
                    var status = recSO.getFieldValue(FLD_SO_SCHED_PO_STATUS);
                    
                    //============STEP 1
                    if(scriptStep == 1 || status == ''){
                    	//var recSO = nlapiLoadRecord(recType,idSalesOrder);
                        var nLines = recSO.getLineItemCount('item');
                        
                        for(var x = lineIndex; x <= nLines; x++){
                            var idVendor = recSO.getLineItemValue('item', FLD_SO_PO_VENDOR, x);
                            //var idNativeVendor = recSO.getLineItemValue('item', 'povendor', x);
                        	var nQty = recSO.getLineItemValue('item', 'quantity', x);
                        	var createdPO =recSO.getLineItemValue('item', 'createdpo', x);
                        	//nlapiLogExecution('debug', 'createdPO step 1', createdPO);
                        	
                        	
                        	if(createdPO == null || createdPO == ''){
                        		recSO.selectLineItem('item',x);
                            	if(nQty == 0 || nQty == '0' || nQty == 0.0){
                            		nlapiLogExecution('debug', 'set to 0 step 1', 'set line qty to 0');
                            		//recSO.setLineItemValue('item', 'quantity', i, '0.01');
                            		recSO.setCurrentLineItemValue('item','quantity','0.01');
                            	}
                               // recSO.setCurrentLineItemValue('item','povendor',idNativeVendor);
                                recSO.setCurrentLineItemValue('item','porate',1);
                                recSO.setCurrentLineItemValue('item','createpo','SpecOrd');
                                
                                // 1.4 Changes
                                //Start Date (RR) (Line) = Start Date (Actual)
                                var startdateActual = recSO.getLineItemValue('item', FLD_COL_STARTDATEACTUAL, x);
                                var startDateRR = recSO.getLineItemValue('item', FLD_COL_STARTDATERR, x);
                                
                                if (!isNullOrEmpty(startdateActual) && isNullOrEmpty(startDateRR)) {
                                	nlapiLogExecution('debug', 'startdateActual', startdateActual);
                                	//recSO.setCurrentLineItemValue('item', FLD_COL_STARTDATERR, startdateActual);
                                	recSO.setCurrentLineItemValue('item',FLD_COL_STARTDATERR,startdateActual);
                                	recSO.setLineItemValue('item', FLD_COL_STARTDATERR, x, startdateActual);
                                }
                                var lineBusinessHeader = recSO.getFieldValue(FLD_SO_LINEBUSINESS_HEADER)
                               
                                //v.5 9/2/2020 add
                                if(!isNullOrEmpty(lineBusinessHeader) ){
                                	// nlapiLogExecution('debug', 'lineBusinessHeader', lineBusinessHeader);
                                	//recSO.setLineItemValue('item','class',i,lineBusinessHeader);
                                	recSO.setCurrentLineItemValue('item','class',lineBusinessHeader);
                                	recSO.setLineItemValue('item', 'class', x, lineBusinessHeader);
                                }

                                recSO.commitLineItem('item');
                        	}

                            
                            //check time
                            var endTime = new Date().getTime();
                            //Calculate the Time Elapsed between End Time and Start Time
                            var timeElapsed = (endTime*0.001) - (startTime*0.001);

                            //nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE step 1',timeElapsed);
                            if(timeElapsed > 1500){ //25 minutes
                            	//reschedule

                                recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, '');
                                //save record then reschedule
                                nlapiSubmitRecord(recSO);
                                
                                params[SPARAM_SEARCH_PARAMETER] = searchId;
                                params[SPARAM_SEARCH_INDEX] = s;
                                params[SPARAM_SO_LINE_INDEX] = x+1;
                                params[SPARAM_ERROR_PO_MSG] = '';
                                params[SPARAM_STATUS] = '';
                                params[SPARAM_SCRIPT_STEP] = 1;
                                
                                nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                break;
                            	
                            }else{
                            	if(x == nLines){  //if last line, set status 
                            		//check time
                            		recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, 1);
                            		
                                    //check time
                                    var endTime = new Date().getTime();
                                    //Calculate the Time Elapsed between End Time and Start Time

                                    var timeElapsed = (endTime*0.001) - (startTime*0.001);

                                    //nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 1',timeElapsed);
                            		
                                    if(timeElapsed > 1500){ //25 minutes	
                                    	//reschedule only
                                        params[SPARAM_SEARCH_PARAMETER] = searchId;
                                        params[SPARAM_SEARCH_INDEX] = s;
                                        params[SPARAM_SO_LINE_INDEX] = x;
                                        params[SPARAM_ERROR_PO_MSG] = '';
                                        params[SPARAM_STATUS] = '';
                                        params[SPARAM_SCRIPT_STEP] = 1;
                                        nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                        break;
                                    }else{
                                		try{
                                			recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, 1);
                                			nlapiSubmitRecord(recSO);
                                			nlapiLogExecution('DEBUG', 'Set PO Fields','Set PO Fields');
                                			scriptStep = 2;
                                		}catch(e1){
                                			errorMsg = e1.message;
                                			nlapiLogExecution('DEBUG', 'Error setting PO Rate and Vendor', e1.message + ' idSalesOrder='+idSalesOrder);
                                		}
                                    }
                            	}
                            }
                        }
                    }  //==========end of STEP 1
                    nlapiLogExecution('DEBUG', 'scriptStep',scriptStep);

                    if(scriptStep == 2 || status == 1){
                    	//return;
                        //========STEP 2
                        //check time
                        var endTime = new Date().getTime();
                        //Calculate the Time Elapsed between End Time and Start Time

                        var timeElapsed = (endTime*0.001) - (startTime*0.001);

                        nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE before step 2',timeElapsed);
                        if(timeElapsed > 1500){ 
                        	//reschedule
                            params[SPARAM_SEARCH_PARAMETER] = searchId;
                            params[SPARAM_SEARCH_INDEX] = s;
                            params[SPARAM_SO_LINE_INDEX] = 1;
                            params[SPARAM_ERROR_PO_MSG] = '';
                            params[SPARAM_STATUS] = 1;
                            params[SPARAM_SCRIPT_STEP] = 2;
                            
                            nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                            break;
                        	
                        }else{
                            //load record 
                            var recSO = nlapiLoadRecord(recType,idSalesOrder);
                            var status = recSO.getFieldValue(FLD_SO_SCHED_PO_STATUS);
                            nlapiLogExecution('DEBUG', 'step 2 status',status + ' errorPOMsg='+errorPOMsg);

                            if(status == 1){
                            	//get all vendor
                            	 var nLines = recSO.getLineItemCount('item');
                                 var aVendors = [];
                                 
                                 if(errorPOMsg == null || errorPOMsg == ''){
                                	 var oHashedData = new Object();
                                     for(var x = 1; x <= nLines; x++){
                                    	 var idVendor = recSO.getLineItemValue('item', 'povendor', x);
                                    	 var newqty = recSO.getLineItemValue('item', 'quantity', x);
                                    	 var newporate = recSO.getLineItemValue('item', 'porate', x);
                                    	 //aVendors.push(idVendor);
                                    	// var createpo1 = salesOrderRec.getCurrentLineItemValue('item', 'createpo');
                                    	 var createpo1 = recSO.getLineItemValue('item', 'createpo', x);
                                    	 nlapiLogExecution('DEBUG', 'createpo1',createpo1);
                                    	 var oCols = new Object();
                                         oCols['idVendor'] = idVendor;
                                         oCols['x'] = x;
                                         oCols['newqty'] = newqty;
                                         oCols['newporate'] = newporate;
  
                                         
                                         var aDataDetails = oHashedData[idVendor] || new Array();
                                         aDataDetails.push(oCols);
                                         oHashedData[idVendor] = aDataDetails;
                                     }
                                     
                                     nlapiLogExecution('DEBUG', 'oHashedData',JSON.stringify(oHashedData));
                            		//generate PO
                                     
                                     //for(p = 0; p < aVendors.length; p++){
                                     for(var idVendor in oHashedData){
                                  	    var aRows = oHashedData[idVendor];
                                 	    for(var z = 0; z < aRows.length; z++){
                                 	    	var oCol = aRows[z];
                                 	    	//log.debug('SO ID = ' + oCol['getSOID'] + 'getCutoverRecId = ' + oCol['getCutoverRecId'] + 'getSOLineID = ' + oCol['getSOLineID']);
                                 	    	//log.debug('getCutoverRecId = ' + oCol['getCutoverRecId']);
                                 	    	//log.debug('getSOLineID = ' + oCol['getSOLineID']);
                                 	    	
                                 	    	nlapiLogExecution('DEBUG', 'vendor ='+ idVendor +'x'+ oCol['x'] + ' qty='+oCol['newqty'] + 'porate='+oCol['newporate']);
                                 	    }
                                    	 
                                    	 
                             			try{
                            		    	var params = {
                            		    		    'recordmode' : 'dynamic',
                            		    		    'soid' : idSalesOrder,
                            		    		    'specord' : 'T', 
                            		    		    'custid' : idCustomer,
                            		    		    'entity': idVendor,
                            		    		    'poentity':idVendor
                            		    		};   

                            		    	var purchaseOrder = nlapiCreateRecord('purchaseorder', params);
                            		    	nlapiLogExecution('debug', 'purchaseOrder', purchaseOrder + ' idVendor='+idVendor);
                            		    	var nLines = purchaseOrder.getLineItemCount('item');
                            		    	nlapiLogExecution('debug', 'nLines', nLines);
                            		    	for(c = 1; c <= nLines; c++){
                            		    		nlapiLogExecution('debug', 'item', purchaseOrder.getLineItemValue('item', 'item', c));
                            		    	}
                            		    	var poId = nlapiSubmitRecord(purchaseOrder);
                            		    	
                            		    	//var recSO = nlapiLoadRecord('purchaseorder',poId);
                            		    	
                            		    	scriptStep=3;
                                			nlapiLogExecution('DEBUG', 'PO Created','PO Created');
                            			}catch(e2){
                            				errorMsg += '\n'+e2.message;
                            				nlapiLogExecution('DEBUG', 'Error creating Special PO', e2.message + ' idSalesOrder='+idSalesOrder)
                                            //save error
                            				
                            			   //check time
                                           var endTime = new Date().getTime();
                                           //Calculate the Time Elapsed between End Time and Start Time

                                           var timeElapsed = (endTime*0.001) - (startTime*0.001);

                                           nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 2',timeElapsed);
                                        		
                                           if(timeElapsed > 1500){ //25 minutes
                                        	   //reschedule
                                               params[SPARAM_SEARCH_PARAMETER] = searchId;
                                               params[SPARAM_SEARCH_INDEX] = s;
                                               //params[SPARAM_SO_LINE_INDEX] = 1;
                                               params[SPARAM_ERROR_PO_MSG] = e2.message;
                                               params[SPARAM_STATUS] = 1;
                                               params[SPARAM_SCRIPT_STEP] = 2;
                                               
                                               nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                               break;
                                        	   
                                        	   
                                        	   
                                           }else{
                               					//set back to 0
                               					var recSO = nlapiLoadRecord(recType,idSalesOrder);
                               				    var nLines = recSO.getLineItemCount('item');
                               				    
                               				    for(var x = 1; x <= nLines; x++){
                               				    	var nQty = recSO.getLineItemValue('item', 'quantity', x);
                               				    	if(nQty == 0.01 || nQty == '.01' || nQty == .01){
                                       					recSO.selectLineItem('item',x);
                                       					
                                       					recSO.setCurrentLineItemValue('item','quantity',0);
                                       					recSO.commitLineItem('item');
                                       				

                               				    	}

                               				    }
                               					recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, '');
                               					recSO.setFieldValue(FLD_SO_PO_GENERATION_ERROR, e2.message);
                               					nlapiSubmitRecord(recSO);
                               					
                               					scriptStep = 0;
                               				//nlapiSubmitField('salesorder', idSalesOrder, FLD_SO_PO_GENERATION_ERROR, e2.message );
                                           }
                            			}
                                     }
                                 }else{
                                	//if error creating PO
                 					//set back to 0
                 					var recSO = nlapiLoadRecord(recType,idSalesOrder);
                   				    var nLines = recSO.getLineItemCount('item');
                   				    
                   				    for(var x = 1; x <= nLines; x++){
                   				    	var nQty = recSO.getLineItemValue('item', 'quantity', x);
                   				    	if(nQty == 0.01 || nQty == '.01' || nQty == .01){
                           					recSO.selectLineItem('item',x);
                           					
                           					recSO.setCurrentLineItemValue('item','quantity',0);
                           					recSO.commitLineItem('item');
                           				

                   				    	}

                   				    }
                 					recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, '');
                 					recSO.setFieldValue(FLD_SO_PO_GENERATION_ERROR, e2.message);
                 					nlapiSubmitRecord(recSO);
                 					
                 					scriptStep = 0;
                                 }
                            }
                        }
                    }
                    nlapiLogExecution('DEBUG', 'scriptStep',scriptStep);
                    if(scriptStep == 3 && status == 1){
                    	return;
                        //========STEP 3
                        //check time
                        var endTime = new Date().getTime();
                        //Calculate the Time Elapsed between End Time and Start Time

                        var timeElapsed = (endTime*0.001) - (startTime*0.001);

                        nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE before step 3',timeElapsed);
                        
                        if(timeElapsed > 1500){ 
                        	//reschedule
                            params[SPARAM_SEARCH_PARAMETER] = searchId;
                            params[SPARAM_SEARCH_INDEX] = s;
                            params[SPARAM_SO_LINE_INDEX] = 1;
                            params[SPARAM_ERROR_PO_MSG] = '';
                            params[SPARAM_STATUS] = 1;
                            params[SPARAM_SCRIPT_STEP] = 3;
                            
                            nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                            break;
                        	
                        }else{
                            //load record 
                            var recSO = nlapiLoadRecord(recType,idSalesOrder);
                            var status = recSO.getFieldValue(FLD_SO_SCHED_PO_STATUS);
                    		if(status == 1){
                                //then load again to set the lines to 0
                                var recSO = nlapiLoadRecord('salesorder',idSalesOrder);
                                
                                var nLines = recSO.getLineItemCount('item');
                                
                                for(var x = 1; x <= nLines; x++ ){
                                	var nQty = recSO.getLineItemValue('item', 'quantity', x);
                                	var createdPO =recSO.getLineItemValue('item', 'createdpo', x);
                                	nlapiLogExecution('debug', 'createdPO', createdPO);
                                    if(createdPO){
                                        if(nQty == 0.01 || nQty == '.01' || nQty == .01){
                                        	recSO.setLineItemValue('item', 'quantity', x, '0');
                                        }
                                    }else{
                                    	nlapiLogExecution('debug', 'test log jumped to reset 0', 'test log jumped to reset 0');
                                    }

                                    recSO.setLineItemValue('item', FLD_SO_PO_GENERATION_COMPLETE, x, 'T');
                                }
                        		try{
                        			
                        			//check time
                                    var timeElapsed = (endTime*0.001) - (startTime*0.001);

                                    nlapiLogExecution('DEBUG', 'TIME ELAPSED INSIDE saving step 3',timeElapsed);
                                 		
                                    if(timeElapsed > 1500){ //25 minutes
                                 	   //reschedule
                                        params[SPARAM_SEARCH_PARAMETER] = searchId;
                                        params[SPARAM_SEARCH_INDEX] = s;
                                        //params[SPARAM_SO_LINE_INDEX] = 1;
                                        params[SPARAM_ERROR_PO_MSG] = '';
                                        params[SPARAM_STATUS] = 1;
                                        params[SPARAM_SCRIPT_STEP] = 3;
                                        
                                        nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                        break;
                                 	   
                                 	   
                                 	   
                                    }else{
                            			recSO.setFieldValue(FLD_SO_SCHED_PO_STATUS, ''); //complete
                            			nlapiSubmitRecord(recSO);
                            			nlapiLogExecution('DEBUG', 'Processed success',' idSalesOrder='+idSalesOrder);
                                        scriptStep = 0;
                                    }


                        		}catch(e3){
                        			errorMsg += '\n'+e3.message;
                        			nlapiLogExecution('DEBUG', 'Error saving so step 3', e3.message + ' idSalesOrder='+idSalesOrder)
                        		    //save error
                        			/*nlapiSubmitField('salesorder', idSalesOrder, FLD_SO_PO_GENERATION_ERROR, e2.message );*/
                        			
                        			//check time
                                    var timeElapsed = (endTime*0.001) - (startTime*0.001);
                        			//reschedule
                        			if(timeElapsed > 1500){
                                        params[SPARAM_SEARCH_PARAMETER] = searchId;
                                        params[SPARAM_SEARCH_INDEX] = s;
                                        //params[SPARAM_SO_LINE_INDEX] = 1;
                                        params[SPARAM_ERROR_PO_MSG] = '';
                                        params[SPARAM_STATUS] = 1;
                                        params[SPARAM_SCRIPT_STEP] = 3;
                                        
                                        nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
                                        break;
                        			}
                        			
                        			scriptStep == 0

                        		}

                    		}
                        	
                        }
                    }
                    if(scriptStep == 0){ //do nothing
                    	//loop 
                    	scriptStep = 1;
                    }
                }
    			//check time
                var timeElapsed = (endTime*0.001) - (startTime*0.001);
                nlapiLogExecution('debug', 'remaining usage after', context.getRemainingUsage() + ' idSalesOrder='+idSalesOrder + ' timeElapsed='+timeElapsed);
    		}
    	}
    }


}

function getAllSearchResults(record_type, filters, columns) {
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);

    var searchRan = search.runSearch()
    ,	bolStop = false
    ,	intMaxReg = 1000
    ,	intMinReg = 0
    ,	result = [];

    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
        // First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        // If the execution reach the the last result set stop the execution
        if (extras.length < 1000) {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array) {
    return target.concat(array); // TODO: use _.union
}


function isNullOrEmpty(data) {
    return (data == null || data == '');
}