/*
 *Script Name: Appf-Update PWP Status UE
 *Script Type: User Event
 *Description: This script updates Vendor Reconciliation Status on PWP record on update
 *Company 	: Appficiency Inc.
 * Version      Date            Author           Remarks
 * 1.00       	9 March 2020                     set the Field VENDOR RECONCILIATION STATUS
 * 1.1			6 Nov 2020		MJ De Asis		update the logic for invoicing status
 * 1.3			7 Nov 2020		MJ De Asis		fixes the ready for pwp checkbox
 */
var FLD_COL_PWP_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_VEND_BILL_LINE_ID = 'custcol_appf_vendorbill_line_id';
var FLD_COL_SO_LINE_ID = 'custcol_appf_line_id';
var FLD_COL_VEND_BILL_LINE_PAYMENT_AMOUNT = 'custcol_appf_pwp_bill_line_amt_paid';
var FLD_COL_DISCREPANTS = 'custcol_appf_discrepant';
var FLD_COL_DISCREPANCY = 'custcol_appf_discrepancy_action';
var FLD_PAYMENT_TYPE = 'custbody_appf_vendor_payment_type';
var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_PWP_SO_LINE_ID = 'custrecord_appf_pwp_so_line_id';
var FLD_PWP_VEND_BILL_LINK = 'custrecord_appf_pwp_vb_link';
var FLD_PWP_VEND_BILL_AMT = 'custrecord_appf_pwp_vb_amount';
var FLD_PWP_VEND_BILL_LINE_ID = 'custrecord_appf_pwp_vb_line_id';
var FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_bill_line_amt_paid';
var FLD_PWP_VVCCP_LINKS = 'custrecord_appf_pwp_vvccp_link';
var FLD_PWP_VEND_STATUS = 'custrecord_appf_pwp_vendor_recon_status';
var FLD_PWP_READY_FOR_PAYMENT = 'custrecord_appf_pwp_ready_for_payment';
var FLD_CM_AMT = 'custrecord_appf_pwp_ven_credit_amt';
var FLD_CM_AMT = 'custrecord_appf_pwp_ven_credit_amt';
var FLD_SO_AMT = 'custrecord_appf_pwp_so_line_amount';
var FLD_PWP_DICOUNT_AMT = 'custrecord_appf_pwp_discount_amt';
var FLD_PWP_CREDIT_MEMO_AMT = 'custrecord_appf_pwp_cm_amount';
var FLD_PWP_POP_REQ = 'custrecord_appf_pwp_pop_required';
var FLD_PWP_POP_RECEIES = 'custrecord_appf_pwp_pop_received';
//custrecord_appf_pwp_ready_for_payment
var FLD_PWP_INV_LINE_AMOUNT = 'custrecord_appf_pwp_inv_line_amount';
var SCRIPT_UPDATE_PWP_FROM_VB_SC = 'customscript_appf_update_pwp_rec_vb_sc';
var SPARAM_VEND_BILL_ID = 'custscript_appf_vend_bill_id';
var SPARAM_UPDATE_PWP_VEND_BILL_SS = 'custscript_appf_update_pwp_vend_bill_ss';
var FLD_PWP_BILL_CRED_AMT = 'custrecord_appf_pwp_ven_credit_amt';
var FLD_PWP_INV_LINE_AMOUNT = 'custrecord_appf_pwp_inv_line_amount';
var FLD_PWP_INV_LINE_AMOUNT_PAID = 'custrecord_appf_pwp_inv_line_amt_paid';
var FLD_PWP_INV_LINE_DISCOUNT_AMOUNT = 'custrecord_appf_pwp_discount_amt';
var FLD_PWP_INV_STATUS = 'custrecord_appf_pwp_client_inv_status';
var FLD_COL_DISCREPANCY_TYPE = 'custcol_appf_discrepancy_type';
var FLD_PWP_INV_LINE_DISCOUNT_AMOUNT = 'custrecord_appf_pwp_discount_amt';
var FLD_PWP_TRIGGER_OUTBOUND_INTEGRATION = 'custrecord_appf_trigger_ob_integration';
var OBJ_DISCREPANCY_TYPE_BILL = {};
OBJ_DISCREPANCY_TYPE_BILL.clearedDiscrepantButMarkedReadyforPayment = '21'; //'19';
OBJ_DISCREPANCY_TYPE_BILL.clearedNoDiscrepancy = '20'; // '18';
OBJ_DISCREPANCY_TYPE_BILL.clearedWithinTwentyFiveDollarThreshold = '24'; //'22';
OBJ_DISCREPANCY_TYPE_BILL.discrepantAmountHigher = '23'; //'17';
OBJ_DISCREPANCY_TYPE_BILL.discrepantCircCPMRate = '7';
OBJ_DISCREPANCY_TYPE_BILL.discrepantCircHigher = '2';
OBJ_DISCREPANCY_TYPE_BILL.discrepantCircLower = '10';
OBJ_DISCREPANCY_TYPE_BILL.discrepantUnitRateHigher = '5';
OBJ_DISCREPANCY_TYPE_BILL.discrepantUnitRateLower = '11';
OBJ_DISCREPANCY_TYPE_BILL.pendingDiscrepancyEvaluation = '19'; //'21';
OBJ_DISCREPANCY_TYPE_BILL.rejectedPermanentReject = '22'; //'20';
var VENDOR_RECONCILIATION_STATUS_UNRECONCILED = '1';
var VENDOR_RECONCILIATION_STATUS_DISCREPANT = '2';
var VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE = '3';
var VENDOR_RECONCILIATION_STATUS_PENDING_AUTHORIZATION = '4';
var VENDOR_RECONCILIATION_STATUS_PENDING_PAYMENT = '5';
var VENDOR_RECONCILIATION_STATUS_PAID = '6';
var VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST = [];
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantCircCPMRate);
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantCircHigher);
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantCircLower);
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantUnitRateHigher);
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantUnitRateLower);
VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.discrepantAmountHigher);
var VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST = [];
VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.clearedDiscrepantButMarkedReadyforPayment);
VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.clearedNoDiscrepancy);
VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.clearedWithinTwentyFiveDollarThreshold);
VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST.push(OBJ_DISCREPANCY_TYPE_BILL.rejectedPermanentReject);
var STATUS_INV_PAYMENT_PENDING = '4'
var STATUS_INV_PARTIALLY_PAID = '5'
var STATUS_INV_PAID = '7'
var SEND_TO_PAY = '1'
var PAYMENT_AMEX = '1'
var PAYMENT_MASTERCARDS = '3'
var PAYMENT_VISA = '9'
var PAYMENT_CHECK = '2'
var PAYMENT_WIRE = '4'
var PAYMENT_ACH = '5'

//var VENDOR_RECONCILIATION_STATUS_PAID='7'
function updatePWPVBAfterSubmit(type) {
	var context = nlapiGetContext();
	if (type != 'delete') {
		var pwpRecId = nlapiGetRecordId();
		try {
			var pwpRecord = nlapiLoadRecord(CUSTOM_RECORD_PWP, pwpRecId);
			var pwpStatus = pwpRecord.getFieldValue(FLD_PWP_VEND_STATUS);
			var readyForPayment = pwpRecord.getFieldValue(FLD_PWP_READY_FOR_PAYMENT);
			var pwpInvLineAmt = pwpRecord.getFieldValue(FLD_PWP_INV_LINE_AMOUNT);
			if (pwpInvLineAmt == null || pwpInvLineAmt == '') pwpInvLineAmt = 0;
			var pwpDisountLineAmt = pwpRecord.getFieldValue(FLD_PWP_INV_LINE_DISCOUNT_AMOUNT);
			if (pwpDisountLineAmt == null || pwpDisountLineAmt == '') pwpDisountLineAmt = 0;
			//var pwpInvLineAmt=pwpRecord.getFieldValue(FLD_PWP_INV_LINE_AMOUNT);

			/// v1.3
			var pwpLineAmtPaid = pwpRecord.getFieldValue(FLD_PWP_INV_LINE_AMOUNT_PAID);
			//if (pwpLineAmtPaid == null || pwpLineAmtPaid == '') pwpLineAmtPaid = 0;
			pwpLineAmtPaid = nvl(pwpLineAmtPaid, parseFloat(pwpLineAmtPaid), 0);
			var soAmount = pwpRecord.getFieldValue(FLD_SO_AMT);
			//if (soAmount == null || soAmount == '') soAmount = 0;
			soAmount = nvl(soAmount, parseFloat(soAmount), 0);
			var discountAmt = pwpRecord.getFieldValue(FLD_PWP_DICOUNT_AMT);
			//if (discountAmt == null || discountAmt == '') discountAmt = 0;
			discountAmt = nvl(discountAmt, parseFloat(discountAmt), discountAmt);
			var creditMemoAmt = pwpRecord.getFieldValue(FLD_PWP_CREDIT_MEMO_AMT);
			//if (creditMemoAmt == null || creditMemoAmt == '') creditMemoAmt = 0;
			creditMemoAmt = nvl(creditMemoAmt, parseFloat(creditMemoAmt), 0);
			var invPaidAmt = pwpLineAmtPaid;
			var popRequirs = pwpRecord.getFieldValue(FLD_PWP_POP_REQ);
			var popReceives = pwpRecord.getFieldValue(FLD_PWP_POP_RECEIES);

			var amount1 = (soAmount + discountAmt).toFixed(2);
			var amount2 = (invPaidAmt + creditMemoAmt).toFixed(2);
			nlapiLogExecution('DEBUG', 'Amount1 ' + amount1, 'Amount2 ' + amount2);

			if (amount1 == amount2) {
				if (popRequirs != 'T') {
					pwpRecord.setFieldValue(FLD_PWP_READY_FOR_PAYMENT, 'T')
				} else {
					if (popReceives == 'T') {
						pwpRecord.setFieldValue(FLD_PWP_READY_FOR_PAYMENT, 'T')
					}
				}
			}
			var totalDiscAmt = 0
			totalDiscAmt = parseFloat(pwpInvLineAmt) + parseFloat(pwpDisountLineAmt);

			/// v1.1
			totalDiscAmt = totalDiscAmt.toFixed(2);
			var totalInvPaid = parseFloat(pwpLineAmtPaid).toFixed(2);
			nlapiLogExecution('DEBUG', totalDiscAmt, totalInvPaid);
			nlapiLogExecution('DEBUG', 'Diff', totalInvPaid == totalDiscAmt);
			if (totalDiscAmt > 0 && totalInvPaid == 0) pwpRecord.setFieldValue(FLD_PWP_INV_STATUS, STATUS_INV_PAYMENT_PENDING);
			if ((totalDiscAmt > 0 && totalInvPaid > 0) && (totalInvPaid < totalDiscAmt)) pwpRecord.setFieldValue(FLD_PWP_INV_STATUS, STATUS_INV_PARTIALLY_PAID)
			if ((totalDiscAmt > 0 && totalInvPaid > 0) && (totalInvPaid == totalDiscAmt)) pwpRecord.setFieldValue(FLD_PWP_INV_STATUS, STATUS_INV_PAID)

			// **** Logic to set VENDOR RECONCILIATION STATUS ****
			var vendorBillAmt = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_AMT);
			if (vendorBillAmt == null || vendorBillAmt == '') vendorBillAmt = 0;
			var vendorBillLinePaymentAmt = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_LINE_PAYMENT_AMT);
			if (vendorBillLinePaymentAmt == null || vendorBillLinePaymentAmt == '') vendorBillLinePaymentAmt = 0;
			var vendorBillLinks = pwpRecord.getFieldValues(FLD_PWP_VEND_BILL_LINK);
			var hasVendorBills = pwpRecord.getFieldValue(FLD_PWP_VEND_BILL_LINK);
			var isDiscrepant = false
			var counter = 0
			var vendorBillLinksCount = 0;
			if (parseFloat(vendorBillAmt) == 0) {
				// Un-Reconciled STATUS
				pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_UNRECONCILED);
			}
			if (hasVendorBills != null && hasVendorBills != '') {
				vendorBillLinksCount = vendorBillLinks.length;
				var fils = [];
				fils.push(new nlobjSearchFilter('internalid', null, 'anyof', vendorBillLinks));
				fils.push(new nlobjSearchFilter('type', null, 'anyof', 'VendBill'));
				fils.push(new nlobjSearchFilter('mainline', null, 'is', 'F'));
				var cols = [];
				cols.push(new nlobjSearchColumn(FLD_COL_DISCREPANCY_TYPE));
				cols.push(new nlobjSearchColumn(FLD_PAYMENT_TYPE));
				var vendorBillsFromPWPSearchResults = nlapiSearchRecord('transaction', null, fils, cols);
				var vbPaymentType = '';
				if (vendorBillsFromPWPSearchResults != null && vendorBillsFromPWPSearchResults != '') {
					if (vendorBillsFromPWPSearchResults.length > 0) {
						for (var i = 0; i < vendorBillsFromPWPSearchResults.length; i++) {
							var col = vendorBillsFromPWPSearchResults[i];
							vbPaymentType = col.getValue(FLD_PAYMENT_TYPE);
							var discrepancyType = col.getValue(FLD_COL_DISCREPANCY_TYPE);
							if (VENDOR_RECONCILIATION_STATUS_DISCREPANT_DISCREPANCY_LIST.indexOf(discrepancyType) != -1) isDiscrepant = true;
							if (VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE_DISCREPANCY_LIST.indexOf(discrepancyType) != -1) counter++;
						}
					}
				}
				if (vendorBillAmt != 0 && isDiscrepant == true) {
					// Discrepant Status
					pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_DISCREPANT)
				} else {
					if (readyForPayment != 'T') {
						// Reconciled - Pending Media Update STATUS
						pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_RECONCILED_PENDING_MEDIA_UPDATE)
					}
				}
				if ((counter == vendorBillLinksCount) && (vbPaymentType == PAYMENT_AMEX || vbPaymentType == PAYMENT_MASTERCARDS || vbPaymentType == PAYMENT_VISA) && (readyForPayment == 'T')) {
					// Pending Authorization STATUS
					pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_PENDING_AUTHORIZATION)
				}
				// shravan 17-aug-2022 added "ACH" condition for Pending Payment status
				if ((counter == vendorBillLinksCount) && (vbPaymentType == PAYMENT_ACH || vbPaymentType == PAYMENT_WIRE || vbPaymentType == PAYMENT_CHECK) && (readyForPayment == 'T')) {
					// Pending Payment STATUS
					pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_PENDING_PAYMENT)
				}
				if (parseFloat(vendorBillAmt) != 0 && isDiscrepant == false && parseFloat(vendorBillAmt) == parseFloat(vendorBillLinePaymentAmt)) {
					// PAID STATUS
					pwpRecord.setFieldValue(FLD_PWP_VEND_STATUS, VENDOR_RECONCILIATION_STATUS_PAID)
				}
			}
			pwpRecord.setFieldValue(FLD_PWP_TRIGGER_OUTBOUND_INTEGRATION, 'T');
			var pwpId = nlapiSubmitRecord(pwpRecord, true, true);
			nlapiLogExecution('DEBUG', 'pwpId', pwpId);
		} catch (e) {
			if (e instanceof nlobjError) nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails())
			else nlapiLogExecution('DEBUG', 'unexpected error', e.toString())
		}
	}
}

function nvl(data, data1, data2) {
	if (data == null || data == '') {
		return data2;
	}
	return data1;
}

function eliminateDuplicates(arr) {
	var i,
		len = arr.length,
		out = [],
		obj = {};
	for (i = 0; i < len; i++) {
		obj[arr[i]] = 0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}
