var SPARAM_VVCCP_PROCESS_APPROVED_RECORDS='custscript_vvccp_process_master_approved';
	 var SPARAM_VVCCP_PROCESS_REJECT_RECORDS='custscript_vvccp_process_master_reject';
	 var SPARAM_VVCCP_MASTER_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
	 var SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH='customscript_vvccp_approve_custmization';
	 var SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH='customscript_appf_vvccp_scheduled_reject';
	var SPARAM_VVCCP_MASTER_BATCH_LINK_ID='custscript_vvccp_exec_batch_id';
	var FLD_MASTER_BATCH_SENT_FOR_PROCESSING = 'custrecord_appf_sent_for_processing';
	var CUSTOMRECORD_MASTER_BATCH = 'customrecord_appf_vvccp_batch_master';
	
	var CUSTOM_RECORD_VVCCP_BATCH ='customrecord_appf_vvccp_batch';
	 
var FLD_VVCCP_BATCH_UNDER_PROCESSING_DONE = 'custrecord_appf_vvccp_underproc_done';	 
var FLD_VVCCP_BATCH_VENDOR_BILLS = 'custrecord_appf_vvccp_vendor_bills';
var FLD_VVCCP_BATCH_VENDOR_CREDITS = 'custrecord_appf_vvccp_vendor_credits';
var FLD_VVCCP_STATUS = 'custbody_appf_vvccp_status';
var SPARAM_VVCCP_BATCH_REC_ID = 'custscript_vvccp_batch_rec_id';
var SPARAM_FILE_INDEX='custscript_reject_appf_file_index';
var CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD='customrecord_appf_vvccp_batch_master';
 	var FLD_BATCH_AUTHORIZATION_AMOUNT='custrecord_appf_vvccp_batch_auth_amt';
 	var FLD_BATCH_SUBSIDIARY='custrecord_appf_vvccp_mbatch_subsidiary';
 	var FLD_TRANSACTIONS_MOVED_UNDER_PROCESSING='custrecord_appf_transactions_under_proc';
 	var FLD_MASTER_DATA_FILE='custrecord_appf_vvccp_master_file';
 	var FLD_BILL_LINE_TO_PROCESS='custrecord_appf_vvccp_master_bills';
 	var FLD_CREDIT_LINES_TO_PROCESS='custrecord_appf_vvccp_master_credits';
 	var FLD_CREDIT_LINE_PROCESSED='custrecord_appf_vvccp_master_credsmarked';
 	var FLD_BILL_LINES_PROCESSED='custrecord_appf_vvccp_master_billsmarked';
 	var FLD_BILL_DATA_FILE='custrecord_appf_vvccp_master_bill_data';
 	var FLD_MASTER_CREDIT_DATA_FILE='custrecord_appf_vvccp_master_credit_data'
 	var FLD_PROCESSED_PERCENT='custrecord_appf_vvccp_master_processed';
 	var FLD_BILL_OR_CREDIT_UPDATE_ERROR_FILE='custrecord_appf_master_update_errorfile'
 	var FLD_NUMBER_OF_AUTHORIZATION_GENERATED='custrecord_appf_vvccp_mast_auth_created';
 	var FLD_NUMBER_OF_AUTHORIZATION_TO_GENERATE='custrecord_appf_vvccp_mast_auth_to_gen';
 	var FLD_AUTHORIZATION_CREATED_SUCCESSFULLY='custrecord_appf_vvccp_master_auth_succes';
 	var FLD_APPROVAL_STATUS='custrecord_appf_vvccp_master_approvestat';
 	var FLD_TRANSACTION_SET_TO_READY_FOR_PROCESSING='custrecord_appf_trans_ready_for_process';
 	var FLD_CREDIT_LINES_UNPROCESSED='custrecord_appf_credit_lines_unprocessed';
 	var FLD_BILLS_LINES_UNPROCESSED='custrecord_appf_bill_lines_unprocessed';
 	var FLD_REJECTION_PERCENTAGE='custrecord_appf_rejection_percentage';
 	var FLD_BILL_OR_BILLCREDIT_REVERSAL_ERROR_FILE='custrecord_appf_master_unprocess_error';
	var FLD_BILL_AND_CREDIT_DETAIL_TEXT_FILE='custrecord_appf_bill_and_credit_detail';
	var SPARAM_VVCCP_EXECUTION_BATCH_LINK_ID='custscript_vvccp_exec_batch_id';
var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978	



function schedule(type)
{
	var context = nlapiGetContext();

//Reject
	var vvccpProcessRejectRecordsSearchId=context.getSetting('SCRIPT',SPARAM_VVCCP_PROCESS_REJECT_RECORDS);
	var vvccpProcessRejectRecordsSearch=nlapiLoadSearch(null, vvccpProcessRejectRecordsSearchId);
	var vvccpProcessRejectRecordsSearchFilts = vvccpProcessRejectRecordsSearch.getFilters();
	var vvccpProcessRejectRecordsSearchColumns=vvccpProcessRejectRecordsSearch.getColumns();
	var vvccpProcessRejectRecordsSearchSSType = vvccpProcessRejectRecordsSearch.getSearchType();
	var vvccpProcessRejectRecordsSearchResults=getAllSearchResults(vvccpProcessRejectRecordsSearchSSType, vvccpProcessRejectRecordsSearchFilts, vvccpProcessRejectRecordsSearchColumns);
	if(vvccpProcessRejectRecordsSearchResults !=null && vvccpProcessRejectRecordsSearchResults !='')
	{
			for(r=0;r<vvccpProcessRejectRecordsSearchResults.length;r++)
			{
				var searchresult = vvccpProcessRejectRecordsSearchResults[r];
				var vvccpBatchRecID = searchresult.getId();
				nlapiLogExecution('debug','vvccpBatchRecID',vvccpBatchRecID);
				nlapiSubmitField(CUSTOMRECORD_MASTER_BATCH, vvccpBatchRecID, FLD_MASTER_BATCH_SENT_FOR_PROCESSING, 'T');
						var processingComplete=true;
  var d = new Date();
	var timeStamp = d.getTime();
	var vvccpMasterBatchRecID = vvccpBatchRecID;
	if (vvccpMasterBatchRecID != null && vvccpMasterBatchRecID != '')
	{
		
		var vvccpMasterBatchRecord = nlapiLoadRecord(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, vvccpMasterBatchRecID);
		var billAndBillCreditDetailFile=vvccpMasterBatchRecord.getFieldValue(FLD_BILL_AND_CREDIT_DETAIL_TEXT_FILE);
		if(billAndBillCreditDetailFile !=null && billAndBillCreditDetailFile !='')
		{
		var billAndBillCreditDetailFileData=nlapiLoadFile(billAndBillCreditDetailFile);
		var fileDetails=billAndBillCreditDetailFileData.getValue();

		//nlapiLogExecution('debug','fileDetails:',fileDetails);
	
		var mainArr=JSON.parse(fileDetails);
		nlapiLogExecution('debug','mainArr:',JSON.stringify(mainArr));
		var errorLog = '';
		var totalBillToBeProcessed=vvccpMasterBatchRecord.getFieldValue(FLD_BILL_LINE_TO_PROCESS);
		var billsProcessed=0;
		var totalBillCreditToBeProcessed=vvccpMasterBatchRecord.getFieldValue(FLD_CREDIT_LINES_TO_PROCESS);
		var billCreditssProcessed=0;
		var totalBillAndBillCreditToBeProcessed=0;
		totalBillAndBillCreditToBeProcessed=parseFloat(totalBillToBeProcessed)+parseFloat(totalBillCreditToBeProcessed);
		for(var i = 0; i < mainArr.length; i++)
		{
			var mainObj = mainArr[i].data;
			var vendorbills=mainObj['vendorbill'];
			var vendorcredits=mainObj['vendorcredit'];	
		
		
		var billOrbillCreditErrorFile='Bill/BillCredit ID,Error Details \n'
		if (vendorbills != null && vendorbills != '')
		{
			
			for (var v = 0; v < vendorbills.length; v++)
			{
				var vbid = vendorbills[v].id;
				try{
				nlapiSubmitField('vendorbill', vbid, FLD_VVCCP_STATUS, '3');
				billsProcessed++;
				var percentage=((parseFloat(billsProcessed)+parseFloat(billCreditssProcessed))/parseFloat(totalBillAndBillCreditToBeProcessed))*100;
				nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, vvccpMasterBatchRecID, [FLD_BILLS_LINES_UNPROCESSED,FLD_REJECTION_PERCENTAGE],[billsProcessed,percentage]);
				}
				catch(e){
		if ( e instanceof nlobjError ){
			nlapiLogExecution( 'DEBUG', 'Error setting Ready For Processing in VVCCP Status for Bill: '+vbid, e.getDetails() );
			errorLog+='Error setting Ready For Processing in VVCCP Status for Bill: '+vbid+e.getDetails()+'\n';
			billOrbillCreditErrorFile+=vbid+','+e.getDetails()+'\n'
		}
		else
		{
			nlapiLogExecution( 'DEBUG', 'Error setting Ready For Processing  in VVCCP Status for Bill: '+vbid, e.toString() );
			errorLog+='Error setting Ready For Processing in VVCCP Status for Bill: '+vbid+e.toString()+'\n';
			billOrbillCreditErrorFile+=vbid+','+e.toString()+'\n'
		}
	}
	if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				
			}
			
			
		}
		
		if (vendorcredits != null && vendorcredits != '')
		{
			for (var c = 0; c < vendorcredits.length; c++)
			{
				var vcid = vendorcredits[c].id;
				try{
				nlapiSubmitField('vendorcredit', vcid, FLD_VVCCP_STATUS, '3');
				billCreditssProcessed++;
				var percentage=((parseFloat(billsProcessed)+parseFloat(billCreditssProcessed))/parseFloat(totalBillAndBillCreditToBeProcessed))*100;
				nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, vvccpMasterBatchRecID, [FLD_CREDIT_LINES_UNPROCESSED,FLD_REJECTION_PERCENTAGE],[billCreditssProcessed,percentage]);
				}
				catch(e){
		if ( e instanceof nlobjError )
		{
			nlapiLogExecution( 'DEBUG', 'Error setting Ready For Processing in VVCCP Status for Credit: '+vcid, e.getDetails() );
			errorLog+='Error setting Ready For Processing in VVCCP Status for Credit: '+vcid+e.getDetails()+'\n';
			billOrbillCreditErrorFile+=vcid+','+e.getDetails()+'\n'
		}
		else
		{
			nlapiLogExecution( 'DEBUG', 'Error setting Ready For Processing  in VVCCP Status for Credit: '+vcid, e.toString() );
			errorLog+='Error setting Ready For Processing in VVCCP Status for Credit: '+vcid+e.toString()+'\n';
			billOrbillCreditErrorFile+=vcid+','+e.getDetails()+'\n'
		}
	}
	if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				
			}
			
			
		}
		if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
		}
		if(errorLog !='' && errorLog !='')
		{
			var billOrbillCreditErrorFileRec=nlapiCreateFile('Bill_And_Credit Update Error File'+timeStamp+'.csv','CSV',billOrbillCreditErrorFile);
			billOrbillCreditErrorFileRec.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
			var billOrbillCreditErrorFileRecId=nlapiSubmitFile(billOrbillCreditErrorFileRec);
			nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, vvccpMasterBatchRecID,FLD_BILL_OR_BILLCREDIT_REVERSAL_ERROR_FILE,billOrbillCreditErrorFileRecId);
		}
			if(processingComplete == true)
			{
				nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, vvccpMasterBatchRecID,FLD_TRANSACTION_SET_TO_READY_FOR_PROCESSING,'T');
			}
	}	
	}
	if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
			}
	}
	
}	
	
	function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
		
		
		
		function randomString(length) {
	var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var u = length; u > 0; --u) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}


function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}