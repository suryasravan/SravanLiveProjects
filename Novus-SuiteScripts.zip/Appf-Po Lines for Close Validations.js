/*
*Script Name: Appf- PO Close Processed ValidationsCL
*Script Type: Client
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       15 May 2020              		This script handles the client side validations for "Appf - PO Lines Close Processed SL"
*/

var FLD_SL_VENDOR = 'custpage_vendor';
var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment'; 
var FLD_SL_PROJECT = 'custpage_project';
var FLD_SL_SERVICE_DATE_FROM = 'custpage_service_date_from';
var FLD_SL_SERVICE_DATE_TO = 'custpage_service_date_to';
var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
var FLD_SL_END_DATE= 'custpage_end_date';
var FLD_SL_START_DATE_TO = 'custpage_start_date_to';
var FLD_SL_START_DATE_FROM= 'custpage_start_date_from';
var FLD_SL_END_DATE_TO= 'custpage_end_date_to';
var FLD_SL_END_DATE_FROM= 'custpage_end_date_from';
var FLD_SL_IN_NUM = 'custpage_inv_num';
var FLD_SL_IO_NUM = 'custpage_io_num';
var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
var SL_FLD_CURRENCY='custpage_currency';
var FLD_SL_POP_RECEIVED = 'custpage_pop_received';
var FLD_SL_TOTAL_AMOUNT = 'custpage_total_amount';
var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
var FLD_SL_CLIENTS = 'custpage_client'; 
var FLD_SL_PURCASE_ORDER_NUM = 'custpage_purchaseorder_num'; 
var FLD_SL_DATE_TO = 'custpage_date_to';
var FLD_SL_DATE_FROM= 'custpage_date_from';
var SL_SUBLIST = 'custpage_sl_sublist';
var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
var SL_COL_TOTAL_AMOUNT = 'custpage_scriptfield3';
var FLD_SL_MEDIA_SUPPLIER = 'custpage_media_supplier'; 
var SCRIPT_MARK_PO_LINES_CLOSE_SL='customscript_appf_po_lines_close_process';
var DEPLOY_MARK_PO_LINES_CLOSE_SL='customdeploy_appf_po_lines_close_process';
var FLD_SL_START_DATE_FROM= 'custpage_start_date_from';
function vendorFieldChangePo(type, name, linenum){
  
	  if(name == FLD_SL_VENDOR){
		  var vendorName = nlapiGetFieldValue(FLD_SL_VENDOR);
        var vendorSubsidiary='';
			if(vendorName != null && vendorName != ''){
              nlapiDisableField(FLD_SL_SUBSIDIARY, true);
				var vendorFields = nlapiLookupField('vendor', vendorName, ['currency','subsidiary']);
				var curr=vendorFields.currency;
				vendorSubsidiary=vendorFields.subsidiary;
			if(curr != null && curr != '')
				nlapiSetFieldValue(SL_FLD_CURRENCY, curr);
			}
			else{
				nlapiSetFieldValue(SL_FLD_CURRENCY, '');
                            nlapiDisableField(FLD_SL_SUBSIDIARY, false);

			}
			if(vendorSubsidiary !=null && vendorSubsidiary !='')
			{
				nlapiSetFieldValue(FLD_SL_SUBSIDIARY, vendorSubsidiary);
			}
			else
			{
				nlapiSetFieldValue(FLD_SL_SUBSIDIARY, '');
			}
	     }
		 if(type == SL_SUBLIST){
	     	if(name == FLD_COL_SL_SELECT){
	          var totAmt = 0;
	          var totLines = 0;
	           var count = nlapiGetLineItemCount(SL_SUBLIST);
	          	for(var c=1; c<=count; c++){
	              var selected = nlapiGetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c);
	              if(selected == 'T'){
	                 totLines++;
	                var totalAmount = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_TOTAL_AMOUNT, c);
	                //alert('totalAmount '+totalAmount);
	                totAmt = Number(totAmt) + Number(totalAmount);
	                 }
	            }
	          nlapiSetFieldValue(FLD_SL_TOTAL_AMOUNT, Number(totAmt));
	          nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
	           }
			}
	  
	}



function applyFilters(){
	var vendorName = nlapiGetFieldValue(FLD_SL_VENDOR);
	var mediaSegment = nlapiGetFieldValue(FLD_SL_MEDIA_SEGMENT);
	var proj = nlapiGetFieldValue(FLD_SL_PROJECT);
	var ioNum = nlapiGetFieldValue(FLD_SL_IO_NUM);
	var subsidiaryVal = nlapiGetFieldValue(FLD_SL_SUBSIDIARY);
	var startDateTo = nlapiGetFieldValue(FLD_SL_START_DATE_TO);
	var strtDateFrom = nlapiGetFieldValue(FLD_SL_START_DATE_FROM);
	var invNum= nlapiGetFieldValue(FLD_SL_IN_NUM);
	var toDate= nlapiGetFieldValue(FLD_SL_DATE_TO);
	var fromDate= nlapiGetFieldValue(FLD_SL_DATE_FROM);
	var curr= nlapiGetFieldValue(SL_FLD_CURRENCY);
   var clieniIO= nlapiGetFieldValue(FLD_SL_CLIENTS);
   var poNum= nlapiGetFieldValue(FLD_SL_PURCASE_ORDER_NUM);
    var mediaSupp= nlapiGetFieldValue(FLD_SL_MEDIA_SUPPLIER);
		var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_MARK_PO_LINES_CLOSE_SL, DEPLOY_MARK_PO_LINES_CLOSE_SL);
	
		suiteletURL=suiteletURL+'&vendorName='+vendorName+'&mediaSegment='+mediaSegment+'&proj='+proj+'&ioNum='+ioNum+'&subsidiaryVal='+subsidiaryVal;
		suiteletURL+='&strtdateto='+startDateTo+'&strtDateFrom='+strtDateFrom+'&toDate='+toDate+'&fromDate='+fromDate+'&invnum='+invNum+'&currency='+curr+'&clientio='+clieniIO+'&ponum='+poNum+'&mediasuppliers='+mediaSupp;
		suiteletURL+='&applyfilters=T';
// if (vendorName == null || vendorName == '')
//   {
//     alert('Please select Vendor Name');
//     return false;
//   }
//	else
//      {
  window.open(suiteletURL,'_self');
//      }
	
}


function onSaveVCSL() {

	var counter=0;
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	if(count > 0){
	for(var i=1; i<=count; i++){
		var checkbox=nlapiGetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, i);
		if(checkbox == 'T')
			counter++;
	}
	
	}
	if(counter == 0){
		alert('Please Select atleast one line to Proceed.');
		return false;
	}
	else
	{
		var submitConfirmation= confirm('Selected transactions will be processed for PO Lines Close Suitelet, Click OK to proceed.');
    if (submitConfirmation== true)
    {
		return true;
    }
   else
   {
       return false;
   }
		//return true;
	}
		
}


function unmarkAll(){
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	var unmarkAll=false;
	for(var i=1; i<=count; i++){
		nlapiSetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, i, 'F');
		unmarkAll=true;
	}
	if(unmarkAll)
	{
	nlapiSetFieldValue(FLD_SL_TOTAL_AMOUNT, '');
	 nlapiSetFieldValue(FLD_SL_TOTAL_LINES, '');
	 }
}

function markAll(){
 var totAmt = 0;
 var totLines = 0;
	var count=nlapiGetLineItemCount(SL_SUBLIST);
 var markAll = false;
	for(var c=1; c<=count; c++){
		nlapiSetLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c, 'T');
		 totLines++;
	     var totalAmount = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_TOTAL_AMOUNT, c);
	     totAmt = Number(totAmt) + Number(totalAmount);
		 markAll=true;
	}
	 if(markAll)
	 {
	 nlapiSetFieldValue(FLD_SL_TOTAL_AMOUNT, Number(totAmt));
	 nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
	  }        
}

function pageInit()
{
  var totAmt = 0;
 var totLines = 0;
	var count=nlapiGetLineItemCount(SL_SUBLIST);
 var markAll = false;
	for(var c=1; c<=count; c++){
		 totLines++;
	     var totalAmount = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_TOTAL_AMOUNT, c);
	     totAmt = Number(totAmt) + Number(totalAmount);
		 markAll=true;
	}
	 if(markAll)
	 {
	 nlapiSetFieldValue(FLD_SL_TOTAL_AMOUNT, Number(totAmt));
	 nlapiSetFieldValue(FLD_SL_TOTAL_LINES, totLines);
	  }     
} 