/**
 *@NApiVersion 2.x
 *@NScriptType ScheduledScript
 */


/*Script Name: Appf-Update Tax Bills SC
*Script Type: Scheduled
*Company 	 : Appficiency
* Version    Date            Author           Remarks
* 1.0      27/04/2022      namrata            This script updates Buying System, Media Segment for every Tax VB from a SS as per the Child VB from Master Vendor Invoice
*/
var PARAM_SC_SAVED_SEARCH_ID = 'custscript_appf_ss_tax_vb_sync';
var FLD_COL_MASTER_VB_LINK ='custcol_appf_masterlink';

var SSCHILDVB_FIELD_NAME_VB_HEADER ='custrecord_appf_interimheader';
var SSCHILDVB_FIELD_NAME_VB_LINK ='custrecord_appf_ivbl_vblink';
var FLD_BUYING_SYSTEM ='custbody_appf_buying_system';
var FLD_COL_MEDIA_SEGMENT ='cseg_appf_media_seg';

var FLD_TAX_VB_SYNC ='custbody_appf_tax_vb_sync';


var CUSTOM_RECORD_NOVUS_CHILD_VB = 'customrecord_appf_interim_vb_line';



define(['N/search', 'N/record', 'N/email', 'N/runtime', 'N/file', 'N/url', 'N/task'],
    function (search, record, email, runtime, file, url, task) {
        function execute(context) {
            var scriptObj = runtime.getCurrentScript();
            var BillSavedSearchId = scriptObj.getParameter(PARAM_SC_SAVED_SEARCH_ID);
            // log.debug('ss_id', BillSavedSearchId);
            var ssRec = search.load({ id: BillSavedSearchId });
            // log.debug('SSRec', ssRec);
            var extFils = ssRec.filters;
            // log.debug('extFils', extFils);
            var extCols = ssRec.columns;
            //  log.debug('extCols', extCols);
            var SSBillResults = getSearchResults('transaction', extFils, extCols);
            // log.debug('SS_Results', SSBillResults);
            if (SSBillResults != '' && SSBillResults != null && SSBillResults.length > 0) {
                log.debug('Total VBs to process', SSBillResults.length)
                for (var s = 0; s < SSBillResults.length; s++) {
                    var vendBillId = SSBillResults[s].id;
                    log.debug('Currently processing index:' + s, 'VB ID:' + vendBillId)
                    try {
                        var masterDocLink = SSBillResults[s].getValue({ name:FLD_COL_MASTER_VB_LINK});
                        //  log.debug('masterDocLink',masterDocLink);
                        var postClosed = SSBillResults[s].getValue({ name: 'closed', join: 'accountingPeriod' });
                       // log.debug('postClosed', postClosed);
                        if (masterDocLink != null && masterDocLink != '') {
                          
                 var taxVendBillRec = record.load({ type: record.Type.VENDOR_BILL, id: Number(vendBillId), isDynamic: true });

                            var filters = [];
                            filters.push(search.createFilter({
                                name: SSCHILDVB_FIELD_NAME_VB_HEADER,
                                operator: search.Operator.ANYOF,
                                values: Number(masterDocLink)
                            }));
                            filters.push(search.createFilter({
                                name: SSCHILDVB_FIELD_NAME_VB_LINK,
                                operator: search.Operator.NONEOF,
                                values: '@NONE@'
                            }));
                            var columns = [];
                            columns.push(search.createColumn({ name: 'internalid', sort: search.Sort.ASC }));
                            columns.push(search.createColumn({ name: SSCHILDVB_FIELD_NAME_VB_LINK }));
                            var SSChildVbResults = getSearchResults(CUSTOM_RECORD_NOVUS_CHILD_VB, filters, columns);
                            //log.debug('SSChildVbResults', SSChildVbResults);
                            if (SSChildVbResults != null && SSChildVbResults != '' && SSChildVbResults.length > 0) {
                                var childVebId = SSChildVbResults[0].id;
                                // log.debug('childVebId', childVebId);
                                var childVbValueId = SSChildVbResults[0].getValue({ name: SSCHILDVB_FIELD_NAME_VB_LINK});
                              //  log.debug('childVbValue', childVbValueId);
                                var childVbRec = record.load({ type: record.Type.VENDOR_BILL, id: Number(childVbValueId), isDynamic: true });
                              //  log.debug('childVbRec', childVbRec);
                                var buyingSysValue = childVbRec.getValue({ fieldId: FLD_BUYING_SYSTEM });
                               // log.debug('buyingSysValue', buyingSysValue);
                                childVbRec.selectLine({ sublistId: 'item', line: 0 })
                                var mediaSegValue = childVbRec.getCurrentSublistValue({ sublistId: 'item', fieldId: FLD_COL_MEDIA_SEGMENT });
                               // log.debug('mediaSegValue', mediaSegValue);
                               // log.debug('TaxVendBillRec', taxVendBillRec);
                                if (postClosed == false) {
                                    taxVendBillRec.setValue({ fieldId: FLD_BUYING_SYSTEM, value: buyingSysValue });
                                    var lineCountTax = taxVendBillRec.getLineCount({ sublistId: 'item' });
                                  //  log.debug('lineCountTax', lineCountTax);
                                    for (var k = 0; k < lineCountTax; k++) {
                                        taxVendBillRec.selectLine({ sublistId: 'item', line: k })
                                        taxVendBillRec.setCurrentSublistValue({ sublistId: 'item', fieldId:FLD_COL_MEDIA_SEGMENT, value: mediaSegValue });
                                        taxVendBillRec.commitLine({ sublistId: 'item' });
                                    };
                                }
                                else {
                                    taxVendBillRec.setValue({ fieldId: FLD_BUYING_SYSTEM, value: buyingSysValue });

                                }
                               


                            }
                         
                              taxVendBillRec.setValue({ fieldId: FLD_TAX_VB_SYNC, value: true });

                           var Id1 = taxVendBillRec.save({
                                    enableSourcing: true,
                                    ignoreMandatoryFields: true
                                });
                        }


                    } catch (error) {
                        log.debug('Error while processing Tax VB:' + vendBillId, error.message);
                    }
                    if (runtime.getCurrentScript().getRemainingUsage() <= 500 && (parseInt(s)+1) <  SSBillResults.length) {
                        log.debug('Rescheduling starts at', 'index:' + s);
                        var scriptTask = task.create({ taskType: task.TaskType.SCHEDULED_SCRIPT });
                        scriptTask.scriptId = runtime.getCurrentScript().id;
                        scriptTask.deploymentId = runtime.getCurrentScript().deploymentId;
                        var scheduledScriptTaskId = scriptTask.submit();
                        break;
                    }
                }
            }
        };
        function getSearchResults(rectype, fils, cols) {
            var mySearch = search.create({
                type: rectype,
                columns: cols,
                filters: fils
            });
            var resultsList = [];
            var myPagedData = mySearch.runPaged({
                pageSize: 1000
            });
            myPagedData.pageRanges.forEach(function (pageRange) {
                var myPage = myPagedData.fetch({
                    index: pageRange.index
                });
                myPage.data.forEach(function (result) {
                    resultsList.push(result);
                });
            });
            return resultsList;
        }
        return {
            execute: execute
        };
    });