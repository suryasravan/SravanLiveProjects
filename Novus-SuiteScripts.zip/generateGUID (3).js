/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */
 var SPARAM_SB_URL_AMEX='custscript_sbx_amex_card_url'
var SPARAM_SB_MATER='custscript_sbx_master_card_url'
var SPARAM_PRODUCTION_URL_AMEX='custscript_prod_amex_card_url'
var SPARAM_PRODUCTION_MATERS='custscript_prod_master_card_url'
define(['N/ui/serverWidget', 'N/https', 'N/runtime'],
    function(ui, https, runtime) {
        function onRequest(option) {
            if (option.request.method === 'GET') {
				var userAccountId = runtime.accountId
                var form = ui.createForm({
                    title: 'Password Form'
                }); var scriptObj = runtime.getCurrentScript();
           var amexUrl=''
		   var mastersUrl=''
				if(userAccountId=='3619984')
				{
					amexUrl =  scriptObj.getParameter({ name: SPARAM_PRODUCTION_URL_AMEX});
					mastersUrl =  scriptObj.getParameter({ name: SPARAM_PRODUCTION_MATERS});
				}
				else
				{
					amexUrl =  scriptObj.getParameter({ name: SPARAM_SB_URL_AMEX});
					mastersUrl =  scriptObj.getParameter({ name: SPARAM_SB_MATER});
					
				}
				if((amexUrl!=null && amexUrl!='') && (mastersUrl!=null && mastersUrl!=''))
				{
                form.addCredentialField({
                    id: 'custfield_sftp_password_token',
                    label: 'Password',
                    restrictToCurrentUser: false,
                    restrictToDomains: [amexUrl,mastersUrl],
                    
                    restrictToScriptIds: ['customscript_appf_vvccp_sftp_send_sl','customscript_appf_vvccp_receive_sl']
                });
                form.addSubmitButton();
                option.response.writePage({
                    pageObject: form
                });
            }
			}			
			else {
                // Request to an existing suitelet with credentials
                var passwordGuid = option.request.parameters.custfield_sftp_password_token;
              log.debug(passwordGuid);
              
              option.response.write(passwordGuid);
                
            }
			
        }
        return {
            onRequest: onRequest
        };
    });