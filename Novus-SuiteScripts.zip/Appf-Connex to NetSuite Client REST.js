/*
* Script Name : Appf-Connex to NetSuite Client REST
* Script Type : 
* Event Type  : 
* Description :This script when executed checks for any new messages in the queue related to Connext Clients and pushes the clients from those messages into netsuite and creates or updates as Customer records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
* Company     :	Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_connex_client_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecord_appf_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecord_appf_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_client_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_connex_status_code';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_connex_resp_status_code';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_appf_correlid';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS = 'custrecord_appf_queuemsg_property';

var SPARAM_CONNEX_CLIENT='customscript_appf_connex_client_2_ns_sc'
function getRESTlet(dataIn)
{
	nlapiLogExecution('debug', 'internalId',  'internalId');	
nlapiScheduleScript(SPARAM_CONNEX_CLIENT,null)
               
	return 'RESTlet successfully connected.';
}
