/**
*Script Name: Appf - Create or Update Order Using Queue Sch
*Script Type: Schedule Script
*Description: 
*Company 	: Appficiency Inc.
*/
 var FLD_COL_TTB_UPDATED_PROJECT='custcol_appf_ttb_update_project';
 var CUSTOMRECORD_APPF_IN_BOUND_PRINT_MERCURY_ORDER_RECS='customrecord_appf_print_mercury_order_in';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_MESSAGE ='custrecord_appf_order_messageid';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_CONTENT_LINK='custrecord_appf_order_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_QUEU_NAME ='custrecord_appf_order_queuename';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_AZURE_RESPONSE='custrecord_appf_order_response';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER='custrecord_order_id';
 var CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_RESPONSE_STATUS='custrecord_response_order_status';
 var CUSTOMRECORD_MEDIA_SUPP_RECS='customrecord_appf_pwp_wrapper_record';
 
function createOrderScheduled(type) 
  {	
	
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
		    try
			   {
                 var Queue=true
                 while (Queue == true) {
				   var QueueName1='novusmedia_mercury_order_in'
				   var d = new Date();
                 var UTCDate= d.toISOString();
var url = 'https://novusmediallc-dev.servicebus.windows.net/'+QueueName1+'/messages/head?api-version=2015-01';
var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey',"Date":UTCDate,"Content-Type": 'application/xml'};
var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
var mainObj = responseData.getBody();
                   if(responseData.getCode()=='204')
                     Queue=false
			   nlapiLogExecution('debug', 'responseData',  responseData.getCode())
                   if(responseData.getCode()!='204')
                     {
						 var responseDataAllHeaders=responseData.getAllHeaders()
  var responseData3=responseDataAllHeaders[3]
  var responseDataProp=responseData.getHeader(responseData3)
  responseDataProp=JSON.parse(responseDataProp)
var MessageId=''
for (var parentProp in responseDataProp)
    	               {
			              var parentProp=parentProp
                             if(parentProp=='MessageId')
                          MessageId=responseDataProp[parentProp]
			
                         }
						 
			  mainObj=JSON.parse(mainObj)
			if(!mainObj.hasOwnProperty('id'))
			{
				nlapiLogExecution('debug', 'hasOwnProperty',  'hasOwnProperty');
				 var payRec=nlapiCreateRecord(CUSTOMRECORD_MEDIA_SUPP_RECS)
				 for (var parentProp in mainObj)
    	             {
						 //nlapiLogExecution('debug', ' parentProp',  parentProp);
			            var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=payRec.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!='') && (parentProp2==null || parentProp2==''))
						 {
			                  payRec.setFieldValue(parentProp,mainObj[parentProp])	
						 }
		              }
		               var id=nlapiSubmitRecord(payRec,true,true)
					
					    var clientIn=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_PRINT_MERCURY_ORDER_RECS)
						  if(responseData.getCode()=='200')
							clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_RESPONSE_STATUS,'Success')
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_MESSAGE,MessageId)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_CONTENT_LINK,mainObj)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_QUEU_NAME,QueueName1)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_AZURE_RESPONSE,responseData.getCode())
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER,id)
					   nlapiSubmitRecord(clientIn,true,true)
				
			}
			else{
                var payRec='';
                 var internalId=mainObj['id']
				  nlapiLogExecution('debug', 'internalId',  internalId);
                  if(internalId==null || internalId=='')
                  payRec=nlapiCreateRecord(CUSTOMRECORD_MEDIA_SUPP_RECS)

                     else
                    payRec=nlapiLoadRecord(CUSTOMRECORD_MEDIA_SUPP_RECS,internalId)

                   nlapiLogExecution('debug', ' payRec',  payRec);
                    for (var parentProp in mainObj)
    	             {
						 //nlapiLogExecution('debug', ' parentProp',  parentProp);
			            var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=payRec.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!='') && (parentProp2==null || parentProp2==''))
						 {
			                  payRec.setFieldValue(parentProp,mainObj[parentProp])	
						 }
		              }
		               var id=nlapiSubmitRecord(payRec,true,true)
					
					    var clientIn=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_PRINT_MERCURY_ORDER_RECS)
						if(responseData.getCode()=='200')
							clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_RESPONSE_STATUS,'Success')
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_MESSAGE,MessageId)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_CONTENT_LINK,mainObj)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_QUEU_NAME,QueueName1)
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER_AZURE_RESPONSE,responseData.getCode())
						clientIn.setFieldValue(CUSTOMRECORD_FLD_APPF_PRINT_MERCURY_ORDER,id)
					 nlapiSubmitRecord(clientIn,true,true)
			}
                     }
		  }
               }
		  catch(e)
		  {
		   nlapiLogExecution('debug', 'sftpFileID', e);
		  }
               
	}