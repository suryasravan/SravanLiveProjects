/*Script Name: Appf - Consolidated Invoice PDFs Zip
 *Script Type: Suitelet
 Description: This script is used to generate pdfs for each selected CI record line and make a zip of them to download or email the customers.
 *Company 	 : Appficiency.
 */

var SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD='customscript_appf_consolidated_inv_pdf';
var DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD='customdeploy_appf_consolidated_inv_pdf';

var SCRIPT_SL_PDF_LAYOUTGEN='customscript_sl_invoice_designgeneration';
var DEPLOY_SL_PDF_LAYOUTGEN='customdeploy_sl_invoice_designgeneration';

var CUSTOM_RECORD_INVOICE_LAYOUT_SETUP = 'customrecord_appf_pdf_layout';
var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var CUSTOM_RECORD_CI_RECORD = 'customrecord_appf_ci_record';
var FLD_CI_RECORD_CONTRACT_INV_RECIPIENTS = 'custrecord_appf_contract_inv_recipients';
var FLD_CI_RECORD_CONTRACT = 'custrecord_appf_ci_contract';
var FLD_CI_RECORD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_CI_RECORD_CLIENT = 'custrecord_appf_ci_client';
var FLD_CONTRACT_INVOICE_RECIPIENTS = 'custrecord_appf_contract_inv_recipients';
var FLD_CI_RECORD_LAST_EMAIL_SENT = 'custrecord_appf_ci_last_email_sent';
var FLD_CI_RECORD_EMAIL_SENT = 'custrecord_appf_ci_email_sent';

var SENDER = '8';//novus@appficiencyinc.com
var DEFAULT_TEMPLATE_ID = '28';
function generateCIRecPDF(request,response)
{
  nlapiLogExecution('DEBUG','usage1:',nlapiGetContext().getRemainingUsage());
	var missingTranArr = [];
	var zipFileArr = [];
	var dummyPdfFileArr = [];
	var finalMailObj = {};
  var totalFileSize = 0;
	try{
		var pdfDetailsArr = request.getParameter('recid');
		var action = request.getParameter('action');
      var emailTemplateId = request.getParameter('emailTemplate');
      if(emailTemplateId == null || emailTemplateId == '')
        emailTemplateId = DEFAULT_TEMPLATE_ID;
		if(pdfDetailsArr != null && pdfDetailsArr != '')
		{
		    pdfDetailsArr = pdfDetailsArr.split(",");
			pdfDetailsArr = eliminateDuplicates(pdfDetailsArr);
		    //nlapiLogExecution('DEBUG','pdfDetailsArr',pdfDetailsArr);
			for(var p=0; p < pdfDetailsArr.length; p++)
			{
				var pdffile = '';
				var timeStamp = new Date().getTime();
				var ciRecID = pdfDetailsArr[p];
				if(ciRecID != null && ciRecID != '')
				{
					var fileData = getPDF(ciRecID);
					
					if(fileData.hasOwnProperty("success"))
					{
						if(!finalMailObj.hasOwnProperty(fileData.ciRecID)){
							finalMailObj[ciRecID] = {};
							finalMailObj[ciRecID].fileArr = [];
							finalMailObj[ciRecID].recipientsArr = [];
						}
						var file = nlapiLoadFile(fileData.success);
						file.setName('CI-'+ciRecID+'.pdf');
						finalMailObj[ciRecID].recipientsArr.push(fileData.recipients);
                        totalFileSize = totalFileSize + file.getSize();
                      	finalMailObj[ciRecID].fileArr.push(file);
						zipFileArr.push(file);
						dummyPdfFileArr.push(fileData.success);
					}
					else
					{
						missingTranArr.push(fileData.error);
					}
				}
			}
          nlapiLogExecution('DEBUG','missingTranArr',missingTranArr);
		  
		  if(action == 'email')
			{
		  for(var ciRecID in finalMailObj){
			  var ciRecObj = finalMailObj[ciRecID];
			  var fileArr = ciRecObj.fileArr;
			  var recipientsArr = ciRecObj.recipientsArr;
			  
			  
				recipientsArr = eliminateDuplicates(recipientsArr);
				//totalFileSize = (Number(totalFileSize);//size in bytes
				//nlapiLogExecution('DEBUG','arr len',fileArr.length+'---' +recipientsArr.length);
				if(fileArr.length > 0 && recipientsArr.length > 0)
				{
					//nlapiLogExecution('DEBUG','final recipientsArr',recipientsArr);
					var process = sendEmail(SENDER,recipientsArr,fileArr,emailTemplateId,ciRecID);
 					response.write('');
                  	response.sendRedirect('SUITELET', SCRIPT_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD, DEPLOY_SL_CONSOLIDATED_INVOICE_PRINT_DOWNLOAD);
				}
			}
			
		  }
		  else
			{
				if(zipFileArr.length == 1)
				{
					response.setContentType('PDF', zipFileArr[0].getName(), 'inline');	
                    var singFileData = zipFileArr[0].getValue();
                   nlapiDeleteFile(dummyPdfFileArr[0]);
					response.write(singFileData);
				}					
				if(zipFileArr.length > 1)
				{  
					var zip = new JSZip();
					var timeStamp = new Date().getTime();
					zip = zip.folder("Consolidated PDFs.zip");				    
					for(var f=0;f < zipFileArr.length; f++)
					{
						zip.file(zipFileArr[f].getName(), zipFileArr[f].getValue(), {base64: true});
						nlapiDeleteFile(dummyPdfFileArr[f]);
                      nlapiLogExecution('DEBUG','usage1:',nlapiGetContext().getRemainingUsage());
					}
					var content = zip.generate();
					response.setContentType('ZIP','Consolidated PDFs-'+timeStamp+'.zip');
					response.write(content);
				} 
			}
		  
			
		}    
	}catch (e) {
		   if( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
  nlapiLogExecution('DEBUG','usage1:',nlapiGetContext().getRemainingUsage());
}
	
function sendEmail(sender,receiver,attachments,emailTemplateId,ciRecID)
{
  if(emailTemplateId != null && emailTemplateId != '' && ciRecID != null && ciRecID != '')
    {
	//send Email
var emailMerger = nlapiCreateEmailMerger(emailTemplateId); 
	emailMerger.setCustomRecord(CUSTOM_RECORD_CI_RECORD, ciRecID); 
	var mergeResult = emailMerger.merge(); 
	var emailSubject = mergeResult.getSubject();
	var emailBody = mergeResult.getBody();
//nlapiLogExecution('debug', 'emailSubject : emailBody', emailSubject+' : '+emailBody);	
var rec = new Array();
	rec['recordtype']=CUSTOM_RECORD_CI_RECORD;
	rec['record'] = ciRecID;
	nlapiSendEmail(sender,receiver,emailSubject,emailBody,null,null,rec,attachments);
	nlapiSubmitField(CUSTOM_RECORD_CI_RECORD, ciRecID, [FLD_CI_RECORD_EMAIL_SENT, FLD_CI_RECORD_LAST_EMAIL_SENT], ['T', new Date()]);
    }   
  return true;
}
	
function getPDF(ciRecID)
{
	var data = {};
	var recipients = [];
	if(ciRecID)
	{
      try{
		  var loadRecord = nlapiLoadRecord('customrecord_appf_ci_record', ciRecID);
		  var ciContract = loadRecord.getFieldValue(FLD_CI_RECORD_CONTRACT);	
			var getInvoicePDFLayout = loadRecord.getFieldValue('custrecord_appf_ci_pdf_layout');		  
		if(ciContract != null && ciContract != '')
		{
			var invRecipients = nlapiLookupField(CUSTOM_RECORD_CONTRACT,ciContract,FLD_CONTRACT_INVOICE_RECIPIENTS);
			if(invRecipients != null && invRecipients != '')
			{
				invRecipients = invRecipients.split(",");
				for(var x=0; x < invRecipients.length; x++)
				{
					var contactFlds = nlapiLookupField('contact', invRecipients[x], ['email','custentity_appf_client_role']);
                  var contactEmail = contactFlds.email; 
                  var contactRole = contactFlds.custentity_appf_client_role;
              //   nlapiLogExecution('DEBUG','contactRole:',contactRole);
                  if(contactRole != null && contactRole != '')
                  {
                    contactRole = contactRole.split(',');
                    for(var c=0; c<contactRole.length; c++){
                      if(contactRole[c] == 3)
						recipients.push(contactEmail);
                    }
                  }
				}
			}	
		}
       try{
	   var pdfGenUrl = nlapiResolveURL('SUITELET', 'customscript_sl_consolidated_pdf_invoice', 'customdeploy_sl_consolidated_pdf_invoice','external');
		  pdfGenUrl = pdfGenUrl +'&isconsolidate=true&custparam_ci_id='+ciRecID+'&custparam_ci_pdf_layout='+getInvoicePDFLayout;
		  var pdfFileID = nlapiRequestURL(pdfGenUrl); 
		  pdfFileID = pdfFileID.body;
		  if(pdfFileID != null && pdfFileID != '')
		  {
			  data.success = pdfFileID;
			  data.recipients = recipients;
			  data.ciRecID = ciRecID;
		  }
	   }catch(exx){
			data.error = ciRecID;
		   nlapiLogExecution('Debug', 'Error in Template:', 'PDF Template is Missing for CI Record:'+ciRecID);
		 }
	}catch(ex){
      data.error = ciRecID;
      nlapiLogExecution('Debug', 'Error in processing:', ex.toString());
    	}
    }
	return data;
}	

function eliminateDuplicates(arr) {
   var i,
       len=arr.length,
       out=[],
       obj={};

   for (i=0;i<len;i++) {
     obj[arr[i]]=0;
   }
   for (i in obj) {
     out.push(i);
   }
   return out;
 }