/**
	 * Script Name : Appf-VVCCP Master Approve Or Rejects SC
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script handles the approve and reject actions on VVCCP Master batch records

	 *
	 * Company 	 : Appficiency. 
	 */
	 var SPARAM_VVCCP_PROCESS_APPROVED_RECORDS='custscript_vvccp_process_master_approved';
	 var SPARAM_VVCCP_PROCESS_REJECT_RECORDS='custscript_vvccp_process_master_reject';
	 var SPARAM_VVCCP_MASTER_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
	 var SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH='customscript_vvccp_approve_custmization';
	 var SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH='customscript_appf_vvccp_scheduled_reject';
	var SPARAM_VVCCP_MASTER_BATCH_LINK_ID='custscript_vvccp_exec_batch_id';
	var FLD_MASTER_BATCH_SENT_FOR_PROCESSING = 'custrecord_appf_sent_for_processing';
	var CUSTOMRECORD_MASTER_BATCH = 'customrecord_appf_vvccp_batch_master';
	
	var CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD='customrecord_appf_vvccp_batch_master';
 	var FLD_BATCH_AUTHORIZATION_AMOUNT='custrecord_appf_vvccp_batch_auth_amt';
 	var FLD_BATCH_SUBSIDIARY='custrecord_appf_vvccp_mbatch_subsidiary';
 	var FLD_TRANSACTIONS_MOVED_UNDER_PROCESSING='custrecord_appf_transactions_under_proc';
 	var FLD_MASTER_DATA_FILE='custrecord_appf_vvccp_master_file';
 	var FLD_BILL_LINE_TO_PROCESS='custrecord_appf_vvccp_master_bills';
 	var FLD_CREDIT_LINES_TO_PROCESS='custrecord_appf_vvccp_master_credits';
 	var FLD_CREDIT_LINE_PROCESSED='custrecord_appf_vvccp_master_credsmarked';
 	var FLD_BILL_LINES_PROCESSED='custrecord_appf_vvccp_master_billsmarked';
 	var FLD_BILL_DATA_FILE='custrecord_appf_vvccp_master_bill_data';
 	var FLD_MASTER_CREDIT_DATA_FILE='custrecord_appf_vvccp_master_credit_data'
 	var FLD_PROCESSED_PERCENT='custrecord_appf_vvccp_master_processed';
 	var FLD_BILL_OR_CREDIT_UPDATE_ERROR_FILE='custrecord_appf_master_update_errorfile'
 	var FLD_NUMBER_OF_AUTHORIZATION_GENERATED='custrecord_appf_vvccp_mast_auth_created';
 	var FLD_NUMBER_OF_AUTHORIZATION_TO_GENERATE='custrecord_appf_vvccp_mast_auth_to_gen';
 	var FLD_AUTHORIZATION_CREATED_SUCCESSFULLY='custrecord_appf_vvccp_master_auth_succes';
 	var FLD_APPROVAL_STATUS='custrecord_appf_vvccp_master_approvestat';
 	var FLD_TRANSACTION_SET_TO_READY_FOR_PROCESSING='custrecord_appf_trans_ready_for_process';
 	var FLD_CREDIT_LINES_UNPROCESSED='custrecord_appf_credit_lines_unprocessed';
 	var FLD_BILLS_LINES_UNPROCESSED='custrecord_appf_bill_lines_unprocessed';
 	var FLD_REJECTION_PERCENTAGE='custrecord_appf_rejection_percentage';
 	var FLD_BILL_OR_BILLCREDIT_REVERSAL_ERROR_FILE='custrecord_appf_master_unprocess_error';
	var FLD_BILL_AND_CREDIT_DETAIL_TEXT_FILE='custrecord_appf_bill_and_credit_detail';
var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var FLD_APPROVAL_STATUS_APPROVED=2;
var FLD_APPROVAL_STATUS_OPEN=11;
var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
var FLD_APPROVAL_STATUS_REJECTED=3;
		
var FLD_VVCCP_BATCH_APPROVAL_STATUS = 'custrecord_appf_vvccp_batch_approval';
var FLD_BATCH_RECS_LINKS = 'custbody_appf_vvccp_batch';
		
var FLD_VVCCCP_PROCESSING_STATUS = 'custbody_appf_vvccp_status';

		
var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING=3;
var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING=1
var FLD_VVCCP_PROCESSING_STATUS_PROCESSED=2
var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978;
var BILL_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_bill_vvccp';
var CREDIT_UPDATE_CSV_IMPORT_ID='custimport_appf_update_vendor_cred_vvccp';
		
var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS=3;
var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS=1
var FLD_VVCCP_PROCESSING_STATUS_PROCESSED_FOR_TRANSACTIONS=2
				
var STATUS_FOR_VVCCP_STATUS_IN_PROGRESS=2
var STATUS_FOR_VVCCP_STATUS_COMPLETED_SUCCESSFULLY=4
var STATUS_FOR_VVCCP_STATUS_COMPLETED_WITH_ERRORS=5
		
//VVCCP Execution Batch
var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills';	
var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred';
var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
var FLD_PROCESSED_PERCENT_EXECUTION_BATCH	='custrecord_appf_vvccp_log_percent';
var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by';
var FLD_VVCCP_LOG_STATUS	     			='custrecord_appf_vvccp_log_status';
var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file';
var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file';
var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log';
var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';
var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
var FLD_BILL_DATA_FILES						='custrecord_appf_vvccp_bill_data_files';
var FLD_CREDIT_DATA_FILE					='custrecord_appf_credit_data_file';
var FLD_APPROVAL_TRIGGERED					='custrecord_approval_button_triggered';
var MASTER_BATCH_RECORD_LINK='custrecord_appf_vvccp_log_master_batch';
var MASTER_BATCH_RECORD_UPDATED='custrecord_appf_master_record_updated';
var FLD_EXECUTION_BATCH_VENDOR='custrecord_appf_vvccp_batch_vendor';
var FLD_TOTAL_AUTHORIZATION_AMOUNT ='custrecord_appf_vvccp_total_auth_amount';
var FLD_LINKED_TRANSACTIONS_CREATED='custrecord_appf_vvccp_underproc_done';
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9

//VVCCP
var CUSTOM_RECORD_VVCCP='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';	 
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;

var CORPORATE_CREDIT_CARD_VVCCP     ='custentity_appf_vvccp_corporate_cc';

var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_ORDER_REFERENCE_NUMBER='custrecord_appf_vvccp_linked_order_ref';
var FLD_SERVICE_DATE='custrecord_appf_vvccp_linked_servicedate';
var FLD_CLIENT_NAME='custrecord_appf_vvccp_linked_client';
var FLD_MEDIA_SUPPLIER_NAME='custrecord_appf_vvccp_linked_publisher';
var FLD_MASTER_VENDOR_BILL_REF='custrecord_appf_vvccp_linked_bill_ref_no';

var COL_FLD_PENDING_AUTHORIZATION_VVCCP='custcol_appf_pending_auth_vvccp';
var FLD_PENDING_AUTHORIZATION_VVCCP='custbody_appf_pending_auth_vvccp';

var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';

var FLD_VB_LINE_ID = 'custcol_appf_vendorbill_line_id';
var FLD_COL_SERVICE_DATE = 'custcol_appf_print_servicedate';
var FLD_COL_MASTER_RECORD_LINK='custcol_appf_masterlink';
var FLD_COL_PWP_CUSTOM_RECORD='custcol_appf_pwp_custom_record';
var FLD_COL_PUBLISHER='custcol_appf_publisher';
var FLD_COL_IO_NUMBER='custcol_appf_ionum';

var CUSTOM_RECORD_MASTER_VENDOR_INVOICE='customrecord_appf_interim_vb';
var FLD_INV_REFERENCE_NUMBER='custrecord_appf_ivb_transid';

var CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER='customrecord_appf_pwp_wrapper_record';
var FLD_CLIENT_NAME='custrecord_appf_pwp_client_link';

var CUSTOM_RECORD_CORPORATE_CREDIT_CARD_VENDOR_PAYMENT='customrecord_appf_corp_card_table';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias';
var FLD_CORPORATE_CREDIT_CARD_IS_MULTI='custrecord_appf_corp_credit_card_multi';
var FLD_CREDIT_CARD_TYPE='custrecord_appf_corp_credit_card_type';
var SPARAM_DATA_FILE_OF_BILL_AND_CREDITS='custscript_bill_and_billcredit_data_file';
var SPARAM_VVCCP_MASTER_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
var SPARAM_VVCCP_SCRIPT_INDEX = 'custscript_vvccp_script_index';


function schedule(type)
{
	
	var context = nlapiGetContext();
	var vvccpProcessApprovedRecordsSearchId=context.getSetting('SCRIPT',SPARAM_VVCCP_PROCESS_APPROVED_RECORDS);
	var vvccpProcessApprovedRecordsSearch=nlapiLoadSearch(null, vvccpProcessApprovedRecordsSearchId);
	var vvccpProcessApprovedRecordsSearchFilts = vvccpProcessApprovedRecordsSearch.getFilters();
	var vvccpProcessApprovedRecordsSearchColumns=vvccpProcessApprovedRecordsSearch.getColumns();
	var vvccpProcessApprovedRecordsSearchSSType = vvccpProcessApprovedRecordsSearch.getSearchType();
	var vvccpProcessApprovedRecordsSearchResults=getAllSearchResults(vvccpProcessApprovedRecordsSearchSSType, vvccpProcessApprovedRecordsSearchFilts, vvccpProcessApprovedRecordsSearchColumns);
	if(vvccpProcessApprovedRecordsSearchResults !=null && vvccpProcessApprovedRecordsSearchResults !='')
	{
		for(var s=0;s<vvccpProcessApprovedRecordsSearchResults.length;s++)
		{
			var searchresult = vvccpProcessApprovedRecordsSearchResults[s];
			var vvccpExecutionBatchREcordId = searchresult.getId();
			nlapiLogExecution('debug','vvccpExecutionBatchREcordId:',vvccpExecutionBatchREcordId);
			if(vvccpExecutionBatchREcordId !=null && vvccpExecutionBatchREcordId !='')
			{
				nlapiSubmitField(CUSTOMRECORD_MASTER_BATCH, vvccpExecutionBatchREcordId, FLD_MASTER_BATCH_SENT_FOR_PROCESSING, 'T');
				
				var vvccpRecordLinks=[];
	var vvccpRecordId='';
	var processingComplete = true;
	var vvccpMasterBatchRecordId = vvccpExecutionBatchREcordId;
	if(vvccpMasterBatchRecordId != null && vvccpMasterBatchRecordId != '')
	{
		var vvccpMasterBatchRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD,vvccpMasterBatchRecordId)
		var dataFile=vvccpMasterBatchRecord.getFieldValue(FLD_BILL_AND_CREDIT_DETAIL_TEXT_FILE);
		var authsCreatedSuccessfully = vvccpMasterBatchRecord.getFieldValue(FLD_AUTHORIZATION_CREATED_SUCCESSFULLY);
		if(dataFile !=null && dataFile !='' && authsCreatedSuccessfully != 'T')
		{
		var fileRec=nlapiLoadFile(dataFile);
		var fileDetails=fileRec.getValue();

		//nlapiLogExecution('debug','fileDetails:',fileDetails);
	
		var mainArr=JSON.parse(fileDetails);
		nlapiLogExecution('debug','mainArr:',JSON.stringify(mainArr));
		var vvccpObj={};
		var errorWhileProcessingBatch='';
		var numberOfAuthorizationGenerated=0;
		numberOfAuthorizationGenerated = vvccpMasterBatchRecord.getFieldValue(FLD_NUMBER_OF_AUTHORIZATION_GENERATED);
		if (numberOfAuthorizationGenerated == null || numberOfAuthorizationGenerated == '')
			numberOfAuthorizationGenerated = 0;
		numberOfAuthorizationGenerated = parseFloat(numberOfAuthorizationGenerated);
		for(var i = 0; i < mainArr.length; i++)
		{
			var d = new Date();
			var timeStamp = d.getTime();
			var errorLog = '';
			var mainObj = mainArr[i].data;
			var prop = mainArr[i].vendorid;
			
			nlapiLogExecution('debug','Vendor',prop);
			nlapiLogExecution('debug','mainObj',JSON.stringify(mainObj));
			//var currency = mainArr[i].currency;
			try{
					
			var vendorRec=nlapiLoadRecord('vendor',prop);
			var currency = vendorRec.getFieldValue('currency');
			nlapiLogExecution('debug','currency',currency);
			
			var corporateCreditCardVvccp=vendorRec.getFieldValue(CORPORATE_CREDIT_CARD_VVCCP);
			nlapiLogExecution('debug','corporateCreditCardVvccp',corporateCreditCardVvccp);
			var isMultiUse = null;
			var cardType='';
			if(corporateCreditCardVvccp !=null && corporateCreditCardVvccp !='')
			{
			var ccRecord =nlapiLoadRecord(CUSTOM_RECORD_CORPORATE_CREDIT_CARD_VENDOR_PAYMENT ,corporateCreditCardVvccp)
			isMultiUse=ccRecord.getFieldValue(FLD_CORPORATE_CREDIT_CARD_IS_MULTI);
			cardType=ccRecord.getFieldValue(FLD_CREDIT_CARD_TYPE);
			if (isMultiUse == 'T')
				isMultiUse = true;
			else
				isMultiUse = false;
			}
			nlapiLogExecution('debug','isMultiUse',isMultiUse);
			var sumOfVendorBills=0;
			var sumOfVendorCredits=0;
			var pwpLinks = [];
			var vendorbills=mainObj['vendorbill'];
			var vendorcredits=mainObj['vendorcredit'];
			var vendorName=mainObj.vendorname;
			nlapiLogExecution('debug','vendorName',vendorName);
			nlapiLogExecution('debug','vendorbills',JSON.stringify(vendorbills));
			nlapiLogExecution('debug','vendorcredits',JSON.stringify(vendorcredits));
			var totalvvccpProcessed = 0;
			var minimumToSpend=0;
			var maximumToSpend=0;
			var uniqueBills = {};
			var uniqueCredits = {};
			var totalBills = [];
			var totalCredits = [];
			var billsWithPipeDelimited='';
			var creditsWithPipeDelimited='';
			var executionBatchRecDataFile='';
			var executionBatchBillDataFile='';
			var executionBatchCreditDataFile='';
			executionBatchBillDataFile+='Bill Id,Bill Line Id,Line PWP,Bill Amount\n';
			executionBatchCreditDataFile+='Credit Id,Credit Amount\n';
			executionBatchRecDataFile+='Vendor,No. of Bills,Bill Ids,Bill Amount,No. of Credits,Credit Ids,Credits Amont,Total Auth Amount\n';
			var billLines=0;
			var creditLines=0;
			var numberOfBills=0;
			var numberOfCredits=0;
			if(vendorbills !=null && vendorbills !='')
			{
				for(var v=0;v<vendorbills.length;v++)
				{					
					var amountInVendorBill=vendorbills[v].payment;
					var vbid = vendorbills[v].id;
					var vbTranid=vendorbills[v].tranid;
					var pwp = vendorbills[v].pwp;
					totalBills.push(vbid);
					var vbid_line = vendorbills[v].lineid;
					nlapiLogExecution('debug','vbid_line:',vbid_line)
					executionBatchBillDataFile+= vbTranid+','+vbid_line+','+pwp+','+amountInVendorBill+'\n';
					if (!uniqueBills.hasOwnProperty(vbid))
					{
						uniqueBills[vbid] = [];
						numberOfBills++;
					}
					var existingBillLineIds = uniqueBills[vbid];
					existingBillLineIds.push(vbid_line);
					uniqueBills[vbid] = existingBillLineIds;
					nlapiLogExecution('debug','uniqueBills:',uniqueBills)
					sumOfVendorBills =parseFloat(sumOfVendorBills)+parseFloat(amountInVendorBill);
					nlapiLogExecution('debug','sumOfVendorBills:',sumOfVendorBills)
					
					nlapiLogExecution('debug','pwp:',pwp)
                  	if(pwp !=null && pwp !='' && pwp !='null')
					pwpLinks.push(pwp);
					if(v != vendorbills.length-1)
					billsWithPipeDelimited=billsWithPipeDelimited+vbTranid+'|';
					else
					billsWithPipeDelimited=billsWithPipeDelimited+vbTranid;
				billLines++
				}
			}
			if(vendorcredits !=null && vendorcredits !='')
			{
				for(var c=0;c<vendorcredits.length;c++)
				{	
					var amountInVendorCredit=vendorcredits[c].payment;
					var vcid = vendorcredits[c].id;
					var vcTranid=vendorcredits[c].tranid;
					executionBatchCreditDataFile+=vcTranid+','+amountInVendorCredit+'\n';
					totalCredits.push(vcid);
					if (!uniqueCredits.hasOwnProperty(vcid))
					{
						uniqueCredits[vcid] = vcid;
						numberOfCredits++;
					}
					sumOfVendorCredits =parseFloat(sumOfVendorCredits)+parseFloat(amountInVendorCredit);
					if(c != vendorcredits.length-1)
					creditsWithPipeDelimited=creditsWithPipeDelimited+vcTranid+'|';
					else
					creditsWithPipeDelimited=creditsWithPipeDelimited+vcTranid;
				creditLines++;
				}
			}			
			if(!isMultiUse)
			minimumToSpend =parseFloat(sumOfVendorBills) - parseFloat(sumOfVendorCredits);
			else
			{
			if(cardType == 2)
			minimumToSpend = 1;
			else
			minimumToSpend = 0;
			}
			maximumToSpend = parseFloat(sumOfVendorBills) - parseFloat(sumOfVendorCredits);
			//var totalAuthorizationAmount=maximumToSpend;
			
			
			var totalLinesToProcess=parseInt(billLines)+parseInt(creditLines);
			executionBatchRecDataFile +=vendorName+','+numberOfBills+','+billsWithPipeDelimited+','+sumOfVendorBills+','+numberOfCredits+','+creditsWithPipeDelimited+','+sumOfVendorCredits+','+maximumToSpend;
			var executionBatchRecDataFileId=nlapiCreateFile('Selected_Bill_And_billCredits_List_Execution_Batch'+timeStamp+'_'+i+'.csv','CSV',executionBatchRecDataFile);
				executionBatchRecDataFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var executionBatchRecDataFileCr= nlapiSubmitFile(executionBatchRecDataFileId);
			var executionBatchBillDataFileId=nlapiCreateFile('Selected_Bill_List_Execution_Batch'+timeStamp+'_'+i+'.csv','CSV',executionBatchBillDataFile);
				executionBatchBillDataFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var executionBatchBillDataFileCr= nlapiSubmitFile(executionBatchBillDataFileId);
		var executionBatchCreditDataFileId=nlapiCreateFile('Selected_billCredits_List_Execution_Batch'+timeStamp+'_'+i+'.csv','CSV',executionBatchCreditDataFile);
				executionBatchCreditDataFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var executionBatchCreditDataFileCr= nlapiSubmitFile(executionBatchCreditDataFileId);
				
				var customRec=nlapiCreateRecord(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH);
				customRec.setFieldValue(MASTER_BATCH_RECORD_LINK,vvccpMasterBatchRecordId);
				customRec.setFieldValue('name', 'VVCCP EXCCUTION BATCH'+timeStamp+i);
				
				customRec.setFieldValue(FLD_TOTAL_VENDOR_BILL_TO_PROCESS,billLines);
				customRec.setFieldValue(FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS,creditLines);
				customRec.setFieldValue(FLD_EXECUTION_BATCH_VENDOR,prop);
				customRec.setFieldValue(FLD_TOTAL_AUTHORIZATION_AMOUNT,maximumToSpend);
				customRec.setFieldValue(FLD_DATA_FILE,executionBatchRecDataFileCr);
				customRec.setFieldValue(FLD_BILL_DATA_FILES,executionBatchBillDataFileCr);
				customRec.setFieldValue(FLD_CREDIT_DATA_FILE,executionBatchCreditDataFileCr);
				customRec.setFieldValues(FLD_VENDOR_BILL_LINKS,totalBills);
				customRec.setFieldValues(FLD_VENDOR_CREDIT_LINKS,totalCredits);
				var vvccpExecutionBatchREcordId=nlapiSubmitRecord(customRec,true,true);
				nlapiLogExecution('debug','vvccpExecutionBatchREcordId:',vvccpExecutionBatchREcordId);			
			try
			{
			if(vvccpExecutionBatchREcordId)
			{
			var vvccpRecord=nlapiCreateRecord(CUSTOM_RECORD_VVCCP);
			var nameForVvccp='PA'+randomString(14);
			var intid = vvccpExecutionBatchREcordId.toString();
			var intidlenforsplit = intid.length*-1;
			//var intidlen=intid.length;
			nameForVvccp = nameForVvccp.slice(0, intidlenforsplit)+''+intid;
			vvccpRecord.setFieldValue('name', nameForVvccp);
			if(!isMultiUse)
			vvccpRecord.setFieldValue(FLD_TYPE,VVCCP_CARD_TYPE_SINGLE_USE);
			else
			vvccpRecord.setFieldValue(FLD_TYPE,VVCCP_CARD_TYPE_MULTI_USE);
			vvccpRecord.setFieldValue(FLD_MINIMUM_TO_SPEND,parseFloat(minimumToSpend).toFixed(2));
			nlapiLogExecution('debug','maximumToSpend:',maximumToSpend);
			vvccpRecord.setFieldValue(FLD_MAXIMUM_TO_SPEND,parseFloat(maximumToSpend).toFixed(2));
            nlapiLogExecution('debug','pwpLinks:',pwpLinks);
			if(pwpLinks.length > 0)
			vvccpRecord.setFieldValues(FLD_PWP_RECORD_LINKS, pwpLinks);
			nlapiLogExecution('debug','vvccpExecutionBatchREcordId:',vvccpExecutionBatchREcordId);
			vvccpRecord.setFieldValue(FLD_VVCCP_BATCH_LINK,vvccpExecutionBatchREcordId);
			nlapiLogExecution('debug','currency:',currency);
			vvccpRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PENDING_BATCH);
            vvccpRecord.setFieldValue(FLD_CURRENCY,currency);
			vvccpRecord.setFieldValue(FLD_VENDOR,prop);
			if(corporateCreditCardVvccp)
			nlapiLogExecution('debug','corporateCreditCardVvccp:',corporateCreditCardVvccp);vvccpRecord.setFieldValue(FLD_CORPORATE_CREDIT_CARD,corporateCreditCardVvccp);
			vvccpRecordId=nlapiSubmitRecord(vvccpRecord,true,true);
			nlapiLogExecution('debug','vvccpRecordId:',vvccpRecordId);	
			}
		}
		catch(e)
		{
			if ( e instanceof nlobjError )
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+'\nReason: '+e.getDetails()+'\n\n';
			else
			errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+'\nReason: '+e.toString()+'\n\n';
		}
		if (vvccpRecordId)
		{
		var linkedTransactionProcessed=0;	
		numberOfAuthorizationGenerated++;
		var statusFileForExecutionBatch='';
		statusFileForExecutionBatch='Bills Id,Credit Id,Status,Reson\n';
		if(vendorbills !=null && vendorbills !='')
			{
				for(var v=0;v<vendorbills.length;v++)
				{	
					var vendorBillId=vendorbills[v].id;
					var vendorBillLineId=vendorbills[v].lineid;
					var amountInVendorBill=vendorbills[v].payment;
					var transactionType=17;
					var billLinePWP=vendorbills[v].pwp;
					var masterVendorBillRef=vendorbills[v].masterRec;
					var serviceDate=vendorbills[v].servicedate;
					var pwpClient=vendorbills[v].pwpclient;
					var mediasupplier=vendorbills[v].mediasupplier;
					var ioNumber=vendorbills[v].ionumber;
					try
					{
						var vvccpLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS);
						vvccpLinkedTransactionRec.setFieldValue(FLD_VVCCP_LINK, vvccpRecordId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,vendorBillId);
						if(vendorBillLineId !=null && vendorBillLineId !='')
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_ID,vendorBillLineId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,parseFloat(amountInVendorBill).toFixed(2));
						if(billLinePWP !=null && billLinePWP !='')
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_PWP,billLinePWP)
						vvccpLinkedTransactionRec.setFieldValue(FLD_LINKED_TRANSACTION_TYPE,transactionType);
						if(masterVendorBillRef)
						vvccpLinkedTransactionRec.setFieldValue(FLD_MASTER_VENDOR_BILL_REF,masterVendorBillRef);
						if(serviceDate)
						vvccpLinkedTransactionRec.setFieldValue(FLD_SERVICE_DATE,serviceDate);
						if(pwpClient)
						vvccpLinkedTransactionRec.setFieldValue(FLD_CLIENT_NAME,pwpClient);
						if(mediasupplier)
						vvccpLinkedTransactionRec.setFieldValue(FLD_MEDIA_SUPPLIER_NAME,mediasupplier);
						if(ioNumber)
						vvccpLinkedTransactionRec.setFieldValue(FLD_ORDER_REFERENCE_NUMBER,ioNumber);
						var vvccpLinkedTransactionRecId=nlapiSubmitRecord(vvccpLinkedTransactionRec,true,true);
						linkedTransactionProcessed++;
						statusFileForExecutionBatch+=vendorBillId+','+''+','+'Success'+','+''+'\n'
					}
					catch(e)
					{
						if ( e instanceof nlobjError )
						{
						statusFileForExecutionBatch+=vendorBillId+','+''+','+'Failed'+','+e.getDetails()+'\n'							
						errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB Line ID: '+vendorBillLineId+'\nReason: '+e.getDetails()+'\n\n';
						}
					else
					{
						statusFileForExecutionBatch+=vendorBillId+','+''+','+'Failed'+','+e.toString()+'\n'							
						errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB Line ID: '+vendorBillLineId+'\nReason: '+e.toString()+'\n\n';
					}
					}
					if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				}
				
			}

			if(vendorcredits !=null && vendorcredits !='')
			{
				var sumOfVendorCredits=0;
				for(var c=0;c<vendorcredits.length;c++)
				{
					var transactionType=20;
					var vendorCreditId=vendorcredits[c].id;	
					var vendorCreditRec = nlapiLoadRecord('vendorcredit', vendorCreditId);
					var amountInVendorCredit=vendorcredits[c].payment;
					var vendorCrediCount=vendorCreditRec.getLineItemCount('item')
					if(vendorCrediCount>0)
					{
						var masterVendorBillRef=''
						var masterVendorBillNum=vendorCreditRec.getLineItemValue('item',FLD_COL_MASTER_RECORD_LINK,1);
                      nlapiLogExecution('debug','masterVendorBillNum:',JSON.stringify(masterVendorBillNum));
						if(masterVendorBillNum!=null && masterVendorBillNum!='')
						{
							masterVendorBillRef=nlapiLookupField(CUSTOM_RECORD_MASTER_VENDOR_INVOICE,masterVendorBillNum,FLD_INV_REFERENCE_NUMBER)
						}
					  //  var serviceDate=vendorcredits[c].servicedate;
					    var pwpClientId=vendorCreditRec.getLineItemValue('item',FLD_COL_PWP_CUSTOM_RECORD,1);
						var pwpClient=''
						if(pwpClientId!=null && pwpClientId!='')
						  pwpClient=nlapiLookupField(CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER,pwpClientId,FLD_CLIENT_NAME)
					    var mediasupplier=vendorCreditRec.getLineItemValue('item',FLD_COL_PUBLISHER,1);
					    var ioNumber=vendorCreditRec.getLineItemValue('item',FLD_COL_IO_NUMBER,1);
						var serviceDate = vendorCreditRec.getLineItemValue('item', FLD_COL_SERVICE_DATE, 1);
						if (serviceDate == null)
							serviceDate = '';
                      nlapiLogExecution('debug','pwpClient',JSON.stringify(pwpClient));
                      nlapiLogExecution('debug','ioNumber',JSON.stringify(ioNumber));
					}
					try
					{
						var vvccpLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS);
						vvccpLinkedTransactionRec.setFieldValue(FLD_VVCCP_LINK, vvccpRecordId);
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,vendorCreditId)
						vvccpLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,parseFloat(amountInVendorCredit).toFixed(2));
						vvccpLinkedTransactionRec.setFieldValue(FLD_LINKED_TRANSACTION_TYPE,transactionType);

						if(masterVendorBillRef)
						vvccpLinkedTransactionRec.setFieldValue(FLD_MASTER_VENDOR_BILL_REF,masterVendorBillRef);
						if(serviceDate)
						vvccpLinkedTransactionRec.setFieldValue(FLD_SERVICE_DATE,serviceDate);
						if(pwpClient)
						vvccpLinkedTransactionRec.setFieldValue(FLD_CLIENT_NAME,pwpClient);
						if(mediasupplier)
						vvccpLinkedTransactionRec.setFieldValue(FLD_MEDIA_SUPPLIER_NAME,mediasupplier);
						if(ioNumber)
						vvccpLinkedTransactionRec.setFieldValue(FLD_ORDER_REFERENCE_NUMBER,ioNumber);
						var vvccpLinkedTransactionRecId=nlapiSubmitRecord(vvccpLinkedTransactionRec,true,true);
						linkedTransactionProcessed++;
						statusFileForExecutionBatch+=''+','+vendorCreditId+','+'Success'+','+''+'\n';
					}
					catch(e)
					{
						if ( e instanceof nlobjError )
						{
							statusFileForExecutionBatch+=''+','+vendorCreditId+','+'Failed'+','+e.getDetails()+'\n'
						errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit: '+vendorCreditId+'\nReason: '+e.getDetails()+'\n\n';
						}
						else
						{
							statusFileForExecutionBatch+=''+','+vendorCreditId+','+'Failed'+','+e.toString()+'\n'
						errorLog += '---> Error creating VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit: '+vendorCreditId+'\nReason: '+e.toString()+'\n\n';
						}
					}
					if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				}
				
			}
			nlapiLogExecution('debug','linkedTransactionProcessed totalLinesToProcess:',linkedTransactionProcessed+'_'+totalLinesToProcess)
				if(parseInt(linkedTransactionProcessed) == parseInt(totalLinesToProcess))
				{
					
					var processPercentage=(parseFloat(linkedTransactionProcessed)/parseFloat(totalLinesToProcess))*100;
					nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId,[FLD_PROCESSED_PERCENT_EXECUTION_BATCH,FLD_LINKED_TRANSACTIONS_CREATED],[processPercentage,'T']);
				}
				}
			}
			catch(e)
			{
				if ( e instanceof nlobjError )
				errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+' for vendor id '+prop+' & currency '+currency+'\nReason: '+e.getDetails()+'\n\n';
				else
				errorLog += '---> Error creating VVCCP main record for Batch: '+vvccpExecutionBatchREcordId+' for vendor id '+prop+' & currency '+currency+'\nReason: '+e.toString()+'\n\n';
			}
			var executionBatchLinkedStatusFileId=nlapiCreateFile('_Execution_Batch_linked_Tran_Status'+timeStamp+'_'+i+'.csv','CSV',statusFileForExecutionBatch);
				executionBatchLinkedStatusFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var executionBatchLinkedStatusFileCr= nlapiSubmitFile(executionBatchLinkedStatusFileId);
				
			var vvccpBatchFields = [FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS,FLD_TOTAL_VVCCP_RECORDS_PROCESSED];
			var vvccpBatchValues = nlapiLookupField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, vvccpBatchFields);
			var toProcess = vvccpBatchValues[FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS];
			if(toProcess == null || toProcess == '')
				toProcess=0;
			toProcess++;
			var processed = vvccpBatchValues[FLD_TOTAL_VVCCP_RECORDS_PROCESSED];
			if (processed == null || processed == '')
				processed = 0
			processed++;
			nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, [FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS,FLD_TOTAL_VVCCP_RECORDS_PROCESSED,FLD_ERROR_LOG,FLD_VVCCP_RECORD_LINK,FLD_STATUS_FILE,MASTER_BATCH_RECORD_UPDATED], [toProcess,processed,errorLog,vvccpRecordId,executionBatchLinkedStatusFileCr,'T']);
			
			nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD,vvccpMasterBatchRecordId,FLD_NUMBER_OF_AUTHORIZATION_GENERATED,numberOfAuthorizationGenerated);
			
			for (var vbprop in uniqueBills)
				{
					try{
						var vbRec = nlapiLoadRecord('vendorbill', vbprop);
					var vb_lines = uniqueBills[vbprop];
					var vbbatchRecLinks = [];
					vbbatchRecLinks.push(vvccpExecutionBatchREcordId);
					if (vbRec.getFieldValue(FLD_BATCH_RECS_LINKS))
					{
					var existingBatchLinks = vbRec.getFieldValues(FLD_BATCH_RECS_LINKS);
					vbbatchRecLinks = vbbatchRecLinks.concat(existingBatchLinks);
					}
					for (var j = 0; j < vb_lines.length; j++)
					{
						var matchedline = vbRec.findLineItemValue('item', FLD_VB_LINE_ID, vb_lines[j]);
						if (matchedline > 0)
						{
							vbRec.setLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, matchedline, 'T');
						}
					}
					vbRec.setFieldValue(FLD_VVCCCP_PROCESSING_STATUS, '3');
					vbRec.setFieldValues(FLD_BATCH_RECS_LINKS, vbbatchRecLinks);
					nlapiSubmitRecord(vbRec);
					}
					catch(e)
					{
						if ( e instanceof nlobjError )
						errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB ID: '+vbprop+'\nReason: '+e.getDetails()+'\n\n';
						else
						errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & VB ID: '+vbprop+'\nReason: '+e.toString()+'\n\n';
					}
					if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				}
			for (var vcprop in uniqueCredits)
				{
					try{
					var vcRec = nlapiLoadRecord('vendorcredit', vcprop);
					var vcbatchRecLinks = [];
					vcbatchRecLinks.push(vvccpExecutionBatchREcordId);
					if (vcRec.getFieldValue(FLD_BATCH_RECS_LINKS))
					{
					var existingBatchLinks = vcRec.getFieldValues(FLD_BATCH_RECS_LINKS);
					vcbatchRecLinks = vcbatchRecLinks.concat(existingBatchLinks);
					}
					vcRec.setFieldValue(FLD_VVCCCP_PROCESSING_STATUS, '3');
					vcRec.setFieldValue(FLD_PENDING_AUTHORIZATION_VVCCP, 'T');
					vcRec.setFieldValues(FLD_BATCH_RECS_LINKS, vcbatchRecLinks);
					nlapiSubmitRecord(vcRec);
					}
					catch(e)
					{
						if ( e instanceof nlobjError )
						errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit ID: '+vcprop+'\nReason: '+e.getDetails()+'\n\n';
						else
						errorLog += '---> Error moving to Ready Processing for VVCCP sub-record record for Batch: '+vvccpExecutionBatchREcordId+' & Vendor Credit ID: '+vcprop+'\nReason: '+e.toString()+'\n\n';
					}
					if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				}
			if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
	}
	if (processingComplete)
	{
					//nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, vvccpExecutionBatchREcordId, FLD_APPROVAL_TRIGGERED, 'T');
					nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD,vvccpMasterBatchRecordId,FLD_AUTHORIZATION_CREATED_SUCCESSFULLY,'T');
	}
	}	
}
			}
			if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
		}
	}



	

}	



function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
		
		
		
		function randomString(length) {
	var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var u = length; u > 0; --u) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}


function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}
