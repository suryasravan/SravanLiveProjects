/**
*Script Name: Appf-Connex to NetSuite Media Suppl REST
*Script Type: 
*Description:  This script when executed checks for any new messages in the queue related to Connex mediasupplier and pushes the mediasupplier from those messages into netsuite and creates or updates as mediasupplier records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
var SPARAM_CONNEX_CLIENT='customscript_appf_connex_medsupp_2_ns_sc'
function getMediaSupplierRESTlet(dataIn)
{
		  
           nlapiScheduleScript(SPARAM_CONNEX_CLIENT,null)   
  return 'RESTlet successfully connected.';
}