/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */


var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;

var sftpserverobj = {};
sftpserverobj.amextest = {};
sftpserverobj.mastercardtest = {};

//SFTP Details of AMEX TEST
sftpserverobj.amextest.username =  'novus_test';
sftpserverobj.amextest.guid = '7742e42e9dc24bd7b3970ce4b5a61861';
sftpserverobj.amextest.domain = 'fsgateway.aexp.com';
sftpserverobj.amextest.hostkey = 'AAAAB3NzaC1yc2EAAAADAQABAAABAQDUs0jorN2/HIsD2HJyeETzpyU4duAMYY7GTgGHe1GYZCh3Z4VvU+just0G3cGVgt6zmZVgb5tmZqDqvqrnssvFhSK2d5WxVTkvZM0saFw3MCYFg0I6KszUKeQawwDDgrcgUGbCfLY0KE5oe3JwlPGyhAeQ+HCEP2+yxWFNI8AL0oykXGWUdxt9jJrFqErKUtvVymCo8lnwUJoNagVRKm/iwwNUSmd0TppOYEg0PAeBcc728zUskvqKMk4tDwP1yXkJ+5QdVC6xxwHgjF9FPX8BvL3Ku2LeyVtKPN9FrHABsu0ZmJv1dFqbrj+cOf2jzE99cadH8HtSXqb8LlmRhYtF';
sftpserverobj.amextest.hostkeytype = 'rsa';
sftpserverobj.amextest.directory = '/'

//SFTP Details of MasterCard Test
sftpserverobj.mastercardtest.username =  'novussr';
sftpserverobj.mastercardtest.guid = '48d5d76503d6483bb3244ee4f5bb38be';
sftpserverobj.mastercardtest.domain = 'securefiletransferuat.citigroup.com';
sftpserverobj.mastercardtest.hostkey = 'AAAAB3NzaC1yc2EAAAADAQABAAABAQDnQp2qLHe1ERs9TLE6k8x5/KEf4Z+9TNXzLs2pyzETIAhO0mN057WsnY3x7M9uubraGaSVDdyeOogrR5uoFHHPJw3KO10TNubZW7ENBiLTL7TCPSUcsRxoZRueOVZMQlo83tLvpIU6fg3SpaumzVEzzQXbzK2XUI+MWSKIZO57R34gA1XJMGnulcq6g+DOT6bH+0/A/r88jOJ+RV2g1jvxqbYzs9Kn4Z/RHLK3ZipSx2CFK1Ois9TEDZc+U4FvliYIKDIWDFkQ4iy+HVGhOQ7WyQSobOXNeDLic+frMHRZ4ziY2Y9/70JZUvjLvp8kURWsyT2K9xbrJiBYhT+gKJr1';
sftpserverobj.mastercardtest.hostkeytype = 'rsa';
sftpserverobj.mastercardtest.directory = '/';

var CUSTOM_RECORD_CI = 'customrecord_nsts_ci_consolidate_invoice';
var SPARAM_INDEX = 'custscript_sftp_file_index';
var SPARAM_FILE_ID = 'custscript_sftp_file_id';


define(['N/search', 'N/runtime', 'N/sftp', 'N/keyControl', 'N/file', 'N/record', 'N/https', 'N/url', 'N/task'],
    function(search, runtime, sftp, keyControl, file, record, https, url, task) {
        function execute(context) 
		{     
			
			
				
				
				var cardType = context.request.parameters.creditCardType;
				log.debug('cardType : ', cardType);
				var fileID = context.request.parameters.fileID;
				log.debug('fileID : ', fileID);
				
				var connection = null;
				
				if (cardType == CREDIT_CARD_TYPE_MASTERCARD)
				{
					
                try{
            
					connection = sftp.createConnection({
					username: sftpserverobj.mastercardtest.username,
					passwordGuid: sftpserverobj.mastercardtest.guid,
					url: sftpserverobj.mastercardtest.domain,
					hostKey: sftpserverobj.mastercardtest.hostkey,
					hostKeyType: sftpserverobj.mastercardtest.hostkeytype
				});
                  log.debug('Master Card connection : ', 'Success');
                }
				catch(ep)
				{
				  connection = null;
				}
				if (connection == null)
				{
					connection = sftp.createConnection({
					username: sftpserverobj.mastercardtest.username,
					passwordGuid: sftpserverobj.mastercardtest.guid,
					url: sftpserverobj.mastercardtest.domain,
					hostKey: sftpserverobj.mastercardtest.hostkey,
					hostKeyType: sftpserverobj.mastercardtest.hostkeytype
					});
                  log.debug('Master Card connection : ', 'Success');
				  
				}
				}
				
				
				
				if (cardType == CREDIT_CARD_TYPE_AMEX)
				{
					
                try{
            
					connection = sftp.createConnection({
					username: sftpserverobj.amextest.username,
					passwordGuid: sftpserverobj.amextest.guid,
					url: sftpserverobj.amextest.domain,
					hostKey: sftpserverobj.amextest.hostkey,
					hostKeyType: sftpserverobj.amextest.hostkeytype
				});
                  log.debug('AMEX connection : ', 'Success');
                }
				catch(ep)
				{
				  connection = null;
				}
				if (connection == null)
				{
					connection = sftp.createConnection({
					username: sftpserverobj.amextest.username,
					passwordGuid: sftpserverobj.amextest.guid,
					url: sftpserverobj.amextest.domain,
					hostKey: sftpserverobj.amextest.hostkey,
					hostKeyType: sftpserverobj.amextest.hostkeytype
					});
                  log.debug('AMEX connection : ', 'Success');
				  
				}
				}
				
				
		
				if (connection == null)
				{
                  log.debug('SFTP Connection : ', 'Failed');
				}
			else {
				
					try{
					  
						var myFileToUpload = file.load({
							id: fileID
						});
						
			                  log.debug('File Name being sent to SFTP : ', myFileToUpload.name);


						connection.upload({
						  file: myFileToUpload,
                          replaceExisting: true,
                          filename: (cardType == CREDIT_CARD_TYPE_MASTERCARD)?myFileToUpload.name:'267236.'+myFileToUpload.name,
						  directory: (cardType == CREDIT_CARD_TYPE_MASTERCARD)?sftpserverobj.mastercardtest.directory:sftpserverobj.amextest.directory
						});
						
								  
											 
    }catch(e)
			{
				log.debug('Error in SFTP File Upload:',e);
			}

			}	
        }
        return {
            onRequest: execute
        };
    });