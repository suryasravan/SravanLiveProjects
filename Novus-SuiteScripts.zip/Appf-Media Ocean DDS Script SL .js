/*Script Name: Appf - Media Ocean DDS Script SL
 *Script Type: Suitelet
 *Company 	 : Appficiency
 * Version    Date            	Author			Remarks
 * 1.0		26 May 2020     		          	This script displays an UI/form with filters and columns based on Saved Search of  Sales Orders line items which provides users with ability to mark multiple lines
 * 1.2		17 Aug 2020			MJ De Asis		Added Start Date and End Date Filters
 * 1.3		17 Aug 2020			MJ De Asis		Update dds header where A = New, C = Updates, D = Deletes
 * 1.4		26 Aug 2020			MJ De Asis		Change Start Date and End Date Filters to Range
 * 1.5		24 Sep 2020  		Roach			Add SO Status filter
 * 1.6		29 Oct 2020  		Roach			Line Changes to INS
 * 1.7		19 Nov 2020			MJ De Asis		Added Vendor Filter
 */

var FLD_AGENCY = 'custpage_agency';

var FLD_ACD_STATUS = 'custpage_acd_status';
var FLD_SL_DOMEDIA_PO = 'custpage_domedia_po';
//var FLD_SL_PROJECT = 'custpage_project';
var FLD_SL_PRODUCT_CODE = 'custpage_ddproduct_code';
var FLD_SL_MARKET = 'custpage_market';
var FLD_SL_ESTIMATE = 'custpage_estimate';
var FLD_SL_CLIENT_CODE = 'custpage_client_code';
var FLD_SL_CLIENTS = 'custpage_client';
var FLD_SL_RATE_TYPE = 'custpage_type';
/// v1.2
var FLD_SL_STARTDATERR = 'custpage_startdate';
var FLD_SL_ENDDATERR = 'custpage_enddate';
/// v1.4
var FLD_SL_STARTDATERR_STARTDATE = 'custpage_startdaterr_startdate';
var FLD_SL_STARTDATERR_ENDDATE = 'custpage_startdaterr_enddate';
var FLD_SL_ENDDATERR_STARTDATE = 'custpage_enddaterr_startdate';
var FLD_SL_ENDDATERR_ENDDATE = 'custpage_enddaterr_enddate';
/// v1.7
var FLD_SL_VENDOR = 'custpage_vendor';

var FLD_SL_STATUS = 'custpage_status';

var FLD_COL_STATUS = 'custcol_appf_do_arcstatus';
var FLD_COL_PO_MEDIA_SEGMENT = 'line.cseg_appf_media_seg';
var FLD_COL_DO_DDS_ESTIMATE= 'custcol_appf_do_dds_estimate';
var FLD_COL_DO_DDS_CLIENTCODE = 'custcol_appf_do_dds_clientcode';
var FLD_COL_DO_DDS_PRODUCT= 'custcol_appf_do_dds_product';
var FLD_COL_MARKET = 'custcol_appf_do_marketcode';  //'custcol_appf_do_market';
var FLD_SL_TOTAL_LINES = 'custpage_total_lines';
var CUSTOM_RECORD_OCEAN_FILE = 'customrecord_appf_media_ocean_file_log';
var CUSTOM_FLD_ACD_STATUS = 'custrecord_appf_acd_status';
var CUSTOM_FLD_OCEN_CLIENT = 'custrecord_appf_media_ocean_client';
var CUSTOM_FLD_ESTIMATE = 'custrecord_dds_estimate';
var CUSTOM_FLD_FILE = 'custrecord_med_ocean_sl_data_file';
var FLD_DOMEDIA_OCEAN_LOG_CSV_DATA_FILE = 'custrecord_domed_ocean_csv_data';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_TO_PROCESS = 'custrecord_num_lines_selected';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED = 'custrecord_domed_ocean_processed';
var FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED = 'custrecord_domed_ocean_failed';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT = 'custrecord_demed_ocean_processed_percent';
var FLD_DOMEDIA_OCEAN_LOG_PROCESSING_STATUS = 'custrecord_ocean_file_proc_status';

var FLD_DOMEDIA_AGENCY_STATUS='custcol_appf_do_agency'


var MANDATORY_FILTERS_GROUP = 'mandatoryfiltersforfiledownload';
var OTHER_FILTERS_GROUP = 'otherfilters';
var ADDITIONAL_FILTERS_GROUP = 'additionalinformation';


var FLD_COL_PRODUCT_CODE = 'custcol_appf_do_ddpubcode';
var FLD_COL_MARKET_CODE = 'custcol_appf_do_ddspubcodemarket';
var FLD_COL_STRART_DATE_SO= 'custcolappf_so_line_startdate';
var FLD_COL_GROSS_POINT = 'custcol_appf_do_grossratingpoint';
var FLD_COL_NUM_UNITS = 'custcol_appf_do_numunits';
var FLD_COL_IO_NUM= 'custcol_appf_ionum';
var FLD_COL_RECORD_ID = 'custcol_appf_do_recordid';
var FLD_COL_INVOICE_NO = 'custcol_appf_do_vendorinvoiceno';
var FLD_COL_PROINCE_NO = 'custcol_appf_do_province';
var FLD_COL_FORMAT = 'custcol_appf_do_format';
var FLD_COL_CURRENT_CLIENT_GROSS = 'custcol_appf_po_current_client_gross';
var FLD_COL_MEDIA_TYPE = 'custcol_appf_do_mediatypename';
var FLD_COL_RATE_TYPE = 'custcol_appf_do_ratetypename';
// v1.2 Added
var FLD_COL_STARTDATERR = 'custcolappf_so_line_startdate';
var FLD_COL_ENDDATERR = 'custcol_appf_so_line_enddate';


var SCRIPT_OCEN_DDS_SCRIPT = 'customscriptappf_media_ocean_dds_scri_cl';
var SPARAM_OCEAN_SCRIPT_SS = 'custscript_appf_media_ocean_dds_scrip_ss';
var SPARAM_MARK_PO_CLOSE_FOLDER= 'custscript_appf_po_lines_for_close_folde';

var SL_SUBLIST = 'custpage_sl_sublist';
var FLD_COL_SL_SELECT = 'custpage_checkbox_selcet';
var FLD_COL_SL_INTERNAL_ID = 'custpage_so_internal_id';
var BTN_MARK_ALL = 'custpage_btn_mark_all';
var BTN_UNMARK_ALL = 'custpage_btn_unmark_all';
var BTN_APPLY_FILTER = 'custpage_apply_filters';

var SCRIPT_PO_LINES_CLOSE_SC = 'customscript_appf_po_lines_close_pros_sc';
var SPARAM_CSV_FILE_ID = 'custscript_appf_po_lines_close_folder';

var THRESHOLD_RECORDS =242;
//242
var SPARAM_MEDIA_OCEN_ID='custscript_appf_media_ocean_id'

var STATUS_INPROGRESS='2';
var STATUS_COMPLETED='4';
var STATUS_COMPLETED_ERRORS='5';
var FOLDER_NUMS=1141

function suiteletDDS(request, response){
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_OCEAN_SCRIPT_SS);
	//var folderID = context.getSetting('SCRIPT', SPARAM_MARK_PO_CLOSE_FOLDER);
	var loadSS, filts, columns, ssType;
	if (ssID!=null && ssID!='')
    {
        loadSS=nlapiLoadSearch(null, ssID);
    	filts = loadSS.getFilters();
		columns=loadSS.getColumns();
	 	ssType = loadSS.getSearchType();
	}

	if (request.getMethod() == 'GET')
    {
		try
        {
            var applyfilters = request.getParameter('applyfilters');
            var agency = request.getParameter('agency');
            var ACDStatus=request.getParameter('ACDStatus');
            var mediaSegment=request.getParameter('mediaSegment');
            var estimate=request.getParameter('estimate');
            var poNum=request.getParameter('ponum');
            var typeRate=request.getParameter('typerate');
            var client=request.getParameter('client');
            var clientCode=request.getParameter('clientCode');
            var productCode=request.getParameter('productCode');
            var market=request.getParameter('market');
            var status=request.getParameter('status') /*|| 'SalesOrd:G'*/;
            var arrStatus = [];
            if (status) {
                if (status.indexOf('\u0005') >= 0) {
                    arrStatus = status.split('\u0005');
                }
                else {
                    arrStatus = [ status ];
                }
            }
			/// v1.2
			//var startDateRR=request.getParameter('startdaterr');
			//var endDateRR=request.getParameter('enddaterr');
			/// v1.4
			var startdaterrStartDateVal=request.getParameter('startdaterr_startdate');
			var startdaterrEndDateVal=request.getParameter('startdaterr_enddate');
			var enddaterrStartDateVal=request.getParameter('enddaterr_startdate');
			var enddaterrEndDateVal=request.getParameter('enddaterr_enddate');
			/// v1.7
			var vendorVal = request.getParameter('vendor');

            var form = nlapiCreateForm('Media Ocean DDS Suitelet');
            form.setScript(SCRIPT_OCEN_DDS_SCRIPT);
            var mandatoryInfoGroup = form.addFieldGroup(MANDATORY_FILTERS_GROUP, 'Mandatory Filters for File Download');
            var otherInfoGroup = form.addFieldGroup(OTHER_FILTERS_GROUP, 'Other Filters');
            var InfoGroup = form.addFieldGroup(ADDITIONAL_FILTERS_GROUP, 'Additional Information');

            var agencyField = form.addField(FLD_AGENCY, 'text', 'Agency',null,ADDITIONAL_FILTERS_GROUP);
            agencyField.setMandatory(true);
            agencyField.setDefaultValue(agency);
            agencyField.setHelpText("Enter the Agency name. This field is used in file names. File Format: [Agency] .[ClientName].[DDSProductCode].[DDSEstimateCode]. [DDSHeader]. [RunDateTime].DDS.[filenumber].txt", false);
            var clientFld = form.addField(FLD_SL_CLIENTS, 'select','Client Name','customer',MANDATORY_FILTERS_GROUP);
            if(client != null && client != '')
                clientFld.setDefaultValue(client);
		    clientFld.setMandatory(true);
		    clientFld.setHelpText("Enter the Client for which the file needs to be generated.", false);

            var  ACDStatusFld = form.addField(FLD_ACD_STATUS, 'select', 'ACD Status','customlist329',MANDATORY_FILTERS_GROUP);
            if(ACDStatus != null && ACDStatus != '')
                ACDStatusFld.setDefaultValue(ACDStatus);
			ACDStatusFld.setMandatory(true);
			ACDStatusFld.setHelpText("Add, Change, Delete Status", false);

            var estimateFld = form.addField(FLD_SL_ESTIMATE, 'text','DDS Estimate',null,MANDATORY_FILTERS_GROUP);
            if (estimate != null && estimate != '')
                estimateFld.setDefaultValue(estimate);
		    estimateFld.setMandatory(true);
	        estimateFld.setHelpText("Enter the DDS Estimate# for which the file needs to be generated.", false);

            // nlapiLogExecution( 'DEBUG', 'testmedia', 'po*')
            var clientCodeFld = form.addField(FLD_SL_CLIENT_CODE, 'text','DDS Client Code',null,MANDATORY_FILTERS_GROUP);
            if (clientCode != null && clientCode != '')
                clientCodeFld.setDefaultValue(clientCode);
            clientCodeFld.setMandatory(true);

            var productCodeFld = form.addField(FLD_SL_PRODUCT_CODE, 'text','DDS Product Code',null,MANDATORY_FILTERS_GROUP);
            if(productCode != null && productCode != '')
                productCodeFld.setDefaultValue(productCode);
            productCodeFld.setMandatory(true);

            // clientCodeFld.setMandatory(true)
            // productCodeFld.setMandatory(true)

            var typeRateFld = form.addField(FLD_SL_RATE_TYPE, 'text','Rate Type Name',null,OTHER_FILTERS_GROUP);
            if(typeRate  != null && typeRate != '')
                typeRateFld.setDefaultValue(typeRate);

            var mediaPoFld = form.addField(FLD_SL_DOMEDIA_PO, 'text','DOMedia PO#',null,OTHER_FILTERS_GROUP);
            if (poNum  != null && poNum != '')
                mediaPoFld.setDefaultValue(poNum);

            var marketFld = form.addField(FLD_SL_MARKET, 'text','Market',null,OTHER_FILTERS_GROUP);
            if (market != null && market != '')
                marketFld.setDefaultValue(market);

            var statusFld = form.addField(FLD_SL_STATUS, 'multiselect','Status',null,OTHER_FILTERS_GROUP);

            //statusFld.addSelectOption('', '');
            statusFld.addSelectOption('SalesOrd:A', 'Pending Approval');
            statusFld.addSelectOption('SalesOrd:B', 'Pending Fulfillment');
            statusFld.addSelectOption('SalesOrd:C', 'Cancelled');
            statusFld.addSelectOption('SalesOrd:D', 'Partially Fulfilled');
            statusFld.addSelectOption('SalesOrd:E', 'Pending Billing/Partially Fulfilled');
            statusFld.addSelectOption('SalesOrd:F', 'Pending Billing');
            statusFld.addSelectOption('SalesOrd:G', 'Billed');
            statusFld.addSelectOption('SalesOrd:H', 'Closed');

            // nlapiLogExecution('debug','status', status);
            nlapiLogExecution('debug','arrStatus', arrStatus);
            var aStatusVal = [];
            // if (status != null && status != ''){
            if (arrStatus != null && arrStatus != ''){
            	// var aStatus = status.split(',');
            	//nlapiLogExecution('debug','aStatus.length', aStatus.length);
            	// if(aStatus.length > 1){
            	// if(arrStatus.length > 1){
            		//var aVal = [];
            		// for(var x = 0; x < aStatus.length; x++){
            		for(var x = 0; x < arrStatus.length; x++){
            			//statusFld.setDefaultValue(aStatus[x]);
            			// nlapiLogExecution('debug','aStatus[x]', aStatus[x]);
            			nlapiLogExecution('debug','aStatus[x]', arrStatus[x]);
            			aStatusVal.push(arrStatus[x]);
            		}
            		statusFld.setDefaultValue(aStatusVal);

            	// }else{
            		/*aStatusVal.push('SalesOrd:A');
            		aStatusVal.push('SalesOrd:B');
            		aStatusVal.push('SalesOrd:C');
            		aStatusVal.push('SalesOrd:D');
            		aStatusVal.push('SalesOrd:F');
            		aStatusVal.push('SalesOrd:H');

            		statusFld.setDefaultValue(status);*/

            	// }

            }else{
            	aStatusVal.push('SalesOrd:A');
        		aStatusVal.push('SalesOrd:B');
        		aStatusVal.push('SalesOrd:C');
        		aStatusVal.push('SalesOrd:D');
        		aStatusVal.push('SalesOrd:E');
        		aStatusVal.push('SalesOrd:F');
        		aStatusVal.push('SalesOrd:H');

        		statusFld.setDefaultValue(aStatusVal);
            }



			/// v1.2 Added Start Date and End Date Filters
			//var startDateRRFld = form.addField(FLD_SL_STARTDATERR, 'date', 'Start Date', null, OTHER_FILTERS_GROUP);
			//startDateRRFld.setBreakType('startcol');
			//if (startDateRR != null && startDateRR != '')
			//	startDateRRFld.setDefaultValue(startDateRR);

			//var endDateRRFld = form.addField(FLD_SL_ENDDATERR, 'date', 'End Date', null, OTHER_FILTERS_GROUP);
			//if (endDateRR != null && endDateRR != '')
			//	endDateRRFld.setDefaultValue(endDateRR);

			/// v1.7
			var vendorFld = form.addField(FLD_SL_VENDOR, 'select', 'Vendor', 'vendor', OTHER_FILTERS_GROUP);
			vendorFld.setBreakType('startcol');
			if (vendorVal != null && vendorVal != '')
				vendorFld.setDefaultValue(vendorVal);

			/// v1.4 Added Start Date and End Date Range Filters
			var startdaterrStartDateFld = form.addField(FLD_SL_STARTDATERR_STARTDATE, 'date', 'Start Date (RR) Range - Start Date', null, OTHER_FILTERS_GROUP);
			//startdaterrStartDateFld.setBreakType('startcol');
			if (startdaterrStartDateVal != null && startdaterrStartDateVal != '')
				startdaterrStartDateFld.setDefaultValue(startdaterrStartDateVal);

			var startdaterrEndDateFld = form.addField(FLD_SL_STARTDATERR_ENDDATE, 'date', 'Start Date (RR) Range - End Date', null, OTHER_FILTERS_GROUP);
			if (startdaterrEndDateVal != null && startdaterrEndDateVal != '')
				startdaterrEndDateFld.setDefaultValue(startdaterrEndDateVal);

			var enddaterrStartDateFld = form.addField(FLD_SL_ENDDATERR_STARTDATE, 'date', 'End Date (RR) Range - Start Date', null, OTHER_FILTERS_GROUP);
			if (enddaterrStartDateVal != null && enddaterrStartDateVal != '')
				enddaterrStartDateFld.setDefaultValue(enddaterrStartDateVal);

			var enddaterrEndDateFld = form.addField(FLD_SL_ENDDATERR_ENDDATE, 'date', 'End Date (RR) Range - End Date', null, OTHER_FILTERS_GROUP);
			if (enddaterrEndDateVal != null && enddaterrEndDateVal != '')
				enddaterrEndDateFld.setDefaultValue(enddaterrEndDateVal);

            var totalLines = form.addField(FLD_SL_TOTAL_LINES, 'integer', 'Total Lines',null,ADDITIONAL_FILTERS_GROUP).setDisplayType('disabled');
            totalLines.setHelpText("Shows the total lines selected for the download files.", false);
            if(applyfilters == 'T')
            {
                nlapiLogExecution('DEBUG', 'applyfilters', applyfilters);
                var suiteletSublist = form.addSubList(SL_SUBLIST,'list', 'Sales Orders');
                suiteletSublist.addButton(BTN_MARK_ALL, 'Mark All', 'markAll();');
                suiteletSublist.addButton(BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
                var selctedFld = suiteletSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
                selctedFld.setDisplayType('entry');
                selctedFld.setDefaultValue('T');
                //suiteletSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');

                var filters =[];

                if(client != null && client != '')
                    filters.push(new nlobjSearchFilter('entity', null, 'anyof', client));

                if(ACDStatus != null && ACDStatus != '')
                    filters.push(new nlobjSearchFilter(FLD_COL_STATUS, null, 'anyof', ACDStatus));

                if(estimate != null && estimate != '')
                    filters.push(new nlobjSearchFilter(FLD_COL_DO_DDS_ESTIMATE, null, 'is', estimate));

                if(poNum != null && poNum!= '')
                    filters.push(new nlobjSearchFilter(FLD_COL_IO_NUM, null, 'is', poNum));

                if(clientCode != null && clientCode != '')
                    filters.push(new nlobjSearchFilter(FLD_COL_DO_DDS_CLIENTCODE, null, 'is', clientCode));

                if(productCode != null && productCode!= '')
                    filters.push(new nlobjSearchFilter(FLD_COL_DO_DDS_PRODUCT, null, 'is', productCode));

                if(market != null && market!= '')
                    filters.push(new nlobjSearchFilter(FLD_COL_MARKET, null, 'is', market));

                if(typeRate != null && typeRate!= '')
                    filters.push(new nlobjSearchFilter(FLD_COL_RATE_TYPE, null, 'is', typeRate));

				/// v1.2 Added Start Date and End Date Filters
				//if (startDateRR != null && startDateRR != '')
				//	filters.push(new nlobjSearchFilter(FLD_COL_STARTDATERR, null, 'on', startDateRR));

				//if (endDateRR != null && endDateRR != '')
				//	filters.push(new nlobjSearchFilter(FLD_COL_ENDDATERR, null, 'on', endDateRR));

				/// v1.4 Added Start Date and End Date Range Filters
				if ((startdaterrStartDateVal != null && startdaterrStartDateVal != '') && (startdaterrEndDateVal != null && startdaterrEndDateVal != ''))
					filters.push(new nlobjSearchFilter(FLD_COL_STARTDATERR, null, 'within', startdaterrStartDateVal, startdaterrEndDateVal));
				else if (startdaterrStartDateVal != null && startdaterrStartDateVal != '')
					filters.push(new nlobjSearchFilter(FLD_COL_STARTDATERR, null, 'onorafter', startdaterrStartDateVal));
				else if (startdaterrEndDateVal != null && startdaterrEndDateVal != '')
					filters.push(new nlobjSearchFilter(FLD_COL_STARTDATERR, null, 'onorbefore', startdaterrEndDateVal));

				if ((enddaterrStartDateVal != null && enddaterrStartDateVal != '') && (enddaterrEndDateVal != null && enddaterrEndDateVal != ''))
					filters.push(new nlobjSearchFilter(FLD_COL_ENDDATERR, null, 'within', enddaterrStartDateVal, enddaterrEndDateVal));
				else if (enddaterrStartDateVal != null && enddaterrStartDateVal != '')
					filters.push(new nlobjSearchFilter(FLD_COL_ENDDATERR, null, 'onorafter', enddaterrStartDateVal));
				else if (enddaterrEndDateVal != null && enddaterrEndDateVal != '')
					filters.push(new nlobjSearchFilter(FLD_COL_ENDDATERR, null, 'onorbefore', enddaterrEndDateVal));
				else if (status != null && status != '') {
                    nlapiLogExecution('DEBUG', 'arrStatus', JSON.stringify(arrStatus));
					filters.push(new nlobjSearchFilter('status', null, 'anyof', arrStatus /*status*/));
					// filters.push(new nlobjSearchFilter('status', null, 'anyof', aStatusVal /*status*/));
                }

				/// v1.7
				if (vendorVal != null && vendorVal != '')
					filters.push(new nlobjSearchFilter('custcol_appf_po_vendor_name', null, 'is', vendorVal));

                if(ssID != null && ssID != '')
                {
                    var colArray=[];
                    var colIndex=1;
                    var scriptfieldcounter = 1;
                    for(var c=0;c<columns.length;c++)
                    {
                        var colObj = columns[c];
                        var colName = colObj.getName();
                        var colLabel = colObj.getLabel();
                        colName = colName.replace('.', '_');
                        if(colArray.indexOf(colName) == -1)
                        {
                            colArray.push(colName);
                        }
                        else
                        {
                            colName=colName+colIndex;
                            colArray.push(colName);
                            colIndex++;
                        }
                        if (colLabel != 'Script Use DNR')
                        {
                            suiteletSublist.addField('custpage_'+colName, 'text', colLabel);
                        }
                        else
                        {
                            var scriptField = suiteletSublist.addField('custpage_scriptfield'+scriptfieldcounter, 'text', colLabel);
                            scriptField.setDisplayType('hidden');
                            scriptfieldcounter++;
                        }
                    }

                    var resultFilters = filters.concat(filts);
                    var searchResults=getAllSearchResults(ssType, resultFilters, columns);
                    if (searchResults != null && searchResults != '') {
                        for (var s = 0; s < searchResults.length; s++) {
                            var result = searchResults[s];
                            var internalid = result.getId();
                            var colIndex = 1;
                            var colArray = [];
                            var scriptfieldcounter = 1;
                            for (var c=0;c<columns.length;c++)
                            {
                                var colObj = columns[c];
                                var columnName = colObj.getName();
                                var colLabel = colObj.getLabel();
                                columnName = columnName.replace('.', '_');
                                var ssResultValue = result.getValue(colObj);
                                if (colObj.getType() == 'select')
                                {
                                    ssResultValue = result.getText(colObj);
                                }
                                if (colArray.indexOf(columnName) == -1)
                                {
                                    colArray.push(columnName);
                                    if (client!=null && client!='')
                                    {
                                        if (s==0)
                                        {
                                            if (columnName==FLD_COL_DO_DDS_CLIENTCODE)
                                                clientCodeFld.setDefaultValue(ssResultValue);

                                            if(columnName==FLD_DOMEDIA_AGENCY_STATUS)
                                                agencyField.setDefaultValue(ssResultValue);
                                        }
                                    }
                                    else
                                    {
                                        if (columnName==FLD_COL_DO_DDS_CLIENTCODE)
                                            clientCodeFld.setDefaultValue('');

                                        if(columnName==FLD_DOMEDIA_AGENCY_STATUS)
                                            agencyField.setDefaultValue('');
                                        }
                                    }
                                    else
                                    {
                                        columnName=columnName+colIndex;
                                        colArray.push(columnName);
                                        colIndex++;
                                    }
                                    // nlapiLogExecution( 'DEBUG', 'columnName', columnName)

                                    if (colLabel != 'Script Use DNR') {
                                        suiteletSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
                                    }
                                    else
                                    {
                                        suiteletSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounter, s+1, ssResultValue);
                                        scriptfieldcounter++;
                                    }
                                }
                            }
                        }
                    }
                }

                form.addButton(BTN_APPLY_FILTER, 'Apply Filters', 'applyFilters()');
                var submBtn = form.addSubmitButton('Download Files');
                if (applyfilters == 'T' && agency != null && agency != '' && ACDStatus != null && ACDStatus != '' && estimate != null && estimate != '' && client != null && client != '' && clientCode != null && clientCode != '' && productCode != null && productCode != '')
                    submBtn.setDisabled(false);
                else
                    submBtn.setDisabled(true);

                response.writePage(form);
	}
	    catch (e)
	    {
	        if ( e instanceof nlobjError )
	            nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
	        else
	            nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );

	    }
	}
	else
	{
	    var csvData = 'Internal ID,Line ID,SO Line ID\n';
	    nlapiLogExecution('debug','rem usage at beginning',nlapiGetContext().getRemainingUsage());
	    try
	    {
	        var count = request.getLineItemCount(SL_SUBLIST);
	        var totalSelected = request.getParameter(FLD_SL_TOTAL_LINES);

	        var countSelected=0;
	        for (var c=1; c<=count; c++)
	        {
	            if (request.getLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c) == 'T')
	            {
	                countSelected++;
	            }
	        }

	        var agency = request.getParameter(FLD_AGENCY);
	        var clientName = request.getParameter(FLD_SL_CLIENTS);
	        var clientCompanyName = nlapiLookupField('customer', clientName, 'companyname');
	        var domediaStatus = request.getParameter(FLD_ACD_STATUS);

			/// 1.3 Changes header to A = New, C = Updates, D = Deletes
	        var ddsHeader = '';
	        //if (domediaStatus == '1' || domediaStatus == '2')
	        //    ddsHeader = 'Updates';
			if (domediaStatus == '1')
				ddsHeader = 'New';
			else if (domediaStatus == '2')
				ddsHeader = 'Updates';
			else
	            ddsHeader = 'Deletes';
	        nlapiLogExecution( 'DEBUG', 'clientName', clientName);

	        var estimate1 = request.getParameter(FLD_SL_ESTIMATE);
	        var ClientCode= request.getParameter(FLD_SL_CLIENT_CODE);
	        if(ClientCode==null || ClientCode=='')
	            ClientCode='';
	        var productCode= request.getParameter(FLD_SL_PRODUCT_CODE);
	        if(productCode==null || productCode=='')
	            productCode=' ';

	        var mainFaileName = agency + '.' + clientCompanyName + '.' + productCode + '.' + estimate1 + '.' + ddsHeader + '.' + formateWithTime() + '.DDS';
	        mainFaileName = mainFaileName.toUpperCase();

	        if(count > 0 && columns != null && columns != '')
	        {
	            var html = '';
	            html +='<table border="1">';
	            html +='<tr>';
	            for (var cl=0; cl<columns.length; cl++)
	            {
	                var colObj = columns[cl];
	                var colLabel = colObj.getLabel();

	                if (colLabel != 'Script Use DNR')
	                    html +='<td > <b>'+colLabel+'</b> </td>';
	            }
	            if (estimate1==null || estimate1=='')
	                estimate1='';

	            html=html+'</tr>';
	            var fileData= '';
	            for (var c=1; c<=count; c++)
	            {
	                if (request.getLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c) == 'T')
	                {
	                    var internalID = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield1', c);
	                    var nsLineID = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield2', c);

	                    var appfLineID = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield3', c);
	                    csvData += internalID+','+nsLineID+','+appfLineID+'\n';
	                    var scriptfieldcounter = 1;
	                    html +='<tr>';
	                    for (var cl=0; cl<columns.length; cl++)
	                    {
	                        var colObj = columns[cl];
	                        var colLabel = colObj.getLabel();
	                        var colName = colObj.getName();
	                        colName = colName.replace('.', '_');
	                        //nlapiLogExecution( 'DEBUG', 'colName', colName)
	                        var colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_'+colName, c);
	                        if (colLabel == 'Script Use DNR')
	                        {
	                            colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield'+scriptfieldcounter, c);
	                            scriptfieldcounter++;
	                        }
	                        if (colValue==null || colValue=='')
	                            colValue='';
	                        if (colLabel == 'Insertion ID' || colLabel == 'Project/Campaign')
	                        {
	                            colValue=colValue.toString();
								if (colValue.length > 15)
								{
								colValue = colValue.slice(colValue.length-15);
								}
	                            //nlapiLogExecution( 'DEBUG', 'colValue', colValue)
	                        }
	                        if (colLabel != 'Script Use DNR')
								html +='<td >'+colValue+'</td>';
	                        }

	                        html +='</tr>';
	                        if (request.getLineItemValue(SL_SUBLIST, FLD_COL_SL_SELECT, c) == 'T')
						    {
	                            var colValueName = request.getLineItemValue(SL_SUBLIST, 'custpage_entity', c);
								if(colValueName==null || colValueName=='')
									colValueName='';
								var colValueEstimate = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_DO_DDS_ESTIMATE, c);
								if(colValueEstimate==null || colValueEstimate=='')
									colValueEstimate='';
	                            var colValueCode = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_PRODUCT_CODE, c);
								if (colValueCode==null || colValueCode=='')
	                                colValueCode=''
								var colValueNarketCode = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_MARKET_CODE, c);
	                            if (colValueNarketCode==null || colValueNarketCode=='')
	                            {
	                                colValueNarketCode=pad('',2,' ');
								}
								nlapiLogExecution( 'DEBUG', 'colValueNarketCode 1', colValueNarketCode);
								if (colValueNarketCode!=null && colValueNarketCode!='')
	                                colValueNarketCode=colValueNarketCode.substring(0, 2);

								nlapiLogExecution( 'DEBUG', 'colValueNarketCode 2', colValueNarketCode);
	                            var colValueStrt = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_STRART_DATE_SO, c);
	                            if (colValueStrt==null || colValueStrt=='')
	                                colValueStrt='';
								var colValuegrassStrtingPoint = request.getLineItemValue(SL_SUBLIST, 'custpage_custcol_appf_do_grossratingpoint', c);
								if (colValuegrassStrtingPoint==null || colValuegrassStrtingPoint=='')
	                               colValuegrassStrtingPoint='';
								var colValuegrassNumUnits = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_NUM_UNITS, c);
								if (colValuegrassNumUnits==null || colValuegrassNumUnits=='')
	                                colValuegrassNumUnits=''
								var colValueIoNums = request.getLineItemValue(SL_SUBLIST, 'custpage_formulatext', c);
								if (colValueIoNums==null || colValueIoNums=='')
	                                colValueIoNums='';
								var colValueRecNums = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_RECORD_ID, c);
								if (colValueRecNums==null || colValueRecNums=='')
	                                colValueRecNums='';
								var colValueVendorInNos = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_INVOICE_NO, c);
								if (colValueVendorInNos==null || colValueVendorInNos=='')
	                                colValueVendorInNos='';
								var colValueMarket = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_MARKET, c);
								if (colValueMarket==null || colValueMarket=='')
	                                colValueMarket='';
								var colValueProvince = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_PROINCE_NO, c);
								if (colValueProvince==null || colValueProvince=='')
	                                colValueProvince='';
								var colValueCatgery = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_FORMAT, c);
								if (colValueCatgery==null || colValueCatgery=='')
	                                colValueCatgery='';
								var colValueRecNums1=colValueIoNums+''+colValueRecNums
								var colValueClientGross = request.getLineItemValue(SL_SUBLIST, 'custpage_quantity', c);
	                            if (colValueClientGross==null || colValueClientGross=='')
	                                colValueClientGross=0;
								var colValueMediaType = request.getLineItemValue(SL_SUBLIST, 'custpage_'+FLD_COL_MEDIA_TYPE, c);
	                            if (colValueMediaType==null || colValueMediaType=='')
	                                colValueMediaType='';
	                            colValueStrt=formate(colValueStrt)
								//nlapiLogExecution( 'DEBUG', 'colValueIoNums', colValueIoNums)
	                            fileData +=pad('INS*',4,' ');
	                            fileData +=pad(colValueCode,8,' ');
	                            fileData +=colValueNarketCode;
	                            fileData +=pad('',3,' ');
	                            fileData +=pad(colValueStrt,8,' ');
	                            fileData +=pad('',6,' ');
	                            fileData +=pad('',17,' ');

                              nlapiLogExecution('debug','before colValuegrassStrtingPoint',colValuegrassStrtingPoint + ' len = '+ colValuegrassStrtingPoint.length);
															colValuegrassStrtingPoint = colValuegrassStrtingPoint.replace(/\s+/g,'');
															nlapiLogExecution('debug','after colValuegrassStrtingPoint',colValuegrassStrtingPoint + ' len = '+ colValuegrassStrtingPoint.length);

                              if(colValuegrassStrtingPoint == null || colValuegrassStrtingPoint == '' || colValuegrassStrtingPoint == ' ' ){
																colValuegrassStrtingPoint = '0';
															}
                              nlapiLogExecution('debug','0 colValuegrassStrtingPoint',colValuegrassStrtingPoint);
                              nlapiLogExecution('debug','colValuegrassNumUnits',colValuegrassNumUnits);
	                           // fileData +=pad(colValuegrassStrtingPoint,3,' ');
	                          //  fileData +=pad(colValuegrassNumUnits,4,'0',STR_PAD_LEFT);
                                fileData +=pad(colValuegrassStrtingPoint,3,' ');
	                            fileData +=pad(colValuegrassNumUnits,4,'0',STR_PAD_LEFT);
	                            fileData +=pad('',4,' ');

                              //format to 2 decimal places. preceed with N
                              colValueClientGross =  'N'+ parseFloat(colValueClientGross).toFixed(2);
	                            fileData +=pad(colValueClientGross,11,' ');
	                            fileData +=pad('',10,' ');
	                            fileData +=pad('',2,' ');
	                            fileData +=pad('',8,' ');
	                            fileData +=pad('',8,' ');
	                            fileData +=pad('',8,' ');
	                            fileData +=pad('',8,' ');
								if (colValueIoNums.length > 15)
                                {
                                 colValueIoNums = colValueIoNums.slice(colValueIoNums.length-15);
                                }
	                            fileData +=pad(colValueIoNums,15,'0',STR_PAD_LEFT);
	                            fileData +=pad('',93,' ');
	                            //fileData +=pad('', 2,' ');

	                            fileData +='\r\n';
	                            fileData +=pad('OPT*',4,' ');
	                            fileData +=pad('SREP=4000',47,' ');
	                            fileData +='\r\n';
	                            fileData +=pad('CCL*',4,' ');
	                            fileData +=pad('Contract#',12,' ');
	                            fileData +=pad(colValueVendorInNos,60,' ');
	                            fileData +='\r\n';
	                            fileData +=pad('CCL*',4,' ');
	                            fileData +=pad('Market',12,' ');
	                            fileData +=pad(colValueMarket,60,' ');
	                            fileData +='\r\n';
	                            fileData +=pad('CCL*',4,' ');
	                            fileData +=pad('Region',12,' ');
	                            fileData +=pad(colValueProvince,60,' ');
	                            fileData +='\r\n';
	                            fileData +=pad('CCL*',4,' ');
	                            fileData +=pad('Category',12,' ');
	                            fileData +=pad(colValueCatgery,60,' ');
	                            fileData +='\r\n';
	                            fileData +=pad('CCL*',4,' ');
	                            fileData +=pad('Type',12,' ');
	                            fileData +=pad(colValueMediaType,60,' ');
	                            fileData +='\r\n';
	                            fileData +='|||';
	                        }
	                    }
	                }

	                html += '</table>';
	                // Text file
	                var timestamp = new Date().getTime();
					var fileName=agency + '.' + colValueName+'.'+colValueCode+'.'+colValueEstimate+'.'+''+formateWithTime()+'DDS';
					var fileData1=fileData.split('|||');
	                //nlapiLogExecution( 'DEBUG', 'fileData', fileData1[0])
	                var modulesCount = parseFloat(countSelected % THRESHOLD_RECORDS);
	                nlapiLogExecution( 'DEBUG', 'modulesCount', modulesCount)
	                var lastLoopInx =  parseFloat(countSelected - modulesCount);
	                nlapiLogExecution( 'DEBUG', 'lastLoopInxCount', lastLoopInx);
	                var lastInxData='';
	                var zip = new JSZip();
	                var fileNameCounter = 1;

	                var textFile='';
	                var textFile1='';
					var textFilecount=true;
					if (parseFloat(lastLoopInx)>0)
					{
	                    nlapiLogExecution( 'DEBUG', 'lastLoopInxinside', lastLoopInx);
	                    for (var c=1; c<=lastLoopInx; c++)
	                    {
	                        if (textFilecount)
	                        {
	                            textFile1 +='HDR*';
	                            textFile1 +='P';
	                            textFile1 +='OU';
	                            textFile1 +='O';
	                            textFile1 +='NOV';
	                            textFile1 +=pad(ClientCode,3,' ');
	                            textFile1 +=pad(productCode,3,' ');
	                            textFile1 +=pad(estimate1,3,'0',STR_PAD_LEFT);
	                            if (domediaStatus == '1' || domediaStatus == '2')
	                                textFile1 +='Y';
	                            else
	                                textFile1 +='D';
	                            textFile1 +=pad('', 3,' ');
	                            textFile1 +=pad('', 10,' ');
	                            textFile1 +='N';
	                            textFile1 +='N';
	                            textFile1 +=pad('',116,' ');
	                            //textFile1 +=pad('',2,' ');
	                            textFile1 +='\r\n';
	                            textFilecount=false;
	                        }
	                        textFile1 +=fileData1[c-1];
	                        if (c%THRESHOLD_RECORDS == 0)
	                        {
	                           // textFile1 +=pad('EOF*',5,' ');
	                        	 textFile1 +=pad('EOF*',4,' ');
	                            textFile1 += '\r\n';

	                            textFile1 = textFile1.toUpperCase();
	                            zip.file(mainFaileName+'.'+fileNameCounter+'.txt', textFile1);
	                            textFile1 = '';
	                            textFilecount=true;
	                            fileNameCounter++;
	                        }
	                    }
	                }
	                var textFilecount1=true;
	                if (modulesCount!=null && modulesCount!='')
	                {
	                    nlapiLogExecution( 'DEBUG', 'lastLoopInxinside', lastLoopInx);
	                    for (var c=parseInt(lastLoopInx)+1;c<=countSelected;c++)
	                    {
	                        nlapiLogExecution( 'DEBUG', 'parseInt(lastLoopInx)+1', c);
	                        if (textFilecount1)
	                        {
	                            textFile1 +='HDR*';
	                            textFile1 +='P';
	                            textFile1 +='OU';
	                            textFile1 +='O';
	                            textFile1 +='NOV';
	                            textFile1 +=pad(ClientCode,3,' ');
	                            textFile1 +=pad(productCode,3,' ');
	                            textFile1 +=pad(estimate1,3,'0',STR_PAD_LEFT);
	                            if (domediaStatus == '1' || domediaStatus == '2')
	                                textFile1 +='Y';
	                            else
	                                textFile1 +='D';
	                            textFile1 +=pad('', 3,' ');
	                            textFile1 +=pad('', 10,' ');
	                            textFile1 +='N';
	                            textFile1 +='N';
	                            textFile1 +=pad('',116,' ');
	                           // textFile1 +=pad('',2,' ');
	                            textFile1 +='\r\n';
	                            textFilecount1=false;
	                        }

	                        textFile1 +=fileData1[c-1];
	                        if(countSelected==c)
	                        {
	                            //textFile1 +=pad('EOF*',5,' ');
	                        	textFile1 +=pad('EOF*',4,' ');
	                            textFile1 += '\r\n';
	                        }

	                        textFile1 = textFile1.toUpperCase();
	                        if (countSelected<=THRESHOLD_RECORDS)
	                        {
	                            textFile =nlapiCreateFile(mainFaileName+'.1'+'.txt', 'PLAINTEXT', textFile1);
	                            //fileNameCounter++;
	                        }
	                        if (countSelected==c && (countSelected!=THRESHOLD_RECORDS && countSelected>THRESHOLD_RECORDS))
	                        {
	                            var fileNum=parseFloat(fileNameCounter);
	                            zip.file(mainFaileName+'.'+fileNameCounter+'.txt', textFile1);
	                            fileNameCounter++;
	                        }
	                    }
	                }
	                zip.file(mainFaileName+'.xls', html);
	                if (textFile!=null && textFile!='')
	                {
	                    var timestamp = new Date().getTime();
	                    var fileString=textFile.getValue();
	                    zip.file(mainFaileName+'.'+fileNameCounter+'.txt', fileString);
	                    fileNameCounter++;
	                }
	                var timestamp = new Date().getTime();
	                //nlapiLogExecution( 'DEBUG', 'html', html)
	                nlapiLogExecution('debug','rem usage before xls',nlapiGetContext().getRemainingUsage());

	                var excelFile =nlapiCreateFile(mainFaileName+'.xls', 'EXCEL', nlapiEncrypt(html, 'base64'));
	                //var excelFile = nlapiCreateFile('SelectedData_'+timestamp+'.xls', 'EXCEL', excelData);
	                nlapiLogExecution( 'DEBUG', 'excelFile', excelFile);
	                excelFile.setFolder(FOLDER_NUMS);
					var excelFileID = nlapiSubmitFile(excelFile);
					csvData = csvData.slice(0,-1);
					var csvDataFile = nlapiCreateFile(fileName+'.csv', 'CSV', csvData);
					csvDataFile.setFolder(FOLDER_NUMS);
					var csvDataFileID = nlapiSubmitFile(csvDataFile);

	                nlapiLogExecution('debug','rem usage after xls',nlapiGetContext().getRemainingUsage());

	                var content = zip.generate();
	                nlapiLogExecution('debug','rem usage before zip',nlapiGetContext().getRemainingUsage());

	                textFile =nlapiCreateFile(mainFaileName+'.zip', 'ZIP', content);

	                textFile.setFolder(FOLDER_NUMS);
	                var textFilelFileID = nlapiSubmitFile(textFile);
	                nlapiLogExecution('debug','rem usage after zip',nlapiGetContext().getRemainingUsage());
	                var 	custOcenRec=nlapiCreateRecord(CUSTOM_RECORD_OCEAN_FILE);
	                if (clientName!=null && clientName!='')
	                    custOcenRec.setFieldValue(CUSTOM_FLD_OCEN_CLIENT,clientName)
	                if (domediaStatus!=null &&  domediaStatus!='')
	                    custOcenRec.setFieldValue(CUSTOM_FLD_ACD_STATUS,domediaStatus)
	                if (estimate1!=null && estimate1!='')
	                    custOcenRec.setFieldValue(CUSTOM_FLD_ESTIMATE,estimate1)
	                custOcenRec.setFieldValue(CUSTOM_FLD_FILE,excelFileID);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_CSV_DATA_FILE, csvDataFileID);
	                custOcenRec.setFieldValue('custrecord_media_ocean_zip_file',textFilelFileID);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_TO_PROCESS, totalSelected);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_PROCESSED, 0);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_NUM_OF_LINES_FAILED, 0);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_PROCESSING_PERCENT, 0);
	                custOcenRec.setFieldValue(FLD_DOMEDIA_OCEAN_LOG_PROCESSING_STATUS, STATUS_INPROGRESS);

	                var recID =nlapiSubmitRecord(custOcenRec,true,true);
	                if (recID != null && recID != '')
	                {
	                    nlapiLogExecution('debug','rem usage after custom rec',nlapiGetContext().getRemainingUsage());
	                    var parms={};
	                    parms[SPARAM_MEDIA_OCEN_ID]=recID;
	                    nlapiScheduleScript('customscript_appf_media_ocean_dds_sc', null,parms)
						response.sendRedirect('RECORD', CUSTOM_RECORD_OCEAN_FILE,recID);
	                }
	            }
	        }
        catch (e)
        {
            if ( e instanceof nlobjError )
                nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
            else
                nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
        }
        nlapiLogExecution('debug','rem usage at ending',nlapiGetContext().getRemainingUsage());
    }
}


function formate(yy)
{
	var x = new Date(yy);
	var y = x.getFullYear().toString();
	var m = (x.getMonth() + 1).toString();
	var d = x.getDate().toString();
	(d.length == 1) && (d = '0' + d);
	(m.length == 1) && (m = '0' + m);
	var yyyymmdd = y + m + d;
	return yyyymmdd;
}

function formateWithTime()
{
	var x = new Date();

	var dtformat = x.toISOString();
	dtformat = dtformat.replace('T','_');
	dtformat = dtformat.split('.')[0];
	var timepart = dtformat.split('_')[1];
	timepart = timepart.replace(/:/g,'');
	var y = x.getFullYear().toString();
	var m = (x.getMonth() + 1).toString();
	var d = x.getDate().toString();
	(d.length == 1) && (d = '0' + d);
	(m.length == 1) && (m = '0' + m);
	var yyyymmddhhmmss = y + m + d + timepart;
	return yyyymmddhhmmss;
}

var STR_PAD_LEFT = 1;
var STR_PAD_RIGHT = 2;
var STR_PAD_BOTH = 3;

function pad(str, len, pad, dir)
{
	if (typeof(len) == "undefined") { var len = 0; }

    if (typeof(pad) == "undefined") { var pad = ' '; }

    if (typeof(dir) == "undefined") { var dir = STR_PAD_RIGHT; }

    if (len + 1 >= str.length) {

        switch (dir){
            case STR_PAD_LEFT:
                str = Array(len + 1 - str.length).join(pad) + str;
            break;

            case STR_PAD_BOTH:
                var right = Math.ceil((padlen = len - str.length) / 2);
                var left = padlen - right;
                str = Array(left+1).join(pad) + str + Array(right+1).join(pad);
            break;

            default:
                str = str + Array(len + 1 - str.length).join(pad);
            break;
        } // switch

    }
    return str;
}

function getAllSearchResults(record_type, filters, columns)
{
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);

	var searchRan = search.runSearch()
	,	bolStop = false
	,	intMaxReg = 1000
	,	intMinReg = 0
	,	result = [];

	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
	{
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);

		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000)
		{
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array)
{
	return target.concat(array); // TODO: use _.union
}
