/**
 * Script Name: Appf-Payment RollBack Button UE
 * Script Type: User Event
 * Deployed On: Payment
 * 
 * Version    Date            Author           		Remarks
 * 1.00            									The script creates a button "Rollback" on the payment record
 *
 * Company 	 : Appficiency. 
 */
var SUITELET_UPDATE_PAYMENT_ON_ROLL_BACK_SCRIPT_ID='customscript_update_payment_on_rollback';
var SUITELET_UPDATE_PAYMENT_ON_ROLL_BACK_DEPLOY_ID='customdeploy_update_payment_on_rollback';
var BTN_ROLL_BACK='custpage_roll_back';
var FLD_PAYMENT_APPLICATION_LOG_LINKS = 'custbody_appf_pmt_appl_log_rec_links';

function beforeLoad(type,form,request)
{
  	try
      {
        if(type == 'view')
		{
		 
	var recId = nlapiGetRecordId();
		var recType = nlapiGetRecordType();
		var record = nlapiLoadRecord(recType, recId);
		
		var execLogLink = record.getFieldValue(FLD_PAYMENT_APPLICATION_LOG_LINKS);
		var applied = record.getFieldValue('applied');
		if (execLogLink != null && execLogLink != '' && applied > 0)
		{
		var url=nlapiResolveURL('SUITELET',SUITELET_UPDATE_PAYMENT_ON_ROLL_BACK_SCRIPT_ID,SUITELET_UPDATE_PAYMENT_ON_ROLL_BACK_DEPLOY_ID);
		url+='&paymentRecordId='+recId;
		form.addButton(BTN_ROLL_BACK,'Rollback','window.open(\''+url+'\',\'_self\')');
		}
	    }
      }
  catch(e)
    {
      nlapiLogExecution( 'DEBUG', 'Error details:', e.toString());
    }
}
 