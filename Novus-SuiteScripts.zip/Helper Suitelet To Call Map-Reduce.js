/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 */

var SCRIPT_MAP_REDUCE = 'customscript_appf_update_rev_arrg_mr';


// This script triggers "Appf-Update Revenue Arrangements MR" map/reduce script for procesisng AEM

define(['N/runtime','N/task'], function(runtime,task) {
    function onRequest(context) {
        var request = context.request;
            var customRecId=request.parameters.custRecId;
			log.debug('customRecId',customRecId);
         	var mrTask = task.create({
         	taskType: task.TaskType.MAP_REDUCE,
         	scriptId: SCRIPT_MAP_REDUCE,
         	deploymentId: null,
         	params: {custscript_log_rec_id: customRecId}
         	});
         	var mrTaskId = mrTask.submit();
    }
    return {
        onRequest: onRequest
    };
});