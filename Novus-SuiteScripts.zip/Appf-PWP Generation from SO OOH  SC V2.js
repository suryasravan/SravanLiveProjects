/*
* Script Name: Appf-PWP Generation from SO SC
* Script Type: Scheduled
* Description:
* Company 	: Appficiency Inc.
* Version    	Date            Author           		Remarks
* 1.1			10/20/2020		MJ De Asis				Added functionality to Enable Line Item Shipping and on each line item, ship to is customize using SO Line ID
*/
var FLD_COL_LINE_ID_SO = 'custcol_appf_line_id';
var FLD_COL_LINE_ID_INV = 'custcol_appf_invoice_line_id';
var FLD_COL_LINE_ID_PO = 'custcol_appf_po_line_id';
var FLD_COL_LINE_ID_VENDOS = 'custcol_appf_vendorbill_line_id';
var FLD_COL_LINE_ID_ESTIMTS = 'custcol_appf_estimate_line_id';
var FLD_COL_LINE_PWP_RECS = 'custcol_appf_pwp_custom_record';
var FLD_COL_POP_RECEIVED = 'custcol_appf_pop_received';
var MEDIA_SEGMENT = 'cseg_appf_media_seg';
var FLD_COL_IO = 'custcol_appf_ionum';
var FLD_COL_CIRCULATION = 'custcol_appf_print_circulation';
var FLD_COL_NOVUS_UNIT_RATE = 'custcol_appf_novusunitrate';
var CUSTOMRECORD_PWP = 'customrecord_appf_pwp_wrapper_record'
var CUSTOMRECORD_SO_LINE_ID_PWP = 'custrecord_appf_pwp_so_line_id'
var CUSTOMRECORD_SO_LINK = 'custrecord_appf_pwp_so_link'
var CUSTOMRECORD_SO_LINE_AMT = 'custrecord_appf_pwp_so_line_amount'

//added 27-10-2021
var CUSTOMRECORD_SO_PRE_CLOSE='custrecord_appf_so_amount_pre_close';

var CUSTOMRECORD_PWP_LINE_OF_BUSINESS = 'custrecord_appf_pwp_line_of_business'
var CUSTOMRECORD_PWP_DEPARTMENT = 'custrecord_appf_pwp_department'
var CUSTOMRECORD_PWP_OFFICE = 'custrecord_appf_pwp_office'
var CUSTOMRECORD_PWP_CLIENT_LINK = 'custrecord_appf_pwp_client_link'
var CUSTOMRECORD_PWP_PRO = 'custrecord_appf_pwp_project'
var CUSTOMRECORD_PWP_POP_RECEIVED = 'custrecord_appf_pwp_pop_received';
var CUSTOMRECORD_PWP_BUYING_SYSTEM = 'custrecord_appf_pwp_buying_system';
var CUSTOMRECORD_PWP_IO = 'custrecord_appf_pwp_io_number';
var FLD_PWP_CLIENT_CURRENCY = 'custrecord_appf_pwp_client_currency';
var CUSTOMRECORD_PWP_CLIENTCONTRACT = 'custrecord_appf_pwp_client_contract';
var CUSTOMRECORD_PWP_IO_CIRCULATION = 'custrecord_appf_pwp_io_circulation';
var CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE = 'custrecord_appf_pwp_io_novus_unit_rate';
var FLD_NEXT_LINE_ID = 'custbody_appf_next_line_number';
var FLD_PO_NEXT_LINE_ID = 'custbody_appf_next_line_number_po';
var FLD_REV_REC_LINK = 'custbody_appf_aem_rev_rec_arrangement';
var FLD_BUYING_SYSTEM = 'custbody_appf_buying_system';
var FLD_SO_PWP_CREATE_SCRIPT_COMPLETE = 'custbody_appf_pwp_complete';
var FLD_SO_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var FLD_SO_OOH_ID = 'custbody_appf_ooh_ns_sss';
var FLD_SO_SPOT_ID = 'custbody_appf_spot_ns_sss';
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var SPARAM_SALES_ORDER_ID = 'custscript_appf_sales_order_id';
var SPARAM_SALESORDER_SS = 'custscript_sales_orders_fo_pwp_gener_oo2';
var SPARAM_SO_INDEX = 'custscript_appf_salesorder_line_index2';
var SPARAM_SS_INDEX = 'custscript_appf_so_savedsearch_index2';

function pwpGenerationSOScheduled(type) {
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_SALESORDER_SS);
	var soIndex = context.getSetting('SCRIPT', SPARAM_SO_INDEX);
	var ssIndex = context.getSetting('SCRIPT', SPARAM_SS_INDEX) || 0;
	var searchObj = nlapiLoadSearch(null, ssID);
	var filters = searchObj.getFilters();
	var columns = searchObj.getColumns();
	var ssType = searchObj.getSearchType();
	var nIndex;
	var searchResults = getAllSearchResults(ssType, filters, columns);
	if (searchResults != null && searchResults != '') {
		if (soIndex != null && soIndex != '') {
			nIndex = soIndex;
		} else {
			nIndex = 1;
		}
		nlapiLogExecution('DEBUG', 'searchResults', searchResults.length + ' soIndex=' + soIndex + ' ssIndex=' + ssIndex + 'nIndex = ' + nIndex);
		for (var s = ssIndex; s < searchResults.length; s++) {
			var result = searchResults[s];
			var columns = result.getAllColumns();
			var internalid = result.getValue(columns[0]);
			try {
				var recId = internalid;
				if (recId != null && recId != '') {
					var record = nlapiLoadRecord('salesorder', recId, {recordmode: 'dynamic'});

					/// v1.1
					var soentity = record.getFieldValue('entity');
					var defaultShipAddress = getDefaultShipAddress(soentity);
					var isLineItemShipEnabled = record.getFieldValue('ismultishipto') == 'T';
					if (!isLineItemShipEnabled) {
						record.setFieldValue('ismultishipto', 'T');
						// Record must be saved with Enabled Line Item Shipping prior to using the subrecord(item, shippingaddress)
						nlapiSubmitRecord(record, true, true);
						// Reload the record
						record = nlapiLoadRecord('salesorder', recId, {recordmode: 'dynamic'});
					}

					//var soStatus = record.getFieldValue('status');
					var processCompleted = true;
					//var soentity = record.getFieldValue('entity');
					var clientCurrency = '';
					if (soentity) {
						clientCurrency = nlapiLookupField('customer', soentity, 'currency');
					}
					//var record = nlapiLoadRecord('salesorder', recId);
					var buyingSystem = record.getFieldValue(FLD_BUYING_SYSTEM);
					var buyingSystemText = record.getFieldText(FLD_BUYING_SYSTEM);
					//v5 added 9/3/2020
					//set client contract if buying system = OOH/Spot
					switch (buyingSystemText) {
						case 'OOH':
							record.setFieldValue(FLD_SO_CLIENT_CONTRACT, record.getFieldValue(FLD_SO_OOH_ID));
							break;
						case 'Spot':
							record.setFieldValue(FLD_SO_CLIENT_CONTRACT, record.getFieldValue(FLD_SO_SPOT_ID));
							break;
					}
					var itemCount = record.getLineItemCount('item');
					nlapiLogExecution('DEBUG', 'itemCount', itemCount);
					var nextItemNumber = 0;
					var pwpObj = {};
					//itemCount = 10;

					for (var k = nIndex; k <= itemCount; k++) {
						nlapiLogExecution('DEBUG', 'context.getRemainingUsage()', context.getRemainingUsage() + ' k=' + k);
						//reschedule
						if (context.getRemainingUsage() <= 1000 /*&& parseInt(s)+1 < searchResults.length*/ ) {
							var record = nlapiLoadRecord('salesorder', recId);
							nlapiLogExecution('DEBUG', 'reschedule', ' k=' + k + ' pwpObj ' + JSON.stringify(pwpObj));
							for (var prop in pwpObj) {
								var lineNum = record.findLineItemValue('item', FLD_COL_LINE_ID_SO, prop);
								if (lineNum != -1) {
									//nlapiLogExecution('DEBUG', 'lineNum inside', prop + ' pwp', pwpObj[prop]);
									record.setLineItemValue('item', FLD_COL_LINE_PWP_RECS, lineNum, pwpObj[prop]);
									//add setting of PO Rates and PO Vendors
									var existingPOVendor = record.getLineItemValue('item', 'povendor', lineNum);
									var vendorName = record.getLineItemValue('item', FLD_COL_VENDOR_NAME, lineNum);
									var existingcreatepo = record.getLineItemValue('item', 'createpo', lineNum);
									if (vendorName == null) vendorName = '';
									// nlapiLogExecution('debug', 'po vendor', vendorName);
									//nlapiLogExecution('debug', 'existingPOVendor', existingPOVendor + ' vendorName='+vendorName);
									if (existingPOVendor != vendorName && vendorName != null && vendorName != '') {
										record.setLineItemValue('item', 'povendor', lineNum, vendorName);
										record.setLineItemValue('item', 'porate', lineNum, 1);
										if (existingcreatepo == null || existingcreatepo == '') {
											record.setLineItemValue('item', 'createpo', lineNum, 'SpecOrd');
										}
									}
								}
							}
							//check lines
							var pwpCount = 0;
							for (var x = 1; x <= itemCount; x++) {
								var idPWP = record.getLineItemValue('item', FLD_COL_LINE_PWP_RECS, x);
								if (idPWP != null && idPWP != '') {
									pwpCount++;
								}
							}
							if (pwpCount == itemCount) {
								nlapiLogExecution('DEBUG', 'all processed', pwpCount);
								record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE, 'T');
							}
                            record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE, 'T');
							var submittedRecId = nlapiSubmitRecord(record, true, true);
							nlapiLogExecution('DEBUG', 'submittedRecId', submittedRecId);
							var params = {};
							params[SPARAM_SALESORDER_SS] = ssID;
							params[SPARAM_SO_INDEX] = k;
							params[SPARAM_SS_INDEX] = s;
							nlapiLogExecution('DEBUG', 'params inside', JSON.stringify(params));
							nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
							nlapiLogExecution('DEBUG', 'inside submit', 'inside submit');
							break;
						}
						var soId = record.getLineItemValue('item', FLD_COL_LINE_ID_SO, k)
						var soAmt = record.getLineItemValue('item', 'amount', k)
						var soAmt = record.getLineItemValue('item', 'amount', k)
						if (soAmt != null && soAmt != '') soAmt = Number(soAmt).toFixed(2);
						var sodepartment = record.getLineItemValue('item', 'department', k)
						var solocation = record.getLineItemValue('item', 'location', k)
						var soPro = record.getLineItemValue('item', 'job', k)
						var soclass = record.getLineItemValue('item', 'class', k)
						var popReceived = record.getLineItemValue('item', FLD_COL_POP_RECEIVED, k)
						var mediaSegment = record.getLineItemValue('item', MEDIA_SEGMENT, k)
						var soCirculation = record.getLineItemValue('item', FLD_COL_CIRCULATION, k)
						if (soCirculation == null || soCirculation == '') soCirculation = 0;
						var soNovusUnitRate = record.getLineItemValue('item', FLD_COL_NOVUS_UNIT_RATE, k)
						if (soNovusUnitRate == null || soNovusUnitRate == '') soNovusUnitRate = 0;
						var io = record.getLineItemValue('item', FLD_COL_IO, k)
						try {
							var pwpRecLink = record.getLineItemValue('item', FLD_COL_LINE_PWP_RECS, k)
							if (pwpRecLink == null || pwpRecLink == '') {
								var pwpFils = [];
								pwpFils.push(new nlobjSearchFilter(CUSTOMRECORD_SO_LINE_ID_PWP, null, 'is', soId));
								pwpFils.push(new nlobjSearchFilter(CUSTOMRECORD_SO_LINK, null, 'anyof', recId));
								var pwpCols = [];
								pwpCols.push(new nlobjSearchColumn('internalid').setSort(true));
								var pwpSearch = nlapiSearchRecord(CUSTOMRECORD_PWP, null, pwpFils, pwpCols);
								//nlapiLogExecution('DEBUG', 'pwpSearch', pwpSearch);
								if (pwpSearch != null && pwpSearch != '') {
									pwpRecLink = pwpSearch[0].getValue('internalid');
								}
							}
							if (pwpRecLink == null || pwpRecLink == '') {
								var pwpRecord = nlapiCreateRecord(CUSTOMRECORD_PWP)
								//nlapiLogExecution('DEBUG', 'pwpRecord', pwpRecord);
								pwpRecord.setFieldValue('name', 'PWP - ' + soId);
								pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_ID_PWP, soId);
								pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINK, recId);
								//nlapiLogExecution('DEBUG', 'recId', recId);
								pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENTCONTRACT, record.getFieldValue(FLD_SO_CLIENT_CONTRACT));
								if (soAmt != null && soAmt != '') 
									pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT, soAmt);
								   //added 27-10-2021
								   if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
								
								if (sodepartment != null && sodepartment != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT, sodepartment);
								if (solocation != null && solocation != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE, solocation);
								if (soentity != null && soentity != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK, soentity);
								if (clientCurrency != null && clientCurrency != '') pwpRecord.setFieldValue(FLD_PWP_CLIENT_CURRENCY, clientCurrency);
								if (soPro != null && soPro != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO, soPro);
								if (soclass != null && soclass != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS, soclass);
								if (buyingSystem != null && buyingSystem != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM, buyingSystem);
								if (mediaSegment != null && mediaSegment != '') pwpRecord.setFieldValue(MEDIA_SEGMENT, mediaSegment);
								pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION, soCirculation);
								pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE, soNovusUnitRate);
								if (io != null && io != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO, io);
								if (popReceived == 'T') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED, popReceived);
								//nlapiLogExecution('DEBUG', 'popReceived', popReceived);
								var pwpRecordID = nlapiSubmitRecord(pwpRecord, true, true)
								//nlapiLogExecution('DEBUG', 'pwpRecordID', pwpRecordID);
								//record.setLineItemValue('item',FLD_COL_LINE_PWP_RECS,k,pwpRecordID);
								pwpObj[soId] = pwpRecordID;
							} else {
								pwpObj[soId] = pwpRecLink;
								var pwpRecord = nlapiLoadRecord(CUSTOMRECORD_PWP, pwpRecLink);
								if (soAmt != null && soAmt != '') 
									pwpRecord.setFieldValue(CUSTOMRECORD_SO_LINE_AMT, soAmt);
								    //added 27-10-2021
								if(soAmt!=null && soAmt!='' && soAmt > 0)
									  {
									  pwpRecord.setFieldValue(CUSTOMRECORD_SO_PRE_CLOSE,soAmt);
									  }
								
								if (sodepartment != null && sodepartment != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_DEPARTMENT, sodepartment);
								if (solocation != null && solocation != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_OFFICE, solocation);
								if (soentity != null && soentity != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_CLIENT_LINK, soentity);
								if (soPro != null && soPro != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_PRO, soPro);
								if (soclass != null && soclass != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_LINE_OF_BUSINESS, soclass);
								if (popReceived == 'T') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_POP_RECEIVED, popReceived);
								if (buyingSystem != null && buyingSystem != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_BUYING_SYSTEM, buyingSystem);
								if (mediaSegment != null && mediaSegment != '') pwpRecord.setFieldValue(MEDIA_SEGMENT, mediaSegment);
								pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_CIRCULATION, soCirculation);
								pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO_NOVUS_UNIT_RATE, soNovusUnitRate);
								if (io != null && io != '') pwpRecord.setFieldValue(CUSTOMRECORD_PWP_IO, io);
								nlapiSubmitRecord(pwpRecord, true, true)
							}
							//nlapiLogExecution('DEBUG', 'pwpObj[soId]', lineNum + ' pwp', pwpObj[prop]);
						} catch (ex) {
							if (ex instanceof nlobjError) {
								errorMessage = 'Error creating/updating PWP for line id ' + soId + ': ' + ex.getDetails();
							} else {
								errorMessage = 'Error creating/updating PWP for line id ' + soId + ': ' + ex.toString();
							}
						}
						//record = nlapiLoadRecord('salesorder', recId);
						//if last index is reached
						if (k == itemCount) {
							var record = nlapiLoadRecord('salesorder', recId);

							nlapiLogExecution('DEBUG', 'last index', ' JSON.stringify(pwpObj)=' + JSON.stringify(pwpObj));

							var nLastIndex;
							var lineCounter = 0;
							for (var prop in pwpObj) {
								var lineNum = record.findLineItemValue('item', FLD_COL_LINE_ID_SO, prop);
								nlapiLogExecution('DEBUG', 'prop', prop + ' lineNum='+lineNum);
								if (lineNum != -1) {
									if(lineCounter == 0){
											nLastIndex = lineNum;
									}
									//nlapiLogExecution('DEBUG', 'lineNum within', lineNum + ' pwp', pwpObj[prop] + ' JSON.stringify(pwpObj)=' + JSON.stringify(pwpObj));
									record.setLineItemValue('item', FLD_COL_LINE_PWP_RECS, lineNum, pwpObj[prop]);
									//add setting of PO Rates and PO Vendors
									var existingPOVendor = record.getLineItemValue('item', 'povendor', lineNum);
									var vendorName = record.getLineItemValue('item', FLD_COL_VENDOR_NAME, lineNum);
									var existingcreatepo = record.getLineItemValue('item', 'createpo', lineNum);
									if (vendorName == null) vendorName = '';
									// nlapiLogExecution('debug', 'po vendor', vendorName);
									//nlapiLogExecution('debug', 'existingPOVendor', existingPOVendor + ' vendorName='+vendorName);
									if (existingPOVendor != vendorName && vendorName != null && vendorName != '') {
										record.setLineItemValue('item', 'povendor', lineNum, vendorName);
										record.setLineItemValue('item', 'porate', lineNum, 1);
										if (existingcreatepo == null || existingcreatepo == '') {
											record.setLineItemValue('item', 'createpo', lineNum, 'SpecOrd');
										}
									}

									/// v1.1
									var soLineID = record.getLineItemValue('item', FLD_COL_LINE_ID_SO, lineNum);
									nlapiLogExecution('DEBUG', 'SO Line ID', soLineID);
									var shipAddress = record.viewLineItemSubrecord('item', 'shippingaddress', lineNum);
									nlapiLogExecution('DEBUG', 'Ship Address', shipAddress + ' defaultShipAddress='+ defaultShipAddress);
									if (defaultShipAddress && (soLineID != null && soLineID != '')) {
										//Custom Shipping Address
										record.selectLineItem('item', lineNum);

										if (shipAddress) {
											record.removeCurrentLineItemSubrecord('item', 'shippingaddress');
										}
										var addressSubrecord = record.createCurrentLineItemSubrecord('item', 'shippingaddress');
										addressSubrecord.setFieldValue('label', soLineID);
										for (var _field in defaultShipAddress) {
											addressSubrecord.setFieldValue(_field, defaultShipAddress[_field]);
										}
										addressSubrecord.commit();
										record.commitLineItem('item');
									}
									nlapiLogExecution('DEBUG', 'Custom Ship Adress Set');
								}
								lineCounter++;

							}

							nlapiLogExecution('DEBUG', 'nIndex',nIndex + ' nLastIndex='+nLastIndex);
							if(nIndex > 1){
									//loop from 1 - ncount
									for(var v = 1; v <= parseInt(nLastIndex)-1; v++){
										var soLineID = record.getLineItemValue('item', FLD_COL_LINE_ID_SO, v);
										var shipTo = record.viewCurrentLineItemSubrecord('item', 'shippingaddress');
										//nlapiLogExecution('DEBUG', 'shipTo', shipTo);
									//	if (!shipTo) {
										//	nlapiLogExecution('DEBUG', 'SO Line ID', soLineID);
											var shipAddress = record.viewLineItemSubrecord('item', 'shippingaddress', v);
											nlapiLogExecution('DEBUG', 'Ship Address', shipAddress + ' defaultShipAddress='+ defaultShipAddress + 'soLineID='+soLineID + 'shipTo='+shipTo );
											if (defaultShipAddress && (soLineID != null && soLineID != '')) {
												//Custom Shipping Address
												record.selectLineItem('item', v);

												if (shipAddress) {
													record.removeCurrentLineItemSubrecord('item', 'shippingaddress');
												}
												var addressSubrecord = record.createCurrentLineItemSubrecord('item', 'shippingaddress');
												addressSubrecord.setFieldValue('label', soLineID);
												for (var _field in defaultShipAddress) {
													addressSubrecord.setFieldValue(_field, defaultShipAddress[_field]);
												}
												addressSubrecord.commit();
												record.commitLineItem('item');
											}
											nlapiLogExecution('DEBUG', 'Custom Ship Adress Set');


									}
							}




							//set client contract if buying system = OOH/Spot
							switch (buyingSystemText) {
								case 'OOH':
									record.setFieldValue(FLD_SO_CLIENT_CONTRACT, record.getFieldValue(FLD_SO_OOH_ID));
									break;
								case 'Spot':
									record.setFieldValue(FLD_SO_CLIENT_CONTRACT, record.getFieldValue(FLD_SO_SPOT_ID));
									break;
							}
							//mark complete
							record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE, 'T');
							var submittedRecId = nlapiSubmitRecord(record, true, true);
							nlapiLogExecution('DEBUG', 'submittedRecId', submittedRecId); //revert
							nlapiLogExecution('DEBUG', 'normal submit', 'normal submit');
							soIndex = 1;
						}
					}
				}
			} catch (e) {
				if (e instanceof nlobjError) nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails())
				else nlapiLogExecution('DEBUG', 'unexpected error', e.toString())
			}
			if (context.getRemainingUsage() <= 1000 && (s + 1) < searchResults.length) {
				var record = nlapiLoadRecord('salesorder', recId);
				for (var prop in pwpObj) {
					var lineNum = record.findLineItemValue('item', FLD_COL_LINE_ID_SO, prop);
					if (lineNum != -1) {
						nlapiLogExecution('DEBUG', 'lineNum outside', prop + ' pwp', pwpObj[prop]);
						record.setLineItemValue('item', FLD_COL_LINE_PWP_RECS, lineNum, pwpObj[prop]);
						//add setting of PO Rates and PO Vendors
						var existingPOVendor = record.getLineItemValue('item', 'povendor', lineNum);
						var vendorName = record.getLineItemValue('item', FLD_COL_VENDOR_NAME, lineNum);
						var existingcreatepo = record.getLineItemValue('item', 'createpo', lineNum);
						if (vendorName == null) vendorName = '';
						// nlapiLogExecution('debug', 'po vendor', vendorName);
						//nlapiLogExecution('debug', 'existingPOVendor', existingPOVendor + ' vendorName='+vendorName);
						if (existingPOVendor != vendorName && vendorName != null && vendorName != '') {
							record.setLineItemValue('item', 'povendor', lineNum, vendorName);
							record.setLineItemValue('item', 'porate', lineNum, vendorName);
							if (existingcreatepo == null || existingcreatepo == '') {
								record.setLineItemValue('item', 'createpo', lineNum, 'SpecOrd');
							}
						}
					}
				}
				//check lines
				var pwpCount = 0;
				for (var x = 1; x <= itemCount; x++) {
					var idPWP = record.getLineItemValue('item', FLD_COL_LINE_PWP_RECS, x);
					if (idPWP != null && idPWP != '') {
						pwpCount++;
					}
				}
				if (pwpCount == itemCount) {
					nlapiLogExecution('DEBUG', 'all processed', pwpCount);
					record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE, 'T');
				}
                record.setFieldValue(FLD_SO_PWP_CREATE_SCRIPT_COMPLETE, 'T');
				var submittedRecId = nlapiSubmitRecord(record, true, true);
				nlapiLogExecution('DEBUG', 'submittedRecId', submittedRecId); //revert
				nlapiLogExecution('DEBUG', 'outside submit', 'outside submit');
				var params = {};
				params[SPARAM_SALESORDER_SS] = ssID;
				params[SPARAM_SO_INDEX] = 1;
				params[SPARAM_SS_INDEX] = (s + 1);
				nlapiLogExecution('DEBUG', 'params outside', JSON.stringify(params));
				nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
				break;
			}
		}
	}
}

function getAllSearchResults(record_type, filters, columns) {
	var search = nlapiCreateSearch(record_type, filters, columns);
	search.setIsPublic(true);
	var searchRan = search.runSearch(),
		bolStop = false,
		intMaxReg = 1000,
		intMinReg = 0,
		result = [];
	while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
		// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
		var extras = searchRan.getResults(intMinReg, intMaxReg);
		result = searchUnion(result, extras);
		intMinReg = intMaxReg;
		intMaxReg += 1000;
		// If the execution reach the the last result set stop the execution
		if (extras.length < 1000) {
			bolStop = true;
		}
	}
	return result;
}

function searchUnion(target, array) {
	return target.concat(array); // TODO: use _.union
}

function eliminateDuplicates(arr) {
	var i,
		len = arr.length,
		out = [],
		obj = {};
	for (i = 0; i < len; i++) {
		obj[arr[i]] = 0;
	}
	for (i in obj) {
		out.push(i);
	}
	return out;
}

/// v1.1
function getDefaultShipAddress(customer_id) {
	var customer_rec = nlapiLoadRecord('customer', customer_id);
	var index = customer_rec.findLineItemValue('addressbook', 'defaultshipping', 'T');
	if (index > 0) {
		var address_subrecord = customer_rec.viewLineItemSubrecord('addressbook', 'addressbookaddress', index);
		return {
			country: address_subrecord.getFieldValue('country'),
			//addressee: address_subrecord.getFieldValue('addressee'),
			//addr1: address_subrecord.getFieldValue('addr1'),
			//addr2: address_subrecord.getFieldValue('addr2'),
			//city: address_subrecord.getFieldValue('city'),
			//state: address_subrecord.getFieldValue('state'),
			//zip: address_subrecord.getFieldValue('zip'),
			//addrphone: address_subrecord.getFieldValue('addrphone')
		};
	}
	return null;
}
