/*
* Script Name : Appf-Mercury ProjectToNetsuite Proje SL
* Script Type : Suitelet
* Event Type  : Azure function triggered
* Description : This Suietlet acts as  web service or web hook for Inbound Flow of Connex to Netsuite "Client" which will trigger a scheduled script that processes all messages in queue.
* Company     :	Appficiency Inc.
*/
  var SCRIPT_SCHEDULED='customscript_appf_mercury_project_to_scs'
function suitelet(request, response)
{
	nlapiLogExecution('debug', 'script entry',  nlapiGetContext().getExecutionContext());	
nlapiScheduleScript(SCRIPT_SCHEDULED,null)
               
	response.write('Successfully connected to Netsuite, messages are being processed');
}
