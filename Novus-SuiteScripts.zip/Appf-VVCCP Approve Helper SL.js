/**
* Script Name : Appf-VVCCP Approve Helper SL
* Script Type : Suitelet
* 
* Version    Date            Author           		Remarks
* 1.00            			 Debendra Panigrahi						
*
* Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH='customscript_vvccp_approve_custmization';
var SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH='customscript_appf_vvccp_scheduled_reject';

var SPARAM_DATA_FILE_OF_BILL_AND_CREDITS='custscript_bill_and_billcredit_data_file';
var SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';


var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
		var FLD_APPROVAL_STATUS_APPROVED=2;
		var FLD_APPROVAL_STATUS_OPEN=11;
		var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
		var FLD_APPROVAL_STATUS_REJECTED=3;

var FLD_APPROVAL_TRIGGERED = 'custrecord_approval_button_triggered';

		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED=2
		var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=978;
		//VVCCP Execution Batch
		var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills';	
		var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred';
		var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
		var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
		var FLD_PROCESSED_PERCENT	     			='custrecord_appf_vvccp_log_percent';
		var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by';
		var FLD_STATUS	     						='custrecord_appf_vvccp_log_status';
		var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file';
		var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file';
		var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log';
		var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';
		var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
		var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
		var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
		var FLD_BILL_DATA_FILES						='ustrecord_appf_vvccp_bill_data_files';


var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9

//VVCCP
var CUSTOM_RECORD_VVCCP='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link	';
var FLD_STATUS	                	='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';	 

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;

var CORPORATE_CREDIT_CARD_VVCCP     ='custentity_appf_vvccp_corporate_cc';

var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';

var COL_FLD_PENDING_AUTHORIZATION_VVCCP='custcol_appf_pending_auth_vvccp';

var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link';

var CUSTOM_RECORD_CORPORATE_CREDIT_CARD_VENDOR_PAYMENT='customrecord_appf_corp_card_table';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias';
var FLD_CORPORATE_CREDIT_CARD_IS_MULTI='custrecord_appf_corp_credit_card_multi';
var SPARAM_DATA_FILE_OF_BILL_AND_CREDITS='custscript_bill_and_billcredit_data_file';
var SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD='custscript_vvccp_execution_batch_rec_lin';
var SPARAM_VVCCP_EXECUTION_BATCH_LINK_ID='custscript_vvccp_exec_batch_id';



function vvccpHelperSuitelet(request,response)
{
	try
	{
	var dataFile=request.getParameter('billAndCreditFileId');
	var recId=request.getParameter('recId');
	var stype=request.getParameter('stype');
	nlapiLogExecution('debug','triggered');
	if(dataFile !=null && dataFile !='' && recId !=null && recId !='')
	{
		if (stype == 'approve')
		{
		var params = {};
		params[SPARAM_DATA_FILE_OF_BILL_AND_CREDITS] = dataFile;
      	params[SPARAM_VVCCP_EXECUTION_BATCH_LINK_RECORD] =recId;
		nlapiScheduleScript(SCRIPT_APPF_UPDATE_VVCCP_EXECUTION_BATCH, null, params);
		}
		else if (stype == 'reject')
		{
			var params = {};
      	params[SPARAM_VVCCP_EXECUTION_BATCH_LINK_ID] =recId;
		nlapiScheduleScript(SCRIPT_APPF_REJECT_VVCCP_EXECUTION_BATCH, null, params);
			
		}
	nlapiSubmitField(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH,recId,FLD_APPROVAL_TRIGGERED, 'T');
	response.sendRedirect('RECORD',CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH,recId)
	}
	}
	catch(e)
	{
		nlapiLogExecution('debug','error details:',e.toString());
	}
}

 function percentage(partialValue, totalValue) {
   return (100 * partialValue) / totalValue;
}	

function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}