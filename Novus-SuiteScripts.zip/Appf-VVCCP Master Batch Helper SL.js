/**
	 * Script Name : Appf-VVCCP Master Batch Helper SL
	 * Script Type : Suitelet
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			 Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD='customrecord_appf_vvccp_batch_master';
var FLD_APPROVAL_STATUS='custrecord_appf_vvccp_master_approvestat';
var SCRIPT_VVCCP_APPROVE_CUSTOMIZATION_ID='customscript_vvccp_approve_custmization';
var SCRIPT_VVCCP_APPROVE_CUSTOMIZATION_DEPLOY_ID='customdeploy_vvccp_approve_custmization';
var SPARAM_MASTER_VVCCP_BATCH_RECORD_ID_APPROVE_CUSTOMIZATION='custscript_vvccp_execution_batch_rec_lin'
var SCRIPT_VVCCP_REJECTED_CUSTOMIZATION_ID='customscript_appf_vvccp_scheduled_reject';
var SCRIPT_VVCCP_REJECTED_CUSTOMIZATION_DEPLOY_ID='customdeploy1';
var SPARAM_MASTER_VVCCP_BATCH_RECORD_ID_REJECT_CUSTOMIZATION='custscript_vvccp_exec_batch_id';
var VVCCP_MASTER_BATCH_APPROVE_STATUS=2;
var VVCCP_MASTER_BATCH_REJECT_STATUS=3;
function masterBatchHelper(request,response)
{
	var recid=request.getParameter('recId');
	var stype=request.getParameter('stype');
	var approvalStatus='';
	if(recid !=null && recid !='')
	{
		if(stype == 'approve')
		{
				approvalStatus=VVCCP_MASTER_BATCH_APPROVE_STATUS;
				var sparams = {};
				sparams[SPARAM_MASTER_VVCCP_BATCH_RECORD_ID_APPROVE_CUSTOMIZATION] = recid;
				nlapiScheduleScript(SCRIPT_VVCCP_APPROVE_CUSTOMIZATION_ID, null, sparams);
		}
		if(stype == 'reject')
		{
				approvalStatus=VVCCP_MASTER_BATCH_REJECT_STATUS;
				var sparams = {};
				sparams[SPARAM_MASTER_VVCCP_BATCH_RECORD_ID_REJECT_CUSTOMIZATION] = recid;
				nlapiScheduleScript(SCRIPT_VVCCP_REJECTED_CUSTOMIZATION_ID, null, sparams);
		}
		nlapiSubmitField(CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD,recid,FLD_APPROVAL_STATUS,approvalStatus);
		response.sendRedirect('RECORD', CUSTOM_RECORD_VVCCP_MASTER_BATCH_RECORD, recid);
	}
}
