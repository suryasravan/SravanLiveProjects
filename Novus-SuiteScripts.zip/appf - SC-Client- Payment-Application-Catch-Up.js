/**
 *@NApiVersion 2.0
 *@NScriptType ScheduledScript
 */
  /*
* Script Name : appf - SC-Client Payment Application Catch-Up 
* Script Type : Scheduled Script
* Description : V1 21/06/2021  the script should Identify the Invoices to be updated based off a saved search, and simply update the Invoice Line Payment Amount to be equal to the client gross Allocation
*                   
* Script Owner: Tarini
* Company     : Appficiency Inc.
*/
var SCRIPT_PARAM_FOR_SS = "custscript_invoice_ss_param"; 
var INDEX_PARAM = 'custscript_index_invoice';
var DATA_PARAM = 'custscript_data_invoice';

var INVOICE_LINE_PAYMENT_AMOUNT = 'custcol_appf_pwp_inv_line_amt_paid';
var INVOICE_LINE_SHARE_OF_SAVINGS = 'custcol_appf_sos_discount';

var INVOICE_LINE_ID = 'custcol_appf_invoice_line_id'; 
 
 
 
define(['N/file','N/search','N/render', 'N/record', 'N/email', 'N/runtime','N/redirect','N/error','N/task'],
    function(file,search,render, record, email, runtime,redirect,error,task) 
	{
        function execute(context)
		{
			var today = new Date();

		     
			var scriptObj = runtime.getCurrentScript(); 
			 
            var index1 = scriptObj.getParameter({name:INDEX_PARAM});
			 var mainobjstr = scriptObj.getParameter({name:DATA_PARAM});
			if (index1 == null || index1 == '')
            index1 = 0;
            var saveSearchId=scriptObj.getParameter({name: SCRIPT_PARAM_FOR_SS});
			var mainObj = null;
			  if (mainobjstr == null || mainobjstr == '')
			  {
		   	var extSSObj = search.load({id:saveSearchId})
			var extFils = extSSObj.filters;
			var extCols = extSSObj.columns;
			var existingSS = getSearchResults('invoice',extFils , extCols);
			 
					if(existingSS.length >0 && existingSS != null && existingSS != '')
					{
						 mainObj = {};
						for(var j= 0;j<existingSS.length;j++)
						{
							var internalId = existingSS[j].id;
							var quantity = existingSS[j].getValue({name:INVOICE_LINE_ID});
							
							
							if(!mainObj.hasOwnProperty(internalId))
							{
                            mainObj[internalId]={};
                            mainObj[internalId]=[quantity];
                                                                 
                            }
                            else
							{
						    var extObj =  mainObj[internalId];
							extObj.push(quantity);
							mainObj[internalId]=extObj;
                                     
							}
							 
							
						}//end-for	
					 
						
					}//end-if-ss
			  }
			  else
			  {
				  mainObj = JSON.parse(mainobjstr)
			  }
			
			 log.debug('mainObj',mainObj);
         
            if(mainObj != null && mainObj != '')
			{
				//var covert = Object.keys(mainObj).map((key) => [Number(key), mainObj[key]]);
				 
				var dataArray  = Object.keys(mainObj).map(function(key)  
				{  
				return [Number(key), mainObj[key]];  
				});  
				 log.debug('dataArray',dataArray)
				 
				 for (var s =index1; s < dataArray.length; s++)
				 {
					 
					 var invoice_id =  dataArray[s][0];
					 try{
               var lineIDData =dataArray[s][1];
			   var invoice_rec = record.load({type:'invoice', id: invoice_id, isDynamic: true})
			   var lineCount = invoice_rec.getLineCount({sublistId:'item'});
			   
			   for (var l =0 ; l < lineCount; l++)
			   {
				   var qty = invoice_rec.getSublistValue({sublistId:'item', fieldId:'quantity', line: l})
				   var shareOfSavings = invoice_rec.getSublistValue({sublistId:'item', fieldId:INVOICE_LINE_SHARE_OF_SAVINGS, line: l})
								   if (shareOfSavings == null || shareOfSavings == '')
									   shareOfSavings = 0;
								   
								   qty = parseFloat(qty) + parseFloat(shareOfSavings);

				   var line_id = invoice_rec.getSublistValue({sublistId:'item', fieldId:INVOICE_LINE_ID, line: l})
				   
				   if (lineIDData.indexOf(line_id) != -1)
				   {
					   invoice_rec.selectLine({sublistId:'item', line: l});
					   invoice_rec.setCurrentSublistValue({sublistId:'item', fieldId: INVOICE_LINE_PAYMENT_AMOUNT, value: qty});
					   invoice_rec.commitLine({sublistId:'item'})
				   }
			   }
			   invoice_rec.save({enableSourcing: true,ignoreMandatoryFields: true});

			   
					 }
					 catch(e)
					 {
						 log.debug('Failed to submit invoice:'+invoice_id, e.message);
					 }
					 var newdt = new Date();
var diffMs = (newdt - today); // milliseconds between now & Christmas

var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); 

					 //reschedule logic
				if((scriptObj.getRemainingUsage() <= 500 || diffMins > 45) && (parseInt(s)+1) < dataArray.length)
				{
				var reschedule = task.create({
				taskType: task.TaskType.SCHEDULED_SCRIPT,
				scriptId: scriptObj.id,
				deploymentId: scriptObj.deploymentId,
				params: {INDEX_PARAM: s+1, DATA_PARAM: JSON.stringify(mainObj) }
				});
				var scheduledScriptTaskId = reschedule.submit();
				break;
				}
				
				 }
				
			}//end-if-mainObj 		 
			   
		
		}
		
		
		function getSearchResults(rectype, fils, cols) {
					var mySearch = search.create({
						type: rectype,
						columns: cols,
						filters: fils
					});
					var resultsList = [];
					var myPagedData = mySearch.runPaged({
						pageSize: 1000
					});
					myPagedData.pageRanges.forEach(function (pageRange) {
						var myPage = myPagedData.fetch({
							index: pageRange.index
						});
						myPage.data.forEach(function (result) {
							resultsList.push(result);
						});
					});
					return resultsList;
				}
		
		
		
		return {
            execute: execute
               };
    });