/*Script Name: Appf-Refresh Vendor Discrepancy Log UE
 *Script Type: User
 *Event Type : Before Load
 *Description: This script creates a refresh button on Appf-Vendor Discrepancy Execution Log custom record on click it refresh the record. 
 *Company 	 : Appficiency.
 */

var CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG='customrecord_appf_vendor_discrepancy_log';
var FLD_PROCESSED_PERCENTAGE='custrecord_appf_vbl_processed_percentage';

var BTN_REFRESH = 'custpage_refresh';
var BTN_VENDOR_DISCREPANCY_SUITLET='custpage_vendor_discrepancy_suitelet';

var SCRIPT_SL_VENDOR_DISCREPANCY_SUITELET='customscript_appf_vendor_discrepancy_sl';
var DEPLOY_SL_VENDOR_DISCREPANCY_SUITELET='customdeployappf_vendor_discrepancy_sl';

var SCRIPT_SL_VENDOR_DISCREPANCY_LOG_VB_SS='customscript_appf_vendor_dis_log_rec_ss';
var DEPLOY_SL_VENDOR_DISCREPANCY_LOG_VB_SS='customdeploy_appf_vendor_dis_log_rec_ss';

function refreshButton(type, form, request)
{
	
	    if(type=='view')
	    {
          try{
	    var id = nlapiGetRecordId();
	    var processedPercentage=nlapiGetFieldValue(FLD_PROCESSED_PERCENTAGE);
      
	    if(processedPercentage == null || processedPercentage == '' || parseFloat(processedPercentage) < 100){ 
		 var url=nlapiResolveURL('SUITELET', SCRIPT_SL_VENDOR_DISCREPANCY_LOG_VB_SS,DEPLOY_SL_VENDOR_DISCREPANCY_LOG_VB_SS);
		 url=url+'&custrecid='+id;
		form.addButton(BTN_REFRESH,'Refresh','window.open(\''+url+'\',\'_self\')');
	    }
	    else
	    {
	    	var suiteletURL=nlapiResolveURL('SUITELET', SCRIPT_SL_VENDOR_DISCREPANCY_SUITELET,DEPLOY_SL_VENDOR_DISCREPANCY_SUITELET);
	 		form.addButton(BTN_VENDOR_DISCREPANCY_SUITLET,'Vendor Discrepancy Suitelet','window.open(\''+suiteletURL+'\',\'_self\')');	
	    }
          }catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
	}
}