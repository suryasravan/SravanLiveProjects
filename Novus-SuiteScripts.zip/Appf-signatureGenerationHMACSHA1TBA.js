/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 */

define(['N/ui/serverWidget', 'N/runtime', 'N/crypto', 'N/encode','N/https'], function(ui, runtime, crypto, encode,https) {
    function onRequest(context) {
      var currentDate = new Date().getTime()/1000;
		var weekval = 60*60*24*7;
		var revisedTime = currentDate+ weekval;
      revisedTime = Math.ceil(revisedTime);
	  //revisedTime = 2079993602;
   var netsuiteAccNum = "3619984";
	var nonceId = randomString(20);
	var timeStamp = Math.ceil(new Date().getTime() / 1000);
	var consumerKey = "04d221aec510747e46d165b5fcf7f456b7449ec6b48099d1450a4a4b91314557";
	var tokenId = "0939ddc71a3cd32bccbefc838da48b2f1695225056f8fe536f4d41915bb13c0d";
	var consumerSecret = "858e9f649d62ceff1aa67ff9a165d0868c05f04fbf12469dc3df67bd4a8141ac";
	var tokenSecret = "f5563302b5096a97b763e7848ce6d155da8d28d85c6ed20828eef38fc642d5aa";
	


	var baseString = netsuiteAccNum+'&'+consumerKey+'&'+tokenId+'&'+nonceId+'&'+timeStamp;
	var signingKey = consumerSecret+'&'+tokenSecret; 
      
          try{
                var hmacSha1 = crypto.createHmac({
                    algorithm: crypto.HashAlg.SHA1,
                    key: signingKey
                });
                hmacSha1.update({
                    input: baseString,
                    inputEncoding: encode.Encoding.UTF_8
                });
                var digestSha256 = hmacSha1.digest({
                    outputEncoding: encode.Encoding.BASE_64
                });
                    log.debug({title: 'sth',details: digestSha256});
                      context.response.write(digestSha256);
		  }
		  catch(e)
		  {
			  
			                      log.debug({title: 'error',details: e.toString()});

		  }
					

		  


    }
	function randomString(length) {
  var text = "";
  var possible =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}

    return {
        onRequest: onRequest
    };
});