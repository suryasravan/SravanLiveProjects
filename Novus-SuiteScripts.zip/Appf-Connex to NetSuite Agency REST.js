/*
* Script Name : Appf-Connex to NetSuite Agency REST
* Script Type : 
* Event Type  : 
* Description :This script when executed checks for any new messages in the queue related to Connext Clients and pushes the clients from those messages into netsuite and creates or updates as Customer records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
* Company     :	Appficiency Inc.
*/
 var SPARAM_CONNEX_AGENCY='customscript_appf_connex_agency_2_ns_sc'
function getAgencyRESTlet(dataIn)
{
	 nlapiLogExecution('debug', 'internalId',  'internalId');
     nlapiScheduleScript(SPARAM_CONNEX_AGENCY,null)
	return 'RESTlet successfully connected.';
	}
