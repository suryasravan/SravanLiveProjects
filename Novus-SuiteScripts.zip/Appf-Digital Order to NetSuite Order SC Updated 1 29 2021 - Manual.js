/**
*Script Name:Appf-Digital to Netsuite Order Sc
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Digital Order and pushes the Order from those messages into netsuite and creates or updates as Order records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_digital_outdo_order_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecord_appf_digita_order_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_digita_order_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecordappf_digital_order_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_digital_order_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_order_digital_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_response_digit_order_status';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_appf_order_status_code';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_appf_order_correlid';
 var CUSTOMRECORD_FLD_CONNEX_NS_RESP = 'custrecord_appf_ns_digit_orders_response';
 // Integration Related
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
// Integration Related
 var QUEUE_CONNEX_ORDER_INBOUND = 'novusmedia_digital_order_in';
 //novusmedia_connex_client_in
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_buyingsystem_salesorder_change';
 var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
 
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee'];
 var FLD_CONNEX='custentity_appf_buyingsystem_id'
 var NS_CLIENT='Novus.Azure.WebJobs.NetSuite.Dtos.SalesOrderResponse'
 
 var FLD_CONNEX='custentity_appf_buyingsystem_id'
 var NS_CLIENT='Novus.Azure.WebJobs.NetSuite.Dtos.SalesOrderResponse'

var SPARAM_CONNEX_CLIENT='customscript_appf_digital_order_2_ns_sc'
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
function createOrderScheduled(type) 
  {	
	 var context = nlapiGetContext();
	 var URL_BASE=''
	 var signatures=''
	
     var context = nlapiGetContext();
	 var userAccountId = context.getCompany();
	 if(userAccountId=='3619984_SB3')
	 {
		 URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
		 signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
	 }
	 if(userAccountId=='3619984_SB2')
	 {
		 URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
		 signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
	 }
	 if(userAccountId=='3619984')
	 {
		 URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
		 signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
	 }
    if(URL_BASE!=null && URL_BASE!='')   //1st difference
      {
		   var messagesFound=true
           
		   while (messagesFound == true) 
		   {
			   var usageRemaining = context.getRemainingUsage();
			   var idForResponse = '';
			   var pareConnex=''
			   var d = new Date();
			   var UTCDate= d.toISOString();
			   var url = URL_BASE+QUEUE_CONNEX_ORDER_INBOUND+'/messages/head?api-version=2015-01';
			   var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
			   var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
			   //var mainObj = responseData.getBody()+'';
			   
			   var mainObj = {
					   "custbody_appf_clientcontractid": "22c973b5-70fa-46f6-a63c-9f0c1962ce99",
					   "custbody_appf_client_contract": 29515,
					   "MediaSupplierNetSuiteId": 104542,
					   "custbody_appf_mediasupplierid": "8f50be5d-122f-4250-b5d8-55df14c52967",
					   "custbody_appf_clientid": "6556ce92-7876-4f2c-bde5-8058b5df42ce",
					   "entity": 745598,
					   "custbody_appf_vendorid": "3a1147ec-2f4c-457e-bf20-37c1bc79045b",
					   "custbody_appf_agency": null,
					   "custbody_appf_orderreference": "JY TEST 33",
					   "custbody_appf_buyingsystem_id": "BS140066",
					   "custbody_appf_buying_system": "3",
					   "custbody_appf_universalid": "35d9523c-0676-43d0-a7ad-e4c89712ec23",
					   "custbody_appf_print_username": "NovusSADevNGA",
					   "custbody_appf_print_schedule": "Test 1/21",
					   "custbody_appf_print_dma": null,
					   "custbody_appf_print_dmaId": null,
					   "custbody_appf_print_onsaledate": null,
					   "custbody_appf_print_isodate": null,
					   "custbody_appf_print_omiflag": null,
					   "custbody_appf_print_mediatype": null,
					   "otherrefnum": null,
					   "custbody_appf_print_clientobjective": null,
					   "custbody_appf_print_servicedate": null,
					   "custbody_appf_datepoprecieved": null,
					   "custbody_appf_print_sourcesystem": 0,
					   "custbody_appf_print_keycode": null,
					   "custbody_appf_clientnet": 17212254.7,
					   "custbody_appf_novusnet": 11474836.47,
					   "custbody_appf_orderstatus": "1",
					   "custbody_appf_print_sysupdatedate": null,
					   "custbody_appf_sysupdatedate": "1/21/2021",
					   "custbody_appf_integr_lastupdatedate": "1/23/2021 11:45:26 PM",
					   "custbody_appf_print_createdate": "1/21/2021",
					   "custbody_appf_print_lastattemptdate": "1/21/2021",
					   "startdate": "2/1/2021",
					   "enddate": "2/9/2021",
					   "customform": 141,
					   "id": 3016905,
					   "custbody_appf_print_creative": null,
					   "custbody_appf_print_creativeproduct": null,
					   "custbody_appf_print_ddspubcode": null,
					   "custbody_appf_print_descriptionofserv": null,
					   "custbody_appf_print_mediasuppliercategory": null,
					   "custbody_appf_print_mediasupplierstate": null,
					   "custbody_appf_print_placementdate1": null,
					   "custbody_appf_print_placementdate2": null,
					   "custbody_appf_dig_placementdate1": null,
					   "custbody_appf_dig_placementdate2": null,
					   "custbody_appf_dig_placementbegindate": "1/21/2021",
					   "custbody_appf_dig_placementenddate": "2/9/2021",
					   "custbody_appf_dig_placementtype": "Single",
					   "custbody_appf_print_placementnumber1": null,
					   "custbody_appf_print_placementnumber2": null,
					   "custbody_appf_print_placementtype": "Single",
					   "custbody_appf_print_prodfinancialdimension": null,
					   "custbody_appf_print_program": null,
					   "custbody_appf_print_placementsection": null,
					   "custbody_appf_dig_section": "ROS/RON",
					   "custbody_appf_print_quantity": 0,
					   "custbody_appf_print_scheduledate1": null,
					   "custbody_appf_dig_campaigndate1": null,
					   "custbody_appf_print_schedulenumber1": null,
					   "custbody_appf_dig_campaignnum1": null,
					   "custbody_appf_print_suppcostcalctype": null,
					   "custbody_appf_print_suppcostclientamt": 0.0,
					   "custbody_appf_print_suppcostclientname": null,
					   "custbody_appf_print_suppcostclientrate": null,
					   "custbody_appf_print_suppcostnovusamt": 0.0,
					   "custbody_appf_print_suppcostnovuscalctype": null,
					   "custbody_appf_print_suppcostnovusname": null,
					   "custbody_appf_print_suppcostnovusrate": null,
					   "custbody_appf_dig_adservedby": "Novus",
					   "custbody_appf_forecastquantity": 1147483647,
					   "custbody_appf_dig_bookedquantity": 2147483647,
					   "custbody_appf_dig_campaignstring1": null,
					   "custbody_appf_dig_campaignstring2": null,
					   "custbody_appf_dig_campaignstring3": null,
					   "custbody_appf_dig_campaignstring4": null,
					   "custbody_appf_dig_campaignstring5": null,
					   "custbody_appf_dig_ionum": "111785_0",
					   "custbody_appf_dig_placementnum": "PL178797",
					   "custbody_appf_dig_placementnum1": null,
					   "custbody_appf_dig_placementnum2": null,
					   "custbody_appf_productbrand": null,
					   "custbody_appf_estimateno": null,
					   "custbody_appf_do_divisionname": null,
					   "custbody_appf_do_status": null,
					   "custbody_appf_do_agency": null,
					   "custbody_appf_strata_agencyoffice": null,
					   "custbody_appf_strata_agenycompany": null,
					   "custbody_appf_clientcode": null,
					   "custbody_appf_strata_estimatename": null,
					   "custbody_appf_strata_key": null,
					   "custbody_appf_strata_modulename": null,
					   "custbody_appf_strata_productcode": null,
					   "custbody_appf_strata_station": null,
					   "custbody_appf_strata_transid": null,
					   "custbody_appf_campaign": "JY Test 1/21",
					   "custbody_appf_vendorname": 550184,
					   "custbody_appf_do_campaignnum": null,
					   "IsMultiLine": null,
					   "items": [
					   {
					   "custcol_appf_publisher": 104542,
					   "custcol_appf_po_vendor_name": 550184,
					   "cseg_appf_media_seg": "1",
					   "custcol_appf_bill_month": "21/03",
					   "custcol_appf_adsize": "1x1 ; ",
					   "custcol_appf_clientcalctype": "CPM",
					   "custcol_appf_clientunitrate": 15.0,
					   "custcol_appf_corporateowner": null,
					   "custcol_appf_dig_actualimpressions": null,
					   "custcol_appf_dig_billableimpressions": null,
					   "custcol_appf_dig_bsnum": "BS140066",
					   "custcol_appf_dig_forecastquantity": 1147483647,
					   "custcol_appf_dig_ionumber": "JY TEST 33",
					   "custcol_appf_dig_placementnum": "JY TEST 33",
					   "custcol_appf_ionum": "JY TEST 33",
					   "custcol_appf_ismediamarkupfixed": "F",
					   "custcol_appf_margin": 33.33,
					   "custcol_appf_marginamt": 5737418.24,
					   "custcol_appf_markupamt": 0.0,
					   "custcol_appf_markuppercent": 0.0,
					   "custcol_appf_novuscalctype": "CPM",
					   "custcol_appf_novusunitrate": 10.0,
					   "custcol_appf_placement1": "14200",
					   "custcol_appf_placement2": "460500",
					   "custcol_appf_placement3": "46050001",
					   "custcol_appf_placement4": "",
					   "custcol_appf_placement5": "",
					   "custcol_appf_placement6": "",
					   "custcol_appf_print_schedulestring1": null,
					   "custcol_appf_print_schedulestring2": null,
					   "custcol_appf_print_schedulestring3": null,
					   "custcol_appf_print_schedulestring4": null,
					   "custcol_appf_print_schedulestring5": null,
					   "custcol_appf_pop_received": "F",
					   "custcol_appf_print_circulation": 0,
					   "custcol_appf_print_servicedate": null,
					   "custcol_appf_print_suppclientcalctype": null,
					   "custcol_appf_print_suppnovuscalctype": null,
					   "custcol_appf_print_suppclientrate": null,
					   "custcol_appf_print_suppnovusrate": null,
					   "custcol_appf_print_suppclientamt": null,
					   "custcol_appf_print_suppnovusamt": null,
					   "custcol_appf_publisher_display": null,
					   "custcol_appf_startdate_custom": "2/1/2021",
					   "custcol_appf_so_line_enddate": "2/9/2021",
					   "custcol_appf_vendor_allocation_amount": 11474836.47,
					   "description": null,
					   "item": 72,
					   "job": "816213",
					   "quantity": 17212254.7,
					   "custcol_appf_do_arcstatus": null,
					   "custcol_appf_do_additionalcost": null,
					   "custcol_appf_do_cycleno": null,
					   "custcol_appf_do_cycletype": null,
					   "custcol_appf_do_ddpubcode": null,
					   "custcol_appf_do_ddspubcodemarket": null,
					   "custcol_appf_do_estimatenum": null,
					   "custcol_appf_do_format": null,
					   "custcol_appf_do_impscycle": null,
					   "custcol_appf_do_invnum": null,
					   "custcol_appf_do_market": null,
					   "custcol_appf_do_marketcode": null,
					   "custcol_appf_do_numunits": null,
					   "custcol_appf_do_product": null,
					   "custcol_appf_do_ratetypename": null,
					   "custcol_appf_do_recordid": null,
					   "custcol_appf_do_vendorinvoiceno": null,
					   "custcol_appf_do_grossratingpoint": null,
					   "custcol_appf_do_province": null,
					   "custcol_appf_do_clientnetcost": null,
					   "custcol_appf_do_vendorcode": null,
					   "custcol_appf_do_mediatypename": null,
					   "custcol_appf_do_productcode": null,
					   "custcol_appf_do_dds_product": null,
					   "custcol_appf_do_dds_clientcode": null,
					   "custcol_appf_do_dds_estimate": null,
					   "custcol_appf_dig_ionum": "111785_0",
					   "custcol_appf_mediaocean_upload": "F",
					   "custcol_appf_do_agency": null,
					   "custcol_appf_makegoodorder": "F",
					   "custcol_appf_strata_estimatenum": null,
					   "custcol_appf_strata_estbillingcode": null,
					   "custcol_appf_strata_product": null,
					   "custcol_appf_print_dds": null,
					   "custcol_appf_strata_market": null,
					   "billingschedule": "21/03"
					   }
					   ],
					   "Originator": null,
					   "OriginalMessageId": "a8f6428d-cc19-4f01-842f-acb701866900"
					   } 
			   
			   //mainObj = JSON.parse(mainObj); // + '';
			   
			   nlapiLogExecution('debug','mainObj content',mainObj);
			   var CorrelationIdProp='NServiceBus.CorrelationId'
			   var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'
		
			   var CorrelationId=responseData.getHeader(CorrelationIdProp)  
			   var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
			   var Status=''
			   var Status1=''
		       var scriptStatus=''
               var fileData=''
		        if(mainObj==null || mainObj=='')
		        {
					 messagesFound=false;
					 Status='FAILED'+'(Empty Message)'
					 scriptStatus='FAILED'
					 Status1='FAILED'+'(Empty Message)'
		        }
		        else
		        {
		        	try {
		        		mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
		        		mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
		        		fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
		        		mainObj = JSON.parse(fileData);
		        		if(mainObj.hasOwnProperty('custbody_appf_buyingsystem_id'))
		        		{
		        			pareConnex=mainObj['custbody_appf_buyingsystem_id'];
		        			nlapiLogExecution('debug', 'pareConnex:', pareConnex);
		        		}
		        		Status='SUCCESS'
			   } 
				catch (e) 
				{
				   Status='FAILED'+'(invalid JSON)'
				   scriptStatus='FAILED'
					Status1='FAILED'+'(invalid JSON)'
				}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var integrationResponseObj={}
					
		var mCode = 225;
		if(mCode!='200' && mCode!='201'/*responseData.getCode()!='200' && responseData.getCode()!='201'*/)
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
			 var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			 integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			 integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			 integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_ORDER_INBOUND)
			 integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS,'FAILED')
			 //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			 integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			 //integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		    nlapiSubmitRecord(integrationRecord,true,true)
		   }
		   
		}  
		else{	

			var nsOrderRecord='';
			var isNewRecord = true;  
			var nsOrderCounts=0;
            var internalId=''
			var isUpdateRecord = true; 
			var nsCreationMsg = '';
			try
			{
				if(!mainObj.hasOwnProperty('id'))
				{
					nsOrderRecord=nlapiCreateRecord('salesorder')
					if(mainObj.hasOwnProperty('custbody_appf_buyingsystem_id'))
					{
						var ConnexId=mainObj['custbody_appf_buyingsystem_id']
						nlapiLogExecution('debug', 'ConnexId:', ConnexId);
						if(ConnexId!=null && ConnexId!='')
						{
							var nsfils = [];
							nsfils.push(new nlobjSearchFilter('custbody_appf_buyingsystem_id',null,'is',ConnexId));
							nsfils.push(new nlobjSearchFilter('mainline',null,'is','T'));
							nsfils.push(new nlobjSearchFilter('type',null,'is','SalesOrd'));
							 
							var custRecord=nlapiSearchRecord('transaction', null, nsfils);
							if(custRecord!=null && custRecord!='')
							{
								nlapiLogExecution('debug','custRecord',custRecord);
								if(custRecord.length>0)
								{
									internalId=custRecord[0].getId()
									nlapiLogExecution('debug', 'internalIdin:',internalId);
									idForResponse=internalId
									nsOrderRecord=nlapiLoadRecord('salesorder',internalId);
									var nsOrderRecordStatus=nsOrderRecord.getFieldValue('status');
                              
									var buyingSystemText=nsOrderRecord.getFieldText('custbody_appf_buying_system');
									var orderStatusId=nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
				                    /*if(nsOrderRecordStatus=='Closed' || nsOrderRecordStatus=='Canceled' || nsOrderRecordStatus=='Cancelled') //v2 removed 9/4/2020
				                              {
				                               Status='FAILED'
				                               scriptStatus='FAILED'
				                               nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
				                   }*/
				                   if((buyingSystemText=='Print' || buyingSystemText=='Digital') && orderStatusId == 5)
				                   {
					                    Status='FAILED'
					                    scriptStatus='FAILED'
					                    nsCreationMsg='Cannot update Confirmed Cancelled orders in Netsuite'
				                   }

				                   nsOrderCounts=nsOrderRecord.getLineItemCount('item')
				                   if(nsOrderCounts>=1) isNewRecord=false
				                   var msdate=''
				                   var nsdate=nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
				                   if(mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate'))
				                   {
				                	   msdate=mainObj['custbody_appf_integr_lastupdatedate']
				                   }					 
			
				                   if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				                   {
				                	   var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
				                	   var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
				                	   if(MsdateTm>nsdateTm)
				                	   {
				                		   isUpdateRecord=true;
				                	   }
				                	   else
				                	   {
				                		   isUpdateRecord=false
				                	   }
				                   }  
								}
							}
						}
					 
					}
				}
				else
				{
			
					var internalId=mainObj['id']
					nlapiLogExecution('debug', 'internalId',  internalId + ' mainObj id = ' + mainObj['id']);
					if(internalId==null || internalId=='' || internalId=='null')
					{
						nsOrderRecord=nlapiCreateRecord('salesorder')
						if(mainObj.hasOwnProperty('custbody_appf_buyingsystem_id'))
						{
							var ConnexId=mainObj['custbody_appf_buyingsystem_id']
							nlapiLogExecution('debug', 'ConnexId:', ConnexId);
							if(ConnexId!=null && ConnexId!='')
							{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter('custbody_appf_buyingsystem_id',null,'is',ConnexId));
	                           nsfils.push(new nlobjSearchFilter('mainline',null,'is','T'));
	                           nsfils.push(new nlobjSearchFilter('type',null,'is','SalesOrd'));
							 
	                           var custRecord=nlapiSearchRecord('transaction', null, nsfils);
	                           if(custRecord!=null && custRecord!='')
	                           {
	                            nlapiLogExecution('debug','custRecord',custRecord);
	                            if(custRecord.length>0)
	                            {
	                            	internalId=custRecord[0].getId()
	                            	nlapiLogExecution('debug', 'internalIdin:',internalId);
	                            	idForResponse=internalId
	                            	nsOrderRecord=nlapiLoadRecord('salesorder',internalId);
	                            	var nsOrderRecordStatus=nsOrderRecord.getFieldValue('status');

	                            	var buyingSystemText=nsOrderRecord.getFieldText('custbody_appf_buying_system');
	                            	var orderStatusId=nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
											/*/if(nsOrderRecordStatus=='Closed' || nsOrderRecordStatus=='Canceled' || nsOrderRecordStatus=='Cancelled') //v2 removed 9/4/2020
											{
											 Status='FAILED'
											 scriptStatus='FAILED'
											 nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
						         }*/
							         if((buyingSystemText=='Print' || buyingSystemText=='Digital') && orderStatusId == 5)
							         {
							        	 Status='FAILED'
							        	 scriptStatus='FAILED'
							        	 nsCreationMsg='Cannot update Confirmed Cancelled orders in Netsuite'
							         }
							         nsOrderCounts=nsOrderRecord.getLineItemCount('item')
							         if(nsOrderCounts>=1) isNewRecord=false
							         var msdate=''
							         var nsdate=nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
							         if(mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate'))
							         {
							        	 msdate=mainObj['custbody_appf_integr_lastupdatedate']
							         }					 
			
							         if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
							         {
							        	 var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
							        	 var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
							        	 if(MsdateTm>nsdateTm)
							        	 {
							        		 isUpdateRecord=true;
							        	 }
							        	 else
							        	 {
							        		 isUpdateRecord=false
							        	 }
							         }  
	                            }
	                           }
							}
					 
						}
					}
					else
					{
						idForResponse = internalId
						nlapiLogExecution('debug', 'idForResponse', idForResponse + 'internalId' + internalId );
						nsOrderRecord = nlapiLoadRecord('salesorder', internalId, {recordmode: 'dynamic'});
						nlapiLogExecution('debug', 'nsOrderRecord', nsOrderRecord)
						var nsOrderRecordStatus = nsOrderRecord.getFieldValue('status');
						var buyingSystemText = nsOrderRecord.getFieldText('custbody_appf_buying_system');
						var orderStatusId = nsOrderRecord.getFieldValue('custbody_appf_orderstatus');
						/*if(nsOrderRecordStatus=='Closed' || nsOrderRecordStatus=='Canceled' || nsOrderRecordStatus=='Cancelled') //v2 removed 9/4/2020
								{
								 Status='FAILED'
								 scriptStatus='FAILED'
								 nsCreationMsg='Cannot update cancelled or closed orders in in Netsuite'
			         }*/
						if ((buyingSystemText == 'Print' || buyingSystemText == 'Digital') && orderStatusId == 5) {
							Status = 'FAILED'
							scriptStatus = 'FAILED'
							nsCreationMsg = 'Cannot update Confirmed Cancelled orders in Netsuite'
						}
						nsOrderCounts = nsOrderRecord.getLineItemCount('item')
						if (nsOrderCounts >= 1) isNewRecord = false
						var msdate = ''
						var nsdate = nsOrderRecord.getFieldValue('custbody_appf_integr_lastupdatedate')
						if (mainObj.hasOwnProperty('custbody_appf_integr_lastupdatedate')) {
							msdate = mainObj['custbody_appf_integr_lastupdatedate']
						}
						if (nsdate != null && nsdate != '' && msdate != null && msdate != '') {
							var nsdateTm = nlapiStringToDate(nsdate, 'datetimetz')
							var MsdateTm = nlapiStringToDate(msdate, 'datetimetz')
							if (MsdateTm > nsdateTm) {
								isUpdateRecord = true;
							} else {
								isUpdateRecord = false
							}
						}
					}

				}
			} catch(e1)
			{
				scriptStatus='FAILED'
				if ( e1 instanceof nlobjError ) nsCreationMsg = e1.getDetails();
				else nsCreationMsg = e1.toString();
			} 		
            nlapiLogExecution('debug','scriptStatus',scriptStatus + ' nsCreationMsg='+ nsCreationMsg + ' isUpdateRecord = ' + isUpdateRecord + ' Status='+Status);
			var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_ORDER_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
		   var nsOrderRecordID=null;
		  
		   if(Status==null || Status=='' || Status=='SUCCESS')
		   {
			   try{ 
				   if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
				   {					
				
					   var hasAddressBook =false;
					   var addressBookObj = {};
					   for (var parentProp in mainObj)
					   {
						   var parentProp=parentProp
						   var parentProp1=''
                           if(parentProp=='items')
                           {
                        	   parentProp1=mainObj[parentProp]
                           } 
                           if(parentProp!='items')
                           {
						      //var parentProp2=nsOrderRecord.getFieldValue(parentProp)
						        if((parentProp!=null && parentProp!=''))
						           {
                                      
						              if(parentProp!='otherrelationships' && parentProp!='id'){
						            	  nsOrderRecord.setFieldValue(parentProp,mainObj[parentProp]);
						            	  nlapiLogExecution('debug','header field id',parentProp + ' field value='+ mainObj[parentProp]);
						              }else{
                                          nlapiLogExecution('debug','DO NOT SET header field id',parentProp + ' field value='+ mainObj[parentProp]);
                                      }
						              
						           }
                           }
                           else
                           {
							   var isArray=true;
							   if (parentProp1 instanceof Array) {
								   isArray=true
							   } else {
								   isArray=false
							   }
							   if(isArray)
							   {
								   var parentPropItems=mainObj[parentProp]
								   nlapiLogExecution('debug', 'line parentPropItemsmain:', parentPropItems.length);
								   var isNewLine = false;
								   for(var i=0;i<parentPropItems.length;i++)
								   {
									   //if(isNewRecord)
									   var hasRevenueElementLink = 'F';
									   if(i+1<=nsOrderCounts)
									   {
										   hasRevenueElementLink = nsOrderRecord.getLineItemValue('item', 'attachedtorevenueelement', i+1)
										   if (hasRevenueElementLink != 'T') hasRevenueElementLink = 'F';
									
										   nsOrderRecord.selectLineItem('item',i+1)
										   //nsOrderRecord.selectNewLineItem('item')
										  // nlapiLogExecution('debug', 'parentPropItems:', 'test');
									   }
									   else
									   {
										   nsOrderRecord.selectNewLineItem('item')
										   //nsOrderRecord.selectLineItem('item',i+1)
										   isNewLine = true;
									   }

									   var parentPropItemsProps=parentPropItems[i]
									   for (var parentPropItem in parentPropItemsProps)
									   {
										  // nlapiLogExecution('debug', 'parentPropItemstest:', parentPropItemsProps[parentPropItem]);
										   //var parent458785=parentPropItemsProps[parentPropItem]
			                                    /*if(parentPropItem!='billingschedule')
												{
													  if (hasRevenueElementLink == 'F')
												 {
													     
														 nsOrderRecord.setCurrentLineItemValue('item',parentPropItem,parentPropItemsProps[parentPropItem])
			
												 }
												 else{
													if(parentPropItem!='item' && parentPropItem != 'custcolappf_so_line_startdate')
													  nsOrderRecord.setCurrentLineItemValue('item',parentPropItem,parentPropItemsProps[parentPropItem])
			
												 }
			                                     
			                 } */
										   if (parentPropItem != 'billingschedule') {
											   if (!(parentPropItem == 'item' && !isNewLine)) {
												   if (hasRevenueElementLink == 'F') {
													   nsOrderRecord.setCurrentLineItemValue('item', parentPropItem, parentPropItemsProps[parentPropItem])
													   nlapiLogExecution('debug','set parentPropItem 1',parentPropItem + ':'+parentPropItemsProps[parentPropItem]);
												   } else {
													   if (parentPropItem != 'item' && parentPropItem != 'custcolappf_so_line_startdate'){
														   
														   nsOrderRecord.setCurrentLineItemValue('item', parentPropItem, parentPropItemsProps[parentPropItem]);
														   nlapiLogExecution('debug','set parentPropItem 2',parentPropItem + ':'+parentPropItemsProps[parentPropItem]);
													   }
													   
												   }
											   }
										   }
										   if(parentPropItem=='billingschedule'){
											   nlapiLogExecution('debug','billing schedule',parentPropItemsProps[parentPropItem]);
											   nsOrderRecord.setCurrentLineItemText('item',parentPropItem,parentPropItemsProps[parentPropItem])
										   }
											   
									   }
									   nsOrderRecord.commitLineItem('item')
								   }
								
							   }
                           }
					   }
					   
					   try{
						   nsOrderRecordID = nlapiSubmitRecord(nsOrderRecord,true,true);
	                         nlapiLogExecution('debug','nsOrderRecordID successfully saved',nsOrderRecordID);
						   
					   }catch(errorsaveSO){
						   nlapiLogExecution('debug','nsOrderRecordID failed saved',errorsaveSO.toString());
					   }
					  
				   }
				   else
				   {
					   if(nsCreationMsg==null || nsCreationMsg=='')
					   {
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
						   scriptStatus='WARNING'
					   }
				   }
			   }
			   catch(e1)
			   {
				   scriptStatus='FAILED'
				   if ( e1 instanceof nlobjError ) nsCreationMsg = e1.getDetails();
				   else nsCreationMsg = e1.toString();
				}        
                nlapiLogExecution('debug','scriptStatus',scriptStatus+ ' nsCreationMsg='+nsCreationMsg);
				if (nsOrderRecordID != null)
				{
					var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') isInActiveRecord=true
					}
					if(!isInActiveRecord) nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS,CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsOrderRecordID, 'SUCCESS']);
				}					   
				else
				{
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus+":"+nsCreationMsg]); 						   
				}							
				if(nsOrderRecordID!=null && nsOrderRecordID!='')
				{
					idForResponse=nsOrderRecordID;
					nlapiLogExecution('debug','responseData.getCode()',responseData.getCode());
                    scriptStatus='SUCCESS'
                        // integrationResponseObj.internalId=recordId  		
                    var mcode = 200;
					if (mcode == '200' || mcode == '201'/*responseData.getCode() == '200' || responseData.getCode() == '201'*/) nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					else nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
					
				}
		   }
		}
		if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
		{			
			if(pareConnex==null || pareConnex=='') pareConnex=''			   
			integrationResponseObj.EntityId=pareConnex
			
			if(idForResponse==null || idForResponse=='') idForResponse=''
			integrationResponseObj.NetSuiteId=idForResponse
          
			if(Status1!=null && Status1!='') integrationResponseObj.IntegrationResponseStatus=Status1
			else integrationResponseObj.IntegrationResponseStatus=scriptStatus
		 
			if(nsCreationMsg==null || nsCreationMsg=='') nsCreationMsg=''
			integrationResponseObj.IntegrationResponseMessage=nsCreationMsg
			
			nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_RESP], [JSON.stringify(integrationResponseObj)]);	
	
			var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
			var body = JSON.stringify(integrationResponseObj);
			var HEADERS = {"Authorization":signatures};
			//HEADERS.scriptStatus=scriptStatus
			if(CorrelationId==null || CorrelationId=='') CorrelationId=''
			HEADERS['NServiceBus.CorrelationId']=CorrelationId
			HEADERS['NServiceBus.EnclosedMessageTypes']=NS_CLIENT
			var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

		}
		if(context.getRemainingUsage()<=1000)
		{
			nlapiScheduleScript(SPARAM_CONNEX_CLIENT,null)
			break; 
		}		   
}
      }
  }