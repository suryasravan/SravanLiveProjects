/*
 * Script Name : Appf-Sync VB/VC from Interim UE
 * Script Type : UserEvent
 * Event Type  : After Submit
 * Description : This script syncs the fields from Interim Header and Interim Child records to the header and line fields of VB or VC
 * Company     :	Appficiency Inc.
 * Version		Date			Author			Description
 * 1.2			10/12/2020		MJ De Asis		Sync Alternate Vendor Field
 * 1.3			10/21/2020		MJ De Asis		Sync Alternate Vendor Field to GST and PST
 * 1.4			10/21/2020		MJ De Asis		Sync VB Header Vendor / Alt Vendor to Child Invoice when added from sublist
 * 1.5			10/21/2020		MJ De Asis		Sync VB Header Vendor Payment Type to Child Invoice and GST and PST Transactions
 * 1.6			11/25/2020		MJ De Asis		Added Checker for Vendor Bills with rate greater than 1
 */
var SCRIPT_SYNC_PT_PTA_GENERIC_SL = 'customscript_appf_generic_sl_4';
var DEPLOY_SYNC_PT_PTA_GENERIC_SL = 'customdeploy_appf_generic_sl_4';
var SPARAM_INTERM_RECS_SS_CHILD = 'custscript_appf_eligible_vb_interim_res';
var CUSTOM_RECORD_INTERIM_CHILD = 'customrecord_appf_interim_vb_line'
var FLD_IV_VB_LINKS = 'custrecord_appf_ivbl_vblink'
var CUSTOM_RECORD_INTERIM = 'customrecord_appf_interim_vb'
var SPARAM_VB_FIELDS = 'custscript_vb_header_fields_sync';
var SPARAM_VB_LINE_FIELDS = 'custscript_vb_line_fields_sync';
var FLD_IV_VC_LINKS = 'custrecord_appf_ivbl_vclink'
var SPARAM_VC_FIELDS = 'custscript_vc_header_fields_sync';
var SPARAM_VC_LINE_FIELDS = 'custscript_vc_line_fields_sync';
var FLD_IV_VC_NET = 'custrecord_appf_ivbl_vendor_net'
var FLD_INTERIM_PARENT_LINK = 'custrecord_appf_interimheader';
var SUBLIST_INTERIM_CHILD = 'recmachcustrecord_appf_interimheader'
var FLD_IV_GST_HST = 'custrecord_appf_ivb_gst';
var FLD_IV_PST_QST = 'custrecord_appf_ivb_qst';
var FLD_IV_GST_HST_VB_LINK = 'custrecord_appf_ivb_gst_hst_vb';
var FLD_IV_PST_QST_VB_LINK = 'custrecord_ivb_pst_qst_vb';
var FLD_IV_SYNC_TO_TRANS_STATUS = 'custrecord_appf_sync_tran_status';
var SPARAM_INTERM_REC_TYPE = 'custscript_appf_interim_rec_type';
var SPARAM_INTERM_REC_ID = 'custscript_appf_interim_rec_id';
var SPARAM_INTERM_INDEX = 'custscript_appf_interim_lindex';
var FLD_CR_NET_AMTS = 'custrecord_appf_ivbl_vendor_net';
var FLD_CR_PO_INTERNALID = 'custrecord_appf_ivbl_po_link';
var FLD_CR_INV_TRNS = 'custrecord_appf_ivb_transid';
var FLD_CR_IV_ON_BASED_ID = 'custrecord_appf_ivb_onbasedocid';
var FLD_CR_IV_DATE = 'custrecord_appf_ivb_date';
var FLD_CR_IV_DESCRIPTIONS = 'custrecord_appf_ivbl_description';
var FLD_CR_IV_IO_NUM = 'custrecord_appf_ivbl_io_num';
var FLD_CR_IV_CIRCULATIONS = 'custrecord_appf_ivbl_circulation';
var FLD_CR_IV_UNITS = 'custrecord_appf_ivbl_novus_unit_rt'
var FLD_COL_PRINT_CIRCULATION = 'custcol_appf_print_circulation'
var FLD_COL_RATE = 'custcol_appf_novusunitrate'
var FLD_COL_MASTER = 'custcol_appf_masterlink'
var FLD_COL_LINKS = 'custcol_appf_childlink'
var FLD_COL_IO = 'custcol_appf_ionum'
var FLD_COL_PUBLISH = 'custcol_appf_publisher'
var SCRIPT_SYNC_INTERIM_TO_VBVC = 'customscript_sync_interim_vbvc_sc';

/// v1.2
var FLD_INTERIM_PARENT_ALTVENDOR = 'custrecord_appp_ivb_alternatevendor';
var FLD_INTERIM_PARENT_VENDOR = 'custrecord_appf_ivb_vendor';
var FLD_CR_VENDOR = 'custrecord_appf_ivbl_vendor_name';

/// v1.5
var FLD_INTERIM_PARENT_PAYMENTTYPE = 'custrecord_appf_ivb_payment_type';
var TRANS_FLD_PAYMENTTYPE = 'custbody_appf_vendor_payment_type';

/// v1.4
function beforeSubmit_syncInterimtoVBVC(type) {
	var context = nlapiGetContext();
	if (type != 'delete' && context.getExecutionContext() != 'scheduled') {
		var recordType = nlapiGetRecordType();

		if (recordType == CUSTOM_RECORD_INTERIM) {
			var vendor = nlapiGetFieldValue(FLD_CR_VENDOR);
			var altVendor = nlapiGetFieldValue(FLD_INTERIM_PARENT_ALTVENDOR);
			var altVendor__to_use = (altVendor != null && altVendor != '') ? altVendor : vendor;

			var count = nlapiGetLineItemCount(SUBLIST_INTERIM_CHILD);
			for (var i=1; i<=count; i++) {
				nlapiSelectLineItem(SUBLIST_INTERIM_CHILD, i);
				var childVendor = nlapiGetCurrentLineItemValue(SUBLIST_INTERIM_CHILD, FLD_CR_VENDOR);
				nlapiLogExecution('DEBUG', 'childVendor', childVendor);
				if (childVendor != altVendor__to_use) {
					nlapiSetCurrentLineItemValue(SUBLIST_INTERIM_CHILD, FLD_CR_VENDOR, altVendor__to_use);
					nlapiCommitLineItem(SUBLIST_INTERIM_CHILD);
				}
			}
		}

	}
}

function syncInterimtoVBVC(type) {
    var LOG_TITLE = 'syncInterimtoVBVC';
	if (type != 'delete' && nlapiGetContext().getExecutionContext() != 'scheduled') {
		var recordId = nlapiGetRecordId();
		var recordType = nlapiGetRecordType();
        nlapiLogExecution('DEBUG', LOG_TITLE, 'recordType = ' + recordType + ', recordId = ' + recordId);
        
		var context = nlapiGetContext()
		if (nlapiGetRecordType() == CUSTOM_RECORD_INTERIM_CHILD) {
			var scriptParamVBHeaderFields = context.getSetting('SCRIPT', SPARAM_VB_FIELDS)
			var scriptParamVBLineFields = context.getSetting('SCRIPT', SPARAM_VB_LINE_FIELDS)
			var scriptParamVCHeaderFields = context.getSetting('SCRIPT', SPARAM_VC_FIELDS)
			var scriptParamVCLineFields = context.getSetting('SCRIPT', SPARAM_VC_LINE_FIELDS)
			var interimLine = nlapiLoadRecord(CUSTOM_RECORD_INTERIM_CHILD, recordId);
			var interimParentLink = interimLine.getFieldValue(FLD_INTERIM_PARENT_LINK);
			var pymtType = '';

            /// v1.2
            var altVendor = null;

			if (interimParentLink != null && interimParentLink != '') {
				var interimParentLinkRec = nlapiLoadRecord(CUSTOM_RECORD_INTERIM, interimParentLink);
				var lineCount = interimParentLinkRec.getLineItemCount(SUBLIST_INTERIM_CHILD);
				pymtType = interimParentLinkRec.getFieldValue('custrecord_appf_ivb_payment_type');
				var totalAmount = 0;
				for (var k = 1; k <= lineCount; k++) {
					var amtLine = interimParentLinkRec.getLineItemValue(SUBLIST_INTERIM_CHILD, FLD_CR_NET_AMTS, k);
					if (amtLine == null || amtLine == '') amtLine = 0;
					totalAmount = parseFloat(totalAmount) + parseFloat(amtLine);
				}
				interimParentLinkRec.setFieldValue('custrecord_appf_ivb_amount', totalAmount);

                /// v1.2
                altVendor = interimParentLinkRec.getFieldValue(FLD_INTERIM_PARENT_ALTVENDOR);

				nlapiSubmitRecord(interimParentLinkRec, true, true);
			}
			var poLineNo = interimLine.getFieldValue('custrecord_appf_ivbl_po_line_id');
			var poID = interimLine.getFieldValue('custrecord_appf_ivbl_po_link');
			var vblink = interimLine.getFieldValue(FLD_IV_VB_LINKS)
			var vclink = interimLine.getFieldValue(FLD_IV_VC_LINKS)
			var poLineAmounts = interimLine.getFieldValue(FLD_CR_NET_AMTS);
			if (poLineAmounts == null || poLineAmounts == '') poLineAmounts = 0;
			var podescription = interimLine.getFieldValue(FLD_CR_IV_DESCRIPTIONS)
			var ioNum = interimLine.getFieldValue(FLD_CR_IV_IO_NUM)
			var poCurculatns = interimLine.getFieldValue(FLD_CR_IV_CIRCULATIONS)
			var poUnit = interimLine.getFieldValue(FLD_CR_IV_UNITS)
			if (vblink != null && vblink != '') {
				var vendorBillRecord = nlapiLoadRecord('vendorbill', vblink)
				vendorBillRecord.setFieldValue('custbody_appf_vendor_payment_type', pymtType)
				vendorBillRecord.selectLineItem('item', 1);
				vendorBillRecord.setCurrentLineItemValue('item', 'quantity', poLineAmounts);
				vendorBillRecord.setCurrentLineItemValue('item', 'rate', 1);
				vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
				vendorBillRecord.setCurrentLineItemValue('item', 'description', podescription);
				vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
				vendorBillRecord.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);

                /// v1.2
                if (altVendor != null && altVendor != '') {
                    vendorBillRecord.setFieldValue('entity', altVendor);
                }

				if (scriptParamVBLineFields != null && scriptParamVBLineFields != '') {
					var vbLineFieldList = scriptParamVBLineFields.split(',');
					for (var vl = 0; vl < vbLineFieldList.length; vl++) {
						var interimLineFieldID = vbLineFieldList[vl].split('|')[0];
						var vbLineFieldID = vbLineFieldList[vl].split('|')[1];
						var interimLineFieldValue = interimLine.getFieldValue(interimLineFieldID);
						vendorBillRecord.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
					}
				}
				vendorBillRecord.commitLineItem('item');
				nlapiSubmitRecord(vendorBillRecord);
				var slURL = nlapiResolveURL('SUITELET', SCRIPT_SYNC_PT_PTA_GENERIC_SL, DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external');
				slURL += '&genetricrecid=' + vblink + '&genetricrectype=vendorbill&isbackend=T';
				nlapiLogExecution('debug', 'slURL', slURL)
				try {
					nlapiRequestURL(slURL);
				} catch (e) {
					try {
						nlapiRequestURL(slURL);
					} catch (ex) {
						try {
							nlapiRequestURL(slURL);
						} catch (ep) {
							nlapiLogExecution('debug', 'error triggering Generic SL', ep);
						}
					}
				}
			}
			if (vclink != null && vclink != '') {
				var vendorCreditRecord = nlapiLoadRecord('vendorcredit', vclink)
				vendorCreditRecord.setFieldValue('custbody_appf_vendor_payment_type', pymtType)
				var poRec = nlapiLoadRecord('purchaseorder', poID)
				var poLineNum = poRec.findLineItemValue('item', 'custcol_appf_po_line_id', poLineNo)
				var poItem = poRec.getLineItemValue('item', 'item', poLineNum)
				var poStrat = poRec.getLineItemValue('item', 'custcolappf_so_line_startdate', poLineNum)
				var poendDat = poRec.getLineItemValue('item', 'custcol_appf_so_line_enddate', poLineNum)
				var poPublishs = poRec.getLineItemValue('item', FLD_COL_PUBLISH, poLineNum)
				var pocust = poRec.getLineItemValue('item', 'customer', poLineNum)
				vendorCreditRecord.selectLineItem('item', 1);
				vendorCreditRecord.setCurrentLineItemValue('item', 'quantity', Math.abs(poLineAmounts));
				vendorCreditRecord.setCurrentLineItemValue('item', 'rate', 1);
				vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_IO, ioNum);
				vendorCreditRecord.setCurrentLineItemValue('item', 'description', podescription);
				vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
				vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
				vendorCreditRecord.setCurrentLineItemValue('item', FLD_COL_PUBLISH, poPublishs);
				vendorCreditRecord.setCurrentLineItemValue('item', 'custcolappf_so_line_startdate', poStrat);
				vendorCreditRecord.setCurrentLineItemValue('item', 'custcol_appf_so_line_enddate', poendDat);
				if (pocust != null && pocust != '' && vendorCreditRecord.getCurrentLineItemValue('item', 'customer') != pocust) vendorCreditRecord.setCurrentLineItemValue('item', 'customer', pocust);
				if (scriptParamVCLineFields != null && scriptParamVCLineFields != '') {
					var vcLineFieldList = scriptParamVCLineFields.split(',');
					for (var vl = 0; vl < vcLineFieldList.length; vl++) {
						var interimLineFieldID = vcLineFieldList[vl].split('|')[0];
						var vbLineFieldID = vcLineFieldList[vl].split('|')[1];
						var interimLineFieldValue = interimLine.getFieldValue(interimLineFieldID);
						nlapiLogExecution('debug', 'interimLineFieldValue', interimLineFieldValue)
						nlapiLogExecution('debug', 'vbLineFieldID', vbLineFieldID)
						if (interimLineFieldID == FLD_IV_VC_NET) {
							interimLineFieldValue = (-1) * interimLineFieldValue
							nlapiLogExecution('debug', 'interimLineFieldValue', interimLineFieldValue)
						}
						vendorCreditRecord.setCurrentLineItemValue('item', vbLineFieldID, interimLineFieldValue);
					}
				}
				vendorCreditRecord.commitLineItem('item');

                /// v1.2
                if (altVendor != null && altVendor != '') {
                    vendorCreditRecord.setFieldValue('entity', altVendor);
                }

				nlapiSubmitRecord(vendorCreditRecord);
				var slURL = nlapiResolveURL('SUITELET', SCRIPT_SYNC_PT_PTA_GENERIC_SL, DEPLOY_SYNC_PT_PTA_GENERIC_SL, 'external');
				slURL += '&genetricrecid=' + vclink + '&genetricrectype=vendorcredit&isbackend=T';
				nlapiLogExecution('debug', 'slURL', slURL)
				try {
					nlapiRequestURL(slURL);
				} catch (e) {
					try {
						nlapiRequestURL(slURL);
					} catch (ex) {
						try {
							nlapiRequestURL(slURL);
						} catch (ep) {
							nlapiLogExecution('debug', 'error triggering Generic SL', ep);
						}
					}
				}
			}

            /// v1.2
            var vendor = interimLine.getFieldValue(FLD_CR_VENDOR);
            if (altVendor != null && altVendor != '' && altVendor != vendor) {
                interimLine.setFieldValue(FLD_CR_VENDOR, altVendor);
                nlapiSubmitRecord(interimLine);
            }

            nlapiLogExecution('DEBUG', 'Alt Vendor', altVendor);

		} else {
			var syncTransStatus = nlapiLookupField(recordType, recordId, FLD_IV_SYNC_TO_TRANS_STATUS);
			var params = {};
			params[SPARAM_INTERM_REC_TYPE] = recordType;
			params[SPARAM_INTERM_REC_ID] = recordId;
			if (syncTransStatus != '1') {
				nlapiScheduleScript(SCRIPT_SYNC_INTERIM_TO_VBVC, null, params);
				nlapiSubmitField(recordType, recordId, FLD_IV_SYNC_TO_TRANS_STATUS, '1');
			}
		}

        /// v1.2
        if (nlapiGetRecordType() == CUSTOM_RECORD_INTERIM) {
            var old_instance = nlapiGetOldRecord();
            var new_instance = nlapiGetNewRecord();
            if (old_instance && new_instance) {
                var old_altVendor = old_instance.getFieldValue(FLD_INTERIM_PARENT_ALTVENDOR);
                var new_altVendor = new_instance.getFieldValue(FLD_INTERIM_PARENT_ALTVENDOR);
                var altVendor__to_use = new_altVendor;
                if (old_altVendor != new_altVendor) {
                    nlapiLogExecution('DEBUG', LOG_TITLE, 'Vendor has changed...');
                    if (altVendor__to_use == null || altVendor__to_use == '') {
                        altVendor__to_use = new_instance.getFieldValue(FLD_INTERIM_PARENT_VENDOR);
                    }
                    nlapiLogExecution('DEBUG', LOG_TITLE, 'altVendor__to_use = ' + altVendor__to_use);

                    if (altVendor__to_use != null && altVendor__to_use != '') {
                        var children = getInterimChildren(nlapiGetRecordId());
                        nlapiLogExecution('DEBUG', LOG_TITLE, 'Interim children = ' + children.length);
                        for (var i=0; i<children.length; i++) {
                            nlapiSubmitField(CUSTOM_RECORD_INTERIM_CHILD, children[i].id, FLD_CR_VENDOR, altVendor__to_use);
                            if (children[i].vendor_bill != null && children[i].vendor_bill != '') {
                                nlapiSubmitField('vendorbill', children[i].vendor_bill, 'entity', altVendor__to_use);
                                nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated vendor bill id = ' + children[i].vendor_bill + ' with entity = ' + altVendor__to_use);
                            }
                            if (children[i].vendor_credit != null && children[i].vendor_credit != '') {
                                nlapiSubmitField('vendorcredit', children[i].vendor_credit, 'entity', altVendor__to_use);
                                nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated vendor credit id = ' + children[i].vendor_credit + ' with entity = ' + altVendor__to_use);
                            }
                            // nlapiLogExecution('DEBUG', 'Updated Novus Child Invoice ', children[i]);
                        }

						/// v1.3
						var gst_transaction = new_instance.getFieldValue(FLD_IV_GST_HST_VB_LINK);
						var pst_transaction = new_instance.getFieldValue(FLD_IV_PST_QST_VB_LINK);
						if (gst_transaction != null && gst_transaction != '') {
							var gst_transaction__rectype = nlapiLookupField('transaction', gst_transaction, 'recordtype');
							nlapiSubmitField(gst_transaction__rectype, gst_transaction, 'entity', altVendor__to_use);
                            nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated ' + gst_transaction__rectype + ' id = ' + gst_transaction + ' with entity = ' + altVendor__to_use);
						}

						if (pst_transaction != null && pst_transaction != '') {
							var pst_transaction__rectype = nlapiLookupField('transaction', pst_transaction, 'recordtype');
							nlapiSubmitField(pst_transaction__rectype, pst_transaction, 'entity', altVendor__to_use);
                            nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated ' + pst_transaction__rectype + ' id = ' + pst_transaction + ' with entity = ' + altVendor__to_use);
						}
                    }
                }

				/// v1.5
				var old_paymentType = old_instance.getFieldValue(FLD_INTERIM_PARENT_PAYMENTTYPE);
				var new_paymentType = new_instance.getFieldValue(FLD_INTERIM_PARENT_PAYMENTTYPE);
				if (new_paymentType != old_paymentType) {
					var children = getInterimChildren(nlapiGetRecordId());
					for (var i=0; i<children.length; i++) {
						if (children[i].vendor_bill != null && children[i].vendor_bill != '') {
							nlapiSubmitField('vendorbill', children[i].vendor_bill, TRANS_FLD_PAYMENTTYPE, new_paymentType);
                            nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated vendorbill id = ' + children[i].vendor_bill + ' with entity = ' + new_paymentType);
						}
						if (children[i].vendor_credit != null && children[i].vendor_credit != '') {
							nlapiSubmitField('vendorcredit', children[i].vendor_credit, TRANS_FLD_PAYMENTTYPE, new_paymentType);
                            nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated vendorcredit id = ' + children[i].vendor_credit + ' with entity = ' + new_paymentType);
						}
						// nlapiLogExecution('DEBUG', 'Updated Novus Child Invoice ', children[i]);
					}
					var gst_transaction = new_instance.getFieldValue(FLD_IV_GST_HST_VB_LINK);
					var pst_transaction = new_instance.getFieldValue(FLD_IV_PST_QST_VB_LINK);
					if (gst_transaction != null && gst_transaction != '') {
						var gst_transaction__rectype = nlapiLookupField('transaction', gst_transaction, 'recordtype');
						nlapiSubmitField(gst_transaction__rectype, gst_transaction, TRANS_FLD_PAYMENTTYPE, new_paymentType);
                        nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated ' + gst_transaction__rectype + ' id = ' + gst_transaction + ' with ' + TRANS_FLD_PAYMENTTYPE + ' = ' + new_paymentType);
					}

					if (pst_transaction != null && pst_transaction != '') {
						var pst_transaction__rectype = nlapiLookupField('transaction', pst_transaction, 'recordtype');
						nlapiSubmitField(pst_transaction__rectype, pst_transaction, TRANS_FLD_PAYMENTTYPE, new_paymentType);
                        nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated ' + pst_transaction__rectype + ' id = ' + pst_transaction + ' with ' + TRANS_FLD_PAYMENTTYPE + ' = ' + new_paymentType);
					}
				}

            }

			/// v1.6
			var children = getInterimChildrenWithWrongRate(nlapiGetRecordId());
            nlapiLogExecution('DEBUG', LOG_TITLE, 'getInterimChildrenWithWrongRate = ' + children.length);
			for (var i=0; i<children.length; i++) {
				var vendorbill_id = children[i].getId();
				var vendorbill_rec = nlapiLoadRecord('vendorbill', vendorbill_id, {recordmode: 'dynamic'});
				var count = vendorbill_rec.getLineItemCount('item');
				for (var j=1; j<=count; j++) {
					vendorbill_rec.selectLineItem('item', j);
					vendorbill_rec.setCurrentLineItemValue('item', 'rate', 1);
					vendorbill_rec.commitLineItem('item');
				}
				if (nlapiSubmitRecord(vendorbill_rec)) {
					nlapiLogExecution('DEBUG', LOG_TITLE, 'Updated VB with wrong rate; id = ' + vendorbill_id);
				}
			}

        }
	}
}

/// v1.2
function getInterimChildren(parent_id) {
    var children = [];
    if (parent_id != null && parent_id != '') {
        var rs = nlapiSearchRecord(CUSTOM_RECORD_INTERIM_CHILD, null,
                [
                    new nlobjSearchFilter(FLD_INTERIM_PARENT_LINK, null, 'is', parent_id),
                    new nlobjSearchFilter('isinactive', null, 'is', 'F')
                ],
                [
                    new nlobjSearchColumn(FLD_IV_VB_LINKS),
                    new nlobjSearchColumn(FLD_IV_VC_LINKS)
                ]) || [];
        for (var i=0; i<rs.length; i++) {
            children.push({
                id: rs[i].getId(),
                vendor_bill: rs[i].getValue(FLD_IV_VB_LINKS),
                vendor_credit: rs[i].getValue(FLD_IV_VC_LINKS)
            });
        }
    }
    return children;
}

/// v1.6
function getInterimChildrenWithWrongRate(parent_id) {
	var children = [];
	if (parent_id != null && parent_id != '') {
		var rs = nlapiSearchRecord('vendorbill', null,
					[
						new nlobjSearchFilter('mainline', null, 'is', 'F'),
						new nlobjSearchFilter('rate', null, 'greaterthan', 1),
						new nlobjSearchFilter('custcol_appf_masterlink', null, 'is', parent_id)
					], []) || [];
		for (var i=0; i<rs.length; i++) {
			children.push(rs[i].getId());
		}
	}
	return children;
}
