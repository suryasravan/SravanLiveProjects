	/**
	 * Script Name : Appf-VVCCP Suitelet Script
	 * Script Type : Suitelet
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script displays VVCCP Suitelet based on SS results of Vendor Bills and Vendor Credits and creates a VVCCP Batch Record		 *
	 *
	 * Company 	 : Appficiency. 
	 */
	var FLD_SL_ACTION='custpage_action';

	var CUSTOM_RECORD_VIRTUAL_CREDIT_CARD=''; 
	//Virtual Credit Card

		var FLD_CARD                ='custrecord_appf_vvccp_card_number';
		var FLD_SECURITY_CODE   	='custrecord_appf_vvccp_card_code'	
		var FLD_EXPIRATION_DATE     ='custrecord_appf_vvccp_card_exp_date';
		var FLD_PROVIDER	        ='custrecord_appf_vvccp_card_provider';
		var FLD_VENDOR_PAYMENT_LINK	='custrecord_appf_vvccp_ven_pmt_link';
		var FLD_VVCCP_LINK	        ='custrecord_appf_vvccp_card_vvccp_link';	
		var FLD_CANCELLED	        ='custrecord_appf_vvccp_card_cancelled';	
		var FLD_PAYMENT_CONTRA_ENTRY='custrecord_appf_vvccp_card_contra_je_2';
		var FLD_VOID_JOURNAL	    ='custrecord_appf_vvccp_payment_void';	
		var FLD_AUTHORIZATION_DATE	='custrecord_appf_vvccp_authorization_date';
		
		var CUSTOM_RECORD_VVCCP='customrecord_appf_vvccp_record';
		//VVCCP

		var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
		var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
		var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
		var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link	';
		var FLD_STATUS	                	='custrecord_appf_vvccp_status';
		var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
		var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
		var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
		var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
		var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
		var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
		var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
		var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
		var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
		
		var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';
		var FLD_APPROVAL_STATUS_APPROVED=2;
		var FLD_APPROVAL_STATUS_OPEN=11;
		var FLD_APPROVAL_STATUS_PENDING_APPROVAL=1;
		var FLD_APPROVAL_STATUS_REJECTED=3;
		
		var FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS=3;
		var FLD_VVCCP_PROCESSING_STATUS_UNDER_PROCESSING_FOR_TRANSACTIONS=1
		var FLD_VVCCP_PROCESSING_STATUS_PROCESSED_FOR_TRANSACTIONS=2
		
		var STATUS_FOR_VVCCP_STATUS_IN_PROGRESS=2
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_SUCCESSFULLY=4
		var STATUS_FOR_VVCCP_STATUS_COMPLETED_WITH_ERRORS=5
		
		var VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID=1106;
		//VVCCP Execution Batch
		var FLD_TOTAL_VENDOR_BILL_TO_PROCESS     	='custrecord_appf_vvccp_log_total_bills_2';	
		var FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS     ='custrecord_appf_vvccp_log_total_cred_2';
		var FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS     	='custrecord_appf_vvccp_to_process';
		var FLD_TOTAL_VVCCP_RECORDS_PROCESSED     	='custrecord_appf_vvccp_processd';
		var FLD_PROCESSED_PERCENT	     			='custrecord_appf_vvccp_log_percent_2';
		var FLD_CREATED_BY	     					='custrecord_appf_vvccp_log_created_by_2';
		var FLD_STATUS	     						='custrecord_appf_vvccp_log_status';
		var FLD_DATA_FILE	     					='custrecord_appf_vvccp_log_data_file_2';
		var FLD_STATUS_FILE	     					='custrecord_appf_vvccp_log_error_file_2';
		var FLD_ERROR_LOG	     					='custrecord_appf_vvccp_log_error_log_2';
		var FLD_VVCCP_RECORD_LINK	     			='custrecord_appf_vvccp_log_vvccp_link_2';
		var FLD_VENDOR_BILL_LINKS	     			='custrecord_appf_vvccp_vendor_bills';
		var FLD_VENDOR_CREDIT_LINKS	     			='custrecord_appf_vvccp_vendor_credits';
		var FLD_APPROVAL_STATUS	     				='custrecord_appf_vvccp_batch_approval';
		var FLD_BILL_DATA_FILES						='custrecord_appf_vvccp_bill_data_files';
		var FLD_CREDIT_DATA_FILE					='custrecord_appf_credit_data_file';
		
		var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
		//VVCCP Linked Transactions
		var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
		var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
		var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
		var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
		var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
		var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
		var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
		var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';
		
		var CUSTOM_RECORD_VVCCP_RECON_FILE='';
		//VVCCP Recon File

         var FLD_SL_INTREM_MASTER='custpage_intrems_masters';
		var CUSTOM_RECORD_INTERIM_VB_HEADER = 'customrecord_appf_interim_vb';
		       
		var FLD_VVCCP_RECORD	='custrecord_appf_vvccp_link';
		var FLD_RECON_FILE		='custrecord_appf_vvccp_recon_file';
		var FLD_AMOUNT_CHARGED	='custrecord_appf_vvccp_recon_amount';
		var FLD_CHARGE_DATE		='custrecord_appf_vvccp_recon_charge_date';
		var FLD_TRANSACTION_ID	='custrecord_appf_vvccp_recon_tran_id';

	var SPARAM_VENDOR_BILL_SAVED_SEARCH='custscript_vendor_bill_search';
	var SPARAM_VENDOR_CREDIT_SAVED_SEARCH='custscript_vendor_credit_search';
	var TITLE_VVCCP_SUITELET='VVCCP Suitelet';
	var FLD_GROUP_FILTERS='custpage_filters';
	var SL_FLD_VENDOR='custpage_vendor';
	var SL_FLD_PUBLISHER='custpage_publisher';
	var SL_FLD_MEDIA_SEGMENT='custpage_media_segment';
	var SL_FLD_PROJECT='custpage_project';
	var SL_FLD_DATE_FROM='custpage_date_from';
	var SL_FLD_DATE_TO='custpage_date_to';
	var SL_FLD_DUE_DATE_FROM='custpage_due_date_from';
	var SL_FLD_DUE_DATE_TO='custpage_due_date_to';
	var SL_FLD_PURCHASEORDER='custpage_purchaseorder';
	var SL_FLD_IO='custpage_io';
	var SL_FLD_SUBSIDIARY='custpage_subsidiary';
	var SL_FLD_DISCREPANT='custpage_discrepant';
	var SL_FLD_DISCREPANCY_TYPE='custpage_discrepancy_type';
	var SL_FLD_READY_FOR_PWP='custpage_ready_for_pwp';
	var SL_FLD_TOTAL_VENDOR_BILLS='custpage_total_vendor_bills';
	var SL_FLD_TOTAL_VENDOR_CREDITS='custpage_total_vendor_credits';
	var SL_FLD_TOTAL_VENDOR_AUTHORIZATION='custpage_total_vendor_authorization';
	var BTN_VENDOR_BILL_MARK_ALL='custpage_vendor_bill_mark_all';
	var BTN_VENDOR_BILL_UNMARK_ALL='custpage_vendor_bill_unmark_all'
	var BTN_VENDOR_CREDIT_MARK_ALL='custpage_vendor_credit_mark_all';
	var BTN_VENDOR_CREDIT_UNMARK_ALL='custpage_vendor_credit_unmark_all';
	var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
	var COL_SL_VENDOR_BILL_SUBLIST='custpage_vendor_bills';
	var COL_SL_VENDOR_CREDIT_SUBLIST='custpage_vendor_credit';
	var COL_SL_VENDOR_BILL_MARK='custpage_vendor_bill_checkbox';
	var COL_SL_VENDOR_CREDIT_MARK='custpage_vendor_credit_checkbox';
	var COL_SL_PAYMENT_AMOUNT='custpage_vendor_bil_payment_amount';
	var COL_SL_VENDOR_CREDIT_AMOUNT ='custpage_credit_amount';
	var COL_SL_MEDIA_SEGMENT='custpage_media_segment_line_level';
	var HELPER_CLIEN_SCRIPT_FOR_VALIDATION='customscript_helper_vvccp_suitelet_cl';

	var COL_FLD_MEDIA_SUPPLIER='custcol_appf_publisher';
	var COL_FLD_PURCHASE_ORDER='custcol_appf_po_number';
	var COL_FLD_IO='custcol_appf_ionum';
	var COL_FLD_DISCREPANT='custcol_appf_discrepant';
	var COL_FLD_DISCREPANT_TYPE='custcol_appf_discrepancy_type';
	var COL_FLD_PWP_CUSTOM_RECORD='custcol_appf_pwp_custom_record';
	var CUSTOM_RECORD_PWP='customrecord_appf_pwp_wrapper_record';
	var FLD_READY_FOR_PWP='custrecord_appf_pwp_ready_for_payment'
	var FLD_PROJECT='custrecord_appf_pwp_project';
	
	var VVCCP_POST_FILTER_CLICK_SCRIPT_ID='customscript_vvccp_post_filter_click_ss';
	var SPARAM_BILL_DATA_FILE_FROM_VVCCP_EXECUTION_LOG='custscript_bill_csv_data_files';
	var SPARAM_CREDIT_DATA_FILE_FROM_VVCCP_EXECUTION_LOG='custscript_credit_csv_data_files';
	
	var SCRIPT_VVCCP_SCHEDULED_SCRIPT_1 = 'customscript_appf_vvccp_sch_1';
	var SPARAM_VVCCP_BATCH_REC_ID = 'custscript_vvccp_batch_rec_id';

	
	
	function suitelet(request, response) {
		 
		 var sAction = request.getParameter(FLD_SL_ACTION);
		 //nlapiLogExecution('debug','action',sAction);
			if (!sAction) {
				var frm = suiteletform(request);
				response.writePage(frm);
			}
			else if (sAction == 'submit'){
				var customRecId = processSelectedBillsAndBillCredits(request);
				nlapiLogExecution( 'DEBUG', 'customRecId:',customRecId);
				if(customRecId !=null && customRecId !='')
				response.sendRedirect('RECORD', CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH, customRecId);
			
			}
		
	}

	function suiteletform(request)
	{
		try
	  {
			var params = request.getAllParameters()

		 var vendor = request.getParameter('vendor');
		 var publisher = request.getParameter('publisher');
		 var mediaSegment = request.getParameter('mediaSegment');
		 var project = request.getParameter('project');
		 var dateFrom = request.getParameter('dateFrom');
		 var dateTo = request.getParameter('dateTo');
		 var dueDateFrom = request.getParameter('dueDateFrom');
		 var dueDateTo=request.getParameter('dueDateTo')
		 var purchaseOrder = request.getParameter('purchaseOrder');
		 var io = request.getParameter('io');
		 var subsidiary=request.getParameter('subsidiary');
		  var intremMater=request.getParameter('intremMater');
		 var discrepant=request.getParameter('discrepant');
		 var discrepancyType=request.getParameter('discrepancyType');
		 var readyForPwp=request.getParameter('readyForPwp');
		 var isApplyFilterClicked=request.getParameter('isApplyFilterClicked');
		 var fieldAction=request.getParameter('fieldAction');
		nlapiLogExecution('debug','vendor:',vendor);
		var form=nlapiCreateForm(TITLE_VVCCP_SUITELET);
		form.setScript(HELPER_CLIEN_SCRIPT_FOR_VALIDATION);
		var FiltersGroup = form.addFieldGroup(FLD_GROUP_FILTERS, 'Filters');
		var fldAction = form.addField(FLD_SL_ACTION, 'text', '',null,FLD_GROUP_FILTERS);
		fldAction.setDisplayType('hidden');
		fldAction.setDefaultValue('submit');
		var vendorFld = form.addField(SL_FLD_VENDOR, 'select','Vendor','vendor',FLD_GROUP_FILTERS);
		vendorFld.setDefaultValue(vendor);
		var publisherFld=form.addField(SL_FLD_PUBLISHER, 'select','Publisher/Media Supplier','customrecord_appf_media_supplier',FLD_GROUP_FILTERS);
		publisherFld.setDefaultValue(publisher);
		var mediaSegmentFld = form.addField(SL_FLD_MEDIA_SEGMENT, 'select','Media Segment','customrecord_cseg_appf_media_seg',FLD_GROUP_FILTERS);
		mediaSegmentFld.setDefaultValue(mediaSegment);
		var projectFld=form.addField(SL_FLD_PROJECT, 'select','Project','job',FLD_GROUP_FILTERS);
		projectFld.setDefaultValue(project);
		var subsidiaryFld=form.addField(SL_FLD_SUBSIDIARY, 'select','Subsidiary','subsidiary',FLD_GROUP_FILTERS);
		subsidiaryFld.setDefaultValue(subsidiary);
		var dateFromFld = form.addField(SL_FLD_DATE_FROM, 'date','Date From',null,FLD_GROUP_FILTERS);
		dateFromFld.setDefaultValue(dateFrom);
		var dateToFld = form.addField(SL_FLD_DATE_TO, 'date','Date To',null,FLD_GROUP_FILTERS);
		dateToFld.setDefaultValue(dateTo);
		var dueDateFromFld=form.addField(SL_FLD_DUE_DATE_FROM, 'date','Due Date From',null,FLD_GROUP_FILTERS);
		dueDateFromFld.setDefaultValue(dueDateFrom);
		var dueDateToFld = form.addField(SL_FLD_DUE_DATE_TO, 'date','Due Date To',null,FLD_GROUP_FILTERS);
		dueDateToFld.setDefaultValue(dueDateTo);
		var purchaseOrderFromBillLine=form.addField(SL_FLD_PURCHASEORDER, 'select','Purchase Order #',null,FLD_GROUP_FILTERS);
		purchaseOrderFromBillLine.addSelectOption('','');
		var purchaseOrderSearch=nlapiSearchRecord('transaction',null,[new nlobjSearchFilter('type',null,'anyof','PurchOrd'),new nlobjSearchFilter('mainline',null,'is','T')],[new nlobjSearchColumn('tranid')]);
		if(purchaseOrderSearch !=null && purchaseOrderSearch !='')
		{
			for(var p=0;p<purchaseOrderSearch.length;p++)
			{
				purchaseOrderFromBillLine.addSelectOption(purchaseOrderSearch[p].getId(), purchaseOrderSearch[p].getValue('tranid'), false);
			}
		}
		purchaseOrderFromBillLine.setDefaultValue(purchaseOrder);
		var ioFromBillLine = form.addField(SL_FLD_IO, 'text','IO #',null,FLD_GROUP_FILTERS);
		ioFromBillLine.setDefaultValue(io);
		
		
		var discrepantFld = form.addField(SL_FLD_DISCREPANT, 'select','Discrepant',null,FLD_GROUP_FILTERS);
			//nlapiLogExecution('debug', 'hasDiscrepant', params.hasOwnProperty('discrepant'));

		var hasDiscrepant = false;
		var hasReadyforPWP = false;
		for (var param in params)
		{
			if (param == 'discrepant')
				hasDiscrepant = true;
			if (param == 'readyForPwp')
				hasReadyforPWP = true;
			
		}
		//params.hasOwnProperty('discrepant');
		discrepantFld.addSelectOption('','',(hasDiscrepant)?false:true);
		discrepantFld.addSelectOption('yes','Yes',(hasDiscrepant&&discrepant=='yes')?true:false);
		discrepantFld.addSelectOption('no','No',(hasDiscrepant&&discrepant=='no')?true:false);
		//discrepantFld.setDefaultValue(discrepant);
		var discrepancyTypeFld=form.addField(SL_FLD_DISCREPANCY_TYPE, 'select','Discrepancy Type','customlist_appf_discrepancy_type',FLD_GROUP_FILTERS);
		discrepancyTypeFld.setDefaultValue(discrepancyType);
		//var hasReadyforPWP = params.hasOwnProperty('readyForPwp');

		//nlapiLogExecution('debug', 'ready for pwp', params.hasOwnProperty('readyForPwp'));
		var readyForPWPFld=form.addField(SL_FLD_READY_FOR_PWP, 'select','Ready for PWP (Y/N)',null,FLD_GROUP_FILTERS); 
		readyForPWPFld.addSelectOption('','',(hasReadyforPWP)?false:true);
		readyForPWPFld.addSelectOption('yes','Yes',(hasReadyforPWP && readyForPwp=='yes')?true:false);
		readyForPWPFld.addSelectOption('no','No',(hasReadyforPWP && readyForPwp=='no')?true:false);
		
var intremMater1=form.addField(FLD_SL_INTREM_MASTER,'select','Interim Masters',CUSTOM_RECORD_INTERIM_VB_HEADER,FLD_GROUP_FILTERS).setDefaultValue(intremMater);;
		//readyForPWPFld.setDefaultValue('');
		 //else
		//	readyForPWPFld.setDefaultValue(readyForPwp); 
			var summaryGroup = form.addFieldGroup('custpage_summary_section', 'Summary');

		var totalVendorBills = form.addField(SL_FLD_TOTAL_VENDOR_BILLS, 'currency','Total Vendor Bills',null,'custpage_summary_section').setDisplayType('disabled');;
		var totalVendorCredits = form.addField(SL_FLD_TOTAL_VENDOR_CREDITS, 'currency','Total Credits ',null,'custpage_summary_section').setDisplayType('disabled');;
		var totalVendorAuthorizations = form.addField(SL_FLD_TOTAL_VENDOR_AUTHORIZATION, 'currency','Total Vendor Authorization',null,'custpage_summary_section').setDisplayType('disabled');;

		var context=nlapiGetContext();
		var vendorBillSearchId = context.getSetting('SCRIPT', SPARAM_VENDOR_BILL_SAVED_SEARCH);
		var vendorCreditSearchId = context.getSetting('SCRIPT', SPARAM_VENDOR_CREDIT_SAVED_SEARCH);
	 
		var vendorBillSearch=nlapiLoadSearch(null, vendorBillSearchId);
		var vendorBillFilts = vendorBillSearch.getFilters();
		var vendorBillColumns=vendorBillSearch.getColumns();
		var vendorBillSSType = vendorBillSearch.getSearchType();
			
		var vendorCreditSearch=nlapiLoadSearch(null, vendorCreditSearchId);
		var vendorCreditFilts = vendorCreditSearch.getFilters();
		var vendorCreditColumns=vendorCreditSearch.getColumns();
		var vendorCreditSSType = vendorCreditSearch.getSearchType();
		nlapiLogExecution('debug','fieldAction:',fieldAction);
		if(fieldAction == 'submit')
		{
		var vendorBillSublist=form.addSubList(COL_SL_VENDOR_BILL_SUBLIST,'list','Vendor Bill');
		vendorBillSublist.addField(COL_SL_VENDOR_BILL_MARK,'checkbox','Select');
		vendorBillSublist.addButton(BTN_VENDOR_BILL_MARK_ALL, 'Mark All', 'vendormarkAll();');
		vendorBillSublist.addButton(BTN_VENDOR_BILL_UNMARK_ALL, 'Unmark All', 'vendorunmarkAll();');
			var colArrvendorBill = [];
			var colIndexvendorBill=1;
			var scriptfieldcountervendorBill = 1;
			for(var c=0;c<vendorBillColumns.length;c++)
			{
				
				var colObj = vendorBillColumns[c];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				//nlapiLogExecution('debug','colName: -colLabel :',colName+':_:'+colLabel)
				if(colArrvendorBill.indexOf(colName) == -1)
				{
					colArrvendorBill.push(colName)
				}
				else
				{
					colName=colName+colIndexvendorBill;
					colIndexvendorBill++;
				}	
				if (colLabel != 'Script Use DNR')
				{
					if (colName != 'line.cseg_appf_media_seg')
                      {
                        
                          vendorBillSublist.addField('custpage_'+colName, 'text', colLabel);	
                      if(colName == 'currency')
                        vendorBillSublist.addField('custpage_currency_id', 'text', colLabel).setDisplayType('hidden');
                        
                      }
					

				}
				else
				{
					var typeofscriptfield = 'text';
					
					if(scriptfieldcountervendorBill == 9)
					vendorBillSublist.addField(COL_SL_MEDIA_SEGMENT, 'text', colLabel);
					
					if (scriptfieldcountervendorBill == 1)
					typeofscriptfield='currency';
					var scriptField =vendorBillSublist.addField('custpage_scriptfield'+scriptfieldcountervendorBill, typeofscriptfield, colLabel);
					scriptField.setDisplayType('hidden');
					scriptfieldcountervendorBill++;
				}         	
			}
			vendorBillSublist.addField(COL_SL_PAYMENT_AMOUNT, 'currency', 'Payment Amount').setDisplayType('entry');
			vendorBillSublist.addField(COL_SL_PAYMENT_AMOUNT+'_native', 'currency', 'Payment Amount Hidden').setDisplayType('hidden');

			var vendorCreditSublist=form.addSubList(COL_SL_VENDOR_CREDIT_SUBLIST,'list','Vendor Credit');
			vendorCreditSublist.addField(COL_SL_VENDOR_CREDIT_MARK,'checkbox','Select');
			vendorCreditSublist.addButton(BTN_VENDOR_CREDIT_MARK_ALL, 'Mark All', 'vendorcreditmarkAll();')
			vendorCreditSublist.addButton(BTN_VENDOR_CREDIT_UNMARK_ALL, 'Unmark All', 'vendorcreditunmarkAll();')
			
			var colArrvendorCredit = [];
			var colIndexvendorCredit=1;
			var scriptfieldcountervendorCredit = 1;
			for(var c=0;c<vendorCreditColumns.length;c++)
			{
				var colObj = vendorCreditColumns[c];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				if(colArrvendorCredit.indexOf(colName) == -1)
				{
					colArrvendorCredit.push(colName)
				}
				else
				{
					colName=colName+colIndexvendorCredit;
					colIndexvendorCredit++;
				}	
				if (colLabel != 'Script Use DNR')
				{
					
					vendorCreditSublist.addField('custpage_'+colName, 'text', colLabel);
					if(colName == 'currency')
                        vendorCreditSublist.addField('custpage_currency_id', 'text', colLabel).setDisplayType('hidden');
				}
				else
				{
					var typeofscriptfield = 'text';
					if (scriptfieldcountervendorCredit == 1)
					typeofscriptfield='currency';
				
					var scriptField =vendorCreditSublist.addField('custpage_scriptfield'+scriptfieldcountervendorCredit, typeofscriptfield, colLabel);
					scriptField.setDisplayType('hidden');
					scriptfieldcountervendorCredit++;
				}         	
			}
				vendorCreditSublist.addField(COL_SL_VENDOR_CREDIT_AMOUNT, 'currency', 'Credit Amount').setDisplayType('entry');
				vendorCreditSublist.addField(COL_SL_VENDOR_CREDIT_AMOUNT+'_native', 'currency', 'Vendor Credit Amount Hidden').setDisplayType('hidden');
				
				
				var vendorBillFilters =[];
				
				if(vendor !=null && vendor !='')
				vendorBillFilters.push(new nlobjSearchFilter('entity', null ,'anyof',vendor));
				
				if(publisher !=null && publisher !='') 
				vendorBillFilters.push(new nlobjSearchFilter(COL_FLD_MEDIA_SUPPLIER,null,'anyof',publisher));
				if(mediaSegment !=null && mediaSegment !='')
				vendorBillFilters.push(new nlobjSearchFilter('line.cseg_appf_media_seg',null,'anyof',mediaSegment));
				if(project !=null && project !='')
				vendorBillFilters.push(new nlobjSearchFilter(FLD_PROJECT,COL_FLD_PWP_CUSTOM_RECORD,'anyof',project));
				if(dateFrom !=null && dateFrom !='' && dateTo !=null && dateTo !='')
				vendorBillFilters.push(new nlobjSearchFilter('trandate',null,'between',[dateFrom,dateTo]));
				if(dueDateFrom !=null && dueDateFrom !='' && dueDateTo !=null && dueDateTo !='')
				vendorBillFilters.push(new nlobjSearchFilter('duedate',null,'between',[dueDateFrom,dueDateTo]));
				if(purchaseOrder !=null && purchaseOrder !='')
				vendorBillFilters.push(new nlobjSearchFilter(COL_FLD_PURCHASE_ORDER,null,'anyof',purchaseOrder));
				if(io !=null && io !='')
				vendorBillFilters.push(new nlobjSearchFilter(COL_FLD_IO,null,'is',io));
				if(subsidiary !=null && subsidiary !='')
				vendorBillFilters.push(new nlobjSearchFilter('subsidiary',null,'anyof',subsidiary));
			if(intremMater!=null && intremMater!='')
					vendorBillFilters.push(new nlobjSearchFilter('custcol_appf_masterlink',null,'anyof',intremMater));
				if(discrepant !=null && discrepant !='')
				{
					if(discrepant == 'yes')
					discrepant == 'T'
					else
					discrepant == 'F'	
					vendorBillFilters.push(new nlobjSearchFilter(COL_FLD_DISCREPANT,null,'is',discrepant));
				}
				if(discrepancyType !=null && discrepancyType !='')	
				vendorBillFilters.push(new nlobjSearchFilter(COL_FLD_DISCREPANT_TYPE,null,'anyof',discrepancyType));
				/*if(readyForPwp !=null && readyForPwp !='')
				{
					if(readyForPwp == 'yes')
					readyForPwp == 'T'
					else
					readyForPwp == 'F'
					vendorBillFilters.push(new nlobjSearchFilter(FLD_READY_FOR_PWP,CUSTOM_RECORD_PWP,'is',readyForPwp));
				}*/
				nlapiLogExecution('debug','vendorBillFilters:',vendorBillFilters)
				var resultFilters = vendorBillFilters.concat(vendorBillFilts);
				var vendorBillSearchResults=getAllSearchResults(vendorBillSSType, resultFilters, vendorBillColumns);
			//if(vendorBillFilters !=null && vendorBillFilters !='')
			//{			
			if (vendorBillSearchResults != null && vendorBillSearchResults != '') 
				{
					for(var s = 0; s < vendorBillSearchResults.length; s++) {

						var searchresult = vendorBillSearchResults[s];
						var internalid = searchresult.getId();
						var colArrVendorBill = [];
						var colIndexVendorBill = 1;
						var scriptfieldcounterVendorBill = 1;
						for(var c=0;c<vendorBillColumns.length;c++)
						{
							var colObj = vendorBillColumns[c];
							var columnName = colObj.getName();
							var colLabel = colObj.getLabel();
							var ssResultValue = searchresult.getValue(colObj);
							
							if(colArrVendorBill.indexOf(columnName) == -1)
							{
								colArrVendorBill.push(columnName)
							}
							else
							{
								columnName=columnName+colIndexVendorBill;
								colIndexVendorBill++;
							}
							
								if (colLabel != 'Script Use DNR')
								{
                                  if(columnName == 'currency')
                                  vendorBillSublist.setLineItemValue('custpage_currency_id', s+1, ssResultValue);
									if(colObj.getType() == 'select')
							{
							 ssResultValue = searchresult.getText(colObj)
							}	
									if(columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid'){
									var url=nlapiResolveURL('RECORD','vendorbill',internalid);
									var redirect='<a href='+url+' target="_blank">'+ssResultValue+'</a>';
									ssResultValue = redirect;
									}
									//nlapiLogExecution('debug','ssResultValue:',ssResultValue);
									if(colLabel == 'Bill Amount Due' || colLabel == 'Payment Amount')
									vendorBillSublist.setLineItemValue('custpage_'+columnName, s+1, parseFloat(ssResultValue).toFixed(2));
									else
									vendorBillSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
									
								}
								else
								{
									if(scriptfieldcounterVendorBill== 1)
										{
											ssResultValue=parseFloat(ssResultValue).toFixed(2);
											vendorBillSublist.setLineItemValue(COL_SL_PAYMENT_AMOUNT, s+1, (ssResultValue!=null && ssResultValue != '')?parseFloat(ssResultValue):0);
											vendorBillSublist.setLineItemValue(COL_SL_PAYMENT_AMOUNT+'_native', s+1, (ssResultValue!=null && ssResultValue != '')?parseFloat(ssResultValue):0);
										}
										else if(scriptfieldcounterVendorBill == 3)
										{
											vendorBillSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounterVendorBill, s+1, internalid);
										}
										else if (scriptfieldcounterVendorBill == 9)
										{
											
									vendorBillSublist.setLineItemValue(COL_SL_MEDIA_SEGMENT, s+1, ssResultValue);
									
										}
										else if (scriptfieldcounterVendorBill == 10)
										{
											
									vendorBillSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounterVendorBill, s+1,  searchresult.getText(colObj));
									
										}
										else
										{
									vendorBillSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounterVendorBill, s+1, ssResultValue);
										}
									scriptfieldcounterVendorBill++;
								}		
						}
					}
				}
			
				var vendorCreditFilters =[];
				if(vendor !=null && vendor !='')
				vendorCreditFilters.push(new nlobjSearchFilter('entity', null ,'anyof',vendor));
			if(project !=null && project !='')
				vendorCreditFilters.push(new nlobjSearchFilter(FLD_PROJECT,COL_FLD_PWP_CUSTOM_RECORD,'anyof',project));
				
				if(subsidiary !=null && subsidiary !='')
				vendorCreditFilters.push(new nlobjSearchFilter('subsidiary',null,'anyof',subsidiary));
			if(intremMater!=null && intremMater!='')
					vendorCreditFilters.push(new nlobjSearchFilter('custcol_appf_masterlink',null,'anyof',intremMater));
				var resultFilters = vendorCreditFilters.concat(vendorCreditFilts);
				var vendorCreditSearchResults=getAllSearchResults(vendorCreditSSType, resultFilters, vendorCreditColumns);
			if (vendorCreditSearchResults != null && vendorCreditSearchResults != '') 
				{
					for(var s = 0; s < vendorCreditSearchResults.length; s++) {
						
						var searchresult = vendorCreditSearchResults[s];
						var internalid = searchresult.getId();
						var colArrVendorCredit = [];
						var colIndexVendorCredit = 1;
						var scriptfieldcounterVendorCredit = 1;
						for(var c=0;c<vendorCreditColumns.length;c++){
							var colObj = vendorCreditColumns[c];
							var columnName = colObj.getName();
							var colLabel = colObj.getLabel();
							var ssResultValue = searchresult.getValue(colObj);
								
							if(colArrVendorCredit.indexOf(columnName) == -1)
							{
								colArrVendorCredit.push(columnName)
							}
							else
							{
								columnName=columnName+colIndexVendorCredit;
								colIndexVendorCredit++;
							}
							
								if (colLabel != 'Script Use DNR')
								{
                                  if(columnName == 'currency')
                                  vendorCreditSublist.setLineItemValue('custpage_currency_id', s+1, ssResultValue);
									if(colObj.getType() == 'select')
							{
							 ssResultValue = searchresult.getText(colObj)
							}
									if(columnName == 'transactionnumber' || columnName == 'number' || columnName == 'tranid'){
									var url=nlapiResolveURL('RECORD','vendorcredit',internalid);
									var redirect='<a href='+url+' target="_blank">'+ssResultValue+'</a>';
									ssResultValue = redirect;
								}	
									if(colLabel == 'Amount' || colLabel == 'Credit Amount')
									vendorCreditSublist.setLineItemValue('custpage_'+columnName, s+1, parseFloat(ssResultValue).toFixed(2));
									else
									vendorCreditSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
								}
								else
								{
									
									if(scriptfieldcounterVendorCredit==1)
									{
										ssResultValue=parseFloat(ssResultValue).toFixed(2);
										vendorCreditSublist.setLineItemValue(COL_SL_VENDOR_CREDIT_AMOUNT, s+1, (ssResultValue!=null && ssResultValue != '')?parseFloat(ssResultValue):0);	
										vendorCreditSublist.setLineItemValue(COL_SL_VENDOR_CREDIT_AMOUNT+'_native', s+1, (ssResultValue!=null && ssResultValue != '')?parseFloat(ssResultValue):0);									
									}
									if (scriptfieldcounterVendorBill == 6)
										{
											
									ssResultValue = searchresult.getText(colObj);
									
										}
									
									vendorCreditSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounterVendorCredit, s+1, ssResultValue);
									scriptfieldcounterVendorCredit++;
								}
									
						}
					}
				}
			}
			form.addButton(BTN_SL_APPLY_FILTERS, 'Apply Filters', 'applyFilters();');
			form.addSubmitButton('Submit');
			response.writePage(form);
			return form;
	}
	catch(e)
	{
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
	}




	function processSelectedBillsAndBillCredits(request)
	{
		 var context=nlapiGetContext();
		 var currentUser=context.getUser();
		 var d = new Date();
		 var vendorObj={}
		var timeStamp = d.getTime();
		try
		{
			var ssVendorBillDataFile='';
			var ssVendorCreditDataFile='';
			ssVendorCreditDataFile += 'Vendor Credit Id,Status,Pending Authorization,VVCCP Execution Batch\n';
			ssVendorBillDataFile += 'Vendor Bill Id,Status,Bill Line Id,Line Auth VVCCP,Line Id,VVCCP Execution Batch\n';
			var vendorBilllineCount = request.getLineItemCount(COL_SL_VENDOR_BILL_SUBLIST);
			var vendorCreditLineCount=request.getLineItemCount(COL_SL_VENDOR_CREDIT_SUBLIST);
			var vendorBill=[];
			var vendorCredit=[];
			var totalUniqueVendors=0;
			var mainObj={};
			
			var billObj={};
			var creditObj={};
			for (var i=1; i<=vendorBilllineCount; i++) 
			{
			 if (request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_VENDOR_BILL_MARK, i) == 'T') 
				{
					var vendorBillId=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield3', i);
					if (!billObj.hasOwnProperty(vendorBillId))
					billObj[vendorBillId]=vendorBillId;
					var vendorBillAmount=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
					var vendorBillLineId=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield2', i);
					var vendor=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield4', i);
					var tranCurrency=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield11', i);
					nlapiLogExecution('debug','bill section-tranCurrency:',tranCurrency);
                  if(tranCurrency == null || tranCurrency == '')
                    {
                      tranCurrency=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_currency_id', i);
                      nlapiLogExecution('debug','bill section-tranCurrency:',tranCurrency);
                    }
					var LineLevelpwp=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield5', i);
					//var item=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield7',i);
					var vvccpEcecutionBatcLink=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield6',i);
					var nativeLineId=request.getLineItemValue(COL_SL_VENDOR_BILL_SUBLIST, 'custpage_scriptfield8',i);
					
					var vendorbillindividualobj={};
					vendorbillindividualobj.id=vendorBillId;
					vendorbillindividualobj.payment=vendorBillAmount;
					vendorbillindividualobj.lineid=vendorBillLineId;
					vendorbillindividualobj.pwp=LineLevelpwp;
					if(vvccpEcecutionBatcLink !=null && vvccpEcecutionBatcLink != '')
					vvccpEcecutionBatcLink=vvccpEcecutionBatcLink.replace(/,/g , '|');
					ssVendorBillDataFile+= vendorBillId+','+FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS+','+vendorBillLineId+','+' '+','+nativeLineId+','+vvccpEcecutionBatcLink+'\n';
					if(!mainObj.hasOwnProperty(vendor+'-'+tranCurrency))
					{
						mainObj[vendor+'-'+tranCurrency]=new Object();
						mainObj[vendor+'-'+tranCurrency].vendorbill=[vendorbillindividualobj];
						totalUniqueVendors++;
					}
					else
					{
						var existingVBs = [];
						if (mainObj[vendor+'-'+tranCurrency].hasOwnProperty('vendorbill'))
						{
							
							existingVBs = existingVBs.concat(mainObj[vendor+'-'+tranCurrency].vendorbill);
							
						}
						existingVBs.push(vendorbillindividualobj);
						mainObj[vendor+'-'+tranCurrency].vendorbill=existingVBs;

					}
					
				}
			}
			for (var i=1; i<=vendorCreditLineCount; i++) 
			{
			 if (request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_MARK, i) == 'T') 
				{ 
					var vendorCreditId=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield2', i);
					if (!creditObj.hasOwnProperty(vendorCreditId))
					creditObj[vendorCreditId]=vendorCreditId;
					var vendorCreditAmount=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, COL_SL_VENDOR_CREDIT_AMOUNT, i);
					var vendor=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield3', i);
										var tranCurrency=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield7', i);
                  if(tranCurrency == null || tranCurrency == '')
                    {
                      tranCurrency=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_currency_id', i);
                      nlapiLogExecution('debug','bill section-tranCurrency:',tranCurrency);
                    }
nlapiLogExecution('debug','bill credit section-tranCurrency:',tranCurrency);
					//var creditLineLevelPwp=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST, 'custpage_scriptfield4', i);
					var vvccpEcecutionBatcLink=request.getLineItemValue(COL_SL_VENDOR_CREDIT_SUBLIST,'custpage_scriptfield5',i);
					var vendorcreditindividualobj={};
					vendorcreditindividualobj.id=vendorCreditId;
					vendorcreditindividualobj.payment=vendorCreditAmount;
					//vendorcreditindividualobj.pwp=creditLineLevelPwp;
					if(vvccpEcecutionBatcLink !=null && vvccpEcecutionBatcLink != '')
					vvccpEcecutionBatcLink=vvccpEcecutionBatcLink.replace(/,/g , '|');
					ssVendorCreditDataFile+= vendorCreditId+','+FLD_VVCCP_PROCESSING_STATUS_READY_FOR_PROCESSING_FOR_TRANSACTIONS+','+' '+','+vvccpEcecutionBatcLink+'\n';
					if(!mainObj.hasOwnProperty(vendor+'-'+tranCurrency))
					{
						mainObj[vendor+'-'+tranCurrency]=new Object();
						mainObj[vendor+'-'+tranCurrency].vendorcredit=[vendorcreditindividualobj];
						totalUniqueVendors++;

					}
					else
					{
						var existingCredits = [];
						if (mainObj[vendor+'-'+tranCurrency].hasOwnProperty('vendorcredit'))
						{
							
							existingCredits = existingCredits.concat(mainObj[vendor+'-'+tranCurrency].vendorcredit);
						}
						existingCredits.push(vendorcreditindividualobj);
						mainObj[vendor+'-'+tranCurrency].vendorcredit=existingCredits;

					}
				}
			}
			var textFileWithMainObjDataId='';
			if(mainObj !=null && mainObj != '')
				{
					
					var mainArr = [];
					
					for (var prop in mainObj)
					{
						var innerObj = {};
						var proplist = prop.split('-');
                      nlapiLogExecution('debug','proplist:',proplist);
						innerObj.vendorid = proplist[0];
						innerObj.currency = proplist[1];
                      nlapiLogExecution('debug','innerObj.currency:',proplist[1]);
						innerObj.data = mainObj[prop];
						mainArr.push(innerObj);
					}
					
					nlapiLogExecution('debug','mainObj:',JSON.stringify(mainObj));
					var textFileWithMainObjData=nlapiCreateFile('MainObj_Content_As_Text_'+timeStamp+'.txt','PLAINTEXT',JSON.stringify(mainArr));
					textFileWithMainObjData.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
					textFileWithMainObjDataId=nlapiSubmitFile(textFileWithMainObjData); 
				}
			
			
			if(billObj !='' && billObj !=null)
				{
					nlapiLogExecution('debug','billObj',JSON.stringify(billObj));
					for(prop in billObj)
					{	
						vendorBill.push(prop);
					}
				}
				if(creditObj !='' && creditObj !=null)
				{
					nlapiLogExecution('debug','creditObj',JSON.stringify(creditObj));
					for(prop in creditObj)
					{
						vendorCredit.push(prop);
					}
				}
				
				
				var ssVendorCreditDataFileId=nlapiCreateFile('Selected_Credits_List_For_Updating_'+timeStamp+'.csv','CSV',ssVendorCreditDataFile);
				ssVendorCreditDataFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var ssDataFileIDCr= nlapiSubmitFile(ssVendorCreditDataFileId);
				var ssVendorBillDataFileId=nlapiCreateFile('Selected_Bills_For_Updating_'+timeStamp+'.csv','CSV',ssVendorBillDataFile);
				
				ssVendorBillDataFileId.setFolder(VVCCP_EXECUTION_BATCH_CSV_FOLDER_ID);
				var ssDataFileIDBill= nlapiSubmitFile(ssVendorBillDataFileId);
				var customRec=nlapiCreateRecord(CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH);
				customRec.setFieldValue('name', 'VVCCP EXCCUTION BATCH'+timeStamp);
				customRec.setFieldValue(FLD_TOTAL_VENDOR_BILL_TO_PROCESS,vendorBill.length);
				customRec.setFieldValue(FLD_TOTAL_VENDOR_CREDITS_TO_PROCESS,vendorCredit.length);
				customRec.setFieldValue(FLD_TOTAL_VVCCP_RECORDS_TO_PROCESS,parseInt(totalUniqueVendors));
				//customRec.setFieldValue(FLD_TOTAL_VVCCP_RECORDS_PROCESSED);
				//customRec.setFieldValue(FLD_PROCESSED_PERCENT);
				customRec.setFieldValue(FLD_CREATED_BY,currentUser);
				customRec.setFieldValue(FLD_STATUS,STATUS_FOR_VVCCP_STATUS_IN_PROGRESS);
				customRec.setFieldValue(FLD_DATA_FILE,textFileWithMainObjDataId);
				//customRec.setFieldValue(FLD_STATUS_FILE);
				//customRec.setFieldValue(FLD_ERROR_LOG);
				customRec.setFieldValue(FLD_BILL_DATA_FILES,ssDataFileIDBill);
				customRec.setFieldValue(FLD_CREDIT_DATA_FILE,ssDataFileIDCr);
				customRec.setFieldValues(FLD_VENDOR_BILL_LINKS,vendorBill);
				customRec.setFieldValues(FLD_VENDOR_CREDIT_LINKS,vendorCredit);
				customRec.setFieldValue(FLD_APPROVAL_STATUS,FLD_APPROVAL_STATUS_PENDING_APPROVAL);
				var customRecordId=nlapiSubmitRecord(customRec,true,true);
				if(customRecordId !=null && customRecordId !='')
				{
					var params={};
					params[SPARAM_VVCCP_BATCH_REC_ID] =customRecordId;
					nlapiScheduleScript(SCRIPT_VVCCP_SCHEDULED_SCRIPT_1, null, params);
				}
				return customRecordId;
				
		}
		catch(e)
		{
			if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
		}
	}
