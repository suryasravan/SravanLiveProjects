/*
*Script Name: Appf-Share of Savings Discount UE
*Script Type: User Event
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       17 Apr 2020     Manikanta		  This script calculates Share of Savings Discount based on percentage selected on Contract and sets the Discount Item and Rate based on calculated
* 2.0       17 Sep 2020     Roach             Fix decimal precision in rount
*/

var FLD_CLIENT_CONTRACT = 'custbody_appf_client_contract';
var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_SHARE_OF_SAVINGS = 'custrecord_appf_contract_sospercent';
var COL_SHARE_OF_SAVINGS='custcol_appf_sos_discount';
var SPARAM_DISCOUNT_ITEM = 'custscript_appf_share_of_savings_item';
function shareOfSavingsUE(type){
	if(type != 'delete'){
		try{
		var context = nlapiGetContext();
		var discItem = context.getSetting('SCRIPT', SPARAM_DISCOUNT_ITEM);
		var recId = nlapiGetRecordId();
		var recType = nlapiGetRecordType();
		var invRec = nlapiLoadRecord(recType, recId);
		var contract = invRec.getFieldValue(FLD_CLIENT_CONTRACT);
		var itemCount=invRec.getLineItemCount('item');
		var resetDiscount = true;
		var shareOfSavings = null;
		var discountitem = invRec.getFieldValue('discountitem');
		var existingDiscountRate=invRec.getFieldValue('discountrate');
		if(contract != null && contract != ''){
			shareOfSavings = nlapiLookupField(CUSTOM_RECORD_CONTRACT, contract, FLD_CONTRACT_SHARE_OF_SAVINGS);
			if(discItem != null && discItem != '' && shareOfSavings != null && shareOfSavings != ''){
              resetDiscount = false;
							}
		}
		if (!resetDiscount)
		{
			if(existingDiscountRate == null || existingDiscountRate == '')
				{
					invRec.setFieldValue('discountitem', discItem);
					shareOfSavings = parseFloat(shareOfSavings).toFixed(2)*-1;
					existingDiscountRate = shareOfSavings+'%';
					invRec.setFieldValue('discountrate', shareOfSavings+'%');
				}
			
		}
		
		if(existingDiscountRate)
		{
			existingDiscountRate=existingDiscountRate.toString();
            if (existingDiscountRate.indexOf('%') != -1)
              {
			existingDiscountRate=existingDiscountRate.replace('%','');
			existingDiscountRate=parseFloat(existingDiscountRate);
			for(var i=1;i<=itemCount;i++)
			{
				var lineAmount=invRec.getLineItemValue('item','amount',i);
				var amountToSetForShareOfSaving=parseFloat(lineAmount/100)*parseFloat(existingDiscountRate);
				//var  amountAfterDeductDiscountRate=parseFloat(lineAmount) - parseFloat(amountToSetForShareOfSaving);
				//amountAfterDeductDiscountRate=amountAfterDeductDiscountRate.toFixed(2);
				//var amountToSetForShareOfSaving=parseFloat(lineAmount)*parseFloat(existingDiscountRate);
				invRec.selectLineItem('item',i);
				//invRec.setCurrentLineItemValue('item',COL_SHARE_OF_SAVINGS,amountToSetForShareOfSaving.toFixed(2)) //updated 9/17/2020
				amountToSetForShareOfSaving = amountToSetForShareOfSaving * -1;
				var amountToSetForShareOfSavingFormat = amountToSetForShareOfSaving.toString();
				nlapiLogExecution( 'DEBUG', 'amountToSetForShareOfSavingFormat',amountToSetForShareOfSavingFormat );
				amountToSetForShareOfSavingFormat = Number(Math.round(amountToSetForShareOfSavingFormat + "e2") + "e-2");
				nlapiLogExecution( 'DEBUG', 'amountToSetForShareOfSavingFormat after',amountToSetForShareOfSavingFormat );
				amountToSetForShareOfSavingFormat = amountToSetForShareOfSavingFormat * -1;
				invRec.setCurrentLineItemValue('item',COL_SHARE_OF_SAVINGS,amountToSetForShareOfSavingFormat)
				invRec.commitLineItem('item');
			}
              }
		}	
				
				nlapiSubmitRecord(invRec, true, true);

		}catch(e){
			if( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			     else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
		}
	}
}