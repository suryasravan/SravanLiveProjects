/*Script Name: Appf-Unconsolidate CI UE
 *Script Type: User Event
 *Event Type : Before Load
 *Description: This script creates a button 'Unconsolidate' on custom CI Record. 
 *Company 	 : Appficiency.
 */
var BTN_UNCONSOLIDATE='custpage_unconsolidate';
var FLD_CREATED_FROM='custbody_created_from';
var FLD_INVOICES = 'custrecord_appf_ci_invoices';

var SUITELET_SCRIPT_ID='customscript_appf_unconsolidate_ci_sl';
var SUITELET_DEPLOY_ID='customdeploy_appf_unconsolidate_ci_sl';

function unconsolidateButton(type, form, request)
{
	     if(type != 'delete')
	     {
	    	 try{
	    	 var recID = nlapiGetRecordId(); 
			 var invoices = nlapiGetFieldValue(FLD_INVOICES);
			 if(invoices != null && invoices != ''){
				 var url=nlapiResolveURL('SUITELET', SUITELET_SCRIPT_ID,SUITELET_DEPLOY_ID);
				 url+='&recid='+recID;
				 var button = form.addButton(BTN_UNCONSOLIDATE,'Unconsolidate','window.open(\''+url+'\',\'_self\')');
			 }
	    	 } catch (e) {
	    		 if( e instanceof nlobjError )
	    		      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
	    		      else
	    		      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	      
	    	}
	}
}

