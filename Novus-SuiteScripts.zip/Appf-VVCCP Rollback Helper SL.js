/**
	 * Script Name : Appf-VVCCP Rollback Helper SL 
	 * Script Type : Suitelet
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00       4-2-2020     	Debendra Panigrahi		The script is triggered on the click of button "Initiate cancellation" 
	 *													on VVCCP records and will update the VVCCP record status and performs Rollback actions
     *
	 *
	 * Company 	 : Appficiency. 
*/
//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_AUTHORIZATION_RECEIVE_DATE  ='custrecord_authorization_receive_date';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';
var FLD_TOTAL_CHARGED='custrecord_appf_vvccp_total_charged';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_UPDATES_RELATED_FILES_FOLDERID =979;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_AUTH_REQUEST_CANCELLED_BY_FINANCE=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8;	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9;
var VVCCP_STATUS_PARTIALLY_CHARGED =10;

var BTN_INITIATE_CANCELLATION='custpage_initiate_cancellation';

function rollbackHelper(request,response)
{
	try
	{
		var recId=request.getParameter('recId');
		nlapiLogExecution('debug','recId:',recId);
		
		if(recId !=null && recId !='')
		{
			var booleanForNewVVCCP=false;
			var vvccpRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP,recId);
			var vvccpStatus=vvccpRecord.getFieldValue(FLD_VVCCP_STATUS);
			var vvccpType=vvccpRecord.getFieldValue(FLD_TYPE);
			var maximumToSpend=vvccpRecord.getFieldValue(FLD_MAXIMUM_TO_SPEND);
			var totalCharged=vvccpRecord.getFieldValue(FLD_TOTAL_CHARGED);
			if(maximumToSpend == null || maximumToSpend == '')
				maximumToSpend=0;
			if(totalCharged ==null || totalCharged == '')
				totalCharged=0;
			var pwpRecordLinks=vvccpRecord.getFieldValues(FLD_PWP_RECORD_LINKS);
			var vendor=vvccpRecord.getFieldValue(FLD_VENDOR);
			var currency=vvccpRecord.getFieldValue(FLD_CURRENCY);
			var corporateCreditCard=vvccpRecord.getFieldValue(FLD_CORPORATE_CREDIT_CARD);
			var vvccpBatchLink=vvccpRecord.getFieldValue(FLD_VVCCP_BATCH_LINK);
			if(vvccpStatus == VVCCP_STATUS_PENDING_BATCH)
			{
				vvccpRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTH_REQUEST_CANCELLED_BY_FINANCE);
				
			}
			if(vvccpStatus == VVCCP_STATUS_AUTHORIZED && (vvccpType == VVCCP_CARD_TYPE_SINGLE_USE || vvccpType == VVCCP_CARD_TYPE_MULTI_USE))
			{
				vvccpRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PENDING_CANCEL);
			}
			if(vvccpStatus == VVCCP_STATUS_PARTIALLY_CHARGED && vvccpType == VVCCP_CARD_TYPE_MULTI_USE)
			{
				vvccpRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_AUTHORIZED);
				booleanForNewVVCCP=true;
			}
			nlapiSubmitRecord(vvccpRecord,true,true);
			if (!booleanForNewVVCCP)
			{
				
				nlapiSetRedirectURL('RECORD', CUSTOM_RECORD_VVCCP, recId)
			}
			else
			{

				var newVVCCPRecord=nlapiCreateRecord(CUSTOM_RECORD_VVCCP);
				var nameForVvccp='PA'+randomString(14);
				newVVCCPRecord.setFieldValue('name',nameForVvccp);
				newVVCCPRecord.setFieldValue(FLD_TYPE,VVCCP_CARD_TYPE_MULTI_USE);
				newVVCCPRecord.setFieldValue(FLD_ORIGINAL_AUTHORIZATION,recId);
				newVVCCPRecord.setFieldValue(FLD_MINIMUM_TO_SPEND,1);
				var maximumToSpendForNewVVCCP=parseFloat(maximumToSpend)-parseFloat(totalCharged);
				newVVCCPRecord.setFieldValue(FLD_MAXIMUM_TO_SPEND,maximumToSpendForNewVVCCP);
				if(pwpRecordLinks)
				newVVCCPRecord.setFieldValues(FLD_PWP_RECORD_LINKS,pwpRecordLinks);
				newVVCCPRecord.setFieldValue(FLD_VVCCP_STATUS,VVCCP_STATUS_PENDING_BATCH);
				if(vendor)
				newVVCCPRecord.setFieldValue(FLD_VENDOR,vendor);
				if(currency)
				newVVCCPRecord.setFieldValue(FLD_CURRENCY,currency);
				if(corporateCreditCard)
				newVVCCPRecord.setFieldValue(FLD_CORPORATE_CREDIT_CARD,corporateCreditCard);
				if(vvccpBatchLink)
				newVVCCPRecord.setFieldValue(FLD_VVCCP_BATCH_LINK,vvccpBatchLink);
				var newVVCCPRecordId=nlapiSubmitRecord(newVVCCPRecord,true,true);
				nlapiLogExecution('debug','newVVCCPRecordId:',newVVCCPRecordId);
				if(newVVCCPRecordId)
				nlapiSetRedirectURL('RECORD', CUSTOM_RECORD_VVCCP, newVVCCPRecordId)
			}
			
			
		}
		
	}	
	catch(e)
	{
		nlapiLogExecution('debug','Error Deatils:',e.toString());
	}
}	

function randomString(length) {
	var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
    return result;
}