/**
	 * Script Name : Appf-Client Credit SC #2
	 * Script Type : Scheduled
	 * 
	 * Version    Date			Author				Remarks
	 * 1.0		  										This script creates vendor credits for every VB line item and ,makes applied amount 
	 *													as 0 and backlinks created vendor credits in appf - Vednor Credit Log Record, 
	 *													Updates the CREDIT SUITELET STATUS field on the VB to ‘Ready for processing’ 
	 *													when the batch is completed, Script Unchecks the Credit Processing (Do Not Hide) checkbox
	 *													at the line level for all the VB lines processed by the batch
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * Version    Date            Author           		Remarks
	 * 2.00            			 Debendra Panigrahi		This script creates credit memos for every sales line item and ,makes applied amount as 0 
	 *													and backlinks created credit memos in appf - Cleint Credit Log Record, 
	 *													Updates the CREDIT SUITELET STATUS field on the sales to ‘Ready for processing’ 
	 *													when the batch is completed,Script Unchecks the Credit Processing (Do Not Hide) checkbox at 
	 *													the line level for all the invoice lines processed by the batch.And also added dynamic
	 *													header & line level customization through script parameters.
	 *
	 * Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_CREDIT_CREATION_LOG = 'customrecord_appf_cust_crd_log';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_cst_crd_tl_pro';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_cst_crd_inv_completed';
var FLD_TOT_LINES_FAILD = 'custrecord_appf_cst_crd_lines_failed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_cst_crd_perc_processed';
var FLD_CREATED_BY = 'custrecord_appf_cst_crd_created_by';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_cst_crd_status';
var FLD_DATA_FILE = 'custrecord_appf_cst_crd_data_file';
var FLD_STATUS_FILE  = 'custrecord_appf_cst_crd_error_file';
var FLD_ERROR_LOG = 'custrecord_appf_cst_crd_error_log';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_cst_crd_client';
var FLD_CURRENCY = 'custrecord_appf_cst_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_cst_crd_link';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_cst_crd_invoice_link';

var FLD_SO_BACKLINKING_PERCENT = 'custrecord_appf_so_backlink_percent';
var FLD_SO_BACKLINKING_STATUS = 'custrecord_appf_so_backlinking_status';

var FLD_RESULT_FILE = 'custrecord_appf_cc_result_file';

var STATUS_CR_COMPLETED_SUCCESSFULLY = '4';
var STATUS_CR_COMPLETED_WITH_ERRORS = '5';
var STATUS_CR_IN_PROGRESS = '2';


var SPARAM_CREDIT_CREATION_LOG_ID = 'custscript_appf_credit_creation_log_id';
var SPARAM_INDEX = 'custscriptappf_inv_line_index';

var SPARAM_APPF_PRINT_FORM_HEADER_PARAMS_CCS = 'custscript_appf_print_header_params_ccs';
var SPARAM_APPF_DIGITALMEDIA_HEADER_PARAMS_CCS = 'custscript_appf_digital_header_param_ccs';
var SPARAM_APPF_DOMEDIA_HEADER_PARAMS_CCS = 'custscript_appf_domedia_header_param_ccs';
var SPARAM_APPF_STRATA_HEADER_PARAMS_CCS = 'custscript_appf_strata_header_params_ccs';
var SPARAM_APPF_NONMEDIA_HEADER_PARAMS_CCS = 'custscript_appf_nonmedi_header_param_ccs';

var SPARAM_APPF_PRINT_FORM_LINE_PARAMS_CCS = 'custscript_appf_print_line_params_ccs';
var SPARAM_APPF_DIGITALMEDIA_LINE_PARAMS_CCS = 'custscript_appf_digital_line_params_ccs';
var SPARAM_APPF_DOMEDIA_LINE_PARAMS_CCS = 'custscript_appf_domedia_line_params_ccs';
var SPARAM_APPF_STRATA_LINE_PARAMS_CCS = 'custscript_appf_spot_line_params_ccs';
var SPARAM_APPF_NONMEDIA_LINE_PARAMS_CCS = 'custscript_appf_nonmedia_line_params_ccs';

var FLD_INV_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var STATUS_INV_CREDIT_SL_READY_FOR_PROCESSING = '3';
var FLD_INV_LOG_RECORDS = 'custbody_appf_credit_log_record';
var FLD_COL_INV_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_COL_INV_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_COL_PWP_REC_SO_LINE='custcol_appf_pwp_custom_record';

var FLD_COL_CRED_MEMO_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_CRED_MEMO_PROJECT_HEADER = 'custbody_appf_project_header';

var SPARAM_RESULT_FOLDER_ID = 'custscript_appf_ccresult_files_folder_id';
var SPARAM_RESULT_FILE_ID = 'custscript_appf_cc_result_file_id';
var SPARAM_PROCESSED_SOS_DATA = 'custscript_appf_processed_sos_data';

var SCRIPT_CLIENT_CREDIT_CREATION_SC_3 = 'customscript_appf_client_credit_sc_3';
var DEPLOY_CLIENT_CREDIT_CREATION_SC_3 = 'customdeploy_appf_client_credit_sc_3';

var SPARAM_BACKLINKING_DATA = 'custscript_appf_so_back_linking_data';
var SPARAM_CC_LOG_EXEC_ID = 'custscript_appf_client_cred_log_rec_id';
var SPARAM_SO_IDS_BACKLINKED = 'custscript_appf_so_ids_back_linked';

function credmemoScheduled(type){
	try{
	var context = nlapiGetContext();
	var customRecId = context.getSetting('SCRIPT', SPARAM_CREDIT_CREATION_LOG_ID);
			   var scriptParamProcessedSOsData = context.getSetting('SCRIPT', SPARAM_PROCESSED_SOS_DATA)

	var resultFileId = context.getSetting('SCRIPT', SPARAM_RESULT_FILE_ID);
	var resultFolderId = context.getSetting('SCRIPT', SPARAM_RESULT_FOLDER_ID);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if(index == null || index == '')
		index = 1;
	nlapiLogExecution('debug', 'customRecId', customRecId);
	if(customRecId != null && customRecId != ''){
		nlapiLogExecution('debug', 'customRecId', customRecId);
		var cclRec = nlapiLoadRecord(CUSTOM_RECORD_CREDIT_CREATION_LOG, customRecId);
		var file = cclRec.getFieldValue(FLD_DATA_FILE);
		var totalCreditsToProcess = cclRec.getFieldValue(FLD_TOT_CREDITS_TO_PROCESS);
		var errorLog = '';
		var timeStamp = new Date().getTime();
		var isTotalLinesProcessed = true;
		if(file != null && file != ''){
			nlapiLogExecution('debug', 'file', file);
			var fileContents = nlapiLoadFile(file).getValue();
			if(fileContents != null && fileContents != ''){
				fileContents = fileContents.split('\n');
				nlapiLogExecution('debug', 'fileContents.length', fileContents.length);
				var totalLinesProcessed = 0;
				var totalLinesFaild = 0;
				var totalCreditMemos = [];
				var salesorders = {};
				if(scriptParamProcessedSOsData != null && scriptParamProcessedSOsData != ''){
					salesorders = JSON.parse(scriptParamProcessedSOsData);
				}
				var salesOrderForm='';
				var creditmemoForm='';
				var headerFieldsFromParam='';
				var lineFieldsFromParam='';
				
				var resultFileContents = '';
				if(resultFileId != null && resultFileId != '')
				{
					var existingData = nlapiLoadFile(resultFileId).getValue();
					resultFileContents = existingData;
					nlapiDeleteFile(resultFileId);
				}
				else{
					resultFileContents = 'Script Status, Reason,'+fileContents[0]+'\n';
				}
				
				for(var f=1; f<(fileContents.length-1); f++){
					try{
					var data = fileContents[f].split(',');
					var salesId = data[0];
					nlapiLogExecution('debug', 'data', data);
					if(!salesorders.hasOwnProperty(salesId)){
						salesorders[salesId] = [];
					}
					/*var creditAmt = data[data.length-2];
					var lineId = data[data.length-1];
					var proj = data[data.length-3];*/
					salesorders[salesId].push(lineId);
					var lineId=data[3];
					//var proj=data[5];
					var creditAmt=data[data.length -2];
					var slaesRec=nlapiLoadRecord('salesorder',salesId);
					var client=slaesRec.getFieldValue('entity');
					salesOrderForm=slaesRec.getFieldValue('customform');
					
					if(salesOrderForm == 123)
					{	
						creditmemoForm = 175;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_PRINT_FORM_HEADER_PARAMS_CCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_PRINT_FORM_LINE_PARAMS_CCS);
					}
					if(salesOrderForm == 141)
					{	
						creditmemoForm = 176;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DIGITALMEDIA_HEADER_PARAMS_CCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DIGITALMEDIA_LINE_PARAMS_CCS);
						
					}
					if(salesOrderForm == 143)
					{
						creditmemoForm = 177;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DOMEDIA_HEADER_PARAMS_CCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DOMEDIA_LINE_PARAMS_CCS);
					}
					if(salesOrderForm == 149)
					{
						creditmemoForm = 178;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_STRATA_HEADER_PARAMS_CCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_STRATA_LINE_PARAMS_CCS);
					}
					if(salesOrderForm == 156)
					{
						creditmemoForm = 132;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_NONMEDIA_HEADER_PARAMS_CCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_NONMEDIA_LINE_PARAMS_CCS);
					}
					var clientCredMemo = nlapiCreateRecord('creditmemo');
					clientCredMemo.setFieldValue('customform',creditmemoForm);
					clientCredMemo.setFieldValue('entity', client);
					if(headerFieldsFromParam !='' && headerFieldsFromParam !=null)
					{
						headerFieldsFromParam =headerFieldsFromParam.split(',');
						for(h=0;h<headerFieldsFromParam.length;h++)
						{
							var headerFieldFromSoToCreditMemo=slaesRec.getFieldValue(headerFieldsFromParam[h]);
							clientCredMemo.setFieldValue(headerFieldsFromParam[h],headerFieldFromSoToCreditMemo);
						}
					}
                     var lineNum = slaesRec.findLineItemValue('item', FLD_SO_LINE_ID, lineId);
                    if(lineNum != -1)
                      {
						var proj=slaesRec.getLineItemValue('item','job',lineNum);
						if(proj !=null && proj !='')
						clientCredMemo.setFieldValue(FLD_CRED_MEMO_PROJECT_HEADER, proj);
                    }
					
				

					
					nlapiLogExecution('debug', 'lineNum', lineNum);
					if(lineNum != -1)
					{
						clientCredMemo.selectNewLineItem('item');
					
						var salesItem=slaesRec.getLineItemValue('item','item',lineNum);
						var solineproj = slaesRec.getLineItemValue('item','job',lineNum);
						var pwpRecFroSoLine=slaesRec.getLineItemValue('item',FLD_COL_PWP_REC_SO_LINE,lineNum);
						clientCredMemo.setCurrentLineItemValue('item', 'item', salesItem);
						nlapiLogExecution('debug','creditAmt:',creditAmt);
						clientCredMemo.setCurrentLineItemValue('item', 'quantity', creditAmt);
						clientCredMemo.setCurrentLineItemValue('item', 'job', solineproj);
						clientCredMemo.setCurrentLineItemValue('item', FLD_SO_LINE_ID, lineId);
						clientCredMemo.setCurrentLineItemValue('item', 'rate', 1);
						if(pwpRecFroSoLine !=null && pwpRecFroSoLine != '')
						clientCredMemo.setCurrentLineItemValue('item', FLD_COL_PWP_REC_SO_LINE, pwpRecFroSoLine);
						if(lineFieldsFromParam !='' && lineFieldsFromParam != null)
						{
							lineFieldsFromParam=lineFieldsFromParam.split(',');
							//nlapiLogExecution('debug','lineFieldsFromParam:',lineFieldsFromParam);
							for(l=0; l<lineFieldsFromParam.length; l++)
							{
								var soLineLevelFieldToCreditMemo=slaesRec.getLineItemValue('item',lineFieldsFromParam[l],lineNum);
								//nlapiLogExecution('debug','soLineLevelFieldToCreditMemo:',soLineLevelFieldToCreditMemo);
								clientCredMemo.setCurrentLineItemValue('item',lineFieldsFromParam[l],soLineLevelFieldToCreditMemo);
							}
						}
                      					clientCredMemo.commitLineItem('item'); 

					}
					
					
                    
                      
                      
					/*for(var c=1; c<=clientCredMemo.getLineItemCount('item'); c++){
						var cmInvLineId = clientCredMemo.getLineItemValue('item', FLD_COL_CRED_MEMO_INVOICE_LINE_ID, c);
						if(cmInvLineId == lineId){
                          clientCredMemo.selectLineItem('item', c);
							clientCredMemo.setCurrentLineItemValue('item', 'quantity', creditAmt);
                          clientCredMemo.commitLineItem('item');
						}
						else{
							clientCredMemo.removeLineItem('item', c);
							c--;
						}
					}*/
					
					//var lineNum = clientCredMemo.findLineItemValue('apply', 'internalid', salesId);
					
					/*if(lineNum != -1){
						clientCredMemo.selectLineItem('apply', lineNum);
						clientCredMemo.setCurrentLineItemValue('apply', 'apply', 'F');
						clientCredMemo.commitLineItem('apply');
					}*/
					var clientCredMemoId = nlapiSubmitRecord(clientCredMemo, true, true);
					nlapiLogExecution('debug', 'clientCredMemoId', clientCredMemoId);
					totalCreditMemos.push(clientCredMemoId);
					totalLinesProcessed++;
					resultFileContents += 'Success, ,';
					}catch(e){
						totalLinesFaild++;
						var failedReason = '';
						if ( e instanceof nlobjError ){
							errorLog += 'System error \n '+ e.getDetails();
							failedReason = e.getDetails();
							nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
						}
						else{
							errorLog += 'Unexpected error \n '+ e.toString();
							failedReason = e.toString();
							nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
						}
						resultFileContents += 'Failed,'+failedReason+',';
					}
					
					resultFileContents += fileContents[f]+'\n';
					
                  var percentProcessed = (Number(totalLinesProcessed) + Number(totalLinesFaild))/Number(totalCreditsToProcess);
				percentProcessed = Number(percentProcessed)*100;
				nlapiSubmitField(CUSTOM_RECORD_CREDIT_CREATION_LOG, customRecId, [FLD_TOT_CREDITS_PROCESSED, FLD_TOT_LINES_FAILD, FLD_CREDITS_PROCESSED_PERCENT, FLD_CREDIT_MEMO_LINK], [totalLinesProcessed, totalLinesFaild, percentProcessed, totalCreditMemos]);
				
					
						if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
					
					
				}
				var newResultFileId = '';
				if(resultFileContents != null && resultFileContents != ''){
					var resultFile = nlapiCreateFile('Client_Credit_Creation_Results_'+timeStamp+'.csv', 'CSV', resultFileContents);
                  nlapiLogExecution('debug','resultFolderId:',resultFolderId);
                  nlapiLogExecution('debug','resultFileContents:',resultFileContents);
					resultFile.setFolder(resultFolderId);
					newResultFileId = nlapiSubmitFile(resultFile);
				}
				var cclRec = nlapiLoadRecord(CUSTOM_RECORD_CREDIT_CREATION_LOG, customRecId);
				if(newResultFileId != null && newResultFileId != ''){
                  nlapiLogExecution('debug', 'newResultFileId', newResultFileId);
					cclRec.setFieldValue(FLD_RESULT_FILE, newResultFileId);
                }
				
					
				  cclRec.setFieldValue(FLD_SO_BACKLINKING_STATUS, STATUS_CR_IN_PROGRESS);
				  				  cclRec.setFieldValue(FLD_SO_BACKLINKING_PERCENT, 0);


				
				cclRec.setFieldValue(FLD_ERROR_LOG, errorLog);
				if(errorLog != null && errorLog != '')
					STATUS_CR_COMPLETED_SUCCESSFULLY = STATUS_CR_COMPLETED_WITH_ERRORS;
				cclRec.setFieldValue(FLD_CREDIT_CREATION_STATUS, STATUS_CR_COMPLETED_SUCCESSFULLY);
				
				var cclrecId = nlapiSubmitRecord(cclRec, true, true);
				nlapiLogExecution('debug', 'cclrecId', cclrecId);
				if(salesorders != null && salesorders != ''){
                  nlapiLogExecution('debug', 'SC #3', 'Calling SC #3');
					var params1 = {};
					params1[SPARAM_BACKLINKING_DATA] = JSON.stringify(salesorders);
					params1[SPARAM_CC_LOG_EXEC_ID] = customRecId;
					nlapiScheduleScript(SCRIPT_CLIENT_CREDIT_CREATION_SC_3, null, params1);
				}
				
				
			}
		}
	}
	}catch(e1){
						if ( e1 instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'system error e1', e1.getCode() + '\n' + e1.getDetails() )
						else
							nlapiLogExecution( 'DEBUG', 'unexpected error e1', e1.toString() )
					}
}


function accountingPeriod(date)
{
	
 	var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
 	var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
 	var Dt1 = nlapiDateToString(startDate);
 	var Dt2 = nlapiDateToString(endDate);

 	var filters = new Array();
 	filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
 	filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
 	filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
 	filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');

 	var columns = new Array();
 	columns[0] = new nlobjSearchColumn('internalid');
 	var search = nlapiSearchRecord('accountingperiod', null, filters, columns); 
 	var periodId = search[0].getValue('internalid'); 
 	return periodId;
 	
 	
}



function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}