/*
*Script Name: Appf-Mark SO Lines for Billing SC
*Script Type: Scheduled
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       27 Feb 2020     Manikanta		This script handles the backend processing of marking Ready for Invoicing checkbox on all selected SO lines from Mark SO Lines for Billing SL through CSV import
*/

var SPARAM_CSV_FILE_ID = 'custscript_appf_so_lines_billing_file_id';
var IMPORT_CSV_MARK_SO_LINES_BILLING = 'custimport_appf_mark_so_lines_forbilling';

function markSOLinesBillingSC(type){
	try{
	var context = nlapiGetContext();
	var csvFileId = context.getSetting('SCRIPT', SPARAM_CSV_FILE_ID);
	var csvFileId = context.getSetting('SCRIPT', SPARAM_CSV_FILE_ID);
      nlapiLogExecution('DEBUG', 'markSOLinesBillingSC', 'csvFileId = ' + csvFileId);
		if(csvFileId != null && csvFileId != ''){
			var csvFile = nlapiLoadFile(csvFileId);
			 var fileData = csvFile.getValue();
			var selectedLines = fileData.split('\n');
			var importSoLinkCIExeLog = '';
			importSoLinkCIExeLog += 'Script Use DNR 1, Script Use DNR 2\n';

			var importSoLinkCIExeLog2 = '';
			importSoLinkCIExeLog2 +=  'Script Use DNR 1, Script Use DNR 2\n';

			var importSoLinkCIExeLog3 = '';
			importSoLinkCIExeLog3 +=  'Script Use DNR 1, Script Use DNR 2\n';

            var importSoLinkCIExeLog4 = '';
			importSoLinkCIExeLog4 +=  'Script Use DNR 1, Script Use DNR 2\n';
			
			var hasSo = false;
			var hasSo2 = false;
			var hasSo3 = false;
			var hasSo5 = false;
            
            nlapiLogExecution('DEBUG', 'markSOLinesBillingSC; selectedLines = ' + selectedLines.length, JSON.stringify(selectedLines));

			for(var s=1; s<(selectedLines.length-1); s++){
				var line = selectedLines[s].split(',');
                nlapiLogExecution('DEBUG', 's = ' + s, JSON.stringify(line));
				var transRecId = line[0];
				var SoLinId = line[1];
                nlapiLogExecution('DEBUG', 's = ' + s, 'transRecId = ' + transRecId + ', SoLinId = ' + SoLinId);
					var nDigit = parseInt(transRecId)%10;
					if(nDigit == 0 || nDigit == 1 || nDigit == 2){
						//nlapiLogExecution('debug', 'nDigit 1', nDigit);
						importSoLinkCIExeLog += transRecId + ',' + SoLinId+ '\n';
            hasSo=true;
					}else if(nDigit == 4 || nDigit == 5){
						//nlapiLogExecution('debug', 'nDigit 2', nDigit);
						importSoLinkCIExeLog2 += transRecId + ',' + SoLinId+ '\n';
            hasSo2=true;
					}else if(nDigit == 6 || nDigit == 7 || nDigit == 8){
						//nlapiLogExecution('debug', 'nDigit 3', nDigit);
						importSoLinkCIExeLog3 +=transRecId + ',' + SoLinId+ '\n';
            hasSo3=true;
					}
					else if(nDigit == 3 || nDigit == 9){
						//nlapiLogExecution('debug', 'nDigit 3', nDigit);
						importSoLinkCIExeLog4 +=transRecId + ',' + SoLinId+ '\n';
            hasSo5=true;
					}
			}
            	
                if(importSoLinkCIExeLog != null && importSoLinkCIExeLog != '' && hasSo){ //queue 2
				nlapiLogExecution('debug', 'importSoLinkCIExeLog', importSoLinkCIExeLog);
				var importSILines = nlapiCreateCSVImport();
				importSILines.setMapping(IMPORT_CSV_MARK_SO_LINES_BILLING);
				importSILines.setPrimaryFile(importSoLinkCIExeLog);
				importSILines.setQueue(2);
				var processingJOBID = nlapiSubmitCSVImport(importSILines)
			}

			if(importSoLinkCIExeLog2 != null && importSoLinkCIExeLog2 != '' && hasSo2){ //queue 3
				nlapiLogExecution('debug', 'importSoLinkCIExeLog2', importSoLinkCIExeLog2);
				var importSILines = nlapiCreateCSVImport();
				importSILines.setMapping(IMPORT_CSV_MARK_SO_LINES_BILLING);
				importSILines.setPrimaryFile(importSoLinkCIExeLog2);
				importSILines.setQueue(3);
				var processingJOBID = nlapiSubmitCSVImport(importSILines)
			}

			if(importSoLinkCIExeLog3 != null && importSoLinkCIExeLog3 != '' && hasSo3){ //queue 4
				nlapiLogExecution('debug', 'importSoLinkCIExeLog3', importSoLinkCIExeLog3);
			var importSILines = nlapiCreateCSVImport();
				importSILines.setMapping(IMPORT_CSV_MARK_SO_LINES_BILLING);
				importSILines.setPrimaryFile(importSoLinkCIExeLog3);
				importSILines.setQueue(4);
				var processingJOBID = nlapiSubmitCSVImport(importSILines);
			}
			if(importSoLinkCIExeLog4 != null && importSoLinkCIExeLog4 != '' && hasSo5){ //queue 5
				nlapiLogExecution('debug', 'importSoLinkCIExeLog4', importSoLinkCIExeLog4);
			var importSILines = nlapiCreateCSVImport();
				importSILines.setMapping(IMPORT_CSV_MARK_SO_LINES_BILLING);
				importSILines.setPrimaryFile(importSoLinkCIExeLog4);
				importSILines.setQueue(5);
				var processingJOBID = nlapiSubmitCSVImport(importSILines);
			}
	}
	
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
}