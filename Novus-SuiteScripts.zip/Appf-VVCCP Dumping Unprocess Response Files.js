/**
	 * Script Name : Appf-VVCCP Dumping UnProcess Response File 
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		
	 *
	 * Company 	 : Appficiency. 
*/
var APPF_VVCCP_SFTP_RECEIVE_SL_SCRIPT_ID='customscript_appf_vvccp_receive_sl';
var APPF_VVCCP_SFTP_RECEIVE_SL_DEPLOY_ID='customdeploy_appf_vvccp_receive_sl';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_AMEX_RESPONSE_UNPROCESSED=1141;
var VVCCP_AMEX_RESPONSE_PROCESSED=1140;
var VVCCP_AMEX_RECON_UNPROCESSED=1139;
var VVCCP_AMEX_RECON_PROCESSED=1142;
var VVCCP_MASTERCARD_RESPONSE_UNPROCESSED=1132;
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;

var RESPONSE_PREFIX_AMEX = 'Response-';
var RECON_PREFIX_AMEX = 'Recon-';
var ERROR_PREFIX_AMEX= 'Error-';


var CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG='customrecord_appf_vvccp_response_proc';
var FLD_INBOUND_FILE_TYPE='custrecord_appf_vvccp_inbound_file_type';
var FLD_CARD_PROVIDER='custrecord_appf_resp_recon_card_provider';
var FLD_VVCCP_TO_PROCESS='custrecord_appf_vvccp_num_process';
var FLD_VVCCP_PROCESSED='custrecord_appf_vvccp_num_processed';
var FLD_PROCESSED_PERCENTAGE='custrecord_appf_vvccp_processed_perc';
var FLD_RESPONSE_OR_RECON_FILE='custrecord_appf_vvccp_res_rec';
var FLD_RESPONSE_OR_RECON_RESULT_FILE='custrecord_appf_vvccp_res_rec_result';
var FLD_ERROR_LOG='custrecord_appf_vvccp_res_rec_errors';
var FLD_VVCCP_RECORD_LINK='custrecord_appf_vvccp_res_rec_link';
var FLD_VIRTUAL_CARD_LINK='custrecord_appf_vvccp_res_card_link';
var	FLD_VVCCP_RECON_RECORD_LINK='custrecord_appf_vvccp_recon_record_link';
var FLD_FILE_MOVED_TO_PROCESSED_FOLDER='custrecord_appf_vvccp_res_rec_file_moved';
var FLD_RESPONSE_FILE_PROCESSED='custrecord_response_file_processed';
var FLD_VVCCP_FAILED='custrecord_num_vvccp_failed';
var VVCCP_INBOUND_FILE_TYPE_RESPONSE='1';
var VVCCP_INBOUND_FILE_TYPE_RECON='2';

var SPARAM_AMEX_CONNECTION_IS_ACTIVE = 'custscript_amex_connection_active';
var SPARAM_MASTERCARD_CONNECTION_IS_ACTIVE = 'custscript_mcard_connection_active';


function schedule(type)
{
	
		var context=nlapiGetContext();
		
		//Sravan 5/4/2022 Added conditions checking if global connections for AMEX or MasterCard active
	var isAMEXActive=context.getSetting('SCRIPT', SPARAM_AMEX_CONNECTION_IS_ACTIVE);
	nlapiLogExecution('debug', 'is AMEX Active?', isAMEXActive);
		var isMasterCardActive=context.getSetting('SCRIPT', SPARAM_MASTERCARD_CONNECTION_IS_ACTIVE);
			nlapiLogExecution('debug', 'is MasterCard Active?', isMasterCardActive);


				//Sravan 5/4/2022 Added conditions checking if global connections for AMEX active

		if (isAMEXActive == 'T')
		{
		
						var url=nlapiResolveURL('SUITELET', APPF_VVCCP_SFTP_RECEIVE_SL_SCRIPT_ID, APPF_VVCCP_SFTP_RECEIVE_SL_DEPLOY_ID,'external');
						var fileurl = url + '&creditCardType='+CREDIT_CARD_TYPE_AMEX;
						try
						{
							var suiteletResponse=nlapiRequestURL(fileurl);
							var amexResponseFileIdData='';
							if(suiteletResponse.getCode() == 200)
							{
								nlapiLogExecution('debug','suiteletResponse.Code:',suiteletResponse.getCode());
								var amexResponseBody = JSON.parse(suiteletResponse.getBody());
								amexResponseFileIdData=amexResponseBody.fileid;
								nlapiLogExecution('debug','amexResponseFileIdData:',amexResponseFileIdData);
                            }
								// amexResponseFileId = 364146;
								if(amexResponseFileIdData !='' && amexResponseFileIdData !=null && amexResponseFileIdData != 'none')
								{
									var amexResponseFileIdDataArr = amexResponseFileIdData.split(',');
									for (var u = 0; u < amexResponseFileIdDataArr.length; u++)
									{
										var amexResponseFileId = amexResponseFileIdDataArr[u];
                                  
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
									nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER,CREDIT_CARD_TYPE_AMEX);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE,(nameToSetForLogRecord.indexOf(RESPONSE_PREFIX_AMEX) != -1 || nameToSetForLogRecord.indexOf(ERROR_PREFIX_AMEX) != -1)?VVCCP_INBOUND_FILE_TYPE_RESPONSE:VVCCP_INBOUND_FILE_TYPE_RECON);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
									}
                                }
                                  
						}
						catch(e)
						{
							if ( e instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'Error in dumping amex response file:'+fileAmexId, e.getCode() + '\n' + e.getDetails() )
							else
							nlapiLogExecution('DEBUG','Error in dumping amex response file:'+fileAmexId, e.toString());			
						}
						
		}
		
				//Sravan 5/4/2022 Added conditions checking if global connections for MasterCard active

		if (isMasterCardActive == 'T')
		{
		
						var url=nlapiResolveURL('SUITELET', APPF_VVCCP_SFTP_RECEIVE_SL_SCRIPT_ID, APPF_VVCCP_SFTP_RECEIVE_SL_DEPLOY_ID,'external');
						var fileurl = url + '&creditCardType='+CREDIT_CARD_TYPE_MASTERCARD;
						try
						{
							var suiteletResponse=nlapiRequestURL(fileurl);
							var masterCardResponseFileIdData='';
							if(suiteletResponse.getCode() == 200)
							{
								nlapiLogExecution('debug','suiteletResponse.Code:',suiteletResponse.getCode());
								var masterCardResponseBody = JSON.parse(suiteletResponse.getBody());
								masterCardResponseFileIdData=masterCardResponseBody.fileid;
								nlapiLogExecution('debug','masterCardResponseFileIdData:',masterCardResponseFileIdData);
                            }
                         // amexResponseFileId = 364146;
								if(masterCardResponseFileIdData !='' && masterCardResponseFileIdData !=null && masterCardResponseFileIdData != 'none')
								{
									var masterCardResponseFileIdDataArr = masterCardResponseFileIdData.split(',');
									for (var u = 0; u < masterCardResponseFileIdDataArr.length; u++)
									{
										var masterCardResponseFileId = masterCardResponseFileIdDataArr[u];
										var masterCardResponseFileObject = nlapiLoadFile(masterCardResponseFileId);
										var filemasterCardId = masterCardResponseFileObject.getName();
										
										var nameToSetForLogRecord=filemasterCardId;
										nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
										nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									
										var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);	
										vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_CARD_PROVIDER,CREDIT_CARD_TYPE_MASTERCARD);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE,(nameToSetForLogRecord.indexOf('Novutevwero_FPCS#SJB_') != -1 || nameToSetForLogRecord.indexOf('Novutevwero_FPCS#SYM_') != -1)?VVCCP_INBOUND_FILE_TYPE_RESPONSE:VVCCP_INBOUND_FILE_TYPE_RECON);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
										vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,masterCardResponseFileId);
										var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
										nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
										
									}
                                }
                                  
						}
						catch(e)
						{
							if ( e instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'Error in dumping masterCard response file:'+filemasterCardId, e.getCode() + '\n' + e.getDetails() )
							else
							nlapiLogExecution('DEBUG','Error in dumping masterCard response file:'+filemasterCardId, e.toString());			
						}
		}
				//Manual File processing Logic for Recon...Starts Here
				                  /*
                                  var amexResponseFileId = '4514545';
                                  
                                  var amexResponseFileObject = nlapiLoadFile(amexResponseFileId);
                                  var fileAmexId = amexResponseFileObject.getName();
									var vvccpResponseFileProcessingLog=nlapiCreateRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG);
									var nameToSetForLogRecord=fileAmexId;
									nameToSetForLogRecord=nameToSetForLogRecord.replace('.txt','');
                                  nlapiLogExecution('debug','nameToSetForLogRecord:',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue('name',nameToSetForLogRecord);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_INBOUND_FILE_TYPE, VVCCP_INBOUND_FILE_TYPE_RECON);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_PROCESSED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_VVCCP_FAILED,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_PROCESSED_PERCENTAGE,0);
									vvccpResponseFileProcessingLog.setFieldValue(FLD_RESPONSE_OR_RECON_FILE,amexResponseFileId);
									var vvccpResponseFileProcessingLogId=nlapiSubmitRecord(vvccpResponseFileProcessingLog,true,true);
									nlapiLogExecution('debug','vvccpResponseFileProcessingLogId:',vvccpResponseFileProcessingLogId);
                                    */
                //Manual File processing Logic for Recon...Ends Here
				
					
		
}

function zeroFill( number, width )
{
  width -= number.toString().length;
  if ( width > 0 )
  {
    return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
  }
  return number + ""; // always return a string
}
function formatDate(date) {
    var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear().toString().substr(-2);
	var century=d.getFullYear().toString().substr(0,2);
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return century.toString()+year.toString()+month.toString()+day.toString();
}