/*
* Script Name : Appf-Connex to Netsuite Agency SL
* Script Type : Suitelet
* Event Type  : Azure function triggered
* Description : This Suietlet acts as  web service or web hook for Inbound Flow of Connex to Netsuite "Agency" which will trigger a scheduled script that processes all messages in queue.
* Company     :	Appficiency Inc.
*/
  var SCRIPT_SCHEDULED='customscript_appf_connex_agency_2_ns_sc'
function suitelet(request, response)
{
	nlapiLogExecution('debug', 'script entry',  nlapiGetContext().getExecutionContext());	
nlapiScheduleScript(SCRIPT_SCHEDULED,null)
               
	return 'Successfully connected to Netsuite, messages are being processed';
}
