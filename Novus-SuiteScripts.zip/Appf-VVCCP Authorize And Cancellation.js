/**
	 * Script Name : Appf-VVCCP Authorize And Cancellation 
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		This script handles Authrized and Cancellation Accepted scenarios of VVCCPs in Batch record and processes them and move the file to Processed folder
	 *
	 * Company 	 : Appficiency. 
**/
//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_AUTHORIZATION_RECEIVE_DATE  ='custrecord_authorization_receive_date';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';
var FLD_VVCCP_PDF = 'custrecord_appf_vvccp_pdf';
/* SBX Folder ids
var VVCCP_AMEX_RESPONSE_UNPROCESSED=1127;
var VVCCP_AMEX_RESPONSE_PROCESSED=1128;
var VVCCP_AMEX_RECON_UNPROCESSED=1135;
var VVCCP_AMEX_RECON_PROCESSED=1136;
var VVCCP_RESULT_FILE_CSV_FOLDER_ID_AMEX=1149;
var VVCCP_MASTERCARD_RESPONSE_UNPROCESSED=1133;
var VVCCP_MASTERCARD_RESPONSE_PROCESSED=1134;
var VVCCP_MASTERCARD_RECON_UNPROCESSED=1146;
var VVCCP_MASTERCARD_RECON_PROCESSED=1145;
var VVCCP_RESULT_FILE_CSV_FOLDER_ID_MASTERCARD=1150;
*/

var VVCCP_AMEX_RESPONSE_UNPROCESSED=1141;
var VVCCP_AMEX_RESPONSE_PROCESSED=1140;
var VVCCP_AMEX_RESPONSE_PROCESSED_WITH_ERRORS=1159;
var VVCCP_AMEX_RECON_UNPROCESSED=1139;
var VVCCP_AMEX_RECON_PROCESSED=1142;
var VVCCP_RESULT_FILE_CSV_FOLDER_ID_AMEX=1148;

var VVCCP_MASTERCARD_RESPONSE_UNPROCESSED=1132;
var VVCCP_MASTERCARD_RESPONSE_PROCESSED=1131;
var VVCCP_MASTERCARD_RESPONSE_PROCESSED_WITH_ERRORS=1160;
var VVCCP_MASTERCARD_RECON_UNPROCESSED=1155;
var VVCCP_MASTERCARD_RECON_PROCESSED=1154;
var VVCCP_RESULT_FILE_CSV_FOLDER_ID_MASTERCARD=1158;


var CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG='customrecord_appf_vvccp_response_proc';
var FLD_INBOUND_FILE_TYPE='custrecord_appf_vvccp_inbound_file_type';
var FLD_VVCCP_TO_PROCESS='custrecord_appf_vvccp_num_process';
var FLD_VVCCP_PROCESSED='custrecord_appf_vvccp_num_processed';
var FLD_PROCESSED_PERCENTAGE='custrecord_appf_vvccp_processed_perc';
var FLD_RESPONSE_OR_RECON_FILE='custrecord_appf_vvccp_res_rec';
var FLD_RESPONSE_OR_RECON_RESULT_FILE='custrecord_appf_vvccp_res_rec_result';
var FLD_ERROR_LOG='custrecord_appf_vvccp_res_rec_errors';
var FLD_VVCCP_RECORD_LINK='custrecord_appf_vvccp_res_rec_link';
var FLD_VIRTUAL_CARD_LINK='custrecord_appf_vvccp_res_card_link';
var	FLD_VVCCP_RECON_RECORD_LINK='custrecord_appf_vvccp_recon_record_link';
var FLD_FILE_MOVED_TO_PROCESSED_FOLDER='custrecord_appf_vvccp_res_rec_file_moved';
var FLD_RESPONSE_FILE_PROCESSED='custrecord_response_file_processed';
var FLD_VVCCP_FAILED='custrecord_num_vvccp_failed';
var FLD_VVCCP_CARD_PROVIDER='custrecord_appf_resp_recon_card_provider';
var VVCCP_INBOUND_FILE_TYPE_RESPONSE='1';
var VVCCP_INBOUND_FILE_TYPE_RECON='2';

var CUSTOMRECORD_VITUAL_CREDIT_CARD_ID='custrecord_appf_vvccp_card_vvccp_link.internalid';
var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9
var CORPORATE_CREDIT_CARD_VVCCP='custentity_appf_vvccp_corporate_cc';
var FLD_VENDOR_PAYMENT_TYPE='custentity_appf_vendorpaymenttype';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var CUSTOM_RECORD_CORPORATE_CREDIT_CARDS='customrecord_appf_corp_card_table';
var FLD_CREDIT_CARD_TYPE='custrecord_appf_corp_credit_card_type';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias'

var CUSTOM_RECORD_PWP='customrecord_appf_pwp_wrapper_record';
var FLD_BILL_LINEAMOUNT_PAID='custrecord_appf_pwp_bill_line_amt_paid'
var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';

var SPARAM_COMPONY_EXPIRATION_DAY='custscript_appf_company_expiration_date';
var SPARAM_VVCCP_UPDATE_SEARCH='custscript_vvccp_update_search';
var TRANSACTION_TYPE_ADD='A';
var TRANSACTION_TYPE_DELETE='D';
var TRANSACTION_TYPE_MODIFY='M';

var NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID=2;
var NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID=7;

var STR_PAD_LEFT = 1;
var STR_PAD_RIGHT = 2;
var STR_PAD_BOTH = 3;

var USD=1;
var CAD=3;

var CUSTOM_RECORD_VIRTUAL_CREDIT_CARD='customrecord_appf_vvccp_authorized_card';
var FLD_CARD_NUMBER='custrecord_appf_vvccp_card_number';
var FLD_SECURITY_CODE='custrecord_appf_vvccp_card_code';
var FLD_EXPIRATION_DATE='custrecord_appf_vvccp_card_exp_date';
var FLD_PROVIDER='custrecord_appf_vvccp_card_provider';
var FLD_PURCHASE_ID_MASTERCARD='custrecord_appf_vvccp_card_purchase_id';
var FLD_VENDOR_PAYMENT_LINK='custrecord_appf_vvccp_ven_pmt_link';
var FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD='custrecord_appf_vvccp_card_vvccp_link';
var FLD_CARD_CANCELLED='custrecord_appf_vvccp_card_cancelled';
var FLD_VOID_JOURNAL='custrecord_appf_vvccp_payment_void';
var FLD_AUTHORIZATION_DATE='custrecord_appf_vvccp_authorization_date';

var SPARAM_VVCCP_SEARCH_WITH_AUTHORISED_STATUS='';
var SPARAM_AMEX_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var SPARAM_MASTERCARD_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var VENDOR_PAYMENT_STATUS_APPROVEED_ID=2;
var FLD_VVCCP_BACKLINK='custbody_appf_vvccp_backlink';
var SPARAM_AUTHORIZED_VVCCP_RECORDS='custscript_process_authorize_vvccp';
var SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE='custscript_amex_contra_account_for_vvccp';
var SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE_USA='custscript_mastercard_contra_account_usa';
var SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE_CAD='custscript_mastercard_contra_account_cad';
var SPARAM_RESPONSE_RECON_LOG_RECORD_SEARCH='custscript_resp_recon_log_serach';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;
var COL_FLD_PENDING_AUTHORIZATION_VVCCP='custcol_appf_pending_auth_vvccp';
var FLD_PENDING_AUTHORIZATION_VVCCP='custbody_appf_pending_auth_vvccp';
var FLD_VB_LINE_ID = 'custcol_appf_vendorbill_line_id';


var CUSTOM_RECORD_CORPORATE_CREDIT_CARD='customrecord_appf_corp_card_table';

var COL_FLD_BILL_LINE_PAYMENT_AMOUNT='custcol_appf_pwp_bill_line_amt_paid';

var SPARAM_VVCP_RESPON_FILE_ID = 'custscript_resp_file_id';
var SPARAM_VVCP_RESPON_FILE_INDEX = 'custscript_resp_file_index';

function schedule(type)
{
	
				var context=nlapiGetContext();
				var d = new Date();
				var timeStamp = d.getTime();
				
	var responfileid = context.getSetting('SCRIPT',SPARAM_VVCP_RESPON_FILE_ID);
	var responindex = context.getSetting('SCRIPT',SPARAM_VVCP_RESPON_FILE_INDEX);
	if (responindex == null || responindex == '')
		responindex = 0;
	
	
				var amexAccountFromCommanyPreference=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_AMEX_FROM_COMPANY_PREFERENCE);
				var masterCardAccountFromCommanyPreferenceUSA=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE_USA);
				var masterCardAccountFromCommanyPreferenceCAD=context.getSetting('SCRIPT', SPARAM_ACCOUNT_FOR_MASTERCARD_FROM_COMPANY_PREFERENCE_CAD);
				var responSS=context.getSetting('SCRIPT', SPARAM_RESPONSE_RECON_LOG_RECORD_SEARCH);
				var responFileIdData = [];
				
				if (responfileid == null || responfileid == '')
		        {
				var vvccpProcessResponseOrReconFileProcessingLog=nlapiSearchRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,responSS);
				if(vvccpProcessResponseOrReconFileProcessingLog !=null && vvccpProcessResponseOrReconFileProcessingLog !='')
	            {
                    for(var u=0;u<vvccpProcessResponseOrReconFileProcessingLog.length;u++)
		            {
						
						var vvccpProcessResponseOrReconFileProcessingLogId=vvccpProcessResponseOrReconFileProcessingLog[u].getId();
						responFileIdData.push(vvccpProcessResponseOrReconFileProcessingLogId);

					}
					
					var responFileObj = nlapiCreateFile('responfile_'+timeStamp+'.txt', 'PLAINTEXT', responFileIdData+'');
					responFileObj.setFolder(-15);
					responfileid = nlapiSubmitFile(responFileObj);
				}
		         }
		
		
				
					if (responfileid != null && responfileid != '')
	{
		var responfileidValues = nlapiLoadFile(responfileid).getValue();
	     var responfileidValuesList = responfileidValues.split(',');
    if(responfileidValuesList.length > 0)
	{
		
		for(var l=responindex;l<responfileidValuesList.length;l++)
		{
			var vvccpProcessResponseOrReconFileProcessingLogId=responfileidValuesList[l];
			nlapiLogExecution('debug','resp log id:',vvccpProcessResponseOrReconFileProcessingLogId); 
			var vvccpProcessResponseOrReconFileProcessingLogRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId);
			var cardProvider=vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValue(FLD_VVCCP_CARD_PROVIDER);
						var existingVVCCPProcessed=vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValue(FLD_VVCCP_PROCESSED);
						if (existingVVCCPProcessed == null || existingVVCCPProcessed == '')
							existingVVCCPProcessed = 0;
						
						var existingVVCCPFailed=vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValue(FLD_VVCCP_FAILED);
						if (existingVVCCPFailed == null || existingVVCCPFailed == '')
							existingVVCCPFailed = 0;

						
						nlapiLogExecution('debug','cardProvider:',cardProvider); 
						
					var responseFileInCustomRecord=vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValue(FLD_RESPONSE_OR_RECON_FILE);
					
								var vvccpProcessResponseOrReconFileProcessingLogName = vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValue('name');

					
					if (responseFileInCustomRecord != null && responseFileInCustomRecord != '')
					{
						
						var rFils = [];
						    rFils.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
						    rFils.push(new nlobjSearchFilter('internalid', null, 'noneof', vvccpProcessResponseOrReconFileProcessingLogId));
							rFils.push(new nlobjSearchFilter('name', null, 'is', vvccpProcessResponseOrReconFileProcessingLogName));
                            rFils.push(new nlobjSearchFilter(FLD_RESPONSE_FILE_PROCESSED, null, 'is', 'T'));
							
						var rSS = nlapiSearchRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG, null, rFils, new nlobjSearchColumn('name'));
							
						if (rSS == null || rSS == '')
						{							


			//Logic Starts : AMEX Response Processing
						if (cardProvider == CREDIT_CARD_TYPE_AMEX)
						{
							nlapiLogExecution('debug','coming inside Amex')
							
							var existingvvccps = vvccpProcessResponseOrReconFileProcessingLogRecord.getFieldValues(FLD_VVCCP_RECORD_LINK);

						var amexUnProcessedFile=nlapiLoadFile(responseFileInCustomRecord);
						var amexValues=amexUnProcessedFile.getValue();
						amexValues=amexValues.split('\n');
						var vvccpToProcess=0;
						var numberOfVVCCPToProcess=[];
						for(var p=1;p<amexValues.length-1;p=p+2)
						{
							var q=p+1;
							var vvccpInternalId=amexValues[q].substr(324,40);
							var amexTransactionType=amexValues[p].substr(4,1);
							var amexStatusUpdate=amexValues[p].substr(20,1);
							var amexErrorNumber=amexValues[p].substr(43,6);
							var amexErrorDescription=amexValues[p].substr(49,35);
							amexRow20AsCardNumber=amexValues[p].substr(21,16);
							amexResponseAsSecurityCode=amexValues[p].substr(785,4);
							amexExpirationDateAsResponse=amexValues[p].substr(166,6);
					
							if(vvccpInternalId !=null && vvccpInternalId !='' && vvccpInternalId !=' ')
							{
								vvccpInternalId=vvccpInternalId.trim();
								vvccpToProcess++;
								numberOfVVCCPToProcess.push(vvccpInternalId);

							}
							
							
						}
						nlapiLogExecution('debug','VVCCPToProcess:',numberOfVVCCPToProcess);
						if (existingvvccps == null || existingvvccps == '')
						{
						try{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId,[FLD_VVCCP_TO_PROCESS,FLD_VVCCP_RECORD_LINK],[vvccpToProcess,numberOfVVCCPToProcess]);
						}
						catch(ex)
						{
							nlapiLogExecution('debug','failed to set vvccp links because it has improper ids:',numberOfVVCCPToProcess);
                            nlapiSubmitField(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId,['custrecord_appf_vvccp_res_rec_errors'],['failed to set vvccp links because it has improper ids:'+numberOfVVCCPToProcess+'\n'+ex]);

							
						}
						}

													var vvccpProcessed=existingVVCCPProcessed;

						var errorDetails='';
						var vvccpFailed=existingVVCCPFailed;
						var vvccpProcessedPercentage=0;
						var virtualCreditCardRecordIdArray=[];
						
						var resultFile='';
						resultFile+='VVCCP INTERNALID,VVCCP NMAE,PROCESS STATUS,FAILURE REASON \n';

						for(var p=1;p<amexValues.length-1;p=p+2)
						{
							var q=p+1;
							var vvccpInternalId=amexValues[q].substr(324,40);
							var amexTransactionType=amexValues[p].substr(4,1);
							var amexStatusUpdate=amexValues[p].substr(20,1);
							var amexErrorNumber=amexValues[p].substr(43,6);
							var amexErrorDescription=amexValues[p].substr(49,35);
							amexRow20AsCardNumber=amexValues[p].substr(21,16);
							amexResponseAsSecurityCode=amexValues[p].substr(785,4);
							amexExpirationDateAsResponse=amexValues[p].substr(166,6);
							if(amexErrorNumber !=null && amexErrorNumber !='')
							amexErrorNumber=amexErrorNumber.trim();	
							if(vvccpInternalId !=null && vvccpInternalId !='' && vvccpInternalId !=' ')
							{
                              	vvccpInternalId=vvccpInternalId.trim();
								//vvccpToProcess=parseFloat(vvccpToProcess)+1;
								if(vvccpInternalId !=null && vvccpInternalId !='')
							{
								var vvccpRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP,vvccpInternalId)
								var originalAuthorization=vvccpRecord.getFieldValue(FLD_ORIGINAL_AUTHORIZATION);
								var vendor=vvccpRecord.getFieldValue(FLD_VENDOR);
								nlapiLogExecution('debug','vvccpInternalId:',vvccpInternalId);
								nlapiLogExecution('debug','vendor:',vendor);
								var corporateCreditCard=vvccpRecord.getFieldValue(FLD_CORPORATE_CREDIT_CARD);
								var vvccpStatus=vvccpRecord.getFieldValue(FLD_VVCCP_STATUS);
								nlapiLogExecution('debug','vvccpStatus:',vvccpStatus);
								var vvccpName=vvccpRecord.getFieldValue('name');
								
								try{
								if(vvccpStatus == VVCCP_STATUS_PENDING_RESPONSE){
								var vvccpDateCreated=vvccpRecord.getFieldValue('created');
								var minPurchaseAmount=vvccpRecord.getFieldValue(FLD_MINIMUM_TO_SPEND);
								var authorizationAmount=vvccpRecord.getFieldValue(FLD_MAXIMUM_TO_SPEND);
								var cardTypeSingleOrMulti=vvccpRecord.getFieldValue(FLD_TYPE);
								var vvccpCurrency=vvccpRecord.getFieldValue(FLD_CURRENCY);
								//nlapiLogExecution('debug','vvccpCurrency:',vvccpCurrency);
								
								var vvccpBatchLink=vvccpRecord.getFieldValue(FLD_VVCCP_BATCH_LINK);
								var creditCardType='';
								if(corporateCreditCard !=null && corporateCreditCard !='')
								{
									creditCardType=nlapiLookupField(CUSTOM_RECORD_CORPORATE_CREDIT_CARD,corporateCreditCard,FLD_CREDIT_CARD_TYPE);
									
								}
								var responseFile=vvccpRecord.getFieldValue(FLD_RESPONSE_FILE);
								var cancellationRequestFile=vvccpRecord.getFieldValue(FLD_CACELLATION_REQUEST_FILE);
								var normalRequestFile=vvccpRecord.getFieldValue(FLD_AUTHORIZATION_REQUEST_FILE);
								var authorizationReceiveDate=vvccpRecord.getFieldValue(FLD_AUTHORIZATION_RECEIVE_DATE);
								var vvccpPaymentGenerated='';
								var vvccpLinkedTransactions=[];
								if(amexTransactionType == 'A' && parseInt(amexStatusUpdate) == 0)
						         {
							vvccpStatus = VVCCP_STATUS_AUTHORIZED;
							
							nlapiAttachRecord('file', responseFileInCustomRecord, CUSTOM_RECORD_VVCCP, vvccpInternalId);
							if(responseFile == '' || responseFile == null)
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, vvccpInternalId, [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [responseFileInCustomRecord,VVCCP_STATUS_AUTHORIZED,'Success']);
							else
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, vvccpInternalId, [FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [responseFileInCustomRecord,VVCCP_STATUS_AUTHORIZED,'Success']);	
						}
						if(amexTransactionType == 'D' && parseInt(amexStatusUpdate) == 0)
						{
							vvccpStatus = VVCCP_STATUS_CANCELLATION_ACCEPTED;
							nlapiAttachRecord('file', responseFileInCustomRecord, CUSTOM_RECORD_VVCCP, vvccpInternalId);
							if(responseFile == '' || responseFile == null)
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, vvccpInternalId, [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [responseFileInCustomRecord,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);
							else
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, vvccpInternalId, [FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [responseFileInCustomRecord,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);	
						}
						if(parseInt(amexStatusUpdate) == 1)
						{
							nlapiAttachRecord('file', responseFileInCustomRecord, CUSTOM_RECORD_VVCCP, vvccpInternalId);
							if(amexErrorNumber != ' ' && amexErrorNumber != null && amexErrorNumber == '11001' && normalRequestFile !=null && normalRequestFile !='' && (cancellationRequestFile == null || cancellationRequestFile == ''))
							{
							vvccpStatus = VVCCP_STATUS_PENDING_BATCH;

								if(responseFile == '' || responseFile == null)
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_AUTHORIZATION_REQUEST_FILE],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_PENDING_BATCH,'']);
								else
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_AUTHORIZATION_REQUEST_FILE],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_PENDING_BATCH,'']);	
							}
							if(amexErrorNumber != '11001' && normalRequestFile !=null && normalRequestFile !='' && (cancellationRequestFile == null || cancellationRequestFile == ''))
							{
								vvccpStatus = VVCCP_STATUS_FAILED;
								if(responseFile == '' || responseFile == null)
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_FAILED]);
								else
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_FAILED]);	
							}
							
							if(amexErrorNumber != ' ' && amexErrorNumber != null && amexErrorNumber == '11001' && cancellationRequestFile !=null && cancellationRequestFile !='')
							{
								vvccpStatus = VVCCP_STATUS_PENDING_CANCEL;
								if(responseFile == '' || responseFile == null)
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_CACELLATION_REQUEST_FILE],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_PENDING_CANCEL,'']);
								else
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_CACELLATION_REQUEST_FILE],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_PENDING_CANCEL,'']);	
							}
							if(amexErrorNumber != '11001' && cancellationRequestFile !=null && cancellationRequestFile !='')
							{
								vvccpStatus = VVCCP_STATUS_FAILED;

								if(responseFile == '' || responseFile == null)
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_FAILED]);
								else
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_RESPONSE_MESSAGE,FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS],[(amexErrorNumber+amexErrorDescription),responseFileInCustomRecord,VVCCP_STATUS_FAILED]);	
							}
							
							
							
							
						}
						nlapiLogExecution('debug','amexStatusUpdate :: vvccpStatus',amexStatusUpdate+'::'+vvccpStatus);
						var virtualCreditCardRecordId='';
						if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
						{
						virtualCreditCardRecordId=createVirtualCreditCard(vvccpInternalId,amexRow20AsCardNumber,amexResponseAsSecurityCode,amexExpirationDateAsResponse,CREDIT_CARD_TYPE_AMEX,true,null);
						nlapiLogExecution('debug','virtualCreditCardRecordId:Amex:',virtualCreditCardRecordId);
						if(virtualCreditCardRecordId !=null && virtualCreditCardRecordId !='')
						{
						virtualCreditCardRecordIdArray.push(virtualCreditCardRecordId)
						}
						var vvccpdfid = pdfsuitelet(vvccpInternalId);
							if (vvccpdfid == null)
								vvccpdfid == '';
							nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_VVCCP_PDF],[vvccpdfid]);	

						}
								
									
								if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
								{
									
                                  nlapiLogExecution('debug','originalAuthorization:',originalAuthorization);
								  var paymentRecordId=null;
                                  nlapiLogExecution('debug','vvccpStatus:',vvccpStatus);
                                  nlapiLogExecution('debug','originalAuthorization:',originalAuthorization);
									var pwpRecordObj = {};
									var uniqueBills = {};
									var uniqueCredits = {};
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
									columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
									var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
									var vendorbillobj={};
									var vendorbillamtobj = {};
									var vendorcreditobj = {};
									var vendorcreditarr=[];
									//nlapiLogExecution('debug','searchOnVVCCPLinkedTransactions:',searchOnVVCCPLinkedTransactions);
									var billIdReqForTransform='';
									if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
									{
                                      nlapiLogExecution('debug','searchOnVVCCPLinkedTransactions:',searchOnVVCCPLinkedTransactions);
										for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
										{
											var billsearchResult=searchOnVVCCPLinkedTransactions[b];
											var vvccpLinkedTransactionInternalId=billsearchResult.getId();
											vvccpLinkedTransactions.push(vvccpLinkedTransactionInternalId);
											var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
											if (transactionId)
												transactionId = transactionId+'';
											var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
											if (trnasactionLineAmount == null || trnasactionLineAmount == '')
												trnasactionLineAmount = 0;
											var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
											var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
											var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
											//nlapiLogExecution('debug','transactionTypes:',transactionTypes);

											if(transactionTypes == 17)
											{
												billIdReqForTransform=transactionId;
												pwpRecordObj[trnasactionLinePWP] = trnasactionLineAmount;
												if (!vendorbillobj.hasOwnProperty(transactionId))
												{
												vendorbillobj[transactionId] = [];
												vendorbillamtobj[transactionId] = parseFloat(trnasactionLineAmount);

												}
												else
												{
													var existingVBLineAmt = vendorbillamtobj[transactionId];
													existingVBLineAmt = parseFloat(existingVBLineAmt) + parseFloat(trnasactionLineAmount)
													vendorbillamtobj[transactionId] = existingVBLineAmt;
													
												}
												vendorbillobj[transactionId].push(transactionLineId+'|'+trnasactionLineAmount);
												
											}
											else
											{
												if (!vendorcreditobj.hasOwnProperty(transactionId))
												{
												vendorcreditobj[transactionId] = parseFloat(trnasactionLineAmount);

												}
												else
												{

													var existingVCAmt = vendorcreditobj[transactionId];
													existingVCAmt = parseFloat(existingVCAmt) + parseFloat(trnasactionLineAmount)
													vendorcreditobj[transactionId] = existingVCAmt;
												}

												if (vendorcreditarr.indexOf(transactionId) == -1)
													vendorcreditarr.push(transactionId);
											}
										}
									}
									
									
									if(originalAuthorization == '' || originalAuthorization == null )
									{
									var vendorPaymentRecord=nlapiTransformRecord('vendorbill', billIdReqForTransform, 'vendorpayment', {'recordmode':'dynamic'});
									//var vendorPaymentRecord=nlapiTransformRecord('vendor', vendor, 'vendorpayment',{'recordmode':'dynamic'})
									//vendorPaymentRecord.setFieldValue('entity',vendor);
									if(creditCardType == CREDIT_CARD_TYPE_AMEX && amexAccountFromCommanyPreference !=null && amexAccountFromCommanyPreference !='')
									{
									if(vvccpCurrency == 3)
									vendorPaymentRecord.setFieldValue('account',994);
									else
									vendorPaymentRecord.setFieldValue('account',amexAccountFromCommanyPreference);
									}
									if(creditCardType == CREDIT_CARD_TYPE_MASTERCARD && masterCardAccountFromCommanyPreference !=null && masterCardAccountFromCommanyPreference !='')
									vendorPaymentRecord.setFieldValue('account',masterCardAccountFromCommanyPreference);
									if(authorizationReceiveDate !='' && authorizationReceiveDate !=null)
									vendorPaymentRecord.setFieldValue('trandate',authorizationReceiveDate);
									vendorPaymentRecord.setFieldValue('tranid',vvccpName);
									vendorPaymentRecord.setFieldValue('memo','VVCCP Payment Generated');
									vendorPaymentRecord.setFieldValue('approvalstatus',VENDOR_PAYMENT_STATUS_APPROVEED_ID);
									vendorPaymentRecord.setFieldValue(FLD_VVCCP_BACKLINK,vvccpInternalId);
									var linecount=vendorPaymentRecord.getLineItemCount('apply');
									nlapiLogExecution('debug','linecount:',linecount);
									if(linecount>0)
									{
										for(var k=1;k<=linecount;k++)
											{
												var tranId=vendorPaymentRecord.getLineItemValue('apply','doc',k);
												var payment=vendorPaymentRecord.getLineItemValue('apply','amount',k);
												var type=vendorPaymentRecord.getLineItemValue('apply','type',k);
												nlapiLogExecution('debug','type:',type);
												nlapiLogExecution('debug','payment:',payment);
												nlapiLogExecution('debug','tranId:',tranId);
												for(var vbprop in vendorbillamtobj)
												{
													if(parseInt(tranId) == parseInt(vbprop))
													{
														//nlapiLogExecution('debug','matching bill id:',vbprop+':_:'+vendorbillobj[vbprop].amount);
														vendorPaymentRecord.selectLineItem('apply',k);
														vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
														vendorPaymentRecord.setCurrentLineItemValue('apply','amount',parseFloat(vendorbillamtobj[vbprop]));
														vendorPaymentRecord.commitLineItem('apply');
													}
												}
												for(var vcprop in vendorcreditobj)
												{
													if(parseInt(tranId) == parseInt(vcprop))
													{
														nlapiLogExecution('debug','matching bill credit id with Amount:',vcprop+':_:'+vendorcreditobj[vcprop].amount);
														vendorPaymentRecord.selectLineItem('apply',k);
														vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
														vendorPaymentRecord.setCurrentLineItemValue('apply','amount',-parseFloat(vendorcreditobj[vcprop]));
														vendorPaymentRecord.commitLineItem('apply');
													}
												}
											}
									}
									paymentRecordId=nlapiSubmitRecord(vendorPaymentRecord,true,true);
									}
									else
									{
										nlapiLogExecution('debug','virtualCreditCardRecordIdArray.length',virtualCreditCardRecordIdArray.length)
										if(virtualCreditCardRecordId !=null && virtualCreditCardRecordId !='')
										{
										var oldfilters=[];
										oldfilters.push(new nlobjSearchFilter(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD, null, 'anyof', originalAuthorization));
										var searchOnVirtualCreditCardRecord=getAllSearchResults(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD, oldfilters, null);
										if(searchOnVirtualCreditCardRecord !=null && searchOnVirtualCreditCardRecord !='')
										{
											
												var virtualCreditRecordIdold=searchOnVirtualCreditCardRecord[0].getId();
												var oldpaymentRecordId=nlapiLookupField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditRecordIdold,FLD_VENDOR_PAYMENT_LINK);
										//var virtualCreditRecordId=virtualCreditCardRecordIdArray[0];
										nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditCardRecordId,[FLD_VENDOR_PAYMENT_LINK],[oldpaymentRecordId])

										}
										}
									}
									
									
						
									nlapiLogExecution('debug','paymentRecordId:',paymentRecordId);
									nlapiLogExecution('debug','vvccpLinkedTransactions:',vvccpLinkedTransactions);
									//4.ii(a)
									if(originalAuthorization == '' || originalAuthorization == null )
									{
									if(paymentRecordId !=null && paymentRecordId !='')
									{
										for(var v=0;vvccpLinkedTransactions.length > 0 && v<vvccpLinkedTransactions.length;v++)
											{
												nlapiSubmitField(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS,vvccpLinkedTransactions[v],[FLD_PAYMENT_LINK],[paymentRecordId]);
												if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
											}
										if(virtualCreditCardRecordId)
										{
												nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditCardRecordId,[FLD_VENDOR_PAYMENT_LINK],[paymentRecordId])
											
										}
										if (vendorcreditarr.length>0)
										{
											for (var w = 0; w < vendorcreditarr.length; w++)
											{
												
												nlapiSubmitField('vendorcredit', vendorcreditarr[w], FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
												if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
												
												}
											}
										}
										
										
										for (var vbprop in vendorbillobj)
										{
											try{
											var vbRecord = nlapiLoadRecord('vendorbill', vbprop);
											for (var e = 0; e < vendorbillobj[vbprop].length; e++)
											{
												var lineIdofBill = vendorbillobj[vbprop][e].split('|')[0];
												var linePayAmtofBill = vendorbillobj[vbprop][e].split('|')[1];

												var hasvbline = vbRecord.findLineItemValue('item', FLD_VB_LINE_ID, lineIdofBill);
												if (hasvbline != -1)
												{
													vbRecord.selectLineItem('item', hasvbline);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
													var existingBillLinePaymentAmount=vbRecord.getCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT);
													if(existingBillLinePaymentAmount == null || existingBillLinePaymentAmount == '')
														existingBillLinePaymentAmount=0;
													var amountTosetInBillLinePaymentAmountLineField=parseFloat(existingBillLinePaymentAmount)+parseFloat(linePayAmtofBill);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT, amountTosetInBillLinePaymentAmountLineField);
													vbRecord.commitLineItem('item');
													
												}
												
											}
											nlapiSubmitRecord(vbRecord, true, true);
											}
											catch (ef)
											{
												
											}
											if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
										}
									
										
									}
									}
							
							
							//end of status as Authorized VVCCP
							
							
								
							
							if(vvccpStatus == VVCCP_STATUS_CANCELLATION_ACCEPTED)
							{
								
								nlapiLogExecution('debug','coming cancel block:');
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_VENDOR_PAYMENT_LINK))
									columns.push(new nlobjSearchColumn(FLD_CARD_CANCELLED))
									var searchOnVirtualCreditCardRecord=getAllSearchResults(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD, filters, columns);
									var paymentLinkedToVirtualCreditCard='';
									var cancelCheckboxOnVirtualCreditCard='';
									var internalidOfVirtualCreditCard='';
									if(searchOnVirtualCreditCardRecord)
									{
										paymentLinkedToVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getValue(FLD_VENDOR_PAYMENT_LINK);
										cancelCheckboxOnVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getValue(FLD_CARD_CANCELLED);
										internalidOfVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getId();
									}
					
									//i.Void Vendor Payment Record Linked to the Virtual Credit Card 
									if(paymentLinkedToVirtualCreditCard !=null && paymentLinkedToVirtualCreditCard!='')
									var voidingId = nlapiVoidTransaction('vendorpayment', paymentLinkedToVirtualCreditCard);
								  if(voidingId)
									nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_VOID_JOURNAL],[voidingId]);
									nlapiLogExecution('debug','voidingId:',voidingId);
								
									//ii.Unapplying the vendor credit from the vendor bills
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
									columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
									var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
									if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
									{
										for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
										{
											var billsearchResult=searchOnVVCCPLinkedTransactions[b];
											var vvccpLinkedTransactionInternalId=billsearchResult.getId();
											var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
											var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
											var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
											var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
											var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
											//nlapiLogExecution('debug',':transactionTypes',transactionTypes);
											if(transactionTypes == 20)
											{
												//nlapiLogExecution('debug',':transactionId',transactionId);
												var vvccpLinkedTransaction=nlapiLoadRecord('vendorcredit',transactionId);
												var applylinecount=vvccpLinkedTransaction.getLineItemCount('apply');
												for(var c=1;c<=applylinecount;c++)
												{
													var type_tran=vvccpLinkedTransaction.getLineItemValue('apply','type',c);
													//nlapiLogExecution('debug','id:',id);
													//nlapiLogExecution('debug','type:',type);
													if(type_tran == 'Vendor Bill')
													{
														vvccpLinkedTransaction.selectLineItem('apply',c);
														vvccpLinkedTransaction.setCurrentLineItemValue('apply','apply','F');
														
														vvccpLinkedTransaction.commitLineItem('apply');
													}
												}
												var vvccpLinkedTransactionId=nlapiSubmitRecord(vvccpLinkedTransaction,true,true);
											}
											else if(transactionTypes == 17)
											{
												
												 try {
												
											var vbRecord = nlapiLoadRecord('vendorbill', transactionId);
											

												var hasvbline = vbRecord.findLineItemValue('item', FLD_VB_LINE_ID, transactionLineId);
												if (hasvbline != -1)
												{
													vbRecord.selectLineItem('item', hasvbline);
													//vbRecord.setCurrentLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
													var existingBillLinePaymentAmount=vbRecord.getCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT);
													if(existingBillLinePaymentAmount == null || existingBillLinePaymentAmount == '')
														existingBillLinePaymentAmount=0;
													var amountTosetInBillLinePaymentAmountLineField=parseFloat(existingBillLinePaymentAmount)-parseFloat(trnasactionLineAmount);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT, amountTosetInBillLinePaymentAmountLineField);
													vbRecord.commitLineItem('item');
													
												}
												
											
											nlapiSubmitRecord(vbRecord, true, true);
												 }
												 catch (er)
												 {
													 
													 
												 }
											
											
												//iii.Update the PWP Records for Bills Linked to VVCCP Linked Transactions
												/*if(trnasactionLinePWP !=null && trnasactionLinePWP !='')
												{
														nlapiLogExecution('debug','trnasactionLinePWPmatching:',trnasactionLinePWP);
														var billLineAmountPaidFromPWPRecord=nlapiLookupField(CUSTOM_RECORD_PWP,trnasactionLinePWP,FLD_BILL_LINEAMOUNT_PAID);
														var amountAfterReduceTheVVCCPLineAmount=parseFloat(billLineAmountPaidFromPWPRecord)-parseFloat(trnasactionLineAmount);
														nlapiSubmitField(CUSTOM_RECORD_PWP,trnasactionLinePWP,[FLD_BILL_LINEAMOUNT_PAID],[amountAfterReduceTheVVCCPLineAmount]);
												}*/
											}
											if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
										}
									}	
									//iv.Update Record Type = Virtual Credit Card 
									if(internalidOfVirtualCreditCard !=null && internalidOfVirtualCreditCard !='')
									{
										nlapiLogExecution('debug','internalidOfVirtualCreditCard:',internalidOfVirtualCreditCard);
										nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_CARD_CANCELLED],['T']);
									}
							}//end of status as Cancellation Accepted VVCCP
							
							
							
                              vvccpProcessed++;	
							resultFile+=vvccpInternalId+','+vvccpName+','+'Success,'+''+'\n'
								}
								else if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
								{
									resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+'Failed To Process the response because the VVCCP already Authorized'+'\n'
									errorDetails=errorDetails+'--> '+vvccpName+' : ' + 'has already been authorized with a virtual credit card'+'\n';
									vvccpFailed=parseInt(vvccpFailed)+1;
								}
                             }
									catch(e)
									{
										if(e instanceof nlobjError)
										{	
										nlapiLogExecution('debug','failed to process response file for: '+vvccpName,e.getDetails());
										errorDetails= errorDetails +'--> '+vvccpName+' : Failed due to: ' +e.getDetails()+'\n';
										resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+e.getDetails()+'\n';

										vvccpFailed=parseInt(vvccpFailed)+1;
										}
										else
										{
											resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+e.toString()+'\n';
										nlapiLogExecution('debug','failed to process response file for: '+vvccpName,e.toString());
										errorDetails= errorDetails +'--> '+vvccpName+' : Failed due to: ' +e.toString()+'\n';
										vvccpFailed=parseInt(vvccpFailed)+1;
										}
										

									}


                        var vvccpProcessResponseOrReconFileProcessingLogRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId);

						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValues(FLD_VIRTUAL_CARD_LINK,virtualCreditCardRecordIdArray);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_VVCCP_PROCESSED,vvccpProcessed);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_VVCCP_FAILED,vvccpFailed);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_ERROR_LOG,errorDetails);
						
							vvccpProcessedPercentage=((parseInt(vvccpFailed)+parseInt(vvccpProcessed))/parseInt(vvccpToProcess))*100;
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_PROCESSED_PERCENTAGE,vvccpProcessedPercentage);
						if(vvccpProcessedPercentage == 100)
						{
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_RESPONSE_FILE_PROCESSED,'T');
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_FILE_MOVED_TO_PROCESSED_FOLDER,'T');
						}
						if((errorDetails == '' || errorDetails == null) && vvccpProcessedPercentage == 100)
						{
							amexUnProcessedFile.setFolder(VVCCP_AMEX_RESPONSE_PROCESSED);
							nlapiSubmitFile(amexUnProcessedFile);
							
						}
						else if(errorDetails !=null && vvccpProcessedPercentage == 100)
						{
							amexUnProcessedFile.setFolder(VVCCP_AMEX_RESPONSE_PROCESSED_WITH_ERRORS);
							nlapiSubmitFile(amexUnProcessedFile);
						}
						if(resultFile != '' && resultFile !=null && vvccpProcessedPercentage == 100)
						{
							var resultFileDetails=nlapiCreateFile('Resultfile_Response_AMEX_'+timeStamp+'.csv','CSV',resultFile);
							
							resultFileDetails.setFolder(VVCCP_RESULT_FILE_CSV_FOLDER_ID_AMEX);
						    
							var resultFileDetailsID= nlapiSubmitFile(resultFileDetails);
							if(resultFileDetailsID)
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_RESPONSE_OR_RECON_RESULT_FILE,resultFileDetailsID);
						}
						
						nlapiSubmitRecord(vvccpProcessResponseOrReconFileProcessingLogRecord,true,true);
							
							} //end of vvccp int id
						}
						if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
						}
						
						}
						
						//Logic Ends : AMEX Response Processing
						
						
						//Logic Starts : MASTERCARD Response Processing
						if (cardProvider == CREDIT_CARD_TYPE_MASTERCARD)
						{
							var masterCardResponseFileId=responseFileInCustomRecord;
							var masterCardFile=nlapiLoadFile(masterCardResponseFileId);
							var masterCardValues=masterCardFile.getValue();
							masterCardValues=masterCardValues.split('\n');
							nlapiLogExecution('debug','masterCardValues:',masterCardValues);
							//nlapiLogExecution('debug','values lengthbefore spliting:',values.length);
							var vvccpToProcess=0;
							var vvccpProcessed=existingVVCCPProcessed;
							var errorDetails='';
						var vvccpFailed=existingVVCCPFailed;
							var vvccpProcessedPercentage = 0;
							var virtualCreditCardRecordIdArray=[];
							var numberOfVVCCPToProcess=[];
							var resultFile='';
							resultFile+='VVCCP INTERNALID,VVCCP NMAE,PROCESS STATUS,FAILURE REASON \n';
                          if(masterCardValues[masterCardValues.length-1] == null || masterCardValues[masterCardValues.length-1] == '')
							masterCardValues=masterCardValues.slice(0,-1);
							for(var q=1;q<masterCardValues.length;q++)
							{
								var columns=masterCardValues[q];
								var columnsValues=columns.split(',');
								var vvccpInternalId=columnsValues[17];
								if(vvccpInternalId !=null && vvccpInternalId !='' && vvccpInternalId != ' ')
								{
									vvccpInternalId=vvccpInternalId.trim();
								vvccpToProcess++;
								numberOfVVCCPToProcess.push(vvccpInternalId);
								}
							}
							
							nlapiSubmitField(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId,[FLD_VVCCP_TO_PROCESS,FLD_VVCCP_RECORD_LINK],[vvccpToProcess,numberOfVVCCPToProcess]);
                            
							for(var m=1;m<masterCardValues.length;m++)
							{
								var columns=masterCardValues[m];
								nlapiLogExecution('debug','columns:',columns);
								var columnsValues=columns.split(',');
								nlapiLogExecution('debug','columnsValues:',columnsValues);
								var actionType=columnsValues[0];
								var responseCode='';
								var vvccpInternalId='';
								var masterCardRow34AsCardNumber='';
								var masterCardResponseAsSecurityCode='';
								var masterCardExpirationDateAsResponse='';
								var masterCardPurchaseIdAsResponse='';
								var responseMessageEncoded='';
								if(actionType == 'CreateApprovedPurchase')
								{
								responseCode=columnsValues[27].toLowerCase();
								vvccpInternalId=columnsValues[17];
								masterCardRow34AsCardNumber=columnsValues[30];
								masterCardResponseAsSecurityCode=columnsValues[31];
								masterCardExpirationDateAsResponse=columnsValues[32];
								responseMessageEncoded=columnsValues[28];
								masterCardPurchaseIdAsResponse=columnsValues[29];
								}
								if(actionType == 'CancelApprovedPurchase')
								{
								responseCode=columnsValues[28].toLowerCase();
								vvccpInternalId=columnsValues[17];
								masterCardRow34AsCardNumber=columnsValues[31];
								masterCardResponseAsSecurityCode=columnsValues[32];
								masterCardExpirationDateAsResponse=columnsValues[33];
								responseMessageEncoded=columnsValues[29];
								masterCardPurchaseIdAsResponse=columnsValues[30];
								}
								if(masterCardExpirationDateAsResponse !=null && masterCardExpirationDateAsResponse !='' && masterCardExpirationDateAsResponse !=' ')
								masterCardExpirationDateAsResponse=masterCardExpirationDateAsResponse.toString();
								if(vvccpInternalId !=null && vvccpInternalId !='' && vvccpInternalId !='undefined' && vvccpInternalId !='null')
								{
									vvccpInternalId=vvccpInternalId.trim();
									var vvccpRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP,vvccpInternalId)
									var originalAuthorization=vvccpRecord.getFieldValue(FLD_ORIGINAL_AUTHORIZATION);
									var vendor=vvccpRecord.getFieldValue(FLD_VENDOR);
									nlapiLogExecution('debug','vvccpInternalId:',vvccpInternalId);
									nlapiLogExecution('debug','vendor:',vendor);
									var corporateCreditCard=vvccpRecord.getFieldValue(FLD_CORPORATE_CREDIT_CARD);
									var vvccpStatus=vvccpRecord.getFieldValue(FLD_VVCCP_STATUS);
									nlapiLogExecution('debug','vvccpStatus:',vvccpStatus);
									var vvccpName=vvccpRecord.getFieldValue('name');
									try{
									if(vvccpStatus == VVCCP_STATUS_PENDING_RESPONSE){	
									var vvccpDateCreated=vvccpRecord.getFieldValue('created');
									var minPurchaseAmount=vvccpRecord.getFieldValue(FLD_MINIMUM_TO_SPEND);
									var authorizationAmount=vvccpRecord.getFieldValue(FLD_MAXIMUM_TO_SPEND);
									var cardTypeSingleOrMulti=vvccpRecord.getFieldValue(FLD_TYPE);
									var vvccpCurrency=vvccpRecord.getFieldValue(FLD_CURRENCY);
									nlapiLogExecution('debug','vvccpCurrency:',vvccpCurrency);
									var vvccpBatchLink=vvccpRecord.getFieldValue(FLD_VVCCP_BATCH_LINK);
									var creditCardType='';
									if(corporateCreditCard !=null && corporateCreditCard !='')
									{
										creditCardType=nlapiLookupField(CUSTOM_RECORD_CORPORATE_CREDIT_CARD,corporateCreditCard,FLD_CREDIT_CARD_TYPE);
										
									}
									var responseFile=vvccpRecord.getFieldValue(FLD_RESPONSE_FILE);
									var cancellationRequestFile=vvccpRecord.getFieldValue(FLD_CACELLATION_REQUEST_FILE);
									var normalRequestFile=vvccpRecord.getFieldValue(FLD_AUTHORIZATION_REQUEST_FILE);
									var authorizationReceiveDate=vvccpRecord.getFieldValue(FLD_AUTHORIZATION_RECEIVE_DATE);
									var vvccpPaymentGenerated='';
									var vvccpLinkedTransactions=[];
									var virtualCreditCardRecordId;
									nlapiLogExecution('debug','actionType:',actionType);
									nlapiLogExecution('debug','responseCode:',responseCode);
									if(actionType == 'CreateApprovedPurchase' && responseCode == 'approved')
									{
										vvccpStatus = VVCCP_STATUS_AUTHORIZED;
										if(responseFile == null || responseFile == '')
										nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(vvccpInternalId), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_AUTHORIZED,'Success']);
										else
										nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(vvccpInternalId), [FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_AUTHORIZED,'Success']);	
									}
									if(actionType == 'CancelApprovedPurchase' && responseCode == 'canceled')
									{
										vvccpStatus = VVCCP_STATUS_CANCELLATION_ACCEPTED;
										if(responseFile == null || responseFile == '')
										nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(vvccpInternalId), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);
										else
										nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(vvccpInternalId), [FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);	
									}
									if(responseCode != 'approved' && responseCode != 'canceled')
									{
										var vvccpFieldsArrForMasterCardType=[];
										var vvccpValuesArrForMasterCardType=[];
										if(responseMessageEncoded != '11001')
										{
											vvccpStatus = VVCCP_STATUS_FAILED;
											if(responseFile == null || responseFile == '')
											{
												
											vvccpFieldsArrForMasterCardType=[FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE];
											vvccpValuesArrForMasterCardType=[masterCardResponseFileId,VVCCP_STATUS_FAILED,responseMessageEncoded];
											}
											else
											{
												vvccpFieldsArrForMasterCardType=[FLD_CACELLATION_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE];
												vvccpValuesArrForMasterCardType=[masterCardResponseFileId,VVCCP_STATUS_FAILED,responseMessageEncoded];
											}
										}
										else
										{
											if(responseFile == null || responseFile == '')
											{
											vvccpFieldsArrForMasterCardType=[FLD_RESPONSE_FILE,FLD_RESPONSE_MESSAGE];
											vvccpValuesArrForMasterCardType=[masterCardResponseFileId,responseMessageEncoded];
											}
											else
											{
												vvccpFieldsArrForMasterCardType=[FLD_CACELLATION_RESPONSE_FILE,FLD_RESPONSE_MESSAGE];
												vvccpValuesArrForMasterCardType=[masterCardResponseFileId,responseMessageEncoded];
											}
										}
										nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(vvccpInternalId), vvccpFieldsArrForMasterCardType, vvccpValuesArrForMasterCardType);
									}
									
									
									if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
									{
										nlapiLogExecution('debug','coming vvccp update block:');
										virtualCreditCardRecordId=createVirtualCreditCard(vvccpInternalId,masterCardRow34AsCardNumber,masterCardResponseAsSecurityCode,masterCardExpirationDateAsResponse,CREDIT_CARD_TYPE_MASTERCARD,false,masterCardPurchaseIdAsResponse);
										nlapiLogExecution('debug','virtualCreditCardRecordId:MasterCard:',virtualCreditCardRecordId);
										if(virtualCreditCardRecordId !=null && virtualCreditCardRecordId !='')
										{
											virtualCreditCardRecordIdArray.push(virtualCreditCardRecordId)
										}
										nlapiLogExecution('debug','coming after virual creation');
										var vvccpdfid = pdfsuitelet(vvccpInternalId);
										if (vvccpdfid == null)
										vvccpdfid == '';
										nlapiSubmitField(CUSTOM_RECORD_VVCCP,vvccpInternalId,[FLD_VVCCP_PDF],[vvccpdfid]);	
nlapiLogExecution('debug','coming after pdf creation');
									}
									nlapiLogExecution('debug','coming after updating vvccp creation');
								if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
								{
									nlapiLogExecution('debug','coming payment creation block:');
									
                                  nlapiLogExecution('debug','originalAuthorization:',originalAuthorization);
								  var paymentRecordId=null;
                                  nlapiLogExecution('debug','vvccpStatus:',vvccpStatus);
                                  nlapiLogExecution('debug','originalAuthorization:',originalAuthorization);
									var pwpRecordObj = {};
									var uniqueBills = {};
									var uniqueCredits = {};
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
									columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
									var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
									var vendorbillobj={};
									var vendorbillamtobj = {};
									var vendorcreditobj = {};
									var vendorcreditarr=[];
									nlapiLogExecution('debug','searchOnVVCCPLinkedTransactions:',searchOnVVCCPLinkedTransactions);
									var billIdReqForTransform='';
									if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
									{
                                      nlapiLogExecution('debug','searchOnVVCCPLinkedTransactions:',searchOnVVCCPLinkedTransactions);
										for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
										{
											var billsearchResult=searchOnVVCCPLinkedTransactions[b];
											var vvccpLinkedTransactionInternalId=billsearchResult.getId();
											vvccpLinkedTransactions.push(vvccpLinkedTransactionInternalId);
											var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
											if (transactionId)
												transactionId = transactionId+'';
											var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
											if (trnasactionLineAmount == null || trnasactionLineAmount == '')
												trnasactionLineAmount = 0;
											var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
											var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
											var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
											//nlapiLogExecution('debug','transactionTypes:',transactionTypes);

											if(transactionTypes == 17)
											{
												billIdReqForTransform=transactionId;
												pwpRecordObj[trnasactionLinePWP] = trnasactionLineAmount;
												if (!vendorbillobj.hasOwnProperty(transactionId))
												{
												vendorbillobj[transactionId] = [];
												vendorbillamtobj[transactionId] = parseFloat(trnasactionLineAmount);

												}
												else
												{
													var existingVBLineAmt = vendorbillamtobj[transactionId];
													existingVBLineAmt = parseFloat(existingVBLineAmt) + parseFloat(trnasactionLineAmount)
													vendorbillamtobj[transactionId] = existingVBLineAmt;
													
												}
												vendorbillobj[transactionId].push(transactionLineId+'|'+trnasactionLineAmount);
												
											}
											else
											{
												if (!vendorcreditobj.hasOwnProperty(transactionId))
												{
												vendorcreditobj[transactionId] = parseFloat(trnasactionLineAmount);

												}
												else
												{

													var existingVCAmt = vendorcreditobj[transactionId];
													existingVCAmt = parseFloat(existingVCAmt) + parseFloat(trnasactionLineAmount)
													vendorcreditobj[transactionId] = existingVCAmt;
												}

												if (vendorcreditarr.indexOf(transactionId) == -1)
													vendorcreditarr.push(transactionId);
											}
										}
									}
									
									
									if(originalAuthorization == '' || originalAuthorization == null )
									{
									var vendorPaymentRecord=nlapiTransformRecord('vendorbill', billIdReqForTransform, 'vendorpayment', {'recordmode':'dynamic'});
									//var vendorPaymentRecord=nlapiTransformRecord('vendor', vendor, 'vendorpayment',{'recordmode':'dynamic'})
									//vendorPaymentRecord.setFieldValue('entity',vendor);
									if(creditCardType == CREDIT_CARD_TYPE_AMEX && amexAccountFromCommanyPreference !=null && amexAccountFromCommanyPreference !='')
									{
									if(vvccpCurrency == 3)
									vendorPaymentRecord.setFieldValue('account',994);
									else
									vendorPaymentRecord.setFieldValue('account',amexAccountFromCommanyPreference);
									}
									if(creditCardType == CREDIT_CARD_TYPE_MASTERCARD && masterCardAccountFromCommanyPreferenceUSA !=null && masterCardAccountFromCommanyPreferenceUSA !='' && vvccpCurrency == 1)
									vendorPaymentRecord.setFieldValue('account',masterCardAccountFromCommanyPreferenceUSA);
									else
									vendorPaymentRecord.setFieldValue('account',masterCardAccountFromCommanyPreferenceCAD);	
									if(authorizationReceiveDate !='' && authorizationReceiveDate !=null)
									vendorPaymentRecord.setFieldValue('trandate',authorizationReceiveDate);
									vendorPaymentRecord.setFieldValue('tranid',vvccpName);
									vendorPaymentRecord.setFieldValue('memo','VVCCP Payment Generated');
									vendorPaymentRecord.setFieldValue('approvalstatus',VENDOR_PAYMENT_STATUS_APPROVEED_ID);
									vendorPaymentRecord.setFieldValue(FLD_VVCCP_BACKLINK,vvccpInternalId);
									var linecount=vendorPaymentRecord.getLineItemCount('apply');
									nlapiLogExecution('debug','linecount:',linecount);
									if(linecount>0)
									{
										for(var k=1;k<=linecount;k++)
											{
												var tranId=vendorPaymentRecord.getLineItemValue('apply','doc',k);
												var payment=vendorPaymentRecord.getLineItemValue('apply','amount',k);
												var type=vendorPaymentRecord.getLineItemValue('apply','type',k);
												nlapiLogExecution('debug','type:',type);
												nlapiLogExecution('debug','payment:',payment);
												nlapiLogExecution('debug','tranId:',tranId);
												for(var vbprop in vendorbillamtobj)
												{
													if(parseInt(tranId) == parseInt(vbprop))
													{
														//nlapiLogExecution('debug','matching bill id:',vbprop+':_:'+vendorbillobj[vbprop].amount);
														vendorPaymentRecord.selectLineItem('apply',k);
														vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
														vendorPaymentRecord.setCurrentLineItemValue('apply','amount',parseFloat(vendorbillamtobj[vbprop]));
														vendorPaymentRecord.commitLineItem('apply');
													}
												}
												for(var vcprop in vendorcreditobj)
												{
													if(parseInt(tranId) == parseInt(vcprop))
													{
														nlapiLogExecution('debug','matching bill credit id with Amount:',vcprop+':_:'+vendorcreditobj[vcprop].amount);
														vendorPaymentRecord.selectLineItem('apply',k);
														vendorPaymentRecord.setCurrentLineItemValue('apply','apply','T');
														vendorPaymentRecord.setCurrentLineItemValue('apply','amount',-parseFloat(vendorcreditobj[vcprop]));
														vendorPaymentRecord.commitLineItem('apply');
													}
												}
											}
									}
									paymentRecordId=nlapiSubmitRecord(vendorPaymentRecord,true,true);
									}
									else
									{
										nlapiLogExecution('debug','virtualCreditCardRecordIdArray.length',virtualCreditCardRecordIdArray.length)
										if(virtualCreditCardRecordId !=null && virtualCreditCardRecordId !='')
										{
										var oldfilters=[];
										oldfilters.push(new nlobjSearchFilter(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD, null, 'anyof', originalAuthorization));
										var searchOnVirtualCreditCardRecord=getAllSearchResults(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD, oldfilters, null);
										if(searchOnVirtualCreditCardRecord !=null && searchOnVirtualCreditCardRecord !='')
										{
											
												var virtualCreditRecordIdold=searchOnVirtualCreditCardRecord[0].getId();
												var oldpaymentRecordId=nlapiLookupField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditRecordIdold,FLD_VENDOR_PAYMENT_LINK);
										//var virtualCreditRecordId=virtualCreditCardRecordIdArray[0];
										nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditCardRecordId,[FLD_VENDOR_PAYMENT_LINK],[oldpaymentRecordId])

										}
										}
									}
									
									nlapiLogExecution('debug','paymentRecordId:',paymentRecordId);
									nlapiLogExecution('debug','vvccpLinkedTransactions:',vvccpLinkedTransactions);
									//4.ii(a)
									if(originalAuthorization == '' || originalAuthorization == null )
									{
									if(paymentRecordId !=null && paymentRecordId !='')
									{
										for(var v=0;vvccpLinkedTransactions.length > 0 && v<vvccpLinkedTransactions.length;v++)
											{
												nlapiSubmitField(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS,vvccpLinkedTransactions[v],[FLD_PAYMENT_LINK],[paymentRecordId]);
												if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
											}
										if(virtualCreditCardRecordId)
										{
												nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,virtualCreditCardRecordId,[FLD_VENDOR_PAYMENT_LINK],[paymentRecordId])
											
										}
										if (vendorcreditarr.length>0)
										{
											for (var w = 0; w < vendorcreditarr.length; w++)
											{
												
												nlapiSubmitField('vendorcredit', vendorcreditarr[w], FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
												if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
												
											}
										}
										
										
										for (var vbprop in vendorbillobj)
										{
											try{
											var vbRecord = nlapiLoadRecord('vendorbill', vbprop);
											for (var e = 0; e < vendorbillobj[vbprop].length; e++)
											{
												var lineIdofBill = vendorbillobj[vbprop][e].split('|')[0];
												var linePayAmtofBill = vendorbillobj[vbprop][e].split('|')[1];

												var hasvbline = vbRecord.findLineItemValue('item', FLD_VB_LINE_ID, lineIdofBill);
												if (hasvbline != -1)
												{
													vbRecord.selectLineItem('item', hasvbline);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
													var existingBillLinePaymentAmount=vbRecord.getCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT);
													if(existingBillLinePaymentAmount == null || existingBillLinePaymentAmount == '')
														existingBillLinePaymentAmount=0;
													var amountTosetInBillLinePaymentAmountLineField=parseFloat(existingBillLinePaymentAmount)+parseFloat(linePayAmtofBill);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT, amountTosetInBillLinePaymentAmountLineField);
													vbRecord.commitLineItem('item');
													
												}
												
											}
											nlapiSubmitRecord(vbRecord, true, true);
											}
											catch (ee)
											{
												
											}
											if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
											
										}
									
									}
									}
							
							
							
						}    //end of status as Authorized VVCCP
						
							if(vvccpStatus == VVCCP_STATUS_CANCELLATION_ACCEPTED)
							{
								
								nlapiLogExecution('debug','coming cancel block:');
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_VENDOR_PAYMENT_LINK))
									columns.push(new nlobjSearchColumn(FLD_CARD_CANCELLED))
									var searchOnVirtualCreditCardRecord=getAllSearchResults(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD, filters, columns);
									var paymentLinkedToVirtualCreditCard='';
									var cancelCheckboxOnVirtualCreditCard='';
									var internalidOfVirtualCreditCard='';
									if(searchOnVirtualCreditCardRecord)
									{
										paymentLinkedToVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getValue(FLD_VENDOR_PAYMENT_LINK);
										cancelCheckboxOnVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getValue(FLD_CARD_CANCELLED);
										internalidOfVirtualCreditCard=searchOnVirtualCreditCardRecord[0].getId();
									}
					
									//i.Void Vendor Payment Record Linked to the Virtual Credit Card 
									if(paymentLinkedToVirtualCreditCard !=null && paymentLinkedToVirtualCreditCard!='')
									var voidingId = nlapiVoidTransaction('vendorpayment', paymentLinkedToVirtualCreditCard);
									if(voidingId)
									nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_VOID_JOURNAL],[voidingId]);
									nlapiLogExecution('debug','voidingId:',voidingId);
								
									//ii.Unapplying the vendor credit from the vendor bills
									var filters=[];
									var columns=[];
									filters.push(new nlobjSearchFilter(FLD_VVCCP_LINK, null, 'anyof', vvccpInternalId));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK))
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
									columns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
									columns.push(new nlobjSearchColumn(FLD_LINKED_TRANSACTION_TYPE));
									var searchOnVVCCPLinkedTransactions=getAllSearchResults(CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS, filters, columns)
									if(searchOnVVCCPLinkedTransactions !=null && searchOnVVCCPLinkedTransactions !='')
									{
										for(var b=0;b<searchOnVVCCPLinkedTransactions.length;b++)
										{
											var billsearchResult=searchOnVVCCPLinkedTransactions[b];
											var vvccpLinkedTransactionInternalId=billsearchResult.getId();
											var transactionId=billsearchResult.getValue(FLD_TRANSACTION_LINK);
											var trnasactionLineAmount=billsearchResult.getValue(FLD_TRANSACTION_LINE_AMOUNT);
											var trnasactionLinePWP=billsearchResult.getValue(FLD_TRANSACTION_LINE_PWP);
											var transactionTypes=billsearchResult.getValue(FLD_LINKED_TRANSACTION_TYPE);
											var transactionLineId=billsearchResult.getValue(FLD_TRANSACTION_LINE_ID);
											//nlapiLogExecution('debug',':transactionTypes',transactionTypes);
											if(transactionTypes == 20)
											{
												//nlapiLogExecution('debug',':transactionId',transactionId);
												var vvccpLinkedTransaction=nlapiLoadRecord('vendorcredit',transactionId);
												var applylinecount=vvccpLinkedTransaction.getLineItemCount('apply');
												for(var c=1;c<=applylinecount;c++)
												{
													var type_tran=vvccpLinkedTransaction.getLineItemValue('apply','type',c);
													//nlapiLogExecution('debug','id:',id);
													//nlapiLogExecution('debug','type:',type);
													if(type_tran == 'Vendor Bill')
													{
														vvccpLinkedTransaction.selectLineItem('apply',c);
														vvccpLinkedTransaction.setCurrentLineItemValue('apply','apply','F');
														
														vvccpLinkedTransaction.commitLineItem('apply');
													}
												}
												var vvccpLinkedTransactionId=nlapiSubmitRecord(vvccpLinkedTransaction,true,true);
											}
											else if(transactionTypes == 17)
											{
												
												try {
												
											var vbRecord = nlapiLoadRecord('vendorbill', transactionId);
											

												var hasvbline = vbRecord.findLineItemValue('item', FLD_VB_LINE_ID, transactionLineId);
												if (hasvbline != -1)
												{
													vbRecord.selectLineItem('item', hasvbline);
													//vbRecord.setCurrentLineItemValue('item', COL_FLD_PENDING_AUTHORIZATION_VVCCP, 'F');
													var existingBillLinePaymentAmount=vbRecord.getCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT);
													if(existingBillLinePaymentAmount == null || existingBillLinePaymentAmount == '')
														existingBillLinePaymentAmount=0;
													var amountTosetInBillLinePaymentAmountLineField=parseFloat(existingBillLinePaymentAmount)-parseFloat(trnasactionLineAmount);
													vbRecord.setCurrentLineItemValue('item', COL_FLD_BILL_LINE_PAYMENT_AMOUNT, amountTosetInBillLinePaymentAmountLineField);
													vbRecord.commitLineItem('item');
													
												}
												
											
											nlapiSubmitRecord(vbRecord, true, true);
												}
												catch (et)
												{
													
													
												}
											
											
												
											}
											if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
										}
									}	
									//iv.Update Record Type = Virtual Credit Card 
									if(internalidOfVirtualCreditCard !=null && internalidOfVirtualCreditCard !='')
									{
										nlapiLogExecution('debug','internalidOfVirtualCreditCard:',internalidOfVirtualCreditCard);
										nlapiSubmitField(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD,internalidOfVirtualCreditCard,[FLD_CARD_CANCELLED],['T']);
									}
							
							
							}  // end of vvccp with status cancellation accepted

							vvccpProcessed=parseInt(vvccpProcessed)+1;
							resultFile+=vvccpInternalId+','+vvccpName+','+'Success,'+''+'\n'
								}
						else if(vvccpStatus == VVCCP_STATUS_AUTHORIZED)
								{
									resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+'Failed To Process the response because the VVCCP already Authorized'+'\n'
									errorDetails=errorDetails+'--> '+vvccpName+' : ' + 'has already been authorized with a virtual credit card'+'\n';
									vvccpFailed=parseInt(vvccpFailed)+1;
								}
						}
													
								
									catch(e)
									{
										if(e instanceof nlobjError)
										{	
										nlapiLogExecution('debug','failed to process response file for: '+vvccpName,e.getDetails());
										errorDetails= errorDetails +'--> '+vvccpName+' : Failed due to: ' +e.getDetails()+'\n';
										resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+e.getDetails()+'\n';

										vvccpFailed=parseInt(vvccpFailed)+1;
										}
										else
										{
											resultFile+=vvccpInternalId+','+vvccpName+','+'Failed,'+e.toString()+'\n';
										nlapiLogExecution('debug','failed to process response file for: '+vvccpName,e.toString());
										errorDetails= errorDetails +'--> '+vvccpName+' : Failed due to: ' +e.toString()+'\n';
										vvccpFailed=parseInt(vvccpFailed)+1;
										}
										

									}
						var vvccpProcessResponseOrReconFileProcessingLogRecord=nlapiLoadRecord(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValues(FLD_VIRTUAL_CARD_LINK,virtualCreditCardRecordIdArray);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_VVCCP_PROCESSED,vvccpProcessed);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_VVCCP_FAILED,vvccpFailed);
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_ERROR_LOG,errorDetails);
						vvccpProcessedPercentage=((parseInt(vvccpFailed)+parseInt(vvccpProcessed))/parseInt(vvccpToProcess))*100;
						vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_PROCESSED_PERCENTAGE,vvccpProcessedPercentage);
						if(vvccpProcessedPercentage == 100)
						{
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_RESPONSE_FILE_PROCESSED,'T');
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_FILE_MOVED_TO_PROCESSED_FOLDER,'T');
						}
						if((errorDetails == '' || errorDetails == null) && vvccpProcessedPercentage == 100)
						{
							masterCardFile.setFolder(VVCCP_MASTERCARD_RESPONSE_PROCESSED);
							nlapiSubmitFile(masterCardFile);
						}
						else if(errorDetails !=null && vvccpProcessedPercentage == 100)
						{
							masterCardFile.setFolder(VVCCP_MASTERCARD_RESPONSE_PROCESSED_WITH_ERRORS);
							nlapiSubmitFile(masterCardFile);
						}							
						if(resultFile != '' && resultFile !=null && vvccpProcessedPercentage == 100)
							{
							var resultFileDetails=nlapiCreateFile('Resultfile_Response_Mastercard_'+timeStamp+'.csv','CSV',resultFile);
							resultFileDetails.setFolder(VVCCP_RESULT_FILE_CSV_FOLDER_ID_MASTERCARD);
							var resultFileDetailsID= nlapiSubmitFile(resultFileDetails);
							if(resultFileDetailsID)
							vvccpProcessResponseOrReconFileProcessingLogRecord.setFieldValue(FLD_RESPONSE_OR_RECON_RESULT_FILE,resultFileDetailsID);
							}
						nlapiSubmitRecord(vvccpProcessResponseOrReconFileProcessingLogRecord,true,true);
								
							}    //end of mastercard vvccp id not null not empty condition
						if(context.getRemainingUsage() < 2000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}	
						
					}   // end of master card file iteration
						}
					//Logic ends : MASTERCARD Response Processing
					}
					else
					{
						
					nlapiSubmitField(CUSTOM_RECORD_VVCCP_RESPONSE_FILE_PROCESSING_LOG,vvccpProcessResponseOrReconFileProcessingLogId,[FLD_RESPONSE_FILE_PROCESSED,FLD_ERROR_LOG],['T','Duplicate file found in log record "'+rSS[0].getId()+'", Not processed']);

						
					}
					
					
					
					}
					if((parseInt(l)+1) < responfileidValuesList.length)
						{
							var params = {};
							params[SPARAM_VVCP_RESPON_FILE_ID] = responfileid;
							params[SPARAM_VVCP_RESPON_FILE_INDEX] = parseInt(l)+1;
							nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
							break;
						}
						else
						{
							
							if (responfileid)
								nlapiDeleteFile(responfileid);
						}
				}
				}			
				
}
}
function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		
function searchUnion(target, array)
{
		return target.concat(array); // TODO: use _.union
}

function createVirtualCreditCard(vvccpInternalId,cardNumber,securityCode,expirationDate,provider,isAmex,masterCardPurchaseIdAsResponse)
{
	securityCode=securityCode.trim();
	vvccpInternalId=vvccpInternalId.trim();
	cardNumber=cardNumber.trim();
	expirationDate=expirationDate.trim();
	//Virtual Credit Card
	//Creating Custom Record Virtual Credit Card
	var virtualCreditCard=nlapiCreateRecord(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD);
	virtualCreditCard.setFieldValue(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD,vvccpInternalId);
	if(cardNumber!=null && cardNumber !='' && cardNumber !=' ')
	virtualCreditCard.setFieldValue(FLD_CARD_NUMBER,cardNumber);
	
	if(securityCode !=null && securityCode !='' && securityCode !=' ')
	{
		nlapiLogExecution('debug','securityCode:',securityCode)
		virtualCreditCard.setFieldValue(FLD_SECURITY_CODE,securityCode);
	}

	virtualCreditCard.setFieldValue(FLD_AUTHORIZATION_DATE,nlapiDateToString(new Date(),'datetimetz'));
	if(expirationDate !=null && expirationDate !='' && expirationDate !=' ')
	{
		var str = expirationDate;
		var yrPart='';
		var mnPart='';
		if(isAmex)
		{
		yrPart = str.slice(2,4);
		mnPart = str.slice(4);
		}
		else
		{	
		yrPart = str.slice(0,2);
		mnPart = str.slice(2);
		}
		var currentYear = new Date().getFullYear();
		  var currentYrPart = currentYear.toString().slice(0,2);
		  var revYear = Number(currentYrPart + yrPart);
		  var revMon = Number(mnPart)-1;
		  var revLastDay =new Date(revYear,  revMon+1, 0);
		  revLastDay=nlapiDateToString(revLastDay);
			nlapiLogExecution('debug','revLastDay',revLastDay);
		virtualCreditCard.setFieldValue(FLD_EXPIRATION_DATE,revLastDay);
	}
	if(provider !=null && provider!='' && provider!=' ')
	virtualCreditCard.setFieldValue(FLD_PROVIDER,provider);
	if(masterCardPurchaseIdAsResponse !=null && masterCardPurchaseIdAsResponse !='')
	virtualCreditCard.setFieldValue(FLD_PURCHASE_ID_MASTERCARD,masterCardPurchaseIdAsResponse);	
	var virtualCreditCardId=nlapiSubmitRecord(virtualCreditCard,true,true);
	
	return virtualCreditCardId;
}	



function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 20000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}
