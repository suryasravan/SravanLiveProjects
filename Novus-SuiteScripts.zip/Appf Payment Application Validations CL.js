/*
* Script Name : Appf Payment Application Validations CL
* Script Type : Client
* event type  : 
* Deployment  :
* Description : This script handles all the client side validations of Consolidated invoice Suitelet form
* 	Company   :	Appficiency Inc.
* 
* 9/18/2020  roach v2.  Validate account for client in each row
*/
var FLD_COL_SUBLIST = 'custpage_invoices';
//var FLD_COL_SUBLIST='custpage_columns';
var COL_SL_INVOICE_SUBLIST = 'custpage_invoices';

var COL_SL_INVOICE_SUBLIST_APPLIED = 'custpage_invoices_applied';
var COL_SL_CREDIT_SUBLIST_APPLIED = 'custpage_creditsublist_appled';

var COL_SL_CREDIT_SUBLIST = 'custpage_creditsublist';
var FLD_SL_PAYMENT_LINK = 'custpage_payment_link';
var COL_SL_LINE_FROM_PAYMENT = 'custpage_line_from_payment';

var COL_SL_INVOICE_MARK = 'custpage_checkbox_invoices';
var COL_SL_CREDIT_SUBLIST_FLD_MARK = 'custpage_checkbox_credit';
//var COL_SL_INVOICE_MARK='custpage_checkbox_invoices';
var COL_SL_INVOICE_LINES = 'custpage_checkbox_invoices';
var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_INVOICE_LINE_PROJECT = 'custpage_invoice_line_project';
var FLD_SL_CM_LINE_PROJECT = 'custpage_cm_line_project';

var FLD_SL_MEDIA_TYPE = 'custpage_media_type';
var FLD_SL_TRAN_DATE_FROM = 'custpage_tran_date_from';
var FLD_SL_TRAN_DATE_TO = 'custpage_tran_date_to';
var FLD_SL_CM_TRAN_DATE_FROM = 'custpage_tran_date_from_cm';
var FLD_SL_CM_TRAN_DATE_TO = 'custpage_tran_date_to_cm';
var FLD_SL_VENDOR = 'custpage_invoice_line_vendor';
var FLD_SL_CLIENT_CM = 'custpage_client_cm';
var FLD_SL_CHILED_CLIENTS_CM = 'custpage_child_clients_cm';
var FLD_SL_SRCH_TRACKER = 'custpage_srch_tracker';
var FLD_SL_TOTAL_SELECTED_LINES = 'custpage_total_selected_lines';

var FLD_SL_AVAILABLE_AMOUNT = 'custpage_paymet_available_amount';
var FLD_SL_INVOICE_LINE_MEDIA_SUPPLIER = 'custpage_invoice_line_media_supplier';
var FLD_SL_INVOICE_LINE_IO = 'custpage_invoice_line_io';
var FLD_SL_CM_LINE_IO = 'custpage_cm_line_io';

var FLD_SL_TRANSACTION_NUMBER = 'custpage_paymet_transaction_number';
var COL_SL_NATIVE_INVOICE_LINE_AMOUNT = 'custpage_invoice_line_level_amount';
var COL_SL_NATIVE_INVOICE_PAYMENT_AMOUNT = 'custpage_invoice_line_level_payment_amount';
var COL_SL_NATIVE_INVOICE_LINE_AMT_MINUS_PAYMENT_AMT = 'custcol_line_amt_minus_payment';
var COL_SL_NATIVE_INVOICE_LINE_AMOUNT_DUE = 'custpage_invoice_line_level_amount_due';
var FLD_SL_PAYMENT_AMOUNT = 'custpage_paymet_amount';
var FLD_SL_ACTION = 'custpage_action';
var SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID = 'customscript_client_paymt_application_sl';
var SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID = 'customdeploy_client_paymt_application_sl';

var FLD_SL_PAYMENT_CURRENCY = 'custpage_paymet_currency';
var FLD_SL_CONSOLIDATED_INVOICE_NUMBER = 'custpage_consolidated_invoice';
var FLD_SL_MEDIA_TYPE = 'custpage_media_type';
var FLD_SL_INVOICE_LINE_PROJECT = 'custpage_invoice_line_project';
var FLD_SL_TRAN_DATE = 'custpage_tran_date';
var FLD_SL_INVOICE_LINE_IO = 'custpage_invoice_line_io';
var FLD_SL_VENDOR = 'custpage_invoice_line_vendor';
var FLD_SL_INVOICE_LINE_MEDIA_SUPPLIER = 'custpage_invoice_line_media_supplier';
var FLD_SL_CHILD_CLIENTS = 'custpage_clients';
var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_TRANSACTION_NUMBER = 'custpage_paymet_transaction_number';
var FLD_SL_AVAILABLE_AMOUNT = 'custpage_paymet_available_amount';
var FLD_SL_PAYMENT_AMOUNT = 'custpage_paymet_amount';
var COL_SL_SUBLIST = 'custpage_invoices';
var SL_FLD_CONSOLIDATED_INVOICE = 'custpage_consolidated_invoices';
var COL_SL_INVOICE_MARK = 'custpage_checkbox_invoices';
var BTN_INVOICE_MARK_ALL = 'custpage_invoice_mark_all';
var BTN_INVOICE_UNMARK_ALL = 'custpage_invoice_unmark_all';
var COL_SL_INVOICE_INTERNAL_ID = 'custpage_invoiceid';
var COL_SL_CREDIT_SUBLIST_FLD_MARK = 'custpage_checkbox_credit';
var BTN_CREDIT_MARK_ALL = 'custpage_invoice_mark_all';
var BTN_CREDIT_UNMARK_ALL = 'custpage_invoice_unmark_all';
var COL_SL_CREDIT_INTERNAL_ID = 'custpage_creditid';

var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
var FLD_COL_INV_CI_RECORD = 'custcol_appf_ci_record';
var SL_TITLE = 'Client Payment Application SL';
var COL_SL_INVOICE_SUBLIST = 'custpage_invoices';
var FLD_GROUP_PAYMENT_DETAILS = 'custpage_payment_details';
var FLD_GROUP_INVOICE_CREDIT_FILTER = 'custpage_invoice_credit_filters';
var SL_FLD_CLIENT_INV = 'custpage_client_inv';
var SL_FLD_CLIENT_CM = 'custpage_client_cm';
var SL_FLD_AR_ACCOUNT = 'custpage_ar_account';
var SL_FLD_CURRENCY = 'custpage_currency';
var SL_FLD_DATE = 'custpage_date';
var SL_FLD_POSTING_PERIOD = 'custpage_posting_period';
var SL_FLD_MEMO = 'custpage_demo';
var SL_FLD_LINE_OF_BUSINESS = 'custpage_line_of_business';
var SL_FLD_DEPARTMENT = 'custpage_department';
var SL_FLD_OFFICE = 'custpage_office';

var FLD_SL_AVAILABLE_AMOUNT = 'custpage_paymet_available_amount';
var COL_SL_PAYMENT_AMOUNT = 'custpage_invoice_line_payment_amount';
var COL_SL_CREDIT_AMOUNT = 'custpage_credit_amount';
var FLD_SL_APPLIED_AMOUNT = 'custpage_applied_amount';
var COL_SL_TAX_AMOUNT = COL_SL_PAYMENT_AMOUNT + '_tax';
var COL_SL_TAX_RATE = 'custpage_scriptfield9';

var COL_SL_INVOICE_ACCOUNT = 'custpage_invoice_account';
var SRCH_SUMMARY = {};
var TOTAL_SELECTED = 0;
var TOTAL_APPLIED_INVOICES = 0;
var TOTAL_APPLIED_CREDITS = 0;
var TOTAL_APPLIED_AMT_INV = 0;
var TOTAL_APPLIED_AMT_CRED = 0;
var TOTAL_UNAPPLIED_INVOICES = 0;
var TOTAL_UNAPPLIED_CREDITS = 0;
var TOTAL_UNAPPLIED_AMT_INV = 0;
var TOTAL_UNAPPLIED_AMT_CRED = 0;
var IS_SELECTED = 'F';

//added by shravan kumar 12-10-2022
var FLD_SL_EXCLUDE_CONSOL_IN = 'custpage_exclude_from_consolidation';

//added by shravan kumar 12-10-2022
var FLD_SL_EXCLUDE_CONSOL_CM = 'custpage_exclude_from_consolidation_cm';

function pageinit () {
	SRCH_SUMMARY = JSON.parse( nlapiGetFieldValue( FLD_SL_SRCH_TRACKER ) );
	console.log( SRCH_SUMMARY );

	var itemCount = nlapiGetLineItemCount( FLD_COL_SUBLIST );
	if ( itemCount > 0 ) {
		for ( var f = 1; f <= itemCount; f++ ) {
			var taxAmtFld = document.getElementsByName( COL_SL_TAX_AMOUNT + f + '_formattedValue' );
			if ( taxAmtFld ) {
				if ( taxAmtFld.length > 0 ) {

					taxAmtFld[ 0 ].disabled = true;
					if ( taxAmtFld.length > 1 )
						taxAmtFld[ 1 ].disabled = true;

				}

			}

		}
	}

	var itemCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST_APPLIED );


	if ( itemCount > 0 ) {
		for ( var f = 1; f <= itemCount; f++ ) {
			var taxAmtFld = document.getElementsByName( COL_SL_TAX_AMOUNT + f + '_formattedValue' );
			if ( taxAmtFld ) {
				if ( taxAmtFld.length > 0 ) {

					taxAmtFld[ 0 ].disabled = true;
					if ( taxAmtFld.length > 1 )
						taxAmtFld[ 1 ].disabled = true;


				}

			}

		}
	}

	var vars = {};
	var parts = window.location.href.replace( /[?&]+([^=&]+)=([^&]*)/gi, function ( m, key, value ) {
		vars[ key ] = value;
	} );

	var paymentRecID = vars[ "recId" ];
	var initiateApplyFilters = vars[ "initiateApplyFilters" ];
	if ( paymentRecID != null && paymentRecID != '' && initiateApplyFilters == 'T' ) {
		applyFilters();

	}
	/*var paymentCount = nlapiGetLineItemCount(FLD_COL_SUBLIST);
	   var creditCount = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST);
	   var totPaymentApplied = 0;
	   var totCredit = 0;
	var totTaxAmount = 0;
	   for(var c=1; c<=paymentCount; c++){
		   if(nlapiGetLineItemValue(FLD_COL_SUBLIST, COL_SL_INVOICE_MARK, c) == 'T'){
		   totPaymentApplied = parseFloat(totPaymentApplied)+parseFloat(nlapiGetLineItemValue(FLD_COL_SUBLIST, COL_SL_PAYMENT_AMOUNT, c));
		   var taxAmt = nlapiGetLineItemValue(FLD_COL_SUBLIST, COL_SL_TAX_AMOUNT, c);
		   if(taxAmt == null || taxAmt == '')
			taxAmt = 0;
		   totTaxAmount = parseFloat(totTaxAmount)+parseFloat(taxAmt);
		 }
	   }
	   for(var c=1; c<=creditCount; c++){
		   if(nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, c) == 'T')
		   totCredit = parseFloat(totCredit)+parseFloat(nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, c));
	   }*/
	var paymentCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST_APPLIED );
	var creditCount = nlapiGetLineItemCount( COL_SL_CREDIT_SUBLIST_APPLIED );

	TOTAL_APPLIED_INVOICES = paymentCount;
	TOTAL_APPLIED_CREDITS = creditCount;
	TOTAL_SELECTED = Number( TOTAL_APPLIED_INVOICES ) + Number( TOTAL_APPLIED_CREDITS );

	var totPaymentApplied = 0;
	var totCredit = 0;
	var totTaxAmount = 0;
	var extLines = nlapiGetFieldValue( 'custpage_total_selected_lines' );
	if ( extLines == null || extLines == '' )
		extLines = 0;
	var extAmount = nlapiGetFieldValue( 'custpage_applied_amount' );
	if ( extAmount == null || extAmount == '' )
		extAmount = 0;

	for ( var c = 1; c <= paymentCount; c++ ) {
		totPaymentApplied = parseFloat( totPaymentApplied ) + parseFloat( nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, c ) );
		var taxAmt = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, c );
		if ( taxAmt == null || taxAmt == '' )
			taxAmt = 0;
		totTaxAmount = parseFloat( totTaxAmount ) + parseFloat( taxAmt );
	}
	for ( var c = 1; c <= creditCount; c++ ) {
		totCredit = parseFloat( totCredit ) + parseFloat( nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, c ) );
	}
	nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, parseFloat( ( parseFloat( totPaymentApplied ) - parseFloat( totCredit ) ) + parseFloat( extAmount ) ) );

	TOTAL_APPLIED_AMT_INV = totPaymentApplied;
	TOTAL_APPLIED_AMT_CRED = totCredit;


	var invApplied = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST_APPLIED );
	var credApplied = nlapiGetLineItemCount( COL_SL_CREDIT_SUBLIST_APPLIED );
	console.log( 'pageinit invApplied = ' + invApplied + ', credApplied = ' + credApplied );
	nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, Number( ( Number( invApplied ) + Number( credApplied ) ) + Number( extLines ) ) );

}

/* function validateField(type, name, linenum) {
    console.log('validateField, type = ' + type + ', name = ' + name + ', linenum = ' + linenum);
    if(
	   (type == COL_SL_INVOICE_SUBLIST && name == COL_SL_INVOICE_MARK) ||
	   (type == COL_SL_CREDIT_SUBLIST && name == COL_SL_CREDIT_SUBLIST_FLD_MARK)
    ) {
	   console.log('validateField, type = ' + type + ', name = ' + name);
	  var isLineSelect = nlapiGetCurrentLineItemValue(type, name);
	  if (isLineSelect == 'T') {
		 var total = Number(TOTAL_SELECTED) + 1;
		 if (total >= 10) {
			alert('You cannot apply this payment to more than 2,500 lines.');
			return false;
		 }
	  }
    }
    
    return true;
} */

/* function validateLine(type, name, linenum) {
    if(
	   (type == COL_SL_INVOICE_SUBLIST && name == COL_SL_INVOICE_MARK) ||
	   (type == COL_SL_CREDIT_SUBLIST && name == COL_SL_CREDIT_SUBLIST_FLD_MARK)
    ) {
	   console.log('validateField, type = ' + type + ', name = ' + name);
	  var isLineSelect = nlapiGetCurrentLineItemValue(type, name);
	  if (isLineSelect == 'T') {
		 var total = Number(TOTAL_SELECTED) + 1;
		 if (total >= 10) {
			alert('You cannot apply this payment to more than 2,500 lines.');
			return false;
		 }
	  }
    }
} */

function clientFieldChanged ( type, name, linenum ) {

	if ( type == COL_SL_INVOICE_SUBLIST && name == COL_SL_INVOICE_MARK ) {
		var paymentAmt = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT );
		var isLineSelect = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK );
		var isLineFromPayment = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_LINE_FROM_PAYMENT );
		var idInvoice = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_INTERNAL_ID );
		//var idAccount = nlapiGetCurrentLineItemValue(COL_SL_INVOICE_SUBLIST,COL_SL_INVOICE_ACCOUNT);

		//9/18/2020
		//console.log('idInvoice='+idInvoice+' isLineSelect='+ isLineSelect);
		if ( ( idInvoice != null && idInvoice != '' ) && isLineSelect == 'T' ) {
			var idHeaderAR = nlapiGetFieldValue( SL_FLD_AR_ACCOUNT );
			var idLineAR = nlapiLookupField( 'invoice', idInvoice, 'account' );

			//console.log('idHeaderAR='+idHeaderAR+' idLineAR='+ idLineAR);
			if ( idHeaderAR != idLineAR ) {
				alert( 'Please check Invoice AR account. Invoice account should be same with Client AR account.' );
				nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, 'F', false, false );
			}


		}

		if ( isLineSelect != 'T' && paymentAmt != null && paymentAmt != '' && isLineFromPayment != null && isLineFromPayment != '' ) {
			alert( 'Please zero out the existing payment value of the lines for any line that needs to be unselected' );
			nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, 'T', false, false );
		}

		/* if(isLineSelect != 'T' && paymentAmt != null && paymentAmt != '' && isLineFromPayment != null && isLineFromPayment != ''){
			alert('Please zero out the existing payment value of the lines for any line that needs to be unselected');
			nlapiSetCurrentLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, 'T', false, false);
		 }*/

	}

	if ( type == COL_SL_CREDIT_SUBLIST && name == COL_SL_CREDIT_SUBLIST_FLD_MARK ) {
		var creditAmt = nlapiGetCurrentLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT );
		var isLineSelect = nlapiGetCurrentLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK );
		var isLineFromPayment = nlapiGetCurrentLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_LINE_FROM_PAYMENT + '_cr' );

		if ( isLineSelect != 'T' && creditAmt != null && creditAmt != '' && isLineFromPayment != null && isLineFromPayment != '' ) {
			alert( 'Please zero out the existing Credit Amount value of the lines for any line that needs to be unselected' );
			nlapiSetCurrentLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, 'T', false, false );
		}
	}

	if ( name == COL_SL_PAYMENT_AMOUNT && type == COL_SL_INVOICE_SUBLIST ) {

		var invoiceAmt = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT );
		var taxRate = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_RATE );
		if ( taxRate == null || taxRate == '' ) {
			nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_AMOUNT, '' );
		}
		else {
			if ( invoiceAmt == null || invoiceAmt == '' )
				invoiceAmt = 0;
			var taxAmtCalc = parseFloat( invoiceAmt ) - ( parseFloat( invoiceAmt ) / ( 1 + ( parseFloat( taxRate ) / 100 ) ) );




			//var taxAmtCalc = (parseFloat(invoiceAmt) * parseFloat(taxRate))/100;
			taxAmtCalc = taxAmtCalc.toFixed( 2 );
			nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_AMOUNT, taxAmtCalc );

		}



	}
	if ( name == COL_SL_PAYMENT_AMOUNT && type == COL_SL_INVOICE_SUBLIST_APPLIED ) {

		var invoiceAmt = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT );
		var taxRate = nlapiGetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_RATE );
		if ( taxRate == null || taxRate == '' ) {
			nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, '' );
		}
		else {
			if ( invoiceAmt == null || invoiceAmt == '' )
				invoiceAmt = 0;
			var taxAmtCalc = parseFloat( invoiceAmt ) - ( parseFloat( invoiceAmt ) / ( 1 + ( parseFloat( taxRate ) / 100 ) ) );




			//var taxAmtCalc = (parseFloat(invoiceAmt) * parseFloat(taxRate))/100;
			taxAmtCalc = taxAmtCalc.toFixed( 2 );
			nlapiSetCurrentLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, taxAmtCalc );

		}



	}


	if ( name == SL_FLD_CLIENT_INV || name == SL_FLD_CLIENT_CM ) {
		var client = nlapiGetFieldValue( SL_FLD_CLIENT_INV );
		if ( name == SL_FLD_CLIENT_CM )
			client = nlapiGetFieldValue( SL_FLD_CLIENT_CM );

		if ( client != null && client != '' ) {
			var invoiceTranDateFrom = nlapiGetFieldValue( FLD_SL_TRAN_DATE_FROM );
			var invoiceTranDateTo = nlapiGetFieldValue( FLD_SL_TRAN_DATE_TO );
			var creditTranDateFrom = nlapiGetFieldValue( FLD_SL_CM_TRAN_DATE_FROM );
			var creditTranDateTo = nlapiGetFieldValue( FLD_SL_CM_TRAN_DATE_TO );
			//var invoiceTranDate=nlapiGetFieldValue(SL_FLD_DATE);
			var invoiceLineIo = nlapiGetFieldValue( FLD_SL_INVOICE_LINE_IO );
			var invoiceLineProject = nlapiGetFieldValue( FLD_SL_INVOICE_LINE_PROJECT );
			var creditLineIo = nlapiGetFieldValue( FLD_SL_CM_LINE_IO );
			var creditLineProject = nlapiGetFieldValue( FLD_SL_CM_LINE_PROJECT );
			var consolidateInv = nlapiGetFieldValues( SL_FLD_CONSOLIDATED_INVOICE );
			var clientPD = nlapiGetFieldValue( SL_FLD_CLIENT_INV );
			var clientPDCM = nlapiGetFieldValue( FLD_SL_CLIENT_CM );
			var url = nlapiResolveURL( 'SUITELET', SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID, SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID );
			url = url + '&clientPD=' + clientPD + '&clientPDCM=' + clientPDCM + '&invoiceLineProject=' + invoiceLineProject + '&creditLineProject=' + creditLineProject + '&invoiceTranDateFrom=' + invoiceTranDateFrom + '&invoiceTranDateTo=' + invoiceTranDateTo + '&creditTranDateFrom=' + creditTranDateFrom + '&creditTranDateTo=' + creditTranDateTo + '&invoiceLineIo=' + invoiceLineIo + '&creditLineIo=' + creditLineIo + '&consolidateInv=' + consolidateInv;
			window.open( url, '_self' );
		}
	}
	if ( name == SL_FLD_DATE ) {
		var date = nlapiGetFieldValue( SL_FLD_DATE );
		if ( date != null && date != '' ) {
			var dateInString = nlapiStringToDate( date );
			var accountingPeriodFld = accountingPeriod( dateInString );
			nlapiSetFieldValue( SL_FLD_POSTING_PERIOD, accountingPeriodFld );
		}
	}
	if ( ( type == COL_SL_INVOICE_SUBLIST && ( name == COL_SL_INVOICE_MARK || name == COL_SL_PAYMENT_AMOUNT ) ) || ( type == COL_SL_CREDIT_SUBLIST && ( name == COL_SL_CREDIT_SUBLIST_FLD_MARK || name == COL_SL_CREDIT_AMOUNT ) ) || ( type == COL_SL_INVOICE_SUBLIST_APPLIED && name == COL_SL_PAYMENT_AMOUNT ) || ( type == COL_SL_CREDIT_SUBLIST_APPLIED && name == COL_SL_CREDIT_AMOUNT ) ) {
		var nCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST );
		var invoiceTotal = 0;
		// TOTAL_SELECTED = 0;
		TOTAL_UNAPPLIED_INVOICES = 0;
		for ( var i = 1; nCount > 0 && i <= nCount; i++ ) {
			var iSelected = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i );
			var invoiceAmt = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i );
			var amountdue = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT + '_native', i );
			var taxAmt = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_AMOUNT, i );
			var taxRateLine = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_RATE, i );
			var isLineFromPayment = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_LINE_FROM_PAYMENT, i );


			if ( taxAmt == null || taxAmt == '' )
				taxAmt = 0;

			if ( invoiceAmt != null && invoiceAmt != '' && amountdue != null && amountdue != '' ) {

				if ( parseFloat( invoiceAmt ) > parseFloat( amountdue ) )// && (isLineFromPayment == null || isLineFromPayment == ''))
				{
					alert( 'Please enter Payment Amount less than or equal to Total Due (' + amountdue + ').' );
					nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i, amountdue );
					if ( taxRateLine ) {
						var taxDue = ( parseFloat( amountdue ) * parseFloat( taxRateLine ) ) / 100;
						nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_AMOUNT, i, taxDue );
					}

					if ( iSelected == 'T' ) {
						invoiceTotal = parseFloat( invoiceTotal ) + parseFloat( amountdue );// + parseFloat(taxAmt);
						// totalSelected++;
						// TOTAL_SELECTED++;
						TOTAL_UNAPPLIED_INVOICES++;
					}

				}
				else {
					if ( iSelected == 'T' ) {
						invoiceTotal = parseFloat( invoiceTotal ) + parseFloat( invoiceAmt );// + parseFloat(taxAmt);
						// totalSelected++;
						// TOTAL_SELECTED++;
						TOTAL_UNAPPLIED_INVOICES++;
					}
				}
			}

		}


		var nCount_credit = nlapiGetLineItemCount( COL_SL_CREDIT_SUBLIST );
		TOTAL_UNAPPLIED_CREDITS = 0;

		for ( var i = 1; nCount_credit > 0 && i <= nCount_credit; i++ ) {
			var iSelected = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i );
			var invoiceAmt = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i );
			var amountdue = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT + '_native', i );
			var isLineFromPayment = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_LINE_FROM_PAYMENT + '_cr', i );

			if ( invoiceAmt != null && invoiceAmt != '' && amountdue != null && amountdue != '' ) {

				if ( parseFloat( invoiceAmt ) > parseFloat( amountdue ) )// && (isLineFromPayment == null || isLineFromPayment == ''))
				{
					alert( 'Please enter Credit Amount less than or equal to Amount (' + amountdue + ').' );
					nlapiSetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i, amountdue );
					if ( iSelected == 'T' ) {
						invoiceTotal = parseFloat( invoiceTotal ) - parseFloat( amountdue );
						// totalSelected++;
						// TOTAL_SELECTED++;
						TOTAL_UNAPPLIED_CREDITS++;
					}
				}
				else {
					if ( iSelected == 'T' ) {
						invoiceTotal = parseFloat( invoiceTotal ) - parseFloat( invoiceAmt );
						// totalSelected++;
						// TOTAL_SELECTED++;
						TOTAL_UNAPPLIED_CREDITS++;
					}
				}
			}

		}

		// var nCountAplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);
		// TOTAL_SELECTED += nCountAplied;
		var nCountAplied = TOTAL_APPLIED_INVOICES;

		for ( var i = 1; nCountAplied > 0 && i <= nCountAplied; i++ ) {
			var invoiceAmt = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i );
			var amountdue = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT + '_native', i );
			var taxAmt = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, i );
			var taxRateLine = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_RATE, i );
			var isLineFromPayment = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_LINE_FROM_PAYMENT, i );


			if ( taxAmt == null || taxAmt == '' )
				taxAmt = 0;

			if ( invoiceAmt != null && invoiceAmt != '' && amountdue != null && amountdue != '' ) {

				if ( parseFloat( invoiceAmt ) > parseFloat( amountdue ) )// && (isLineFromPayment == null || isLineFromPayment == ''))
				{
					alert( 'Please enter Payment Amount less than or equal to Total Due (' + amountdue + ').' );
					nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i, amountdue );
					if ( taxRateLine ) {
						var taxDue = ( parseFloat( amountdue ) * parseFloat( taxRateLine ) ) / 100;
						nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, i, taxDue );
					}

					invoiceTotal = parseFloat( invoiceTotal ) + parseFloat( amountdue );// + parseFloat(taxAmt);

				}
				else {
					invoiceTotal = parseFloat( invoiceTotal ) + parseFloat( invoiceAmt );// + parseFloat(taxAmt);
				}
			}

		}


		// var nCount_creditApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);
		// TOTAL_SELECTED += nCount_creditApplied;
		var nCount_creditApplied = TOTAL_APPLIED_CREDITS;

		for ( var i = 1; nCount_creditApplied > 0 && i <= nCount_creditApplied; i++ ) {
			var invoiceAmt = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i );
			var amountdue = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT + '_native', i );
			var isLineFromPayment = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_LINE_FROM_PAYMENT + '_cr', i );

			if ( invoiceAmt != null && invoiceAmt != '' && amountdue != null && amountdue != '' ) {

				if ( parseFloat( invoiceAmt ) > parseFloat( amountdue ) )// && (isLineFromPayment == null || isLineFromPayment == ''))
				{
					alert( 'Please enter Credit Amount less than or equal to Amount (' + amountdue + ').' );
					nlapiSetLineItemValue( COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i, amountdue );
					invoiceTotal = parseFloat( invoiceTotal ) - parseFloat( amountdue );
				}
				else {
					invoiceTotal = parseFloat( invoiceTotal ) - parseFloat( invoiceAmt );
				}
			}

		}

		updateTotals();

		nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, invoiceTotal.toFixed( 2 ) );
		// nlapiSetFieldValue(FLD_SL_TOTAL_SELECTED_LINES, totalSelected);
		nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED );
	}

}

function updateTotals () {
	TOTAL_SELECTED =
		Number( TOTAL_APPLIED_INVOICES ) +
		Number( TOTAL_APPLIED_CREDITS ) +
		Number( TOTAL_UNAPPLIED_INVOICES ) +
		Number( TOTAL_UNAPPLIED_CREDITS );
	console.log( {
		TOTAL_APPLIED_INVOICES: TOTAL_APPLIED_INVOICES,
		TOTAL_APPLIED_CREDITS: TOTAL_APPLIED_CREDITS,
		TOTAL_UNAPPLIED_INVOICES: TOTAL_UNAPPLIED_INVOICES,
		TOTAL_UNAPPLIED_CREDITS: TOTAL_UNAPPLIED_CREDITS,
		TOTAL_SELECTED: TOTAL_SELECTED
	} );
}

function invoicemarkAll () {
	var a = performance.now();
	var paymentAmountTotal = 0;
	// var totalSelected = 0;

	var invCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST );
	// var credCount = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST);
	// var invCountApplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);
	// var credCountApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);

	var tempTotal = Number( invCount ) + Number( TOTAL_UNAPPLIED_CREDITS ) + Number( TOTAL_APPLIED_INVOICES ) + Number( TOTAL_APPLIED_CREDITS );
	if ( tempTotal > 2500 ) {
		alert( 'You cannot apply this payment to more than 2,500 lines.' );
		return;
	}

	TOTAL_UNAPPLIED_INVOICES = 0;

	for ( var i = 1; i <= invCount; i++ ) {

		nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i, 'T' );
		/* // nlapiSelectLineItem(COL_SL_INVOICE_SUBLIST, i);
		// nlapiSetCurrentLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, 'T', false, true); */

		var paymentAmount = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i );
		var taxAmount = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_TAX_AMOUNT, i );
		if ( taxAmount == null || taxAmount == '' )
			taxAmount = 0;
		if ( paymentAmount == null || paymentAmount == '' )
			paymentAmount = 0;
		paymentAmountTotal = Number( paymentAmountTotal ) + Number( paymentAmount );// + Number(taxAmount);
		// totalSelected++;
		// TOTAL_SELECTED++;
		TOTAL_UNAPPLIED_INVOICES++;
	}
	updateTotals();

	TOTAL_UNAPPLIED_AMT_INV = paymentAmountTotal;

	// var creditAmountTotal=0;

	/* for (var i=1; i<=credCount; i++) {
		var iSelected = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i);
		if(iSelected == 'T'){
		var creditAmount = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i);
		if(creditAmount == null || creditAmount == '')
			creditAmount = 0;
		creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
	 // totalSelected++;
	 // TOTAL_SELECTED++;
	 // TOTAL_UNAPPLIED
		}

	} */

	/* for (var i=1; i<=invCountApplied; i++) {
		var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i);
    var taxAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_TAX_AMOUNT, i);
    if(taxAmount == null || taxAmount == '')
	 taxAmount = 0;
		if(paymentAmount == null || paymentAmount == '')
			paymentAmount = 0;
		paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);// + Number(taxAmount);
		

	}

	for (var i=1; i<=credCountApplied; i++) {
		var creditAmount = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i);
		if(creditAmount == null || creditAmount == '')
			creditAmount = 0;
		creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);

	} */

	var pmtTotal = Number( TOTAL_APPLIED_AMT_INV ) + Number( TOTAL_UNAPPLIED_AMT_INV );
	var crTotal = Number( TOTAL_UNAPPLIED_AMT_CRED ) + Number( TOTAL_APPLIED_AMT_CRED );

	nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, Number( pmtTotal ) - Number( crTotal ) );
	/* // nlapiSetFieldValue(FLD_SL_APPLIED_AMOUNT, Number(paymentAmountTotal)-Number(creditAmountTotal));
  // nlapiSetFieldValue(FLD_SL_TOTAL_SELECTED_LINES, totalSelected);
  // nlapiSetFieldValue(FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED); */
	nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED );

	var b = performance.now();
	console.log( 'markAll elapsed = ' + ( b - a ) );
}
function invoiceunmarkAll () {
	var a = performance.now();
	var invCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST );
	var invAmountTotal = 0;
	var invSelected = invCount;

	for ( var i = 1; i <= invCount; i++ ) {
		var isLineFromPayment = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_LINE_FROM_PAYMENT, i );
		var paymentAmount = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i );
		if ( paymentAmount == null || paymentAmount == '' )
			paymentAmount = 0;
		if ( isLineFromPayment == null || isLineFromPayment == '' ) {
			nlapiSetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i, 'F' );
			invSelected = Number( invSelected ) - 1;
		}
		else {
			invAmountTotal = parseFloat( invAmountTotal ) + parseFloat( paymentAmount )
		}
	}
	TOTAL_UNAPPLIED_INVOICES = invSelected;
	TOTAL_UNAPPLIED_AMT_INV = invAmountTotal;

	/* var creditAmountTotal=0;

	   var credCount = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST);

	   for (var i=1; i<=credCount; i++) {
		   var iSelected = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i);
		   if(iSelected == 'T'){
		   var creditAmount = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i);
		   if(creditAmount == null || creditAmount == '')
			   creditAmount = 0;
		   creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
		   }

	   }
   var invCountApplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);
	   for (var i=1; i<=invCountApplied; i++) {
					   var isLineFromPayment = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_LINE_FROM_PAYMENT, i);
						var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i);
			   if(paymentAmount == null || paymentAmount == '')
				   paymentAmount = 0;
	    if (isLineFromPayment != null && isLineFromPayment != '')
		   {
			   invAmountTotal = parseFloat(invAmountTotal) + parseFloat(paymentAmount)
		   }
	   	
	   	
	   }
	
	   var credCountApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);

	   for (var i=1; i<=credCountApplied; i++) {
	   	
		   var creditAmount = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i);
		   if(creditAmount == null || creditAmount == '')
			   creditAmount = 0;
		   creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
	   	

	   } */

	// TOTAL_UNAPPLIED_INVOICES = 0;
	updateTotals();

	var pmtTotal = Number( TOTAL_UNAPPLIED_AMT_INV ) + Number( TOTAL_APPLIED_AMT_INV );
	var crTotal = Number( TOTAL_UNAPPLIED_AMT_CRED ) + Number( TOTAL_APPLIED_AMT_CRED );

	nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, Number( pmtTotal ) - Number( crTotal ) );
	// nlapiSetFieldValue(FLD_SL_APPLIED_AMOUNT, Number(invAmountTotal)-Number(creditAmountTotal));
	nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED );

	var b = performance.now();
	console.log( 'unmarkAll elapsed = ' + ( b - a ) );
	alert( 'Please zero out the existing payment value of the lines for any line that came from existing payment' );

}

function creditmarkAll () {
	var a = performance.now();
	var paymentAmountTotal = 0;
	// var totalSelected = 0;

	// var invCount = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST);
	var credCount = nlapiGetLineItemCount( COL_SL_CREDIT_SUBLIST );
	// var invCountApplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);
	// var credCountApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);

	var tempTotal = Number( TOTAL_UNAPPLIED_INVOICES ) + Number( credCount ) + Number( TOTAL_APPLIED_INVOICES ) + Number( TOTAL_APPLIED_CREDITS );
	if ( tempTotal > 2500 ) {
		alert( 'You cannot apply this payment to more than 2,500 lines.' );
		return;
	}

	TOTAL_UNAPPLIED_CREDITS = 0;

	// var invCount = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST);

	/* for (var i=1; i<=invCount; i++) {
		var iSelected = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i);
		if(iSelected == 'T'){
		var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
		if(paymentAmount == null || paymentAmount == '')
			paymentAmount = 0;
		paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
		}

	} */

	var creditAmountTotal = 0;

	// var credCount = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST);

	for ( var i = 1; i <= credCount; i++ ) {
		nlapiSetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i, 'T' );

		var creditAmount = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i );
		if ( creditAmount == null || creditAmount == '' )
			creditAmount = 0;
		creditAmountTotal = Number( creditAmountTotal ) + Number( creditAmount );
		TOTAL_UNAPPLIED_CREDITS++;
	}
	updateTotals();

	TOTAL_UNAPPLIED_AMT_CRED = creditAmountTotal;

	/* var invCountApplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);

	for (var i=1; i<=invCountApplied; i++) {
		var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i);
		if(paymentAmount == null || paymentAmount == '')
			paymentAmount = 0;
		paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
		

	}

	var credCountApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);

	for (var i=1; i<=credCountApplied; i++) {
		
		var creditAmount = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i);
		if(creditAmount == null || creditAmount == '')
			creditAmount = 0;
		creditAmountTotal = Number(creditAmountTotal) + Number(creditAmount);
		

	} */

	var pmtTotal = Number( TOTAL_APPLIED_AMT_INV ) + Number( TOTAL_UNAPPLIED_AMT_INV );
	var crTotal = Number( TOTAL_UNAPPLIED_AMT_CRED ) + Number( TOTAL_APPLIED_AMT_CRED );

	nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, Number( pmtTotal ) - Number( crTotal ) );
	// nlapiSetFieldValue(FLD_SL_APPLIED_AMOUNT, Number(paymentAmountTotal)-Number(creditAmountTotal));
	nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED );

	var b = performance.now();
	console.log( 'markAll elapsed = ' + ( b - a ) );
}
function creditunmarkAll () {
	var a = performance.now();
	var credCount = nlapiGetLineItemCount( COL_SL_CREDIT_SUBLIST );
	var creditAmountTotal = 0;
	var credSelected = credCount;

	for ( var i = 1; i <= credCount; i++ ) {
		var isLineFromPayment = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_LINE_FROM_PAYMENT + '_cr', i );
		var cAmt = nlapiGetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_AMOUNT, i );

		if ( isLineFromPayment == null || isLineFromPayment == '' ) {
			nlapiSetLineItemValue( COL_SL_CREDIT_SUBLIST, COL_SL_CREDIT_SUBLIST_FLD_MARK, i, 'F' );
			credSelected = Number( credSelected ) - 1;
		}
		else {
			creditAmountTotal = parseFloat( creditAmountTotal ) + parseFloat( cAmt );
		}
	}
	TOTAL_UNAPPLIED_CREDITS = credSelected;
	TOTAL_UNAPPLIED_AMT_CRED = creditAmountTotal;

	/* var paymentAmountTotal=0;
var invCount = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST);

			for (var i=1; i<=invCount; i++) {
				var iSelected = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i);
				if(iSelected == 'T'){
				var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_PAYMENT_AMOUNT, i);
				if(paymentAmount == null || paymentAmount == '')
					paymentAmount = 0;
				paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
				}

			}
			
			
			var credCountApplied = nlapiGetLineItemCount(COL_SL_CREDIT_SUBLIST_APPLIED);

	for (var i=1; i<=credCountApplied; i++) {
									var isLineFromPayment = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_LINE_FROM_PAYMENT+'_cr', i);
									  var cAmt = nlapiGetLineItemValue(COL_SL_CREDIT_SUBLIST_APPLIED, COL_SL_CREDIT_AMOUNT, i);

			  if (isLineFromPayment != null && isLineFromPayment != '')
				creditAmountTotal = parseFloat(creditAmountTotal) + parseFloat(cAmt);
				
			}
	
var invCountApplied = nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);

			for (var i=1; i<=invCountApplied; i++) {
				
				var paymentAmount = nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST_APPLIED, COL_SL_PAYMENT_AMOUNT, i);
				if(paymentAmount == null || paymentAmount == '')
					paymentAmount = 0;
				paymentAmountTotal = Number(paymentAmountTotal) + Number(paymentAmount);
				

			} */

	// TOTAL_UNAPPLIED_CREDITS = 0;
	updateTotals();

	var pmtTotal = Number( TOTAL_UNAPPLIED_AMT_INV ) + Number( TOTAL_APPLIED_AMT_INV );
	var crTotal = Number( TOTAL_UNAPPLIED_AMT_CRED ) + Number( TOTAL_APPLIED_AMT_CRED );

	nlapiSetFieldValue( FLD_SL_APPLIED_AMOUNT, Number( pmtTotal ) - Number( crTotal ) );
	// nlapiSetFieldValue(FLD_SL_APPLIED_AMOUNT, Number(paymentAmountTotal)-parseFloat(creditAmountTotal));	
	nlapiSetFieldValue( FLD_SL_TOTAL_SELECTED_LINES, TOTAL_SELECTED );

	var b = performance.now();
	console.log( 'unmarkAll elapsed = ' + ( b - a ) );
	alert( 'Please zero out the existing payment value of the lines for any line that came from existing payment' );
	// alert('Please zero out the existing credit value of the lines for any line that came from existing payment');
}




function applyFilters () {
	var client = nlapiGetFieldValue( SL_FLD_CLIENT_INV );
	if ( client != null && client != '' ) {
		var url = getUrl();
		window.open( url, '_self' );
	}
	else {
		alert( 'Please enter value for the field : Client' );
		return false;
	}

}

function getUrl () {
	//  var recId=nlapiGetRecordId();
	var client = nlapiGetFieldValue( SL_FLD_CLIENT_INV );
	//
	var invoiceTranDateFrom = nlapiGetFieldValue( FLD_SL_TRAN_DATE_FROM );
	var invoiceTranDateTo = nlapiGetFieldValue( FLD_SL_TRAN_DATE_TO );
	var creditTranDateFrom = nlapiGetFieldValue( FLD_SL_CM_TRAN_DATE_FROM );
	var creditTranDateTo = nlapiGetFieldValue( FLD_SL_CM_TRAN_DATE_TO );
	var invoiceLineIo = nlapiGetFieldValue( FLD_SL_INVOICE_LINE_IO );
	var invoiceLineProject = nlapiGetFieldValue( FLD_SL_INVOICE_LINE_PROJECT );
	var creditLineIo = nlapiGetFieldValue( FLD_SL_CM_LINE_IO );
	var creditLineProject = nlapiGetFieldValue( FLD_SL_CM_LINE_PROJECT );

	var consolidateInv = nlapiGetFieldValues( SL_FLD_CONSOLIDATED_INVOICE );
	var consolidateInvValues = '';
	if ( consolidateInv != null && consolidateInv != '' ) {
		for ( var v = 0; v < consolidateInv.length; v++ ) {
			consolidateInvValues += consolidateInv[ v ] + '|';
		}
		consolidateInvValues = consolidateInvValues.slice( 0, -1 );
	}
	var clientPD = nlapiGetFieldValue( SL_FLD_CLIENT_INV );
	var filtersectionClient = nlapiGetFieldValues( FLD_SL_CHILD_CLIENTS );
	var filtersectionClientValues = '';
	if ( filtersectionClient != null && filtersectionClient != '' ) {
		for ( var v = 0; v < filtersectionClient.length; v++ ) {
			filtersectionClientValues += filtersectionClient[ v ] + '|';
		}
		filtersectionClientValues = filtersectionClientValues.slice( 0, -1 );
	}

	//var invoiceTranDate=nlapiGetFieldValue(SL_FLD_DATE);

	var clientPDCM = nlapiGetFieldValue( FLD_SL_CLIENT_CM );
	var filtersectionClientCM = nlapiGetFieldValues( FLD_SL_CHILED_CLIENTS_CM );
	var filtersectionClientCMValues = '';
	if ( filtersectionClientCM != null && filtersectionClientCM != '' ) {
		for ( var v = 0; v < filtersectionClientCM.length; v++ ) {
			filtersectionClientCMValues += filtersectionClientCM[ v ] + '|';
		}
		filtersectionClientCMValues = filtersectionClientCMValues.slice( 0, -1 );
	}
	//added by shravan kumar 12-10-2022
	var excludeCon = nlapiGetFieldValue( FLD_SL_EXCLUDE_CONSOL_IN );
	//added by shravan kumar 12-10-2022
	var excludeConCM = nlapiGetFieldValue( FLD_SL_EXCLUDE_CONSOL_CM );

	var recId = nlapiGetFieldValue( FLD_SL_PAYMENT_LINK );
	if ( recId == null )
		recId = '';
	var url = nlapiResolveURL( 'SUITELET', SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID, SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID );
	url = url + '&recId=' + recId + '&clientPD=' + clientPD + '&clientPDCM=' + clientPDCM + '&invoiceLineProject=' + invoiceLineProject + '&creditLineProject=' + creditLineProject + '&invoiceTranDateFrom=' + invoiceTranDateFrom + '&invoiceTranDateTo=' + invoiceTranDateTo + '&creditTranDateFrom=' + creditTranDateFrom + '&creditTranDateTo=' + creditTranDateTo + '&invoiceLineIo=' + invoiceLineIo + '&creditLineIo=' + creditLineIo + '&consolidateInv=' + consolidateInvValues + '&filtersectionClient=' + filtersectionClientValues + '&filtersectionClientCM=' + filtersectionClientCMValues;
	//added by shravan kumar 12-10-2022
	url = url + '&excludeCon=' + excludeCon;
	url = url + '&excludeConCM=' + excludeConCM
	return url;
}

function gotoPage ( recType, inc, applied ) {
	console.log( 'gotoPage, recType = ' + recType + ', inc = ' + inc + ', applied = ' + applied );
	var url = getUrl();

	if ( inc != '' && inc != null && inc != undefined ) {
		var rtype = recType + ( applied == true ? '__applied' : '' );
		console.log( SRCH_SUMMARY[ rtype ] );

		var arrIndex = [];
		var arrTypes = [ 'invoice', 'transaction', 'invoice__applied', 'creditmemo__applied' ];
		for ( var i = 0, n = arrTypes.length; i < n; i++ ) {
			var index = 0;
			if ( SRCH_SUMMARY.hasOwnProperty( arrTypes[ i ] ) == true ) {
				index = parseInt( SRCH_SUMMARY[ arrTypes[ i ] ].index );
			}
			if ( arrTypes[ i ] == rtype ) {
				index += ( parseInt( SRCH_SUMMARY.pageSize ) * inc );
			}
			arrIndex.push( arrTypes[ i ] + ':' + index.toString() );
		}
		// url += '&srchType=' + recType + '&srchIndex=' + index;
		url += '&srchIndex=' + arrIndex.join( '|' );
	}

	console.log( url );
	window.open( url, '_self' );
}

function gotoInvPage ( inc, applied ) {
	gotoPage( 'invoice', inc, applied );
}

function gotoCredPage ( inc, applied ) {
	gotoPage( 'transaction', inc, applied );
}

function onsave () {
	var sAction = nlapiGetFieldValue( FLD_SL_ACTION );
	if ( sAction == null || sAction == '' ) {
		nlapiSetFieldValue( FLD_SL_ACTION, 'submit' );
	}
	var availableAmount = nlapiGetFieldValue( FLD_SL_AVAILABLE_AMOUNT );
	var appliedAmount = nlapiGetFieldValue( FLD_SL_APPLIED_AMOUNT );
	var lineCount = nlapiGetLineItemCount( COL_SL_INVOICE_SUBLIST );
	var invcount = 0;
	for ( var i = 1; i <= lineCount; i++ ) {
		// var selected=nlapiGetLineItemValue(COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_LINES, i);
		var selected = nlapiGetLineItemValue( COL_SL_INVOICE_SUBLIST, COL_SL_INVOICE_MARK, i );
		if ( selected == 'T' ) {
			invcount++;
			break;
		}

	}

	// console.log('onsave count = ' + count);
	// var lineCountApplied=nlapiGetLineItemCount(COL_SL_INVOICE_SUBLIST_APPLIED);
	/* var lineCountApplied=TOTAL_APPLIED_INVOICES;
    for(var i=1;i<=lineCountApplied;i++){
				 count++;
    } */
	var count = Number( TOTAL_UNAPPLIED_INVOICES ) + Number( TOTAL_APPLIED_INVOICES );
	//alert( count )
	// Prevent submissions with more than 2,500 lines
	if ( count >= 2500 ) {
		alert( 'Unable to submit more than 2,500 lines.' );
		return false;
	}
	if ( count > 0 || invcount > 0 ) {
		if ( availableAmount == null || availableAmount == '' )
			availableAmount = 0;
		if ( appliedAmount == null || appliedAmount == '' )
			appliedAmount = 0;
		if ( parseFloat( appliedAmount ) < 0 ) {
			alert( 'Applied Amount (' + appliedAmount + ') should be > 0' );
			return false;
			//return true;
		}
		else {
			if ( ( parseFloat( availableAmount ) >= parseFloat( appliedAmount ) ) ) {
				var isOKToProceed = confirm( 'Selected transactions will be submitted for Payment Application, Click OK to proceed' );
				if ( !isOKToProceed )
					return false;
				else
					return true;
				//return true;
			}

			else {
				alert( 'Applied Amount (' + appliedAmount + ') should not exceed the Available Amount (' + availableAmount + ')' );
				return false;
			}
		}
	}
	else {
		alert( 'Please select atleast one invoice line for payment application' );
		return false;
	}

}


function accountingPeriod ( date ) {

	var startDate = new Date( date.getFullYear(), date.getMonth(), 1 );
	var endDate = new Date( date.getFullYear(), date.getMonth() + 1, 0 );
	var Dt1 = nlapiDateToString( startDate );
	var Dt2 = nlapiDateToString( endDate );

	var filters = new Array();
	filters[ 0 ] = new nlobjSearchFilter( 'startdate', null, 'on', Dt1 );
	filters[ 1 ] = new nlobjSearchFilter( 'enddate', null, 'on', Dt2 );
	filters[ 2 ] = new nlobjSearchFilter( 'isyear', null, 'is', 'F' );
	filters[ 3 ] = new nlobjSearchFilter( 'isquarter', null, 'is', 'F' );

	var columns = new Array();
	columns[ 0 ] = new nlobjSearchColumn( 'internalid' );
	var search = nlapiSearchRecord( 'accountingperiod', null, filters, columns );
	var periodId = search[ 0 ].getValue( 'internalid' );
	return periodId;


}







