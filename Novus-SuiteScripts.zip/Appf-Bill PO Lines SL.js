/*
* Script Name : Appf-Bill PO Lines UI SL
* Script Type : Suitelet
* Description : This page displays the UI page of Bill from PO Lines based on a SS.
* Company     : Appficeincy Inc.
* 
**/

var CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG = 'customrecord_appf_bill_po_lines_log';
var FLD_CR_TOTAL_BILLS_TO_PROCESS = 'custrecord_appf_bill_po_lines_total';
var FLD_CR_TOTAL_BILLS_CREATED = 'custrecord_appf_bill_po_lines_created';
var FLD_CR_TOTAL_POS_TO_PROCESS = 'custrecord_appf_bill_po_lines_to_process';
var FLD_CR_PROCESSED_PERCENT = 'custrecord_appf_bill_po_lines_percent';
var FLD_CR_CREATED = 'custrecord_appf_bill_po_lines_created_by';
var FLD_CR_BILL_POS_BATCH_STATUS = 'custrecord_appf_bill_po_lines_status';
var FLD_CR_DATA_FILE = 'custrecord_appf_bill_po_lines_data_file';
var FLD_CR_STATUS_FILE = 'custrecord_appf_bill_po_lines_status_fil';
var FLD_CR_ERROR_LOG = 'custrecord_appf_bill_po_lines_error_log';
var FLD_CR_PO_LINK = 'custrecord_appf_bill_po_lines_po_link';
var FLD_CR_BILL_LINK = 'custrecord_appf_bill_po_lines_bill_link';
var FLD_CR_ACCOUNT_NUM = 'custrecord_appf_ap_account';
var FLD_CR_REF_NUM = 'custrecord_appf_ref_number';
var FLD_SL_REF_NUM = 'custpage_ref_num';
var FLD_SL_AP_ACCOUNTS_NUM = 'custpage_account_num';
var CUSTOM_RECORD_MEDIA_SUPPLIER = 'customrecord_appf_media_supplier';
var CUSTOM_RECORD_PWP = 'customrecord_appf_pwp_wrapper_record';
var FLD_CR_VENDOR_NUM = 'custrecord_vendor_ids';
var FLD_CR_VENDOR_SUBS = 'custrecord_appf_subsidiary';

var FLD_PWP_PROJECT = 'custrecord_appf_pwp_project';
var FLD_PWP_CLIENT = 'custrecord_appf_pwp_client_link';

var TITLE_BILL_PO_LINES_SL = 'Bill PO Lines';
var SCRIPT_CLIENT_VALIDATIONS = 'customscript_appf_bill_po_lines_valid_cl';
var FILTERS_GROUP='custpage_filter';
var FLD_SL_ACTION='custpage_action';
var FLD_SL_VENDOR='custpage_vendor';
var FLD_SL_PUBLISHER_MEDIA_SUPLIER='custpage_media_supplier';
var FLD_SL_MEDIA_SEGMENT='custpage_media_segment';
var FLD_PROJECT_PWP_REC='custpage_proj_pwp_rec';
var FLD_SL_START_DATE_FROM='custpage_start_date_from';
var FLD_SL_START_DATE_TO='custpage_start_date_to';
var FLD_SL_END_DATE_FROM='custpage_end_date_from';
var FLD_SL_END_DATE_TO='custpage_end_date_to';
var FLD_SL_PO_TRAN_NUM='custpage_po_tran_number';
var FLD_SL_IO_NUM = 'custpage_io_number';
var FLD_SL_LOB='custpage_line_of_bussiness';
var FLD_SL_SUBSIDIARY='custpage_subsidiary';
var FLD_SL_CLIENT='custpage_client';
var FLD_SL_USE_TO_BILL='custpage_use_to_bill';
var BTN_SL_APPLY_FILTERS = 'custpage_button_apply_filters';

var COLUMNS_GROUP = 'custpage_column';
var SL_SUBLIST='custpage_sublist';
var BTN_SL_MARKALL_BUTTON='custpage_marke_all';
var BTN_SL_UN_MARKALL='custpage_un_marke_all';
var COL_SL_SELECT = 'custpage_select';
var COL_SL_PO_ID = 'custpage_po_id';
var COL_SL_UNBILLED_AMT = 'custpage_unbilled_amt';
var COL_SL_CURRENCY = 'custpage_currency_script';
var COL_SL_UNBILLED_AMT_DUPLICATE = 'custpage_unbilled_amt_duplicate';
var COL_SL_VEND_ID = 'custpage_vendor_id';
var COL_SL_LINE_ID = 'custpage_line_id';

var SPARAM_BILL_PO_LINES_SL_SS = 'custscript_appf_bill_po_lines_sl_ss';

var FLD_BILL_PO_LINES_SL_STATUS = 'custbody_appf_bill_po_line_status';
var FLD_COL_MEDIA_PUBLISHER = 'custcol_appf_publisher';
var FLD_COL_PWP_CUSTOM_RECORD = 'custcol_appf_pwp_custom_record';
var FLD_COL_START_DATE_RR = 'custcolappf_so_line_startdate';
var FLD_COL_SERVICE_DATE_RR = 'custcol_appf_print_servicedate';

var FLD_COL_END_DATE_RR = 'custcol_appf_so_line_enddate';
var FLD_COL_PO_NUMBER = 'custcol_appf_po_number';
var FLD_COL_IO_NUMBER = 'custcol_appf_ionum';

var SCRIPT_BILL_PO_LINES_SC = 'customscript_appf_bill_po_lines_sc';
var DEPLOY_BILL_PO_LINES_SC = 'customdeploy_appf_bill_po_lines_sc';

var SPARAM_SELECTED_POS_FOLDER = 'custscript_appf_selected_pos_folder_id';
var SPARAM_CUSTOM_RECORD_ID = 'custscript_appf_bill_po_line_exec_log_id';

var STATUS_INPROGRESS = '2';
var STATUS_COMPLETED_SUCCESSFULLY = '4';
var STATUS_COMPLETED_WITH_ERRORS = '5';

var FLD_BILL_PO_LINES_EXEC_LOG = 'custbody_appf_bill_po_lines_log';

var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';

function billPOLinesSuitelet(request, response) {
	    if(request.getMethod() == 'GET') {
	        var frm = suiteletform(request);
	        response.writePage(frm);
	    }
	    else{
			
			var customRecId = processSelectedPOs(request);
		
			nlapiLogExecution( 'DEBUG', 'customRecId:',customRecId);
			response.sendRedirect('RECORD', CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG, customRecId);
			
		}	
}


function suiteletform(request)
{
	try
	{
		var context = nlapiGetContext();
		var billPOLinesSSId = context.getSetting('SCRIPT', SPARAM_BILL_PO_LINES_SL_SS);
		var mediaSegmentList = [{"value":"","text":""},{"value":"-1","text":"- New -"},{"value":"1","text":"Digital"},{"value":"2","text":"Outdoor"},{"value":"3","text":"Print"},{"value":"4","text":"Print : Insert"},{"value":"5","text":"Print : ROP"},{"value":"6","text":"Print : Print - Other"},{"value":"7","text":"Spot"},{"value":"8","text":"Spot : Broadcast"},{"value":"9","text":"Spot : Radio"}];
		
		var filtersApply = false;
		if(request.getParameter('applyFils') == 'T')
			filtersApply = true;
		var vend = request.getParameter('vend');
		if(vend != null && vend != '')
			vend = vend.split(',');
		var mediaSup = request.getParameter('mediaSupplier');
		var mediaSegment = request.getParameter('mediaSegment');
		var projPWPRecVal = request.getParameter('projPWPRec');
		var stdtFrom = request.getParameter('stdtFrom');
		var stdtTo = request.getParameter('stdtTo');
		//var endtFrom = request.getParameter('endtFrom');
		//var endtTo = request.getParameter('endtTo');
		//nlapiLogExecution('debug', 'endtFrom', endtFrom);
		var accountNum = request.getParameter('accountNum');
		var poNumber = request.getParameter('poNum');
		var ioNumber = request.getParameter('ioNum');
		var lobVal = request.getParameter('lob');
		var subsiVal = request.getParameter('subsi');
		var clientVal = request.getParameter('client');
		var utb = request.getParameter('useToBill');
		
      	var form=nlapiCreateForm(TITLE_BILL_PO_LINES_SL); 
		form.setScript(SCRIPT_CLIENT_VALIDATIONS);
		var filterGroup = form.addFieldGroup(FILTERS_GROUP, 'Filters');
		var fldAction = form.addField(FLD_SL_ACTION, 'text', '',null,FILTERS_GROUP);
		fldAction.setDisplayType('hidden');
		fldAction.setDefaultValue('submit');
		var vendorFil=form.addField(FLD_SL_VENDOR,'select','Vendor','vendor',FILTERS_GROUP);
		vendorFil.setDefaultValue(vend);
		var mediaSupplier=form.addField(FLD_SL_PUBLISHER_MEDIA_SUPLIER,'multiselect','Publisher/Media Supplier',CUSTOM_RECORD_MEDIA_SUPPLIER,FILTERS_GROUP);
		mediaSupplier.setDefaultValue(mediaSup);
		var mediaSeg=form.addField(FLD_SL_MEDIA_SEGMENT,'select','Media Segment', null,FILTERS_GROUP);
		for(var m = 0; m<mediaSegmentList.length; m++){
			var obj = mediaSegmentList[m];
			var selected = false;
			if(obj.value == mediaSegment)
				selected = true;
			mediaSeg.addSelectOption(obj.value, obj.text, selected);
		}
		var projPWPRec=form.addField(FLD_PROJECT_PWP_REC,'select','Project','job',FILTERS_GROUP);
		projPWPRec.setDefaultValue(projPWPRecVal);
		var startDateFrom=form.addField(FLD_SL_START_DATE_FROM,'date','ServiceDate (From)',null,FILTERS_GROUP);
		startDateFrom.setDefaultValue(stdtFrom);
		var startDateTo=form.addField(FLD_SL_START_DATE_TO,'date','ServiceDate  (To)',null,FILTERS_GROUP);
		startDateTo.setDefaultValue(stdtTo);
		var poNum=form.addField(FLD_SL_PO_TRAN_NUM,'text','Purchase Order #',null,FILTERS_GROUP);
		poNum.setDefaultValue(poNumber);
		var ioNum=form.addField(FLD_SL_IO_NUM,'text','IO #',null,FILTERS_GROUP);
		ioNum.setDefaultValue(ioNumber);
		var lob=form.addField(FLD_SL_LOB,'select','Line of Business','classification',FILTERS_GROUP);
		lob.setDefaultValue(lobVal);
		var subsi=form.addField(FLD_SL_SUBSIDIARY,'select','Subsidiary','subsidiary',FILTERS_GROUP);
		subsi.setDefaultValue(subsiVal);
		var client=form.addField(FLD_SL_CLIENT,'select','Client','customer',FILTERS_GROUP);
		client.setDefaultValue(clientVal);
		var useToBill=form.addField(FLD_SL_USE_TO_BILL,'checkbox','Use Bill-To Address from Vendor',null,FILTERS_GROUP);
		 form.addField(FLD_SL_REF_NUM,'text','Reference Number',null,FILTERS_GROUP).setMandatory(true);
    var account=  form.addField(FLD_SL_AP_ACCOUNTS_NUM,'select','AP Account',	'account',FILTERS_GROUP);
       account.setDefaultValue(accountNum);
		useToBill.setDefaultValue(utb);
		form.addButton(BTN_SL_APPLY_FILTERS, 'Apply Filters', 'applyFilters();');
		
		var sublist= form.addSubList(SL_SUBLIST,'list','Columns',COLUMNS_GROUP);
		sublist.addButton(BTN_SL_MARKALL_BUTTON,'Mark All','markAll();');
		sublist.addButton(BTN_SL_UN_MARKALL,'Unmark All','unmarkall();');
		sublist.addField(COL_SL_SELECT,'checkbox','Select');
		var poIntId =sublist.addField(COL_SL_PO_ID,'text','PO ID');
		poIntId.setDisplayType('hidden');
		var unbilledAmt =sublist.addField(COL_SL_UNBILLED_AMT_DUPLICATE,'text','Unbilled Amount Duplicate');
		unbilledAmt.setDisplayType('hidden');
		
		var billPOLinesSSObj = nlapiLoadSearch(null, billPOLinesSSId);
		var ssType = billPOLinesSSObj.getSearchType();
		var filters = billPOLinesSSObj.getFilters();
		var columns = billPOLinesSSObj.getColumns();
		
		var formulaIndex = 1;
		var scriptfieldcounter = 1;
		for(var c=0; c<columns.length; c++){
			var colObj = columns[c];
			var label = colObj.getLabel();
			var name = colObj.getName();
			name = name.replace('line.', '');
			if(name.indexOf('formula') == 0){
				name = name+formulaIndex;
				formulaIndex++;
			}
			
				if (label != 'Script Use DNR')
                {
					sublist.addField('custpage_'+name,'text',label);
                }
				else
				{
					if(scriptfieldcounter == 2){
				var lineId = sublist.addField(COL_SL_LINE_ID,'integer','Line ID');
				lineId.setDisplayType('hidden');
			}
			if(scriptfieldcounter == 6){
				var vendIntId = sublist.addField(COL_SL_VEND_ID,'text','Vendor ID');
				vendIntId.setDisplayType('hidden');
			}
		
				if(scriptfieldcounter == 5){
					var lineField = sublist.addField(COL_SL_UNBILLED_AMT,'currency','Bill Amount');
					lineField.setDisplayType('entry');
					
					//nlapiLogExecution('debug', 'name', 'custpage_'+name);
				}
				if(scriptfieldcounter == 9){
					var lineField = sublist.addField(COL_SL_CURRENCY,'select','Currency');
					lineField.setDisplayType('hidden');
					
					//nlapiLogExecution('debug', 'name', 'custpage_'+name);
				}
					 var scriptField = sublist.addField('custpage_scriptfield'+scriptfieldcounter, 'text', label);
					scriptField.setDisplayType('hidden');
                    scriptfieldcounter++;
				
			}
		}
		if(filtersApply == true){	
			var newFilters = [];
			if(vend != null && vend != '')
				newFilters.push(new nlobjSearchFilter('internalid', 'vendor', 'anyof', vend));
			if(subsiVal != null && subsiVal != '')
				newFilters.push(new nlobjSearchFilter('internalid', 'subsidiary', 'anyof', subsiVal));
			if(accountNum != null && accountNum != '')
				newFilters.push(new nlobjSearchFilter('payablesaccount', 'vendor', 'anyof', accountNum));
			//if(vend != null && vend != '')
				//newFilters.push(new nlobjSearchFilter('internalid', 'vendor', 'anyof', vend));
			if(mediaSup != null && mediaSup != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_MEDIA_PUBLISHER, null, 'anyof', mediaSup));
			if(mediaSegment != null && mediaSegment != '')
              {
                mediaSegment = mediaSegment.toString()
                mediaSegment = mediaSegment.split(',');
				newFilters.push(new nlobjSearchFilter('line.cseg_appf_media_seg', null, 'anyof', mediaSegment));
              }
			if(projPWPRecVal != null && projPWPRecVal != '')
				newFilters.push(new nlobjSearchFilter(FLD_PWP_PROJECT, FLD_COL_PWP_CUSTOM_RECORD, 'anyof', projPWPRecVal));
			if(stdtFrom != null && stdtFrom != '' && stdtTo != null && stdtTo != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_SERVICE_DATE_RR, null, 'within', stdtFrom, stdtTo));
			if(stdtFrom != null && stdtFrom != '' && (stdtTo == null || stdtTo == ''))
				newFilters.push(new nlobjSearchFilter(FLD_COL_SERVICE_DATE_RR, null, 'onorafter', stdtFrom));
			if((stdtFrom == null || stdtFrom == '') && stdtTo != null && stdtTo != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_SERVICE_DATE_RR, null, 'onorbefore', stdtTo));
			
			/*if(endtFrom != null && endtFrom != '' && endtTo != null && endtTo != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_END_DATE_RR, null, 'within', endtFrom, endtTo));
			if(endtFrom != null && endtFrom != '' && (endtTo == null || endtTo == ''))
				newFilters.push(new nlobjSearchFilter(FLD_COL_END_DATE_RR, null, 'onorafter', endtFrom));
			if((endtFrom == null || endtFrom == '') && endtTo != null && endtTo != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_END_DATE_RR, null, 'onorbefore', endtTo));*/
			if(poNumber != null && poNumber != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_PO_NUMBER, null, 'anyof', poNumber));
			if(ioNumber != null && ioNumber != '')
				newFilters.push(new nlobjSearchFilter(FLD_COL_IO_NUMBER, null, 'any', ioNumber));
			if(lobVal != null && lobVal != '')
              {
                lobVal = lobVal.toString();
                lobVal = lobVal.split(',')
				newFilters.push(new nlobjSearchFilter('class', null, 'anyof', lobVal));
              }
			if(subsiVal != null && subsiVal != '')
				newFilters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsiVal));
			if(clientVal != null && clientVal != '')
				newFilters.push(new nlobjSearchFilter(FLD_PWP_CLIENT, FLD_COL_PWP_CUSTOM_RECORD, 'anyof', clientVal));
			
			var newFilters = newFilters.concat(filters);
			
			var ssResults = getAllSearchResults(ssType, newFilters, columns);
			if(ssResults != null && ssResults != ''){
				for(var s = 0; s < ssResults.length; s++){
					var ssObj = ssResults[s];
					var scriptfieldcounter = 1;
					var formulaIndex = 1;
					sublist.setLineItemValue(COL_SL_PO_ID ,s+1,ssObj.getId());
					for(var c=0; c<columns.length; c++){
						var colObj = columns[c];
						var label = colObj.getLabel();
						var name = colObj.getName();
						var colVal = ssObj.getValue(colObj);
						if(colObj.getType() == 'select')
							colVal = ssObj.getText(colObj);
						name = name.replace('line.', '');
						if(name.indexOf('formula') == 0){
							name = name+formulaIndex;
							formulaIndex++;
						}
						
							if (label != 'Script Use DNR')
						{
							if (name == 'tranid' || name == 'number' || name == 'transactionnumber')
							{
								var url_tran=nlapiResolveURL('RECORD','purchaseorder',ssObj.getId());
							var colValNumber='<a href='+url_tran+' target="_blank">'+colVal+'</a>';
							sublist.setLineItemValue('custpage_'+name, s+1, colValNumber);
							}
							else
							{
								
							sublist.setLineItemValue('custpage_'+name, s+1, colVal);

							}
						}
						else
						{
							
							if(scriptfieldcounter == 2){
											sublist.setLineItemValue(COL_SL_LINE_ID ,s+1,colVal);

			}
			if(scriptfieldcounter == 6){
				sublist.setLineItemValue(COL_SL_VEND_ID ,s+1,colVal);
			}
		
				if(scriptfieldcounter == 5){
					sublist.setLineItemValue(COL_SL_UNBILLED_AMT ,s+1,colVal);
								sublist.setLineItemValue(COL_SL_UNBILLED_AMT_DUPLICATE ,s+1,colVal);
					
					//nlapiLogExecution('debug', 'name', 'custpage_'+name);
				}
				if(scriptfieldcounter == 9){
					sublist.setLineItemValue(COL_SL_CURRENCY ,s+1,colVal);
								sublist.setLineItemValue(COL_SL_CURRENCY ,s+1,colVal);
					
					//nlapiLogExecution('debug', 'name', 'custpage_'+name);
				}
							
							sublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounter, s+1, colVal);								
							scriptfieldcounter++;
							
						}
						
					}
				}
			}
		}
		form.addSubmitButton('Submit');
		return form;
	}catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}

function processSelectedPOs(request){
	var context=nlapiGetContext();
	var currentUser=context.getUser();
		var billPOLinesSSId = context.getSetting('SCRIPT', SPARAM_BILL_PO_LINES_SL_SS);
			var billPOLinesSSObj = nlapiLoadSearch(null, billPOLinesSSId);
		var ssType = billPOLinesSSObj.getSearchType();
		var filters = billPOLinesSSObj.getFilters();
		var columns = billPOLinesSSObj.getColumns();
	var poFolderId = context.getSetting('SCRIPT', SPARAM_SELECTED_POS_FOLDER);
	var timeStamp = new Date().getTime();
	try
	{
		var uniquePOs = [];
		var uniqueVendors = [];
      var totalBillsToCreate = 0;
		nlapiLogExecution('debug','poRefNum','poRefNum');
		var poRefNum=request.getParameter(FLD_SL_REF_NUM)
		nlapiLogExecution('debug','poRefNum',poRefNum);
		var poAccNums=request.getParameter(FLD_SL_AP_ACCOUNTS_NUM)
		nlapiLogExecution('debug','poAccNums',poAccNums);
		var poVendorNum=request.getParameter(FLD_SL_VENDOR)
		nlapiLogExecution('debug','poVendorNum',poVendorNum);
		var poVendorSubs=request.getParameter(FLD_SL_SUBSIDIARY)
		nlapiLogExecution('debug','poVendorSubs',poVendorSubs);
		var sscount = request.getLineItemCount(SL_SUBLIST);
		nlapiLogExecution('debug','sscount',sscount);
		var formulaIndex = 1;
		var scriptfieldcounter = 1;
		if(sscount > 0 && columns != null && columns != ''){					
				var csvData = '';
              var labelctr = 1;
				for(var cl=0; cl<columns.length; cl++){
					var colObj = columns[cl];
					var colLabel = colObj.getLabel();
					var name = colObj.getName();
			      
                  if (colLabel == 'Script Use DNR')
                    {
                      colLabel += ' ' +labelctr;
                      labelctr++;
                    }
					csvData += colLabel+',';
				}
				csvData += 'PO ID' + ',';
                csvData += 'Po Line' + ',';
                csvData += COL_SL_VEND_ID + ','
				csvData += 'Bill PO Line' + ',';
                csvData += 'Unbilled Amount';
				
				csvData = csvData+'\n';
				for(var c=1; c<=sscount; c++){
					if(request.getLineItemValue(SL_SUBLIST, COL_SL_SELECT, c) == 'T'){		
                      totalBillsToCreate++;
						var scriptfieldcounter = 1;
						var formulaIndex = 1;
						for(var cl=0; cl<columns.length; cl++){
							var colObj = columns[cl];
							var colLabel = colObj.getLabel();
							var colName = colObj.getName();
							 
							var colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_'+colName, c);
							if (colLabel == 'Script Use DNR')
							{
								colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield'+scriptfieldcounter, c);
								scriptfieldcounter++;
							}
							if(colValue!=null && colValue!='')
							colValue = colValue.replace(',', '');
							csvData += colValue+',';
						}
						csvData += request.getLineItemValue(SL_SUBLIST, COL_SL_PO_ID, c) + ',';
csvData += request.getLineItemValue(SL_SUBLIST, COL_SL_LINE_ID, c) + ',';
csvData += request.getLineItemValue(SL_SUBLIST, COL_SL_VEND_ID, c) + ',';
csvData += true + ',';
csvData += request.getLineItemValue(SL_SUBLIST, COL_SL_UNBILLED_AMT, c);
						csvData = csvData+'\n';
						var vendorId=request.getLineItemValue(SL_SUBLIST, COL_SL_VEND_ID, c)
						if(uniqueVendors.indexOf(vendorId) == -1)
					uniqueVendors.push(vendorId);
				
				var poId=request.getLineItemValue(SL_SUBLIST, COL_SL_PO_ID, c)
				if(uniquePOs.indexOf(poId) == -1)
					uniquePOs.push(poId);
					}
				}
				var timestamp = new Date().getTime();
				var csvFile = nlapiCreateFile('Selected_POs_For_Under_Processing_'+timestamp+'.csv', 'CSV', csvData);
				csvFile.setFolder(poFolderId);
				var posDataFileID = nlapiSubmitFile(csvFile);
			}	
		var customRec=nlapiCreateRecord(CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG);
		customRec.setFieldValue(FLD_CR_REF_NUM,poRefNum);
		customRec.setFieldValue(FLD_CR_ACCOUNT_NUM,poAccNums);
		customRec.setFieldValue(FLD_CR_VENDOR_NUM,poVendorNum);
		customRec.setFieldValue(FLD_CR_VENDOR_SUBS,poVendorSubs);
		
		//var customRec=nlapiLoadRecord(CUSTOM_RECORD_BILL_PO_LINES_EXEC_LOG,1);
		/*customRec.setFieldValue(FLD_CR_TOTAL_BILLS_TO_PROCESS, totalBillsToProcess);
		customRec.setFieldValue(FLD_CR_TOTAL_BILLS_CREATED,'');
		customRec.setFieldValue(FLD_CR_PROCESSED_PERCENT,'');
		customRec.setFieldValue(FLD_CR_BILL_POS_BATCH_STATUS, '');
		customRec.setFieldValue(FLD_CR_BILL_LINK,'');
		customRec.setFieldValue(FLD_CR_ERROR_LOG,'');*/
		customRec.setFieldValue(FLD_CR_TOTAL_BILLS_TO_PROCESS, totalBillsToCreate);
		customRec.setFieldValue(FLD_CR_BILL_POS_BATCH_STATUS, STATUS_INPROGRESS);
		customRec.setFieldValue(FLD_CR_DATA_FILE, posDataFileID);
		customRec.setFieldValues(FLD_CR_PO_LINK, uniquePOs);
		customRec.setFieldValue(FLD_CR_CREATED,currentUser);
		var billPOLinesExecutionLogID=nlapiSubmitRecord(customRec, true, true);
		nlapiLogExecution('debug', 'billPOLinesExecutionLogID', billPOLinesExecutionLogID);
		var params = {};
		params[SPARAM_CUSTOM_RECORD_ID] = billPOLinesExecutionLogID;
		nlapiScheduleScript(SCRIPT_BILL_PO_LINES_SC, null, params);
		//return billPOLinesExecutionLogID;	
		return billPOLinesExecutionLogID;	
			
	}catch(e){
		if ( e instanceof nlobjError )
			nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		else
			nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}

/*
Script for getting search results more than 1000 incase of Grouping/Non Grouping/ additional filters/additional columns.
param record_type{string} - Search Record Type
param filters{array} - array of filters of the saved search
param columns{array} - arraay of columns of the saved search

*/
 function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}