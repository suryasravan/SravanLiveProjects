/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Adds Print button to invoice record
 * 
 * Author: Rochelle Tapulado
 * Date: Aug 10, 2020
 * 
 * 
 */
define(['N/record','N/url'],

function(record,url) {
	var VAL_BTN_CLOSE_BUTTON = 'custpage_btn_close';
	var VAL_PARAM_INVOICE_ID = 'custparam_invoice_id';
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	if (scriptContext.type == scriptContext.UserEventType.VIEW) {
    		var rec = scriptContext.newRecord;
    		var idInvoice = rec.id;

    		var invoiceUrl = url.resolveRecord({
    		    recordType: record.Type.SALES_ORDER,
    		    recordId: idInvoice,
    		    isEditMode: false
    		});
    		
    		invoiceUrl += '&'+VAL_PARAM_INVOICE_ID+'='+rec.id;

    		scriptContext.form.addButton({
    		    id : VAL_BTN_CLOSE_BUTTON,
    		    label : 'Print',
    		    functionName: 'location.href="'+invoiceUrl+'";'
    		});
    		/*scriptContext.form.addButton({
    		    id : VAL_BTN_CLOSE_BUTTON,
    		    label : 'Print',
    		    functionName: 'window.open("'+ invoiceUrl +'");'
    		});*/

    	}

    }


    return {
        beforeLoad: beforeLoad
    };
    
});
