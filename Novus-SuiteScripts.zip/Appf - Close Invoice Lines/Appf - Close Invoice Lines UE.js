/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2020
 * 
 * Description: Adds Close button to invoice record when clicked will close invoice lines
 * 
 * Author: Rochelle Tapulado
 * Date: Aug 10, 2020
 * 
 * 
 */
define(['N/record','N/url','N/redirect'],

function(record,url,redirect) {
	var VAL_BTN_CLOSE_BUTTON = 'custpage_btn_close';
	var VAL_PARAM_INVOICE_ID = 'custparam_invoice_id';
	var VAL_PARAM_CLOSE_INVOICE = 'custparam_close_invoice';
	var VAL_BTN_LABEL = 'Close Lines';
	var FLD_INV_CI_STATUS = 'custcol_appf_ci_status';
	var FLD_INV_CI_RECORD = 'custcol_appf_ci_record';
	var FLD_INV_CLOSED_PROCESS = 'custcol_appf_close_processed';
	var FLD_INV_PRE_CLOSE_AMT = 'custcol_appf_pre_close_amt';
	var FLD_INV_PWP = 'custcol_appf_pwp_custom_record';
	var VAL_CI_STATUS_NOT_STARTED = 1;
	var REC_PWP = 'customrecord_appf_pwp_wrapper_record';
	var FLD_PWP_INVOICE_AMT = 'custrecord_appf_pwp_inv_line_amount';
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) {
    	var sCloseInvoice = scriptContext.request.parameters[VAL_PARAM_CLOSE_INVOICE] || '';
		var recInvoice = scriptContext.newRecord;
		var idInvoice = recInvoice.id;
		
    	if (scriptContext.type == scriptContext.UserEventType.VIEW) { //display Close button
    		var invoiceUrl = url.resolveRecord({
    		    recordType: record.Type.INVOICE,
    		    recordId: idInvoice,
    		    isEditMode: false
    		});
    		invoiceUrl += '&'+VAL_PARAM_INVOICE_ID+'='+recInvoice.id;
    		invoiceUrl += '&'+VAL_PARAM_CLOSE_INVOICE+'=T';

    		var bShow = checkLines(recInvoice);
    		if(bShow){
        		scriptContext.form.addButton({
        		    id : VAL_BTN_CLOSE_BUTTON,
        		    label : VAL_BTN_LABEL,
        		    /*functionName: "confirm('Are you Sure you want to close the lines?');window.open('"+ invoiceUrl +"', '_self');"*/
        		    functionName: "if(confirm('Are you sure you want to close the lines?')) window.open('"+ invoiceUrl +"', '_self');"
        		});
    		}	
    	}
    	
    	if(sCloseInvoice == 'T'){  //update invoice lines
    		log.debug('param sCloseInvoice', sCloseInvoice);
    		//load invoice record
   		    var recInvoice = record.load({
			    type: record.Type.INVOICE,
			    id: idInvoice,
			    isDynamic: false /*true*/,
		    });
    		
    		var status = updateInvoiceLines(recInvoice);
    		if(status){
    			//redirect invoice 
    			redirect.toRecord({
    			    type : record.Type.INVOICE,
    			    id : idInvoice
    			});
    		}
    		
    	}
    	

    }

    /**
     * Check if any of the lines can be closed, if return True will show Close button. Should satisfy the following condition:
     * Invoice status Open
     * CI Status is Not Started
     * CI Record is empty
     * At least one line has the Close Processed {custcol_appf_close_processed} checkbox unchecked
     */
    function checkLines(recInvoice){
    	var nLines = recInvoice.getLineCount({ sublistId: 'item' });
    	var bForClose = false;
    	for(var i = 0; i < nLines; i++){
    		var idCIStatus = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: FLD_INV_CI_STATUS,
        	    line: i
        	});
    		var idCIRecord = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: FLD_INV_CI_RECORD,
        	    line: i
        	});
    		var sClosedProcessed = recInvoice.getSublistValue({
        	    sublistId: 'item',
        	    fieldId: FLD_INV_CLOSED_PROCESS,
        	    line: i
        	});
    		
    		if(idCIStatus == VAL_CI_STATUS_NOT_STARTED && isEmpty(idCIRecord) && sClosedProcessed != true){
    			log.debug('sClosedProcessed',sClosedProcessed);
    			bForClose = true;
    			return bForClose;
    		}
    		
    	}
    	return bForClose;
    }

    /**
     * Update line columns:
     * Copy Client Gross Allocation(Quantity field) to Pre-Close Amount
     * Set Client Gross Allocation(Quantity field) = 0
     * Mark Close Process field checked
     * Update Related PWP record Invoice Amount = 0
     */
    function updateInvoiceLines(recInvoice){
    	var status = true;
    	try{  //Handle error when PWP amount not updated
    		var nLines = recInvoice.getLineCount({ sublistId: 'item' });
    		var aPWP = [];
    		for(var i = 0; i < nLines; i++){
        		var nQty = recInvoice.getSublistValue({
            	    sublistId: 'item',
            	    fieldId: 'quantity',
            	    line: i
            	});
        		var idPWP = recInvoice.getSublistValue({
            	    sublistId: 'item',
            	    fieldId: FLD_INV_PWP,
            	    line: i
            	});
    			if(!isEmpty(idPWP)){
    				aPWP.push(idPWP);
    			}
    			recInvoice.setSublistValue({
    			    sublistId: 'item',
    			    fieldId: FLD_INV_PRE_CLOSE_AMT,
    			    line: i,
    			    value: nQty
    			});
    			recInvoice.setSublistValue({
    			    sublistId: 'item',
    			    fieldId: FLD_INV_CLOSED_PROCESS,
    			    line: i,
    			    value: true
    			});
    			recInvoice.setSublistValue({
    			    sublistId: 'item',
    			    fieldId: 'quantity',
    			    line: i,
    			    value: 0
    			});
    			/*recInvoice.selectLine({
    			    sublistId: 'item',
    			    line: i
    			});
    			var nQty = recInvoice.getCurrentSublistValue({
    			    sublistId: 'item',
    			    fieldId: 'quantity'
    			});
    			var idPWP = recInvoice.getCurrentSublistValue({
    			    sublistId: 'item',
    			    fieldId: FLD_INV_PWP
    			});
    			if(isEmpty(idPWP)){
    				aPWP.push(idPWP);
    			}
    			recInvoice.setCurrentSublistValue({
      	            sublistId: 'item',
      	            fieldId: FLD_INV_PRE_CLOSE_AMT,
      	            value: nQty
      	        });
    			recInvoice.setCurrentSublistValue({
      	            sublistId: 'item',
      	            fieldId: FLD_INV_CLOSED_PROCESS,
      	            value: true
      	        });
    			recInvoice.setCurrentSublistValue({
      	            sublistId: 'item',
      	            fieldId: 'quantity',
      	            value: 0
      	        });
    			recInvoice.commitLine({ 
    		        sublistId: 'item' 
    			});*/

    		}
    		var idInvoice = recInvoice.save({
    		    enableSourcing: true,
    		    ignoreMandatoryFields: false
    		});
			if(idInvoice){
				
				var oFields = new Object();
				//Update invoice amount field on PWP record
				aPWP = aPWP.reduce(function(a,b){
	    		    if (a.indexOf(b) < 0 ) a.push(b);
	    		    return a;
	    		  },[]);
				log.debug('aPWP',aPWP);
				for(var j  =0; j < aPWP.length; j++){
					oFields[FLD_PWP_INVOICE_AMT] = 0;
					record.submitFields({
					    type: REC_PWP,
					    id: aPWP[j],
					    values: {
					        'custrecord_appf_pwp_inv_line_amount': 0
					    }
					});
					/*record.submitFields({
					    type: REC_PWP,
					    id: aPWP[j],
					    values: oFields
					});*/
				}
			}

    		
    	}catch(e){
    		status = false;
    		log.error('Error updating PWP invoice amount',e.message);
    	}
    	
    	return status;
    	
    }
    
    
    /**
     * Evaluate id value is null
     * @param stValue
     */
    function isEmpty(stValue) {
        return (
        	stValue === '' ||
            stValue === '[]' ||
            stValue === 'undefined' ||
            stValue == null ||
            stValue == undefined ||
           (stValue.constructor === Array && stValue.length == 0) ||
           (stValue.constructor === Object &&
           (function(v) {
               for (var k in v) return false;
                   return true;
            })(stValue))
        );
    }
    return {
        beforeLoad: beforeLoad
    };
    
});
