/*
*Script Name: Appf-Vendor Credit CL
*Script Type: Client Script
*Description: This script will do client side validations for Appf-Vendor Credit SL
*Company 	: Appficiency.
*/

var SL_FLD_VENDOR='custpage_vendor';
var SL_FLD_MEDIA_SUPPLIER='custpage_media_supplier';
var SL_FLD_CLIENT='custpage_client';
var SL_FLD_SUBSIDIARY='custpage_subsidiary';
var SL_FLD_MEDIA_SUPPLIER_STATE='custpage_media_supplier_state';
var SL_FLD_CORPORATE_OWNER='custpage_corporate_owner';
var SL_FLD_BUYING_SYSTEM='custpage_buying_system';
var SL_FLD_CURRENCY='custpage_currency';
var SL_FLD_VB_REF='custpage_vb_ref';
var SL_FLD_VB_IO='custpage_vb_io';
var SL_FLD_CREDIT='custpage_credit';
var SL_FLD_TOTAL_CREDIT='custpage_total_credits';
var SL_FLD_TOTAL_CREDIT_MEMOS='custpage_total_credit_memos';
var SL_FLD_DATE_FROM='custpage_date_from';
var SL_FLD_DATE_TO='custpage_date_to';
var SL_FLD_IO='custpage_io';
var SL_FLD_PROJECT='custpage_project';

var SL_SUBLIST='custpage_custom_line';
var SL_COL_UPDATE='custpage_update';
var SL_COL_CREDIT_AMOUNT = 'custpage_credit_amount';

var SCRIPT_SL_VENDOR_CREDIT_SUITELET='customscript_appf_vendor_credit_sl';
var DEPLOY_SL_VENDOR_CREDIT_SUITELET='customdeploy_appf_vendor_credit_sl';

function clientFieldChange(type, name, linenum){
	  if(name == SL_FLD_VENDOR){
		  var vend = nlapiGetFieldValue(SL_FLD_VENDOR);
			if(vend != null && vend != ''){
				var curr = nlapiLookupField('vendor', vend, 'currency');
			if(curr != null && curr != '')
				nlapiSetFieldValue(SL_FLD_CURRENCY, curr);
			}
			else{
				nlapiSetFieldValue(SL_FLD_CURRENCY, '');
			}
	     }
	  if(type == SL_SUBLIST){
	     	if(name == SL_COL_UPDATE){
	          var totCreditAmt = 0;
	          var totCreditMemos = 0;
	           var count = nlapiGetLineItemCount(SL_SUBLIST);
	          	for(var c=1; c<=count; c++){
	              var selected = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, c);
	              if(selected == 'T'){
	                 totCreditMemos++;
	                var creditAmt = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_CREDIT_AMOUNT, c);
	                
	                totCreditAmt = Number(totCreditAmt) + Number(creditAmt);
	                 }
	            }
	          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT, Number(totCreditAmt));
	          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, totCreditMemos);
	           }
	     }
	}


function applyFilter(){

	var vendor = nlapiGetFieldValue(SL_FLD_VENDOR);
	if(vendor == null || vendor == '')
		vendor = '';
	
	var mediaSupp = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER);
	if(mediaSupp == null || mediaSupp == '')
		mediaSupp = '';
	
	var dateFrom = nlapiGetFieldValue(SL_FLD_DATE_FROM);
	if(dateFrom == null || dateFrom == '')
		dateFrom = '';
	var dateTo = nlapiGetFieldValue(SL_FLD_DATE_TO);
	if(dateTo == null || dateTo == '')
		dateTo = '';
	var ioNum = nlapiGetFieldValue(SL_FLD_IO);
	if(ioNum == null || ioNum == '')
		ioNum = '';
	var project = nlapiGetFieldValue(SL_FLD_PROJECT);
	if(project == null || project == '')
		project = '';
	
	var client = nlapiGetFieldValue(SL_FLD_CLIENT);
	if(client == null || client == '')
		client = '';
	
	var subsidiary = nlapiGetFieldValue(SL_FLD_SUBSIDIARY);
	if(subsidiary != null && subsidiary != '')
		applyFilter = true;
	
	var mediaSuppState = nlapiGetFieldValue(SL_FLD_MEDIA_SUPPLIER_STATE);
	if(mediaSuppState == null || mediaSuppState == '')
		mediaSuppState = '';
	
	var corporateOwner = nlapiGetFieldValue(SL_FLD_CORPORATE_OWNER);
	if(mediaSuppState == null || mediaSuppState == '')
		mediaSuppState = '';
	
	var buyingSystem = nlapiGetFieldValue(SL_FLD_BUYING_SYSTEM);
	if(buyingSystem == null || buyingSystem == '')
		buyingSystem = '';
	
	var currency = nlapiGetFieldValue(SL_FLD_CURRENCY);
	if(currency == null || currency == '')
		currency = '';
	
	var vbRef = nlapiGetFieldValue(SL_FLD_VB_REF);
	if(vbRef == null || vbRef == '')
		vbRef = '';
	
	var vbIO = nlapiGetFieldValue(SL_FLD_VB_IO);
	if(vbIO == null || vbIO == '')
		vbIO = '';
	
	/*var credit = nlapiGetFieldValue(SL_FLD_CREDIT);
	if(credit == null && credit == '')
		credit = '';*/
	
	if(subsidiary != null && subsidiary != ''){
	var suiteletURL = nlapiResolveURL('SUITELET', SCRIPT_SL_VENDOR_CREDIT_SUITELET, DEPLOY_SL_VENDOR_CREDIT_SUITELET);
	suiteletURL=suiteletURL+'&vendor='+vendor+'&mediasupp='+mediaSupp+'&subs='+subsidiary+'&applyFils=T'+'&dtFrom='+dateFrom+'&dtTo='+dateTo+'&io='+ioNum+'&proj='+project+'&currency='+currency;
	window.open(suiteletURL,'_self');
	}
	else {
		alert('Please select the field value : Subsidiary');
	}	
	
}


function onSaveVCSL() {

	var counter=0;
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	if(count > 0){
	for(var i=1; i<=count; i++){
		var checkbox=nlapiGetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i);
		if(checkbox == 'T')
			counter++;
	}
	
	}
	if(counter == 0){
		alert('Please Select atleast one line to Proceed.');
		return false;
	}
	else
	{
		var submitConfirmation= confirm('Selected transactions will be processed for Vendor Credit Suitelet, Click OK to proceed.');
    if (submitConfirmation== true)
    {
		return true;
    }
   else
   {
       return false;
   }
	}
		
}


function unmarkAll(){
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	for(var i=1; i<=count; i++){
		nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i, 'F');
	}
	nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT, 0);
	          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, 0);
}

function markAll(){
	var count=nlapiGetLineItemCount(SL_SUBLIST);
	var totCreditAmt = 0;
	          var totCreditMemos = 0;
	          	for(var c=1; c<=count; c++){
					nlapiSetLineItemValue(SL_SUBLIST, SL_COL_UPDATE, c, 'T');
	              
	                 totCreditMemos++;
	                var creditAmt = nlapiGetLineItemValue(SL_SUBLIST, SL_COL_CREDIT_AMOUNT, c);
	                
	                totCreditAmt = Number(totCreditAmt) + Number(creditAmt);
	                 
	            }
	          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT, Number(totCreditAmt));
	          nlapiSetFieldValue(SL_FLD_TOTAL_CREDIT_MEMOS, totCreditMemos);
	
}
