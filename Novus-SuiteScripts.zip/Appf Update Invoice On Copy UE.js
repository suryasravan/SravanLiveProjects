/*
* Script Name : Appf Update Invoice On Copy UE
* Script Type : User Event
* Deployed On : Invoice
* Event Type  : BeforeLoad
* Description : The script updates some fields of invoice on Copy of it.
* company     : Appficeincy Inc.
* */
var COL_APPF_INV_LINE_AMOUNT_PAID='custcol_appf_pwp_inv_line_amt_paid';
var APPF_PAYMENT_APPLICATION_LOG_RECORDS='custbody_appf_pmt_appl_log_rec_links';
var PAYMENT_APPLICATION_SUITELET_STATUS='custbody_appf_cst_pmt_status';
var PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING=3;
function beforeLoad(type,form,request)
{
  	try
      {
        if(type == 'copy')
          {
        var recId = nlapiGetRecordId();
		nlapiSetFieldValue(APPF_PAYMENT_APPLICATION_LOG_RECORDS,null);
       nlapiSetFieldValue(PAYMENT_APPLICATION_SUITELET_STATUS,PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING);
		var count=nlapiGetLineItemCount('item');
		//nlapiLogExecution('debug','count:',count);
		for(var i=1;i<=count;i++)
		{
			nlapiSelectLineItem('item',i)
			nlapiSetCurrentLineItemValue('item',COL_APPF_INV_LINE_AMOUNT_PAID,'');
			nlapiCommitLineItem('item');
		}
          }
      }
  catch(e)
    {
      nlapiLogExecution( 'DEBUG', 'Error details:', e.toString());
    }
}