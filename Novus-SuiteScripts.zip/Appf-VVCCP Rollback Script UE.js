/**
	 * Script Name : Appf-VVCCP Rollback Script 
	 * Script Type : User Event
	 * Event  Type : Before Load
	 * Version    Date            Author           		Remarks
	 * 1.00       4-2-2020     	Debendra Panigrahi		The script displays a button "Initiate Cancellation" on VVCCP Records 
	 *													with status any of Pending Batch OR Authorized OR Partially Charged
	 *
	 *
	 * Company 	 : Appficiency. 
*/
//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_AUTHORIZATION_RECEIVE_DATE  ='custrecord_authorization_receive_date';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_UPDATES_RELATED_FILES_FOLDERID =979;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8;	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9;
var VVCCP_STATUS_PARTIALLY_CHARGED =10;

var BTN_INITIATE_CANCELLATION='custpage_initiate_cancellation';
var SUITELET_VVCCP_ROLLBACK_HELPER_SCRIPT_ID='customscript_appf_vvccp_rollback_helper';
var SUITELET_VVCCP_ROLLBACK_HELPER_DEPLOY_ID='customdeploy_appf_vvccp_rollback_helper';
function beforeLoad(type,form,request)
{
	try
	{
		if(type == 'view')
		{
			var recId = nlapiGetRecordId();
			var recType = nlapiGetRecordType();
			var vvccpStatus=nlapiGetFieldValue(FLD_VVCCP_STATUS);
          nlapiLogExecution('debug','vvccpStatus:',vvccpStatus);
			if(vvccpStatus == VVCCP_STATUS_PENDING_BATCH ||vvccpStatus == VVCCP_STATUS_AUTHORIZED || vvccpStatus ==VVCCP_STATUS_PARTIALLY_CHARGED)
			{
				var url=nlapiResolveURL('SUITELET',SUITELET_VVCCP_ROLLBACK_HELPER_SCRIPT_ID,SUITELET_VVCCP_ROLLBACK_HELPER_DEPLOY_ID);
				url+='&recId='+recId;
				form.addButton(BTN_INITIATE_CANCELLATION,'Initiate Cancellation','window.open(\''+url+'\',\'_self\')');
			}
		}
	}	
	catch(e)
	{
		nlapiLogExecution('debug','Error Deatils:',e.toString());
	}
}	
