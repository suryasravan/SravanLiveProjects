/*
* Script Name : Appf Client Payment Application UE
* Script Type : User Event
* Deployed On : Payment
* Event Type  : BeforeLoad
* Description : The script put button on the Payment called "Apply Payment" and on click of it call a suitelet to process the payment.
* company     : Appficeincy Inc.
* */
var SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID='customscript_client_paymt_application_sl';
var SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID='customdeploy_client_paymt_application_sl';
var BTN_APPLY_PAYMENT='custpage_apply_payment';

var ADMIN_ROLE = '3';

function beforeLoad(type,form,request)
{
  	try
      {
        if(type == 'view')
		{
        var recId = nlapiGetRecordId();
          var record = nlapiLoadRecord(nlapiGetRecordType(), recId);
          var unapplied = record.getFieldValue('unapplied');
          if (unapplied == null || unapplied == '')
            unapplied = 0;
		var clientPD = record.getFieldValue('customer');
//if (unapplied > 0)
  //{
		var url=nlapiResolveURL('SUITELET',SUITELET_CLIENT_PAYMENT_APPLICATION_SCRIPT_ID,SUITELET_CLIENT_PAYMENT_APPLICATION_DEPLOY_ID);
  		url=url+'&clientPD='+clientPD
		url+='&recId='+recId;
		form.addButton(BTN_APPLY_PAYMENT,'Apply Payment','window.open(\''+url+'\',\'_self\')');
		//}
      }
     //disabld Payall, auto apply, clear buttons  
     /*if(type == 'create' || type == 'edit'){
       
		var currentRole = nlapiGetRole();
       nlapiLogExecution('debug', 'currentRole', currentRole);
		if(currentRole != ADMIN_ROLE){
		
          
          var applyField = nlapiGetLineItemField('apply', 'apply');
          if(applyField != null && applyField != '')
            applyField.setDisplayType('disabled');
          
          
           var applyFieldCr = nlapiGetLineItemField('credit', 'apply');
          if(applyFieldCr != null && applyFieldCr != '')
            applyFieldCr.setDisplayType('disabled');
		}
	}*/
        
      }
  catch(e)
    {
      nlapiLogExecution( 'DEBUG', 'Error details:', e.toString());
    }
}