/*Script Name: Appf-Unconsolidate CI SL
 *Script Type: Suitelet
 *Description: This script updates invoice and credit memo line fields linked with CI Record.
 *Company 	 : Appficiency.
 */

var CUSTOM_RECORD_CI='customrecord_appf_ci_record';
var FLD_COL_CI_RECORD='custcol_appf_ci_record';
var FLD_COL_CI_STATUS='custcol_appf_ci_status';
var FLD_COL_CI_LOG='custcol_appf_ci_log';
var VAL_STATUS_NOT_STARTED='1';
var FLD_CI_INVOICES='custrecord_appf_ci_invoices';
var FLD_CI_NO_OF_INVOICES='custrecord_appf_ci_number_invoices';
var FLD_CI_AMOUNT='custrecord_appf_ci_amount';
var FLD_CI_DUE_DATE = 'custrecord_appf_ci_due_date';
var FLD_CI_TERMS = 'custrecord_appf_ci_terms';
var FLD_CI_DISCOUNT='custrecord_appf_ci_discount';
var FLD_CI_TAX='custrecord_appf_ci_tax';
var FLD_CI_SUBTOTAL='custrecord_appf_ci_subtotal';
var FLD_CI_CURRENCY='custrecord_appf_ci_currency';
var FLD_CI_DATE='custrecord_appf_ci_date';
var FLD_CI_UNCONSOLIDATION_STATUS = 'custrecord_appf_ci_unconsolidate_status';
var SPARAM_REC_ID = 'custscript_appf_unconsolidate_ci_id';
var VAL_UNCONSOLIDATION_STATUS_INPROGRESS = 1;
var VAL_UNCONSOLIDATION_STATUS_COMPLETE = 2;

/**
 * @param {String} type Context Types: scheduled, ondemand, userinterface, aborted, skipped
 * @returns {Void}
 */
function scheduled(type) {
	try{
        var context = nlapiGetContext();
    	var customCIRecID = context.getSetting('SCRIPT', SPARAM_REC_ID);
        
        if(customCIRecID != null && customCIRecID != '')
        {
    
	         var isTranLineFieldsRemove=false;
	    	 var mainObj = {};
	
			 var filters = [];
			 filters.push(new nlobjSearchFilter('mainline', null, 'is','F'));
			 filters.push(new nlobjSearchFilter(FLD_COL_CI_RECORD, null, 'is', customCIRecID));
			 filters.push(new nlobjSearchFilter('type', null, 'anyof', ['CustInvc','CustCred']));
		  	 
		  	 var searchResult = nlapiSearchRecord('transaction', null, filters, null); 
		  	 var nLineCount = 0;
		  	 
		 	 if (searchResult != null && searchResult != '')
		 	 {
		 		for (var i = 0; i < searchResult.length; i++)
		 		{
					 var transactionRecID = searchResult[i].getId();
					 var transactionRecType = searchResult[i].getRecordType();
		
					 nlapiLogExecution('debug','transactionRecID',transactionRecID);
					 nlapiLogExecution('debug','transactionRecType',transactionRecType);
					
					 var groupObj={};
					 var transctionString = transactionRecID+'_'+transactionRecType;
		
					 if(!mainObj.hasOwnProperty(transactionRecID))
					 {
						mainObj[transactionRecID] = {};
						mainObj[transactionRecID].type = transactionRecType;
		
					 }	
					 
					 nLineCount++;
			  
	            }
		     }
			 nlapiLogExecution('debug', 'mainObj',JSON.stringify(mainObj));
			 nlapiLogExecution('DEBUG','nLineCount before lines are processed',nLineCount);
		     if(mainObj != null && mainObj != '')
	         {
		    	 for(var prop in mainObj)
		    	 {
		    	  
		    		 //check remaining usage
		    		 if(context.getRemainingUsage() <= 500 /* && parseInt(s)+1 < searchResults.length*/) {
		    			 var params = {};
		    			 //params[SPARAM_SEARCH_PARAMETER] = searchId;
		    			 params[SPARAM_REC_ID] = customCIRecID;
		    			 
		    			 nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params);
		    			 nlapiLogExecution('debug','reschedule',JSON.stringify(params));
		    			 break;
		    		 }else{
		    			 
				    	 var tranID=prop;
				 		 var tranType=mainObj[prop].type;  
				    	
					     nlapiLogExecution('debug','tranID',tranID);
					     nlapiLogExecution('debug','tranType',tranType);
					     
			             if(tranID != null && tranID != '' && tranType != null && tranType != '')
			             {
					 	     var tranRec = nlapiLoadRecord(tranType,tranID);
						     var itemCount = tranRec.getLineItemCount('item');
						     nlapiLogExecution('debug','itemCount',itemCount);
				
					         for(var j=1; j<=itemCount; j++)
					         {
						    	var tranLineCIRecord = tranRec.getLineItemValue('item',FLD_COL_CI_RECORD, j);
								nlapiLogExecution('debug','tranLineCIRecord',tranLineCIRecord);
								nlapiLogExecution('debug','customCIRecID',customCIRecID);
					
						    	if( tranLineCIRecord == customCIRecID)
						    	{
						            tranRec.selectLineItem('item', j);
							    	tranRec.setCurrentLineItemValue('item',FLD_COL_CI_RECORD,'');
							    	tranRec.setCurrentLineItemValue('item',FLD_COL_CI_LOG,'');
							    	tranRec.setCurrentLineItemValue('item',FLD_COL_CI_STATUS,VAL_STATUS_NOT_STARTED);
									tranRec.commitLineItem('item');
							    	isTranLineFieldsRemove=true;
						    	}
					   
					         }
					         var tranRecID=nlapiSubmitRecord(tranRec,true,true);
						     nlapiLogExecution('DEBUG','updated tran Rec ID:',tranRecID);
						     nLineCount--;
			             }
		    			 
	                	
		    		 }
		    	  


		      }
	         }
		     
		     nlapiLogExecution('DEBUG','nLineCount after lines are processed',nLineCount);
		     if(nLineCount == 0){  //all lines are unconsolidated
		    	 
			     var customCIRec = nlapiLoadRecord(CUSTOM_RECORD_CI, customCIRecID);
		         
			     if(isTranLineFieldsRemove)
			     {
				 	customCIRec.setFieldValue(FLD_CI_INVOICES,'');
				 	customCIRec.setFieldValue(FLD_CI_NO_OF_INVOICES,'');
				 	customCIRec.setFieldValue(FLD_CI_AMOUNT,'');
				 	customCIRec.setFieldValue(FLD_CI_DUE_DATE,'');
				 	customCIRec.setFieldValue(FLD_CI_TERMS,'');
					customCIRec.setFieldValue(FLD_CI_DATE,'');
				 	customCIRec.setFieldValue(FLD_CI_TAX,'');
				 	customCIRec.setFieldValue(FLD_CI_SUBTOTAL,'');
				 	customCIRec.setFieldValue(FLD_CI_CURRENCY,'');
				 	//set status to complete
				 	customCIRec.setFieldValue(FLD_CI_UNCONSOLIDATION_STATUS,VAL_UNCONSOLIDATION_STATUS_COMPLETE);
			     }
			     
			    
			    

				var customCIRecID=nlapiSubmitRecord(customCIRec,true,true);
				nlapiLogExecution('DEBUG','updated custom CI Rec ID:',customCIRecID);
				//if(customCIRecID != null && customCIRecID != '')
				//response.sendRedirect('RECORD',CUSTOM_RECORD_CI,customCIRecID);
		    	 
		     }

	
        }   
	 } catch (e) {
		 if( e instanceof nlobjError ){
		      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
		      }
		      else{
		      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
		      }
			 
	 }
}
