/*Script Name: Appf-Vendor Credit Creation SL
 *Script Type: Suitelet
 *Description: This script will display the Vendor Credit Creation form with filters and results as VB lines and creates a appf - Vendor Credit Creation Log Record with VBs selected
 *Company 	 : Appficiency.
 */
var SL_TITLE='Vendor Credit Suitelet';
var SL_FLD_VENDOR='custpage_vendor';
var SL_FLD_MEDIA_SUPPLIER='custpage_media_supplier';
var SL_FLD_INTERM='custpage_interm';
var SL_FLD_CLIENT='custpage_client';
var SL_FLD_SUBSIDIARY='custpage_subsidiary';
var SL_FLD_MEDIA_SUPPLIER_STATE='custpage_media_supplier_state';
var SL_FLD_CORPORATE_OWNER='custpage_corporate_owner';
var SL_FLD_BUYING_SYSTEM='custpage_buying_system';
var SL_FLD_CURRENCY='custpage_currency';
var SL_FLD_VB_REF='custpage_vb_ref';
var SL_FLD_VB_IO='custpage_vb_io';
var SL_FLD_CREDIT='custpage_credit';
var SL_FLD_TOTAL_CREDIT='custpage_total_credits';
var SL_FLD_TOTAL_CREDIT_MEMOS='custpage_total_credit_memos';
var SL_FLD_DATE_FROM='custpage_date_from';
var SL_FLD_DATE_TO='custpage_date_to';
var SL_FLD_IO='custpage_io';
var SL_FLD_PROJECT='custpage_project';

var SL_SUBLIST='custpage_custom_line';
var SL_COL_UPDATE='custpage_update';
var SL_COL_INTERNAL_ID='custpage_internal_id';
var SL_COL_CREDIT_AMOUNT = 'custpage_credit_amount';
var FLD_COL_IO='custcol_appf_ionum';

var CUSTOM_LIST_BUYING_SYSTEM='customlist_appf_buying_system';

var CUSTOM_RECORD_MEDIA_SUPPLIER='customrecord_appf_media_supplier';
var CUSTOM_RECORD_INTERM='customrecord_appf_interim_vb';
var CUSTOM_RECORD_CONSOLIDATED_INVOICE='customrecord_nsts_ci_consolidate_invoice';
var BTN_APPLY_FILTER='custpage_apply_button';
var BTN_MARK_ALL='custpage_mark_All';
var BTN_UNMARK_ALL='custpage_unmark_All';
var SPARAM_VENDOR_CREDIT_SS='custscript_appf_vendor_credit_ss';
var SPARAM_VENDOR_CREDIT_FOLDER_ID='custscript_appf_vendor_credit_fld_id';

var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_PROJECT='custrecord_appf_pwp_project';
var FLD_CLIENT='custrecord_appf_pwp_client_link';
var FLD_COL_MEDIA_SUPPLIER='custcol_appf_publisher';
var FLD_COL_VENDOR='custcol_appf_po_vendor_name';
var FLD_COL_PWP_CUSTOM_RECORD='custcol_appf_pwp_custom_record';
var CLIENT_SCRIPT='customscript_appf_vendor_credit_cl';

var FLD_INV_MEDIA_TYPE='custbody_appf_print_mediatype';
var FLD_COL_INV_CI_RECORD='custcol_appf_ci_record';
var FLD_COL_IO='custcol_appf_ionum';
var FLD_COL_VB_MEDIA_SUPPLIER='custcol_appf_publisher';
var FLD_COL_VENDOR_NAME='custcol_appf_po_vendor_name';
var FLD_MEDIA_SUPPLIER_STATE = 'custrecord_appf_ms_state';
var FLD_COL_CORPORATE_OWNER='custcol_appf_corporateowner';
var FLD_VB_BUYING_SYSTEM='custbody_appf_buying_system';
var FLD_COL_IO_NUM='custcol_appf_ionum';

var CUSTOM_RECORD_CREDIT_CREATION_LOG = 'customrecord_appf_vend_crd_log';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_vend_crd_tl_pro';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_vend_crd_inv_completed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_vend_crd_perc_processed';
var FLD_CREATED_BY = 'custrecord_appf_vend_crd_created_by';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_vend_crd_status';
var FLD_DATA_FILE = 'custrecord_appf_vend_crd_data_file';
var FLD_STATUS_FILE  = 'custrecord_appf_vend_crd_error_file';
var FLD_ERROR_LOG = 'custrecord_appf_vend_crd_error_log';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_vend_crd_client';
var FLD_CURRENCY = 'custrecord_appf_vend_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_vend_crd_link';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_vend_crd_invoice_link';
var VALUE_STATUS_IN_PROGRESS='2';
var FLD_COL_VB_LINE_ID='custcol_appf_vendorbill_line_id';
var SCRIPT_UPDATE_VENDOR_CREDIT_CREATION_SC = 'customscript_appf_update_bills_credit_sc';
var SPARAM_CREDIT_CREATION_LOG_ID_1 = 'custscript_appf_vendor_credit_log_id';
var SAPARM_SELECTED_LINES_FILE_ID='custscript_appf_selected_vb_file_id';

function vendorCreditSL(request, response){
	var context = nlapiGetContext();
	var ssID = context.getSetting('SCRIPT', SPARAM_VENDOR_CREDIT_SS);
	var folderID = context.getSetting('SCRIPT', SPARAM_VENDOR_CREDIT_FOLDER_ID);
	if(ssID!=null && ssID!='')
    {
		var loadSS=nlapiLoadSearch(null, ssID);
    	var filts = loadSS.getFilters();
		var columns=loadSS.getColumns();
	 	var ssType = loadSS.getSearchType();
	  if(request.getMethod() == 'GET'){
		try{
		var applyfilter = false;
		if(request.getParameter('applyFils') == 'T')
		applyfilter = true;
		var vendor=request.getParameter('vendor');
		var mediasupp=request.getParameter('mediasupp');
		var project=request.getParameter('proj');
		var mediasuppstate=request.getParameter('mediasuppstate');
		var corporateowner=request.getParameter('corporateowner');
		var client=request.getParameter('client');
		var curr=request.getParameter('currency');
		var buyingsystem=request.getParameter('buysystem');
		var subsidiary=request.getParameter('subs');
		var vbref=request.getParameter('vbref');
		var vbio=request.getParameter('vbio');
		var creditNum=request.getParameter('credit');
		var dateFrom=request.getParameter('dtFrom');
		var dateTo=request.getParameter('dtTo');
		var io=request.getParameter('io');
		var form = nlapiCreateForm(SL_TITLE);
		form.setScript(CLIENT_SCRIPT);
		
		var vendorFld = form.addField(SL_FLD_VENDOR, 'select', 'Vendor','vendor');
		if(vendor != null && vendor != '')
		vendorFld.setDefaultValue(vendor);
		
		var clientFld = form.addField(SL_FLD_CLIENT, 'select','Client','customer');
		
		if(client != null && client != '')
		clientFld.setDefaultValue(client);
		
		var mediaSuppFld = form.addField(SL_FLD_MEDIA_SUPPLIER, 'select','Media Supplier',CUSTOM_RECORD_MEDIA_SUPPLIER);
		if(mediasupp != null && mediasupp != '')
		mediaSuppFld.setDefaultValue(mediasupp);
	
	
		
		var mediaSuppStateField = form.addField(SL_FLD_MEDIA_SUPPLIER_STATE, 'text','Media Supplier State');
		if(mediasuppstate != null && mediasuppstate != '')
		mediaSuppStateField.setDefaultValue(mediasuppstate);

		var corporateOwnerField = form.addField(SL_FLD_CORPORATE_OWNER, 'text','Corporate Owner');
		if(corporateowner != null && corporateowner != '')
		corporateOwnerField.setDefaultValue(corporateowner);
		
		var ioFld = form.addField(SL_FLD_IO, 'text', 'IO #');
		if(io != null && io != '')
			ioFld.setDefaultValue(io);
		var projectFld = form.addField(SL_FLD_PROJECT, 'select', 'Project','job');
		if(project != null && project != '')
			projectFld.setDefaultValue(project);
		
		var dateFldFrom = form.addField(SL_FLD_DATE_FROM, 'date', 'Date (From)');
		if(dateFrom != null && dateFrom != '')
			dateFldFrom.setDefaultValue(dateFrom);
		var dateFldTo = form.addField(SL_FLD_DATE_TO, 'date', 'Date (To)');
		if(dateTo != null && dateTo != '')
			dateFldTo.setDefaultValue(dateTo);
		
	    var currencyFld = form.addField(SL_FLD_CURRENCY, 'select', 'Currency','currency');
		currencyFld.setDisplayType('disabled');
	   if(curr != null && curr != '')
	    currencyFld.setDefaultValue(curr);
				
		var buyingSystemFld = form.addField(SL_FLD_BUYING_SYSTEM, 'select', 'Buying System',CUSTOM_LIST_BUYING_SYSTEM);
		if(buyingsystem != null && buyingsystem != '')
		buyingSystemFld.setDefaultValue(buyingsystem);
		
		var subsidiaryFld = form.addField(SL_FLD_SUBSIDIARY, 'select','Subsidiary','subsidiary');
		if(subsidiary != null && subsidiary != '')
		subsidiaryFld.setDefaultValue(subsidiary);
		subsidiaryFld.setMandatory(true)
		//subsidiaryFld.setDisplayType('disabled');

		    
		var vbRefField = form.addField(SL_FLD_VB_REF, 'text','VB Ref#');
		if(vbref != null && vbref != '')
		vbRefField.setDefaultValue(vbref);
						  
		var vbIOField = form.addField(SL_FLD_VB_IO, 'text','VB IO#');
		if(vbio != null && vbio != '')
		vbIOField.setDefaultValue(vbio);
						
		/*var creditNumFld = form.addField(SL_FLD_CREDIT, 'text', 'Credit #');
		if(creditNum != null && creditNum != '')
		creditNumFld.setDefaultValue(creditNum);*/
						  
		var totalCreditFld = form.addField(SL_FLD_TOTAL_CREDIT, 'currency', 'Total Credits').setDisplayType('disabled');
		var totalCreditMemos = form.addField(SL_FLD_TOTAL_CREDIT_MEMOS, 'integer', 'Total Vendor Credits').setDisplayType('disabled');
		
		if(applyfilter == true)
        {
		var suiteletSublist = form.addSubList(SL_SUBLIST,'list', 'Bills');
		suiteletSublist.addButton(BTN_MARK_ALL, 'Mark All', 'markAll();')
		suiteletSublist.addButton(BTN_UNMARK_ALL, 'Unmark All', 'unmarkAll();')
	    suiteletSublist.addField(SL_COL_UPDATE, 'checkbox', 'Select').setDisplayType('entry');
	    suiteletSublist.addField(SL_COL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');
		suiteletSublist.addField(SL_FLD_INTERM, 'select','Vendor Bill Link (Interim)',CUSTOM_RECORD_INTERM).setDisplayType('entry');

		var filters =[];
		if(vendor != null && vendor != '')
		filters.push(new nlobjSearchFilter('name', null, 'anyof',vendor));
		
		if(mediasupp != null && mediasupp != '')
		filters.push(new nlobjSearchFilter(FLD_COL_VB_MEDIA_SUPPLIER, null, 'anyof',mediasupp));
		
		if(mediasuppstate != null && mediasuppstate != '')
		filters.push(new nlobjSearchFilter(FLD_MEDIA_SUPPLIER_STATE, FLD_COL_VB_MEDIA_SUPPLIER, 'is', mediasuppstate));
		
		if(corporateowner != null && corporateowner != '')
		filters.push(new nlobjSearchFilter(FLD_COL_CORPORATE_OWNER, null, 'is',corporateowner));

		if(project != null && project != '')
		filters.push(new nlobjSearchFilter('internalid', 'job', 'anyof',project));
		
		if(io != null && io != '')
		filters.push(new nlobjSearchFilter(FLD_COL_IO, null, 'is',io));
		
		
		if(buyingsystem != null && buyingsystem != '')
		filters.push(new nlobjSearchFilter(FLD_VB_BUYING_SYSTEM, null, 'anyof',buyingsystem));
		
		if(subsidiary != null && subsidiary != '')
		filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof',subsidiary));
		
		if(dateFrom != null && dateFrom != '' && dateTo != null && dateTo != '')
		filters.push(new nlobjSearchFilter('trandate', null, 'within', dateFrom, dateTo));
		if(dateFrom != null && dateFrom != '' && (dateTo == null || dateTo != ''))
		filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', dateFrom));
		if((dateFrom == null || dateFrom == '') && dateTo != null && dateTo != '')
		filters.push(new nlobjSearchFilter('trandate', null, 'onorbefore', dateTo));
		
		
    	 	var colArray=[];
    		var colIndex=1;
			var scriptfieldcounter = 1;
			for(var c=0;c<columns.length;c++)
			{
				var colObj = columns[c];
				var colName = colObj.getName();
				var colLabel = colObj.getLabel();
				
				if(colArray.indexOf(colName) == -1)
				{
					colArray.push(colName);
				}
				else
				{
					colName=colName+colIndex;
                  	colArray.push(colName);
					colIndex++;
				}
			
			//suiteletSublist.addField('custpage_'+colName, 'text', colLabel);
				if(colLabel.toUpperCase() == 'VENDOR CREDIT AMOUNT'){
					suiteletSublist.addField(SL_COL_CREDIT_AMOUNT, 'text', colLabel);
				}
				else{
					if (colLabel != 'Script Use DNR')
                    {
					suiteletSublist.addField('custpage_'+colName, 'text', colLabel);
                    }
                  else
                    {
                      var scriptField =suiteletSublist.addField('custpage_scriptfield'+scriptfieldcounter, 'text', colLabel);
						scriptField.setDisplayType('hidden');
                      scriptfieldcounter++;
                    }
				}
			
		    }
			var resultFilters = filters.concat(filts);
            var ssResultValue='';
            var totalCredit='';
            var idArray=[];
			var searchResults=getAllSearchResults(ssType, resultFilters, columns);
			if (searchResults != null && searchResults != '') {
				totalCredit=searchResults.length;
				for(var s = 0; s < searchResults.length; s++) {
					
					var result = searchResults[s];
					var internalid = result.getId();
					idArray.push(internalid);
					
					var colIndex = 1;
					var colArray = [];
					var scriptfieldcounter = 1;
					for(var c=0;c<columns.length;c++){
                      	var colObj = columns[c];
						var columnName = colObj.getName();
						var colLabel = colObj.getLabel();

						var ssResultValue = result.getValue(colObj);
						if(colObj.getType() == 'select')
						{
						 ssResultValue = result.getText(colObj);                        
						}
						if(colArray.indexOf(columnName) == -1)
						{
							colArray.push(columnName);
						}
						else
						{
							columnName=columnName+colIndex;
                          	colArray.push(columnName);
							colIndex++;
						}
						suiteletSublist.setLineItemValue(SL_COL_INTERNAL_ID, s+1, internalid);
						if(columnName == 'transactionnumber'){
						var url=nlapiResolveURL('RECORD','purchaseorder',internalid);
						var redirect='<a href='+url+' target="_blank">'+ssResultValue+'</a>';
						ssResultValue = redirect;
						}
						//suiteletSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
						if(colLabel.toUpperCase() == 'VENDOR CREDIT AMOUNT'){
							suiteletSublist.setLineItemValue(SL_COL_CREDIT_AMOUNT, s+1, ssResultValue);
						}
						else{
							if (colLabel != 'Script Use DNR')
							{
							suiteletSublist.setLineItemValue('custpage_'+columnName, s+1, ssResultValue);
							}
							else
							{
							  suiteletSublist.setLineItemValue('custpage_scriptfield'+scriptfieldcounter, s+1, ssResultValue);								
							  scriptfieldcounter++;
							}
						}				

					}
				}

			}
        
		}
		form.addButton(BTN_APPLY_FILTER, 'Apply Filters', 'applyFilter()');
		form.addSubmitButton('Submit');
		response.writePage(form);
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}

		
	}
	  else{
		  var vendor = request.getParameter(SL_FLD_VENDOR);
		  var currency = request.getParameter(SL_FLD_CURRENCY);
		    
		  var count = request.getLineItemCount(SL_SUBLIST);
		  var totalCreditSelected=0;
		  var csvData= '';
		  var idArr=[];
          var internalIdsArr=[];
		  var selectedBills = {};
           var  intermIdsArr=[];
		  try{
			 
			  if(columns != null && columns != '')
			  {
			  csvData += 'Internal ID,';
			  csvData += 'Intrem ID,';
			  for(var c=0;c<columns.length;c++)
			  {
			  var colObj = columns[c];
			  var columnLabel = colObj.getLabel();
			  csvData += columnLabel;
			  csvData = csvData+',';
			  }
	        
			  csvData = csvData.slice(0, -1)+'\n';
			  for(var i = 1; i <= count; i++)
			  {
			  	var checkBox = request.getLineItemValue(SL_SUBLIST, SL_COL_UPDATE, i);
			  	
			  if(checkBox == 'T')
			  {
				   var intermIds = request.getLineItemValue(SL_SUBLIST, SL_FLD_INTERM, i);
				   if (intermIds == null)
					   intermIds = '';
				  var internalID = request.getLineItemValue(SL_SUBLIST, SL_COL_INTERNAL_ID, i);
					internalIdsArr.push(internalID);
					if (intermIds)
					intermIdsArr.push(intermIds);
					if(!selectedBills.hasOwnProperty(internalID)){
						selectedBills[internalID] = [];
					}	
					
				   csvData += internalID+',';
				   csvData += intermIds+',';
	              totalCreditSelected++;
				 var scriptfieldcounter = 1;
	          	for(var c=0;c<columns.length;c++)
			  {
	          		var colObj = columns[c];
	      		  var columnName = colObj.getName();
				  var colLabel = colObj.getLabel();
				var colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_'+columnName, i);
				 if(colLabel.toUpperCase() == 'VENDOR CREDIT AMOUNT'){
					  colValue = request.getLineItemValue(SL_SUBLIST, SL_COL_CREDIT_AMOUNT, i);
				  }
				  if (colLabel == 'Script Use DNR')
                    {
						colValue = request.getLineItemValue(SL_SUBLIST, 'custpage_scriptfield'+scriptfieldcounter, i);
                      scriptfieldcounter++;
					}
				if(columnName == FLD_COL_VB_LINE_ID){
					  selectedBills[internalID].push(colValue);
				  }
	              
				  csvData += colValue+',';
				}  
	            csvData = csvData.slice(0, -1)+'\n';
			  }
			  }
			  }
			  	internalIdsArr = removeDuplicates(internalIdsArr);

			  var timeStamp = new Date().getTime();
			  var csvFile = nlapiCreateFile('SelectedLines_'+timeStamp+'.csv', 'CSV', csvData)
			  csvFile.setFolder(folderID);
			  var fileID = nlapiSubmitFile(csvFile);
			  var createdBy = nlapiGetUser();
			  
			 var creditCreationLogRec = nlapiCreateRecord(CUSTOM_RECORD_CREDIT_CREATION_LOG);
	          //var creditCreationLogRec = nlapiLoadRecord(CUSTOM_RECORD_CREDIT_CREATION_LOG, '2');
			  creditCreationLogRec.setFieldValue(FLD_CREDIT_CREATION_STATUS,VALUE_STATUS_IN_PROGRESS);
			  if(createdBy != null && createdBy != '')
			  creditCreationLogRec.setFieldValue(FLD_CREATED_BY,createdBy);
			  
			  if(totalCreditSelected != null && totalCreditSelected != '')
			  creditCreationLogRec.setFieldValue(FLD_TOT_CREDITS_TO_PROCESS,totalCreditSelected);

			  if(fileID != null && fileID != '')
			  creditCreationLogRec.setFieldValue(FLD_DATA_FILE,fileID);
			  
			  if(intermIdsArr.length>0)
			  {
				 intermIdsArr = eliminateDuplicates(intermIdsArr);
			  creditCreationLogRec.setFieldValues('custrecord_appf_ven_cred_vb_header',intermIdsArr);
			  }
		  
			  if(vendor != null && vendor != '')
				  creditCreationLogRec.setFieldValue(FLD_CLIENT_OR_VENDOR,vendor);
			  if(currency != null && currency != '')
				  creditCreationLogRec.setFieldValue(FLD_CURRENCY,currency);
			  if(internalIdsArr != null && internalIdsArr != '')
				  creditCreationLogRec.setFieldValues(FLD_INV_VEND_BILL_LINK,internalIdsArr);
			  
			  var custRecID = nlapiSubmitRecord(creditCreationLogRec,true,true);
			  
			  var billsData = '';
			  for(var vbId in selectedBills){
					billsData += vbId + '::';
					var vbLineIds = selectedBills[vbId];
					for(var l=0; l<vbLineIds.length; l++){
						billsData += vbLineIds[l] + '|';
					}
					billsData = billsData+'\n';
			  }
			  //billsData = billsData.slice(0, -2);
			  var billsDataFile = nlapiCreateFile('SelectedBillsData.txt', 'PLAINTEXT', billsData);
			  billsDataFile.setFolder(folderID);
			  var billsDataFileID = nlapiSubmitFile(billsDataFile);
			  
			  if(custRecID != null && custRecID != '')
				{
				  var params = {};
				   params[SPARAM_CREDIT_CREATION_LOG_ID_1] = custRecID;
				   params[SAPARM_SELECTED_LINES_FILE_ID] = billsDataFileID;
				   nlapiScheduleScript(SCRIPT_UPDATE_VENDOR_CREDIT_CREATION_SC, null, params);
				   response.sendRedirect('RECORD',CUSTOM_RECORD_CREDIT_CREATION_LOG,custRecID);

				} 	


			  nlapiLogExecution('debug','csvData',csvData);
			  
			  
		  }catch (e) {
			   if ( e instanceof nlobjError )
				      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
				      else
				      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
		  
		  
	  }
}
	
}


function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}


function removeDuplicates(num){
	  var x,
	      len=num.length,
	      out=[],
	      obj={};
	 
	  for (x=0; x<len; x++) {
	    obj[num[x]]=0;
	  }
	  for (x in obj) {
	    out.push(x);
	  }
	  return out;
	}

//function calling
//var searchres_morethan1000 = getAllSearchResults(record_type, filters, columns);
//function definations
function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		 function searchUnion(target, array)
		{
			return target.concat(array); // TODO: use _.union
		}
