/*
* Script Name : Appf-Connex to NetSuite Contact REST
* Script Type : 
* Event Type  : 
* Description :This script when executed checks for any new messages in the queue related to Connext Contact and pushes the Contact from those messages into netsuite and creates or updates as Contact records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
* Company     :	Appficiency Inc.
*/
 var SPARAM_CONNEX_CONTACT='customscript_appf_connex_contact_2_ns_sc'
function getContactRESTlet(dataIn)
{
	nlapiLogExecution('debug', 'internalId',  'internalId');	
             
	              nlapiScheduleScript(SPARAM_CONNEX_CONTACT,null) 	 
	return 'RESTlet successfully connected.';
}
