/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */

/*
* Script Name : Appf-Print EBP Payment SL
* Script Type : Suitelet
* Description : This script will display Payment PDF of EBP details of transactions grouped by tranid for ACH and Wire
* Company     : Appf.
* Script Owner: Shravan
* Date        : 18/07/2022 
*/

const CUSTRECORD_FLD_PAYMENT_LINK = 'custrecord_appf_ebp_linked_payment';
const CUSTRECORD_FLD_EBP_TRANSACTION_LINK = 'custrecord_appf_ebp_linked_transaction';
const CUSTRECORD_FLD_EBP_LINK_RECORD = 'customrecord_appf_ebp_linked_trans';
const month_names = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];

define( [ 'N/ui/serverWidget', 'N/record', 'N/search', 'N/redirect', 'N/format', 'N/url', 'N/file', 'N/xml', 'N/format/i18n' ], function ( serverWidget, record, search, redirect, format, url, file, xml, formati ) {
     const onRequest = ( context ) => {
          try {
               const vbpId = context.request.parameters.vbpId;
               if ( vbpId ) {
                    let logoFIleId = null;
                    let logoUrl = null;
                    let subId = null;
                    let vbpDate = null;
                    let fullAddress = null;
                    let billingAddress = null;
                    let payee = null;
                    let payeeVal = '';
                    let payAmount = 0;
                    let tranId = '';
                    let mainPhone = '';
                    let invoiceObj = {};
                    let currencyId = '';
                    let currencyCode = '';
                    let currencySymbal = '';
                    let logoWidth = "200px"
                    let logoHeight = "100%"

                    var myFormat = formati.getCurrencyFormatter( { currency: "USD" } );

                    let venderBillPaymentRecordData = search.lookupFields( {
                         type: 'vendorpayment',
                         id: Number( vbpId ),
                         columns: [ 'subsidiary', 'trandate', 'entity', 'fxamount', 'tranid', 'currency' ]
                    } )

                    if ( venderBillPaymentRecordData ) {
                         subId = venderBillPaymentRecordData.subsidiary[ 0 ].value;
                         vbpDate = venderBillPaymentRecordData.trandate;
                         payee = venderBillPaymentRecordData.entity[ 0 ].text;
                         payAmount = venderBillPaymentRecordData.fxamount;

                         if ( payAmount < 0 )
                              payAmount = payAmount * ( -1 )

                         currencyId = venderBillPaymentRecordData.currency[ 0 ].value;
                         tranId = venderBillPaymentRecordData.tranid;
                    }

                    if ( subId == 7 ) {
                         logoHeight = "40%";
                         logoWidth = "40%";
                    }

                    if ( currencyId ) {
                         let currencyRecord = record.load( {
                              type: 'currency',
                              id: Number( currencyId ),
                              isDynamic: true,
                         } )
                         currencyCode = currencyRecord.getValue( { fieldId: 'symbol' } );
                         currencySymbal = currencyRecord.getValue( { fieldId: 'displaysymbol' } );

                    }


                    if ( subId ) {
                         let subsidiaryRecordData = record.load( {
                              type: 'subsidiary',
                              id: Number( subId ),
                              isDynamic: true,
                         } )
                         logoFIleId = subsidiaryRecordData.getValue( { fieldId: 'custrecord_appf_vvccp_logo' } )
                         if ( !logoFIleId )
                              logoFIleId = subsidiaryRecordData.getValue( { fieldId: 'logo' } )
                         fullAddress = subsidiaryRecordData.getValue( { fieldId: 'mainaddress_text' } )
                         let addressSubRecord = subsidiaryRecordData.getSubrecord( { fieldId: 'mainaddress' } );
                         if ( addressSubRecord )
                              mainPhone = addressSubRecord.getValue( { fieldId: 'addrphone' } );
                    }
                    if ( logoFIleId ) {
                         let lookUpLogoData = search.lookupFields( {
                              type: 'file',
                              id: Number( logoFIleId ),
                              columns: [ 'url' ]
                         } )
                         logoUrl = lookUpLogoData.url;
                    }
                    logoUrl = 'https://system.netsuite.com' + logoUrl
                    if ( logoUrl )
                         logoUrl = xml.escape( { xmlText: logoUrl } )
                    if ( vbpDate ) {
                         let dateObj = format.parse( {
                              value: vbpDate,
                              type: format.Type.DATE
                         } )
                         var day = dateObj.getDate();
                         var month = dateObj.getMonth();
                         var year = dateObj.getFullYear();
                         if ( day < 10 ) {
                              day = '0' + day;
                         }
                         vbpDate = month_names[ month ] + ' ' + day + ', ' + year + ' ';

                         vbpDate = xml.escape( { xmlText: vbpDate } )
                    }
                    if ( fullAddress ) {
                         fullAddress = fullAddress.split( '\n' );
                         billingAddress = '<table>'
                         for ( let i = 0; i < fullAddress.length; i++ ) {
                              if ( fullAddress[ i ] )
                                   billingAddress += '<tr><td><b>' + xml.escape( { xmlText: fullAddress[ i ] } ) + '</b></td></tr>'
                         }
                         billingAddress += '</table>'
                    }

                    if ( payee ) {


                         if ( payee.slice( 0, 3 ) == 've_' )
                              payee = payee.slice( payee.indexOf( ' ' ) + 1 );
                    }

                    let ebpFils = [];
                    ebpFils.push( search.createFilter( {
                         name: 'isinactive',
                         operator: search.Operator.IS,
                         values: false,
                    } ) );

                    ebpFils.push( search.createFilter( {
                         name: CUSTRECORD_FLD_PAYMENT_LINK,
                         operator: search.Operator.ANYOF,
                         values: Number( vbpId ),
                    } ) );

                    let ebpCols = [];
                    ebpCols.push( search.createColumn( {
                         name: CUSTRECORD_FLD_EBP_TRANSACTION_LINK,
                    } ) )

                    let trnasactionIds = [];

                    let ebpLinkRes = getSearchResults( CUSTRECORD_FLD_EBP_LINK_RECORD, ebpFils, ebpCols )
                    if ( ebpLinkRes ) {
                         for ( let i = 0; i < ebpLinkRes.length; i++ ) {
                              let transactionId = ebpLinkRes[ i ].getValue( { name: CUSTRECORD_FLD_EBP_TRANSACTION_LINK } );
                              if ( trnasactionIds.indexOf( transactionId ) == -1 )
                                   trnasactionIds.push( transactionId );
                         }
                    }

                    if ( trnasactionIds.length > 0 ) {
                         let venderBillFils = [];
                         venderBillFils.push( search.createFilter( {
                              name: 'type',
                              operator: search.Operator.ANYOF,
                              values: [ "VendBill", "VendCred" ]
                         } ) )
                         venderBillFils.push( search.createFilter( {
                              name: 'mainline',
                              operator: search.Operator.IS,
                              values: false
                         } ) )

                         venderBillFils.push( search.createFilter( {
                              name: 'taxline',
                              operator: search.Operator.IS,
                              values: false
                         } ) )

                         venderBillFils.push( search.createFilter( {
                              name: 'cogs',
                              operator: search.Operator.IS,
                              values: false
                         } ) )

                         venderBillFils.push( search.createFilter( {
                              name: 'internalid',
                              operator: search.Operator.ANYOF,
                              values: trnasactionIds
                         } ) )



                         let venderBillCols = [];
                         venderBillCols.push( search.createColumn( {
                              name: "tranid",
                         } ) )
                         //27-07-2022   added by shravan kumar custcol_appf_print_servicedate change to custcolappf_so_line_startdate
                         venderBillCols.push( search.createColumn( {
                              name: "custcolappf_so_line_startdate",
                         } ) )

                         venderBillCols.push( search.createColumn( {
                              name: "custrecord_appf_contract_client",
                              join: "CUSTBODY_APPF_CLIENT_CONTRACT",
                         } ) )
                         venderBillCols.push( search.createColumn( {
                              name: "item",
                         } ) )
                         venderBillCols.push( search.createColumn( {
                              name: "fxamount",
                         } ) )
                         //added by shravan 02-08-2022
                         venderBillCols.push( search.createColumn( {
                              name: "fxamount",
                              function: 'absoluteValue'
                         } ) )
                         venderBillCols.push( search.createColumn( {
                              name: "type",
                         } ) )


                         venderBillCols.push( search.createColumn( {
                              name: "custbody_appf_orderreference",
                         } ) )
                         venderBillCols.push( search.createColumn( {
                              name: "custcol_appf_publisher",
                         } ) )



                         let venderBillRes = getSearchResults( 'transaction', venderBillFils, venderBillCols );
                         if ( venderBillRes ) {
                              for ( let i = 0; i < venderBillRes.length; i++ ) {
                                   let tranId = venderBillRes[ i ].getValue( { name: "tranid" } );
                                   let serviceDate = venderBillRes[ i ].getValue( { name: "custcolappf_so_line_startdate" } );
                                   let contactName = venderBillRes[ i ].getText( { name: "custrecord_appf_contract_client", join: "CUSTBODY_APPF_CLIENT_CONTRACT" } );
                                   if ( contactName.slice( 0, 3 ) == 'cu_' )
                                        contactName = contactName.slice( contactName.indexOf( ' ' ) + 1 );
                                   let type = venderBillRes[ i ].getValue( { name: "type" } );
                                   let item = venderBillRes[ i ].getText( { name: "item" } );
                                   //added by shravan
                                   let vbamount = venderBillRes[ i ].getValue( { name: "fxamount", function: 'absoluteValue' } );
                                   let vcamount = venderBillRes[ i ].getValue( { name: "fxamount" } );

                                   let orderRef = venderBillRes[ i ].getValue( { name: "custbody_appf_orderreference" } );
                                   let mediaPublisher = venderBillRes[ i ].getText( { name: "custcol_appf_publisher" } );

                                   if ( tranId.indexOf( '-' ) != -1 ) {
                                        tranId = tranId.slice( 0, tranId.lastIndexOf( '-' ) );
                                        tranId = tranId.replace( /\s+$/gm, '' );
                                   }

                                   let amount;
                                   if ( type == "VendBill" ) {
                                        amount = vbamount;
                                   }
                                   else {
                                        amount = vcamount;

                                        //added by shravan kumar 16-08-2022
                                        if ( amount > 0 )
                                             amount = amount * ( -1 )

                                   }

                                   if ( item.includes( "GST/HST" ) || item.includes( "PST/QST" ) || item.includes( "PST" ) ) {
                                        orderRef = item;

                                   }
                                   else
                                        orderRef = orderRef;

                                   //added by shravan kumar 16-08-2022
                                   let sortNumber = 1;
                                   if ( item.includes( "PST" ) ) {
                                        sortNumber = 3
                                   }
                                   else if ( item.includes( "GST/HST" ) ) {
                                        sortNumber = 2
                                   }
                                   else {
                                        sortNumber = 1
                                   }

                                   if ( !invoiceObj.hasOwnProperty( tranId ) ) {
                                        invoiceObj[ tranId ] = {};
                                        invoiceObj[ tranId ].lines = [];
                                        invoiceObj[ tranId ].amount = parseFloat( amount );
                                        let objData = {};
                                        objData.orderRef = orderRef;
                                        objData.serviceDate = serviceDate;
                                        objData.contactName = contactName;
                                        objData.amount = amount;
                                        objData.mediaPublisher = mediaPublisher;
                                        //added by shravan kumar 16-08-2022
                                        objData.sortNumber = sortNumber;
                                        invoiceObj[ tranId ].lines.push( objData );
                                   }
                                   else {
                                        let extObj = invoiceObj[ tranId ].lines;
                                        let extamount = invoiceObj[ tranId ].amount;
                                        extamount = parseFloat( extamount ) + parseFloat( amount )
                                        let objData = {};
                                        objData.orderRef = orderRef;
                                        objData.serviceDate = serviceDate;
                                        objData.contactName = contactName;
                                        objData.amount = amount;
                                        objData.mediaPublisher = mediaPublisher;
                                        //added by shravan kumar 16-08-2022
                                        objData.sortNumber = sortNumber;
                                        extObj.push( objData );
                                        invoiceObj[ tranId ].amount = ( extamount )
                                   }

                              }
                         }

                    }

                    let invTabalesData = '';

                    for ( let prop in invoiceObj ) {
                         let totalAmount = '';
                         let lineData = [];

                         if ( invoiceObj[ prop ].amount )
                              totalAmount = invoiceObj[ prop ].amount;
                         if ( totalAmount ) {
                              //  totalAmount = myFormat.format( { number: parseFloat( totalAmount ) } );
                              if ( totalAmount < 0 ) {
                                   totalAmount = totalAmount * ( -1 )
                                   totalAmount = myFormat.format( { number: parseFloat( totalAmount ) } );
                                   totalAmount = '(' + totalAmount + ')'
                              }
                              else {
                                   totalAmount = myFormat.format( { number: parseFloat( totalAmount ) } );
                              }
                         }

                         let table2Data = '<table width="100%" style="border: 0.25px solid black; border-collapse: collapse; margin-bottom: 25px;">'
                         table2Data += '<tr style="background-color: #e3e3e3;">'
                         table2Data += '<td colspan="4" width="70%" style="border: 0.25px solid black; border-collapse: collapse;border-right-width:0px"><span style="padding-left:0px"><b>Invoice:   ' + prop + '</b></span></td><td width="30%" style="border: 0.25px solid black; border-collapse: collapse;border-left-width:0px"><b>Total:   ' + totalAmount + '</b></td>'
                         table2Data += '</tr>'
                         table2Data += '<tr>'
                         table2Data += '<td width="20%" align="center" style="border: 0.25px solid black; border-collapse: collapse;"><p style="text-align:center"><b>Order Reference</b></p></td>'
                         table2Data += '<td width="20%" align="center" style="border: 0.25px solid black; border-collapse: collapse;"><p style="text-align:center"><b>Service Date</b></p></td>'
                         table2Data += '<td width="20%" align="center" style="border: 0.25px solid black; border-collapse: collapse;"><p style="text-align:center"><b>Amount</b></p></td>'
                         table2Data += '<td width="20%" align="center" style="border: 0.25px solid black; border-collapse: collapse;"><p style="text-align:center"><b>Client Name</b></p></td>'
                         table2Data += '<td width="20%" align="center" style="border: 0.25px solid black; border-collapse: collapse;"><p style="text-align:center"><b>Media Supplier Name</b></p></td>'
                         table2Data += '</tr>';
                         if ( invoiceObj[ prop ].lines ) {
                              lineData = invoiceObj[ prop ].lines
                         }
                         lineData = lineData.sort( ( a, b ) => ( a.sortNumber > b.sortNumber ? 1 : -1 ) )
                         for ( let i = 0; i < lineData.length; i++ ) {
                              let orRef = '';
                              let srDate = '';
                              let amt = '';
                              let cName = '';
                              let msName = '';
                              if ( lineData[ i ].orderRef ) {
                                   orRef = lineData[ i ].orderRef;
                                   orRef = xml.escape( { xmlText: orRef } )
                              }
                              if ( lineData[ i ].serviceDate )
                                   srDate = lineData[ i ].serviceDate;
                              if ( lineData[ i ].amount )
                                   amt = lineData[ i ].amount;
                              if ( lineData[ i ].contactName ) {
                                   cName = lineData[ i ].contactName;
                                   cName = xml.escape( { xmlText: cName } )
                              }
                              if ( lineData[ i ].mediaPublisher ) {
                                   msName = lineData[ i ].mediaPublisher;
                                   msName = xml.escape( { xmlText: msName } )
                              }
                              if ( amt ) {
                                   if ( amt < 0 ) {
                                        amt = amt * ( -1 )
                                        amt = myFormat.format( { number: parseFloat( amt ) } );
                                        amt = '(' + amt + ')'
                                   }
                                   else
                                        amt = myFormat.format( { number: parseFloat( amt ) } );
                              }
                              table2Data += '<tr>'
                              table2Data += '<td width="20%" style="border: 0.25px solid black; border-collapse: collapse;padding:5px;">' + orRef + '</td>'
                              table2Data += '<td width="20%" style="border: 0.25px solid black; border-collapse: collapse;padding:5px;">' + srDate + '</td>'
                              table2Data += '<td width="20%" style="border: 0.25px solid black; border-collapse: collapse;padding:5px;">' + amt + '</td>'
                              table2Data += '<td width="20%" style="border: 0.25px solid black; border-collapse: collapse;padding:5px;">' + cName + '</td>'
                              table2Data += '<td width="20%" style="border: 0.25px solid black; border-collapse: collapse;padding:5px;">' + msName + '</td>'
                              table2Data += '</tr>';
                         }
                         table2Data += '</table>'
                         invTabalesData = invTabalesData + table2Data;
                    }

                    if ( payAmount )
                         payAmount = myFormat.format( { number: parseFloat( payAmount ) } );

                    if ( payee )
                         payee = xml.escape( { xmlText: payee } )


                    let table1Data = '<table  style="padding-bottom: 25px;">'
                    table1Data += '<tr><td align="left" valign="top"  style="padding-bottom: 25px;"  colspan="2"><img src="' + logoUrl + '" width="' + logoWidth + '" height="' + logoHeight + '"/></td></tr>'
                    table1Data += '<tr><td  align="left" valign="top"  colspan="2"><b>' + vbpDate + '</b></td></tr>'
                    table1Data += '<tr>'
                    table1Data += '<td width="30%">Billing Address:</td>'
                    table1Data += '<td  style="margin-left:-70px;">' + billingAddress + '</td>'
                    table1Data += '</tr>'
                    table1Data += '<tr>'
                    table1Data += '<td width="30%">Main Phone:</td>'
                    //  table1Data += '<td style="margin-left:-70px;"><b>' + mainPhone + '</b></td>'
                    table1Data += '<td style="margin-left:-70px;"><b> (612) 758 – 8600</b></td>'
                    table1Data += '</tr>'
                    table1Data += '<tr>'
                    table1Data += '<td width="30%">Payee:</td>'
                    table1Data += '<td style="margin-left:-70px;"><b>' + payee + '</b></td>'
                    table1Data += '</tr>'
                    table1Data += '<tr>'
                    table1Data += '<td width="30%">Payment Amount:</td>'
                    table1Data += '<td style="margin-left:-70px;"><b>' + "" + payAmount + " " + currencyCode + '</b></td>'
                    table1Data += '</tr>'
                    table1Data += '<tr>'
                    table1Data += '<td colspan="2"><b>The following buys are included on Wire/ACH payment reference number : ' + tranId + '</b></td>'
                    table1Data += '</tr>'
                    table1Data += '</table>'

                    let pdfData = "<?xml version=\"1.0\"?>\n" +
                         "<!DOCTYPE pdf PUBLIC \"-//big.faceless.org//report\" \"report-1.1.dtd\">\n";
                    pdfData += '<pdf>\n'
                    pdfData += '<head>'
                    pdfData += '<style type="text/css">'
                    pdfData += '* {'
                    pdfData += 'font-family: Calibri, Helvetica, sans-serif;'
                    pdfData += 'font-size: 12px;'
                    pdfData += '}'
                    pdfData += '</style>'
                    pdfData += '</head>\n'
                    pdfData += '<body padding="0.5in 0.5in 0.5in 0.5in" size="Letter" style="border:1px solid; margin:30px; padding:15px;">'
                    pdfData += table1Data
                    pdfData += invTabalesData
                    pdfData += "</body>/n"
                    pdfData += "</pdf>"

                    context.response.renderPdf( pdfData );
               }
          }
          catch ( e ) {
               log.debug( 'failed', e.message );
          }
     };

     const getSearchResults = ( rectype, fils, cols ) => {
          let mySearch = search.create( {
               type: rectype,
               columns: cols,
               filters: fils
          } );
          let resultsList = [];
          let myPagedData = mySearch.runPaged( {
               pageSize: 1000
          } );
          myPagedData.pageRanges.forEach( ( pageRange ) => {
               let myPage = myPagedData.fetch( {
                    index: pageRange.index
               } );
               myPage.data.forEach( ( result ) => {
                    resultsList.push( result );
               } );
          } );
          return resultsList;
     };

     return {
          onRequest: onRequest
     };
} );