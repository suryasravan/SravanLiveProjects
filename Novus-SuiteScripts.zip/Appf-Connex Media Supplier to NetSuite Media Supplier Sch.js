/**
*Script Name: Appf-Connex Media Supplier to NetSuite M
*Script Type: Schedule Script
*Description:  This script when executed checks for any new messages in the queue related to Connex mediasupplier and pushes the mediasupplier from those messages into netsuite and creates or updates as mediasupplier records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
var FLD_COL_TTB_UPDATED_PROJECT='custcol_appf_ttb_update_project';
 var CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS='customrecord_appf_connex_media_suppli_in';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_MESSAGE ='custrecord_appf_media_supplier_messageid';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_CONTENT_LINK='custrecord_appf_media_supp_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_QUEU_NAME ='custrecord_appf_media_supplier_queuename';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_AZURE_RESPONSE='custrecord_appf_media_supplier_response';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP='custrecord_media_supplier_id';
 var CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_RESPONSE_STATUS='custrecord_response_media_supp_status';
var CUSTOMRECORD_MEDIA_SUPP_RECS='customrecord_appf_media_supplier';
 var CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP = 'custrecord_appf_netsuite_medi_send_resp';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_connex_media_resp_status';
 
 // Integration Related
 var QUEUE_CONNEX_MEDIA_SUPP_INBOUND = 'novusmedia_connex_medsupplier_in';
//novusmedia_connex_medsupplier_in
 var QUEUE_CONNEX_MEDIA_SUPP_INBOUND_RESPONSE = 'netsuite_crm_response';
  var FLD_CONNEX_ID='custrecord_appf_ms_connexid';
     var FLD_LAST_UPDATE_DATE_TIME = 'custrecord_appf_integr_lastupdatedatems';


 var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';
 // var NS_OB_RESPONSE_PROPERTY='Novus.Connex.Sync.NetSuite.Models.Response.MediaSupplierResponse'
 var NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Response.NetSuite.MediaSupplierResponseMessage'
 var SPARAM_CONNEX_MEDIA_SUPPL='customscript_appf_connex_medsupp_2_ns_sc'
 var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
function createMediaSuppScheduled(type) 
  {	
		    var context = nlapiGetContext();
    var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
    if(URL_BASE!=null && URL_BASE!='')
      {
                  var messagesFound=true
                 while (messagesFound == true) {
                 var idForResponse = '';
	var usageRemaining = context.getRemainingUsage();
	var connexIDResponseValue=''
				   var d = new Date();
                 var UTCDate= d.toISOString();
var url = URL_BASE+QUEUE_CONNEX_MEDIA_SUPP_INBOUND+'/messages/head?api-version=2015-01';
var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
var mainObj = responseData.getBody();
   nlapiLogExecution('debug','mainObj content',mainObj);
var CorrelationIdProp='NServiceBus.CorrelationId'
var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

  var CorrelationId=responseData.getHeader(CorrelationIdProp)  
  var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
 var responseDataAllHeaders=responseData.getAllHeaders()
  var responseData3=responseDataAllHeaders[3]
  var responseDataProp=responseData.getHeader(responseData3) 
                    var Status=''
				   var Status1=''
				   var scriptStatus=''
                   var fileData=''
var main1={}
                  if(mainObj==null || mainObj=='')
                     {
                        messagesFound=false;
                     Status='FAILED'+'(Empty Message)'
					 scriptStatus='FAILED'
					 Status1='FAILED'+'(Empty Message)'
                     }
                   else
                     {
                       try {
								mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
					{
						connexIDResponseValue=mainObj[FLD_CONNEX_ID];
						nlapiLogExecution('debug', 'connexIDResponseValue:', connexIDResponseValue);
					}
					Status='SUCCESS'
                           } 
						catch (e) 
						{
						   Status='FAILED'+'(invalid JSON)'
						   scriptStatus='FAILED'
							Status1='FAILED'+'(invalid JSON)'
						}
                     }
                 
                   if(responseData.getCode()!='200' && responseData.getCode()!='201')
				   {
                     messagesFound=false
					   if (responseData.getCode()!='204')
					   {
						    var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS)
							integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_RESPONSE_STATUS,'FAILED')
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_MESSAGE,responseDataProp)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_CONTENT_LINK,fileData)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_QUEU_NAME,QUEUE_CONNEX_MEDIA_SUPP_INBOUND)
					    var integrationRecordID=nlapiSubmitRecord(integrationRecord,true,true)
					   }
				   }
			 
                  else
                     {			 
			  var nsMediaSuppRecord='';
			  var nsCreationMsg = '';
			   var isUpdateRecord = true; 
			   try
			   {
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsMediaSuppRecord=nlapiCreateRecord(CUSTOMRECORD_MEDIA_SUPP_RECS)
                if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					 var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord(CUSTOMRECORD_MEDIA_SUPP_RECS, null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
                        if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
                     nsMediaSuppRecord=nlapiLoadRecord(CUSTOMRECORD_MEDIA_SUPP_RECS,internalId)
					 var msdate=''
var nsdate=nsMediaSuppRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }	
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
                                  }
                        }

					}
                 }
			}
			else{
                 var internalId=mainObj['id']
                  if(internalId==null || internalId=='')
                    {
                  nsMediaSuppRecord=nlapiCreateRecord(CUSTOMRECORD_MEDIA_SUPP_RECS)
                        if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					 var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord(CUSTOMRECORD_MEDIA_SUPP_RECS, null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
                        if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                   idForResponse=internalId
                     nsMediaSuppRecord=nlapiLoadRecord(CUSTOMRECORD_MEDIA_SUPP_RECS,internalId)
					 var msdate=''
var nsdate=nsMediaSuppRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }	
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
                                  }
                        }

					}
                 }
                    }

                     else
                   { 
idForResponse=internalId
                     nsMediaSuppRecord=nlapiLoadRecord(CUSTOMRECORD_MEDIA_SUPP_RECS,internalId)
					 var msdate=''
				 	var nsdate=nsMediaSuppRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }				 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
						 else
						 {
							 isUpdateRecord=false
						 }
                   }  
                   }
			}
			   }
					 catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			 var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS)
							integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_RESPONSE_STATUS,'SUCCESS')
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_MESSAGE,responseDataProp)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_CONTENT_LINK,fileData)
						integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_QUEU_NAME,QUEUE_CONNEX_MEDIA_SUPP_INBOUND)
					var integrationRecordID= nlapiSubmitRecord(integrationRecord,true,true)
			
			var nsMediaSuppRecordID=null;
					   
					    if(Status==null || Status=='' || Status=='SUCCESS')
                       {
					     try{
							 if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {
			  for (var parentProp in mainObj)
    	             {
			            var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=nsMediaSuppRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!='') && parentProp!='id')
						 {
			                  nsMediaSuppRecord.setFieldValue(parentProp,mainObj[parentProp])	
						 }
		              }
		               nsMediaSuppRecordID=nlapiSubmitRecord(nsMediaSuppRecord,true,true)
						 }
						  else
					   {
						if(nsCreationMsg==null || nsCreationMsg=='')
						   nsCreationMsg='Last Update Date from JSON ('+msdate+') is earlier than the Last Update Date found in Netsuite('+nsdate+').'
					       scriptStatus='WARNING'
					   }
						 }
						  catch(e1)
					   {
						   scriptStatus='FAILED'
						   if (e1 instanceof nlobjError)
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
					   }
					   
					   
					    if (nsMediaSuppRecordID != null)
					   {
                         var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') 
						  isInActiveRecord=true
					}
					if(!isInActiveRecord)
						   nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP,CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_AZURE_RESPONSE], [nsMediaSuppRecordID, 'SUCCESS']);
					   }
					   
					   else
					   {
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CONNEX_MEDIA_SUPP_AZURE_RESPONSE], [scriptStatus+":"+nsCreationMsg]);
   
					   }
					   
			
			if(nsMediaSuppRecordID!=null && nsMediaSuppRecordID!='')
			{
              idForResponse=nsMediaSuppRecordID;
			
		scriptStatus='SUCCESS'
if (responseData.getCode() == '200' || responseData.getCode() == '201')
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					  else
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
				
				
			}
                     }
					 }
		   if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
				   {
				      	
						 if(connexIDResponseValue==null || connexIDResponseValue=='')
							   connexIDResponseValue=''
						    main1.EntityId=connexIDResponseValue
						
		                 if(idForResponse==null || idForResponse=='')
							 idForResponse=''
						  main1.NetSuiteId=idForResponse
						  if(Status1!=null && Status1!='')
							   main1.IntegrationResponseStatus=Status1
						   else
						 main1.IntegrationResponseStatus=scriptStatus
					 
						  if(nsCreationMsg==null || nsCreationMsg=='')
							 nsCreationMsg=''
						  main1.IntegrationResponseMessage=nsCreationMsg
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CONNEX_MEDIA_SUPP_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP], [JSON.stringify(main1)]);   
				   var url = URL_BASE+QUEUE_CONNEX_MEDIA_SUPP_INBOUND_RESPONSE+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":signatures};
 //HEADERS.scriptStatus=scriptStatus
                   if(CorrelationId==null || CorrelationId=='')
					   CorrelationId=''
                HEADERS['NServiceBus.CorrelationId']=CorrelationId
				HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

				   }
                   if(context.getRemainingUsage()<=1000)
	{
	nlapiScheduleScript(SPARAM_CONNEX_MEDIA_SUPPL,null)
      break;  
	}		 
	     
	}
      }
	}