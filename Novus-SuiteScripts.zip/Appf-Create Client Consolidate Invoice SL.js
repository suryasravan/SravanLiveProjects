/*
* Script Name : Appf-Create Client Consolidate Invoice SL
* Script Type : Suitelet
* Description : 
* Company     : Appficiency Inc.
*/

var FLD_GRP_CLIENT_DETAILS = 'custpage_client_details';
var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_CLIENT = 'custpage_client';
var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
var FLD_SL_LINE_OF_BUSIBNESS = 'custpage_line_of_business';
var FLD_SL_CURRENCY = 'custpage_currency';
var FLD_SL_CONTRACT = 'custpage_contract';
var FLD_SL_PUBLISHER_MEDIA_SIPPLIER = 'custpage_publisher_media_supplier';
var FLD_SL_VENDOR = 'custpage_vendor';
var FLD_SL_TRANSACTION_TYPE = 'custpage_transaction_tupe';
var FLD_SL_DATE_FROM = 'custpage_date_from';
var FLD_SL_DATE_TO = 'custpage_date_to';
var FLD_SL_SCHED_NAME_PROJ = 'custpage_sched_ame_proj';
var FLD_SL_BILL_MONTH = 'custpage_bill_month';
var FLD_SL_ADJUSTMENT_INVOICE = 'custpage_adjustment_invoice';

var FLD_SL_PLACEMENT_STR_1 = 'custpage_placement_str_1';
var FLD_SL_PLACEMENT_STR_2 = 'custpage_placement_str_2';
var FLD_SL_PLACEMENT_STR_3 = 'custpage_placement_str_3';
var FLD_SL_PLACEMENT_STR_4 = 'custpage_placement_str_4';
var FLD_SL_PLACEMENT_STR_5 = 'custpage_placement_str_5';
var FLD_SL_PLACEMENT_STR_6 = 'custpage_placement_str_6';
var FLD_SL_GRP_TRANSACTION_LINKS = 'custpage_ci_transaction_links';


var FLD_CONTRACT_CLIENT = 'custrecord_appf_contract_client';
var FLD_GRP_CONTRACT_DETAILS = 'custpage_contract_details_tab';
var FLD_SL_GRP_BATCH_OPTION_1 = 'custpage_batch_opt_1';
var FLD_SL_GRP_BATCH_OPTION_2 = 'custpage_batch_opt_2';
var FLD_SL_GRP_BATCH_OPTION_3 = 'custpage_batch_opt_3';
var FLD_SL_GRP_BATCH_OPTION_4 = 'custpage_batch_opt_4';
var FLD_SL_GRP_OVERRIDE = 'custpage_override';

var FLD_GRP_SUMMARY_DETAILS = 'custpage_summary_details';
var FLD_SL_GRP_INV_AVAIL_CONSOL = 'custpage_inv_avail_consol';
var FLD_SL_GRP_INV_LINES_AVAIL_CONSOL = 'custpage_inv_lines_avail_consol';
var FLD_SL_GRP_TOT_CI_TO_CREATE = 'custpage_total_ci_to_create';
var FLD_SL_GRP_TOT_CI_AMT = 'custpage_total_ci_amount';
var FLD_SL_GRP_TOT_CI_INVOICES = 'custpage_total_ci_invoices';

var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var CUSTOM_SEGMENT_MEDIA = 'line.cseg_appf_media_seg';
var CUSTOM_RECORD_MEDIA_SUPLIER = 'customrecord_appf_media_supplier';
var CUSTOM_RECORD_MEDIA_SEGMENT = 'customrecord_cseg_appf_media_seg';
var TRANSACTION_TYPE_INV = 'CustInvc';
var TRANSACTION_TYPE_CM = 'CustCred';
var CUSTOM_LIST_BATCH_OPTIONS = 'customlist_appf_batch_options';

var BTN_SL_APPLY_FILTERS = 'custpage_btn_apply_filters';
var BTN_SL_MARK_ALL = 'custpage_btn_mark_all';
var BTN_SL_UNMARK_ALL = 'custpage_btn_unmark_all';

var SUBLIST_SL_INV_DETAILS = 'custpage_sublist_inv_details';
var FLD_COL_SL_SELECT = 'custpage_sl_select';
var FLD_COL_SL_INTERNAL_ID = 'custpage_internal_id';
var FLD_COL_SL_CLIENT_ID = 'custpage_client_id';
var FLD_COL_SL_CONTRACT_ID = 'custpage_contract_id';
var FLD_COL_SL_CURRENCY_ID = 'custpage_currency_id';
var FLD_COL_SL_REC_TYPE = 'custpage_type_id';

var FLD_CONTRACT = 'custbody_appf_client_contract';
var FLD_PUBLISHER = 'custcol_appf_publisher';
var FLD_CI_BATCH_STATUS = 'custbody_appf_ci_batch_status';

var FLD_CI_BATCH_STATUS_NOT_STARTED = '1';
var FLD_CI_BATCH_STATUS_UNDER_PROCESSING = '2';
var FLD_CI_BATCH_STATUS_COMPLETED = '3';
var FLD_CI_BATCH_STATUS_FAILED = '4';

var FLD_COL_INVOICE_LINE_ID = 'custcol_appf_invoice_line_id';
var FLD_COL_VENDOR_NAME = 'custcol_appf_po_vendor_name';
var FLD_COL_BILL_MONTH = 'custcol_appf_bill_month';
var FLD_COL_PLACEMENT_STRING_1 = 'custcol_appf_placement1';
var FLD_COL_PLACEMENT_STRING_2 = 'custcol_appf_placement2';
var FLD_COL_PLACEMENT_STRING_3 = 'custcol_appf_placement3';
var FLD_COL_PLACEMENT_STRING_4 = 'custcol_appf_placement4';
var FLD_COL_PLACEMENT_STRING_5 = 'custcol_appf_placement5';
var FLD_COL_PLACEMENT_STRING_6 = 'custcol_appf_placement6';
var FLD_COL_CI_STATUS = 'custcol_appf_ci_status';
var FLD_COL_CI_LOG = 'custcol_appf_ci_log';
var CI_STATUS_UNDER_PROCESSING = '2';
var FLD_COL_ADJUSTMENT_INVOICE= 'custcol_appf_adjustment_invoice';

var SCRIPT_CREATE_CLIENT_CI_VALIDATIONS = 'customscript_appf_create_client_ci_valid';
var SCRIPT_CREATE_CLIENT_CI_SC = 'customscript_appf_create_client_ci_sc';
//var DEPLOY_CREATE_CLIENT_CI_SC = '';
var SPARAM_CI_EXEC_LOG_ID = 'custscript_appf_ci_execution_log_id';
var SPARAM_CI_EXEC_FOLDER_ID = 'custscript_appf_ci_exec_fold_id';

var SPARAM_APPF_INV_LINES_FOR_CONSOL_SS = 'custscript_appf_inv_lines_for_consol_ss';

var SPARAM_FOLDER_CLIENT_CONSOLIDATED_INVOICES = 'custscript_appf_client_ci_folder_id';
var SPARAM_SEARCH_COLS_LENGTH = 'custscript_appf_search_columns_length';

var CUSTOM_RECORD_CI_EXECUTION_LOG = 'customrecord_appf_ci_execution_log';
var FLD_CI_EXEC_LOG_FILE = 'custrecord_appf_ci_file_to_process';
var FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_ci_total_lines_process';
var FLD_CI_EXEC_LOG_REMAIN_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_ci_remain_lines_process';
var FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_PROCESSED = 'custrecord_appf_ci_lines_processed';
var FLD_CI_EXEC_LOG_PERCENT_PROCESSED = 'custrecord_appf_ci_percent_processed';
var FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE = 'custrecord_appf_ci_total_ci_to_create';
var FLD_CI_EXEC_LOG_POST_EXEC_CONSOL_FILE = 'custrecord_appf_ci_post_exec_file';
var FLD_CI_EXEC_LOG_PROCESSING_CONSOL_STATUS_FILE = 'custrecord_appf_ci_process_status_file';
var FLD_CI_EXEC_LOG_ERROR_LOG = 'custrecord_appf_ci_error_log';
var FLD_CI_EXEC_LOG_ERROR_FILE = 'custrecord_appf_ci_error_file';
var FLD_CI_EXEC_LOG_CREATED_BY = 'custrecord_appf_ci_log_created_by';
var FLD_CI_EXEC_LOG_TOT_CI_CREATED = 'custrecord_appf_ci_total_ci_created';
var FLD_CI_EXEC_LOG_BATCH_OPTION_1 = 'custrecord_appf_ci_exec_batch_opt_1';
var FLD_CI_EXEC_LOG_BATCH_OPTION_2 = 'custrecord_appf_ci_exec_batch_opt_2';
var FLD_CI_EXEC_LOG_BATCH_OPTION_3 = 'custrecord_appf_ci_exec_batch_opt_3';
var FLD_CI_EXEC_LOG_BATCH_OPTION_4 = 'custrecord_appf_ci_exec_batch_opt_4';
var FLD_CI_EXEC_LOG_CI_BATCH_STATUS = 'custrecord_appf_ci_exec_batch_status';
var FLD_CI_EXEC_LOG_TRANSACTION_LINKS = 'custrecord_appf_ci_transaction_links';
var FLD_CI_EXEC_LOG_LINES_TO_PROCESS = 'custrecord_appf_ci_lines_toprocess';

var SEARCH_CI_LOGS_IN_PROGRESS = 'customsearch_appf_ci_logs_inprog';

function createClientCISuitelet(request, response) {
    var context = nlapiGetContext();
    var invLinesConsolSS = context.getSetting('SCRIPT', SPARAM_APPF_INV_LINES_FOR_CONSOL_SS);
    var invLinesConsolSSObj = nlapiLoadSearch(null, invLinesConsolSS);
    var srchFilters = invLinesConsolSSObj.getFilters();
    var srchColumns = invLinesConsolSSObj.getColumns();
    var srchType = invLinesConsolSSObj.getSearchType();
    if (request.getMethod() == 'GET') {
        try {
            var clientFlt = request.getParameter('clientFlt');
            var subsiFlt = request.getParameter('subsiFlt');
            var medSegFlt = request.getParameter('medSegFlt');
            var lobFlt = request.getParameter('lobFlt');
            var currFlt = request.getParameter('currFlt');
            var contractFlt = request.getParameter('contractFlt');
            var pubMedSupFlt = request.getParameter('pubMedSupFlt');
            var vendFlt = request.getParameter('vendFlt');
            var transTypeFlt = request.getParameter('transTypeFlt');
            var dtFrmFlt = request.getParameter('dtFrmFlt');
            var dtToFlt = request.getParameter('dtToFlt');
            var schedProjFlt = request.getParameter('schedProjFlt');
            var billMnthFlt = request.getParameter('billMnthFlt');
            var adjustInvFlt = request.getParameter('adjustInvFlt');
            var plcmntStr1Flt = request.getParameter('plcmntStr1Flt');
            var plcmntStr2Flt = request.getParameter('plcmntStr2Flt');
            var plcmntStr3Flt = request.getParameter('plcmntStr3Flt');
            var plcmntStr4Flt = request.getParameter('plcmntStr4Flt');
            var plcmntStr5Flt = request.getParameter('plcmntStr5Flt');
            var plcmntStr6Flt = request.getParameter('plcmntStr6Flt');
            var applyFilters = request.getParameter('applyFilters');
            var batOpt1 = request.getParameter('batOpt1');
            var batOpt2 = request.getParameter('batOpt2');
            var batOpt3 = request.getParameter('batOpt3');
            var batOpt4 = request.getParameter('batOpt4');
            var isOverride = request.getParameter('isOverride');
            var form = nlapiCreateForm('Consolidate Client Invoices');
            form.setScript(SCRIPT_CREATE_CLIENT_CI_VALIDATIONS);
            var clientDetailsGrp = form.addFieldGroup(FLD_GRP_CLIENT_DETAILS, 'Client Details (Filters)');
            var client = form.addField(FLD_SL_CLIENT, 'select', 'Client', 'customer', FLD_GRP_CLIENT_DETAILS);
            client.setMandatory(true);
            client.setDefaultValue(clientFlt);
            var subsi = form.addField(FLD_SL_SUBSIDIARY, 'select', 'Subsidiary', 'subsidiary', FLD_GRP_CLIENT_DETAILS);
            subsi.setDefaultValue(subsiFlt);
            var mediaSegment = form.addField(FLD_SL_MEDIA_SEGMENT, 'select', 'Media Segment', CUSTOM_RECORD_MEDIA_SEGMENT, FLD_GRP_CLIENT_DETAILS);
            mediaSegment.setDefaultValue(medSegFlt);
            var lob = form.addField(FLD_SL_LINE_OF_BUSIBNESS, 'select', 'Line of Business', 'classification', FLD_GRP_CLIENT_DETAILS);
            lob.setDefaultValue(lobFlt);
            var curr = form.addField(FLD_SL_CURRENCY, 'select', 'Currency', 'currency', FLD_GRP_CLIENT_DETAILS);
            curr.setMandatory(true);
            curr.setDefaultValue(currFlt);
            var contract = form.addField(FLD_SL_CONTRACT, 'select', 'Contract', null, FLD_GRP_CLIENT_DETAILS);
            contract.addSelectOption('', '');
            if (clientFlt != null && clientFlt != '') {
                var contrFils = new nlobjSearchFilter(FLD_CONTRACT_CLIENT, null, 'anyof', clientFlt);
                var contrCols = new nlobjSearchColumn('name');
                var contrSearch = nlapiSearchRecord(CUSTOM_RECORD_CONTRACT, null, contrFils, contrCols);
                if (contrSearch != null) {
                    for (var cr = 0; cr < contrSearch.length; cr++) {
                        var isCRDefault = false;
                        if (contrSearch[cr].getId() == contractFlt)
                            isCRDefault = true;
                        contract.addSelectOption(contrSearch[cr].getId(), contrSearch[cr].getValue('name'), isCRDefault);
                    }
                }
            }
            contract.setMandatory(true);
            contract.setDefaultValue(contractFlt);
            var pubMediaSupp = form.addField(FLD_SL_PUBLISHER_MEDIA_SIPPLIER, 'select', 'Publisher/Media Supplier', CUSTOM_RECORD_MEDIA_SUPLIER, FLD_GRP_CLIENT_DETAILS);
            pubMediaSupp.setDefaultValue(pubMedSupFlt);
            var vend = form.addField(FLD_SL_VENDOR, 'select', 'Vendor', 'vendor', FLD_GRP_CLIENT_DETAILS);
            vend.setDefaultValue(vendFlt);
            var transactionType = form.addField(FLD_SL_TRANSACTION_TYPE, 'select', 'Transaction Type', null, FLD_GRP_CLIENT_DETAILS);
            var invSelect = false;
            var cmSelect = false;
            if (transTypeFlt == TRANSACTION_TYPE_INV)
                invSelect = true;
            if (transTypeFlt == TRANSACTION_TYPE_CM)
                cmSelect = true;
            transactionType.addSelectOption('', '');
            transactionType.addSelectOption(TRANSACTION_TYPE_INV, 'Client Invoice', invSelect);
            transactionType.addSelectOption(TRANSACTION_TYPE_CM, 'Credit Memo', cmSelect);
            var dtFrm = form.addField(FLD_SL_DATE_FROM, 'date', 'Date (From)', null, FLD_GRP_CLIENT_DETAILS);
            dtFrm.setDefaultValue(dtFrmFlt);
            var dtTo = form.addField(FLD_SL_DATE_TO, 'date', 'Date (To)', null, FLD_GRP_CLIENT_DETAILS);
            dtTo.setDefaultValue(dtToFlt);
            var schedNameProj = form.addField(FLD_SL_SCHED_NAME_PROJ, 'select', 'Schedule Name/Project', 'job', FLD_GRP_CLIENT_DETAILS);
            schedNameProj.setDefaultValue(schedProjFlt);
            var billMonth = form.addField(FLD_SL_BILL_MONTH, 'text', 'Bill Month', null, FLD_GRP_CLIENT_DETAILS);
            billMonth.setDefaultValue(billMnthFlt);
            var adjustmentInv = form.addField(FLD_SL_ADJUSTMENT_INVOICE, 'select', 'Adjustment Invoice', null, FLD_GRP_CLIENT_DETAILS);
            adjustmentInv.addSelectOption('', '');
            adjustmentInv.addSelectOption('T', 'Yes');
            adjustmentInv.addSelectOption('F', 'No');
            adjustmentInv.setDefaultValue(adjustInvFlt);
            var placementStr1 = form.addField(FLD_SL_PLACEMENT_STR_1, 'text', 'Placement String 1', null, FLD_GRP_CLIENT_DETAILS);
            placementStr1.setDefaultValue(plcmntStr1Flt);
            var placementStr2 = form.addField(FLD_SL_PLACEMENT_STR_2, 'text', 'Placement String 2', null, FLD_GRP_CLIENT_DETAILS);
            placementStr2.setDefaultValue(plcmntStr2Flt);
            var placementStr3 = form.addField(FLD_SL_PLACEMENT_STR_3, 'text', 'Placement String 3', null, FLD_GRP_CLIENT_DETAILS);
            placementStr3.setDefaultValue(plcmntStr3Flt);
            var placementStr4 = form.addField(FLD_SL_PLACEMENT_STR_4, 'text', 'Placement String 4', null, FLD_GRP_CLIENT_DETAILS);
            placementStr4.setDefaultValue(plcmntStr4Flt);
            var placementStr5 = form.addField(FLD_SL_PLACEMENT_STR_5, 'text', 'Placement String 5', null, FLD_GRP_CLIENT_DETAILS);
            placementStr5.setDefaultValue(plcmntStr5Flt);
            var placementStr6 = form.addField(FLD_SL_PLACEMENT_STR_6, 'text', 'Placement String 6', null, FLD_GRP_CLIENT_DETAILS);
            placementStr6.setDefaultValue(plcmntStr6Flt);
            var contractDetailsGrp = form.addFieldGroup(FLD_GRP_CONTRACT_DETAILS, 'Contract Details (Group By)');
            var batchOpt1 = form.addField(FLD_SL_GRP_BATCH_OPTION_1, 'select', 'Batch Option 1', CUSTOM_LIST_BATCH_OPTIONS, FLD_GRP_CONTRACT_DETAILS);
            batchOpt1.setDisplayType('disabled');
            batchOpt1.setDefaultValue(batOpt1);
            var batchOpt2 = form.addField(FLD_SL_GRP_BATCH_OPTION_2, 'select', 'Batch Option 2', CUSTOM_LIST_BATCH_OPTIONS, FLD_GRP_CONTRACT_DETAILS);
            batchOpt2.setDisplayType('disabled');
            batchOpt2.setDefaultValue(batOpt2);
            var batchOpt3 = form.addField(FLD_SL_GRP_BATCH_OPTION_3, 'select', 'Batch Option 3', CUSTOM_LIST_BATCH_OPTIONS, FLD_GRP_CONTRACT_DETAILS);
            batchOpt3.setDisplayType('disabled');
            batchOpt3.setDefaultValue(batOpt3);
            var batchOpt4 = form.addField(FLD_SL_GRP_BATCH_OPTION_4, 'select', 'Batch Option 4', CUSTOM_LIST_BATCH_OPTIONS, FLD_GRP_CONTRACT_DETAILS);
            batchOpt4.setDisplayType('disabled');
            batchOpt4.setDefaultValue(batOpt4);
            var override = form.addField(FLD_SL_GRP_OVERRIDE, 'checkbox', 'Override', null, FLD_GRP_CONTRACT_DETAILS);
            override.setDefaultValue(isOverride);
            if (isOverride == 'T') {
                batchOpt1.setDisplayType('normal');
                batchOpt2.setDisplayType('normal');
                batchOpt3.setDisplayType('normal');
                batchOpt4.setDisplayType('normal');
            }
            var summaryDetailsGrp = form.addFieldGroup(FLD_GRP_SUMMARY_DETAILS, 'Summary Details');
            var invAvailConsol = form.addField(FLD_SL_GRP_INV_AVAIL_CONSOL, 'integer', 'Invoices Available for Consolidation', null, FLD_GRP_SUMMARY_DETAILS);
            invAvailConsol.setDisplayType('disabled');
            var invLinesAvailConsol = form.addField(FLD_SL_GRP_INV_LINES_AVAIL_CONSOL, 'integer', 'Invoice Lines Available for Consolidation', null, FLD_GRP_SUMMARY_DETAILS);
            invLinesAvailConsol.setDisplayType('disabled');
            var toCItoCreate = form.addField(FLD_SL_GRP_TOT_CI_TO_CREATE, 'integer', 'Total CI to Create', null, FLD_GRP_SUMMARY_DETAILS);
            toCItoCreate.setDisplayType('disabled');
            var toCIAmount = form.addField(FLD_SL_GRP_TOT_CI_AMT, 'currency', 'Total CI Amount', null, FLD_GRP_SUMMARY_DETAILS);
            toCIAmount.setDisplayType('disabled');
            var toCIAmount = form.addField(FLD_SL_GRP_TOT_CI_INVOICES, 'integer', 'Total No of Invoices', null, FLD_GRP_SUMMARY_DETAILS);
            toCIAmount.setDisplayType('hidden');
            var tranLinks = form.addField(FLD_SL_GRP_TRANSACTION_LINKS, 'multiselect', 'Transaction Links', 'transaction', FLD_GRP_SUMMARY_DETAILS);
            tranLinks.setDisplayType('hidden');
            form.addButton(BTN_SL_APPLY_FILTERS, 'Apply Filters', 'applyFilters();');
            form.addSubmitButton('Submit');
            if (applyFilters == 'T') {
                var invDetailsSublist = form.addSubList(SUBLIST_SL_INV_DETAILS, 'list', 'Invoice Details (Results)');
                invDetailsSublist.addButton(BTN_SL_MARK_ALL, 'Mark All', 'markAll();');
                invDetailsSublist.addButton(BTN_SL_UNMARK_ALL, 'Unmark All', 'unmarkAll();');
                if (invLinesConsolSS != null && invLinesConsolSS != '') {
                    invDetailsSublist.addField(FLD_COL_SL_SELECT, 'checkbox', 'Select');
                    invDetailsSublist.addField(FLD_COL_SL_INTERNAL_ID, 'text', 'Internal ID').setDisplayType('hidden');
                    var formulaIndex = 1;
                    for (var c = 0; c < srchColumns.length; c++) {
                        var col = srchColumns[c];
                        var colName = col.getName();
                        var colLabel = col.getLabel();
                        if (colName.indexOf('formula') != -1) {
                            colName = colName + '_' + formulaIndex;
                            formulaIndex++;
                        }
                        var sublistLine = invDetailsSublist.addField('custpage_' + colName, 'text', colLabel);
                        if (col.getType() == 'select')
                            sublistLine = invDetailsSublist.addField('custpage_' + colName + '_id', 'text', colLabel + '_ID').setDisplayType('hidden');
                        if (colName == 'line')
                            sublistLine.setDisplayType('hidden');
                    }
                    if (batOpt1 != null && batOpt1 != '') {
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name, 'text', batchFieldsData(batOpt1).label);
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt1).name + '_id', 'text', batchFieldsData(batOpt1).label + '_ID').setDisplayType('hidden');
                    }
                    if (batOpt2 != null && batOpt2 != '') {
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name, 'text', batchFieldsData(batOpt2).label);
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt2).name + '_id', 'text', batchFieldsData(batOpt2).label + '_ID').setDisplayType('hidden');
                        nlapiLogExecution('debug', 'batch 2 column field name', 'custpage_' + batchFieldsData(batOpt2).name);
                        nlapiLogExecution('debug', 'batch 2 column field id', 'custpage_' + batchFieldsData(batOpt2).name + '_id');
                    }
                    if (batOpt3 != null && batOpt3 != '') {
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name, 'text', batchFieldsData(batOpt3).label);
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt3).name + '_id', 'text', batchFieldsData(batOpt3).label + '_ID').setDisplayType('hidden');
                    }
                    if (batOpt4 != null && batOpt4 != '') {
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name, 'text', batchFieldsData(batOpt4).label);
                        invDetailsSublist.addField('custpage_' + batchFieldsData(batOpt4).name + '_id', 'text', batchFieldsData(batOpt4).label + '_ID').setDisplayType('hidden');
                    }
                    var filters = [];
                    if (clientFlt != null && clientFlt != '')
                        filters.push(new nlobjSearchFilter('mainname', null, 'anyof', clientFlt));
                    if (subsiFlt != null && subsiFlt != '')
                        filters.push(new nlobjSearchFilter('subsidiary', null, 'anyof', subsiFlt));
                    if (medSegFlt != null && medSegFlt != '')
                        filters.push(new nlobjSearchFilter(CUSTOM_SEGMENT_MEDIA, null, 'anyof', medSegFlt));
                    if (lobFlt != null && lobFlt != '')
                        filters.push(new nlobjSearchFilter('class', null, 'anyof', lobFlt));
                    if (currFlt != null && currFlt != '')
                        filters.push(new nlobjSearchFilter('currency', null, 'anyof', currFlt));
                    if (contractFlt != null && contractFlt != '')
                        filters.push(new nlobjSearchFilter(FLD_CONTRACT, null, 'anyof', contractFlt));
                    if (pubMedSupFlt != null && pubMedSupFlt != '')
                        filters.push(new nlobjSearchFilter(FLD_PUBLISHER, null, 'anyof', pubMedSupFlt));
                    if (vendFlt != null && vendFlt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_VENDOR_NAME, null, 'anyof', vendFlt));
                    if (transTypeFlt != null && transTypeFlt != '')
                        filters.push(new nlobjSearchFilter('type', null, 'anyof', transTypeFlt));
                    if (dtFrmFlt != null && dtFrmFlt != '' && dtToFlt != null && dtToFlt != '')
                        filters.push(new nlobjSearchFilter('trandate', null, 'within', dtFrmFlt, dtToFlt));
                    if (dtFrmFlt != null && dtFrmFlt != '' && (dtToFlt == null || dtToFlt == ''))
                        filters.push(new nlobjSearchFilter('trandate', null, 'onorafter', dtFrmFlt));
                    if ((dtFrmFlt == null || dtFrmFlt == '') && dtToFlt != null && dtToFlt != '')
                        filters.push(new nlobjSearchFilter('trandate', null, 'onorbefore', dtToFlt));
                    if (schedProjFlt != null && schedProjFlt != '')
                        filters.push(new nlobjSearchFilter('internalid', 'job', 'anyof', schedProjFlt));
                    if (billMnthFlt != null && billMnthFlt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_BILL_MONTH, null, 'contains', billMnthFlt));
                    if (adjustInvFlt != null && adjustInvFlt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_ADJUSTMENT_INVOICE, null, 'is', adjustInvFlt));
                    if (plcmntStr1Flt != null && plcmntStr1Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_1, null, 'contains', plcmntStr1Flt));
                    if (plcmntStr2Flt != null && plcmntStr2Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_2, null, 'contains', plcmntStr2Flt));
                    if (plcmntStr3Flt != null && plcmntStr3Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_3, null, 'contains', plcmntStr3Flt));
                    if (plcmntStr4Flt != null && plcmntStr4Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_4, null, 'contains', plcmntStr4Flt));
                    if (plcmntStr5Flt != null && plcmntStr5Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_5, null, 'contains', plcmntStr5Flt));
                    if (plcmntStr6Flt != null && plcmntStr6Flt != '')
                        filters.push(new nlobjSearchFilter(FLD_COL_PLACEMENT_STRING_6, null, 'contains', plcmntStr6Flt));
                    filters = filters.concat(srchFilters);
                    var columns = [];
                    if (batOpt1 != null && batOpt1 != '')
                        columns.push(new nlobjSearchColumn(batchFieldsData(batOpt1).name));
                    if (batOpt2 != null && batOpt2 != '')
                        columns.push(new nlobjSearchColumn(batchFieldsData(batOpt2).name));
                    if (batOpt3 != null && batOpt3 != '')
                        columns.push(new nlobjSearchColumn(batchFieldsData(batOpt3).name));
                    if (batOpt4 != null && batOpt4 != '')
                        columns.push(new nlobjSearchColumn(batchFieldsData(batOpt4).name));
                    columns = columns.concat(srchColumns);
                    var invLinesConsolSSResults = getAllSearchResults(srchType, filters, columns);
                    nlapiLogExecution('debug', 'invLinesConsolSSResults', invLinesConsolSSResults);
                    var pendingLines = getAllPendingLines();
                    if (invLinesConsolSSResults != null && invLinesConsolSSResults != '') {
                        invLinesAvailConsol.setDefaultValue(invLinesConsolSSResults.length);
                        var totalInvoices = [];
                        var r = 0;
                        for (var rx = 0, rl = invLinesConsolSSResults.length; rx < rl; rx++) {
                            var result = invLinesConsolSSResults[rx];
                            var lineID = result.getValue(FLD_COL_INVOICE_LINE_ID);
                            nlapiLogExecution('DEBUG', 'createClientCISuitelet', 'lineID = ' + lineID);
                            if (pendingLines.indexOf(lineID) >= 0) {
                                nlapiLogExecution('DEBUG', 'lineID = ' + lineID, 'Skipping line...');
                                continue;
                            }
                            var recId = result.getId();
                            var recType = result.getRecordType();
                            if (totalInvoices.indexOf(recId) == -1) {
                                totalInvoices.push(recId);
                            }
                            invDetailsSublist.setLineItemValue(FLD_COL_SL_INTERNAL_ID, r + 1, recId);
                            var formulaIndex = 1;
                            for (var c = 0; c < srchColumns.length; c++) {
                                var col = srchColumns[c];
                                var colName = col.getName();
                                var colLabel = col.getLabel();
                                var colVal = result.getValue(col);
                                if (colName.indexOf('formula') != -1) {
                                    colName = colName + '_' + formulaIndex;
                                    formulaIndex++;
                                }
                                if (col.getType() == 'select') {
                                    invDetailsSublist.setLineItemValue('custpage_' + colName + '_id', r + 1, colVal);
                                    colVal = result.getText(col);
                                }
                                if (colName == 'tranid') {
                                    var url = nlapiResolveURL('RECORD', recType, recId);
                                    colVal = '<a href=' + url + ' target="_blank">' + colVal + '</a>';
                                }
                                invDetailsSublist.setLineItemValue('custpage_' + colName, r + 1, colVal);
                            }
                            if (batOpt1 != null && batOpt1 != '') {
                                if (batchFieldsData(batOpt1).issel)
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getText(batchFieldsData(batOpt1).name));
                                else
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name, r + 1, result.getValue(batchFieldsData(batOpt1).name));
                                invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt1).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt1).name));
                            }
                            if (batOpt2 != null && batOpt2 != '') {
                                if (batchFieldsData(batOpt2).issel)
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getText(batchFieldsData(batOpt2).name));
                                else
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name, r + 1, result.getValue(batchFieldsData(batOpt2).name));
                                invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt2).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt2).name));
                            }
                            if (batOpt3 != null && batOpt3 != '') {
                                if (batchFieldsData(batOpt3).issel)
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getText(batchFieldsData(batOpt3).name));
                                else
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name, r + 1, result.getValue(batchFieldsData(batOpt3).name));
                                invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt3).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt3).name));
                            }
                            if (batOpt4 != null && batOpt4 != '') {
                                if (batchFieldsData(batOpt4).issel)
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getText(batchFieldsData(batOpt4).name));
                                else
                                    invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name, r + 1, result.getValue(batchFieldsData(batOpt4).name));
                                invDetailsSublist.setLineItemValue('custpage_' + batchFieldsData(batOpt4).name + '_id', r + 1, result.getValue(batchFieldsData(batOpt4).name));
                            }
                            r++;
                        }
                        if (totalInvoices != null && totalInvoices != '')
                            invAvailConsol.setDefaultValue(totalInvoices.length);
                    }
                }
            }
            response.writePage(form);
        } catch (e) {
            if (e instanceof nlobjError)
                nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails());
            else
                nlapiLogExecution('DEBUG', 'unexpected error', e.toString());
        }
    } else {
        try {
            var batOpt1 = request.getParameter(FLD_SL_GRP_BATCH_OPTION_1);
            var batOpt2 = request.getParameter(FLD_SL_GRP_BATCH_OPTION_2);
            var batOpt3 = request.getParameter(FLD_SL_GRP_BATCH_OPTION_3);
            var batOpt4 = request.getParameter(FLD_SL_GRP_BATCH_OPTION_4);
            var totInvselected = request.getParameter(FLD_SL_GRP_TOT_CI_INVOICES);
            var totCItoCreate = request.getParameter(FLD_SL_GRP_TOT_CI_TO_CREATE);
            var transactionLinks = request.getParameterValues(FLD_SL_GRP_TRANSACTION_LINKS);
            nlapiLogExecution('debug', 'transactionLinks', transactionLinks);
            var lineCount = request.getLineItemCount(SUBLIST_SL_INV_DETAILS);
            if (lineCount > 0) {
                var selectedLinesData = '';
                selectedLinesData += 'Internal ID,';
                for (var s1 = 0; s1 < srchColumns.length; s1++) {
                    var col = srchColumns[s1];
                    selectedLinesData += col.getLabel() + ',';
                    if (col.getType() == 'select')
                        selectedLinesData += col.getLabel() + '_ID,';
                }
                if (batOpt1 != null && batOpt1 != '') {
                    selectedLinesData += batchFieldsData(batOpt1).label + ',';
                    selectedLinesData += batchFieldsData(batOpt1).label + '_ID,';
                }
                if (batOpt2 != null && batOpt2 != '') {
                    selectedLinesData += batchFieldsData(batOpt2).label + ',';
                    selectedLinesData += batchFieldsData(batOpt2).label + '_ID,';
                }
                if (batOpt3 != null && batOpt3 != '') {
                    selectedLinesData += batchFieldsData(batOpt3).label + ',';
                    selectedLinesData += batchFieldsData(batOpt3).label + '_ID,';
                }
                if (batOpt4 != null && batOpt4 != '') {
                    selectedLinesData += batchFieldsData(batOpt4).label + ',';
                    selectedLinesData += batchFieldsData(batOpt4).label + '_ID,';
                }
                selectedLinesData = selectedLinesData.slice(0, -1) + '\n';
                var ssColumns = 1;
                for (var s1 = 0; s1 < srchColumns.length; s1++) {
                    ssColumns++;
                    if (srchColumns[s1].getType() == 'select') {
                        ssColumns++;
                    }
                }
                var selectedRecords = [];
                var selectedRecordID = [];
                for (var c = 1; c <= lineCount; c++) {
                    var selected = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c);
                    if (selected == 'T') {
                        var client = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + FLD_CONTRACT, c);
                        var internalId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_INTERNAL_ID, c);
                        selectedLinesData += internalId + ',';
                        var formulaIndex = 1;
                        for (var s1 = 0; s1 < srchColumns.length; s1++) {
                            var col = srchColumns[s1];
                            var colName = col.getName();
                            if (colName.indexOf('formula') != -1) {
                                colName = colName + '_' + formulaIndex;
                                formulaIndex++;
                            }
                            var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                            if (colVal != null && colVal != '')
                                colVal = colVal.replace(',', '|');
                            selectedLinesData += colVal + ',';
                            if (col.getType() == 'select') {
                                var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                                selectedLinesData += colValId + ',';
                            }
                            if (colName == 'custcol_appf_invoice_line_id') {
                                selectedRecordID.push(colVal);
                            }
                        }
                        if (batOpt1 != null && batOpt1 != '') {
                            var colName = batchFieldsData(batOpt1).name;
                            var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                            if (colVal != null && colVal != '')
                                colVal = colVal.replace(',', '|');
                            var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                            selectedLinesData += colVal + ',';
                            selectedLinesData += colValId + ',';
                        }
                        if (batOpt2 != null && batOpt2 != '') {
                            var colName = batchFieldsData(batOpt2).name;
                            var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                            if (colVal != null && colVal != '')
                                colVal = colVal.replace(',', '|');
                            var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                            selectedLinesData += colVal + ',';
                            selectedLinesData += colValId + ',';
                        }
                        if (batOpt3 != null && batOpt3 != '') {
                            var colName = batchFieldsData(batOpt3).name;
                            var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                            if (colVal != null && colVal != '')
                                colVal = colVal.replace(',', '|');
                            var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                            selectedLinesData += colVal + ',';
                            selectedLinesData += colValId + ',';
                        }
                        if (batOpt4 != null && batOpt4 != '') {
                            var colName = batchFieldsData(batOpt4).name;
                            var colVal = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName, c);
                            if (colVal != null && colVal != '')
                                colVal = colVal.replace(',', '|');
                            var colValId = request.getLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_' + colName + '_id', c);
                            selectedLinesData += colVal + ',';
                            selectedLinesData += colValId + ',';
                        }
                        selectedLinesData = selectedLinesData.slice(0, -1) + '\n';
                    }
                }
                var timestamp = new Date().getTime();
                var selectedDataFile = nlapiCreateFile('Selected_Lines_to_Consolidate' + timestamp + '.csv', 'CSV', selectedLinesData);
                var ciFolder = context.getSetting('SCRIPT', SPARAM_FOLDER_CLIENT_CONSOLIDATED_INVOICES);
                selectedDataFile.setFolder(ciFolder);
                var fileId = nlapiSubmitFile(selectedDataFile);
                var currentUser = nlapiGetUser();
                var ciExecLogRec = nlapiCreateRecord(CUSTOM_RECORD_CI_EXECUTION_LOG);
                ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_FILE, fileId);
                ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CREATED_BY, currentUser);
                if (totCItoCreate != null && totCItoCreate != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_TOT_EXPECT_CI_TO_CREATE, totCItoCreate);
                if (totInvselected != null && totInvselected != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_TOT_TRANSACTIONS_TO_PROCESS, totInvselected);
                if (transactionLinks != null && transactionLinks != '')
                    ciExecLogRec.setFieldValues(FLD_CI_EXEC_LOG_TRANSACTION_LINKS, transactionLinks);
                if (batOpt1 != null && batOpt1 != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_1, batOpt1);
                if (batOpt2 != null && batOpt2 != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_2, batOpt2);
                if (batOpt3 != null && batOpt3 != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_3, batOpt3);
                if (batOpt4 != null && batOpt4 != '')
                    ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_BATCH_OPTION_4, batOpt4);
                ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_CI_BATCH_STATUS, '1');
                nlapiLogExecution('debug', 'selectedRecordID', selectedRecordID);
                ciExecLogRec.setFieldValue(FLD_CI_EXEC_LOG_LINES_TO_PROCESS, selectedRecordID.join(','));
                var newCIExecLogRec = nlapiSubmitRecord(ciExecLogRec, true, true);
                nlapiLogExecution('debug', 'newCIExecLogRec', newCIExecLogRec);
                if (newCIExecLogRec != null && newCIExecLogRec != '') {
                    response.sendRedirect('RECORD', CUSTOM_RECORD_CI_EXECUTION_LOG, newCIExecLogRec);
                    var params = {};
                    params[SPARAM_CI_EXEC_LOG_ID] = newCIExecLogRec;
                    params[SPARAM_SEARCH_COLS_LENGTH] = parseInt(ssColumns);
                    params[SPARAM_CI_EXEC_FOLDER_ID] = ciFolder;
                    nlapiScheduleScript(SCRIPT_CREATE_CLIENT_CI_SC, null, params);
                }
            }
        } catch (e) {
            if (e instanceof nlobjError)
                nlapiLogExecution('DEBUG', 'system error', e.getCode() + '\n' + e.getDetails());
            else
                nlapiLogExecution('DEBUG', 'unexpected error', e.toString());
        }
    }
}

function batchFieldsData(batchId) {
    var batchFields = {};
    batchFields[1] = {
        'name': 'custcol_appf_bill_month',
        'label': 'Bill Month'
    };
    batchFields[2] = {
        'name': '',
        'label': 'Client Objective'
    };
    batchFields[3] = {
        'name': 'custcol_appf_do_client_po',
        'label': 'Client PO Number'
    };
    batchFields[4] = {
        'name': '',
        'label': 'DMA'
    };
    batchFields[5] = {
        'name': '',
        'label': 'Insertion Date'
    };
    batchFields[6] = {
        'name': 'custbody_appf_print_isodate',
        'label': 'Issue Date'
    };
    batchFields[7] = {
        'name': 'custcol_appf_publisher',
        'label': 'Media Supplier',
        'issel': 'T'
    };
    batchFields[8] = {
        'name': 'custcol_appf_placement1',
        'label': 'Placement_String 1'
    };
    batchFields[9] = {
        'name': 'custcol_appf_placement2',
        'label': 'Placement_String 2'
    };
    batchFields[10] = {
        'name': 'custcol_appf_placement3',
        'label': 'Placement_String 3'
    };
    batchFields[11] = {
        'name': 'custcol_appf_placement4',
        'label': 'Placement_String 4'
    };
    batchFields[12] = {
        'name': 'custcol_appf_placement5',
        'label': 'Placement_String 5'
    };
    batchFields[13] = {
        'name': 'custcol_appf_placement6',
        'label': 'Placement_String 6'
    };
    batchFields[14] = {
        'name': 'custbody_appf_print_mediatype',
        'label': 'Reporting Media Type',
        'issel': 'T'
    };
    batchFields[15] = {
        'name': 'entity',
        'label': 'Schedule Name',
        'issel': 'T'
    };
    batchFields[16] = {
        'name': 'custcol_appf_print_servicedate',
        'label': 'Service Date'
    };
    batchFields[17] = {
        'name': 'custcol_appf_do_estimatenum',
        'label': 'Estimate # (DoMedia)'
    };
    batchFields[18] = {
        'name': 'custcol_appf_do_estimatenum',
        'label': 'Estimate # (Strata)'
    };
    batchFields[19] = {
        'name': 'custcol_appf_print_dds',
        'label': 'Product Code (DoMedia)'
    };
    batchFields[20] = {
        'name': 'custcol_appf_print_dds',
        'label': 'Product Code (Strata)'
    };
    batchFields[21] = {
        'name': 'custcol_appf_do_market',
        'label': 'Market'
    };
    batchFields[22] = {
        'name': 'custcol_appf_po_vendor_name',
        'label': 'Vendor'
    };
    return batchFields[batchId];
}

function getAllPendingLines() {
    var LOG_TITLE = 'fn:getAllPendingLines';
    var invLinesConsolSSObj = nlapiLoadSearch(null, SEARCH_CI_LOGS_IN_PROGRESS);
    var srchFilters = invLinesConsolSSObj.getFilters();
    var srchColumns = invLinesConsolSSObj.getColumns();
    var srchType = invLinesConsolSSObj.getSearchType();
    var results = getAllSearchResults(srchType, srchFilters, srchColumns);
    var lineIDs = [];
    for (var i = 0, n = results.length; i < n; i++) {
        var ids = results[i].getValue('custrecord_appf_ci_lines_toprocess');
        lineIDs = lineIDs.concat(ids.split(','));
    }
    nlapiLogExecution('debug', LOG_TITLE + ' lineIDs', JSON.stringify(lineIDs));
    return lineIDs;
}

function getAllSearchResults(record_type, filters, columns) {
    var search = nlapiCreateSearch(record_type, filters, columns);
    search.setIsPublic(true);
    var searchRan = search.runSearch(), bolStop = false, intMaxReg = 1000, intMinReg = 0, result = [];
    while (!bolStop && nlapiGetContext().getRemainingUsage() > 10) {
        var extras = searchRan.getResults(intMinReg, intMaxReg);
        result = searchUnion(result, extras);
        intMinReg = intMaxReg;
        intMaxReg += 1000;
        if (extras.length < 1000) {
            bolStop = true;
        }
    }
    return result;
}

function searchUnion(target, array) {
    return target.concat(array);
}