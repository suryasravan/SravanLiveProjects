/**
 * Script Name: Appf- EBP Purchase Pay UE
 * Script Type: User Event
 * Deployed On: Payment
 * 
 * Version    Date            Author           		Remarks
 * 1.00            									The script creates a button "Refresh" on the payment record
 *
 * Company 	 : Appficiency. 
 */
var BTN_ROLL_BACK='custpage_refresh';
//var FLD_PAYMENT_APPLICATION_LOG_LINKS = 'custbody_appf_pmt_appl_log_rec_links';
var FLD_PAYMENT_COMPLETED = 'custrecord_appf_ebp_processing_completed';
var FLD_EBP_COMPLETED ='custrecord_ebp_file_gen_script_done'

function beforeLoad(type,form,request)
{
       if(type == 'view')
		{
          var ispayment=nlapiGetFieldValue(FLD_PAYMENT_COMPLETED);
          var paymentebp=nlapiGetFieldValue(FLD_EBP_COMPLETED);
         nlapiLogExecution('debug','ispayment:',ispayment)
          if(ispayment=='F' || paymentebp=='F')
            {
		form.addButton(BTN_ROLL_BACK,'Refresh','location.reload(true)');
            }
	    }
}
 