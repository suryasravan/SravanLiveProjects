/*
* Script Name : Appf-Mark Discrepant VB Lines SC
* Script Type : Scheduled
* Description : This script marks the Descripant field and set value in Discrepant Type field in VB line level from the "appf - Mark Discrepant Vendor Bill Lines (Script - Do Not Use)" SS.
* Company     : Appficiency Inc.
*/

var SPARAM_MARK_DISCREPANT_VB_LINES_SS = 'custscript_appf_mark_disc_vb_lines_ss';
var SPARAM_FILE_ID = 'custscript_appf_vb_lines_file_id';
var SPARAM_INDEX = 'custscript_appf_vb_line_index';

var FLD_COL_VEND_BILL_LINE_ID = 'custcol_appf_vendorbill_line_id';
var FLD_COL_DISCREPANCY_TYPE = 'custcol_appf_discrepancy_type';
var FLD_COL_DISCREPANT = 'custcol_appf_discrepant';

var CUSTOM_LIST_DISCREPANCY_TYPE = 'customlist_appf_discrepancy_type';

function DiscrepantVBLinesScheduled(type){
	try{
	var context = nlapiGetContext();
	var markDiscVBLinesSS = context.getSetting('SCRIPT', SPARAM_MARK_DISCREPANT_VB_LINES_SS);
	var fileId = context.getSetting('SCRIPT', SPARAM_FILE_ID);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if(index == null || index == '')
		index = 0;
	 
	if((fileId == null || fileId == '') && markDiscVBLinesSS != null && markDiscVBLinesSS != ''){
		var markDiscVBLinesSSObj = nlapiLoadSearch(null, markDiscVBLinesSS);
		var filters = markDiscVBLinesSSObj.getFilters();
		var columns = markDiscVBLinesSSObj.getColumns();
		var ssType = markDiscVBLinesSSObj.getSearchType();
		var ssResults = getAllSearchResults(ssType, filters, columns);
		if(ssResults != null && ssResults != ''){
			
			var uniqueVendors = {};
			var vendorsData = '';
			for(var s=0; s<ssResults.length; s++){
				var col = ssResults[s];
				var vbId = col.getId();
				var discType = col.getValue(columns[1]);
				var vbLineId = col.getValue(columns[6]);
				
				if(!uniqueVendors.hasOwnProperty(vbId)){
					uniqueVendors[vbId] = {};
					if(!uniqueVendors[vbId].hasOwnProperty(vbLineId))
						uniqueVendors[vbId][vbLineId] = discType;
				}
				else{
					if(!uniqueVendors[vbId].hasOwnProperty(vbLineId))
						uniqueVendors[vbId][vbLineId] = discType;
				}
			}
			if(uniqueVendors != null && uniqueVendors != ''){
				for(var vend in uniqueVendors){
					vendorsData = vendorsData + vend + '__';
					var keys = Object.keys(uniqueVendors[vend]);
					for(var k =0; k < keys.length; k++ ){
						vendorsData = vendorsData + keys[k] + '::' + uniqueVendors[vend][keys[k]] + '|';
					}
					vendorsData = vendorsData.slice(0, -1)+ '\n';
				}
			}
			var timeStamp = new Date().getTime();
			var file = nlapiCreateFile('VendorBillsResults_'+timeStamp+'.csv', 'CSV', vendorsData);
			file.setFolder('-15');
			fileId = nlapiSubmitFile(file);
			
		}
		
	}
	if(fileId != null && fileId != ''){
		var fileProcessed = true;
		var fileObj = nlapiLoadFile(fileId);
		var fileValue = fileObj.getValue();
		if(fileValue != null && fileValue != ''){
			var col = new Array();
	col[0] = new nlobjSearchColumn('name');
	col[1] = new nlobjSearchColumn('internalId');
	var discrepancyList = {};
	var results = nlapiSearchRecord(CUSTOM_LIST_DISCREPANCY_TYPE, null, null, col);
	for ( var i = 0; results != null && i < results.length; i++ ){
		  var res = results[i];
		  var listValue = res.getValue('name');
		  var listID = res.getValue('internalId');
		  discrepancyList[listValue] = listID;
	}
			var fileData = fileValue.split('\n');
			for(var f=index; f<(fileData.length-1); f++){
				try{
				var fileLine = fileData[f];
				if(fileLine != null && fileLine != ''){
				var lines = fileLine.split('__');	
				var vbId = lines[0];
				var vbLineInfo = lines[1];
				if(vbLineInfo != null && vbLineInfo != ''){
					var vbRec = nlapiLoadRecord('vendorbill', vbId);
					var vbLinesArr = vbLineInfo.split('|');
					for(var v=0; v<vbLinesArr.length; v++){
						var currLine = vbLinesArr[v];
						if(currLine != null && currLine != ''){
							var vbLine = currLine.split('::');
							var vbLineId = vbLine[0];
							var vbDiscId = vbLine[1];
							if(vbDiscId != null && vbDiscId != ''){
								var lineNum = vbRec.findLineItemValue('item', FLD_COL_VEND_BILL_LINE_ID, vbLineId);
								if(lineNum != -1){
									vbRec.setLineItemValue('item', FLD_COL_DISCREPANCY_TYPE, lineNum, discrepancyList[vbDiscId]);
									vbRec.setLineItemValue('item', FLD_COL_DISCREPANT, lineNum, 'T');
								}
							}						
						}
							
					}
					nlapiSubmitRecord(vbRec, true, true);
				}
				}
				}catch(e){
					if ( e instanceof nlobjError )
						nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
						nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
				}
				if(context.getRemainingUsage() < 500 && (f+1) > (fileData.length-1)){
					fileProcessed = false;
					var params = {};
					params[SPARAM_INDEX] = (f+1);
					params[SPARAM_FILE_ID] = fileId;
					params[SPARAM_MARK_DISCREPANT_VB_LINES_SS] = markDiscVBLinesSS;
					nlapiScheduleScript(context.getScriptId(), null, params);
					break;
				}
			
			}
		}
		if(fileProcessed)
			nlapiDeleteFile(fileId);
	}
	}catch(e){
		if ( e instanceof nlobjError )
						nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
					else
						nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
	}
}

function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
function searchUnion(target, array)
	{
		return target.concat(array); // TODO: use _.union
	}
	
	