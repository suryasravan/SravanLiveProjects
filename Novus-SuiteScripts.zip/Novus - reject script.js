/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record'],

function(record) {
   
    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(scriptContext) 
    {

    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function beforeSubmit(scriptContext) 
    {
    	
    }

    /**
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) 
    {
	// Get the value of the Reject reason
    	var rejReason = scriptContext.newRecord.getValue({
    		fieldId: 'custrecord6'							// Change this according to the internal id of the Field Reject Reason in the Custom Record Created
    	});

    	// Get the ID of the Journal Entry Created reason
    	var journalID = scriptContext.newRecord.getValue({
    		fieldId: 'custrecord7'							// Change this according to the internal id of the Field Journal Entry in the Custom Record Created
    	});
 	
	// populate the Reject Reason in the Journal Entry field
    	var id = record.submitFields({
    	    type: record.Type.JOURNAL_ENTRY,
    	    id: journalID,
    	    values: {
    	    	custbodycustbody_reject_reason: rejReason						// Change custbody1 to the internal id of the custom field Reject Reason in the Journal Entry Record
    	    },
    	    options: {
    	        enableSourcing: false,
    	        ignoreMandatoryFields : true
    	    }
    	});
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
    
});