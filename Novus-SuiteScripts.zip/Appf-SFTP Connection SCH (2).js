/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 */

var FLD_PDF_PRINTED = 'custrecord_appf_pdf_printed';
 


var SFTP_USERNAME =  'novus_test';
var SFTP_PASSWORD_GUID = '1de37304e4c5407ea1844579e37f2111';
var SFTP_DOMAIN = 'fsgateway.aexp.com';
var SFTP_HOSTKEY = 'AAAAB3NzaC1yc2EAAAADAQABAAABAQDUs0jorN2/HIsD2HJyeETzpyU4duAMYY7GTgGHe1GYZCh3Z4VvU+just0G3cGVgt6zmZVgb5tmZqDqvqrnssvFhSK2d5WxVTkvZM0saFw3MCYFg0I6KszUKeQawwDDgrcgUGbCfLY0KE5oe3JwlPGyhAeQ+HCEP2+yxWFNI8AL0oykXGWUdxt9jJrFqErKUtvVymCo8lnwUJoNagVRKm/iwwNUSmd0TppOYEg0PAeBcc728zUskvqKMk4tDwP1yXkJ+5QdVC6xxwHgjF9FPX8BvL3Ku2LeyVtKPN9FrHABsu0ZmJv1dFqbrj+cOf2jzE99cadH8HtSXqb8LlmRhYtF';
var SFTP_HOSTKEY_TYPE = 'rsa';
var SFTP_FILE_DIRECTORY = '/inbox';

var CUSTOM_RECORD_CI = 'customrecord_nsts_ci_consolidate_invoice';
var SPARAM_INDEX = 'custscript_sftp_file_index';
var SPARAM_FILE_ID = 'custscript_sftp_file_id';
define(['N/search', 'N/runtime', 'N/sftp', 'N/keyControl', 'N/file', 'N/record', 'N/https', 'N/url', 'N/task'],
    function(search, runtime, sftp, keyControl, file, record, https, url, task) {
        function execute(context) 
		{     
			
			
				var connection = null;
                try{
            //directory: SFTP_FILE_DIRECTORY
					connection = sftp.createConnection({
					username: SFTP_USERNAME,
					passwordGuid: SFTP_PASSWORD_GUID,
					url: SFTP_DOMAIN,
					hostKey: SFTP_HOSTKEY,
					hostKeyType: SFTP_HOSTKEY_TYPE,
                      directory: SFTP_FILE_DIRECTORY
					
				});
                  log.debug('connection : '+connection);
                }
				catch(ep)
				{
				  connection = null;
				}
				if (connection == null)
				{
					connection = sftp.createConnection({
					username: SFTP_USERNAME,
					passwordGuid: SFTP_PASSWORD_GUID,
					url: SFTP_DOMAIN,
					hostKey: SFTP_HOSTKEY,                      
					hostKeyType: SFTP_HOSTKEY_TYPE
					});
				  log.debug('connection : '+connection);
				  
				}
		
				
					try{
					   
						var myFileToUpload = file.load({
							id: '273623'
						});
			

						connection.upload({
						  file: myFileToUpload,
                          replaceExisting: true,
                          directory: SFTP_FILE_DIRECTORY,
                          filename: myFileToUpload.name
						});
								  
							
    }catch(e)
			{
				log.debug('Error in SFTP Connection:',e.toString());
			}

				
        }
        return {
            onRequest: execute
        };
    });