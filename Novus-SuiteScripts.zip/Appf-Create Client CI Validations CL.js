/*
* Script Name : Appf-Create Client CI Validations CL
* Script Type : Client
* Description : 
* Company     : Appficiency Inc.
*/

var FLD_SL_PARENT_CLIENT = 'custpage_parent_client';
var FLD_SL_CLIENT = 'custpage_client';
var FLD_SL_SUBSIDIARY = 'custpage_subsidiary';
var FLD_SL_MEDIA_SEGMENT = 'custpage_media_segment';
var FLD_SL_LINE_OF_BUSIBNESS = 'custpage_line_of_business';
var FLD_SL_CURRENCY = 'custpage_currency';
var FLD_SL_CONTRACT = 'custpage_contract';
var FLD_SL_PUBLISHER_MEDIA_SIPPLIER = 'custpage_publisher_media_supplier';
var FLD_SL_VENDOR = 'custpage_vendor';
var FLD_SL_TRANSACTION_TYPE = 'custpage_transaction_tupe';
var FLD_SL_DATE_FROM = 'custpage_date_from';
var FLD_SL_DATE_TO = 'custpage_date_to';
var FLD_SL_SCHED_NAME_PROJ = 'custpage_sched_ame_proj';
var FLD_SL_BILL_MONTH = 'custpage_bill_month';
var FLD_SL_ADJUSTMENT_INVOICE = 'custpage_adjustment_invoice';
var FLD_SL_PLACEMENT_STR_1 = 'custpage_placement_str_1';
var FLD_SL_PLACEMENT_STR_2 = 'custpage_placement_str_2';
var FLD_SL_PLACEMENT_STR_3 = 'custpage_placement_str_3';
var FLD_SL_PLACEMENT_STR_4 = 'custpage_placement_str_4';
var FLD_SL_PLACEMENT_STR_5 = 'custpage_placement_str_5';
var FLD_SL_PLACEMENT_STR_6 = 'custpage_placement_str_6';
var FLD_SL_GRP_TRANSACTION_LINKS = 'custpage_ci_transaction_links';


var FLD_SL_GRP_BATCH_OPTION_1 = 'custpage_batch_opt_1';
var FLD_SL_GRP_BATCH_OPTION_2 = 'custpage_batch_opt_2';
var FLD_SL_GRP_BATCH_OPTION_3 = 'custpage_batch_opt_3';
var FLD_SL_GRP_BATCH_OPTION_4 = 'custpage_batch_opt_4';
var FLD_SL_GRP_OVERRIDE = 'custpage_override';

var FLD_SL_GRP_INV_AVAIL_CONSOL = 'custpage_inv_avail_consol';
var FLD_SL_GRP_INV_LINES_AVAIL_CONSOL = 'custpage_inv_lines_avail_consol';
var FLD_SL_GRP_TOT_CI_TO_CREATE = 'custpage_total_ci_to_create';
var FLD_SL_GRP_TOT_CI_AMT = 'custpage_total_ci_amount';
var FLD_SL_GRP_TOT_CI_INVOICES = 'custpage_total_ci_invoices';

var SUBLIST_SL_INV_DETAILS = 'custpage_sublist_inv_details';
var FLD_COL_SL_SELECT = 'custpage_sl_select';
var FLD_COL_SL_AMOUNT = 'custpage_formulacurrency_1';
var FLD_COL_SL_INTERNAL_ID = 'custpage_internal_id';

var CUSTOM_RECORD_CONTRACT = 'customrecord_appf_client_contract';
var FLD_CONTRACT_REC_BATCH_OPT_1 = 'custrecord_appf_contract_batchoption1';
var FLD_CONTRACT_REC_BATCH_OPT_2 = 'custrecord_appf_contract_batchoption2';
var FLD_CONTRACT_REC_BATCH_OPT_3 = 'custrecord_appf_contract_batchoption3';
var FLD_CONTRACT_REC_BATCH_OPT_4 = 'custrecord_appf_contract_batchoption4';

var SCRIPT_CREATE_CLIENT_CI_SL = 'customscript_appf_create_client_ci_sl';
var DEPLOY_CREATE_CLIENT_CI_SL = 'customdeploy_appf_create_client_ci_sl';

function createCCIFieldChange(type, name, linenum){
	
	if (name == FLD_SL_CLIENT)
	{
		var clientFlt = nlapiGetFieldValue(FLD_SL_CLIENT);
		if(clientFlt!=null && clientFlt!='')
		{
			var client = nlapiLookupField('customer', clientFlt, ['subsidiary','currency']);
			var clientSub=client.subsidiary
			var clientCurrecy=client.currency
			nlapiSetFieldValue(FLD_SL_CURRENCY, clientCurrecy);
			nlapiSetFieldValue(FLD_SL_SUBSIDIARY,clientSub);
			
		}
       else
        {
             nlapiSetFieldValue(FLD_SL_CURRENCY, '');
			nlapiSetFieldValue(FLD_SL_SUBSIDIARY,'');
        }
     
		applyFilters("yes");
	}
  
	if(name == FLD_SL_GRP_OVERRIDE){
		var batOpt1Fld = nlapiGetField(FLD_SL_GRP_BATCH_OPTION_1);
		var batOpt2Fld = nlapiGetField(FLD_SL_GRP_BATCH_OPTION_2);
		var batOpt3Fld = nlapiGetField(FLD_SL_GRP_BATCH_OPTION_3);
		var batOpt4Fld = nlapiGetField(FLD_SL_GRP_BATCH_OPTION_4);
		var override = nlapiGetFieldValue(FLD_SL_GRP_OVERRIDE);
		
		if(override == 'T'){
			batOpt1Fld.setDisplayType('normal');
			batOpt2Fld.setDisplayType('normal');
			batOpt3Fld.setDisplayType('normal');
			batOpt4Fld.setDisplayType('normal');
		}
		else{
			batOpt1Fld.setDisplayType('disabled');
			batOpt2Fld.setDisplayType('disabled');
			batOpt3Fld.setDisplayType('disabled');
			batOpt4Fld.setDisplayType('disabled');
		}
	}
	if(name == FLD_SL_CONTRACT){
		var contractFlt = nlapiGetFieldValue(FLD_SL_CONTRACT);
		if(contractFlt != null && contractFlt != ''){
			var contractRec = nlapiLoadRecord(CUSTOM_RECORD_CONTRACT, contractFlt);
			var batchOpt1 = contractRec.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_1);
			var batchOpt2 = contractRec.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_2);
			var batchOpt3 = contractRec.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_3);
			var batchOpt4 = contractRec.getFieldValue(FLD_CONTRACT_REC_BATCH_OPT_4);
			
			if(batchOpt1 == null || batchOpt1 == '')
				batchOpt1 = '';
			if(batchOpt2 == null || batchOpt2 == '')
				batchOpt2 = '';
			if(batchOpt3 == null || batchOpt3 == '')
				batchOpt3 = '';
			if(batchOpt4 == null || batchOpt4 == '')
				batchOpt4 = '';
			
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_1, batchOpt1);
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_2, batchOpt2);
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_3, batchOpt3);
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_4, batchOpt4);
		}
		else{
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_1, '');
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_2, '');
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_3, '');
			nlapiSetFieldValue(FLD_SL_GRP_BATCH_OPTION_4, '');
		}
	}
	if(type == SUBLIST_SL_INV_DETAILS && name == FLD_COL_SL_SELECT){
			var batOpt1 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_1);
			var batOpt2 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_2);
			var batOpt3 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_3);
			var batOpt4 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_4);
			var uniqueBatchGrp = {};
			var uniqueTransactions = [];
			var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS);
			for(var c=1; c<=count; c++){
				var prevSelected = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c);
				if(prevSelected == 'T'){
					var internalId = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_INTERNAL_ID, c);
					if(uniqueTransactions.indexOf(internalId) == -1)
						uniqueTransactions.push(internalId);
					var batchGrp = '';
					var amt = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_AMOUNT, c);
					if(amt == null || amt == '')
						amt = 0;
					if(batOpt1 != null && batOpt1 != ''){
						var batch1FldName = batchFieldsData(batOpt1).name;
						
						batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch1FldName, c)+'||';
						
						console.log('batch1FldName='+batch1FldName + ' batch 1='+nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch1FldName, c));
					}
					if(batOpt2 != null && batOpt2 != ''){
						var batch2FldName = batchFieldsData(batOpt2).name;
						batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch2FldName, c)+'||';
						
						console.log('column id = ' + 'custpage_'+batch2FldName);
						console.log('batch2FldName='+batch2FldName + ' batch 2='+nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch2FldName, c));
					
					
					}
					if(batOpt3 != null && batOpt3 != ''){
						var batch3FldName = batchFieldsData(batOpt3).name;
						batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch3FldName, c)+'||';
					}
					if(batOpt4 != null && batOpt4 != ''){
						var batch4FldName = batchFieldsData(batOpt4).name;
						batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch4FldName, c)+'||';
					}
					if(!uniqueBatchGrp.hasOwnProperty(batchGrp)){
						uniqueBatchGrp[batchGrp] = {};
						uniqueBatchGrp[batchGrp].amt = amt;
					}
					else{
						uniqueBatchGrp[batchGrp].amt = parseFloat(uniqueBatchGrp[batchGrp].amt) + parseFloat(amt);
					}
				}				
			}
			var totAmt = 0;
			var totCItoCreate = 0;
			console.log('uniqueBatchGrp='+JSON.stringify(uniqueBatchGrp));
			for(var prop in uniqueBatchGrp){
				totCItoCreate++;
				totAmt = parseFloat(totAmt) + parseFloat(uniqueBatchGrp[prop].amt);
			}
			nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_TO_CREATE, totCItoCreate);
			nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_AMT, totAmt);
			if(uniqueTransactions != null && uniqueTransactions != '')
			{
				nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_INVOICES, uniqueTransactions.length);
				nlapiSetFieldValues(FLD_SL_GRP_TRANSACTION_LINKS,uniqueTransactions);
			}
			else
			{
				nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_INVOICES, 0);
				nlapiSetFieldValues(FLD_SL_GRP_TRANSACTION_LINKS,null);
			}
	}
}

function submitCreateCISL(){
	var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS);
	var selectedLines = 0;
	for(var c=1; c<=count; c++){
		var selected = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c);
		if(selected == 'T'){
			selectedLines++;
		}
	}
	if(selectedLines == 0){
		alert('Please select atleast one line to Submit.');
		return false;
	}
	else{
		
		var submitConfirmation= confirm('Selected transactions will be processed for Consolidation, Click OK to proceed.');
    if (submitConfirmation== true)
    {
		return true;
    }
   else
   {
       return false;
   }
    }
}

function applyFilters(doNotapply){
	
	//var parentClient = nlapiGetFieldValue(FLD_SL_PARENT_CLIENT);
	var clientFlt = nlapiGetFieldValue(FLD_SL_CLIENT);
	var subsiFlt = nlapiGetFieldValue(FLD_SL_SUBSIDIARY);
	var medSegFlt = nlapiGetFieldValue(FLD_SL_MEDIA_SEGMENT);
	var lobFlt = nlapiGetFieldValue(FLD_SL_LINE_OF_BUSIBNESS);
	var currFlt = nlapiGetFieldValue(FLD_SL_CURRENCY);
	var contractFlt = nlapiGetFieldValue(FLD_SL_CONTRACT);
	var pubMedSupFlt = nlapiGetFieldValue(FLD_SL_PUBLISHER_MEDIA_SIPPLIER);
	var vendFlt = nlapiGetFieldValue(FLD_SL_VENDOR);
	var transTypeFlt = nlapiGetFieldValue(FLD_SL_TRANSACTION_TYPE);
	var dtFrmFlt = nlapiGetFieldValue(FLD_SL_DATE_FROM);
	var dtToFlt = nlapiGetFieldValue(FLD_SL_DATE_TO);
	var schedProjFlt = nlapiGetFieldValue(FLD_SL_SCHED_NAME_PROJ);
	var billMnthFlt = nlapiGetFieldValue(FLD_SL_BILL_MONTH);
	var adjustInvFlt = nlapiGetFieldValue(FLD_SL_ADJUSTMENT_INVOICE);
	var plcmntStr1Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_1);
	var plcmntStr2Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_2);
	var plcmntStr3Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_3);
	var plcmntStr4Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_4);
	var plcmntStr5Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_5);
	var plcmntStr6Flt = nlapiGetFieldValue(FLD_SL_PLACEMENT_STR_6);
	
	var batOpt1 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_1);
	var batOpt2 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_2);
	var batOpt3 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_3);
	var batOpt4 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_4);
	var override = nlapiGetFieldValue(FLD_SL_GRP_OVERRIDE);
	
	/*if((parentClient == null || parentClient == '') && (clientFlt == null || clientFlt == '') && (subsiFlt == null || subsiFlt == '') && (medSegFlt == null || medSegFlt == '') && (lobFlt == null || lobFlt == '') && (currFlt == null || currFlt == '') && (contractFlt == null || contractFlt == '') && (pubMedSupFlt == null || pubMedSupFlt == '') && (vendFlt == null || vendFlt == '') && (transTypeFlt == null || transTypeFlt == '') && (dtFrmFlt == null || dtFrmFlt == '') && (dtToFlt == null || dtToFlt == '') && (schedProjFlt == null || schedProjFlt == '') && (billMnthFlt == null || billMnthFlt == '') && (plcmntStr1Flt == null || plcmntStr1Flt == '') && (plcmntStr2Flt == null || plcmntStr2Flt == '') && (plcmntStr3Flt == null || plcmntStr3Flt == '') && (plcmntStr4Flt == null || plcmntStr4Flt == '') && (plcmntStr5Flt == null || plcmntStr5Flt == '') && (plcmntStr6Flt == null || plcmntStr6Flt == '') )  
	{
		alert('Please enter at least one filter to proceed.');
	}*/
				if (!doNotapply)
				{	
	if((clientFlt == null || clientFlt == '') && (contractFlt == null || contractFlt == '') && (currFlt == null || currFlt == '')){
		alert('Please enter value(s) for the fields: Client, Contract and Currency');
	}
  else if((clientFlt == null || clientFlt == '') && (contractFlt != null && contractFlt != '') && (currFlt == null || currFlt == '')){
		alert('Please enter value for the fields: Client and Currency');
	}
   else if((clientFlt != null && clientFlt != '') && (contractFlt == null || contractFlt == '') && (currFlt == null || currFlt == '')){
		alert('Please enter value for the fields: Contract and Currency');
	}
	   else if((clientFlt == null || clientFlt == '') && (contractFlt == null || contractFlt == '') && (currFlt != null && currFlt != '')){
		alert('Please enter value for the fields: Client and Contract');
	}
	else if((clientFlt == null || clientFlt == '') && (contractFlt != null && contractFlt != '') && (currFlt != null && currFlt != '')){
		alert('Please enter value for the field: Client');
	}
	else if((clientFlt != null && clientFlt != '') && (contractFlt == null || contractFlt == '') && (currFlt != null && currFlt != '')){
		alert('Please enter value for the field: Contract');
	}
	else if((clientFlt != null && clientFlt != '') && (contractFlt != null && contractFlt != '') && (currFlt == null || currFlt == '')){
		alert('Please enter value for the field: Currency');
	}
	else{
		var url = nlapiResolveURL('SUITELET', SCRIPT_CREATE_CLIENT_CI_SL, DEPLOY_CREATE_CLIENT_CI_SL);
		url += '&clientFlt='+clientFlt+'&subsiFlt='+subsiFlt+'&medSegFlt='+medSegFlt+'&lobFlt='+lobFlt+'&currFlt='+currFlt;
		url += '&contractFlt='+contractFlt+'&pubMedSupFlt='+pubMedSupFlt+'&vendFlt='+vendFlt+'&transTypeFlt='+transTypeFlt+'&dtFrmFlt='+dtFrmFlt+'&dtToFlt='+dtToFlt;
		url += '&schedProjFlt='+schedProjFlt+'&billMnthFlt='+billMnthFlt+'&adjustInvFlt='+adjustInvFlt+'&plcmntStr1Flt='+plcmntStr1Flt+'&plcmntStr2Flt='+plcmntStr2Flt+'&plcmntStr3Flt='+plcmntStr3Flt;
		url += '&plcmntStr4Flt='+plcmntStr4Flt+'&plcmntStr5Flt='+plcmntStr5Flt+'&plcmntStr6Flt='+plcmntStr6Flt+'&batOpt1='+batOpt1+'&batOpt2='+batOpt2+'&batOpt3='+batOpt3+'&batOpt4='+batOpt4;
		//if (!doNotapply)
		url += '&isOverride='+override+'&applyFilters=T';
		
		window.open(url, '_self');
	}
				}
				else
				{
					var url = nlapiResolveURL('SUITELET', SCRIPT_CREATE_CLIENT_CI_SL, DEPLOY_CREATE_CLIENT_CI_SL);
		url += '&clientFlt='+clientFlt+'&subsiFlt='+subsiFlt+'&medSegFlt='+medSegFlt+'&lobFlt='+lobFlt+'&currFlt='+currFlt;
		url += '&contractFlt='+contractFlt+'&pubMedSupFlt='+pubMedSupFlt+'&vendFlt='+vendFlt+'&transTypeFlt='+transTypeFlt+'&dtFrmFlt='+dtFrmFlt+'&dtToFlt='+dtToFlt;
		url += '&schedProjFlt='+schedProjFlt+'&billMnthFlt='+billMnthFlt+'&adjustInvFlt='+adjustInvFlt+'&plcmntStr1Flt='+plcmntStr1Flt+'&plcmntStr2Flt='+plcmntStr2Flt+'&plcmntStr3Flt='+plcmntStr3Flt;
		url += '&plcmntStr4Flt='+plcmntStr4Flt+'&plcmntStr5Flt='+plcmntStr5Flt+'&plcmntStr6Flt='+plcmntStr6Flt+'&batOpt1='+batOpt1+'&batOpt2='+batOpt2+'&batOpt3='+batOpt3+'&batOpt4='+batOpt4;
		//if (!doNotapply)
		url += '&isOverride='+override+'&applyFilters=F';
		
		window.open(url, '_self');
				}
}

function markAll(){
	var batOpt1 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_1);
	var batOpt2 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_2);
	var batOpt3 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_3);
	var batOpt4 = nlapiGetFieldValue(FLD_SL_GRP_BATCH_OPTION_4);
	var uniqueBatchGrp = {};
	var uniqueTransactions = [];
	var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS);
    console.log('markAll count', count);
	for(var c=1; c<=count; c++){
		nlapiSetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c, 'T');
		var internalId = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_INTERNAL_ID, c);
		if(uniqueTransactions.indexOf(internalId) == -1)
			uniqueTransactions.push(internalId);
		var batchGrp = '';
		var amt = nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_AMOUNT, c);
		if(amt == null || amt == '')
			amt = 0;
		if(batOpt1 != null && batOpt1 != ''){
			var batch1FldName = batchFieldsData(batOpt1).name;
			batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch1FldName, c)+'||';
		}
		if(batOpt2 != null && batOpt2 != ''){
			var batch2FldName = batchFieldsData(batOpt2).name;
			batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch2FldName, c)+'||';
		}
		if(batOpt3 != null && batOpt3 != ''){
			var batch3FldName = batchFieldsData(batOpt3).name;
			batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch3FldName, c)+'||';
		}
		if(batOpt4 != null && batOpt4 != ''){
			var batch4FldName = batchFieldsData(batOpt4).name;
			batchGrp += nlapiGetLineItemValue(SUBLIST_SL_INV_DETAILS, 'custpage_'+batch4FldName, c)+'||';
		}
		if(!uniqueBatchGrp.hasOwnProperty(batchGrp)){
			uniqueBatchGrp[batchGrp] = {};
			uniqueBatchGrp[batchGrp].amt = amt;
		}
		else{
			uniqueBatchGrp[batchGrp].amt = parseFloat(uniqueBatchGrp[batchGrp].amt) + parseFloat(amt);
		}
	}
	var totAmt = 0;
	var totCItoCreate = 0;
	for(var prop in uniqueBatchGrp){
		totCItoCreate++;
		totAmt = parseFloat(totAmt) + parseFloat(uniqueBatchGrp[prop].amt);
	}
	nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_TO_CREATE, totCItoCreate);
	nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_AMT, totAmt);
	if(uniqueTransactions != null && uniqueTransactions != '')
	{
		nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_INVOICES, uniqueTransactions.length);
						nlapiSetFieldValues(FLD_SL_GRP_TRANSACTION_LINKS,uniqueTransactions);

	}
}

function unmarkAll(){
	var count = nlapiGetLineItemCount(SUBLIST_SL_INV_DETAILS);
	for(var c=1; c<=count; c++){
		nlapiSetLineItemValue(SUBLIST_SL_INV_DETAILS, FLD_COL_SL_SELECT, c, 'F');
	}
	nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_TO_CREATE, '');
	nlapiSetFieldValue(FLD_SL_GRP_TOT_CI_AMT, '');
							nlapiSetFieldValues(FLD_SL_GRP_TRANSACTION_LINKS,null);

}

function batchFieldsData(batchId){
	var batchFields = {};
 
	batchFields[1] = {"name":"custcol_appf_bill_month","label":"Bill Month"};
	batchFields[2] = {"name":"","label":"Client Objective"};
	batchFields[3] = {"name":"custcol_appf_do_client_po","label":"Client PO Number"};
	batchFields[4] = {"name":"","label":"DMA"};
	batchFields[5] = {"name":"","label":"Insertion Date"};
	batchFields[6] = {"name":"custbody_appf_print_isodate","label":"Issue Date"};
	batchFields[7] = {"name":"custcol_appf_publisher","label":"Media Supplier", "issel":"T"};
	batchFields[8] = {"name":"custcol_appf_placement1","label":"Placement_String 1"};
	batchFields[9] = {"name":"custcol_appf_placement2","label":"Placement_String 2"};
	batchFields[10] = {"name":"custcol_appf_placement3","label":"Placement_String 3"};
	batchFields[11] = {"name":"custcol_appf_placement4","label":"Placement_String 4"};
	batchFields[12] = {"name":"custcol_appf_placement5","label":"Placement_String 5"};
	batchFields[13] = {"name":"custcol_appf_placement6","label":"Placement_String 6"};
	batchFields[14] = {"name":"custbody_appf_print_mediatype","label":"Reporting Media Type", "issel":"T"};
	batchFields[15] = {"name":"entity","label":"Schedule Name", "issel":"T"};
	batchFields[16] = {"name":"custcol_appf_print_servicedate","label":"Service Date"};
    batchFields[17] = {"name":"custcol_appf_do_estimatenum","label":"Estimate # (DoMedia)"};
    batchFields[18] = {"name":"custcol_appf_do_estimatenum","label":"Estimate # (Strata)"};
    batchFields[19] = {"name":"custcol_appf_print_dds","label":"Product Code (DoMedia)"};
    batchFields[20] = {"name":"custcol_appf_print_dds","label":"Product Code (Strata)"};
    batchFields[21] = {"name":"custcol_appf_do_market","label":"Market"};
    batchFields[22] = {"name":"custcol_appf_po_vendor_name","label":"Vendor"};
	
	return batchFields[batchId];
}
/*function batchFieldsData(batchId){
	var batchFields = [];
 
	batchFields[1] = {"name":"custcol_appf_bill_month","label":"Bill Month"};
	batchFields[2] = {"name":"","label":"Client Objective"};
	batchFields[3] = {"name":"custcol_appf_do_client_po","label":"Client PO Number"};
	batchFields[4] = {"name":"","label":"DMA"};
	batchFields[5] = {"name":"","label":"Insertion Date"};
	batchFields[6] = {"name":"custbody_appf_print_isodate","label":"Issue Date"};
	batchFields[7] = {"name":"custcol_appf_publisher","label":"Media Supplier"};
	batchFields[8] = {"name":"custbody_appf_print_placementstring1","label":"Placement_String 1"};
	batchFields[9] = {"name":"custbody_appf_print_placementstring2","label":"Placement_String 2"};
	batchFields[10] = {"name":"custbody_appf_print_placementstring3","label":"Placement_String 3"};
	batchFields[11] = {"name":"custbody_appf_print_placementstring4","label":"Placement_String 4"};
	batchFields[12] = {"name":"custbody_appf_print_placementstring5","label":"Placement_String 5"};
	batchFields[13] = {"name":"custbody_appf_print_placementstring6","label":"Placement_String 6"};
	batchFields[14] = {"name":"custbody_appf_print_mediatype","label":"Reporting Media Type"};
	batchFields[15] = {"name":"entity","label":"Schedule Name"};
	batchFields[16] = {"name":"custbody_appf_print_servicedate","label":"Service Date"};
    batchFields[17] = {"name":"custcol_appf_do_estimatenum","label":"Estimate # (DoMedia)"};
    batchFields[18] = {"name":"custcol_appf_do_estimatenum","label":"Estimate # (Strata)"};
    batchFields[19] = {"name":"custcol_appf_print_dds","label":"Product Code (DoMedia)"};
    batchFields[20] = {"name":"custcol_appf_print_dds","label":"Product Code (Strata)"};
    batchFields[21] = {"name":"custcol_appf_do_market","label":"Market"};
    batchFields[22] = {"name":"custcol_appf_po_vendor_name","label":"Vendor"};
	
	return batchFields[batchId];
}*/
