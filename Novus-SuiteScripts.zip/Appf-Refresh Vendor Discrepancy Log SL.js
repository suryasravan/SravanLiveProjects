/*Script Name: Appf-Refresh Vendor Discrepancy Log SL
 *Script Type: Suitelet
 *Description: This Script trigger on click of Refresh button on Appf - Vendor Discrepancy Execution Log Record to calculate no.of records processed.
 *Company 	 : Appficiency.
 */
var CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG='customrecord_appf_vendor_discrepancy_log';
var TOTAL_VENDOR_BILL_LINE_PROCESSED='custrecord_appf_tot_vb_lines_processed';

var FLD_COL_VENDOR_DIS_EXECUTION_LOG_LINK='custcol_appf_vb_discrepancy_exec_log';

function vendorDiscrepancyLogSS(request, response)
{
	if(request.getMethod() == 'GET')
	{	
	try{
		
		var customRecVendorDisLogId=request.getParameter('custrecid');
		nlapiLogExecution('debug','customRecVendorDisLogId:',customRecVendorDisLogId);
		var totalVendorBillLineProcessed=0;
		var filters =[];
		if(customRecVendorDisLogId != null && customRecVendorDisLogId != ''){
		 filters.push(new nlobjSearchFilter(FLD_COL_VENDOR_DIS_EXECUTION_LOG_LINK, null, 'anyof',customRecVendorDisLogId));
		 filters.push(new nlobjSearchFilter('mainline', null, 'is','F'));
         var vbSearchResults = nlapiSearchRecord('vendorbill', null, filters, null);
         if (vbSearchResults != null && vbSearchResults != '') 
         {
 			nlapiLogExecution('debug','vbSearchResults length:', vbSearchResults.length);
 			totalVendorBillLineProcessed=vbSearchResults.length;
 			
         }
         if(customRecVendorDisLogId != null && customRecVendorDisLogId != '')
  			nlapiSubmitField(CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG, customRecVendorDisLogId, TOTAL_VENDOR_BILL_LINE_PROCESSED, totalVendorBillLineProcessed);
		
		response.sendRedirect('RECORD', CUSTOM_REC_VENDOR_DISCREPANCY_EXEC_LOG,customRecVendorDisLogId);

		}
	}catch (e) {
		   if ( e instanceof nlobjError )
			      nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() )
			      else
			      nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() )
			}
	}
	
}
	