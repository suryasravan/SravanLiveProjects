/**
*Script Name: Appf-Sync Azure Queues SL
*Script Type: Suitelet Script
*Description: This script triggers from Azure's Timer Trigger function and calls this suitelet every one minute and this will trigger all Connex and Buying System Integration Flows 
*Company 	: Appficiency Inc.
*/
    var SCRIPT_CONNEX_AGENCY='customscript_appf_connex_agency_2_ns_sc'
    var SCRIPT_CONNEX_CLIENT='customscript_appf_connex_client_2_ns_sc'
    var SCRIPT_CONNEX_CONTACT='customscript_appf_connex_contact_2_ns_sc'
    var SCRIPT_CONNEX_CONTRACT='customscript_appf_connex_contrac_2_ns_sc'
    var SCRIPT_CONNEX_VENDORS='customscript_appf_connex_vendor_2_ns_sc'
    var SCRIPT_CONNEX_MEDISUPP='customscript_appf_connex_medsupp_2_ns_sc'

    var SCRIPT_MERCURY_PROJECT='customscript_appf_mercury_project_to_scs'
    var SCRIPT_DIGITAL_PROJECT='customscript_appf_digita_project_2_ns_sc'
    var SCRIPT_STRATA_PROJECT='customscript_appf_strata_project_2_ns_sc' 
    var SCRIPT_DOMEDIAS_PROJECT='customscript_appf_do_med_project_2_ns_s'
    var SCRIPT_DOMEDIAS_PROJECT_SINGLE='customscript_appf_do_med_proj_sc_single'
    
    var SCRIPT_MERCURY_ORDERS='customscript_appmercury_order_to_netsuit'
    var SCRIPT_DIGITAL_ORDERS='customscript_appf_digital_order_2_ns_sc'
    var SCRIPT_STRATA_ORDERS='customscript_appf_strata_order_2_ns_sc'
    var SCRIPT_DOMEDIAS_ORDERS='customscript_appf_do_med_contrac_2_ns_sc'
    var SCRIPT_DOMEDIAS_ORDERS_SINGLE='customscript_appf_do_med_contrac_sc_sngl'
    
    var SCRIPT_STRATA_OCR_VENDDOR_BILL = 'customscript_strata_ocr_vendorbill_sc';

      
	var QUEUE_CONNEX_VENDOR_INBOUND = 'novusmedia_connex_vendor_in';
	var QUEUE_CONNEX_AGENCEY_INBOUND = 'novusmedia_connex_agency_in';
	var QUEUE_CONNEX_MEDIA_SUPP_INBOUND = 'novusmedia_connex_mediasupplier_in';
	var QUEUE_CONNEX_CLIENT_INBOUND = 'novusmedia_connex_client_in';
	var QUEUE_CONNEX_CONTACT_INBOUND = 'novusmedia_connex_contact_in';
	var QUEUE_CONNEX_CONTRACT_INBOUND = 'novusmedia_connex_contract_in';
	var QUEUE_DIGITAL_ORDER_INBOUND = 'novusmedia_digital_order_in';
	var QUEUE_DOMEDIAS_ORDERS_INBOUND = 'novusmedia_domedia_order_in';
    var QUEUE_DOMEDIAS_ORDERS_SINGLE_INBOUND = 'novusmedia_domedia_singleline_order_in';
	var QUEUE_MERCURY_ORDER_INBOUND = 'novusmedia_mercury_order_in';
	var QUEUE_STRATA_ORDER_INBOUND = 'novusmedia_strata_order_in';
	var QUEUE_DIGITAL_PROJECT_INBOUND = 'novusmedia_digital_project_in';
	var QUEUE_DOMEDIAS_PROJECT_INBOUND = 'novusmedia_domedia_project_in';
    var QUEUE_DOMEDIAS_PROJECT_SINGLE_INBOUND = 'novusmedia_domedia_singleline_project_in';
	var QUEUE_STRATA_PROJECT_INBOUND = 'novusmedia_strata_project_in';
	var QUEUE_MERCURY_PROJECT_INBOUND = 'novusmedia_mercury_project_in';
    var QUEUE_CONNEX_ORDER_INBOUND = 'novusmedia_vendorbill_in';

	  var d = new Date();
        var UTCDate= d.toISOString();
		var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'

	
	
    
function suitelet(request, response)
{
  //var URL_BASE = 'https://nvm-prd-sbus-usc-integrations-01.servicebus.windows.net/';	
  nlapiLogExecution('DEBUG', 'Triggered From Azure On:', new Date());
 
   var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}

nlapiLogExecution('DEBUG', 'Triggered From Azure On:', new Date());
  
      if(URL_BASE!=null && URL_BASE!='')
        {
           var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
      // digital
      
		var url = URL_BASE+QUEUE_DIGITAL_ORDER_INBOUND+'/messages/head?api-version=2015-01';
		
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDigital = responseData.getBody()+'';
 
        // DOMEDIAS
		var url = URL_BASE+QUEUE_DOMEDIAS_ORDERS_INBOUND+'/messages/head?api-version=2015-01';
		
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDomidia = responseData.getBody()+'';
          
        // DOMEDIA Orders Single
		var url = URL_BASE+QUEUE_DOMEDIAS_ORDERS_SINGLE_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDoMediaSingle = responseData.getBody()+'';
		
        //
        var url = URL_BASE+QUEUE_CONNEX_VENDOR_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjvendor = responseData.getBody()+'';
		
		 var url = URL_BASE+QUEUE_CONNEX_AGENCEY_INBOUND+'/messages/head?api-version=2015-01'
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjAgencey = responseData.getBody()+'';
		
		 var url = URL_BASE+QUEUE_CONNEX_MEDIA_SUPP_INBOUND+'/messages/head?api-version=2015-01'
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjMediaSup = responseData.getBody()+'';
		
		 var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjClient = responseData.getBody()+'';
		
	    var url = URL_BASE+QUEUE_CONNEX_CONTACT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjContact = responseData.getBody()+'';	
		
		 var url = URL_BASE+QUEUE_CONNEX_CONTRACT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjContract = responseData.getBody()+'';	
		
		var url = URL_BASE+QUEUE_MERCURY_ORDER_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjMercuery = responseData.getBody()+'';	
	
		var url = URL_BASE+QUEUE_STRATA_ORDER_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjStrata = responseData.getBody()+'';	
  
        var url = URL_BASE+QUEUE_DIGITAL_PROJECT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDigitalPro = responseData.getBody()+'';	
		
		var url = URL_BASE+QUEUE_DOMEDIAS_PROJECT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDomidiaPro = responseData.getBody()+'';	
          
        //Do Media Project Single
		var url = URL_BASE+QUEUE_DOMEDIAS_PROJECT_SINGLE_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjDoMediaProjectSingle = responseData.getBody()+'';	
		
		var url = URL_BASE+QUEUE_STRATA_PROJECT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjStrataPro = responseData.getBody()+'';	
		
		var url = URL_BASE+QUEUE_MERCURY_PROJECT_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjMercuryPro = responseData.getBody()+'';
		
		
		var url = URL_BASE+QUEUE_CONNEX_ORDER_INBOUND+'/messages/head?api-version=2015-01';
		var responseData=nlapiRequestURL(url, null, HEADERS,'GET');
		var mainObjvendorbills = responseData.getBody()+'';
		
  if(mainObjContact!=null && mainObjContact!='')
nlapiScheduleScript(SCRIPT_CONNEX_CONTACT,null);

if(mainObjAgencey!=null && mainObjAgencey!='')
nlapiScheduleScript(SCRIPT_CONNEX_AGENCY,null);

if(mainObjClient!=null && mainObjClient!='')
nlapiScheduleScript(SCRIPT_CONNEX_CLIENT,null);

if(mainObjvendor!=null && mainObjvendor!='')
nlapiScheduleScript(SCRIPT_CONNEX_VENDORS,null);

if(mainObjContract!=null && mainObjContract!='')
nlapiScheduleScript(SCRIPT_CONNEX_CONTRACT,null);

if(mainObjMediaSup!=null && mainObjMediaSup!='')
nlapiScheduleScript(SCRIPT_CONNEX_MEDISUPP,null);
  
  if(mainObjMercuryPro!=null && mainObjMercuryPro!='')
nlapiScheduleScript(SCRIPT_MERCURY_PROJECT,null);

if(mainObjDigitalPro!=null && mainObjDigitalPro!='')
nlapiScheduleScript(SCRIPT_DIGITAL_PROJECT,null);

if(mainObjStrataPro!=null && mainObjStrataPro!='')
nlapiScheduleScript(SCRIPT_STRATA_PROJECT,null);

if(mainObjDomidiaPro!=null && mainObjDomidiaPro!='')
nlapiScheduleScript(SCRIPT_DOMEDIAS_PROJECT,null);
          
if(mainObjDoMediaProjectSingle!=null && mainObjDoMediaProjectSingle!='')
nlapiScheduleScript(SCRIPT_DOMEDIAS_PROJECT_SINGLE,null);
  
  if(mainObjMercuery!=null && mainObjMercuery!='')
nlapiScheduleScript(SCRIPT_MERCURY_ORDERS,null);

if(mainObjDigital!=null && mainObjDigital!='')
nlapiScheduleScript(SCRIPT_DIGITAL_ORDERS,null);

if(mainObjStrata!=null && mainObjStrata!='')
nlapiScheduleScript(SCRIPT_STRATA_ORDERS,null);

if(mainObjDomidia!=null && mainObjDomidia!='')
nlapiScheduleScript(SCRIPT_DOMEDIAS_ORDERS,null);
          
if(mainObjDoMediaSingle!=null && mainObjDoMediaSingle!='')
nlapiScheduleScript(SCRIPT_DOMEDIAS_ORDERS_SINGLE,null);
  
  if(mainObjvendorbills!=null && mainObjvendorbills!='')
nlapiScheduleScript(SCRIPT_STRATA_OCR_VENDDOR_BILL,null);

response.write('Sync from Azure to NS started');
          nlapiLogExecution('DEBUG', 'Triggered From Azure On1:', new Date());
        }
}