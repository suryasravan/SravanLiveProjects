/*
* Script Name : Appf-Populate Open Accounting Period CL
* Script Type : Client
* Event Type  : FieldChange
* Description : This script populate the nearest opened accounting period on the change of date field. 
* Company     :	Appficiency Inc.
*/
var CUSTOM_RECORD_REC_INTERIM='recmachcustrecord_appf_interimheader'

var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';
var FLD_POSTING_PERIOD = 'custrecord_appf_ivb_postingperiod';

function fieldChange(type, name, linenum)
{
	if(name == FLD_CR_IV_DATE)
	{
		var date=nlapiGetFieldValue(FLD_CR_IV_DATE);
		if(date !=null && date !='')
		{
			postingperiod=postingPeriod(date);
			nlapiSetFieldValue(FLD_POSTING_PERIOD,postingperiod);
		}
	}
}

function postingPeriod(date)
{
		date=nlapiStringToDate(date);
var startDate = new Date(date.getFullYear(), date.getMonth(), 1);
var endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
var Dt1 = nlapiDateToString(startDate);
var Dt2 = nlapiDateToString(endDate);
var filters = new Array();
filters[0] = new nlobjSearchFilter('startdate', null, 'on', Dt1);
filters[1] = new nlobjSearchFilter('enddate', null, 'on', Dt2);
filters[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
filters[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
//filters[4] = new nlobjSearchFilter('closed',null,'is','F');

var columns = new Array();
columns[0] = new nlobjSearchColumn('internalid');
columns[1] = new nlobjSearchColumn('closed');
var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters, columns);
var periodId=''
if(searchAccPeriods!=null && searchAccPeriods!='')
{
var isclosedperiod = searchAccPeriods[0].getValue('closed');
if(isclosedperiod!='T')
{
periodId=searchAccPeriods[0].getValue('internalid');
}
else
{
var filters1 = new Array();
filters1[0] = new nlobjSearchFilter('startdate', null, 'onorafter', Dt1);
filters1[1] = new nlobjSearchFilter('enddate', null, 'onorafter', Dt2);
filters1[2] = new nlobjSearchFilter('isyear', null, 'is', 'F');
filters1[3] = new nlobjSearchFilter('isquarter', null, 'is', 'F');
filters1[4] = new nlobjSearchFilter('closed',null,'is','F');

var columns1 = new Array();
columns1[0] = new nlobjSearchColumn('internalid');
columns1[1] = new nlobjSearchColumn('enddate');
columns1[1].setSort();
var searchAccPeriods = nlapiSearchRecord('accountingperiod', null, filters1, columns1);
if(searchAccPeriods!=null && searchAccPeriods!='')
{
periodId=searchAccPeriods[0].getValue('internalid');
}
}
}

return periodId;
 }