/**
	 * Script Name : Appf-VVCCP Process Response File 
	 * Script Type : Scheduled
	 * 
	 * Version    Date            Author           		Remarks
	 * 1.00            			Debendra Panigrahi		The script receives the response files for AMEX & MasterCard and will update VVCCP records.
	 *
	 * Company 	 : Appficiency. 
*/
var CUSTOM_RECORD_APPF_VVCCP_EXECUTION_BATCH='customrecord_appf_vvccp_batch';

//VVCCP
var CUSTOM_RECORD_VVCCP				='customrecord_appf_vvccp_record';
var FLD_TYPE                		='custrecord_appf_vvccp_card_type';
var FLD_MINIMUM_TO_SPEND            ='custrecord_appf_vvccp_min_spend_amt';	
var FLD_MAXIMUM_TO_SPEND	        ='custrecord_appf_vvccp_max_spend_amt';	
var FLD_VVCCP_BATCH_LINK	        ='custrecord_appf_vvccp_batch_link';
var FLD_VVCCP_STATUS	            ='custrecord_appf_vvccp_status';
var FLD_VENDOR	                	='custrecord_appf_vvccp_vendor';
var FLD_RESPONSE_FILE	            ='custrecord_appf_vvccp_response_file';
var FLD_CACELLATION_RESPONSE_FILE	='custrecord_appf_vvccp_cancellation_resp';
var FLD_REMITTANCE_EMAIL	        ='custrecord_appf_vvccp_remittance_email';
var FLD_AUTHORIZATION_REQUEST_FILE	='custrecord_appf_vvccp_auth_request_file';
var FLD_CACELLATION_REQUEST_FILE	='custrecord_appf_vvccp_cancel_req_file';
var FLD_ORIGINAL_AUTHORIZATION	    ='custrecord_appf_vvccp_original_auth';
var FLD_RESPONSE_MESSAGE	        ='custrecord_appf_vvccp_response_message';
var FLD_CORPORATE_CREDIT_CARD	    ='custrecord_appf_vvccp_corp_card';
var FLD_CURRENCY       				='custrecord_appf_vvccp_currency';
var FLD_PWP_RECORD_LINKS = 'custrecord_appf_vvccp_pwp_links';

var VVCCP_CARD_TYPE_SINGLE_USE=1;
var VVCCP_CARD_TYPE_MULTI_USE=2;
var VVCCP_UPDATES_RELATED_FILES_FOLDERID =979;
var VVCCP_STATUS_PENDING_BATCH =1;
var VVCCP_STATUS_PENDING_RESPONSE=2	  
var VVCCP_STATUS_AUTHORIZED=3;	  
var VVCCP_STATUS_AUTHORIZED_CLEARED=4;	  
var VVCCP_STATUS_PENDING_CANCEL=5;	  
var VVCCP_STATUS_CANCELLED=6;	  
var VVCCP_STATUS_FAILED =7;  
var VVCCP_STATUS_CANCELLATION_ACCEPTED=8	  
var VVCCP_STATUS_CANCELLATION_REJECTED =9
var CORPORATE_CREDIT_CARD_VVCCP='custentity_appf_vvccp_corporate_cc';
var FLD_VENDOR_PAYMENT_TYPE='custentity_appf_vendorpaymenttype';
var CREDIT_CARD_TYPE_AMEX= 2;
var CREDIT_CARD_TYPE_MASTERCARD= 1;

var CUSTOM_RECORD_VIRTUAL_CREDIT_CARD='customrecord_appf_vvccp_authorized_card';
var FLD_CARD_NUMBER='custrecord_appf_vvccp_card_number';
var FLD_SECURITY_CODE='custrecord_appf_vvccp_card_code';
var FLD_EXPIRATION_DATE='custrecord_appf_vvccp_card_exp_date';
var FLD_PROVIDER='custrecord_appf_vvccp_card_provider';
var FLD_VENDOR_PAYMENT_LINK='custrecord_appf_vvccp_ven_pmt_link';
var FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD='custrecord_appf_vvccp_card_vvccp_link';
var FLD_CARD_CANCELLED='custrecord_appf_vvccp_card_cancelled';
var FLD_VOID_JOURNAL='custrecord_appf_vvccp_payment_void';
var FLD_AUTHORIZATION_DATE='custrecord_appf_vvccp_authorization_date';

var CUSTOM_RECORD_CORPORATE_CREDIT_CARDS='customrecord_appf_corp_card_table';
var FLD_CREDIT_CARD_TYPE='custrecord_appf_corp_credit_card_type';
var FLD_CROP_CREDIT_CARD_ALIAS='custrecord_appf_corp_credit_card_alias'


var CUSTOM_RECORD_VVCCP_LINKED_TRANSACTIONS='customrecord_appf_vvccp_linked_trans';
//VVCCP Linked Transactions
var FLD_VVCCP_LINK				='custrecord_appf_vvccp_backlink';
var FLD_TRANSACTION_LINK		='custrecord_appf_vvccp_linked_transaction';
var FLD_TRANSACTION_LINE_ID		='custrecord_appf_vvccp_linked_linkid';
var FLD_TRANSACTION_LINE_AMOUNT	='custrecord_appf_vvccp_linked_tran_amt';
var FLD_TRANSACTION_LINE_PWP	='custrecord_appf_vvccp_linked_trans_pwp';
var FLD_CREDIT_APPLIED			='custrecord_appf_vvccp_linked_cr_applied';
var FLD_PAYMENT_LINK			='custrecord_appf_vvccp_linked_payment';
var FLD_LINKED_TRANSACTION_TYPE	='custrecord_appf_vvccp_linked_tran_type';

var SPARAM_COMPONY_EXPIRATION_DAY='custscript_appf_company_expiration_date';
var SPARAM_VVCCP_UPDATE_SEARCH='custscript_vvccp_update_search';
var TRANSACTION_TYPE_ADD='A';
var TRANSACTION_TYPE_DELETE='D';
var TRANSACTION_TYPE_MODIFY='M';

var NOVOUS_MEDIA_LLC_SUBSIDIARY_INTERNAL_ID=2;
var NOVOUS_MEDIA_CANADA_CROP_INTERNAL_ID=7;

var STR_PAD_LEFT = 1;
var STR_PAD_RIGHT = 2;
var STR_PAD_BOTH = 3;

var USD=1;
var CAD=3;

var SPARAM_VVCCP_SEARCH_WITH_AUTHORISED_STATUS='';
var SPARAM_AMEX_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var SPARAM_MASTERCARD_ACCOUNT_FROM_COMPANY_PREFERENCE='';
var VENDOR_PAYMENT_STATUS_APPROVEED_ID=2;
var FLD_VVCCP_BACKLINK='custbody_appf_vvccp_backlink';
var SPARAM_PROCESS_AUTHORIZE_VVCCP_SCRIPT_ID='customscript_appf_process_vvcp_authorize';
var SPARAM_PROCESS_CANCELLATION_VVCCP_SCRIPT_ID='customscript_process_cancellation_vvccps';
function schedule(type)
{
	try
	{
		var context=nlapiGetContext();
		var creditCardType='';
		/*var vvccpAuthorisedSearchParam=context.getSetting('SCRIPT', SPARAM_VVCCP_SEARCH_WITH_AUTHORISED_STATUS);
		var amexAccountFromCommanyPreference=context.getSetting('SCRIPT', SPARAM_AMEX_ACCOUNT_FROM_COMPANY_PREFERENCE);
		var masterCardAccountFromCommanyPreference=context.getSetting('SCRIPT', SPARAM_MASTERCARD_ACCOUNT_FROM_COMPANY_PREFERENCE);*/
		var amexRow20AsCardNumber='';
		var masterCardRow34AsCardNumber='';
		var amexResponseAsSecurityCode='';
		var masterCardResponseAsSecurityCode='';
		var amexExpirationDateAsResponse='';
		var masterCardExpirationDateAsResponse='';
      	//var amexResponseFileId=489596;
      	var amexResponseFileId=320656;
		var arrayOfVVCCPWithAuthorisedStatus=[];
		//if(creditCardType == 'AMEX')
		//{

			var amexFile=nlapiLoadFile(amexResponseFileId);
			var amexValues=amexFile.getValue();
			//nlapiLogExecution('debug','amexValues:',amexValues);
	
			amexValues=amexValues.split('\n'); 
			nlapiLogExecution('debug','amexValues :',amexValues);
			for(var p=1;p<amexValues.length-1;p=p+2)
			{
					var q=p+1;	
					//nlapiLogExecution('debug','amexValues after spliting :',amexValues);
					var amexTransactionType=amexValues[p].substr(4,1);
					var amexStatusUpdate=amexValues[p].substr(20,1);
					var internalIdOfVVCCP=amexValues[q].substr(324,40);
					var amexErrorNumber=amexValues[p].substr(43,6);
					var amexErrorDescription=amexValues[p].substr(49,35);
					amexRow20AsCardNumber=amexValues[p].substr(21,16);
					amexResponseAsSecurityCode=amexValues[p].substr(785,4);
					amexExpirationDateAsResponse=amexValues[p].substr(37,6);
					nlapiLogExecution('debug','internalIdOfVVCCP :',internalIdOfVVCCP);
					nlapiLogExecution('debug','amexStatusUpdate :',amexStatusUpdate);
					nlapiLogExecution('debug','amexTransactionType :',amexTransactionType);
					nlapiLogExecution('debug','amexResponseAsSecurityCode :',amexResponseAsSecurityCode);
					if(amexTransactionType!=' ' && amexTransactionType!=null && amexStatusUpdate!=' ' &&  amexStatusUpdate!=null)
					{
						if(amexTransactionType == 'A' && parseInt(amexStatusUpdate) == 0)
						{
							nlapiLogExecution('debug','internalIdOfVVCCP :',internalIdOfVVCCP);
							nlapiLogExecution('debug','amexStatusUpdate :',amexStatusUpdate);
							nlapiLogExecution('debug','amexTransactionType :',amexTransactionType);
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(internalIdOfVVCCP), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [amexResponseFileId,VVCCP_STATUS_AUTHORIZED,'Success']);
							arrayOfVVCCPWithAuthorisedStatus.push(internalIdOfVVCCP);
						}
						if(amexTransactionType == 'D' && parseInt(amexStatusUpdate) == 0)
						{
							nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(internalIdOfVVCCP), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [amexResponseFileId,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);
						}
						if(parseInt(amexStatusUpdate) == 1)
						{
							if(amexErrorNumber != ' ' && amexErrorNumber != null && amexErrorNumber == '11001')
							{	
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,parseInt(internalIdOfVVCCP),[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_AUTHORIZATION_REQUEST_FILE],[(amexErrorNumber+amexErrorDescription),amexResponseFileId,VVCCP_STATUS_PENDING_BATCH,'']);
							}
							else
							{
								nlapiSubmitField(CUSTOM_RECORD_VVCCP,parseInt(internalIdOfVVCCP),[FLD_RESPONSE_MESSAGE,FLD_RESPONSE_FILE,FLD_VVCCP_STATUS],[(amexErrorNumber+amexErrorDescription),amexResponseFileId,VVCCP_STATUS_FAILED]);
							}
						}
						//creating Virtual  Credit Card
				var virtualCreditCardRecordId=createVirtualCreditCard(internalIdOfVVCCP,amexRow20AsCardNumber,amexResponseAsSecurityCode,amexExpirationDateAsResponse,CREDIT_CARD_TYPE_AMEX,true);
				nlapiLogExecution('debug','virtualCreditCardRecordId:Amex:',virtualCreditCardRecordId);
					}
				
			}
		//}  	// ending of amex response
		
		
		//if(creditCardType == 'MasterCard')
		//{
			//var masterCardResponseFileId=489599;
      		var masterCardResponseFileId=321862;
			nlapiLogExecution('debug','masterCardResponseFileId:',masterCardResponseFileId);
			var masterCardFile=nlapiLoadFile(masterCardResponseFileId);
			var masterCardValues=masterCardFile.getValue();
			masterCardValues=masterCardValues.split('\n');
			nlapiLogExecution('debug','masterCardValues:',masterCardValues);
			//nlapiLogExecution('debug','values lengthbefore spliting:',values.length);
			masterCardValues=masterCardValues.slice(0,-1);
			for(var m=1;m<masterCardValues.length;m++)
				{
					var columns=masterCardValues[m];
					nlapiLogExecution('debug','columns:',columns);
					var columnsValues=columns.split(',');
					nlapiLogExecution('debug','columnsValues:',columnsValues);
					var actionType=columnsValues[0];
					var responseCode=columnsValues[28];
					var internalIdOfVVCCP=columnsValues[18];
					masterCardRow34AsCardNumber=columnsValues[31];
					masterCardResponseAsSecurityCode=columnsValues[32];
					masterCardExpirationDateAsResponse=columnsValues[33];
					if(masterCardExpirationDateAsResponse !=null && masterCardExpirationDateAsResponse !='' && masterCardExpirationDateAsResponse !=' ')
					masterCardExpirationDateAsResponse=masterCardExpirationDateAsResponse.toString();
					nlapiLogExecution('debug','actionType:',actionType);
					nlapiLogExecution('debug','responseCode:',responseCode);
					nlapiLogExecution('debug','internalIdOfVVCCP:',internalIdOfVVCCP);
					nlapiLogExecution('debug','masterCardRow34AsCardNumber:',masterCardRow34AsCardNumber);
					nlapiLogExecution('debug','masterCardResponseAsSecurityCode:',masterCardResponseAsSecurityCode);
					nlapiLogExecution('debug','masterCardExpirationDateAsResponse:',masterCardExpirationDateAsResponse);
					if(actionType == 'CreateApprovedPurchase' && responseCode == 'Approved')
					{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(internalIdOfVVCCP), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_AUTHORIZED,'Success']);
						arrayOfVVCCPWithAuthorisedStatus.push(internalIdOfVVCCP);
					}
					if(actionType == 'CancelApprovedPurchase' && responseCode == 'Cancelled')
					{
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(internalIdOfVVCCP), [FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE], [masterCardResponseFileId,VVCCP_STATUS_CANCELLATION_ACCEPTED,'Success']);
					}
					if(responseCode != 'Approved' && responseCode != 'Cancelled')
					{
						var responseMessageEncoded=columnsValues[29];
						var vvccpFieldsArrForMasterCardType=[];
						var vvccpValuesArrForMasterCardType=[];
						if(responseMessageEncoded != '11001')
						{
							vvccpFieldsArrForMasterCardType=[FLD_RESPONSE_FILE,FLD_VVCCP_STATUS,FLD_RESPONSE_MESSAGE];
							vvccpValuesArrForMasterCardType=[masterCardResponseFileId,VVCCP_STATUS_FAILED,responseMessageEncoded];
						}
						else
						{
							vvccpFieldsArrForMasterCardType=[FLD_RESPONSE_FILE,FLD_RESPONSE_MESSAGE];
							vvccpValuesArrForMasterCardType=[masterCardResponseFileId,responseMessageEncoded];
						}
						nlapiSubmitField(CUSTOM_RECORD_VVCCP, parseInt(internalIdOfVVCCP), vvccpFieldsArrForMasterCardType, vvccpValuesArrForMasterCardType);
					}
					var virtualCreditCardRecordId=createVirtualCreditCard(internalIdOfVVCCP,masterCardRow34AsCardNumber,masterCardResponseAsSecurityCode,masterCardExpirationDateAsResponse,CREDIT_CARD_TYPE_MASTERCARD,false);
					nlapiLogExecution('debug','virtualCreditCardRecordId:Mastercard:',virtualCreditCardRecordId);
				}
		//}    // ending of master card response


		
      				//calling the schedule script Appf-Process VVCCP Authorize Records
					nlapiScheduleScript(SPARAM_PROCESS_AUTHORIZE_VVCCP_SCRIPT_ID, null);

      				//calling the schedule script Appf-Process Cancellation VVCCP Records
					//nlapiScheduleScript(SPARAM_PROCESS_CANCELLATION_VVCCP_SCRIPT_ID, null);
			}	
	catch(e)
	{
		nlapiLogExecution('debug','Error Deatils:',e.toString());
	}
}	



function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		
	function searchUnion(target, array)
	{
		return target.concat(array); // TODO: use _.union
	}
function createVirtualCreditCard(vvccpInternalId,cardNumber,securityCode,expirationDate,provider,isAmex)
{
	securityCode=securityCode.trim();
	vvccpInternalId=vvccpInternalId.trim();
	cardNumber=cardNumber.trim();
	expirationDate=expirationDate.trim();
	//Virtual Credit Card
	//Creating Custom Record Virtual Credit Card
	var virtualCreditCard=nlapiCreateRecord(CUSTOM_RECORD_VIRTUAL_CREDIT_CARD);
	virtualCreditCard.setFieldValue(FLD_VVCCP_LINK_ON_VIRTUAL_CREDIT_CARD,vvccpInternalId);
	if(cardNumber!=null && cardNumber !='' && cardNumber !=' ')
	virtualCreditCard.setFieldValue(FLD_CARD_NUMBER,cardNumber);
	
	if(securityCode !=null && securityCode !='' && securityCode !=' ')
	{
		nlapiLogExecution('debug','securityCode:',securityCode)
		virtualCreditCard.setFieldValue(FLD_SECURITY_CODE,securityCode);
	}

	virtualCreditCard.setFieldValue(FLD_AUTHORIZATION_DATE,nlapiDateToString(new Date(),'datetimetz'));
	if(expirationDate !=null && expirationDate !='' && expirationDate !=' ')
	{
		var str = expirationDate;
		var yrPart='';
		var mnPart='';
		if(isAmex)
		{
		yrPart = str.slice(2,4);
		mnPart = str.slice(4);
		}
		else
		{	
		yrPart = str.slice(0,2);
		mnPart = str.slice(2);
		}
		var currentYear = new Date().getFullYear();
		  var currentYrPart = currentYear.toString().slice(0,2);
		  var revYear = Number(currentYrPart + yrPart);
		  var revMon = Number(mnPart)-1;
		  var revLastDay =new Date(revYear,  revMon+1, 0);
		  revLastDay=nlapiDateToString(revLastDay);
			nlapiLogExecution('debug','revLastDay',revLastDay);
		virtualCreditCard.setFieldValue(FLD_EXPIRATION_DATE,revLastDay);
	}
	if(provider !=null && provider!='' && provider!=' ')
	virtualCreditCard.setFieldValue(FLD_PROVIDER,provider);
	var virtualCreditCardId=nlapiSubmitRecord(virtualCreditCard,true,true);
	
	return virtualCreditCardId;
}	