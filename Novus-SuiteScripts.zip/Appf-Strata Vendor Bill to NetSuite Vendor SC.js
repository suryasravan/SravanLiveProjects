/**
*Script Name: Appf-Strata Vendor Bill Creations Sch
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Connext Contact and pushes the Contact from those messages into netsuite and creates or updates as Contact records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_VB_RECS='customrecord_appf_strata_vb_log_in';
 var CUSTOMRECORD_FLD_VB_INTERNAL ='custrecord_appf_strata_vb_log_vendor';
 var CUSTOMRECORD_FLD_VB_MESSAGE ='custrecord_appf_strata_vb_messageid';
 var CUSTOMRECORD_FLD_VB_MESSAGES_LINK ='custrecord_appf_strata_vb_jsoncontent';
 var CUSTOMRECORD_FLD_VB_QUEUE_NAME ='custrecord_appf_strata_vb_queuename';
 var CUSTOMRECORD_FLD_VB_NS_NAME_RESP ='custrecord_appf_strata_vb_response';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_contact_jsoncontent';
 var CUSTOMRECORD_FLD_VB_NS_STATUS ='custrecord_appf_strata_vb_status';
 
 
 var CUSTOMRECORD_APPF_IN_VB_LINE_RECS='recmachcustrecord_appf_strata_vb_log_link';
 var CUSTOMRECORD_FLD_VB_LINE_MEDISUPP ='custrecord_appf_strata_vb_line_med_suppl';
 var CUSTOMRECORD_FLD_VB_LINE_IO ='custrecord_appf_strata_vb_line_io';
 var CUSTOMRECORD_FLD_VB_LINE_PO ='custrecord_appf_strata_vb_log_line_po';
 var CUSTOMRECORD_FLD_VB_LINE_PO_IDS ='custrecord_appf_strata_vb_log_line_polin';
 var CUSTOMRECORD_FLD_VB_LINES='custrecord_appf_strata_vb_log_link';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_contact_jsoncontent';
 
 var QUEUE_CONNEX_CLIENT_INBOUND = 'novus_strata_vendor_bill_test';
 var URL_BASE = 'https://novusmediallc-dev.servicebus.windows.net/';
var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
function createContactScheduled(type) 
  {	
		var context = nlapiGetContext();
    var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
              var messagesFound=true
    while (messagesFound == true) 
	{
      var usageRemaining = context.getRemainingUsage();
      var idForResponse = '';
		var connexIDResponseValue=''
		var d = new Date();
        var UTCDate= d.toISOString();
		var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var HEADERS = {"Authorization":signatures,"Date":UTCDate,"Content-Type": 'application/xml'};
		var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
		var mainObj = responseData.getBody()+'';
            nlapiLogExecution('debug','mainObj content',mainObj);  
        var Status=''
		var Status1=''
		var scriptStatus=''
         var fileData=''
        if(mainObj==null || mainObj=='')
        {
			 messagesFound=false;
			 Status='FAILED'+'(Empty Message)'
			 scriptStatus='FAILED'
			 Status1='FAILED'+'(Empty Message)'
        }
        else
        {
		   try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
					{
						connexIDResponseValue=mainObj[FLD_CONNEX_ID];
						nlapiLogExecution('debug', 'connexIDResponseValue:', connexIDResponseValue);
					}
					Status='SUCCESS'
			   } 
			catch (e) 
			{
			   Status='FAILED'+'(invalid JSON)'
			   scriptStatus='FAILED'
				Status1='FAILED'+'(invalid JSON)'
			}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var main1={}
								
		if(responseData.getCode()!='200' && responseData.getCode()!='201')
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
		   var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_VB_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_MESSAGES_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_QUEUE_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_STATUS,'FAILED')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_NAME_RESP, 'CorrelationId');
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   nlapiSubmitRecord(integrationRecord,true,true)
		   }
		   
		}    
		else
        {
			    scriptStatus='SUCCESS'
				var integrationid=mainObj['vendor']
			 var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_VB_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_MESSAGES_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_QUEUE_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_STATUS,'SUCCESS')
			if(integrationid!=null && integrationid!='')
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_INTERNAL,integrationid)
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_NAME_RESP, 'CorrelationId');
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordIDS=nlapiSubmitRecord(integrationRecord,true,true)
		    if(mainObj.hasOwnProperty('lines'))
				 {
		   if(integrationRecordIDS!=null && integrationRecordIDS!='')
		   {
			   var integrationRecord=nlapiLoadRecord(CUSTOMRECORD_APPF_IN_VB_RECS,integrationRecordIDS)
			   var lines=mainObj['lines']
			   nlapiLogExecution('debug', 'lines', JSON.stringify(lines));
			   for(var i=0;i<lines.length;i++) 
       {
		   var mainObjlines=lines[i]
		   nlapiLogExecution('debug', 'linesJSON.stringify', JSON.stringify(mainObjlines));
			   var medisupp=mainObjlines['custcol_appf_publisher']
			   var ios=mainObjlines['custcol_appf_ionum']
			   var integrationid=mainObjlines['vendor']
			   var integrationid=mainObjlines['vendor']  
			   integrationRecord.selectNewLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS)
			integrationRecord.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_MEDISUPP,medisupp)
			integrationRecord.setCurrentLineItemValue(CUSTOMRECORD_APPF_IN_VB_LINE_RECS,CUSTOMRECORD_FLD_VB_LINE_IO,ios)
			integrationRecord.commitLineItem(CUSTOMRECORD_APPF_IN_VB_LINE_RECS)
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_LINES,integrationRecordIDS)
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_STATUS,'SUCCESS')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_VB_NS_NAME_RESP, 'CorrelationId');
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
	   } 
	   nlapiSubmitRecord(integrationRecord,true,true)
			   
		   }
				 }
        }				   
		
		  		   
	}
		  }
           