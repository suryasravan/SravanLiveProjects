/**
	 * Script Name : Appf-Vendor Credit SC #3
	 * Script Type : Scheduled
	 * 
	 * Version    Date			 Author			        Remarks
	 * 1.0		  										 * Company 	 : Appficiency. 
*/

var CUSTOM_RECORD_VEND_CRED_CREATION_LOG = 'customrecord_appf_vend_crd_log';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_vend_crd_tl_pro';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_vend_crd_inv_completed';
var FLD_TOT_LINES_FAILD = 'custrecord_appf_vend_crd_lines_failed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_vend_crd_perc_processed';
var FLD_CREATED_BY = 'custrecord_appf_vend_crd_created_by';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_vend_crd_status';
var FLD_DATA_FILE = 'custrecord_appf_vend_crd_data_file';
var FLD_STATUS_FILE  = 'custrecord_appf_vend_crd_error_file';
var FLD_ERROR_LOG = 'custrecord_appf_vend_crd_error_log';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_vend_crd_client';
var FLD_CURRENCY = 'custrecord_appf_vend_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_vend_crd_link';
var FLD_CREDIT_LOG_LINK = 'custbody_appf_ven_credit_log_record';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_vend_crd_invoice_link';
var FLD_PO_BACKLINKING_PERCENT = 'custrecord_appf_po_backlink_percent';
var FLD_PO_BACKLINKING_STATUS = 'custrecord_appf_po_backlinking_status';
var FLD_RESULT_FILE = 'custrecord_appf_result_file';

var FLD_VB_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var STATUS_VB_CREDIT_SL_READY_FOR_PROCESSING = '3';
var FLD_VB_LOG_RECORDS = 'custbody_appf_ven_credit_log_record';
var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';
var FLD_COL_VB_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var FLD_COL_VB_ = 'custcol_appf_pwp_custom_record';
var FLD_COL_PWP_CUSTOM_RECORDS='custcol_appf_pwp_custom_record';
var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_VEND_CREDIT_PROJECT_HEADER = 'custbody_appf_project_header';

var STATUS_CR_COMPLETED_SUCCESSFULLY = '4';
var STATUS_CR_COMPLETED_WITH_ERRORS = '5';
var STATUS_CR_INPROGRESS = '2';

var SPARAM_BACKLINKING_DATA = 'custscript_appf_po_back_linking_data';
var SPARAM_VC_LOG_EXEC_ID = 'custscript_appf_vend_cred_log_rec_id';
var SPARAM_PO_IDS_BACKLINKED = 'custscript_appf_po_ids_back_linked';

function backliningPOsSC(type){
	
	var context = nlapiGetContext();
	var purchaseOrders = context.getSetting('SCRIPT', SPARAM_BACKLINKING_DATA);
	var customRecId = context.getSetting('SCRIPT', SPARAM_VC_LOG_EXEC_ID);
	
	var processedPOs = [];
	var poIdsBackLinked = context.getSetting('SCRIPT', SPARAM_PO_IDS_BACKLINKED);
	if(poIdsBackLinked != null && poIdsBackLinked != ''){
		poIdsBackLinked = poIdsBackLinked.split(',');
		processedPOs = processedPOs.concat(poIdsBackLinked);
	}
	if(purchaseOrders != null && purchaseOrders != '' && customRecId != null && customRecId != ''){
		purchaseOrders = JSON.parse(purchaseOrders);
		
		var totalPOs = 0;
		var totalPOsBacklinked = 0;
		for(var prop in purchaseOrders){
			totalPOs++;
		}
		for(var prop in purchaseOrders){
			try{
				if(processedPOs.indexOf(prop) == -1){
				
					var poRec = nlapiLoadRecord('purchaseorder', prop);
					var logRecords = poRec.getFieldValues(FLD_CREDIT_LOG_LINK);
					var newLogRecords = [];
					if(logRecords != null && logRecords != '')
						newLogRecords = newLogRecords.concat(logRecords);
					newLogRecords.push(customRecId);
					poRec.setFieldValue(FLD_VB_CREDIT_SL_STATUS, STATUS_VB_CREDIT_SL_READY_FOR_PROCESSING);
					poRec.setFieldValues(FLD_CREDIT_LOG_LINK, newLogRecords);
					var vbLineIds = purchaseOrders[prop];
					if(vbLineIds != null && vbLineIds != ''){
						for(var v=0; v<vbLineIds.length; v++){
							var lineNum = poRec.findLineItemValue('item', FLD_COL_PO_LINE_ID, vbLineIds[v]);
							if(lineNum != -1)
							poRec.setLineItemValue('item', FLD_COL_VB_CREDIT_PROCESSING, lineNum, 'F');
						}
					}
					var vbSubmitted = nlapiSubmitRecord(poRec, true, true);
					if(vbSubmitted != null && vbSubmitted != ''){
						nlapiLogExecution('debug', 'vbSubmitted', vbSubmitted);
						processedPOs.push(vbSubmitted);
					}
				}
					
				}catch(e1){
						if ( e1 instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'system error e1', e1.getCode() + '\n' + e1.getDetails() )
						else
							nlapiLogExecution( 'DEBUG', 'unexpected error e1', e1.toString() )
				}
				totalPOsBacklinked++;
				
				var backlinkedPercent = parseFloat(totalPOsBacklinked)/parseFloat(totalPOs);
				if(backlinkedPercent != null && backlinkedPercent != ''){
					backlinkedPercent = parseFloat(backlinkedPercent)*100;
					if(parseFloat(backlinkedPercent) == 100)
						STATUS_CR_INPROGRESS = STATUS_CR_COMPLETED_SUCCESSFULLY;
				
				}
				try{	
					nlapiSubmitField(CUSTOM_RECORD_VEND_CRED_CREATION_LOG, customRecId, [FLD_PO_BACKLINKING_PERCENT, FLD_PO_BACKLINKING_STATUS], [parseFloat(backlinkedPercent), STATUS_CR_INPROGRESS]);
				}catch(e){
						if ( e instanceof nlobjError )
							nlapiLogExecution( 'DEBUG', 'system error e', e.getCode() + '\n' + e.getDetails() )
						else
							nlapiLogExecution( 'DEBUG', 'unexpected error e', e.toString() )
				}
				if(context.getRemainingUsage() < 1000) { 
					setRecoveryPoint(); 
					checkGovernance();
					}
				
			}
			
		
			
		
	}
}



function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint(); 
    
    if(state.status == 'SUCCESS')
        return;  
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {  
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);        
    }
}

function checkGovernance() {
    var context = nlapiGetContext();
    
    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}