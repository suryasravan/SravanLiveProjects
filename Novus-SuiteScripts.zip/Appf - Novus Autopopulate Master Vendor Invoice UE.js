/**
 * Module Description
 *
 * Version    Date            Author           Remarks
 * 1.00       02 Sep 2020     zark          From Vendor Record, Autopopulate the following Novus Master Invoice Record fields:
 *                                          currency, account, terms, due date, vendor payment type
 *
 */

{
    var FLD_MVI_CURRENCY = 'custrecord_appf_ivb_currency';
    var FLD_MVI_ACCOUNT = 'custrecord_appf_ivb_account';
    var FLD_MVI_TERMS = 'custrecord_appf_ivb_terms';
    var FLD_MVI_DUEDATE = 'custrecord_appf_ivb_due_date';
    var FLD_MVI_VENDORPAYMENTTYPE = 'custrecord_appf_ivb_payment_type';
    var FLD_MVI_DATE = 'custrecord_appf_ivb_date';
    var FLD_MVI_VENDOR = 'custrecord_appf_ivb_vendor';
    var FLD_MVI_ALTVENDOR = 'custrecord_appp_ivb_alternatevendor';

    var FLD_VENDOR_CURRENCY = 'currency';
    var FLD_VENDOR_ACCOUNT = 'accountnumber';
    var FLD_VENDOR_TERMS = 'terms';
    var FLD_VENDOR_VENDORPAYMENTTYPE = 'custentity_appf_vendorpaymenttype';
}

function beforeSubmit_AutopopulateMasterVendorInv(type) {
    if (type == 'create' || type == 'edit') {
        var vendor = nlapiGetFieldValue(FLD_MVI_ALTVENDOR) || nlapiGetFieldValue(FLD_MVI_VENDOR);
      if (vendor)
      {
        var vendor_info = nlapiLookupField('vendor', vendor,
            [FLD_VENDOR_CURRENCY, FLD_VENDOR_ACCOUNT, FLD_VENDOR_TERMS, FLD_VENDOR_VENDORPAYMENTTYPE]);

        nlapiLogExecution('DEBUG', 'Vendor Info', JSON.stringify(vendor_info));

        if (vendor_info) {
            nlapiSetFieldValue(FLD_MVI_CURRENCY, vendor_info[FLD_VENDOR_CURRENCY]);
            nlapiSetFieldValue(FLD_MVI_ACCOUNT, vendor_info[FLD_VENDOR_ACCOUNT]);
            nlapiSetFieldValue(FLD_MVI_TERMS, vendor_info[FLD_VENDOR_TERMS]);
            //nlapiSetFieldValue(FLD_MVI_VENDORPAYMENTTYPE, vendor_info[FLD_VENDOR_VENDORPAYMENTTYPE]);

            var terms = vendor_info[FLD_VENDOR_TERMS];
            var startdate = nlapiGetFieldValue(FLD_MVI_DATE);
            if (terms && startdate) {
                var termdays = nlapiLookupField('term', terms, 'daysuntilnetdue');
                if (termdays) {
                    var dueDate = nlapiAddDays(nlapiStringToDate(startdate), Number(termdays));
                    dueDate = nlapiDateToString(dueDate);
                    nlapiSetFieldValue(FLD_MVI_DUEDATE, dueDate);
                }
            }
            else {
                nlapiSetFieldValue(FLD_MVI_DUEDATE, '');
            }
        }
    }
    }
}
