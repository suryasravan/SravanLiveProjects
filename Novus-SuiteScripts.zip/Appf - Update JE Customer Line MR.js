/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 * 
 * Appficiency Copyright 2021
 * 
 * Description: Update Customer column in JE.
 * 
 * Author: Roach
 * Date: June 24, 2021
 */
 define(['N/sftp','N/runtime','N/record','N/search','N/format'],

 function(sftp,runtime,record,search,format) {
   var SPARAM_SAVED_SEARCH = 'custscript_appf_je_update_customer_ss';
 
     /**
      * Evaluate id value is null
      * @param stValue
      */
     function isEmpty(stValue) {
         return (
           stValue === '' ||
             stValue === '[]' ||
             stValue === 'undefined' ||
             stValue == null ||
             stValue == undefined ||
            (stValue.constructor === Array && stValue.length == 0) ||
            (stValue.constructor === Object &&
            (function(v) {
                for (var k in v) return false;
                    return true;
             })(stValue))
         );
     }
 
   
   function searchRecords(searchID)
   {
     if(searchID != null){
       var searchObj = search.load({
         id: searchID
       });
       var resultSet = searchObj.run();
       var results = [];
       var start = 0;
       var end = 1000;
       do{
         var result = resultSet.getRange(start,end);
         results = results.concat(result);
         start += 1000;
         end += 1000;
         
       }while(result.length == 1000);
       
       return results;
     }
     return null;
     
 
   }
     /**
      * Marks the beginning of the Map/Reduce process and generates input data.
      *
      * @typedef {Object} ObjectRef
      * @property {number} id - Internal ID of the record instance
      * @property {string} type - Record type id
      *
      * @return {Array|Object|Search|RecordRef} inputSummary
      * @since 2015.1
      */
     function getInputData() {
       var idSavedSearch = runtime.getCurrentScript().getParameter({name: SPARAM_SAVED_SEARCH});
 
       try{
           //Code to load the saved search
           if(idSavedSearch){
             var oGroupedData = new Object();
               var searchResult = searchRecords(idSavedSearch);     	
               //loop
                 for (var s = 0; s < searchResult.length; s++) {
                   var idTran = searchResult[s].id;
                   var col = searchResult[s].columns;
                   var idJE = searchResult[s].getValue(col[0]);
                   var sClientName = searchResult[s].getText(col[1]);
                   var nLine = searchResult[s].getValue(col[5]);
                   var idProject = searchResult[s].getValue(col[7]);
                   var idClient = searchResult[s].getValue(col[8]);
                   var sClient = searchResult[s].getText(col[8]);
                   var idProjClient = searchResult[s].getValue(col[9]);
                   var sClientProjCompanyName = searchResult[s].getValue(col[10]);
                   var sClientNamePrint = '';
                   var idClientNamePrint = null;
                   if(!isEmpty(idProject)){
                     sClientNamePrint = sClient;//sClient;
                     idClientNamePrint = idClient;
                   }else{
                     sClientNamePrint = sClientProjCompanyName;//sClientName;
                     idClientNamePrint = idProjClient;
                   }
 
                    var oCols = new Object();
                    oCols['idJE'] = idJE;
                    oCols['nLine'] = nLine;
                    oCols['sClientNamePrint'] = sClientNamePrint;
                    oCols['idClientNamePrint'] = idClientNamePrint;
                    
                    var aDataDetails = oGroupedData[idJE] || new Array();
                   aDataDetails.push(oCols);
                   oGroupedData[idJE] = aDataDetails;
                 }
                 
           }
 
           //send contents
           return oGroupedData;
           
         
       }catch(e){
         log.error('debug', e.message);
       }
 
       
 
     }
 
     /**
      * Executes when the map entry point is triggered and applies to each key/value pair.
      *
      * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
      * @since 2015.1
      */
     function reduce(context){
         //function map(context){
           log.debug('rowJson reduce raw', context);
           var rowJson = JSON.parse(context.values[0]); //JSON.parse(context.values[0]);
           //var rowJson = context.values[0];
           var aData = rowJson;
           log.debug('reduce stage: aData', aData + ' key = ' + context.key );
           log.debug('reduce stage: aData length='+aData.length + ' start = '+ new Date());
           var recJE;
           try{
             recJE = record.load({type: record.Type.JOURNAL_ENTRY,id: aData[0].idJE,isDynamic: false});
           }catch(e){
             recJE = record.load({type: record.Type.STATISTICAL_JOURNAL_ENTRY, id: aData[0].idJE, isDynamic: false});
           }
 
           log.debug("recJE", recJE);
 
         var getLineCount = recJE.getLineCount({sublistId: 'line'});
           log.debug('reduce stage: getLineCount', getLineCount);
 
           for(var k = 0; k < aData.length; k++){
             log.debug('aData', JSON.stringify(aData[k]));
             var getLineId = aData[k].nLine;
           getLineId =  getLineId.replace(/\s+/g,'');
 
           var i = recJE.findSublistLineWithValue({
               sublistId: 'line',
               fieldId: 'line',
               value: getLineId
           });
           log.debug('i', i);
 
           if(i >= 0){
             recJE.setSublistValue({sublistId: 'line',fieldId: 'custcol_novus_customer_name',line: i,value: aData[k].sClientNamePrint});
             recJE.setSublistValue({sublistId: 'line',fieldId: 'custcol_novus_customer_internal_id',line: i,value: aData[k].idClientNamePrint});
             log.debug('commit line', 'commit line : ' + getLineId);
           }
               }
 
         try{
           recJE.save();
           log.debug('reduce stage: successfully saved JE : ' + aData[0].idJE);
         }catch(e){
           log.error('Error', e.message);
 
         }
 
         }
 
     /**
          * Executes when the summarize entry point is triggered and applies to the result set.
          *
          * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
          * @since 2015.1
          */
      function summarize(summary) {
             var inputSummary = summary.inputSummary;
             if (inputSummary.error) {
                 log.error("Input Errors", inputSummary.error);
             }
 
             var reduceSummary = summary.reduceSummary;
             handleErrorInStage("Reduce", reduceSummary);
         }
     
     function handleErrorInStage(stage, summary) {
             summary.errors.iterator().each(function (key, value) {
                 var msg = 'Failure to process key: ' + key + '. Error was: ' + JSON.parse(value).message + '\n';
                 log.error(stage + " Errors", msg);
                 return true;
             });
         }
 
     return {
         getInputData: getInputData,
         reduce: reduce,
     summarize: summarize
     };
     
 });