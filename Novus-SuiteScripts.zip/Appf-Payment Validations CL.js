/*
*Script Name: Appf-Payment Validations CL
*Script Type: Client
*Company 	: Appficiency.
* Version    Date            Author           Remarks
* 1.0       17 Mar 2020     Manikanta		This script restricts the users who are not administartors to accress apply tab on Payment record  
*/

var ADMIN_ROLE = '3';

function fldchangepym(type, name)
{
  if ((type == 'apply' || type == 'credit') && name == 'apply')
    {
      var currentRole = nlapiGetRole();
	if(currentRole != ADMIN_ROLE){
      nlapiDisableLineItemField(type,'apply',true);
      nlapiSetCurrentLineItemValue(type, name, 'F', false, false);
           // nlapiDisableLineItemField('credit','apply',true);
    }
    }
  
}

function paymentBtnDisable(type){
	if(type == 'create' || type == 'edit'){
	var currentRole = nlapiGetRole();
	if(currentRole != ADMIN_ROLE){
      if(document.getElementById('tbl_markall') != null && document.getElementById('tbl_markall') != '')
		document.getElementById('tbl_markall').style.display = "none";
      if(document.getElementById('tbl_unmarkall') != null && document.getElementById('tbl_unmarkall') != '')
		document.getElementById('tbl_unmarkall').style.display = "none";
      if(document.getElementById('markall') != null && document.getElementById('markall') != '')
		document.getElementById('markall').style.display = "none";
      if(document.getElementById('unmarkall') != null && document.getElementById('unmarkall') != '')
		document.getElementById('unmarkall').style.display = "none";
      if(document.getElementById('payall') != null && document.getElementById('payall') != '')
		document.getElementById('payall').style.display = "none";
      if(document.getElementById('autoapply') != null && document.getElementById('autoapply') != '')
      document.getElementById('autoapply').style.display = "none";
      if(document.getElementById('clear') != null && document.getElementById('clear') != '')
      document.getElementById('clear').style.display = "none";
if(document.getElementById('clearsplitsapply') != null && document.getElementById('clearsplitsapply') != '')
      document.getElementById('clearsplitsapply').style.display = "none";
       if(document.getElementById('tbl_payall') != null && document.getElementById('tbl_payall') != '')
		document.getElementById('tbl_payall').style.display = "none";
      if(document.getElementById('tbl_autoapply') != null && document.getElementById('tbl_autoapply') != '')
      document.getElementById('tbl_autoapply').style.display = "none";
      if(document.getElementById('tbl_clear') != null && document.getElementById('tbl_clear') != '')
      document.getElementById('tbl_clear').style.display = "none";
      if(document.getElementById('tbl_clearsplitsapply') != null && document.getElementById('tbl_clearsplitsapply') != '')
      document.getElementById('tbl_clearsplitsapply').style.display = "none";
      //tbl_payall

		}
	}
}