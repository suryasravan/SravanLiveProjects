/**
	 * Script Name : Appf-Vendor Credit SC #2
	 * Script Type : Scheduled
	 * 
	 * Version    Date			 Author			        Remarks
	 * 1.0		  										This script creates vendor credits for every VB line item and ,makes applied amount 
	 *													as 0 and backlinks created vendor credits in appf - Vednor Credit Log Record,
	 *													Updates the CREDIT SUITELET STATUS field on the VB to ‘Ready for processing’ when  
	 *													the batch is completed,Script Unchecks the Credit Processing (Do Not Hide) checkbox 
	 *													at the line level for all the VB lines processed by the batch
	 *
	 *
	 *
	 *
	 *
	 *
	 *
	 * Version    Date            Author           		Remarks
	 * 2.00            			 Debendra Panigrahi		This script creates vendor credits for every PO line item and ,makes applied amount 
	 *													as 0 and backlinks created vendor credits in appf - Vednor Credit Log Record, 
	 *													Updates the CREDIT SUITELET STATUS field on the PO to ‘Ready for processing’ when 
	 *													the batch is completed,Script Unchecks the Credit Processing (Do Not Hide) checkbox
	 *													at the line level for all the PO lines processed by the batch.And also added dynamic
	 *													header & line level customization through script parameters.
	 *
	 * Company 	 : Appficiency. 
*/

var CUSTOM_RECORD_VEND_CRED_CREATION_LOG = 'customrecord_appf_vend_crd_log';
var FLD_TOT_CREDITS_TO_PROCESS = 'custrecord_appf_vend_crd_tl_pro';
var FLD_TOT_CREDITS_PROCESSED = 'custrecord_appf_vend_crd_inv_completed';
var FLD_TOT_LINES_FAILD = 'custrecord_appf_vend_crd_lines_failed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_vend_crd_perc_processed';
var FLD_CREATED_BY = 'custrecord_appf_vend_crd_created_by';
var FLD_CREDIT_CREATION_STATUS = 'custrecord_appf_vend_crd_status';
var FLD_DATA_FILE = 'custrecord_appf_vend_crd_data_file';
var FLD_STATUS_FILE  = 'custrecord_appf_vend_crd_error_file';
var FLD_ERROR_LOG = 'custrecord_appf_vend_crd_error_log';
var FLD_CLIENT_OR_VENDOR = 'custrecord_appf_vend_crd_client';
var FLD_CURRENCY = 'custrecord_appf_vend_crd_currency';
var FLD_CREDIT_MEMO_LINK = 'custrecord_appf_vend_crd_link';
var FLD_CREDIT_LOG_LINK = 'custbody_appf_ven_credit_log_record';
var FLD_INV_VEND_BILL_LINK = 'custrecord_appf_vend_crd_invoice_link';
var STATUS_CR_COMPLETED_SUCCESSFULLY = '4';
var STATUS_CR_COMPLETED_WITH_ERRORS = '5';

var SUBLIST_INTERIM = 'recmachcustrecord_appf_interimheader';
var FLD_INTERIM_CHILD_LINKS = 'custrecord_appf_ven_cred_vb_lines';

var SPARAM_CREDIT_CREATION_LOG_ID = 'custscript_appf_credit_creation_log_rec';
var SPARAM_INDEX = 'custscript_appf_vendor_credit_index';

var SPARAM_APPF_PRINT_FORM_HEADER_PARAMS_VCS = 'custscript_appf_print_header_params_vcs';
var SPARAM_APPF_DIGITALMEDIA_HEADER_PARAMS_VCS = 'custscript_appf_digital_header_param_vcs';
var SPARAM_APPF_DOMEDIA_HEADER_PARAMS_VCS = 'custscript_appf_domedia_header_param_vcs';
var SPARAM_APPF_STRATA_HEADER_PARAMS_VCS = 'custscript_appf_strata_header_params_vcs';
var SPARAM_APPF_NONMEDIA_HEADER_PARAMS_VCS = 'custscript_appf_nonmedi_header_param_vcs';

var SPARAM_APPF_PRINT_FORM_LINE_PARAMS_VCS = 'custscript_appf_print_line_params_vcs';
var SPARAM_APPF_DIGITALMEDIA_LINE_PARAMS_VCS = 'custscript_appf_digital_line_params_vcs';
var SPARAM_APPF_DOMEDIA_LINE_PARAMS_VCS = 'custscript_appf_domedia_line_params_vcs';
var SPARAM_APPF_STRATA_LINE_PARAMS_VCS = 'custscript_appf_spot_line_params_vcs';
var SPARAM_APPF_NONMEDIA_LINE_PARAMS_VCS = 'custscript_appf_nonmedia_line_params_vcs';

var SPARAM_IMMEDIATE_EXECUTION = 'custscript_created_from_ext_scripts';

var CUSTOM_RECORD_INTERIM='customrecord_appf_interim_vb'
var CUSTOM_RECORD_INTERIM_CHILD='customrecord_appf_interim_vb_line'
var FLD_CR_PO_LINE_NOS= 'custrecord_appf_ivbl_po_line_id';
var FLD_CR_NET_AMTS= 'custrecord_appf_ivbl_vendor_net';
var FLD_CR_PO_INTERNALID= 'custrecord_appf_ivbl_po_link';
var FLD_CR_INV_TRNS= 'custrecord_appf_ivb_transid';
var FLD_CR_IV_ON_BASED_ID= 'custrecord_appf_ivb_onbasedocid';
var FLD_CR_IV_DATE ='custrecord_appf_ivb_date';
var FLD_CR_IV_DESCRIPTIONS= 'custrecord_appf_ivbl_description';
var FLD_CR_IV_IO_NUM= 'custrecord_appf_ivbl_io_num';
var FLD_CR_IV_CIRCULATIONS= 'custrecord_appf_ivbl_circulation';
var FLD_CR_IV_UNITS='custrecord_appf_ivbl_novus_unit_rt'
var FLD_CR_IV_VENDOR_NUM='custrecord_appf_ivb_vendoraccnum'
var FLD_CR_IV_TRANS='custrecord_appf_transactions_created';
var FLD_TRANSACTIOMN_FAILURE = 'custrecord_appf_transaction_failure';

var FLD_COL_PRINT_CIRCULATION='custcol_appf_print_circulation'
var FLD_COL_RATE='custcol_appf_novusunitrate'
var FLD_COL_MASTER='custcol_appf_masterlink'
var FLD_COL_LINKS='custcol_appf_childlink'
var FLD_COL_IO='custcol_appf_ionum'
var FLD_COL_PUBLISH='custcol_appf_publisher'
var FLD_COL_LINE_IDS='custcol_appf_line_id'
var FLD_COL_PP_RECS='custcol_appf_pwp_custom_record'
var FLD_COL_PO_LINES='custcol_appf_po_line_id'

var FLD_VB_CREDIT_SL_STATUS = 'custbody_appf_credit_suitelet_status';
var STATUS_VB_CREDIT_SL_READY_FOR_PROCESSING = '3';
var FLD_VB_LOG_RECORDS = 'custbody_appf_ven_credit_log_record';
var FLD_COL_PO_LINE_ID = 'custcol_appf_po_line_id';
var FLD_COL_VB_CREDIT_PROCESSING = 'custcol_appf_credit_suitelet';
var FLD_COL_VB_ = 'custcol_appf_pwp_custom_record';
var FLD_COL_PWP_CUSTOM_RECORDS='custcol_appf_pwp_custom_record';
var FLD_SO_LINE_ID='custcol_appf_line_id';
var FLD_VEND_CREDIT_PROJECT_HEADER = 'custbody_appf_project_header';
 var SPARAM_VC_FIELDS = 'custscript_vc_header_fields_sync';

function vbCreditScheduled(type){

	var context = nlapiGetContext();
		   var scriptParamVCHeaderFields = context.getSetting('SCRIPT', SPARAM_VC_FIELDS)

	var customRecId = context.getSetting('SCRIPT', SPARAM_CREDIT_CREATION_LOG_ID);
	var index = context.getSetting('SCRIPT', SPARAM_INDEX);
	if(index == null || index == '')
		index = 1;
	if(customRecId != null && customRecId != ''){
		var vclRec = nlapiLoadRecord(CUSTOM_RECORD_VEND_CRED_CREATION_LOG, customRecId);
		var file = vclRec.getFieldValue(FLD_DATA_FILE);
		var totalCreditsToProcess = vclRec.getFieldValue(FLD_TOT_CREDITS_TO_PROCESS);
		var errorLog = '';
		
		if(file != null && file != ''){
			var fileContents = nlapiLoadFile(file).getValue();
			if(fileContents != null && fileContents != ''){
				fileContents = fileContents.split('\n');
				var totalLinesProcessed = 0;
				var totalLinesFaild = 0;
				var totalVendCredits = [];
				var interimChildRecordIDList = [];
				var vendorBills = {};
				
				var purchaseOrderForm='';
				var vendorCrediForm='';
				var headerFieldsFromParam='';
				var lineFieldsFromParam='';
				
				for(var f=index; f<(fileContents.length-1); f++){
					
					var data = fileContents[f].split(',');
					var poId = data[0];
					var interimHeaderID = data[1];
					if(!vendorBills.hasOwnProperty(poId)){
						vendorBills[poId] = [];
					}
					var creditAmt = data[data.length-2];
					var lineId = data[data.length-1];
					vendorBills[poId].push(lineId)
					var proj = data[data.length-3];
					var ppId = data[data.length-4];
					var io = data[data.length-5];
					var poCurrency = data[data.length-6];
					var vendCreditId = null;
					
					
					var poRec = nlapiLoadRecord('purchaseorder', poId);
										 						var poTranID = poRec.getFieldValue('tranid');
 
					  
					if (interimHeaderID == null || interimHeaderID == '')
					{
					try{
					purchaseOrderForm=poRec.getFieldValue('customform')
                    var povendor=poRec.getFieldValue('entity')
					 var potrandate=poRec.getFieldValue('trandate');
					 var lineNum = poRec.findLineItemValue('item', FLD_COL_PO_LINE_ID, lineId);
					

					if(purchaseOrderForm == 124)
					{	
						vendorCrediForm = 180;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_PRINT_FORM_HEADER_PARAMS_VCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_PRINT_FORM_LINE_PARAMS_VCS);
					}
					if(purchaseOrderForm == 147)
					{	
						vendorCrediForm = 179;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DIGITALMEDIA_HEADER_PARAMS_VCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DIGITALMEDIA_LINE_PARAMS_VCS);
						
					}
					if(purchaseOrderForm == 148)
					{
						vendorCrediForm = 181;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DOMEDIA_HEADER_PARAMS_VCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_DOMEDIA_LINE_PARAMS_VCS);
					}
					if(purchaseOrderForm == 150)
					{
						vendorCrediForm = 182;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_STRATA_HEADER_PARAMS_VCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_STRATA_LINE_PARAMS_VCS);
					}
					if(purchaseOrderForm == 157)
					{
						vendorCrediForm = 161;
						headerFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_NONMEDIA_HEADER_PARAMS_VCS);
						lineFieldsFromParam=context.getSetting('SCRIPT', SPARAM_APPF_NONMEDIA_LINE_PARAMS_VCS);
					}
					var vendCred = nlapiCreateRecord('vendorcredit');
					if(vendorCrediForm != '' && vendorCrediForm !=null)
					vendCred.setFieldValue('customform', vendorCrediForm);
					vendCred.setFieldValue('entity', povendor);
										vendCred.setFieldValue(FLD_VEND_CREDIT_PROJECT_HEADER, proj);
					
					if(headerFieldsFromParam !='' && headerFieldsFromParam !=null)
					{
						headerFieldsFromParam =headerFieldsFromParam.split(',');
						for(h=0;h<headerFieldsFromParam.length;h++)
						{
							var headerFieldFromPoToVendorCredit=poRec.getFieldValue(headerFieldsFromParam[h]);
							vendCred.setFieldValue(headerFieldsFromParam[h],headerFieldFromPoToVendorCredit);
						}
					}
					//vendCred.setFieldValue('trandate', potrandate);
					//vendCred.setFieldValue('postingperiod', povendor);
					if(lineNum != -1)
					{
						 var poLineId = poRec.getLineItemValue('item', FLD_COL_PO_LINE_ID, lineNum);
						  var porate = poRec.getLineItemValue('item', 'rate', lineNum);
						   var pCusId = poRec.getLineItemValue('item', FLD_COL_PWP_CUSTOM_RECORDS, lineNum);
						    var soLineId = poRec.getLineItemValue('item', FLD_SO_LINE_ID, lineNum);
							  var poLineItem= poRec.getLineItemValue('item', 'item', lineNum);
							  var poProject =  poRec.getLineItemValue('item', 'customer', lineNum);
						 
							vendCred.selectNewLineItem('item');
							vendCred.setCurrentLineItemValue('item', 'item', poLineItem);
							vendCred.setCurrentLineItemValue('item', FLD_COL_PO_LINE_ID, poLineId);
							vendCred.setCurrentLineItemValue('item', FLD_SO_LINE_ID, soLineId);
							vendCred.setCurrentLineItemValue('item', 'rate', 1);
							vendCred.setCurrentLineItemValue('item', FLD_COL_PWP_CUSTOM_RECORDS, pCusId);
							vendCred.setCurrentLineItemValue('item', 'quantity', creditAmt);
							//vendCred.setCurrentLineItemValue('item', 'customer', poProject);
							
							if(lineFieldsFromParam !='' && lineFieldsFromParam != null)
							{
								lineFieldsFromParam=lineFieldsFromParam.split(',');
								for(l=0; l<lineFieldsFromParam.length; l++)
								{
									var poLineLevelFieldToVendorCredit=poRec.getLineItemValue('item',lineFieldsFromParam[l],lineNum);
									vendCred.setCurrentLineItemValue('item',lineFieldsFromParam[l],poLineLevelFieldToVendorCredit);
								}
							}
							vendCred.commitLineItem('item');
					}
					vendCreditId = nlapiSubmitRecord(vendCred, true, true);
					}catch(e1){
						totalLinesFaild++;
						if ( e1 instanceof nlobjError )
		errorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.getDetails() + '\n';
		else
		errorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.toString() + '\n';
					}
					}
					
					else
					{
						try{
						creditAmt = Math.round(creditAmt*100)/100;
					var interimHeadeRecord = nlapiLoadRecord(CUSTOM_RECORD_INTERIM, interimHeaderID);
					
					 var transids=interimHeadeRecord.getFieldValue(FLD_CR_INV_TRNS)
  var invOnbase=interimHeadeRecord.getFieldValue(FLD_CR_IV_ON_BASED_ID)
  var invdate=interimHeadeRecord.getFieldValue('custrecord_appf_ivb_date')
    	var poNo=interimHeadeRecord.getFieldValue(FLD_CR_IV_VENDOR_NUM)

  var nsOrderCounts=interimHeadeRecord.getLineItemCount(SUBLIST_INTERIM);
  nsOrderCounts = parseInt(nsOrderCounts) + 1;
	var revisedTranNum =transids+ '-'+nsOrderCounts;

					var vendorfromInterim = interimHeadeRecord.getFieldValue('custrecord_appf_ivb_vendor');
					var altVendorFromInterim = interimHeadeRecord.getFieldValue('custrecord_appp_ivb_alternatevendor');
					if (altVendorFromInterim == null || altVendorFromInterim == '')
						altVendorFromInterim = vendorfromInterim;
					
						
					                                 var interimChildRecord=nlapiCreateRecord(CUSTOM_RECORD_INTERIM_CHILD);
													 
													 interimChildRecord.setFieldValue('custrecord_appf_ivbl_vendor_name',altVendorFromInterim);
						                                interimChildRecord.setFieldValue('custrecord_appf_interimheader',interimHeaderID);
							                            interimChildRecord.setFieldValue('custrecord_appf_ivbl_vendor_net', parseFloat(creditAmt) * -1);
                                                       			interimChildRecord.setFieldValue('custrecord_appf_ivbl_po_link', poId);
														interimChildRecord.setFieldValue('custrecord_appf_ivbl_po_line_id', lineId);
														interimChildRecord.setFieldValue('custrecord_appf_ivbl_io_num', io);
														interimChildRecord.setFieldValue('custrecord_appf_ivbl_pwplink', ppId);
														interimChildRecord.setFieldText('custrecord_appf_ivbl_pocurrency', poCurrency);
														var interimChildRecordID=nlapiSubmitRecord(interimChildRecord,true,true);
														interimChildRecordIDList.push(interimChildRecordID);
					nlapiLogExecution('debug', 'interimChildRecordID', interimChildRecordID);
					
					
		
		
		
	    var poCount=poRec.getLineItemCount('item')
		var vcCreate=nlapiCreateRecord('vendorcredit');
	  
		    vcCreate.setFieldValue('entity',altVendorFromInterim)
	
	vcCreate.setFieldValue('tranid',revisedTranNum)
	        vcCreate.setFieldValue('custbody_appf_onbase_docid',invOnbase)
	        vcCreate.setFieldValue('trandate',invdate)
	        vcCreate.setFieldValue('custbody_appf_accnum_ocr', poNo);
			
			                                         var poLineNum=poRec.findLineItemValue('item','custcol_appf_po_line_id',lineId)
						                               var poItem=poRec.getLineItemValue('item','item',poLineNum)
													   var poStrat=poRec.getLineItemValue('item','custcolappf_so_line_startdate',poLineNum)
													   var poendDat=poRec.getLineItemValue('item','custcol_appf_so_line_enddate',poLineNum)
													   var poPublishs=poRec.getLineItemValue('item',FLD_COL_PUBLISH,poLineNum)
													   var soLineIds=poRec.getLineItemValue('item',FLD_COL_LINE_IDS,poLineNum)
													   var ppLineIds=poRec.getLineItemValue('item',FLD_COL_PP_RECS,poLineNum)
													   var poLineIds=poRec.getLineItemValue('item',FLD_COL_PO_LINES,poLineNum)
													   var pocust = poRec.getLineItemValue('item','customer',poLineNum)
			                                            vcCreate.selectNewLineItem('item');
														vcCreate.setCurrentLineItemValue('item', 'item', poItem);
							                            vcCreate.setCurrentLineItemValue('item', 'quantity', creditAmt);
                                                        vcCreate.setCurrentLineItemValue('item', 'rate', 1);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_IO, io);
														//vcCreate.setCurrentLineItemValue('item', 'description', podescription);
														//vcCreate.setCurrentLineItemValue('item', FLD_COL_PRINT_CIRCULATION, poCurculatns);
														//vcCreate.setCurrentLineItemValue('item', FLD_COL_RATE, poUnit);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_PUBLISH, poPublishs);
														vcCreate.setCurrentLineItemValue('item', 'custcolappf_so_line_startdate', poStrat);
														vcCreate.setCurrentLineItemValue('item', 'custcol_appf_so_line_enddate', poendDat);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_LINE_IDS, soLineIds);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_PP_RECS, ppLineIds);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_PO_LINES, poLineIds);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_MASTER, interimHeaderID);
														vcCreate.setCurrentLineItemValue('item', FLD_COL_LINKS, interimChildRecordID);
														if (pocust != null && pocust != '')
														vcCreate.setCurrentLineItemValue('item', 'customer', pocust);

														

                                                        vcCreate.commitLineItem('item');
					                                    



if(scriptParamVCHeaderFields!=null && scriptParamVCHeaderFields!='')
{
var vcHeaderFieldList = scriptParamVCHeaderFields.split(',');
for (var vh = 0; vh < vcHeaderFieldList.length; vh++)
{
var interimHeaderFieldID = vcHeaderFieldList[vh].split('|')[0];
var vbHeaderFieldID = vcHeaderFieldList[vh].split('|')[1];
var interimHeaderFieldValue = interimHeadeRecord.getFieldValue(interimHeaderFieldID);
vcCreate.setFieldValue(vbHeaderFieldID, interimHeaderFieldValue);
}
}
														vendCreditId=nlapiSubmitRecord(vcCreate,true,true)
														nlapiLogExecution('debug','vendCreditId',vendCreditId)
														if(vendCreditId!=null && vendCreditId!='')
	                                                         {
	                                                           
	                                                    
																 	nlapiSubmitField(CUSTOM_RECORD_INTERIM_CHILD, interimChildRecordID, 'custrecord_appf_ivbl_vclink', vendCreditId);
	                                                             }
																 
					}
	catch(e1)
		{
									totalLinesFaild++;

			if ( e1 instanceof nlobjError )
		errorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.getDetails() + '\n';
		else
		errorLog += '---> Failed to create Vendor Credit for PO:'+poTranID+', Reason: '+e1.toString() + '\n';
		}
						
						
					}
					if (vendCreditId)
					{
					nlapiLogExecution('debug', 'vendCreditId', vendCreditId);
					totalVendCredits.push(vendCreditId);
					totalLinesProcessed++;
					}
                   
					
                  var percentProcessed = (Number(totalLinesProcessed) + Number(totalLinesFaild))/Number(totalCreditsToProcess);
				percentProcessed = Number(percentProcessed)*100;
                  
                  nlapiSubmitField(CUSTOM_RECORD_VEND_CRED_CREATION_LOG, customRecId, [FLD_CREDITS_PROCESSED_PERCENT, FLD_TOT_CREDITS_PROCESSED, FLD_TOT_LINES_FAILD, FLD_CREDIT_MEMO_LINK], [percentProcessed, totalLinesProcessed, totalLinesFaild, totalVendCredits]);
					if(context.getRemainingUsage() <= 1000 && (f+1)<(fileContents.length-1)){
						var params = {};
						params[SPARAM_CREDIT_CREATION_LOG_ID] = customRecId;
						params[SPARAM_INDEX] = (f+1);
						nlapiScheduleScript(context.getScriptId(), null, params);
						break;
					}
				}
				var vclRec = nlapiLoadRecord(CUSTOM_RECORD_VEND_CRED_CREATION_LOG, customRecId);	

if (interimChildRecordIDList.length>0)
{
				vclRec.setFieldValues(FLD_INTERIM_CHILD_LINKS, interimChildRecordIDList);

}	
				if(errorLog != null && errorLog != '')
					STATUS_CR_COMPLETED_SUCCESSFULLY = STATUS_CR_COMPLETED_WITH_ERRORS;
				vclRec.setFieldValue(FLD_CREDIT_CREATION_STATUS, STATUS_CR_COMPLETED_SUCCESSFULLY);
				vclRec.setFieldValue(FLD_ERROR_LOG, errorLog);
				
				var vclId = nlapiSubmitRecord(vclRec, true, true);
				nlapiLogExecution('debug', 'vclId', vclId);
				
				for(var prop in vendorBills){
					var vbRec = nlapiLoadRecord('purchaseorder', prop);
					var logRecords = vbRec.getFieldValues(FLD_CREDIT_LOG_LINK);
					var newLogRecords = [];
                  if(logRecords != null && logRecords != '')
					newLogRecords = newLogRecords.concat(logRecords);
					newLogRecords.push(customRecId);
					vbRec.setFieldValue(FLD_VB_CREDIT_SL_STATUS, STATUS_VB_CREDIT_SL_READY_FOR_PROCESSING);
					vbRec.setFieldValues(FLD_CREDIT_LOG_LINK, newLogRecords);
					var vbLineIds = vendorBills[prop];
					if(vbLineIds != null && vbLineIds != ''){
					for(var v=0; v<vbLineIds.length; v++){
						var lineNum = vbRec.findLineItemValue('item', FLD_COL_PO_LINE_ID, vbLineIds[v]);
						if(lineNum != -1)
						vbRec.setLineItemValue('item', FLD_COL_VB_CREDIT_PROCESSING, lineNum, 'F');
					}
				}
					var vbSubmitted = nlapiSubmitRecord(vbRec, true, true);
					nlapiLogExecution('debug', 'vbSubmitted', vbSubmitted);
				}
			}
		}
		
				 
		   
			 }
		
	
	}
	
	