/*
* Script Name : Appf - NS Client To Buying System - UE
* Script Type : UserEvent
* Event Type  : After Submit
* Description : This script triggers on submit of Customer or Client, prepares raw JSON, makes a secured connection to Azure SB, send the json to queue and creates the custom record with linking record and response
* Company     :	Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_OUT_BOUND_CUSTOMER_RECS='customrecord_appf_buying_syst_client_out';
 var CUSTOMRECORD_FLD_APPF_OUT_JSON_CUSTOMERS ='custrecord_appf_jsonconetnt_out_customer';
 var CUSTOMRECORD_FLD_APPF_CUSTOMER_LINK='custrecord_customer_record';
 var CUSTOMRECORD_FLD_STATUS='custrecord_ststus';
 var CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_CUSTOMERS ='custrecord_appf_azureresponse_customers';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME_CUSTOMERS='custrecord_appfstrata_vendor_out_clients';
  // var  NS_OB_RESPONSE_PROPERTY='Novus.Integration.NetSuite.Interfaces.INetSuiteClient'
  var  NS_OB_RESPONSE_PROPERTY='Novus.Framework.Models.Crm.Incoming.NetSuite.ClientIncomingMessage'
  var SPARAM_SB3_URL_BASE='custscript_sb3_base_url'
var SPARAM_SB3_SIGNATURE='custscript_sb3_signature'
var SPARAM_PRODUCTION_URL_BASE='custscript_prod_base_url'
var SPARAM_PRODUCTION_SIGNATURE='custscript_prod_signature'
var SPARAM_SB1_URL_BASE='custscript_sb1_base_url'
var SPARAM_SB1_SIGNATURE='custscript_sb1_signature'
var SPARAM_SB2_URL_BASE='custscript_sb2_base_url'
var SPARAM_SB2_SIGNATURE='custscript_sb2_signature'
function customerMessage(type)
{
 if(type!='delete')
	{
      
       nlapiLogExecution('debug', 'nlapiGetContext().getExecutionContext()', nlapiGetContext().getExecutionContext());
      // && nlapiGetContext().getExecutionContext() != 'scheduled' && nlapiGetContext().getExecutionContext() !='suitelet'
var URL_BASE=''
	var signatures=''
	
	var context = nlapiGetContext();
var userAccountId = context.getCompany();
if(userAccountId=='3619984_SB3')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB3_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB3_SIGNATURE);
}
if(userAccountId=='3619984_SB2')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_SB2_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_SB2_SIGNATURE);
}
if(userAccountId=='3619984')
{
	URL_BASE = context.getSetting('SCRIPT', SPARAM_PRODUCTION_URL_BASE);
	signatures = context.getSetting('SCRIPT', SPARAM_PRODUCTION_SIGNATURE);
}
		var recordId=nlapiGetRecordId();
	    var recordType=nlapiGetRecordType();
	    //var estimateRec=nlapiLoadRecord(recordType,recordId)
       var customerRec=nlapiLoadRecord(recordType,recordId)
	     var contract=customerRec.getFieldValue('parent')
	   if(contract!=null && contract!='')
	   {
		var customerRecFields=customerRec.getAllFields()
		var queueName='netsuite_crm_client'
        
			var main1={}
		for(var i=0;i<customerRecFields.length;i++) 
       {
		     //var main={}
			var customerRecFieldId=customerRecFields[i]
			var customerRecFieldValue=customerRec.getFieldValue(customerRecFieldId)
			if(customerRecFieldValue==null)
		      customerRecFieldValue=''
		      main1[customerRecFieldId]=customerRecFieldValue
		} 
var addressbookCount=customerRec.getLineItemCount('addressbook')
var addressbookCount1=customerRec.getAllLineItemFields('addressbook')
if(addressbookCount>=1)
{
var addressbookaddr1=customerRec.getLineItemValue('addressbook','addr1',1)
                     if(addressbookaddr1==null)
		      addressbookaddr1=''
			  var addressbookaddr2=customerRec.getLineItemValue('addressbook','addr2',1)
                     if(addressbookaddr2==null)
		      addressbookaddr2=''
			  var addressbookaddr3=customerRec.getLineItemValue('addressbook','addr3',1)
                     if(addressbookaddr3==null)
		      addressbookaddr3=''
			  var addressbookZip=customerRec.getLineItemValue('addressbook','zip',1)
                     if(addressbookZip==null)
		      addressbookZip=''
   var phoneaddr=customerRec.getLineItemValue('addressbook','phone',1)
                     if(phoneaddr==null)
		      phoneaddr=''
			   var addressbookState=customerRec.getLineItemValue('addressbook','state',1)
                     if(addressbookState==null)
		      addressbookState=''
			   var addressbookCty=customerRec.getLineItemValue('addressbook','city',1)
                     if(addressbookCty==null)
		      addressbookCty=''
		    var addressbookCountry=customerRec.getLineItemValue('addressbook','country',1)
                     if(addressbookCountry==null)
		      addressbookCountry=''
		    var addressbookattention=customerRec.getLineItemValue('addressbook','attention',1)
                     if(addressbookattention==null)
		      addressbookattention=''
		    var addressbookaddressee=customerRec.getLineItemValue('addressbook','addressee',1)
                     if(addressbookaddressee==null)
		      addressbookaddressee=''
		      //addressbookInternalOb.addr1=addressbookaddr1
			    main1.addr1=addressbookaddr1
			    main1.addr2=addressbookaddr2
			    main1.addr3=addressbookaddr3
			    main1.zip=addressbookZip
    main1.phoneaddr=phoneaddr
			    main1.attention=addressbookattention
			    main1.addressee=addressbookaddressee
			    main1.state=addressbookState
			    main1.city=addressbookCty
			    main1.country=addressbookCountry
}
       //main1.addressbook=addressbookCountArry	
      if(URL_BASE!=null && URL_BASE!='')
        {
var url = URL_BASE+queueName+'/messages';
var body = JSON.stringify(main1);
var HEADERS = {"Authorization":signatures};
         HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
var response=nlapiRequestURL(url, body, HEADERS,'POST');
		var outboundFlowRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_OUT_BOUND_CUSTOMER_RECS)
		var responseData=response.getBody()
         nlapiLogExecution('debug', ' responseData.getCode()',response.getCode());
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_AZURE_RESPONSE_CUSTOMERS,responseData)
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_OUT_JSON_CUSTOMERS,JSON.stringify(main1))
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CUSTOMER_LINK,recordId)
		if(response.getCode()=='200' || response.getCode()=='201')
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_STATUS,'Success')
        else	
	    outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_STATUS,'Failed')   
		outboundFlowRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME_CUSTOMERS,queueName)
		nlapiSubmitRecord(outboundFlowRecord,true,true)
		//nlapiSendEmail(1224,'laxmikanth@cloudalp.com','test',JSON.stringify(main1),null,null,null,HEADERS)
		nlapiLogExecution('debug', ' main1',JSON.stringify(main1));
	   }
       }	
	}
	
}

