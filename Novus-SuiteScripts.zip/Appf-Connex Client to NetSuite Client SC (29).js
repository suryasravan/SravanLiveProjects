/**
*Script Name: Appf-Connex Client to NetSuite Client SC
*Script Type: Schedule Script
*Description: This script when executed checks for any new messages in the queue related to Connext Clients and pushes the clients from those messages into netsuite and creates or updates as Customer records.
This will also trigger a response integration flow (outbound) with JSON of created or updated records from netsuite to response queue
*Company 	: Appficiency Inc.
*/
 var CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS='customrecord_appf_connex_client_in';
 var CUSTOMRECORD_FLD_APPF_MESSAGE ='custrecord_appf_messageid';
 var CUSTOMRECORD_FLD_APPF_CONTENT_LINK='custrecord_appf_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_QUEU_NAME ='custrecord_appf_queuename';
 var CUSTOMRECORD_FLD_APPF_NS_RESPONSE='custrecord_appf_response';
 var CUSTOMRECORD_FLD_APPF_CLIENTS='custrecord_client_id';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS = 'custrecord_connex_status_code';
 var CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP = 'custrecord_connex_resp_status_code';
 var CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP = 'custrecord_appf_correlid';
 var CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP = 'custrecord_appf_netsuite_send_response';
 
 
 var CUSTOMRECORD_APPF_IN_BOUND_PRODCTS_RECS='customrecord_appf_domedia_products_in';
 //var CUSTOMRECORD_FLD_APPF_PRODCTS_MESSAGE ='custrecord_appf_messageid';
 var CUSTOMRECORD_FLD_APPF_PRODCTS_CONTENT_LINK='custrecord_appf_product_jsoncontent';
 var CUSTOMRECORD_FLD_APPF_PRODCTS_QUEU_NAME ='custrecord_appf_products_queuenames';
 var CUSTOMRECORD_FLD_APPF_NS_PRODCTS_RESPONSE='custrecord_appf_netsuite_produc_response';
 var CUSTOMRECORD_FLD_APPF_PRODCTS_CLIENTS='custrecord_client_product_id';
 
 // Integration Related
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee','phoneaddr'];
// Integration Related
 var QUEUE_CONNEX_CLIENT_INBOUND = 'novusmedia_ocr_mercury';
 //novusmedia_connex_client_in
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE = 'netsuite_crm_response';
 var QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE_1 = 'netsuite_crm_product';
//netsuite_crm_response
 var URL_BASE = 'https://novusmediallc-dev.servicebus.windows.net/';
 
 var addressBookFields = ['addr1','country','state','zip','city','addr2','addr3','attention','addressee','phoneaddr'];
 var FLD_CONNEX_ID='custentity_appf_connexid';
 var FLD_LAST_UPDATE_DATE_TIME = 'custentity_appf_integr_lastupdatedate';
 var NS_OB_RESPONSE_PROPERTY='Novus.Connex.Sync.NetSuite.Models.Response.ClientResponse'

var FLD_CONNEX_BUS_UNITS='custentity_appf_businessunits'
var SPARAM_CONNEX_CLIENT='customscript_appf_connex_client_2_ns_sc'
function createClientScheduled(type) 
  {	
	
		//var salesOrderId = context.getSetting('SCRIPT', SPARAM_SO_INTERNAL_ID);
		var context = nlapiGetContext();

		   var messagesFound=true
    while (messagesFound == true) 
	{
	var usageRemaining = context.getRemainingUsage();
	 var idForResponse = '';
		var connexIDResponseValue=''
		var d = new Date();
        var UTCDate= d.toISOString();
		var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND+'/messages/head?api-version=2015-01';
		var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey',"Date":UTCDate,"Content-Type": 'application/xml'};
		var responseData=nlapiRequestURL(url, null, HEADERS,'DELETE');
		var mainObj = responseData.getBody()+'';
            nlapiLogExecution('debug','mainObj content',mainObj);
		var CorrelationIdProp='NServiceBus.CorrelationId'
		var EnclosedMessageProp='NServiceBus.EnclosedMessageTypes'

		var CorrelationId=responseData.getHeader(CorrelationIdProp)  
		var EnclosedMessageTypes=responseData.getHeader(EnclosedMessageProp)  
        var Status=''
		var Status1=''
		var scriptStatus=''
        var fileData=''
        if(mainObj==null || mainObj=='')
        {
			 messagesFound=false;
			 Status='FAILED'+'(Empty Message)'
			 scriptStatus='FAILED'
			 Status1='FAILED'+'(Empty Message)'
        }
        else
        {
		   try {
					mainObj = mainObj.substring(mainObj.indexOf("{") + 1);// to remove { if exists as first charecter
					mainObj = mainObj.slice(0,mainObj.lastIndexOf("}"));	// to remove } if exists as last charecter
					fileData = '{'+mainObj+'}';		//concatinating to make perfect JSON
					mainObj = JSON.parse(fileData);
					if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
					{
						connexIDResponseValue=mainObj[FLD_CONNEX_ID];
						nlapiLogExecution('debug', 'connexIDResponseValue:', connexIDResponseValue);
					}
					Status='SUCCESS'
			   } 
			catch (e) 
			{
			   Status='FAILED'+'(invalid JSON)'
			   scriptStatus='FAILED'
				Status1='FAILED'+'(invalid JSON)'
			}
        }
                    
		var responseDataAllHeaders=responseData.getAllHeaders()
		var responseData3=responseDataAllHeaders[3]
		var responseDataProp=responseData.getHeader(responseData3)
        var integrationResponseObj={}
								
		if(responseData.getCode()!='200' && responseData.getCode()!='201')
		{
			messagesFound=false;
		   if (responseData.getCode()!='204')
		   {
			 scriptStatus='FAILED'
		   var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS,'FAILED')
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   nlapiSubmitRecord(integrationRecord,true,true)
		   }
		 
		}    
		else
        {
			var nsClientRecord='';
			var isNewRecord = true;  
			var internalId=''
			var isUpdateRecord = true; 
			 var nsCreationMsg = '';
			try
			{
			if(!mainObj.hasOwnProperty('id'))
			{
				 nsClientRecord=nlapiCreateRecord('customer')
				 if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					var ConnexId=mainObj[FLD_CONNEX_ID]
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('customer', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                        {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalId:', internalId);
                     idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('customer',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				
				         var msdate=''
				var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }					 
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                    else
						 {
							 isUpdateRecord=false
						 }
                   }  
						
                                  }
                        }
					}
				 }
			}
			else
			{
			
				  internalId=mainObj['id']
				nlapiLogExecution('debug', 'internalId',  internalId);
				if(internalId==null || internalId=='' || internalId=='null')
				{
				  nsClientRecord=nlapiCreateRecord('customer')
				   if(mainObj.hasOwnProperty(FLD_CONNEX_ID))
				 {
					var ConnexId=mainObj[FLD_CONNEX_ID]
					nlapiLogExecution('debug', 'ConnexId:', ConnexId);
					if(ConnexId!=null && ConnexId!='')
					{
				               var nsfils = [];
	                           nsfils.push(new nlobjSearchFilter(FLD_CONNEX_ID,null,'is',ConnexId));
							 
							  var custRecord=nlapiSearchRecord('customer', null, nsfils);
	                            nlapiLogExecution('debug','custRecord',custRecord);
								  if(custRecord!=null && custRecord!='')
                          {
								if(custRecord.length>0)
                                  {
								internalId=custRecord[0].getId()
								nlapiLogExecution('debug', 'internalIdin:',internalId);
                     idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('customer',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				 var msdate=''
                 var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                    else
						 {
							 isUpdateRecord=false
						 }
                   }  
                                  }
                        }
					}
				 }
				}
				else
				{
                  internalId=internalId.toString()
                  idForResponse=internalId
					nsClientRecord=nlapiLoadRecord('customer',internalId);
					var addressbookCount=nsClientRecord.getLineItemCount('addressbook')
					if(addressbookCount>=1)
					isNewRecord = false;
				 var msdate=''
var nsdate=nsClientRecord.getFieldValue(FLD_LAST_UPDATE_DATE_TIME)
				 if (mainObj.hasOwnProperty(FLD_LAST_UPDATE_DATE_TIME))
				 {
					 msdate=mainObj[FLD_LAST_UPDATE_DATE_TIME]
				 }
			
				 if(nsdate!=null && nsdate!='' && msdate!=null && msdate!='')
				 {
				    var nsdateTm= nlapiStringToDate(nsdate,'datetimetz')
                    var MsdateTm=nlapiStringToDate(msdate,'datetimetz')
                       if(MsdateTm>nsdateTm)
                        {
                               isUpdateRecord=true;
                         }
                    else
						 {
							 isUpdateRecord=false
						 }
                   }  
				}
			}
			}
			catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				} 
			var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_MESSAGE,responseDataProp)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CONTENT_LINK,fileData)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS, Status);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_CLIENTS,nsClientRecordID)
			integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_CORRELS_STATUS_RESP, CorrelationId);
			//integrationRecord.setFieldValue(CUSTOMRECORD_FLD_CONNEX_INTEGRATION_PROPS, responseDataAllHeaders);
		   var integrationRecordID = nlapiSubmitRecord(integrationRecord,true,true);
		   var nsClientRecordID=null;
		  
			if(Status==null || Status=='' || Status=='SUCCESS')
		   {
				try{	
                       if(isUpdateRecord && (nsCreationMsg==null || nsCreationMsg==''))
					   {						   
					var hasAddressBook =false;
					var addressBookObj = {};   
					   //var nsClientRecord=nlapiCreateRecord('customer')
					for (var parentProp in mainObj)
					{
						 if (addressBookFields.indexOf(parentProp) != -1)
						 {
							 hasAddressBook =  true;
							 addressBookObj[parentProp] = mainObj[parentProp];
						 }
						// nlapiLogExecution('debug', ' parentProp',  parentProp);
			          //  var parentProp=parentProp
                         var parentProp1=mainObj[parentProp]
						  var parentProp2=nsClientRecord.getFieldValue(parentProp)
						 if((parentProp1!=null && parentProp1!=''))
						 {
						      if(parentProp!='otherrelationships' && parentProp!='version' && parentProp!='id')
			                  nsClientRecord.setFieldValue(parentProp,mainObj[parentProp])	
						  
						 }
		            }					  
					if(hasAddressBook)
					{
						  if (isNewRecord)
						  {
							  nsClientRecord.selectNewLineItem('addressbook');
						  }						  
						  else
						  {
							   nsClientRecord.selectLineItem('addressbook', 1);
						  }
						  for (var addrprop in addressBookObj)
						  {
							  if(addrprop!='phoneaddr')
							  nsClientRecord.setCurrentLineItemValue('addressbook', addrprop, addressBookObj[addrprop]);
						      if(addrprop=='phoneaddr')
							  {
								   nsClientRecord.setCurrentLineItemValue('addressbook', 'phone', addressBookObj[addrprop]);
								   	nlapiLogExecution('debug', 'addrprop',  addrprop);
									nlapiLogExecution('debug', 'addressBookObj[addrprop]',  addressBookObj[addrprop]);
							  }
						  }
						  
						  nsClientRecord.commitLineItem('addressbook');
					}
		               nsClientRecordID = nlapiSubmitRecord(nsClientRecord,true,true);
					     if(mainObj.hasOwnProperty(FLD_CONNEX_BUS_UNITS))
				               {
					                 var businessId=mainObj['custentity_appf_businessunits']
					                 nlapiLogExecution('debug', 'businessId:', businessId);
									 if(businessId!=null && businessId!='')
									 {
										 businessId=businessId.split(',')
										 for(var i=0; i<businessId.length; i++)
										 {
											 
											 var businessIds=businessId[i]
                                             if(businessIds!=null && businessIds!='')
                                               {
											 var integrationRecord=nlapiCreateRecord(CUSTOMRECORD_APPF_IN_BOUND_PRODCTS_RECS)
			                                    integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_PRODCTS_CLIENTS,nsClientRecordID)
			                                    integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_PRODCTS_CONTENT_LINK,businessIds)
			                                    integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_PRODCTS_QUEU_NAME,QUEUE_CONNEX_CLIENT_INBOUND)
			                                    integrationRecord.setFieldValue(CUSTOMRECORD_FLD_APPF_NS_PRODCTS_RESPONSE, Status);
												var integrationRecordID1 = nlapiSubmitRecord(integrationRecord,true,true);
											 var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE_1+'/messages';
                                                  var bodymain={}
                                                  bodymain.name=businessIds
			                                  var body = JSON.stringify(bodymain);
			                                  var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'};
			                                    //HEADERS.scriptStatus=scriptStatus
			                                if(CorrelationId==null || CorrelationId=='')
				                               //CorrelationId=''
										   //var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');
										   var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');
										 }
                                         }
									 }
				               }
					   
					   }
					   else
					   {    
				           if(nsCreationMsg==null || nsCreationMsg=='')
                             {
						       nsCreationMsg='Last Update Date from JSON ('+msdate+') is on or earlier than the Last Update Date found in Netsuite ('+nsdate+').';
                               scriptStatus='WARNING'
                             }
					   }
				}
				catch(e1)
				{
					scriptStatus='FAILED'
					if ( e1 instanceof nlobjError )
					nsCreationMsg = e1.getDetails();
					else
					nsCreationMsg = e1.toString();
				}                       					   
				if (nsClientRecordID != null)
				{
					var isInActiveRecord=false;
					if(mainObj.hasOwnProperty('isinactive'))
					{
					  if (mainObj['isinactive'] == 'T') 
						  isInActiveRecord=true
					}
					if(!isInActiveRecord)
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_CLIENTS,CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [nsClientRecordID, 'SUCCESS']);
				}					   
				else
				{
					nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_APPF_NS_RESPONSE], [scriptStatus+':'+nsCreationMsg]); 						   
				}							
				if(nsClientRecordID!=null && nsClientRecordID!='')
				{
				idForResponse=nsClientRecordID;
					
                    scriptStatus='SUCCESS'
                        // integrationResponseObj.internalId=recordId  				 				  
					if (responseData.getCode() == '200' || responseData.getCode() == '201')
						  nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['SUCCESS']);
					  else
						 nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_INTEGRATION_STATUS_RESP], ['FAILED']);
					
				}
            }
        }				   
		if(scriptStatus!=null && scriptStatus!='' && messagesFound==true)
		{			
			if(connexIDResponseValue==null || connexIDResponseValue=='')
				   connexIDResponseValue=''			   
			integrationResponseObj.EntityId=connexIDResponseValue
			
			if(idForResponse==null || idForResponse=='')
				idForResponse=''
			  integrationResponseObj.NetSuiteId=idForResponse
          
			if(Status1!=null && Status1!='')
				integrationResponseObj.IntegrationResponseStatus=Status1
			else
				integrationResponseObj.IntegrationResponseStatus=scriptStatus
		 
			if(nsCreationMsg==null || nsCreationMsg=='')
				 nsCreationMsg=''
			integrationResponseObj.IntegrationResponseMessage=nsCreationMsg
	nlapiSubmitField(CUSTOMRECORD_APPF_IN_BOUND_CLIENT_RECS, integrationRecordID, [CUSTOMRECORD_FLD_CONNEX_NS_SEND_RESP], [JSON.stringify(integrationResponseObj)]);
			   
			var url = URL_BASE+QUEUE_CONNEX_CLIENT_INBOUND_RESPONSE+'/messages';
			var body = JSON.stringify(integrationResponseObj);
			var HEADERS = {"Authorization":'SharedAccessSignature sr=https%3a%2f%2fnovusmediallc-dev.servicebus.windows.net&sig=J8TkVo2QEf0fiHULJlLpHoZmgNI1d1HLM0vIlzZUExg%3d&se=2079993600&skn=RootManageSharedAccessKey'};
			//HEADERS.scriptStatus=scriptStatus
			if(CorrelationId==null || CorrelationId=='')
				CorrelationId=''
			HEADERS['NServiceBus.CorrelationId']=CorrelationId
			HEADERS['NServiceBus.EnclosedMessageTypes']=NS_OB_RESPONSE_PROPERTY
		//	var responseData=nlapiRequestURL(url, body, HEADERS, null,'POST');

		}
		if(usageRemaining<=1000)
	{
	nlapiScheduleScript(SPARAM_CONNEX_CLIENT,null)
	}		   
	}
                          
	}