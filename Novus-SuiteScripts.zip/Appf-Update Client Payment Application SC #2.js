/**
 * Script Name: Appf-Update Client Payment Application SC #2
 * Script Type: Schedule Scipt
 * 
 * 
 * Version    Date            Author           		Remarks
 * 1.00            				This script will be triggered from submission of payment application suitelet and applies
								invoices and amounts into the payment and trigegrs backlinking process with payment 
								to the invoice lines
 *
 * Version	 Date			  Author				Remarks
 * 2.0		 29 FEB 2020	  Debendra Panigrahi	
 *
 * 
 * Company 	 : Appficiency. 
 */

var PAYMENT_APPLICATION_SUITELET_STATUS_UNDER_PROCESSING=1;
var PAYMENT_APPLICATION_SUITELET_STATUS_PROCESSED=2;
var PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING=3;
var PAYMENT_APPLICATION_CSV_FOLDER_ID=953;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS=2;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY=4;
var CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS=5;
var SPARAM_RANDOM_TEXT='custscript_random_text';

var SPARAM_INVOICES_PWP_UPDATE_DATA = 'custscript_invoices_pwp_updates_data';
var SPARAM_SELECTED_INVOICE_LIST='custscript_selected_invoice_list';
var SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID='custscript_payment_application_log_id';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID='custscript_payment_processed_file_id';
var SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM = 'custscript_payment_processed_cm_file';
var SPARAM_UPDATED_LINKED_TRANSACTIONS = 'custscript_appf_tot_updated_linked_trans';

var SPARAM_PAYMENT_APPLICATION_INV_FILE = 'custscript_pay_appl_inv_file';
var SPARAM_PAYMENT_APPLICATION_CM_FILE = 'custscript_pay_appl_cm_file';

var SPARAM_PAYMENT_NEED_TO_UPDATE='custscript_payment_need_to_process';
var SPARAM_INVOICE_DETAIL_OBJ_FORM='custscript_invoice_detail_obj';
var SPARAM_CREDIT_DETAIL_OBJ_FORM='custscript_credit_detail_obj';
var SPARAM_DATA_FOR_PAYMENT='custscript_data_for_payment';

var CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG='customrecord_appf_cust_pmt_app_log';
var SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS='custscript_total_invoice_to_process';
var FLD_TOT_CHILD_INVCS_LINE_TO_PROCESS='custrecord_appf_cst_pmt_lines_to_process';

var FLD_CHILD_INVCS_PROCESS_PERCENTAGE='custrecord_appf_cst_pmt_perc_processed';
var FLD_CUSTOMER_PAYMENT_APPLICATION_FILE='custrecord_appf_cst_pmt_data_file';
var FLD_CUSTOMER_PAYMENT_APPLICATION_FILE_CM = 'custrecord_appf_cst_pmt_data_file_cm';
var FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG='custrecord_appf_cst_pmt_error_log';
var FLD_CUSTOMER_PAYMENT_APPLICATION_LINKS='custbody_appf_pmt_appl_log_rec_links';
var SCRIPT_APPF_PAYMENT_APPLICATION_LOG_ID='custscript_payment_application_log_id';
var CSV_CHILD_INVOICE_UNDERPROCESSING='custimport_invoices_under_processing';
var CSV_CREDITS_UNDERPROCESSING = 'custimport_credits_under_processing';
var CSV_CHILD_INVOICE_PROCESSING='custimport_invoices_processing_payappl';
var CSV_CHILD_CREDIT_PROCESSING='custimport_credits_processing_payappl';
var COL_PWP_CUSTOM_RECORD_INVOICE='custcol_appf_pwp_custom_record';
var COL_INVOICE_LINE_PAYMENT_AMOUNT = 'custcol_appf_pwp_inv_line_amt_paid';
var COL_INVOICE_LINE_ID='custcol_appf_invoice_line_id';
var FLD_CUSTOMER_PAYMENT_STATUS='custrecord_appf_cst_pmt_status';
var FLD_CUSTOMER_PAYMENT_STATUS_IN_INVOICE='custbody_appf_cst_pmt_status';
var FLD_CREDITS_APPLIED = 'custbody_appf_credits_applied';
var FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_tot_linked_trans_to_proc';
var FLD_LINKED_TRANSACTION_RESULT_FILE = 'custrecord_appf_linked_trans_result_file';
var FLD_LINKED_TRANSACTION_PROCESSED_PERCENT = 'custrecord_appf_linked_trans_prc_percent';
var FLD_LINKED_TRANSACTIONS_PROCESSED = 'custrecord_appf_tot_linked_trans_process';
var FLD_TOTAL_CREDIT_MEMOS_TO_PROCESS = 'custrecord_appf_tot_credits_to_process';
var FLD_TOTAL_CREDIT_MEMOS_PROCESSED = 'custrecord_appf_tot_credits_processed';
var FLD_CREDITS_PROCESSED_PERCENT = 'custrecord_appf_credits_processed_percen';
var FLD_CREDITS_RESULT_FILE = 'custrecord_appf_credit_processing_result';
var FLD_TOT_CHILD_INVCS_TO_PROCESS='custrecord_appf_cst_pmt_total_inv';
var FLD_TOT_CHILD_INVCS_PROCESSED='custrecord_appf_cst_pmt_inv_completed';
var FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT='custrecord_appf_inv_processed_percent';
var FLS_TOT_CHILD_INV_RESULT_FILE = 'custrecord_invoice_processing_resultfile';
var FLD_TRANSACTIONS_TO_PROCESS = 'custrecord_appf_transactions_to_process';
var FLD_BACKLINKING_STATUS = 'custrecord_appf_backlinking_status';


var CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION='customrecord_appf_pay_app_linked_trans';
var FLD_PAYMENT_TRANSACTION_LINK='custrecord_appf_pay_app_pmt_link'
var FLD_TRANSACTION_LINK='custrecord_appf_pay_app_tran_link';
var FLD_TRANSACTION_LINE_ID='custrecord_appf_pay_app_tran_lineid';
var FLD_TRANSACTION_LINE_AMOUNT='custrecord_appf_pay_app_tran_line_amt';
var FLD_TRANSACTION_LINE_TAX = 'custrecord_appf_pay_app_tax';
var FLD_APPLIED_TO_INVOICE_LINK='custrecord_applied_to_invoice_link'
var FLD_TRANSACTION_LINE_PWP='custrecord_appf_pay_app_line_pwp';
var CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD='customrecord_appf_pwp_wrapper_record';
var FLD_INVOICE_LINE_PAYMENT_AMOUNT='custrecord_appf_pwp_inv_line_amt_paid';
var FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD='custrecord_appf_pay_app_log_link'
var FLD_CUSTOMER_PAYMENT_APPLICATION_LINK='custrecord_appf_cst_pmt_link';
var FLD_PWP_INVOICE_LINE_PAYMENT_AMT = 'custrecord_appf_pwp_inv_line_amt_paid';
var FLD_PWP_INVOICE_STATUS = 'custrecord_appf_pwp_client_inv_status';
var FLD_PWP_INVOICED_AMT = 'custrecord_appf_pwp_inv_line_amount';
var FLD_PWP_CRED_MEMO_AMT = 'custrecord_appf_pwp_cm_amount';

var FLD_PWP_IO_CHECKBOX='custrecord_appf_trigger_ob_integration';

var FLD_CONSOLIDATION_PROCESSING_STATUS_FILE = 'custrecord_appf_cst_pmt_error_file';
var FLD_CONSOLIDATION_PROCESSING_STATUS_FILE_CM = 'custrecord_appf_credit_proc_file';

var STATUS_PAYMENT_PENDING='4'
var STATUS_PARTIALLY_PAID='5'
var STATUS_PAID='7'

var SPARAM_READY_FOR_PROCESSING_FILE_ID = 'custscript_ready_for_processing_file_id';
var SPARAM_PAYMENT_APPLICATION_LOG_ID = 'custscript_appf_cust_payment_log_id';
var SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION_3 = 'customscript_appf_update_client_pay_sc_3';
var DEPLOY_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION_3 = 'customdeploy_appf_update_client_pay_sc_3';

function schedule(type)
{
		var isRescheduled = false;
		var errorLog = '';
		var context=nlapiGetContext();
		
		var invLineData = {};
		var invLineDataParam=context.getSetting('SCRIPT','custscript_invlinedata');
		if (invLineDataParam == '""')
			invLineDataParam = '';
		if (invLineDataParam != null && invLineDataParam != '')
			invLineData = JSON.parse(invLineDataParam);
		
	
		
		var dataForPayment=context.getSetting('SCRIPT',SPARAM_DATA_FOR_PAYMENT);
		nlapiLogExecution('debug','dataForPayment @ start',dataForPayment);
		if (dataForPayment == '""')
			dataForPayment = '';
		var unappliedDataArr = context.getSetting('SCRIPT', 'custscript_appf_unchecked_linked_trans');
		if (unappliedDataArr == '""')
			unappliedDataArr = '';
		var selectedInvoicesList=context.getSetting('SCRIPT',SPARAM_SELECTED_INVOICE_LIST);
		if (selectedInvoicesList == '""')
			selectedInvoicesList = '';
		var totalIvoiceToProcess=context.getSetting('SCRIPT',SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS);
		if (totalIvoiceToProcess == '""')
			totalIvoiceToProcess = '';
		var customRecordAppfPaymentApplicationLog=context.getSetting('SCRIPT',SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID);
		if (customRecordAppfPaymentApplicationLog == '""')
			customRecordAppfPaymentApplicationLog = '';
		var invoicesAppliedFile =context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_INV_FILE);
		if (invoicesAppliedFile == '""')
			invoicesAppliedFile = '';
		var creditsAppliedFile =context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_CM_FILE);
		if (creditsAppliedFile == '""')
			creditsAppliedFile = '';
		var indexUnappliedPalt=context.getSetting('SCRIPT','custscript_unappl_index');
		if (indexUnappliedPalt == '""')
			indexUnappliedPalt = '';
		nlapiLogExecution( 'DEBUG', 'indexUnappliedPalt: @ start', indexUnappliedPalt);
		var cmArrayIndexProp=context.getSetting('SCRIPT','custscript_cmarr_index');
		if (cmArrayIndexProp == '""')
			cmArrayIndexProp = '';
		nlapiLogExecution( 'DEBUG', 'cmArrayIndexProp', cmArrayIndexProp);
		var indexLinkedTransGen=context.getSetting('SCRIPT','custscript_ipalt_index');
			if (indexLinkedTransGen == '""')
			indexLinkedTransGen = '';
		nlapiLogExecution( 'DEBUG', 'indexLinkedTransGen: @ start', indexLinkedTransGen);
		var indexLinkedTransInv=context.getSetting('SCRIPT','custscript_pialt_index');
		if (indexLinkedTransInv == '""')
			indexLinkedTransInv = '';
		nlapiLogExecution( 'DEBUG', 'indexLinkedTransInv: @ start', indexLinkedTransInv);
		var indexLinkedTransCM=context.getSetting('SCRIPT','custscript_pcalt_index');
			if (indexLinkedTransCM == '""')
			indexLinkedTransCM = '';
		nlapiLogExecution( 'DEBUG', 'indexLinkedTransCM: @ start', indexLinkedTransCM);
		
		var dataLinkedTransInv=context.getSetting('SCRIPT','custscript_invoice_linked_trans_data');
		if (dataLinkedTransInv == '""')
			dataLinkedTransInv = '';
		var dataLinkedTransCM=context.getSetting('SCRIPT','custscript_credit_linked_trans_data');
		if (dataLinkedTransCM == '""')
			dataLinkedTransCM = '';
		var linkedTransFileGen=context.getSetting('SCRIPT','custscript_lt_file_gen');
		if (linkedTransFileGen == '""')
			linkedTransFileGen = '';
		nlapiLogExecution('debug', 'linkedTransFileGen @ start', linkedTransFileGen);
        var cmDataObj=context.getSetting('SCRIPT','custscript_cm_data_obj');
		if (cmDataObj == '""')
			cmDataObj = '';
		nlapiLogExecution( 'DEBUG', 'cmDataObj: @ start',JSON.stringify(cmDataObj));
		var invResultFileId = context.getSetting('SCRIPT','custscript_appf_inv_result_file_id');
		if (invResultFileId == '""')
			invResultFileId = '';
		nlapiLogExecution( 'DEBUG', 'invResultFileId: @ start',invResultFileId);
		var cmResultFileId = context.getSetting('SCRIPT','custscript_appf_cm_result_file_id');
		if (cmResultFileId == '""')
			cmResultFileId = '';
		nlapiLogExecution( 'DEBUG', 'cmResultFileId: @ start',cmResultFileId);
		
		var updatedLinkedTrans = context.getSetting('SCRIPT', SPARAM_UPDATED_LINKED_TRANSACTIONS);
		if (updatedLinkedTrans == '""')
			updatedLinkedTrans = '';
		nlapiLogExecution( 'DEBUG', 'updatedLinkedTrans: @ start',JSON.stringify(updatedLinkedTrans));
		
		var paymentApplicationSuccessFile=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID);
		if (paymentApplicationSuccessFile == '""')
			paymentApplicationSuccessFile = '';
		var paymentApplicationCreditSuccessFile=context.getSetting('SCRIPT',SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM);
		if (paymentApplicationCreditSuccessFile == '""')
			paymentApplicationCreditSuccessFile = '';
		
		
		var paymentNeedToUpdate=context.getSetting('SCRIPT',SPARAM_PAYMENT_NEED_TO_UPDATE);
		if (paymentNeedToUpdate == '""')
			paymentNeedToUpdate = '';
		var randomText=context.getSetting('SCRIPT',SPARAM_RANDOM_TEXT);
		if (randomText == '""')
			randomText = '';
		if(randomText == null || randomText == '')
			randomText = new Date().getTime()+'I';
		var mainObj=context.getSetting('SCRIPT',SPARAM_INVOICE_DETAIL_OBJ_FORM);
		if (mainObj == '""')
			mainObj = '';
		var creditObj = context.getSetting('SCRIPT',SPARAM_CREDIT_DETAIL_OBJ_FORM);
		if (creditObj == '""')
			creditObj = '';
		nlapiLogExecution( 'DEBUG', 'mainObj: @ start',mainObj);
		nlapiLogExecution( 'DEBUG', 'creditObj: @ start',creditObj);
		
		var dumpInvoicesFile = null;
		var dumpCreditMemosFile = null;
		var cmemoPercent = 0;
		var invPercent = 0;
		var creditLTProcessed = 'F';
		var allTransactions = [];
		var dumpFiles = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT, FLD_CREDITS_PROCESSED_PERCENT, FLD_LINKED_TRANSACTIONS_PROCESSED, FLD_CUSTOMER_PAYMENT_APPLICATION_FILE, FLD_CUSTOMER_PAYMENT_APPLICATION_FILE_CM, 'custrecord_credit_lt_processed','custrecord_appf_tran_internal_ids']);
	  var linkedTransProcessed = 0;
	  if(dumpFiles != null && dumpFiles != ''){
		dumpInvoicesFile = dumpFiles[FLD_CUSTOMER_PAYMENT_APPLICATION_FILE];
		allTransactions = dumpFiles['custrecord_appf_tran_internal_ids'];
		if (allTransactions)
			allTransactions = allTransactions.split(',');
		dumpCreditMemosFile = dumpFiles[FLD_CUSTOMER_PAYMENT_APPLICATION_FILE_CM];
		linkedTransProcessed = dumpFiles[FLD_LINKED_TRANSACTIONS_PROCESSED];
		creditLTProcessed = dumpFiles['custrecord_credit_lt_processed'];
		if(creditLTProcessed != 'T')
			creditLTProcessed = 'F';
		if (linkedTransProcessed == null || linkedTransProcessed == '')
			linkedTransProcessed = 0;
		cmemoPercent = dumpFiles[FLD_CREDITS_PROCESSED_PERCENT];
		if (cmemoPercent == null || cmemoPercent == '')
			cmemoPercent = 0;
		invPercent = dumpFiles[FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT];
		if (invPercent == null || invPercent == '')
			invPercent = 0;
	  }
	  
	  var dumpCreditValues = null;
	  var dumpInvoiceValues = null;
	  if(dumpInvoicesFile != null && dumpInvoicesFile != ''){
			var invfile=nlapiLoadFile(dumpInvoicesFile);
				var dumpInvoiceValues=invfile.getValue();
				//nlapiLogExecution('debug','dumpInvoiceValues:',dumpInvoiceValues);
				//nlapiLogExecution('debug','dumpInvoiceValues length::',dumpInvoiceValues.length);
				dumpInvoiceValues=dumpInvoiceValues.split('\n');
				//nlapiLogExecution('debug','dumpInvoiceValues lengthbefore spliting:',dumpInvoiceValues.length);
				dumpInvoiceValues=dumpInvoiceValues.slice(0,-1);
		}
		if(dumpCreditMemosFile != null && dumpCreditMemosFile != ''){
			var cmfile=nlapiLoadFile(dumpCreditMemosFile);
				var dumpCreditValues=cmfile.getValue();
				//nlapiLogExecution('debug','dumpCreditValues:',dumpCreditValues);
				//nlapiLogExecution('debug','dumpCreditValues length::',dumpCreditValues.length);
				dumpCreditValues=dumpCreditValues.split('\n');
				//nlapiLogExecution('debug','dumpCreditValues lengthbefore spliting:',dumpCreditValues.length);
				dumpCreditValues=dumpCreditValues.slice(0,-1);
		}
	  var creditDataArray = [];
				var creditDataIdArray = [];
				if(dumpCreditValues != null && dumpCreditValues != ''){
				for (var cs = 0; cs < dumpCreditValues.length; cs++)
				{
					if(cs == 0){
						var creditmemoIntid = dumpCreditValues[cs].split(',')[1];
						creditDataArray.push(dumpCreditValues[cs].toString());
						creditDataIdArray.push(creditmemoIntid);
					}
					else{
						var isSelect = dumpCreditValues[cs].split(',')[0];
						if(isSelect == 'T'){
							var creditmemoIntid = dumpCreditValues[cs].split(',')[1];
							creditDataArray.push(dumpCreditValues[cs].toString());
							creditDataIdArray.push(creditmemoIntid);
						}
					}
				}
				}
				
				
	nlapiLogExecution('debug', 'creditDataArray || creditDataIdArray', JSON.stringify(creditDataArray)+' || '+JSON.stringify(creditDataIdArray));			
				var invoiceDataArray = [];
				var invoiceDataCompletedArray = [];

				var invoiceDataIdArray = [];
				if(dumpInvoiceValues != null && dumpInvoiceValues != ''){
				for (var ci = 0; ci < dumpInvoiceValues.length; ci++)
				{
					if(ci == 0){
						var invoiceIntid = dumpInvoiceValues[ci].split(',')[1];
						invoiceDataArray.push(dumpInvoiceValues[ci].toString());
						invoiceDataIdArray.push(invoiceIntid);
					}
					else{
						var isSelect = dumpInvoiceValues[ci].split(',')[0];
						if(isSelect == 'T'){
							var invoiceIntid = dumpInvoiceValues[ci].split(',')[1];
							invoiceDataArray.push(dumpInvoiceValues[ci].toString());
							invoiceDataIdArray.push(invoiceIntid);
						}
					}
				}
				}
	  nlapiLogExecution('debug', 'invoiceDataArray || invoiceDataIdArray', JSON.stringify(invoiceDataArray)+' || '+JSON.stringify(invoiceDataIdArray));
		var file=nlapiLoadFile(paymentApplicationSuccessFile);
				var values=file.getValue();
				//nlapiLogExecution('debug','values:',values);
				//nlapiLogExecution('debug','values length::',values.length);
				values=values.split('\n');
				//nlapiLogExecution('debug','values lengthbefore spliting:',values.length);
				values=values.slice(0,-1);
				//nlapiLogExecution('debug','columns when loop length not equal 0:',values.length);

				var creditValues = null;
				if (paymentApplicationCreditSuccessFile)
				{
							var cmfile=nlapiLoadFile(paymentApplicationCreditSuccessFile);

					var creditValues=cmfile.getValue();
				//nlapiLogExecution('debug','values:',values);
				//nlapiLogExecution('debug','values length::',values.length);
				creditValues=creditValues.split('\n');
				//nlapiLogExecution('debug','values lengthbefore spliting:',values.length);
				creditValues=creditValues.slice(0,-1);
				}
				
		
		var processedInvoiceIds=[];
		var processedCreditIds =[];
  		var paymentUpdatedSuccessFullyBoolean=false;
		var invoiceObjectNotEmpty=false;
		
		var creditLinkedTransactions=[]; 
		if (dataLinkedTransCM != null && dataLinkedTransCM != '')
			creditLinkedTransactions = dataLinkedTransCM.split(',');
		var invoiceLinkedTransactions=[];
		if (dataLinkedTransInv != null && dataLinkedTransInv != '')
			invoiceLinkedTransactions = dataLinkedTransInv.split(',');
		
		var paltInvReslutsObj = {};
			var paltInvDataParam=context.getSetting('SCRIPT','custscript_palt_inv_data');
			if (paltInvDataParam == '""')
			paltInvDataParam = '';
		if (paltInvDataParam != null && paltInvDataParam != '')
			paltInvReslutsObj = JSON.parse(paltInvDataParam);
		var paltCMReslutsObj = {};
		
		var totSSPaltRecs = [];
		var totUpdatedPaltRecs = [];
		if(updatedLinkedTrans != null && updatedLinkedTrans != ''){
			totUpdatedPaltRecs = updatedLinkedTrans.split(',');
		}
		if (paymentNeedToUpdate != null && paymentNeedToUpdate != '')
		{
			var paltFilters = [];
			paltFilters.push(new nlobjSearchFilter('isinactive', null, 'is', 'F'));
			paltFilters.push(new nlobjSearchFilter(FLD_PAYMENT_TRANSACTION_LINK, null, 'anyof', paymentNeedToUpdate));
			
			var paltColumns = [];
			paltColumns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINK));
			paltColumns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_ID));
			paltColumns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_AMOUNT));
			paltColumns.push(new nlobjSearchColumn(FLD_TRANSACTION_LINE_PWP));
			paltColumns.push(new nlobjSearchColumn(FLD_APPLIED_TO_INVOICE_LINK));
			paltColumns.push(new nlobjSearchColumn(FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD));

			
			var paltResults = getAllSearchResults(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paltFilters, paltColumns);
			if(paltResults != null && paltResults != ''){
				for(var p=0; p<paltResults.length; p++){
					var col = paltResults[p];
					var paltId = col.getId();
					totSSPaltRecs.push(paltId);
					var transId = col.getValue(FLD_TRANSACTION_LINK);
					var transLineId = col.getValue(FLD_TRANSACTION_LINE_ID);
					var transLinePWP = col.getValue(FLD_TRANSACTION_LINE_AMOUNT);
					var transLineAmt = col.getValue(FLD_TRANSACTION_LINE_PWP);
					var appliedInvLink = col.getValue(FLD_APPLIED_TO_INVOICE_LINK);
					var linkedLogRecID = col.getValue(FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD);
					
					if(appliedInvLink == null || appliedInvLink == '')
						appliedInvLink = '';
					
					if(transLineId != null && transLineId != ''){
						paltInvReslutsObj[transId+'||'+transLineId] = paltId;
					}
					else{
						paltCMReslutsObj[transId+'||'+appliedInvLink] = paltId;
					}
					
				}
			}
		}
		
		var totalInvoicesProcessed = 0;
		var totalCreditMemosProcessed = 0;
		
		var totalLinkedTransactionsProcessed = parseInt(linkedTransProcessed);
		
		var totalLinkedTransactionsToProceess = 0;
		var totalInvoicesToProcess = 0;
		var totalCreditMemosToProcess = 0;
		
		var logRecFields = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_TOTAL_CREDIT_MEMOS_PROCESSED, FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS, FLD_TOT_CHILD_INVCS_TO_PROCESS, FLD_TOTAL_CREDIT_MEMOS_TO_PROCESS]);
		if(logRecFields != null && logRecFields != ''){
			totalLinkedTransactionsToProceess = logRecFields[FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS];
			totalInvoicesToProcess = logRecFields[FLD_TOT_CHILD_INVCS_TO_PROCESS];
			totalCreditMemosToProcess = logRecFields[FLD_TOTAL_CREDIT_MEMOS_TO_PROCESS];
			totalCreditMemosProcessed = logRecFields[FLD_TOTAL_CREDIT_MEMOS_PROCESSED];
			if (totalCreditMemosProcessed == null || totalCreditMemosProcessed == '')
				totalCreditMemosProcessed = 0;
			nlapiLogExecution('debug','totalLinkedTransactionsToProceess :: totalInvoicesToProcess :: totalCreditMemosToProcess', totalLinkedTransactionsToProceess+' :: '+totalInvoicesToProcess+' :: '+totalCreditMemosToProcess);

		}
		var selectedInvoiceObj=JSON.parse(mainObj);
		var isErrorOcuured = false;
		
		var zeroCreditLinkedTransactions = [];
		
		var linkedTransactionFile = '';
		linkedTransactionFile += 'INTERNAL ID, TRANSACTION LINK, TRANSACTION LINE ID, TRANSACTION LINE AMOUNT, TRANSACTION LINE PWP, APPLIED TO INVOICE LINK, CLIENT PAYMENT APPLICATION LOG RECORD, TRANSACTION LINE TAX\n';
		if (linkedTransFileGen != null && linkedTransFileGen != '')
		{
			linkedTransactionFile = nlapiLoadFile(linkedTransFileGen).getValue();
			
		}
		
		var creditMemoResultsFile = '';
		creditMemoResultsFile += 'Processing Status, Failed Reason,'+creditDataArray[0]+'\n';
		if (cmResultFileId != null && cmResultFileId != ''){
			creditMemoResultsFile = nlapiLoadFile(cmResultFileId).getValue();
		}
		var invoiceResultsFile = '';
		invoiceResultsFile += 'Processing Status, Failed Reason,'+invoiceDataArray[0]+'\n';
		if(invResultFileId != null && invResultFileId != ''){
			invoiceResultsFile = nlapiLoadFile(invResultFileId).getValue();
		}
		
		var creditMemosProcessedSuccessfully = [];
		var invoicesProcessedSuccessfully = [];
		
		var cmObj = {};
		if (cmDataObj != null && cmDataObj != '')
			cmObj = JSON.parse(cmDataObj);
		var pymObj = {};
		
		if(creditLTProcessed != 'T' && creditObj != null && creditObj != '' && creditObj != '{}')
		{
			var selectedCreditObj = JSON.parse(creditObj);
			var creditsAppliedForInvArr = [];
			for(var cmprop in selectedCreditObj)
			{
				try{
						
					processedCreditIds.push(cmprop);
					var creditAmount=Number(selectedCreditObj[cmprop].payment);
							
					
					
					for(var invprop in selectedInvoiceObj)
					{
						
						var paltCM = '';
						if(paltCMReslutsObj.hasOwnProperty(cmprop+'||'+invprop)){
							paltCM = paltCMReslutsObj[cmprop+'||'+invprop];
							totUpdatedPaltRecs.push(paltCM);
						}
						invoiceObjectNotEmpty=true;
						processedInvoiceIds.push(invprop)
						var invAmount=Number(selectedInvoiceObj[invprop].payment);
						//invAmount = Math.round(invAmount*100)/100;
						var invLineTaxAmt=Number(selectedInvoiceObj[invprop].invLineTaxAmt);
						//invLineTaxAmt = Math.round(invLineTaxAmt*100)/100;
						
						if(parseFloat(creditAmount)==0){
						
							if(paltCMReslutsObj.hasOwnProperty(cmprop+'||'+invprop)){
								var paltCM = paltCMReslutsObj[cmprop+'||'+invprop];
								totUpdatedPaltRecs.push(paltCM);
								if(paltCM != null && paltCM != '' && zeroCreditLinkedTransactions.indexOf(paltCM+'||'+cmprop) == -1){
								
									zeroCreditLinkedTransactions.push(paltCM+'||'+cmprop);
								}
							}		
							if (selectedInvoiceObj != null && selectedInvoiceObj != '' && selectedInvoiceObj != '{}')
								invoiceObjectNotEmpty = true;	
							
							
						}
						if(!isErrorOcuured && parseFloat(creditAmount) < parseFloat(invAmount) && parseFloat(creditAmount) > 0 && ((cmArrayIndexProp == null || cmArrayIndexProp == '') && (indexUnappliedPalt == null || indexUnappliedPalt == '') && (indexLinkedTransGen == null || indexLinkedTransGen == '') && (indexLinkedTransInv == null || indexLinkedTransInv == '') && (indexLinkedTransCM == null || indexLinkedTransCM == '')))
						{
							nlapiLogExecution('debug', 'creditAmount < invAmount', creditAmount+' :: '+invAmount);
							
							try{
								var paymentApplicationLinkedTransactionRec = null;
								if(paltCM == null || paltCM == '')
									paymentApplicationLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION);
								else
									paymentApplicationLinkedTransactionRec=nlapiLoadRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paltCM);
								if(paymentApplicationLinkedTransactionRec){	
									//paymentApplicationLinkedTransactionRec.setFieldValue(FLD_PAYMENT_TRANSACTION_LINK,paymentNeedToUpdate);
									if(customRecordAppfPaymentApplicationLog)
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD,customRecordAppfPaymentApplicationLog);
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,cmprop);
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,Number(creditAmount).toFixed(2));
									
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_TAX,'');
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_APPLIED_TO_INVOICE_LINK,invprop);
									
									var paymentApplicationLinkedTransactionRecId=nlapiSubmitRecord(paymentApplicationLinkedTransactionRec,true,true);
								
									if(paymentApplicationLinkedTransactionRecId)
									creditLinkedTransactions.push(paymentApplicationLinkedTransactionRecId)
									
									totalLinkedTransactionsProcessed++;
									
									if(Number(totalLinkedTransactionsProcessed) > Number(totalLinkedTransactionsToProceess))
										totalLinkedTransactionsProcessed = Number(totalLinkedTransactionsToProceess)
									var linkedTransactionsProcessedPercent = parseFloat(totalLinkedTransactionsProcessed)/parseFloat(totalLinkedTransactionsToProceess);
									if(linkedTransactionsProcessedPercent == null || linkedTransactionsProcessedPercent == '')
										linkedTransactionsProcessedPercent = 0;
									linkedTransactionsProcessedPercent = parseFloat(linkedTransactionsProcessedPercent) * 100;
									nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_LINKED_TRANSACTIONS_PROCESSED, FLD_LINKED_TRANSACTION_PROCESSED_PERCENT], [totalLinkedTransactionsProcessed, linkedTransactionsProcessedPercent]);
								
									linkedTransactionFile += paymentApplicationLinkedTransactionRecId+','+cmprop+', ,'+creditAmount+', ,'+invprop+','+customRecordAppfPaymentApplicationLog+', \n';
									if(!cmObj.hasOwnProperty(cmprop)){
										cmObj[cmprop] = [];
										cmObj[cmprop].push(invprop+'||'+creditAmount);
									}else{
										cmObj[cmprop].push(invprop+'||'+creditAmount);
									}
									if (creditsAppliedForInvArr.indexOf(invprop) == -1)
									{
										
										var indexes = getAllIndexes(invoiceDataIdArray, invprop);
										for(var ind=0; ind<indexes.length; ind++){
											if (invoiceDataCompletedArray.indexOf(indexes[ind]) == -1)
											{
												if (invoiceResultsFile.indexOf('Success, ,'+invoiceDataArray[indexes[ind]]) == -1){
											invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[indexes[ind]]+'\n';
											invoiceDataCompletedArray.push(indexes[ind]);
											totalInvoicesProcessed++;
												}
											}
						
						
										}
										creditsAppliedForInvArr.push(invprop);
										/*invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invprop+'\n';
										//invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[invprop]+'\n';
											invoiceDataCompletedArray.push(invprop);
											totalInvoicesProcessed++;*/
									}
								}
							}catch(el){
								
								isErrorOcuured = true;
								var failedReason = '';
								if ( el instanceof nlobjError ){
									nlapiLogExecution( 'DEBUG', 'System error while Creating Linked Transactions', el.getCode() + '\n' + el.getDetails());
									errorLog += 'System error : \n'+el.getDetails();
								}else{
									nlapiLogExecution( 'DEBUG', 'Unexpected error while Creating Linked Transactions', el.toString());
									errorLog += 'Unexpected error : \n'+el.toString();
								}
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
								break;
								

							}
							var remainingInvAmount=parseFloat(invAmount)- parseFloat(creditAmount);
							//remainingInvAmount=Math.round(remainingInvAmount*100)/100;
							//nlapiLogExecution('debug','remainingInvAmount:',remainingInvAmount)
							selectedInvoiceObj[invprop].payment=remainingInvAmount;
							creditAmount=0;
							
						}
						else if(!isErrorOcuured && parseFloat(creditAmount) >= parseFloat(invAmount) && parseFloat(invAmount) > 0 && parseFloat(creditAmount) > 0 && ((cmArrayIndexProp == null || cmArrayIndexProp == '') && (indexUnappliedPalt == null || indexUnappliedPalt == '') && (indexLinkedTransGen == null || indexLinkedTransGen == '') && (indexLinkedTransInv == null || indexLinkedTransInv == '') && (indexLinkedTransCM == null || indexLinkedTransCM == '')))
						{
							nlapiLogExecution('debug', 'creditAmount >= invAmount', creditAmount+' :: '+invAmount);
							
							try{
								var paymentApplicationLinkedTransactionRec = null;
								if(paltCM == null || paltCM == '')
									paymentApplicationLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION);
								else
									paymentApplicationLinkedTransactionRec=nlapiLoadRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paltCM);
								
								if(paymentApplicationLinkedTransactionRec){
									//paymentApplicationLinkedTransactionRec.setFieldValue(FLD_PAYMENT_TRANSACTION_LINK,paymentNeedToUpdate);
									if(customRecordAppfPaymentApplicationLog)
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD,customRecordAppfPaymentApplicationLog);
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,cmprop);
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,Number(invAmount).toFixed(2));
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_TAX,'');
									paymentApplicationLinkedTransactionRec.setFieldValue(FLD_APPLIED_TO_INVOICE_LINK,invprop);
									
									var paymentApplicationLinkedTransactionRecId=nlapiSubmitRecord(paymentApplicationLinkedTransactionRec,true,true);
										
									if(paymentApplicationLinkedTransactionRecId)
										creditLinkedTransactions.push(paymentApplicationLinkedTransactionRecId)
									
									totalLinkedTransactionsProcessed++;
									if(Number(totalLinkedTransactionsProcessed) > Number(totalLinkedTransactionsToProceess))
										totalLinkedTransactionsProcessed = Number(totalLinkedTransactionsToProceess)
									var linkedTransactionsProcessedPercent = parseFloat(totalLinkedTransactionsProcessed)/parseFloat(totalLinkedTransactionsToProceess);
									if(linkedTransactionsProcessedPercent == null || linkedTransactionsProcessedPercent == '')
										linkedTransactionsProcessedPercent = 0;
									else
										linkedTransactionsProcessedPercent = parseFloat(linkedTransactionsProcessedPercent)*100;
									nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_LINKED_TRANSACTIONS_PROCESSED, FLD_LINKED_TRANSACTION_PROCESSED_PERCENT], [totalLinkedTransactionsProcessed, linkedTransactionsProcessedPercent]);
									
									linkedTransactionFile += paymentApplicationLinkedTransactionRecId+','+cmprop+', ,'+invAmount+', ,'+invprop+','+customRecordAppfPaymentApplicationLog+', \n';
									if(!cmObj.hasOwnProperty(cmprop)){
										cmObj[cmprop] = [];
										cmObj[cmprop].push(invprop+'||'+invAmount);
									}else{
										cmObj[cmprop].push(invprop+'||'+invAmount);
									}
									if (creditsAppliedForInvArr.indexOf(invprop) == -1)
									{
										creditsAppliedForInvArr.push(invprop);
										/*invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invprop+'\n';
										//invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[invprop]+'\n';
											invoiceDataCompletedArray.push(invprop);
											totalInvoicesProcessed++;*/
											
										var indexes = getAllIndexes(invoiceDataIdArray, invprop);
										for(var ind=0; ind<indexes.length; ind++){
											if (invoiceDataCompletedArray.indexOf(indexes[ind]) == -1)
											{
												if (invoiceResultsFile.indexOf('Success, ,'+invoiceDataArray[indexes[ind]]) == -1){
											invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[indexes[ind]]+'\n';
											invoiceDataCompletedArray.push(indexes[ind]);
											totalInvoicesProcessed++;
												}
											}
						
						
										}
									}
									
								}
							}catch(el){
								
								isErrorOcuured = true;
								
								if ( el instanceof nlobjError ){
									nlapiLogExecution( 'DEBUG', 'System error while Creating Linked Transactions', el.getCode() + '\n' + el.getDetails());
									errorLog += 'System error : \n'+el.getDetails();
								}else{
									nlapiLogExecution( 'DEBUG', 'Unexpected error while Creating Linked Transactions', el.toString());
									errorLog += 'Unexpected error : \n'+el.toString();
								}
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
								break;
							}
				
				
							if (creditsAppliedForInvArr.indexOf(invprop) == -1)
							{
								
								var indexes = getAllIndexes(invoiceDataIdArray, invprop);
								for(var ind=0; ind<indexes.length; ind++){
									if (invoiceDataCompletedArray.indexOf(indexes[ind]) == -1)
									{
										if (invoiceResultsFile.indexOf('Success, ,'+invoiceDataArray[indexes[ind]]) == -1){
									invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[indexes[ind]]+'\n';
									invoiceDataCompletedArray.push(indexes[ind]);
									totalInvoicesProcessed++;
										}
									}
				
				
								}
								creditsAppliedForInvArr.push(invprop);
								/*invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invprop+'\n';
								//invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[invprop]+'\n';
									invoiceDataCompletedArray.push(invprop);
									totalInvoicesProcessed++;*/
							}
							creditAmount=parseFloat(creditAmount)- parseFloat(invAmount);
							//creditAmount=Math.round(creditAmount*100)/100;
							selectedInvoiceObj[invprop].payment=0;
				
						}
						if(context.getRemainingUsage() < 200) {

					setRecoveryPoint();
					checkGovernance();
					}
						if(isErrorOcuured == true)
							break;
						
					}
					
					
			
					if (creditDataIdArray.indexOf(cmprop) != -1){
						if ((cmResultFileId == null || cmResultFileId == '') &&  creditMemoResultsFile.indexOf('success, ,'+creditDataArray[creditDataIdArray.indexOf(cmprop)]) == -1)
						creditMemoResultsFile = creditMemoResultsFile + 'success, ,'+creditDataArray[creditDataIdArray.indexOf(cmprop)]+'\n';
						creditMemosProcessedSuccessfully.push(cmprop);						
					}					
					if(isErrorOcuured)
						break;
				}catch(el){
					
					isErrorOcuured = true;
					var failedReason = '';
					if ( el instanceof nlobjError ){
						nlapiLogExecution( 'DEBUG', 'System error @ Creditmemo Submit', el.getCode() + '\n' + el.getDetails());
						failedReason = el.getDetails();
						errorLog += 'System error :\n'+el.getDetails();
					}else{
						nlapiLogExecution( 'DEBUG', 'Unexpected error @ Creditmemo Submit', el.toString());
						failedReason = el.toString();
						errorLog += 'Unexpected error :\n'+el.toString();
					}
					nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
					if (cmResultFileId == null || cmResultFileId == '')
					creditMemoResultsFile = creditMemoResultsFile + 'Failed,'+failedReason+','+creditDataArray[creditDataIdArray.indexOf(cmprop)]+'\n';
					creditMemosProcessedSuccessfully.push(cmprop);
					break;
				}
				if(context.getRemainingUsage() < 200) {

					setRecoveryPoint();
					checkGovernance();
					}
			}
			nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, 'custrecord_credit_lt_processed', 'T');
			for(var cmprop in selectedCreditObj)
			{
				if(creditMemosProcessedSuccessfully.indexOf(cmprop) == -1){
					if (cmResultFileId == null || cmResultFileId == '')
					creditMemoResultsFile = creditMemoResultsFile + 'Failed, ,'+creditDataArray[creditDataIdArray.indexOf(cmprop)]+'\n';
				}
			}
			
		}
		else
		{
			invoiceObjectNotEmpty = true;
			
		}
		nlapiLogExecution('debug', 'totalInvoicesProcessed 1', totalInvoicesProcessed);
		nlapiLogExecution('debug', 'zeroCreditLinkedTransactions', JSON.stringify(zeroCreditLinkedTransactions));
		if(zeroCreditLinkedTransactions != null && zeroCreditLinkedTransactions != '' && zeroCreditLinkedTransactions.length>0){
			var cmAlreadyCame = [];
			for(var c=0; c<zeroCreditLinkedTransactions.length; c++){
				var cmPaltData = zeroCreditLinkedTransactions[c];
				var cmId = '';
				var linkedTranId = '';
				if(cmPaltData != null && cmPaltData != ''){
					linkedTranId = cmPaltData.split('||')[0];
					cmId = cmPaltData.split('||')[1];
					if (cmAlreadyCame.indexOf(cmId) == -1)
					{
					cmAlreadyCame.push(cmId);
					}
				    else
					{
						nlapiDeleteRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, linkedTranId);
						linkedTranId='';
					}
				}
				
				if(linkedTranId != null && linkedTranId != '')
				{
					nlapiSubmitField(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, linkedTranId, [FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD, FLD_TRANSACTION_LINE_AMOUNT, FLD_APPLIED_TO_INVOICE_LINK],[customRecordAppfPaymentApplicationLog, 0, '']);
					totalLinkedTransactionsProcessed++;
					if(Number(totalLinkedTransactionsProcessed) > Number(totalLinkedTransactionsToProceess))
								totalLinkedTransactionsProcessed = Number(totalLinkedTransactionsToProceess)
					var linkedTransactionsProcessedPercent = parseFloat(totalLinkedTransactionsProcessed)/parseFloat(totalLinkedTransactionsToProceess);
					if(linkedTransactionsProcessedPercent == null || linkedTransactionsProcessedPercent == '')
						linkedTransactionsProcessedPercent = 0;
					else
						linkedTransactionsProcessedPercent = parseFloat(linkedTransactionsProcessedPercent)*100;
					nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_LINKED_TRANSACTIONS_PROCESSED, FLD_LINKED_TRANSACTION_PROCESSED_PERCENT], [totalLinkedTransactionsProcessed, linkedTransactionsProcessedPercent]);
									
					linkedTransactionFile += linkedTranId+','+cmId+', ,0, , ,'+customRecordAppfPaymentApplicationLog+', \n';
					if(creditLinkedTransactions.indexOf(linkedTranId) == -1)
						creditLinkedTransactions.push(linkedTranId)
				}
				if(context.getRemainingUsage() < 200) {

					setRecoveryPoint();
					checkGovernance();
					}
				
			}
			
		}
		if (!isErrorOcuured && invoicesAppliedFile != null && invoicesAppliedFile != '' && ((cmArrayIndexProp == null || cmArrayIndexProp == '') && (indexUnappliedPalt == null || indexUnappliedPalt == '')  && (indexLinkedTransInv == null || indexLinkedTransInv == '') && (indexLinkedTransCM == null || indexLinkedTransCM == '')))
			{
				var indexLinkedTransGenIndex = 1;
				if (indexLinkedTransGen != null && indexLinkedTransGen != '')
					indexLinkedTransGenIndex = indexLinkedTransGen;
				
				try{
				var invoicesAppliedFileObj=nlapiLoadFile(invoicesAppliedFile);
				var invoicesAppliedFileData=invoicesAppliedFileObj.getValue();
				invoicesAppliedFileData=invoicesAppliedFileData.split('\n');
				invoicesAppliedFileData=invoicesAppliedFileData.slice(0,-1);	
				//nlapiLogExecution('debug','# of invoices lines applied for payment',invoicesAppliedFileData.length);
				nlapiLogExecution('debug','1st inv line applied for payment',invoicesAppliedFileData[1]);
				for(var i=indexLinkedTransGenIndex;i<invoicesAppliedFileData.length;i++)
				{
					try{
						var invoiceId=invoicesAppliedFileData[i].split(',')[0];
						var invoiceLinePWP=invoicesAppliedFileData[i].split(',')[4];

						var invoiceLineId=invoicesAppliedFileData[i].split(',')[1];
						var paymentAmount=invoicesAppliedFileData[i].split(',')[2];
						//if(invoiceLineId == 'INV_384-0001')
						//nlapiLogExecution('debug', 'paymentAmount', paymentAmount);
						if (paymentAmount == null || paymentAmount == '' || paymentAmount == 'null')
							paymentAmount = 0;
						var invLineTaxAmt=invoicesAppliedFileData[i].split(',')[3];
						if(invLineTaxAmt == null || invLineTaxAmt ==  '' || invLineTaxAmt == 'null')
							invLineTaxAmt = 0;
						//if(invoiceLineId == 'INV_384-0001')
						//nlapiLogExecution('debug', 'invLineTaxAmt', invLineTaxAmt);
						var paltInv = '';
						if(paltInvReslutsObj.hasOwnProperty(invoiceId+'||'+invoiceLineId)){
							paltInv = paltInvReslutsObj[invoiceId+'||'+invoiceLineId];
							totUpdatedPaltRecs.push(paltInv);
						}
						var differencePaymentAmt = 0;
						var differencePaymentAmtTax = 0;
						var paymentApplicationLinkedTransactionRec = null;
						//if(invoiceLineId == 'INV_384-0001')
						//nlapiLogExecution('debug', 'paltInv', paltInv);
						if(paltInv == null || paltInv == ''){
							paymentApplicationLinkedTransactionRec=nlapiCreateRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION);
							differencePaymentAmt = parseFloat(paymentAmount);
							differencePaymentAmtTax = parseFloat(invLineTaxAmt);
							
						}
						else{
							paymentApplicationLinkedTransactionRec=nlapiLoadRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, paltInv);
							var existingPaymentAmt = paymentApplicationLinkedTransactionRec.getFieldValue(FLD_TRANSACTION_LINE_AMOUNT);
							var existingPaymentAmtTax = paymentApplicationLinkedTransactionRec.getFieldValue(FLD_TRANSACTION_LINE_TAX);
							if (existingPaymentAmtTax == null || existingPaymentAmtTax == '')
								existingPaymentAmtTax = 0;
							//if(invoiceLineId == 'INV_384-0001')
							//nlapiLogExecution('debug', 'existingPaymentAmt', existingPaymentAmt);
							if(parseFloat(paymentAmount)!=parseFloat(existingPaymentAmt)){
								differencePaymentAmt = parseFloat(paymentAmount)-parseFloat(existingPaymentAmt);
							}
							else{
								differencePaymentAmt = 0;
							}
							if(parseFloat(invLineTaxAmt)!=parseFloat(existingPaymentAmtTax)){
								differencePaymentAmtTax = parseFloat(invLineTaxAmt)-parseFloat(existingPaymentAmtTax);
							}
							else{
								differencePaymentAmtTax = 0;
							}
						}
						//if(invoiceLineId == 'INV_384-0001')
					//	nlapiLogExecution('debug', 'differencePaymentAmt :: differencePaymentAmtTax', differencePaymentAmt+' :: '+differencePaymentAmtTax);
						if(paymentApplicationLinkedTransactionRec){
							//paymentApplicationLinkedTransactionRec.setFieldValue(FLD_PAYMENT_TRANSACTION_LINK,paymentNeedToUpdate);
							if(customRecordAppfPaymentApplicationLog)
							paymentApplicationLinkedTransactionRec.setFieldValue(FLD_CLIENT_PAYMENT_APPLICATION_LOG_RECORD,customRecordAppfPaymentApplicationLog);
							
							paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINK,invoiceId);
							paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_ID,invoiceLineId);
							
							paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT,Number(paymentAmount).toFixed(2));
							paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_TAX,invLineTaxAmt);
							
							
							
							var  pwpRecordFromInvoiceLine=invoiceLinePWP;
							if(pwpRecordFromInvoiceLine !=null && pwpRecordFromInvoiceLine !='' && pwpRecordFromInvoiceLine != 'null')
							{
								paymentApplicationLinkedTransactionRec.setFieldValue(FLD_TRANSACTION_LINE_PWP,pwpRecordFromInvoiceLine);
	
							}
							if (!invLineData.hasOwnProperty(invoiceId))
								{
									invLineData[invoiceId] = [];
								}
								var invcalcamt = parseFloat(differencePaymentAmt) - parseFloat(differencePaymentAmtTax);
								invLineData[invoiceId].push(invoiceLineId+'|'+invcalcamt);
								
							var paymentApplicationLinkedTransactionRecId=nlapiSubmitRecord(paymentApplicationLinkedTransactionRec,true,true);
							if(paymentApplicationLinkedTransactionRecId)
								invoiceLinkedTransactions.push(paymentApplicationLinkedTransactionRecId)
								
							totalLinkedTransactionsProcessed++
							if(Number(totalLinkedTransactionsProcessed) > Number(totalLinkedTransactionsToProceess))
								totalLinkedTransactionsProcessed = Number(totalLinkedTransactionsToProceess)
							var linkedTransactionsProcessedPercent = parseFloat(totalLinkedTransactionsProcessed)/parseFloat(totalLinkedTransactionsToProceess);
							if(linkedTransactionsProcessedPercent == null || linkedTransactionsProcessedPercent == '')
								linkedTransactionsProcessedPercent = 0;
							else
								linkedTransactionsProcessedPercent = parseFloat(linkedTransactionsProcessedPercent)*100;
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_LINKED_TRANSACTIONS_PROCESSED, FLD_LINKED_TRANSACTION_PROCESSED_PERCENT], [totalLinkedTransactionsProcessed, linkedTransactionsProcessedPercent]);
							
							linkedTransactionFile += paymentApplicationLinkedTransactionRecId+','+invoiceId+','+invoiceLineId+','+paymentAmount+','+pwpRecordFromInvoiceLine+', ,'+customRecordAppfPaymentApplicationLog+','+invLineTaxAmt+'\n';
						}
						
					}catch(el){
						isErrorOcuured=true;
						if ( el instanceof nlobjError ){
						nlapiLogExecution( 'DEBUG', 'System error Linked Transactions 2', el.getCode() + '\n' + el.getDetails());
						errorLog += 'System error :\n'+el.getDetails();
						}else{
						nlapiLogExecution( 'DEBUG', 'Unexpected error Linked Transactions 2', el.toString());
						errorLog += 'Unexpected error :\n'+el.toString();
						}
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
						break;
					}
						
					if (context.getRemainingUsage() <= 1000 && (parseInt(i)+1) < invoicesAppliedFileData.length)
					{
						nlapiLogExecution('debug', 'Resched @ Credit Linked Transactions creation', 'Resched @ Credit Linked Transactions creation');
						var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+new Date().getTime()+'.csv', 'CSV', linkedTransactionFile);
						linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
						nlapiLogExecution('debug', 'linkedTransactionFileId @ Credit Linked Transactions creation', linkedTransactionFileId);
						
						var invResultFileCSV = nlapiCreateFile('InvResultFile_'+new Date().getTime()+'.csv', 'CSV', invoiceResultsFile);
						invResultFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var InvResultFileFileId = nlapiSubmitFile(invResultFileCSV);
						nlapiLogExecution('debug', 'InvResultFileFileId @ Credit Linked Transactions creation', InvResultFileFileId);
						
						var params_ipalt = {};
						params_ipalt['custscript_ipalt_index'] =  parseInt(i)+1;
						params_ipalt['custscript_lt_file_gen'] =  linkedTransactionFileId;
						params_ipalt['custscript_appf_inv_result_file_id'] =  InvResultFileFileId;
						params_ipalt['custscript_palt_inv_data'] =  JSON.stringify(paltInvReslutsObj);
						
						params_ipalt[SPARAM_RANDOM_TEXT] = randomText;
						params_ipalt[SPARAM_INVOICE_DETAIL_OBJ_FORM] =mainObj;
						params_ipalt[SPARAM_CREDIT_DETAIL_OBJ_FORM] =creditObj;
						params_ipalt[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalIvoiceToProcess;
						params_ipalt[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesList;
						params_ipalt[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=customRecordAppfPaymentApplicationLog;
						params_ipalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=paymentApplicationSuccessFile; //needed for direct update, UI display
						params_ipalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=paymentApplicationCreditSuccessFile; //needed for direct update, UI display
						params_ipalt[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesAppliedFile; //other updates related to amounts, backend purpose
						params_ipalt['custscript_credit_linked_trans_data'] = creditLinkedTransactions+'';
						params_ipalt['custscript_invoice_linked_trans_data'] = invoiceLinkedTransactions+'';
						params_ipalt['custscript_invlinedata']=JSON.stringify(invLineData);
						params_ipalt[SPARAM_UPDATED_LINKED_TRANSACTIONS]=totUpdatedPaltRecs+'';

						params_ipalt[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentNeedToUpdate;
						nlapiLogExecution('debug', 'cmObj @ Credit Linked Transactions creation', JSON.stringify(cmObj));

						params_ipalt['custscript_cm_data_obj'] = JSON.stringify(cmObj);
						
						if(dataForPayment)
						params_ipalt[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
						
						nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_ipalt);
						isRescheduled = true;
						break;
							
					}
						
				}
				nlapiLogExecution('debug', 'totalLinkedTransactionsProcessed 2', totalLinkedTransactionsProcessed + ' isErrorOcuured='+isErrorOcuured);
				indexLinkedTransGen = null;
				}catch(e4){
					isErrorOcuured=true;
							if ( e4 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error', e4.getCode() + '\n' + e4.getDetails());
							errorLog += 'System error : \n'+e4.getDetails();
							}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error', e4.toString());
							errorLog += 'Unexpected error : \n'+e4.toString();
							}
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
				}
				
			}
			if (!isRescheduled)
			{
				
				if(!isErrorOcuured && linkedTransactionFile != null && linkedTransactionFile != '' && (indexUnappliedPalt == null || indexUnappliedPalt == '') ){
					try{
						if (parseFloat(totalLinkedTransactionsProcessed) != parseFloat(totalLinkedTransactionsToProceess))
						{
							
							totalLinkedTransactionsToProceess = parseFloat(totalLinkedTransactionsProcessed);
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_LINKED_TRANSACTION_PROCESSED_PERCENT, FLD_TOTAL_LINKED_TRANSACTIONS_TO_PROCESS],[100, totalLinkedTransactionsToProceess]);

						}
						var timeStamp = new Date().getTime();
						var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+randomText+'.csv', 'CSV', linkedTransactionFile);
						linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
						nlapiLogExecution('debug', 'linkedTransactionFileId', linkedTransactionFileId);  
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_LINKED_TRANSACTION_RESULT_FILE],[linkedTransactionFileId]);
					}catch(e4){
						isErrorOcuured=true;
						if ( e4 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error while Submitting Linked Transactions Result File', e4.getCode() + '\n' + e4.getDetails());
							errorLog += 'System error :\n'+e4.getDetails();
						}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error while Submitting Linked Transactions Result File', e4.toString());
							errorLog += 'Unexpected error :\n'+e4.toString();
						}
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
					}				
				}
				
				
				nlapiLogExecution('debug', 'totSSPaltRecs : totUpdatedPaltRecs', JSON.stringify(totSSPaltRecs)+' : '+JSON.stringify(totUpdatedPaltRecs));
				nlapiLogExecution('debug', 'cmObj', JSON.stringify(cmObj));
				if(!isRescheduled && !isErrorOcuured && (indexUnappliedPalt == null || indexUnappliedPalt == '') && (cmemoPercent != 100 && cmemoPercent != '100.0%')){
					var creditmemoArray = [];
					for(var cmprop in cmObj){
						
						creditmemoArray.push(cmprop);
					}
					if (cmArrayIndexProp == null || cmArrayIndexProp == '')
						cmArrayIndexProp = 0;
					nlapiLogExecution('debug', 'creditmemoArray Length', creditmemoArray?creditmemoArray.length:0)
					for(var cmo=cmArrayIndexProp; cmo <creditmemoArray.length; cmo++){
						try{
							var cmprop = creditmemoArray[cmo];
							var creditmemorec=nlapiLoadRecord('creditmemo', cmprop, {recordmode:'dynamic'});
							var applyCountCM=creditmemorec.getLineItemCount('apply');
							for(var cm=1;cm<=applyCountCM;cm++)
							{
								var isCMApplied = creditmemorec.getLineItemValue('apply', 'apply', cm);
								if (isCMApplied == 'T')
								{
									var InvinCM = creditmemorec.getLineItemValue('apply', 'doc', cm);

									if (allTransactions.indexOf(InvinCM) != -1)
									{
								creditmemorec.selectLineItem('apply',cm);
								creditmemorec.setCurrentLineItemValue('apply','apply','F');
								creditmemorec.commitLineItem('apply');
									}
								}
							}
							var cmObjArr = cmObj[cmprop];
							for(var a=0; a<cmObjArr.length; a++){
								var subData = cmObjArr[a];
								var invId = subData.split('||')[0];
								var invAmount = subData.split('||')[1];
								
									if(invAmount == null || invAmount == '')
									invAmount = 0;
									var cmLineNum = creditmemorec.findLineItemValue('apply', 'doc', invId);
									if(cmLineNum != -1)
									{
										
										creditmemorec.selectLineItem('apply',cmLineNum);
										creditmemorec.setCurrentLineItemValue('apply','apply','T');
										creditmemorec.setCurrentLineItemValue('apply','amount',parseFloat(invAmount).toFixed(2));
										creditmemorec.commitLineItem('apply');
					
									}	
								
							}
							
							var creditMemoRecordId=nlapiSubmitRecord(creditmemorec,true,true);	
						}catch(e2){
							isErrorOcuured=true;
							if ( e2 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error while Updating Credit Memo', e2.getCode() + '\n' + e2.getDetails());
							errorLog += 'System error :\n' + e2.getDetails();
							}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error Updating Invoice', e2.toString());
							errorLog += 'Unexpected error :\n' + e2.toString();
							}
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
							break;
						}
						totalCreditMemosProcessed = parseInt(cmo)+1;
						if(!isErrorOcuured && totalCreditMemosToProcess != null && totalCreditMemosToProcess != '' && parseFloat(totalCreditMemosToProcess)>0){
							try{
								var totalCreditMemosProcessedPercent = parseFloat(totalCreditMemosProcessed)/parseFloat(totalCreditMemosToProcess);
								if(totalCreditMemosProcessedPercent == null || totalCreditMemosProcessedPercent == '')
									totalCreditMemosProcessedPercent = 0;
								else
									totalCreditMemosProcessedPercent = parseFloat(totalCreditMemosProcessedPercent)*100;
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,customRecordAppfPaymentApplicationLog, [FLD_TOTAL_CREDIT_MEMOS_PROCESSED, FLD_CREDITS_PROCESSED_PERCENT], [totalCreditMemosProcessed, totalCreditMemosProcessedPercent]);
							}catch(e4){
								isErrorOcuured=true;
								if ( e4 instanceof nlobjError ){
								nlapiLogExecution( 'DEBUG', 'System error While ProcessingCredit Memos', e4.getCode() + '\n' + e4.getDetails());
								errorLog += 'System error :\n' + e4.getDetails();
								}else{
								nlapiLogExecution( 'DEBUG', 'Unexpected error @ Credit Memos Processing', e4.toString());
								errorLog += 'Unexpected error :\n' + e4.toString();
								}
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
							}
						}
						
						if (context.getRemainingUsage() <= 1000 && (parseInt(cmo)+1) < creditmemoArray.length)
							{
								nlapiLogExecution('debug', 'Resched @ Credits Processing', 'Resched @ Credits Processing');
								var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+new Date().getTime()+'.csv', 'CSV', linkedTransactionFile);
								linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
								var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
								nlapiLogExecution('debug', 'linkedTransactionFileId @ Backlinking Credit Linked Transactions', linkedTransactionFileId);
								var params_cmarr = {};
								var invResultFileCSV = nlapiCreateFile('InvResultFile_'+new Date().getTime()+'.csv', 'CSV', invoiceResultsFile);
						invResultFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var InvResultFileFileId = nlapiSubmitFile(invResultFileCSV);
						//nlapiLogExecution('debug', 'InvResultFileFileId @ Credit Linked Transactions creation', InvResultFileFileId);
						
							var creditMemoResultsFileCSV = nlapiCreateFile('CreditMemoResultFile_'+new Date().getTime()+'.csv', 'CSV', creditMemoResultsFile);
						creditMemoResultsFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var creditMemoResultsFileId = nlapiSubmitFile(creditMemoResultsFileCSV);
						
						        params_cmarr['custscript_appf_cm_result_file_id'] =  creditMemoResultsFileId;

						        params_cmarr['custscript_appf_inv_result_file_id'] =  InvResultFileFileId;
								params_cmarr['custscript_cmarr_index'] = parseInt(cmo)+1;
								params_cmarr[SPARAM_RANDOM_TEXT] = randomText;
								params_cmarr['custscript_lt_file_gen'] =  linkedTransactionFileId;
								params_cmarr[SPARAM_INVOICE_DETAIL_OBJ_FORM] =mainObj;
								params_cmarr[SPARAM_CREDIT_DETAIL_OBJ_FORM] =creditObj;
								params_cmarr[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalIvoiceToProcess;
								params_cmarr[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesList;
								params_cmarr[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=customRecordAppfPaymentApplicationLog;
								params_cmarr[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=paymentApplicationSuccessFile; //needed for direct update, UI display
								params_cmarr[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=paymentApplicationCreditSuccessFile; //needed for direct update, UI display
								params_cmarr[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesAppliedFile; //other updates related to amounts, backend purpose
								params_cmarr[SPARAM_UPDATED_LINKED_TRANSACTIONS]=totUpdatedPaltRecs+'';
								params_cmarr[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentNeedToUpdate;
								nlapiLogExecution('debug', 'cmObj @ Payment creation', JSON.stringify(cmObj));
								params_cmarr['custscript_cm_data_obj'] = JSON.stringify(cmObj);
								params_cmarr['custscript_credit_linked_trans_data'] = creditLinkedTransactions+'';
								params_cmarr['custscript_invoice_linked_trans_data'] = invoiceLinkedTransactions+'';
								params_cmarr['custscript_invlinedata']=JSON.stringify(invLineData);

			
								if(dataForPayment)
								params_cmarr[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
								nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_cmarr);
								isRescheduled = true;
								break;
								
							}
						
						
					}
				}
			
		
				if(!isRescheduled && !isErrorOcuured && (indexUnappliedPalt == null || indexUnappliedPalt == '')  && creditMemoResultsFile != null && creditMemoResultsFile != '' && creditDataIdArray.length > 1){
					try{
						var prevLen = creditMemoResultsFile.split('\n').length-1;
						if (prevLen < creditDataIdArray.length)
						{
							for (var z = 0; z < creditDataIdArray.length; z++)
							{
								
								if ((parseInt(z)+1) > prevLen)
								{
									creditMemoResultsFile += 'Failed, ,'+creditDataIdArray[z]+'\n';
								}
							}
							
						}
						var timeStamp = new Date().getTime();
						var creditMemoResultsFileCSV = nlapiCreateFile('CreditMemoResultFile_'+randomText+'.csv', 'CSV', creditMemoResultsFile);
						creditMemoResultsFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
						var creditMemoResultsFileId = nlapiSubmitFile(creditMemoResultsFileCSV);
						nlapiLogExecution('debug', 'creditMemoResultsFileId', creditMemoResultsFileId);  
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_CREDITS_RESULT_FILE],[creditMemoResultsFileId]);
					}catch(e4){
						isErrorOcuured=true;
						if ( e4 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error @ CreditMemo ResultFile', e4.getCode() + '\n' + e4.getDetails());
							errorLog += 'System error :\n' + e4.getDetails();
						}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error @ CreditMemo ResultFile', e4.toString());
							errorLog += 'Unexpected error :\n' + e4.toString();
						}
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
					}
					
				}
		
				nlapiLogExecution('debug','selectedInvoiceObj after apply credit to the invoices:selectedInvoiceObj',JSON.stringify(selectedInvoiceObj))
				

				

				var paymentId ='';
				var customerPayment='';
				if(!isRescheduled && !isErrorOcuured && (indexUnappliedPalt == null || indexUnappliedPalt == '') && (invPercent != 100 && invPercent != '100.0%'))
				{
				 nlapiLogExecution('debug','yielding script before payment creation', 'Date/Time: '+new Date())

					setRecoveryPoint();
					checkGovernance();
					try{
						var ltFils =[];
ltFils.push(new nlobjSearchFilter('custrecord_appf_pay_app_tran_lineid', null, 'isnotempty'));
ltFils.push(new nlobjSearchFilter('mainline', 'custrecord_appf_pay_app_tran_link', 'is', 'T'));
ltFils.push(new nlobjSearchFilter('custrecord_appf_pay_app_log_link', null, 'anyof', [customRecordAppfPaymentApplicationLog]));


var ltCols = [];
ltCols.push(new nlobjSearchColumn('internalid', 'custrecord_appf_pay_app_tran_link', 'group'));
ltCols.push(new nlobjSearchColumn('custrecord_appf_pay_app_tran_line_amt', null, 'sum'));




var ltSS = getAllSearchResults('customrecord_appf_pay_app_linked_trans', ltFils, ltCols);

var ltCrFils =[];
ltCrFils.push(new nlobjSearchFilter('custrecord_applied_to_invoice_link', null, 'noneof', '@NONE@'));
ltCrFils.push(new nlobjSearchFilter('mainline', 'custrecord_applied_to_invoice_link', 'is', 'T'));
ltCrFils.push(new nlobjSearchFilter('custrecord_appf_pay_app_log_link', null, 'anyof', [customRecordAppfPaymentApplicationLog]));


var ltCrCols = [];
ltCrCols.push(new nlobjSearchColumn('internalid', 'custrecord_applied_to_invoice_link', 'group'));
ltCrCols.push(new nlobjSearchColumn('custrecord_appf_pay_app_tran_line_amt', null, 'sum'));




var ltCrSS = getAllSearchResults('customrecord_appf_pay_app_linked_trans', ltCrFils, ltCrCols);

var ltInvObj = {};
for (var l =0; ltSS != null && l < ltSS.length; l++)
{
var invoiceId = ltSS[l].getValue('internalid', 'custrecord_appf_pay_app_tran_link', 'group');
							  var invPayAmount = ltSS[l].getValue('custrecord_appf_pay_app_tran_line_amt', null, 'sum');	
if(invPayAmount == null || invPayAmount == '')
invPayAmount = 0;
invPayAmount  = Number(invPayAmount);
ltInvObj[invoiceId] = Number(invPayAmount).toFixed(2);

}

for (var l =0; ltCrSS != null && l < ltCrSS.length; l++)
{
var invoiceId = ltCrSS[l].getValue('internalid', 'custrecord_applied_to_invoice_link', 'group');
							  var invPayAmount = ltCrSS[l].getValue('custrecord_appf_pay_app_tran_line_amt', null, 'sum');	
if(invPayAmount == null || invPayAmount == '')
invPayAmount = 0;
invPayAmount  = Number(invPayAmount);
if (ltInvObj.hasOwnProperty(invoiceId))
{
var revLtamt = Number(ltInvObj[invoiceId]) - Number(invPayAmount);
revLtamt = Number(revLtamt).toFixed(2);
ltInvObj[invoiceId] = revLtamt;
if (parseFloat(revLtamt) <= 0)
delete ltInvObj[invoiceId];
}

}

var ltssLen = 0;
if (ltSS != null && ltSS != '')
	ltssLen = ltSS.length;
	

						nlapiLogExecution('debug','ltSS length', ltssLen);


						nlapiLogExecution('debug','Payment Creation/Update Initiated', 'Date/Time: '+new Date());
												nlapiLogExecution('debug','dataForPayment in Payment Block', dataForPayment);

						if(dataForPayment)
						{
							dataForPayment=dataForPayment.split('||');
							var client=parseInt(dataForPayment[0]);
							var arAccount=dataForPayment[1];
							var currency=dataForPayment[2];
							var date=dataForPayment[3];
							var postingPeriod=dataForPayment[4];
							var memo=dataForPayment[5];
							var lineOfBusiness=dataForPayment[6];
							var department=dataForPayment[7];
							var office=dataForPayment[8];
							nlapiLogExecution('debug','client:',client);
							
							if (paymentNeedToUpdate == null || paymentNeedToUpdate == '')
							customerPayment = nlapiTransformRecord('customer',client, 'customerpayment', {recordmode:'dynamic'});
							else
							customerPayment = nlapiLoadRecord('customerpayment', paymentNeedToUpdate, {recordmode:'dynamic'});
							//customerPayment.setFieldValue('customer',client);
							var pymAccount = customerPayment.getFieldValue('account');
							var pymarAccount = customerPayment.getFieldValue('aracct');
							var pymcurrency = customerPayment.getFieldValue('currency');
							var pympostingperiod = customerPayment.getFieldValue('postingperiod');
							var pymdate = customerPayment.getFieldValue('trandate');
							//if(pymAccount != null && pymAccount != '')
								//customerPayment.setFieldValue('account',pymAccount);
							customerPayment.setFieldValues(FLD_CUSTOMER_PAYMENT_APPLICATION_LINKS, [customRecordAppfPaymentApplicationLog]);
							
							if (arAccount != null && arAccount != '' && arAccount != pymarAccount)
							customerPayment.setFieldValue('aracct',arAccount);
							if (currency != null && currency != '' && currency != pymcurrency)
							customerPayment.setFieldValue('currency',currency);
							if (date != null && date != '' && date != pymdate)
							customerPayment.setFieldValue('trandate',date);
							if (postingPeriod != null && postingPeriod != '' && postingPeriod != pympostingperiod)
							customerPayment.setFieldValue('postingperiod',postingPeriod);
							if (memo != null && memo != '')
							customerPayment.setFieldValue('memo',memo);
							if (lineOfBusiness != null && lineOfBusiness != '')
							customerPayment.setFieldValue('class',lineOfBusiness);
							if (department != null && department != '')
							customerPayment.setFieldValue('department',department);
							if (office != null && office != '')
							customerPayment.setFieldValue('location',office);
						}
						var lineCountOfInvoices=customerPayment.getLineItemCount('apply');
						nlapiLogExecution('debug','lineCountOfInvoices:',lineCountOfInvoices);
						for(var i=1;lineCountOfInvoices > 0 && i<=lineCountOfInvoices;i++)
						{
							customerPayment.selectLineItem('apply',i);
							customerPayment.setCurrentLineItemValue('apply','apply','F');
							customerPayment.commitLineItem('apply');
						}
						for (var lprop in ltInvObj)
                        {
                              var invoiceId = lprop;
							  var invPayAmount = Number(ltInvObj[lprop]);	
						
							var invoiceIdline=customerPayment.findLineItemValue('apply','doc',invoiceId);
							if (invoiceIdline != -1)
							{
															nlapiLogExecution('debug','invoiceId + invPayAmount',invoiceId+'+'+invPayAmount);							

								customerPayment.selectLineItem('apply',invoiceIdline);
								customerPayment.setCurrentLineItemValue('apply','apply','T');
								customerPayment.setCurrentLineItemValue('apply','amount',parseFloat(invPayAmount));
								customerPayment.commitLineItem('apply');
								
								var indexes = getAllIndexes(invoiceDataIdArray, invoiceId);
								for(var ind=0; ind<indexes.length; ind++){
									if (invoiceDataCompletedArray.indexOf(indexes[ind]) == -1)
									{
										if (invoiceResultsFile.indexOf('Success, ,'+invoiceDataArray[indexes[ind]]) == -1){
									invoiceResultsFile = invoiceResultsFile + 'Success, ,'+invoiceDataArray[indexes[ind]]+'\n';
									invoiceDataCompletedArray.push(indexes[ind]);
									totalInvoicesProcessed++;
										}
									}
				
				
								}
								
							}
							
						}
						if(processedCreditIds.length > 0)
						{
							nlapiLogExecution('debug','processedCreditIds:',processedCreditIds);
							customerPayment.setFieldValues(FLD_CREDITS_APPLIED, processedCreditIds);
						}
						else
						{
							//nlapiLogExecution('debug','processedCreditIds:',processedCreditIds);
							customerPayment.setFieldValue(FLD_CREDITS_APPLIED, null);
						}
						
						try{
							paymentId=nlapiSubmitRecord(customerPayment,true,true);
							nlapiLogExecution('debug','paymentId:',paymentId);
						}catch(el){
							isErrorOcuured = true;
							if ( el instanceof nlobjError ){
								nlapiLogExecution( 'DEBUG', 'System error @ Payment Creation', el.getCode() + '\n' + el.getDetails());
								failedReason = el.getDetails();
								errorLog += 'System error :\n'+el.getDetails();
							}else{
								nlapiLogExecution( 'DEBUG', 'Unexpected error @ Payment Creation', el.toString());
								failedReason = el.toString();
								errorLog += 'Unexpected error :\n'+el.toString();
							}
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
							
						}

						paymentNeedToUpdate = paymentId;
						nlapiLogExecution('debug','paymentNeedToUpdate',paymentNeedToUpdate);
					}catch(el){
						nlapiLogExecution('debug','9/17/2020 payment failed',paymentId);		
						isErrorOcuured = true;
						var failedReason = '';
						if ( el instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error @ Payment Creation', el.getCode() + '\n' + el.getDetails());
							failedReason = el.getDetails();
							errorLog += 'System error :\n' + el.getDetails();
						}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error @ Payment Creation', el.toString());
							failedReason = el.toString();
							errorLog += 'Unexpected error :\n' + el.toString();
						}
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
						for(var i=1;lineCountOfInvoices > 0 && i<=lineCountOfInvoices;i++)
						{
							var invoiceId=customerPayment.getLineItemValue('apply','doc',i);
							var indexes = getAllIndexes(invoiceDataIdArray, invoiceId);
							for(var ind=0; ind<indexes.length; ind++){
								if (invoiceDataCompletedArray.indexOf(indexes[ind]) == -1)
								{
								nlapiLogExecution('debug', '9/17/2020 check error per line fail', '9/17/2020 check error per line fail');
								invoiceResultsFile = invoiceResultsFile + 'Failed,'+failedReason+','+invoiceDataArray[indexes[ind]]+'\n';
								invoiceDataCompletedArray.push(indexes[ind]);
								totalInvoicesProcessed++;
								}
							}
						}
						
					}
					nlapiLogExecution('debug', 'totalInvoicesProcessed 2', totalInvoicesProcessed);
					if(!isErrorOcuured && paymentNeedToUpdate != null && paymentNeedToUpdate != '' && totalInvoicesToProcess != null && totalInvoicesToProcess != '' && parseFloat(totalInvoicesToProcess)>0){
						try{
							if (parseFloat(totalInvoicesProcessed) != parseFloat(totalInvoicesToProcess))
								totalInvoicesProcessed = parseFloat(totalInvoicesToProcess);
							var totalInvoicesProcessedPercent = parseFloat(totalInvoicesProcessed)/parseFloat(totalInvoicesToProcess);
							if(totalInvoicesProcessedPercent == null || totalInvoicesProcessedPercent == '')
								totalInvoicesProcessedPercent = 0;
							else
								totalInvoicesProcessedPercent = parseFloat(totalInvoicesProcessedPercent)*100;
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,customRecordAppfPaymentApplicationLog, [FLD_TOT_CHILD_INVCS_PROCESSED, FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT], [totalInvoicesProcessed, totalInvoicesProcessedPercent]);
						}catch(e4){
							isErrorOcuured=true;
							if ( e4 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error @ CreditMemo Processing', e4.getCode() + '\n' + e4.getDetails());
							errorLog += 'System error :\n' + e4.getDetails();
							}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error @ CreditMemo Processing', e4.toString());
							errorLog += 'Unexpected error :\n' + e4.toString();
							}
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
						}
					}
					
					if(!isErrorOcuured && invoiceResultsFile != null && invoiceResultsFile != '' && invoiceDataArray.length > 1){
						try{
							var prevLen = invoiceResultsFile.split('\n').length-1;
							var invErrorMsg = '';
							if (prevLen < invoiceDataArray.length)
							{
								var checkInvoiceError = 0;
								for (var z = 0; z < invoiceDataArray.length; z++)
								{
									
									if ((parseInt(z)+1) > prevLen)
									{
										invoiceResultsFile += 'Failed, ,'+invoiceDataArray[z]+'\n';
										totalInvoicesProcessed++;
										nlapiLogExecution('debug', '9/17/2020 fail per line', invoiceResultsFile);
										checkInvoiceError++;
										var totalInvoicesProcessedPercent = parseFloat(totalInvoicesProcessed)/parseFloat(totalInvoicesToProcess);
										if(totalInvoicesProcessedPercent == null || totalInvoicesProcessedPercent == '')
											totalInvoicesProcessedPercent = 0;
										else
											totalInvoicesProcessedPercent = parseFloat(totalInvoicesProcessedPercent)*100;
										nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,customRecordAppfPaymentApplicationLog, [FLD_TOT_CHILD_INVCS_PROCESSED, FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT], [totalInvoicesProcessed, totalInvoicesProcessedPercent]);
									}
								}
								
								if(checkInvoiceError > 0){
									invErrorMsg = 'No Invoices applied.Please check Account assigned in invoices.';
									
								}
								
							}
							var timeStamp = new Date().getTime();
							var invoiceResultsFileCSV = nlapiCreateFile('InvoiceResultFile_'+randomText+'.csv', 'CSV', invoiceResultsFile);
							invoiceResultsFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
							var invoiceResultsFileId = nlapiSubmitFile(invoiceResultsFileCSV);	
							nlapiLogExecution('debug', 'invoiceResultsFileId', invoiceResultsFileId);
							if(invErrorMsg == null || invErrorMsg == '')
								CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS;
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLS_TOT_CHILD_INV_RESULT_FILE,FLD_CUSTOMER_PAYMENT_STATUS,FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG],[invoiceResultsFileId,CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS,invErrorMsg]);
						}catch(e4){
							isErrorOcuured=true;
							if ( e4 instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'System error @ Invoice ResultFile', e4.getCode() + '\n' + e4.getDetails());
							errorLog += 'System error :\n' + e4.getDetails();
							}else{
							nlapiLogExecution( 'DEBUG', 'Unexpected error @ Invoice ResultFile', e4.toString());
							errorLog += 'Unexpected error :\n' + e4.toString();
							}
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
						}
						
							  
					}
					if(!isRescheduled && !isErrorOcuured && creditLinkedTransactions.length >0 && paymentId != null && paymentId != '' && ((indexLinkedTransGen == null || indexLinkedTransGen == '') && (indexLinkedTransInv == null || indexLinkedTransInv == '')))
					{
						nlapiLogExecution('debug', 'creditLinkedTransactions Resched', JSON.stringify(creditLinkedTransactions));
						
						var indexLinkedTransCMIndex = 0;
						if (indexLinkedTransCM != null && indexLinkedTransCM != '')
						indexLinkedTransCMIndex = indexLinkedTransCM;
				
						nlapiLogExecution('debug', '9/17/2020 check error', '9/17/2020 check error');
						//nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,customRecordAppfPaymentApplicationLog,[FLD_CUSTOMER_PAYMENT_APPLICATION_LINK],[paymentId])
						for(var t=indexLinkedTransCMIndex;t<creditLinkedTransactions.length;t++)
						{
								
							try{
								nlapiSubmitField(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION,creditLinkedTransactions[t],[FLD_PAYMENT_TRANSACTION_LINK],[paymentId]);
							}catch(el){
								isErrorOcuured = true;
								
								if ( el instanceof nlobjError ){
									nlapiLogExecution( 'DEBUG', 'System error @ Linking Pyament to Credit Linked Transaction', el.getCode() + '\n' + el.getDetails());
									errorLog += 'System error :\n' + el.getDetails();
								}else{
									nlapiLogExecution( 'DEBUG', 'Unexpected error @ Linking Pyament to Linked Transaction', el.toString());
									errorLog += 'Unexpected error :\n' + el.toString();
								}
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
								//break;
					
							}
							if (context.getRemainingUsage() <= 1000 && (parseInt(t)+1) < creditLinkedTransactions.length)
							{
								nlapiLogExecution('debug', 'Resched @ Backlinking Payment to Credit Linked Transactions', 'Resched @ Backlinking Payment to  Credit Linked Transactions');
								var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+new Date().getTime()+'.csv', 'CSV', linkedTransactionFile);
								linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
								var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
								nlapiLogExecution('debug', 'linkedTransactionFileId @ Backlinking Credit Linked Transactions', linkedTransactionFileId);
								var params_pcpalt = {};
								params_pcpalt['custscript_pcalt_index'] = parseInt(t)+1;
								params_pcpalt[SPARAM_RANDOM_TEXT] = randomText;
								params_pcpalt['custscript_lt_file_gen'] =  linkedTransactionFileId;
								params_pcpalt[SPARAM_INVOICE_DETAIL_OBJ_FORM] =mainObj;
								params_pcpalt[SPARAM_CREDIT_DETAIL_OBJ_FORM] =creditObj;
								params_pcpalt[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalIvoiceToProcess;
								params_pcpalt[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesList;
								params_pcpalt[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=customRecordAppfPaymentApplicationLog;
								params_pcpalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=paymentApplicationSuccessFile; //needed for direct update, UI display
								params_pcpalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=paymentApplicationCreditSuccessFile; //needed for direct update, UI display
								params_pcpalt[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesAppliedFile; //other updates related to amounts, backend purpose
								params_pcpalt[SPARAM_UPDATED_LINKED_TRANSACTIONS]=totUpdatedPaltRecs+'';
								params_pcpalt[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentNeedToUpdate;
								nlapiLogExecution('debug', 'cmObj @ Payment creation', JSON.stringify(cmObj));
								params_pcpalt['custscript_cm_data_obj'] = JSON.stringify(cmObj);
								params_pcpalt['custscript_credit_linked_trans_data'] = creditLinkedTransactions+'';
								params_pcpalt['custscript_invoice_linked_trans_data'] = invoiceLinkedTransactions+'';
								params_pcpalt['custscript_invlinedata']=JSON.stringify(invLineData);

			
								if(dataForPayment)
								params_pcpalt[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
								nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_pcpalt);
								isRescheduled = true;
								break;
								
							}
						}
						indexLinkedTransCM = null;
						
					}
					
					if(!isRescheduled && !isErrorOcuured && invoiceLinkedTransactions.length >0 && paymentId != null && paymentId != '' && ((indexLinkedTransGen == null || indexLinkedTransGen == '') && (indexLinkedTransCM == null || indexLinkedTransCM == ''))){
						nlapiLogExecution('debug', 'invoiceLinkedTransactions Resched', JSON.stringify(invoiceLinkedTransactions));
						var indexLinkedTransInvIndex = 0;
						if (indexLinkedTransInv != null && indexLinkedTransInv != '')
							indexLinkedTransInvIndex = indexLinkedTransInv;
						for(var t=indexLinkedTransInvIndex;t<invoiceLinkedTransactions.length;t++)
						{
							try{
								nlapiSubmitField(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION,invoiceLinkedTransactions[t],[FLD_PAYMENT_TRANSACTION_LINK],[paymentId]);
							}catch(el){
								isErrorOcuured = true;
								
								if ( el instanceof nlobjError ){
									nlapiLogExecution( 'DEBUG', 'System error @ Linking Pyament to Inv Linked Transaction', el.getCode() + '\n' + el.getDetails());
									errorLog += 'System error :\n' + el.getDetails();
								}else{
									nlapiLogExecution( 'DEBUG', 'Unexpected error @ Linking Pyament to Linked Transaction', el.toString());
									errorLog += 'Unexpected error :\n' + el.toString();
								}
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
								//break;
					
							}
							if (context.getRemainingUsage() <= 1000 && (parseInt(t)+1) < invoiceLinkedTransactions.length)
							{
								nlapiLogExecution('debug', 'Resched @ Payment Backlinking to Inv Linked Trans', 'Resched @ Payment Backlinking to Inv Linked Trans');
								var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+new Date().getTime()+'.csv', 'CSV', linkedTransactionFile);
								linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
								var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
								nlapiLogExecution('debug', 'linkedTransactionFileId @ Payment Backlinking to Inv Linked Trans', linkedTransactionFileId);
								var params_pipalt = {};
								params_pipalt['custscript_pialt_index'] = parseInt(t)+1;
								params_pipalt['custscript_lt_file_gen'] =  linkedTransactionFileId;
								params_pipalt[SPARAM_RANDOM_TEXT] = randomText;
								params_pipalt[SPARAM_INVOICE_DETAIL_OBJ_FORM] =mainObj;
								params_pipalt[SPARAM_CREDIT_DETAIL_OBJ_FORM] =creditObj;
								params_pipalt[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalIvoiceToProcess;
								params_pipalt[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesList;
								params_pipalt[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=customRecordAppfPaymentApplicationLog;
								params_pipalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=paymentApplicationSuccessFile; //needed for direct update, UI display
								params_pipalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=paymentApplicationCreditSuccessFile; //needed for direct update, UI display
								params_pipalt[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesAppliedFile; //other updates related to amounts, backend purpose
								params_pipalt[SPARAM_UPDATED_LINKED_TRANSACTIONS]=totUpdatedPaltRecs+'';
								params_pipalt[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentNeedToUpdate;
								nlapiLogExecution('debug', 'cmObj @ Payment Backlinking to Inv Linked Trans', JSON.stringify(cmObj));
								params_pipalt['custscript_cm_data_obj'] = JSON.stringify(cmObj);
								params_pipalt['custscript_invoice_linked_trans_data'] = invoiceLinkedTransactions+'';
								params_pipalt['custscript_credit_linked_trans_data'] = creditLinkedTransactions+'';
								params_pipalt['custscript_invlinedata']=JSON.stringify(invLineData);
			
								if(dataForPayment)
								params_pipalt[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
								nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_pipalt);
								isRescheduled = true;
								break;
								
							}
						}
						indexLinkedTransInv = null;
							
					}
				
				}
				if (!isRescheduled)
				{
					if(!isErrorOcuured && paymentNeedToUpdate !=null && paymentNeedToUpdate !='')
					{
						if (indexUnappliedPalt == null || indexUnappliedPalt == '') 
						nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG,customRecordAppfPaymentApplicationLog,[FLD_CUSTOMER_PAYMENT_APPLICATION_LINK],[paymentNeedToUpdate])
						try
						{
							if (indexUnappliedPalt == null || indexUnappliedPalt == '') 
							{
							/*var paymentRecord = nlapiLoadRecord('customerpayment', paymentNeedToUpdate);
							paymentRecord.setFieldValues(FLD_CUSTOMER_PAYMENT_APPLICATION_LINKS, [customRecordAppfPaymentApplicationLog]);
							nlapiSubmitRecord(paymentRecord);*/
							nlapiLogExecution( 'DEBUG', 'mainObj:', mainObj);
							mainObj=JSON.parse(mainObj);
							if (creditObj)
							creditObj = JSON.parse(creditObj);

							//nlapiLogExecution('debug','invoiceInternalidInPaymentRec',invoiceInternalidInPaymentRec);
							if(mainObj !=null && mainObj !='')
							{
								for(var prop in mainObj)
								{
									processedInvoiceIds.push(prop);

								}
							}

							if(creditObj !=null && creditObj !='')
							{
								for(var prop in creditObj)
								{
										processedCreditIds.push(prop);

								}
							}
							

							var processedTransactionIds = processedInvoiceIds.concat(processedCreditIds);
							if(customRecordAppfPaymentApplicationLog !=null && customRecordAppfPaymentApplicationLog !=''){
								var processedPercentFields = nlapiLookupField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT, FLD_CREDITS_PROCESSED_PERCENT]);
								if(processedPercentFields == null || processedPercentFields == '' || parseFloat(processedPercentFields[FLD_TOT_CHILD_INVCS_PROCESSED_PERCENT]) < 100 || parseFloat(processedPercentFields[FLD_CREDITS_PROCESSED_PERCENT]) < 100)
									CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY = CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS;
								//nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_CUSTOMER_PAYMENT_STATUS],[CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLETED_SUCCESSFULLY])
							
							}
						
							}
							
							var uncheckedPalts = [];
							if (unappliedDataArr == null || unappliedDataArr == '')
							{
							if(!isErrorOcuured && totSSPaltRecs.length > 0){
								if(totUpdatedPaltRecs != null && totUpdatedPaltRecs != '' && totUpdatedPaltRecs.length>0){
									var diffArr = arrayDiff(eliminateDuplicates(totSSPaltRecs), eliminateDuplicates(totUpdatedPaltRecs));
									for(var d=0; d<diffArr.length; d++){
										uncheckedPalts.push(diffArr[d]);
									}
								}
								
								else{
									for(var d=0; d<totSSPaltRecs.length; d++){
										uncheckedPalts.push(totSSPaltRecs[d]);
									}
								}
								
							}
							}
							else
							{
								uncheckedPalts = unappliedDataArr.split(',');
								
							}
							nlapiLogExecution('debug', 'uncheckedPalts', JSON.stringify(uncheckedPalts));
							if(!isErrorOcuured && uncheckedPalts != null && uncheckedPalts != '' && uncheckedPalts.length>0){
								var indexUnappliedPaltIndex = 0;
								if (indexUnappliedPalt != null && indexUnappliedPalt != '')
								{
									indexUnappliedPaltIndex = indexUnappliedPalt;
								}
								for(var u=indexUnappliedPaltIndex; u<uncheckedPalts.length; u++){
									try{
									var paltRec = nlapiLoadRecord(CUSTOM_RECORD_PAYMENT_APPLICATION_LINKED_TRANSACTION, uncheckedPalts[u]);
									var tranLink = paltRec.getFieldValue(FLD_TRANSACTION_LINK);
									var appliedtranLink = paltRec.getFieldValue(FLD_APPLIED_TO_INVOICE_LINK);

									var existingTransLineAmt = paltRec.getFieldValue(FLD_TRANSACTION_LINE_AMOUNT);
									if(existingTransLineAmt == null || existingTransLineAmt == '')
										existingTransLineAmt = 0;
									var existingTransLineAmtTax = paltRec.getFieldValue(FLD_TRANSACTION_LINE_TAX);
									if(existingTransLineAmtTax == null || existingTransLineAmtTax == '')
										existingTransLineAmtTax = 0;
									var pwp = paltRec.getFieldValue(FLD_TRANSACTION_LINE_PWP);
									
									if(parseFloat(existingTransLineAmt)!=0 && pwp != null && pwp != ''){
										var pwpRec = nlapiLoadRecord(CUSTOM_RECORD_PAY_WHEN_PAID_WRAPPER_RECORD, pwp);
										var invLinePaymentAmt = pwpRec.getFieldValue(FLD_INVOICE_LINE_PAYMENT_AMOUNT);

										if(invLinePaymentAmt != null && invLinePaymentAmt != ''){
											invLinePaymentAmt = parseFloat(invLinePaymentAmt)-(parseFloat(existingTransLineAmt) - parseFloat(existingTransLineAmtTax));
										}
										if(invLinePaymentAmt == null || invLinePaymentAmt == '')
											invLinePaymentAmt = 0;
										pwpRec.setFieldValue(FLD_INVOICE_LINE_PAYMENT_AMOUNT, invLinePaymentAmt);
										nlapiSubmitRecord(pwpRec, true, true);						
									}
									
									if (tranLink != null && tranLink != '' && appliedtranLink != null && appliedtranLink != '' && (pwp == null || pwp == ''))
									{
										
										var cmemoRec = nlapiLoadRecord('creditmemo', tranLink, {recordmode:'dynamic'});
										var applymatchedline = cmemoRec.findLineItemValue('apply', 'doc', appliedtranLink.toString());
										if (applymatchedline != -1)
										{
											var existingAppliedAmt = cmemoRec.getLineItemValue('apply', 'amount', applymatchedline);
											if (existingAppliedAmt == null || existingAppliedAmt == '')
											existingAppliedAmt = 0;
											var existingAppliedInvCheck = cmemoRec.getLineItemValue('apply', 'apply', applymatchedline);
											 if (existingAppliedInvCheck == 'T')
											 {
												 existingAppliedAmt = parseFloat(existingAppliedAmt)- parseFloat(existingTransLineAmt);
												 //existingAppliedAmt = Math.round(existingAppliedAmt*100)/100;
												cmemoRec.selectLineItem('apply', applymatchedline);
												cmemoRec.setCurrentLineItemValue('apply', 'amount', existingAppliedAmt);
												cmemoRec.commitLineItem('apply');
											 }
											 nlapiSubmitRecord(cmemoRec, true, true);
										}

										
									}
									//paltRec.setFieldValue('isinactive', 'T');
									paltRec.setFieldValue(FLD_TRANSACTION_LINE_AMOUNT, 0);
									nlapiSubmitRecord(paltRec, true, true);
									
									}catch(el){
										isErrorOcuured=true;
										if ( el instanceof nlobjError ){
										nlapiLogExecution( 'DEBUG', 'System error @ Zero out unchecked Linked Transactions', el.getCode() + '\n' + el.getDetails());
										errorLog += 'System error :\n' + el.getDetails();
										}else{
										nlapiLogExecution( 'DEBUG', 'Unexpected error @ Zero out unchecked Linked Transactions', el.toString());
										errorLog += 'Unexpected error :\n' + el.toString();
										}
										nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog, [FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG], [errorLog]);
										break;
									}
									if (context.getRemainingUsage() <= 1000 && (parseInt(u)+1) < uncheckedPalts.length)
											{
												nlapiLogExecution('debug', 'Resched @ CM & PWP Updation', 'Resched @ CM & PWP Updation');
												nlapiLogExecution('debug', 'mainObj @ CM & PWP Updation', JSON.stringify(mainObj));
												nlapiLogExecution('debug', 'creditObj @ CM & PWP Updation', JSON.stringify(creditObj));
												var linkedTransactionFileCSV = nlapiCreateFile('LinkedTransactionFile_'+new Date().getTime()+'.csv', 'CSV', linkedTransactionFile);
												linkedTransactionFileCSV.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
												var linkedTransactionFileId = nlapiSubmitFile(linkedTransactionFileCSV);
												nlapiLogExecution('debug', 'linkedTransactionFileId @ CM & PWP Updation', linkedTransactionFileId);
												var params_unpalt = {};
												params_unpalt['custscript_unappl_index'] = parseInt(u)+1;
												params_unpalt['custscript_lt_file_gen'] =  linkedTransactionFileId;
												params_unpalt[SPARAM_RANDOM_TEXT] = randomText;
												params_unpalt[SPARAM_INVOICE_DETAIL_OBJ_FORM] = context.getSetting('SCRIPT',SPARAM_INVOICE_DETAIL_OBJ_FORM);
												params_unpalt[SPARAM_CREDIT_DETAIL_OBJ_FORM] =context.getSetting('SCRIPT',SPARAM_CREDIT_DETAIL_OBJ_FORM);
												params_unpalt[SPARAM_TOTAL_INVOICE_NEED_TO_PROCESS]=totalIvoiceToProcess;
												params_unpalt[SPARAM_SELECTED_INVOICE_LIST] =selectedInvoicesList;
												params_unpalt[SPARAM_APPF_PAYMENT_APPLICATION_LOG_ID]=customRecordAppfPaymentApplicationLog;
												params_unpalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID]=paymentApplicationSuccessFile; //needed for direct update, UI display
												params_unpalt[SPARAM_PAYMENT_APPLICATION_SUCCESS_FILE_ID_CM]=paymentApplicationCreditSuccessFile; //needed for direct update, UI display
												params_unpalt[SPARAM_PAYMENT_APPLICATION_INV_FILE]=invoicesAppliedFile; //other updates related to amounts, backend purpose
												params_unpalt[SPARAM_UPDATED_LINKED_TRANSACTIONS]=totUpdatedPaltRecs+'';
												params_unpalt[SPARAM_PAYMENT_NEED_TO_UPDATE] = paymentNeedToUpdate;
												nlapiLogExecution('debug', 'cmObj @ CM & PWP Updation', JSON.stringify(cmObj));
												params_unpalt['custscript_cm_data_obj'] = JSON.stringify(cmObj);
												params_unpalt['custscript_invoice_linked_trans_data'] = invoiceLinkedTransactions+'';
												params_unpalt['custscript_credit_linked_trans_data'] = creditLinkedTransactions+'';
												params_unpalt['custscript_appf_unchecked_linked_trans'] = uncheckedPalts+'';

												params_unpalt['custscript_invlinedata']=JSON.stringify(invLineData);
						
												if(dataForPayment)
												params_unpalt[SPARAM_DATA_FOR_PAYMENT]=dataForPayment;	
												nlapiScheduleScript(context.getScriptId(), context.getDeploymentId(), params_unpalt);
												isRescheduled = true;
												break;
												
											}
								}
							}
						
						  paymentUpdatedSuccessFullyBoolean=true;
						//var paymentRecordID=nlapiSubmitRecord(paymentRecord,true,true);
						}
						catch(p)
						{
							isErrorOcuured=true;
							paymentUpdatedSuccessFullyBoolean=false;
							if ( p instanceof nlobjError ){
							nlapiLogExecution( 'DEBUG', 'Payment Level system error', p.getCode() + '\n' + p.getDetails());
							errorLog += 'System error :\n' + p.getDetails();
							}else{
							nlapiLogExecution( 'DEBUG', 'Payment Level unexpected error', p.toString());
							errorLog += 'Unexpected error :\n' + p.toString();
							}
							
							if(customRecordAppfPaymentApplicationLog !=null && customRecordAppfPaymentApplicationLog !='')
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_CUSTOMER_PAYMENT_STATUS,FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG],[CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS,errorLog]);
						}
						nlapiLogExecution('debug','coming inside payment not empty block should not come when payment created inside schedule script:')
						
					}	
					nlapiLogExecution('debug','paymentUpdatedSuccessFullyBoolean outside invoice block:',paymentUpdatedSuccessFullyBoolean);
   
				  if (!isRescheduled)
				  {
						var fileDataForReadyForProcessing = [];
				  
							if(!isErrorOcuured && processedInvoiceIds.length > 0 && customRecordAppfPaymentApplicationLog !=null && customRecordAppfPaymentApplicationLog !='')
							{
								  var ssUnsuccessDataFile='';
									ssUnsuccessDataFile += 'Invoice ID,Status\n';
									var ssDataFile= '';
								
									
									
									
									
									for(var v=0;v<values.length;v++)
									{
										if(v == 0)
										{
											var columns=values[v];
											ssDataFile=columns+'\n';
										//	nlapiLogExecution('debug','length 0 csv headings:',values.length);
										}
										else
										{
											var columns=values[v];
											var columnsValues=columns.split(',');	
                                            if(processedInvoiceIds.indexOf(columnsValues[0]) != -1)
											{										
										ssUnsuccessDataFile += columnsValues[0]+','+PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING+'\n';
												
												
								
								ssDataFile += columnsValues[0]+','+PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING+','+columnsValues[2]+','+columnsValues[3]+','+columnsValues[4]+','+columnsValues[5]+'|'+customRecordAppfPaymentApplicationLog+'\n';	
								
								var invIDForProcessing = columnsValues[0];
								
								var invStatusForProcessing = PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING;
								
								var newBackLinksInv = customRecordAppfPaymentApplicationLog;
								
								if (columnsValues[5] != null && columnsValues[5] != '')
								{
								
								newBackLinksInv = columnsValues[5] + '|' + newBackLinksInv;

								}
								
								fileDataForReadyForProcessing.push(invIDForProcessing + ',' + newBackLinksInv + ',1\n');
								
											}
												
										}
									}

								
							 

							}

							//Credits section processingJOBID
							if(!isErrorOcuured && processedCreditIds.length > 0 && customRecordAppfPaymentApplicationLog !=null && customRecordAppfPaymentApplicationLog !='')
							{

								  var ssUnsuccessDataFile='';
									ssUnsuccessDataFile += 'Credit ID,Status\n';
									var ssDataFile= '';
								   
										
										
										for(var v=0;v<creditValues.length;v++)
										{

											if(v == 0)
											{
												var columns=creditValues[v];
												ssDataFile=columns+'\n';
											//	nlapiLogExecution('debug','length 0 csv headings:',values.length);
											}
											else
											{
												var columns=creditValues[v];
												var columnsValues=columns.split(',');	
												
												
										
												if(processedCreditIds.indexOf(columnsValues[0]) != -1)
												{	
											
											
											ssUnsuccessDataFile += columnsValues[0]+','+PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING+'\n';
								
									ssDataFile += columnsValues[0]+','+PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING+','+columnsValues[2]+'|'+customRecordAppfPaymentApplicationLog+'\n';	
									
									var credmemoIDForProcessing = columnsValues[0];
									var credmemoStatusForProcessing = PAYMENT_APPLICATION_SUITELET_STATUS_READY_FOR_PROCESSING;
									
									var newBackLinkscredmemo = customRecordAppfPaymentApplicationLog;
									if (columnsValues[2] != null && columnsValues[2] != '')
									{
									newBackLinkscredmemo = columnsValues[2] + '|' + newBackLinkscredmemo;
									}
									
									fileDataForReadyForProcessing.push(credmemoIDForProcessing + ',' + newBackLinkscredmemo + ',2\n');
					
												}
											}
										}

									
								
							}
							
							
							
							
							
							if (!isErrorOcuured && fileDataForReadyForProcessing.length>0)
							{
								fileDataForReadyForProcessing = eliminateDuplicates(fileDataForReadyForProcessing);
								var moduleResult = parseInt(fileDataForReadyForProcessing.length)%5;
								var totalTrans = (parseInt(fileDataForReadyForProcessing.length)-parseInt(moduleResult))/5;
								nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_TRANSACTIONS_TO_PROCESS, FLD_BACKLINKING_STATUS],[fileDataForReadyForProcessing.length, CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_IN_PROGRESS]);
								for(var q=0; q<5; q++){
									var fileDataForReadyForProcessingData = '';
									var startingIndex = parseInt(q)*parseInt(totalTrans);
									var endingIndex = parseInt(startingIndex)+parseInt(totalTrans);
									if(q==4)
										endingIndex = parseInt(endingIndex)+parseInt(moduleResult);
									
									if(parseInt(endingIndex) > 0){
										nlapiLogExecution('debug', 'Loop'+q, startingIndex+ ' :: ' +endingIndex);
										for(var tp=startingIndex; tp<endingIndex; tp++){
											fileDataForReadyForProcessingData = fileDataForReadyForProcessingData + fileDataForReadyForProcessing[tp];										
										}
										//create text file
										//send text file id to 3rd scheduled script
										//in 3rd schedule script process 0 to length-2 and update inv/credit memo
																		
										var timeStamp = new Date().getTime();
										var readyForProcessingFileCreate=nlapiCreateFile('Selected_Transactions_Ready_For_Processing_'+timeStamp+'.txt','PLAINTEXT',fileDataForReadyForProcessingData);
										readyForProcessingFileCreate.setFolder(PAYMENT_APPLICATION_CSV_FOLDER_ID);
										var readyForProcessingCreateFileID= nlapiSubmitFile(readyForProcessingFileCreate);
										
										if(readyForProcessingCreateFileID != null && readyForProcessingCreateFileID != ''){
											nlapiLogExecution('debug', 'Calling SC #3', 'Calling SC #3');
											var params3 = {};
											params3[SPARAM_READY_FOR_PROCESSING_FILE_ID] = readyForProcessingCreateFileID;
											params3[SPARAM_PAYMENT_APPLICATION_LOG_ID] = customRecordAppfPaymentApplicationLog;
											params3[SPARAM_INVOICES_PWP_UPDATE_DATA] = JSON.stringify(invLineData);
											params3['custscript_tot_trans_ready_for_process'] = fileDataForReadyForProcessing.length;
											nlapiLogExecution('debug', 'invLineData'+q, JSON.stringify(invLineData));
											nlapiScheduleScript(SCRIPT_APPF_UPDATE_CLIENT_PAYMENT_APPLICATION_3, null, params3);
										}
									}
								
								
								}
							}
						if(isErrorOcuured)
							nlapiSubmitField(CUSTOM_RECORD_CUSTOMER_PAYMENT_APPLICATION_LOG, customRecordAppfPaymentApplicationLog,[FLD_CUSTOMER_PAYMENT_STATUS,FLD_CUSTOMER_PAYMENT_APPLICATION_ERROR_LOG],[CUSTOMER_PAYMENT_APPLICATION_SUITELET_STATUS_COMPLEYTED_WITH_ERRORS, errorLog]);
							}
					}
			}
}

function getCustomerStatus(pwpRecord,fielID,fieldValue) 
{
	                    var invAmtSum = fieldValue;
						var invLinePaymentAmtSum = fieldValue;
						var crditAmtSum = fieldValue;
						
						var crditStatus=''
						
						if(fielID!=FLD_PWP_INVOICED_AMT)
							invAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICED_AMT);
						
						if(fielID!=FLD_PWP_INVOICE_LINE_PAYMENT_AMT)
							invLinePaymentAmtSum=pwpRecord.getFieldValue(FLD_PWP_INVOICE_LINE_PAYMENT_AMT);
						
						if(fielID!=FLD_PWP_CRED_MEMO_AMT)
							crditAmtSum=pwpRecord.getFieldValue(FLD_PWP_CRED_MEMO_AMT);
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{	
					if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)==0)
							crditStatus=STATUS_PAYMENT_PENDING
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && ((parseFloat(invAmtSum)-parseFloat(invLinePaymentAmtSum))>0))
							crditStatus=STATUS_PARTIALLY_PAID
						}
						if (invAmtSum != null && invAmtSum != '' && invLinePaymentAmtSum != null && invLinePaymentAmtSum != '' && crditAmtSum!=null && crditAmtSum!='')
						{
						if(parseFloat(invAmtSum)>0 && parseFloat(invLinePaymentAmtSum)>0 && parseFloat(invAmtSum)==(parseFloat(invLinePaymentAmtSum)+parseFloat(crditAmtSum)))
							crditStatus=STATUS_PAID
						}
							
							return crditStatus
	
}

function percentage(partialValue, totalValue) {
   return (100 * partialValue) / totalValue;
}


function arrayDiff(arr1, arr2){

	Array.prototype.diff = function(a) {
		    return this.filter(function(i) {return a.indexOf(i) < 0;});
	};
	return arr1.diff(arr2);
}

function eliminateDuplicates(arr) 
{
var i,
len=arr.length,
out=[],
obj={};

for (i=0;i<len;i++) {
obj[arr[i]]=0;
}
for (i in obj) {
out.push(i);
}
return out;
}

function getAllIndexes(arr, val) {
    var indexes = [], i3 = -1;
    while ((i3 = arr.indexOf(val, i3+1)) != -1){
        indexes.push(i3);
    }
    return indexes;
}



function setRecoveryPoint() {
    var state = nlapiSetRecoveryPoint();

    if(state.status == 'SUCCESS')
        return;
    if(state.status == 'RESUME') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        handleScriptRecovery();
    } else if (state.status == 'FAILURE') {
        nlapiLogExecution('DEBUG', 'setRecoveryPoint', 'Failed to create recovery point. Reason = ' + state.reason + ' / Size = ' + state.size);
    }
}

function checkGovernance() {
    var context = nlapiGetContext();

    if(context.getRemainingUsage() < 10000) {
        var state = nlapiYieldScript();
        if(state.status == 'FAILURE') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Failed to yield script, exiting: Reason = ' + state.reason + ' / Size = ' + state.size);
            throw 'Failed to yield script';
        } else if (state.status == 'RESUME') {
            nlapiLogExecution('DEBUG', 'checkGovernance', 'Resuming script because of ' + state.reason + '.  Size = ' + state.size);
        }
    }
}



function getAllSearchResults(record_type, filters, columns)
		{
			var search = nlapiCreateSearch(record_type, filters, columns);
			search.setIsPublic(true);

			var searchRan = search.runSearch()
			,	bolStop = false
			,	intMaxReg = 1000
			,	intMinReg = 0
			,	result = [];

			while (!bolStop && nlapiGetContext().getRemainingUsage() > 10)
			{
				// First loop get 1000 rows (from 0 to 1000), the second loop starts at 1001 to 2000 gets another 1000 rows and the same for the next loops
				var extras = searchRan.getResults(intMinReg, intMaxReg);

				result = searchUnion(result, extras);
				intMinReg = intMaxReg;
				intMaxReg += 1000;
				// If the execution reach the the last result set stop the execution
				if (extras.length < 1000)
				{
					bolStop = true;
				}
			}

			return result;
		}
		
		
function searchUnion(target, array)
{
		return target.concat(array); // TODO: use _.union
}